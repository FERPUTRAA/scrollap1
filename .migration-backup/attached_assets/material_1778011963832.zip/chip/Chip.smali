.class public Lcom/google/android/material/chip/Chip;
.super Landroidx/appcompat/widget/AppCompatCheckBox;

# interfaces
.implements Lcom/google/android/material/chip/b$a;
.implements Lcom/google/android/material/shape/s;
.implements Lcom/google/android/material/internal/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/chip/Chip$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/appcompat/widget/AppCompatCheckBox;",
        "Lcom/google/android/material/chip/b$a;",
        "Lcom/google/android/material/shape/s;",
        "Lcom/google/android/material/internal/h<",
        "Lcom/google/android/material/chip/Chip;",
        ">;"
    }
.end annotation


# static fields
.field private static final A:Landroid/graphics/Rect;

.field private static final B:[I

.field private static final C:[I

.field private static final D:Ljava/lang/String; = "http://schemas.android.com/apk/res/android"

.field private static final E:I = 0x30

.field private static final F:Ljava/lang/String; = "android.widget.Button"

.field private static final G:Ljava/lang/String; = "android.widget.CompoundButton"

.field private static final H:Ljava/lang/String; = "android.widget.RadioButton"

.field private static final I:Ljava/lang/String; = "android.view.View"

.field private static final w:Ljava/lang/String; = "Chip"

.field private static final x:I

.field private static final y:I = 0x0

.field private static final z:I = 0x1


# instance fields
.field private e:Lcom/google/android/material/chip/b;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Landroid/graphics/drawable/InsetDrawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private g:Landroid/graphics/drawable/RippleDrawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private h:Landroid/view/View$OnClickListener;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Lcom/google/android/material/internal/h$a;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/internal/h$a<",
            "Lcom/google/android/material/chip/Chip;",
            ">;"
        }
    .end annotation
.end field

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:Z

.field private n:Z

.field private o:I

.field private p:I
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private q:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final r:Lcom/google/android/material/chip/Chip$c;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private s:Z

.field private final t:Landroid/graphics/Rect;

.field private final u:Landroid/graphics/RectF;

.field private final v:Lcom/google/android/material/resources/f;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_Chip_Action:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    sput v0, Lcom/google/android/material/chip/Chip;->x:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/material/chip/Chip;->A:Landroid/graphics/Rect;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const v0, 0x10100a1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/material/chip/Chip;->B:[I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const v0, 0x101009f

    const/4 v1, 0x0

    move v2, v1

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/material/chip/Chip;->C:[I

    const/4 v1, 0x1

    or-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/Chip;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget v0, Lcom/google/android/material/R$attr;->chipStyle:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/chip/Chip;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget v4, Lcom/google/android/material/chip/Chip;->x:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatCheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    new-instance p1, Landroid/graphics/Rect;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->t:Landroid/graphics/Rect;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance p1, Landroid/graphics/RectF;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->u:Landroid/graphics/RectF;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance p1, Lcom/google/android/material/chip/Chip$a;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {p1, p0}, Lcom/google/android/material/chip/Chip$a;-><init>(Lcom/google/android/material/chip/Chip;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->v:Lcom/google/android/material/resources/f;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {p0, p2}, Lcom/google/android/material/chip/Chip;->G(Landroid/util/AttributeSet;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0, p2, p3, v4}, Lcom/google/android/material/chip/b;->a1(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/chip/b;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {p0, v0, p2, p3}, Lcom/google/android/material/chip/Chip;->n(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setChipDrawable(Lcom/google/android/material/chip/b;)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-static {p0}, Landroidx/core/view/k1;->R(Landroid/view/View;)F

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1, v1}, Lcom/google/android/material/shape/j;->n0(F)V

    const/4 v7, 0x0

    sget-object v2, Lcom/google/android/material/R$styleable;->Chip:[I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x0

    move v7, v1

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-array v5, v1, [I

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v3, p3

    move v3, p3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->Chip_shapeAppearance:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance p2, Lcom/google/android/material/chip/Chip$c;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {p2, p0, p0}, Lcom/google/android/material/chip/Chip$c;-><init>(Lcom/google/android/material/chip/Chip;Lcom/google/android/material/chip/Chip;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput-object p2, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->B()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez p3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->o()V

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-boolean p2, p0, Lcom/google/android/material/chip/Chip;->j:Z

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0, p2}, Lcom/google/android/material/chip/Chip;->setChecked(Z)V

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/chip/b;->P1()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/chip/b;->I1()Landroid/text/TextUtils$TruncateAt;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->F()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/chip/b;->K3()Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 p1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setLines(I)V

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    const p1, 0x800013

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setGravity(I)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->E()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->z()Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz p1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget p1, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput p1, p0, Lcom/google/android/material/chip/Chip;->o:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void
.end method

.method private A(Lcom/google/android/material/chip/b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/chip/b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b1s  mo~f@t~@~@ @~i/@l@  r~~uoMS~@ ~ @db~ ~@ fb v~~  ~o@ @~~s t~o@.@o~@~~alnyo@i@~-4@~~@@c  /i @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/chip/b;->k3(Lcom/google/android/material/chip/b$a;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method private B()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->m()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->w()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->h:Landroid/view/View$OnClickListener;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, v0}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    iput-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method private C()V
    .locals 4

    sget-boolean v0, Lcom/google/android/material/ripple/b;->a:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->D()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    move v3, v1

    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/b;->J3(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getBackgroundDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->E()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->l()V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method private D()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/google/android/material/chip/b;->N1()Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getBackgroundDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0, v1, v2, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/android/material/chip/Chip;->g:Landroid/graphics/drawable/RippleDrawable;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/b;->J3(Z)V

    const/4 v4, 0x5

    move v5, v4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->g:Landroid/graphics/drawable/RippleDrawable;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p0, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->E()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void
.end method

.method private E()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v0, :cond_2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->p1()F

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/android/material/chip/b;->R1()F

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-float/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/android/material/chip/b;->V0()F

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-float/2addr v0, v1

    const/4 v5, 0x4

    float-to-int v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/chip/b;->u1()F

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/material/chip/b;->S1()F

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-float/2addr v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Lcom/google/android/material/chip/b;->R0()F

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-float/2addr v1, v2

    const/4 v5, 0x6

    float-to-int v1, v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v2, Landroid/graphics/Rect;

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/InsetDrawable;->getPadding(Landroid/graphics/Rect;)Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    iget v3, v2, Landroid/graphics/Rect;->left:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/2addr v1, v3

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v2, v2, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/2addr v0, v2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0, v1, v2, v0, v3}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    :cond_2
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void
.end method

.method private F()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-object v1, v0, Landroid/text/TextPaint;->drawableState:[I

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getTextAppearance()Lcom/google/android/material/resources/d;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/chip/Chip;->v:Lcom/google/android/material/resources/f;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v0, v3}, Lcom/google/android/material/resources/d;->n(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method private G(Landroid/util/AttributeSet;)V
    .locals 6
    .param p1    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v0, "abnmkdcgrs"

    const-string/jumbo v0, "rosnckgbda"

    const/4 v5, 0x6

    const-string v0, "dogboucrna"

    const-string v0, "background"

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "hcse/b:maaan.ipi/dcetpsdhrdsm.aonotmro/k/d"

    const-string v1, "/.emdodn/dadtponr.sakmhco/m/aaeh:/prsisitc"

    const-string v1, "ednamturmdraa/oes/hop:s.//cnpoacsdkdt.iihr"

    const-string/jumbo v1, "http://schemas.android.com/apk/res/android"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p1, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v2, "hpCi"

    const/4 v5, 0x6

    const-string v2, "Chip"

    const-string v2, "Chip"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v0, "p;ctha pusae.oa it nuhrblttaCnsroDogedb nwne a   dowagmdgbenk kos io"

    const-string/jumbo v0, "oho opnsdro biukht adaDwkctitlCuacgw nnbete omad a neos ag ;e srg.bn"

    const/4 v5, 0x5

    const-string v0, "Dwo g odqaoe g t;uidhChdlnatcbkt.mgrs n orbans su rp tanae ekbwcaeio"

    const-string v0, "Do not set the background; Chip manages its own background drawable."

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v0, "rasawlbeLdft"

    const-string v0, "drawableLeft"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {p1, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v0, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v0, "atrmdbSblraae"

    const-string/jumbo v0, "tSdarbraebwal"

    const-string v0, "aabdoSwtreart"

    const-string v0, "drawableStart"

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {p1, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v0, :cond_6

    const/4 v5, 0x5

    const-string v0, "bnedwbEladu"

    const-string/jumbo v0, "ldbaanueEdw"

    const/4 v5, 0x6

    const-string v0, "Edrnaaulewb"

    const-string v0, "drawableEnd"

    const/4 v5, 0x6

    invoke-interface {p1, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v3, "snlea ppuc tIrssealatl  eRo#ncwteda.noeiebsPdg "

    const-string/jumbo v3, "uodl bIpglw# nanlercesttaRr.eesds nti csoePaea "

    const/4 v5, 0x0

    const-string v3, "Please set end drawable using R.attr#closeIcon."

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v0, "aRadwlqhqbter"

    const-string/jumbo v0, "hdwRialtqbare"

    const-string v0, "dbsRthelrwgia"

    const-string v0, "drawableRight"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p1, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v0, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x1

    const-string/jumbo v0, "lsnmnLgsee"

    const-string v0, "Lnsenlsgie"

    const/4 v5, 0x0

    const-string/jumbo v0, "nliLoeneis"

    const-string/jumbo v0, "singleLine"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    move v5, v4

    invoke-interface {p1, v1, v0, v3}, Landroid/util/AttributeSet;->getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, "biesm"

    const-string/jumbo v0, "slime"

    const/4 v5, 0x7

    const-string/jumbo v0, "iueln"

    const-string/jumbo v0, "lines"

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-interface {p1, v1, v0, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-ne v0, v3, :cond_3

    const/4 v5, 0x0

    const-string/jumbo v0, "nsioLenp"

    const-string v0, "Lisnoien"

    const/4 v5, 0x6

    const-string/jumbo v0, "qesiLmin"

    const-string/jumbo v0, "minLines"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {p1, v1, v0, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    if-ne v0, v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v0, "imsbaLex"

    const-string/jumbo v0, "iaexmbnL"

    const/4 v5, 0x6

    const-string/jumbo v0, "maxLines"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {p1, v1, v0, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne v0, v3, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v0, "gtvmrya"

    const-string/jumbo v0, "tyrvgau"

    const/4 v5, 0x0

    const-string v0, "avgyoit"

    const-string/jumbo v0, "gravity"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const v3, 0x800013

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {p1, v1, v0, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eq p1, v3, :cond_2

    const/4 v4, 0x7

    and-int/2addr v5, v4

    const-string p1, "C ngrbt t niaecr sdtllxlspm iteenuidryv h a bttctaeea"

    const-string p1, " rtc u pepaalse tgat eynixtlslnneria ttChdtvcedb mr i"

    const/4 v5, 0x5

    const-string p1, "csv  iurerr gtybitedmneelpiaau st xce l tdtth nCeaanl"

    const-string p1, "Chip text must be vertically center and start aligned"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x7

    const-string v0, " uoseCoptinr ot  thp-epxtemql udinpti"

    const-string/jumbo v0, "io-huluCqeotrdt tpnxtnmo sei tpie lp "

    const/4 v5, 0x3

    const-string v0, " ohtuxetqi delp m-ioirset snno lutpCt"

    const-string v0, "Chip does not support multi-line text"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p1, v3}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw p1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {p1, v3}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p1

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v0, "#Ise nse a dlapwPrgtatusin.esercattlhcR sot.b sa"

    const-string v0, "Rrs sinaawthaaeuo.egacPestlibn etd .st#ptls Ir c"

    const/4 v5, 0x0

    const-string v0, "dwameat..eRcr taaacp hnsbrsP sltslrgtute on iI#i"

    const-string v0, "Please set start drawable using R.attr#chipIcon."

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p1

    :cond_7
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v0, "situoogpP.bsRteledcweraIalnmacfis# trae.t  e lh"

    const-string v0, "alRmch dfbsliat.reP#wagerpn  acstt Ileueo.senti"

    const/4 v5, 0x5

    const-string/jumbo v0, "sl  rbl.nflcieae RIa#awnPahsgteot.tecbe d sirtu"

    const-string v0, "Please set left drawable using R.attr#chipIcon."

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw p1
.end method

.method static synthetic b(Lcom/google/android/material/chip/Chip;)Lcom/google/android/material/chip/b;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/chip/Chip;)Z
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->m()Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    return p0
.end method

.method static synthetic d(Lcom/google/android/material/chip/Chip;)Landroid/graphics/RectF;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBounds()Landroid/graphics/RectF;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic e(Lcom/google/android/material/chip/Chip;)Landroid/view/View$OnClickListener;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/chip/Chip;->h:Landroid/view/View$OnClickListener;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic f(Lcom/google/android/material/chip/Chip;Z)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->m:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic g(Lcom/google/android/material/chip/Chip;)Landroid/graphics/Rect;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBoundsInt()Landroid/graphics/Rect;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method private getCloseIconTouchBounds()Landroid/graphics/RectF;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->u:Landroid/graphics/RectF;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->m()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->h:Landroid/view/View$OnClickListener;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->u:Landroid/graphics/RectF;

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/b;->F1(Landroid/graphics/RectF;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->u:Landroid/graphics/RectF;

    const/4 v3, 0x6

    return-object v0
.end method

.method private getCloseIconTouchBoundsInt()Landroid/graphics/Rect;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBounds()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->t:Landroid/graphics/Rect;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v2, v0, Landroid/graphics/RectF;->left:F

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    float-to-int v2, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v3, v0, Landroid/graphics/RectF;->top:F

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    float-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v4, v0, Landroid/graphics/RectF;->right:F

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    float-to-int v4, v4

    const/4 v6, 0x3

    iget v0, v0, Landroid/graphics/RectF;->bottom:F

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    float-to-int v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3, v4, v0}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->t:Landroid/graphics/Rect;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-object v0
.end method

.method private getTextAppearance()Lcom/google/android/material/resources/d;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->Q1()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    return-object v0
.end method

.method static synthetic h()Landroid/graphics/Rect;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/material/chip/Chip;->A:Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method private i(Lcom/google/android/material/chip/b;)V
    .locals 2
    .param p1    # Lcom/google/android/material/chip/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    invoke-virtual {p1, p0}, Lcom/google/android/material/chip/b;->k3(Lcom/google/android/material/chip/b$a;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private j()[I
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->m:Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->l:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array v0, v0, [I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const v1, 0x101009e

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    aput v1, v0, v2

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x4

    xor-int/2addr v3, v2

    :cond_4
    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->m:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const v1, 0x101009c

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    aput v1, v0, v2

    const/4 v4, 0x6

    add-int/lit8 v2, v2, 0x1

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->l:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const v1, 0x1010367

    const/4 v4, 0x0

    const/4 v3, 0x3

    aput v1, v0, v2

    const/4 v4, 0x3

    add-int/lit8 v2, v2, 0x1

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v3, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const v1, 0x10100a7

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    aput v1, v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/lit8 v2, v2, 0x1

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_8

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const v1, 0x10100a1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput v1, v0, v2

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v0
.end method

.method private l()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getBackgroundDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private m()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->y1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method private n(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->Chip:[I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget v4, Lcom/google/android/material/chip/Chip;->x:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-array v5, v6, [I

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v3, p3

    move v3, p3

    const/4 v8, 0x1

    move v3, p3

    move v3, p3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget p2, Lcom/google/android/material/R$styleable;->Chip_ensureMinTouchTargetSize:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, p2, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-boolean p2, p0, Lcom/google/android/material/chip/Chip;->n:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/16 p3, 0x30

    const/4 v8, 0x4

    invoke-static {p2, p3}, Lcom/google/android/material/internal/y;->e(Landroid/content/Context;I)F

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    float-to-double p2, p2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {p2, p3}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    double-to-float p2, p2

    const/4 v8, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->Chip_chipMinTouchTargetSize:I

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p1, p3, p2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    float-to-double p2, p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {p2, p3}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    double-to-int p2, p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput p2, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    return-void
.end method

.method private o()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/chip/Chip$b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/chip/Chip$b;-><init>(Lcom/google/android/material/chip/Chip;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method private p(IIII)V
    .locals 9

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v6, Landroid/graphics/drawable/InsetDrawable;

    const/4 v7, 0x2

    or-int/2addr v8, v7

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    move v2, p1

    move v2, p1

    move v2, p1

    const/4 v8, 0x5

    move v3, p2

    move v3, p2

    const/4 v8, 0x0

    move v3, p2

    move v3, p2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v4, p3

    move v4, p3

    const/4 v8, 0x4

    move v4, p3

    move v4, p3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    move v5, p4

    move v5, p4

    const/4 v8, 0x2

    move v5, p4

    move v5, p4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v8, 0x0

    iput-object v6, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-void
.end method

.method private setCloseIconHovered(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->l:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->l:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private setCloseIconPressed(Z)V
    .locals 3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private y()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v2, 0x5

    const/4 v0, 0x0

    or-int/2addr v1, v0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMinWidth(I)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getChipMinHeight()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    float-to-int v0, v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->C()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/chip/Chip;->k(I)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->invalidateOutline()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method protected dispatchHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 3
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/customview/widget/a;->k(Landroid/view/MotionEvent;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 p1, 0x4

    const/4 p1, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x2

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroidx/customview/widget/a;->l(Landroid/view/KeyEvent;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroidx/customview/widget/a;->q()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/high16 v1, -0x80000000

    const/4 v2, 0x3

    move v3, v2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1

    :cond_1
    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p1
.end method

.method protected drawableStateChanged()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-super {p0}, Landroidx/appcompat/widget/AppCompatCheckBox;->drawableStateChanged()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->c2()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->j()[I

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/chip/b;->f3([I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->q:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->q:Ljava/lang/CharSequence;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->q()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/google/android/material/chip/ChipGroup;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/material/chip/ChipGroup;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/ChipGroup;->k()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, ".oridnuunoiaRoto.dBieattdw"

    const-string/jumbo v0, "itdoongaBawnourtod.ieidtR."

    const/4 v3, 0x4

    const-string v0, "duood.tpitoiRtiBwea.ndragd"

    const-string v0, "android.widget.RadioButton"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "notiubd.qoptd.gneaiCnduwBomtr"

    const-string/jumbo v0, "rtBgdb.pnuoita.nmoueddoioCwtn"

    const/4 v3, 0x3

    const-string/jumbo v0, "gusnodndedrtmoiBdiCanpuo.tot."

    const-string v0, "android.widget.CompoundButton"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "drdmdnoa.tweitButongi"

    const-string/jumbo v0, "ntBordueaddtn.ioitw.g"

    const/4 v3, 0x1

    const-string/jumbo v0, "otdnodtwunao.iBrei.tg"

    const-string v0, "android.widget.Button"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x4

    const-string v0, "en.ewidprvdaoiiwV"

    const/4 v3, 0x1

    const-string v0, "edaiVbdwniwi..evr"

    const-string v0, "android.view.View"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public getBackgroundDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public getCheckedIcon()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->l1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public getCheckedIconTint()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x2

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->m1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getChipBackgroundColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->n1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public getChipCornerRadius()F
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method

.method public getChipDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getChipEndPadding()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->p1()F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public getChipIcon()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->q1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public getChipIconSize()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->r1()F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public getChipIconTint()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->s1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getChipMinHeight()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->t1()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getChipStartPadding()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->u1()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getChipStrokeColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->v1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public getChipStrokeWidth()F
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->w1()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getChipText()Ljava/lang/CharSequence;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getCloseIcon()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->y1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public getCloseIconContentDescription()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->z1()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public getCloseIconEndPadding()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->A1()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getCloseIconSize()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->B1()F

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getCloseIconStartPadding()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->C1()F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getCloseIconTint()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->E1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public getEllipsize()Landroid/text/TextUtils$TruncateAt;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->I1()Landroid/text/TextUtils$TruncateAt;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method public getFocusedRect(Landroid/graphics/Rect;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/customview/widget/a;->q()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/customview/widget/a;->m()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    if-ne v0, v1, :cond_1

    :cond_0
    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBoundsInt()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->getFocusedRect(Landroid/graphics/Rect;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public getHideMotionSpec()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->J1()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getIconEndPadding()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->K1()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public getIconStartPadding()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->L1()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getRippleColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->N1()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    return-object v0
.end method

.method public getShapeAppearanceModel()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public getShowMotionSpec()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->O1()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTextEndPadding()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->R1()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public getTextStartPadding()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->S1()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public k(I)Z
    .locals 7
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput p1, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->z()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x1

    or-int/2addr v6, v5

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->y()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->C()V

    :goto_0
    const/4 v5, 0x4

    move v6, v5

    return v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->getIntrinsicHeight()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    sub-int v0, p1, v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/google/android/material/chip/b;->getIntrinsicWidth()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    sub-int v2, p1, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-gtz v2, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-gtz v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz p1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->y()V

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->C()V

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    return v1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-lez v2, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    div-int/lit8 v2, v2, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_2

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-lez v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    div-int/lit8 v1, v0, 0x2

    :cond_5
    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v0, :cond_6

    const/4 v5, 0x2

    move v6, v5

    new-instance v0, Landroid/graphics/Rect;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/android/material/chip/Chip;->f:Landroid/graphics/drawable/InsetDrawable;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v4, v0}, Landroid/graphics/drawable/InsetDrawable;->getPadding(Landroid/graphics/Rect;)Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v4, v0, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x5

    if-ne v4, v1, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v4, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ne v4, v1, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v4, v0, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ne v4, v2, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v0, v0, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v0, v2, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->C()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v3

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/widget/TextView;->getMinHeight()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eq v0, p1, :cond_7

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    :cond_7
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/widget/TextView;->getMinWidth()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eq v0, p1, :cond_8

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setMinWidth(I)V

    :cond_8
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, v2, v1, v2, v1}, Lcom/google/android/material/chip/Chip;->p(IIII)V

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->C()V

    const/4 v5, 0x5

    move v6, v5

    return v3
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/widget/CheckBox;->onAttachedToWindow()V

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/google/android/material/shape/k;->f(Landroid/view/View;Lcom/google/android/material/shape/j;)V

    const/4 v2, 0x4

    return-void
.end method

.method protected onCreateDrawableState(I)[I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    add-int/lit8 p1, p1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    sget-object v0, Lcom/google/android/material/chip/Chip;->B:[I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->q()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/material/chip/Chip;->C:[I

    const/4 v2, 0x1

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_1
    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method protected onFocusChanged(ZILandroid/graphics/Rect;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3}, Landroid/widget/CheckBox;->onFocusChanged(ZILandroid/graphics/Rect;)V

    const/4 v1, 0x6

    move v2, v1

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {v0, p1, p2, p3}, Landroidx/customview/widget/a;->B(ZILandroid/graphics/Rect;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public onHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x7

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eq v0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 v1, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/Chip;->setCloseIconHovered(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBounds()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/Chip;->setCloseIconHovered(Z)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p1
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 10
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getAccessibilityClassName()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->q()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    instance-of v0, v0, Lcom/google/android/material/chip/ChipGroup;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eqz v0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    check-cast v0, Lcom/google/android/material/chip/ChipGroup;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1}, Landroidx/core/view/accessibility/l0;->X1(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroidx/core/view/accessibility/l0;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/chip/ChipGroup;->c()Z

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    if-eqz v1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v0, p0}, Lcom/google/android/material/chip/ChipGroup;->i(Landroid/view/View;)I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v1, -0x1

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    move v4, v1

    move v4, v1

    const/4 v9, 0x0

    move v4, v1

    move v4, v1

    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0, p0}, Lcom/google/android/material/internal/FlowLayout;->b(Landroid/view/View;)I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v5, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v6, 0x0

    move v9, v6

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v7

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static/range {v2 .. v7}, Landroidx/core/view/accessibility/l0$c;->h(IIIIZZ)Landroidx/core/view/accessibility/l0$c;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->Z0(Ljava/lang/Object;)V

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    return-void
.end method

.method public onResolvePointerIcon(Landroid/view/MotionEvent;I)Landroid/view/PointerIcon;
    .locals 3
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBounds()Landroid/graphics/RectF;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2, v0, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/16 p2, 0x3ea

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lcom/google/android/material/chip/a;->a(Landroid/content/Context;I)Landroid/view/PointerIcon;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public onRtlPropertiesChanged(I)V
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x11
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onRtlPropertiesChanged(I)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/chip/Chip;->o:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/chip/Chip;->o:I

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->E()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 7
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->getCloseIconTouchBounds()Landroid/graphics/RectF;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eq v0, v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eq v0, v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v1, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eq v0, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_2

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {p0, v3}, Lcom/google/android/material/chip/Chip;->setCloseIconPressed(Z)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->k:Z

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->x()Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    move v0, v3

    move v0, v3

    const/4 v6, 0x3

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p0, v3}, Lcom/google/android/material/chip/Chip;->setCloseIconPressed(Z)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_3

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v1, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0, v2}, Lcom/google/android/material/chip/Chip;->setCloseIconPressed(Z)V

    :cond_4
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_3

    :cond_5
    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    move v0, v3

    move v0, v3

    :goto_3
    const/4 v6, 0x0

    if-nez v0, :cond_7

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p1, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_4

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    move v2, v3

    move v2, v3

    const/4 v6, 0x1

    move v2, v3

    move v2, v3

    :cond_7
    :goto_4
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v2
.end method

.method public q()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->W1()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public r()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->s()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public s()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->Y1()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    return v0
.end method

.method public setAccessibilityClassName(Ljava/lang/CharSequence;)V
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->q:Ljava/lang/CharSequence;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getBackgroundDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->g:Landroid/graphics/drawable/RippleDrawable;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo p1, "pChi"

    const-string/jumbo p1, "pChi"

    const/4 v2, 0x6

    const-string p1, "Chip"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "eet i.us uohra;arudo Cwshngnowd sbnttt knakglm  cnoagp oqcDbaai dbee"

    const-string v0, "  uatrb qeaothrgc khsadiwndpCwniea.slnbcbs t ooa eDaunrgm;tnokeodg  "

    const/4 v2, 0x4

    const-string/jumbo v0, "scdbbkoprnh gn.lhCo aDuaar  ewoaoumi ncetdrn pn agkabigee tt;otd ws "

    const-string v0, "Do not set the background; Chip manages its own background drawable."

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public setBackgroundColor(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo p1, "hpCi"

    const-string/jumbo p1, "iCph"

    const/4 v2, 0x3

    const-string p1, "Cphi"

    const-string p1, "Chip"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const-string v0, "eko  mu.qDgnaohessdsg btooa    rt lnr  npbiluotaadCewccnborniareawo; ksdgc"

    const-string/jumbo v0, "t sitcpu ligg aaswbtnshmrndln ocoobwkneaaoracCrdrhsoub oda .g  Deeone;   k"

    const/4 v2, 0x3

    const-string/jumbo v0, "okswbaranis ablosi sonontcCgbnetang  Dug  tw erm lhcoard cted oud ;ekraoph"

    const-string v0, "Do not set the background color; Chip manages its own background drawable."

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->getBackgroundDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->g:Landroid/graphics/drawable/RippleDrawable;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const-string/jumbo p1, "piCh"

    const/4 v2, 0x4

    const-string/jumbo p1, "iChp"

    const-string p1, "Chip"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const-string/jumbo v0, "wrom htntbma ;bl hou geCars acoakwsnapbtgeg unm.banededs ordae  ni tiodlk wca"

    const-string v0, ".e mwk barbgtoatsed Cndnuodmsa gwlo;ak li bcthbenaewu ae ia g p dononsrtrcahr"

    const/4 v2, 0x0

    const-string v0, "Do not set the background drawable; Chip manages its own background drawable."

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatCheckBox;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo p1, "phiC"

    const-string/jumbo p1, "pCih"

    const/4 v2, 0x1

    const-string/jumbo p1, "hCpi"

    const-string p1, "Chip"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "okroor or sa neawbssahoocgutt ;DCcwbnridln.hesemdtg n ucto ndgka ap  euiraoee"

    const-string/jumbo v0, "osrwo dr tr mon ado  glto;irewnbnctsr g aanccuo eCudhkeaenuDtgs eap.iaskho be"

    const-string/jumbo v0, "iasrbbdtootcukurma o eoetnosinco .wnugne pdc ghCwabk  aerl;essa  banhegrrd  t"

    const-string v0, "Do not set the background resource; Chip manages its own background drawable."

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo p1, "hiCp"

    const-string p1, "Cpih"

    const/4 v2, 0x5

    const-string/jumbo p1, "piCh"

    const-string p1, "Chip"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "bC tanutblioohoaktin bwn  asggs;tp bwr tsmDueraroaincc.o n ded utgskde  tlen h"

    const-string/jumbo v0, "noC;sbeo nog itotkalcaiu.ks  twamd  e chuenbabrndeDtsp t dio batw gaghnr lsnrt"

    const/4 v2, 0x6

    const-string v0, "e Dowtsp aoenashobrones dt li t ui nad inesgrirulakbntnc bt agtC.h apwgtd ;mok"

    const-string v0, "Do not set the background tint list; Chip manages its own background drawable."

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo p1, "pihC"

    const-string p1, "Chip"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "eern wibqdi a odwss;g tagntdagmbnc  nhop co eo leta  tDeokdCn.aubntirukhsmr at"

    const-string v0, "bnc; rulnnad  tgog tddeaapachtgs kCt abiuriu nke o t Dwnos roamesedem.nwhotib "

    const/4 v2, 0x3

    const-string/jumbo v0, "rgsbDrsc  itaaoh d  utiekdkbmwnsunme.o Ctoacatehtigl arbwgn no netoda;e  podn "

    const-string v0, "Do not set the background tint mode; Chip manages its own background drawable."

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setCheckable(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->l2(Z)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public setCheckableResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->m2(I)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public setChecked(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->j:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->W1()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq v0, p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->i:Lcom/google/android/material/internal/h$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/android/material/internal/h$a;->a(Ljava/lang/Object;Z)V

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setCheckedIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->n2(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public setCheckedIconEnabled(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setCheckedIconVisible(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setCheckedIconEnabledResource(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setCheckedIconVisible(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method public setCheckedIconResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->q2(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setCheckedIconTint(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->r2(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setCheckedIconTintResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->s2(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setCheckedIconVisible(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->t2(I)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public setCheckedIconVisible(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->u2(Z)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public setChipBackgroundColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->v2(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public setChipBackgroundColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->w2(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public setChipCornerRadius(F)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->x2(F)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public setChipCornerRadiusResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->y2(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public setChipDrawable(Lcom/google/android/material/chip/b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/chip/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/Chip;->A(Lcom/google/android/material/chip/b;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/chip/b;->v3(Z)V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/Chip;->i(Lcom/google/android/material/chip/b;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget p1, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->k(I)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public setChipEndPadding(F)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->z2(F)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setChipEndPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->A2(I)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setChipIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->B2(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x2

    return-void
.end method

.method public setChipIconEnabled(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setChipIconVisible(Z)V

    const/4 v1, 0x0

    return-void
.end method

.method public setChipIconEnabledResource(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setChipIconVisible(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setChipIconResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->E2(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public setChipIconSize(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->F2(F)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setChipIconSizeResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->G2(I)V

    :cond_0
    const/4 v2, 0x4

    return-void
.end method

.method public setChipIconTint(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->H2(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public setChipIconTintResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->I2(I)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public setChipIconVisible(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->J2(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public setChipIconVisible(Z)V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->K2(Z)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public setChipMinHeight(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->L2(F)V

    :cond_0
    const/4 v1, 0x1

    return-void
.end method

.method public setChipMinHeightResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->M2(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setChipStartPadding(F)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->N2(F)V

    :cond_0
    const/4 v1, 0x0

    move v2, v1

    return-void
.end method

.method public setChipStartPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->O2(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setChipStrokeColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->P2(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setChipStrokeColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->Q2(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setChipStrokeWidth(F)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->R2(F)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public setChipStrokeWidthResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->S2(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public setChipText(Ljava/lang/CharSequence;)V
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setChipTextResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, 0x7

    return-void
.end method

.method public setCloseIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->U2(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->B()V

    return-void
.end method

.method public setCloseIconContentDescription(Ljava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->V2(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setCloseIconEnabled(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setCloseIconVisible(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public setCloseIconEnabledResource(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setCloseIconVisible(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public setCloseIconEndPadding(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->Y2(F)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public setCloseIconEndPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->Z2(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setCloseIconResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->a3(I)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->B()V

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public setCloseIconSize(F)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->b3(F)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setCloseIconSizeResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->c3(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setCloseIconStartPadding(F)V
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->d3(F)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setCloseIconStartPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->e3(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setCloseIconTint(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->g3(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public setCloseIconTintResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->h3(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public setCloseIconVisible(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->setCloseIconVisible(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public setCloseIconVisible(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->j3(Z)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->B()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    if-nez p1, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x3

    if-nez p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const-string p2, "atemstieb rlpeswgdato.nle.cduoRarInPc #el  nase"

    const-string p2, "deeasw p c..issa#arl tI egdnnePRnc tetlebaourol"

    const/4 v1, 0x1

    const-string p2, "Ptngooeaeuestecdln ec  ai#lnseolI.dssatrb R raw"

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    throw p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    const-string p2, "c ssrb n.#atuepr Rt.aasgnislraoti wtb aqchdIPtee"

    const-string/jumbo p2, "eto stI qe.tisPdacth #aasaRninlategrbrrepu .cw s"

    const/4 v1, 0x3

    const-string/jumbo p2, "t i.whuctcullntPrRntaairp  ebtas#eI.ao  essgsera"

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    throw p1
.end method

.method public setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-nez p1, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v0, 0x6

    move v1, v0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    const-string p2, "aawsucnpaP ltt ceie#bsedrsoos.t.rRelne  In leds"

    const-string p2, "a sorrenecaPtosetubdtssd ele#wsane niR la.. Ilc"

    const/4 v1, 0x4

    const-string/jumbo p2, "wte aoalqnlcaaeositr u# res. becg. stddneeIPRns"

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    throw p1

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    const-string p2, "anssraPo bstelt.t.cRmt e ecriunrlgwaid I #psahae"

    const-string p2, "aadmn.sa.tptiI eis#tler w aa nRebgertuchrsPloc s"

    const/4 v1, 0x3

    const-string p2, "bw mdt.oilIRpar# s selP.henraucsraitctn gatteaes"

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    throw p1
.end method

.method public setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 v0, 0x7

    move v1, v0

    if-nez p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    const/4 v0, 0x2

    move v1, v0

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    const-string/jumbo p2, "rdwlolee asIt.aaePos lc.sttudinreebo scon #Rea "

    const-string/jumbo p2, "loc o#nac . l.aItePgai osdtuerle tRadnbrsessewe"

    const/4 v1, 0x3

    const-string/jumbo p2, "snetgbdnwlceeaReb.roP a n cld.Is#tls ioea saret"

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    throw p1

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    const-string/jumbo p2, "sahpe#ursotRbsPrn.u bataclee  tsaIed gwr.taiinc "

    const-string/jumbo p2, "naoagb wdIs nea terta#Ret.repucibat.P tlsrihc ss"

    const/4 v1, 0x5

    const-string p2, "Pegs bap.tesrcRlc  ri#erihwt.e dtlIapsnauastan o"

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    const/4 v1, 0x0

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    throw p1
.end method

.method public setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 v0, 0x4

    or-int/2addr v1, v0

    if-nez p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesRelativeWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void

    :cond_0
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    const-string p2, ".rubwn  qaneaoaaldesiRlecotegltrd .nuseeI stsP#"

    const-string/jumbo p2, "waagc.u sune Raei#secnts.ePl ldbIoer oltrstdane"

    const-string/jumbo p2, "o#slIedw gus.tdoalelbecta. saesrncne  tsPRi arn"

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    throw p1

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    const-string/jumbo p2, "seamch IsaPreicuga #asbRnrdnir p.totttl w. estea"

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    throw p1
.end method

.method public setCompoundDrawablesWithIntrinsicBounds(IIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 v1, 0x6

    if-nez p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    const-string/jumbo p2, "s.acos edsllroestReadcugnt.brteaIaeil p n P#oen"

    const-string/jumbo p2, "snI.aPRplaoceeen cseasb.e ts rra glnldi d#utote"

    const/4 v1, 0x3

    const-string/jumbo p2, "tad. btIuso rnieegs esb.elnadclPn acoe#ate lrws"

    const-string p2, "Please set end drawable using R.attr#closeIcon."

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    throw p1

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string p2, " e rebugtasisstcwqpue t.athrnrtRnoi#d a laas.leI"

    const-string p2, ".esi#eIaqugt wardrto bctns.i  plRtPaalssrtneaeh "

    const/4 v1, 0x5

    const-string p2, "btreiespnRI#criascdtotsw.alrtt laeps haP  ea ngu"

    const-string p2, "Please set start drawable using R.attr#chipIcon."

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    throw p1
.end method

.method public setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    if-nez p1, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    const-string/jumbo p2, "tnoighcwqueadot #las Plbleetna riretgr cssIRea..s"

    const-string p2, "P.sI dr.  iwl gt bgtntser#shauoealreacicleRoasnte"

    const/4 v1, 0x5

    const-string/jumbo p2, "les Ig#sdeltPRbsasticehsr aen.n olwtor gricatua e"

    const-string p2, "Please set right drawable using R.attr#closeIcon."

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    throw p1

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x1

    move v1, v0

    const-string p2, "ebamtR .s lt  tgIelscreurse#ncowpP.tneliidahaf "

    const-string p2, "Please set left drawable using R.attr#chipIcon."

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    throw p1
.end method

.method public setElevation(F)V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setElevation(F)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->n0(F)V

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public setEllipsize(Landroid/text/TextUtils$TruncateAt;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p1, v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->l3(Landroid/text/TextUtils$TruncateAt;)V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :cond_2
    const/4 v2, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string v0, "ei aoh l  ars a tl mtTecilo.cxolnt dorpewhwnt"

    const-string v0, " dome aiptenrwoowlx stial l rTheon.ht l tca c"

    const/4 v2, 0x6

    const-string/jumbo v0, "sw tab rathlnc.  lo octwh xTioliltnraeep  edo"

    const-string v0, "Text within a chip are not allowed to scroll."

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public setEnsureMinTouchTargetSize(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/chip/Chip;->n:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/android/material/chip/Chip;->p:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/Chip;->k(I)Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-void
.end method

.method public setGravity(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const v0, 0x800013

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string p1, "Chip"

    const/4 v2, 0x4

    const-string/jumbo p1, "iphC"

    const-string p1, "Chip"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo v0, "tlbat uvtiesn up agay  dlerxmnCsti   lecahtceenetitrr"

    const-string v0, "Chip text must be vertically center and start aligned"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setGravity(I)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public setHideMotionSpec(Lcom/google/android/material/animation/h;)V
    .locals 3
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->m3(Lcom/google/android/material/animation/h;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setHideMotionSpecResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->n3(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setIconEndPadding(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->o3(F)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setIconEndPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->p3(I)V

    :cond_0
    const/4 v2, 0x1

    return-void
.end method

.method public setIconStartPadding(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->q3(F)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public setIconStartPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->r3(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public setInternalOnCheckedChangeListener(Lcom/google/android/material/internal/h$a;)V
    .locals 2
    .param p1    # Lcom/google/android/material/internal/h$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/internal/h$a<",
            "Lcom/google/android/material/chip/Chip;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->i:Lcom/google/android/material/internal/h$a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public setLayoutDirection(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setLayoutDirection(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public setLines(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-gt p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setLines(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x7

    const-string v0, "-otmlosphleent e n tipCridt  xspuupto"

    const-string v0, "Chip does not support multi-line text"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    throw p1
.end method

.method public setMaxLines(I)V
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-gt p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMaxLines(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "op r  C qutdiuhxtopmttnpns so-eeollti"

    const-string v0, "entlouorieohx temp C sd t is-pputnotl"

    const/4 v2, 0x7

    const-string/jumbo v0, "urst ltsipiet htlos pCe-n poxdiuom nt"

    const-string v0, "Chip does not support multi-line text"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    throw p1
.end method

.method public setMaxWidth(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMaxWidth(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->s3(I)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setMinLines(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-gt p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setMinLines(I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "xisdtbhetstop rluCoepi eti nnlmp  -uo"

    const/4 v2, 0x6

    const-string/jumbo v0, "tpemCnesltitth oppsxotm l roeiu  u-nd"

    const-string v0, "Chip does not support multi-line text"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p1
.end method

.method public setOnCloseIconClickListener(Landroid/view/View$OnClickListener;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/Chip;->h:Landroid/view/View$OnClickListener;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->B()V

    const/4 v1, 0x5

    return-void
.end method

.method public setRippleColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->t3(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/chip/b;->U1()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->D()V

    :cond_1
    const/4 v2, 0x3

    return-void
.end method

.method public setRippleColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->u3(I)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/chip/b;->U1()Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->D()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public setShowMotionSpec(Lcom/google/android/material/animation/h;)V
    .locals 3
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->w3(Lcom/google/android/material/animation/h;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public setShowMotionSpecResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->x3(I)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public setSingleLine(Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setSingleLine(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x5

    const-string v0, "   sox pntuitrtpetlhnpesouo-tliumdeo "

    const-string/jumbo v0, "ptoen utossiei tlopr eh- tlpx mundiut"

    const/4 v2, 0x1

    const-string/jumbo v0, "xt e b orhn-pCepimlpiu otseno uttlsdi"

    const-string v0, "Chip does not support multi-line text"

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    throw p1
.end method

.method public setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x5

    const-string p1, ""

    const-string p1, ""

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->K3()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    and-int/2addr v1, v0

    const/4 v2, 0x7

    goto :goto_0

    :cond_2
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-super {p0, v0, p2}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz p2, :cond_3

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Lcom/google/android/material/chip/b;->y3(Ljava/lang/CharSequence;)V

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setTextAppearance(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setTextAppearance(I)V

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->A3(I)V

    :cond_0
    const/4 v1, 0x0

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->F()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public setTextAppearance(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->setTextAppearance(Landroid/content/Context;I)V

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/material/chip/b;->A3(I)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->F()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public setTextAppearance(Lcom/google/android/material/resources/d;)V
    .locals 3
    .param p1    # Lcom/google/android/material/resources/d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->z3(Lcom/google/android/material/resources/d;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/Chip;->F()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setTextAppearanceResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0, p1}, Lcom/google/android/material/chip/Chip;->setTextAppearance(Landroid/content/Context;I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setTextEndPadding(F)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->D3(F)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setTextEndPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->E3(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setTextStartPadding(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->H3(F)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public setTextStartPaddingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/chip/b;->I3(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public t()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->u()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public u()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->a2()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public v()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/Chip;->w()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public w()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/Chip;->e:Lcom/google/android/material/chip/b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/chip/b;->d2()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    or-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public x()Z
    .locals 5
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->playSoundEffect(I)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->h:Landroid/view/View$OnClickListener;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v1, p0}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    const/4 v4, 0x2

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/chip/Chip;->s:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/Chip;->r:Lcom/google/android/material/chip/Chip$c;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {v1, v2, v2}, Landroidx/customview/widget/a;->N(II)Z

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v0
.end method

.method public z()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/Chip;->n:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method
