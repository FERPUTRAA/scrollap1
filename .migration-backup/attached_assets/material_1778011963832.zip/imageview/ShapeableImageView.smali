.class public Lcom/google/android/material/imageview/ShapeableImageView;
.super Landroidx/appcompat/widget/AppCompatImageView;

# interfaces
.implements Lcom/google/android/material/shape/s;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/imageview/ShapeableImageView$a;
    }
.end annotation


# static fields
.field private static final s:I

.field private static final t:I = -0x80000000


# instance fields
.field private final a:Lcom/google/android/material/shape/p;

.field private final b:Landroid/graphics/RectF;

.field private final c:Landroid/graphics/RectF;

.field private final d:Landroid/graphics/Paint;

.field private final e:Landroid/graphics/Paint;

.field private final f:Landroid/graphics/Path;

.field private g:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private h:Lcom/google/android/material/shape/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Lcom/google/android/material/shape/o;

.field private j:F
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private k:Landroid/graphics/Path;

.field private l:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private m:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private n:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private o:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private p:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private q:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private r:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_ShapeableImageView:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput v0, Lcom/google/android/material/imageview/ShapeableImageView;->s:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    move v2, v1

    move v2, v1

    const/4 v3, 0x4

    invoke-direct {p0, p1, v0, v1}, Lcom/google/android/material/imageview/ShapeableImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x5

    move v3, v2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/imageview/ShapeableImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget v0, Lcom/google/android/material/imageview/ShapeableImageView;->s:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p1, p2, p3, v0}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {}, Lcom/google/android/material/shape/p;->k()Lcom/google/android/material/shape/p;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->a:Lcom/google/android/material/shape/p;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance p1, Landroid/graphics/Path;

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->f:Landroid/graphics/Path;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 p1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->r:Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v2, Landroid/graphics/Paint;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->e:Landroid/graphics/Paint;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v4, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v7, 0x1

    new-instance v4, Landroid/graphics/PorterDuffXfermode;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget-object v5, Landroid/graphics/PorterDuff$Mode;->DST_OUT:Landroid/graphics/PorterDuff$Mode;

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v4, v5}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    const/4 v7, 0x7

    const/4 v6, 0x4

    new-instance v2, Landroid/graphics/RectF;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->b:Landroid/graphics/RectF;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance v2, Landroid/graphics/RectF;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->c:Landroid/graphics/RectF;

    const/4 v7, 0x4

    new-instance v2, Landroid/graphics/Path;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->k:Landroid/graphics/Path;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v2, Lcom/google/android/material/R$styleable;->ShapeableImageView:[I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1, p2, v2, p3, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_strokeColor:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v1, v2, v4}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput-object v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_strokeWidth:I

    const/4 v7, 0x5

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    int-to-float v4, v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPadding:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v7, 0x4

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingLeft:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingTop:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingRight:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingBottom:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2, v4, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingStart:I

    const/4 v7, 0x5

    const/high16 v4, -0x80000000

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, p1, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget p1, Lcom/google/android/material/R$styleable;->ShapeableImageView_contentPaddingEnd:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2, p1, v4}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance p1, Landroid/graphics/Paint;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->d:Landroid/graphics/Paint;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v1, p2, p3, v0}, Lcom/google/android/material/shape/o;->e(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/shape/o$b;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->i:Lcom/google/android/material/shape/o;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance p1, Lcom/google/android/material/imageview/ShapeableImageView$a;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p1, p0}, Lcom/google/android/material/imageview/ShapeableImageView$a;-><init>(Lcom/google/android/material/imageview/ShapeableImageView;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-void
.end method

.method static synthetic b(Lcom/google/android/material/imageview/ShapeableImageView;)Lcom/google/android/material/shape/o;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ms@~   ot@ ~@i1nov 4s~io~~o@ -li@ @/@ ~Mf~b~~  ~@b~~ S@ @~ d@l~.~~ ~a @@~f@b/@oKu y r@~~@c@o@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->i:Lcom/google/android/material/shape/o;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic d(Lcom/google/android/material/imageview/ShapeableImageView;)Lcom/google/android/material/shape/j;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->h:Lcom/google/android/material/shape/j;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic e(Lcom/google/android/material/imageview/ShapeableImageView;Lcom/google/android/material/shape/j;)Lcom/google/android/material/shape/j;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->h:Lcom/google/android/material/shape/j;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic f(Lcom/google/android/material/imageview/ShapeableImageView;)Landroid/graphics/RectF;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->b:Landroid/graphics/RectF;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method private g(Landroid/graphics/Canvas;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->d:Landroid/graphics/Paint;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v2}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    cmpl-float v1, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-lez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->d:Landroid/graphics/Paint;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->f:Landroid/graphics/Path;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->d:Landroid/graphics/Paint;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method private h()Z
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/high16 v1, -0x80000000

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-ne v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0
.end method

.method private i()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getLayoutDirection()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v1
.end method

.method private l(II)V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->b:Landroid/graphics/RectF;

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getPaddingLeft()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    int-to-float v1, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getPaddingTop()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    int-to-float v2, v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getPaddingRight()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    sub-int v3, p1, v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    int-to-float v3, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    sub-int v4, p2, v4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    int-to-float v4, v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->a:Lcom/google/android/material/shape/p;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->i:Lcom/google/android/material/shape/o;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->b:Landroid/graphics/RectF;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/android/material/imageview/ShapeableImageView;->f:Landroid/graphics/Path;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v4, v2, v3}, Lcom/google/android/material/shape/p;->d(Lcom/google/android/material/shape/o;FLandroid/graphics/RectF;Landroid/graphics/Path;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->k:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->rewind()V

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->k:Landroid/graphics/Path;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->f:Landroid/graphics/Path;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->c:Landroid/graphics/RectF;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    int-to-float p1, p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    int-to-float p2, p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v1, p1, p2}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->k:Landroid/graphics/Path;

    const/4 v6, 0x1

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->c:Landroid/graphics/RectF;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    sget-object v0, Landroid/graphics/Path$Direction;->CCW:Landroid/graphics/Path$Direction;

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p1, p2, v0}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-void
.end method


# virtual methods
.method public getContentPaddingBottom()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public final getContentPaddingEnd()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/high16 v1, -0x80000000

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0
.end method

.method public getContentPaddingLeft()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->h()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/high16 v1, -0x80000000

    const/4 v2, 0x0

    and-int/2addr v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0
.end method

.method public getContentPaddingRight()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->h()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/high16 v1, -0x80000000

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_1

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v3, 0x5

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v0
.end method

.method public final getContentPaddingStart()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v3, 0x2

    const/high16 v1, -0x80000000

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0
.end method

.method public getContentPaddingTop()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getPaddingBottom()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingBottom()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0
.end method

.method public getPaddingEnd()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingEnd()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingEnd()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    sub-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return v0
.end method

.method public getPaddingLeft()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingLeft()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0
.end method

.method public getPaddingRight()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingRight()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v0
.end method

.method public getPaddingStart()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingStart()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingStart()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0
.end method

.method public getPaddingTop()I
    .locals 4
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingTop()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method public getShapeAppearanceModel()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->i:Lcom/google/android/material/shape/o;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public getStrokeColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getStrokeWidth()F
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public j(IIII)V
    .locals 7
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/high16 v0, -0x80000000

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->p:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->q:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    sub-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int/2addr v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    sub-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/2addr v1, p2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v3, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    sub-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-int/2addr v2, p3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    sub-int/2addr v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/2addr v3, p4

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    invoke-super {p0, v0, v1, v2, v3}, Landroid/widget/ImageView;->setPadding(IIII)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput p2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput p3, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput p4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-void
.end method

.method public k(IIII)V
    .locals 7
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x11
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingStart()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingStart()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    sub-int/2addr v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int/2addr v0, p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    sub-int/2addr v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/2addr v1, p2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingEnd()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingEnd()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    sub-int/2addr v2, v3

    const/4 v6, 0x6

    add-int/2addr v2, p3

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v6, 0x3

    sub-int/2addr v3, v4

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    add-int/2addr v3, p4

    const/4 v6, 0x3

    invoke-super {p0, v0, v1, v2, v3}, Landroid/widget/ImageView;->setPaddingRelative(IIII)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    move v0, p3

    move v0, p3

    const/4 v6, 0x5

    move v0, p3

    move v0, p3

    const/4 v5, 0x4

    move v6, v5

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v6, 0x3

    move v0, p1

    move v0, p1

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->l:I

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    iput p2, p0, Lcom/google/android/material/imageview/ShapeableImageView;->m:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->i()Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    if-eqz p2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move p1, p3

    move p1, p3

    const/4 v6, 0x3

    move p1, p3

    move p1, p3

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->n:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput p4, p0, Lcom/google/android/material/imageview/ShapeableImageView;->o:I

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void
.end method

.method protected onAttachedToWindow()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-super {p0}, Landroid/widget/ImageView;->onAttachedToWindow()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    move v3, v2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-super {p0}, Landroid/widget/ImageView;->onDetachedFromWindow()V

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroid/widget/ImageView;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->k:Landroid/graphics/Path;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->e:Landroid/graphics/Paint;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/imageview/ShapeableImageView;->g(Landroid/graphics/Canvas;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method protected onMeasure(II)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-super {p0, p1, p2}, Landroid/widget/ImageView;->onMeasure(II)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->r:Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->isLayoutDirectionResolved()Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x5

    move v3, v2

    iput-boolean p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->r:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->isPaddingRelative()Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->h()Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/google/android/material/imageview/ShapeableImageView;->setPadding(IIII)V

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_3
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingStart()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingEnd()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/google/android/material/imageview/ShapeableImageView;->setPaddingRelative(IIII)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->onSizeChanged(IIII)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/imageview/ShapeableImageView;->l(II)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public setPadding(IIII)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingLeft()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    add-int/2addr p1, v0

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingTop()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    add-int/2addr p2, v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingRight()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    add-int/2addr p3, v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingBottom()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    add-int/2addr p4, v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->setPadding(IIII)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public setPaddingRelative(IIII)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingStart()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    add-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingTop()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    add-int/2addr p2, v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingEnd()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    add-int/2addr p3, v0

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0}, Lcom/google/android/material/imageview/ShapeableImageView;->getContentPaddingBottom()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    add-int/2addr p4, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->setPaddingRelative(IIII)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->i:Lcom/google/android/material/shape/o;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->h:Lcom/google/android/material/shape/j;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/imageview/ShapeableImageView;->l(II)V

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/View;->invalidateOutline()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public setStrokeColor(Landroid/content/res/ColorStateList;)V
    .locals 2
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->g:Landroid/content/res/ColorStateList;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setStrokeColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/imageview/ShapeableImageView;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public setStrokeWidth(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    cmpl-float v0, v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/imageview/ShapeableImageView;->j:F

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setStrokeWidthResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    int-to-float p1, p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/imageview/ShapeableImageView;->setStrokeWidth(F)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method
