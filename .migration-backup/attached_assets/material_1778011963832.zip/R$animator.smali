.class public final Lcom/google/android/material/R$animator;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "animator"
.end annotation


# static fields
.field public static final design_appbar_state_list_animator:I = 0x7f020000

.field public static final design_fab_hide_motion_spec:I = 0x7f020001

.field public static final design_fab_show_motion_spec:I = 0x7f020002

.field public static final linear_indeterminate_line1_head_interpolator:I = 0x7f020009

.field public static final linear_indeterminate_line1_tail_interpolator:I = 0x7f02000a

.field public static final linear_indeterminate_line2_head_interpolator:I = 0x7f02000b

.field public static final linear_indeterminate_line2_tail_interpolator:I = 0x7f02000c

.field public static final m3_btn_elevated_btn_state_list_anim:I = 0x7f02000d

.field public static final m3_btn_state_list_anim:I = 0x7f02000e

.field public static final m3_card_elevated_state_list_anim:I = 0x7f02000f

.field public static final m3_card_state_list_anim:I = 0x7f020010

.field public static final m3_chip_state_list_anim:I = 0x7f020011

.field public static final m3_elevated_chip_state_list_anim:I = 0x7f020012

.field public static final mtrl_btn_state_list_anim:I = 0x7f020013

.field public static final mtrl_btn_unelevated_state_list_anim:I = 0x7f020014

.field public static final mtrl_card_state_list_anim:I = 0x7f020015

.field public static final mtrl_chip_state_list_anim:I = 0x7f020016

.field public static final mtrl_extended_fab_change_size_collapse_motion_spec:I = 0x7f020017

.field public static final mtrl_extended_fab_change_size_expand_motion_spec:I = 0x7f020018

.field public static final mtrl_extended_fab_hide_motion_spec:I = 0x7f020019

.field public static final mtrl_extended_fab_show_motion_spec:I = 0x7f02001a

.field public static final mtrl_extended_fab_state_list_animator:I = 0x7f02001b

.field public static final mtrl_fab_hide_motion_spec:I = 0x7f02001c

.field public static final mtrl_fab_show_motion_spec:I = 0x7f02001d

.field public static final mtrl_fab_transformation_sheet_collapse_spec:I = 0x7f02001e

.field public static final mtrl_fab_transformation_sheet_expand_spec:I = 0x7f02001f


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method
