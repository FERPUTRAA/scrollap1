.class public Lcom/google/android/material/checkbox/MaterialCheckBox;
.super Landroidx/appcompat/widget/AppCompatCheckBox;


# static fields
.field private static final h:I

.field private static final i:[[I


# instance fields
.field private e:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Z

.field private g:Z


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_CompoundButton_CheckBox:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    sput v0, Lcom/google/android/material/checkbox/MaterialCheckBox;->h:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-array v0, v0, [[I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const v1, 0x101009e

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const v2, 0x10100a0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    filled-new-array {v1, v2}, [I

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    aput-object v3, v0, v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const v3, -0x10100a0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    filled-new-array {v1, v3}, [I

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    aput-object v1, v0, v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const v1, -0x101009e

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    filled-new-array {v1, v2}, [I

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v4, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x0

    aput-object v2, v0, v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v2, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x6

    filled-new-array {v1, v3}, [I

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-object v1, v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    sput-object v0, Lcom/google/android/material/checkbox/MaterialCheckBox;->i:[[I

    const/4 v5, 0x0

    and-int/2addr v6, v5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/checkbox/MaterialCheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget v0, Lcom/google/android/material/R$attr;->checkboxStyle:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/checkbox/MaterialCheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget v4, Lcom/google/android/material/checkbox/MaterialCheckBox;->h:I

    const/4 v7, 0x3

    move v8, v7

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatCheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget-object v2, Lcom/google/android/material/R$styleable;->MaterialCheckBox:[I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x2

    new-array v5, v6, [I

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    move v3, p3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->MaterialCheckBox_buttonTint:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v7, 0x6

    invoke-static {p1, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget p1, Lcom/google/android/material/R$styleable;->MaterialCheckBox_useMaterialThemeColors:I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p2, p1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->f:Z

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget p1, Lcom/google/android/material/R$styleable;->MaterialCheckBox_centerIfNoTextEnabled:I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 p3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->g:Z

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-void
.end method

.method private getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@ s@~@ @a~f  M@l~@li~o /o@u~ @ts@~1 @@~~ ty or@vo@~~~~~~b~m  f /@bo @  i@@@K-S ~~.~in do@4@b~~c~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->e:Landroid/content/res/ColorStateList;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget-object v0, Lcom/google/android/material/checkbox/MaterialCheckBox;->i:[[I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    array-length v1, v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-array v1, v1, [I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    sget v2, Lcom/google/android/material/R$attr;->colorControlActivated:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-static {p0, v2}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    sget v3, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p0, v3}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    sget v4, Lcom/google/android/material/R$attr;->colorOnSurface:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p0, v4}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-static {v3, v2, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    aput v2, v1, v5

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const v2, 0x3f0a3d71    # 0.54f

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v3, v4, v2}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v5, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x2

    aput v2, v1, v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v2, 0x2

    const/4 v7, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    const v5, 0x3ec28f5c    # 0.38f

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v3, v4, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    aput v6, v1, v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v2, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x0

    invoke-static {v3, v4, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    aput v3, v1, v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v2, Landroid/content/res/ColorStateList;

    const/4 v8, 0x3

    const/4 v7, 0x0

    invoke-direct {v2, v0, v1}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput-object v2, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->e:Landroid/content/res/ColorStateList;

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->e:Landroid/content/res/ColorStateList;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-object v0
.end method


# virtual methods
.method public b()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->g:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->f:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/widget/CheckBox;->onAttachedToWindow()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->f:Z

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Landroidx/core/widget/d;->b(Landroid/widget/CompoundButton;)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/checkbox/MaterialCheckBox;->setUseMaterialThemeColors(Z)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->g:Z

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p0}, Landroidx/core/widget/d;->a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v1, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    move v6, v5

    const/4 v1, 0x5

    const/4 v1, 0x1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    sub-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    div-int/lit8 v2, v2, 0x2

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    mul-int/2addr v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    int-to-float v3, v2

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v3, p1, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    iget v4, p1, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x2

    add-int/2addr v4, v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v5, 0x7

    and-int/2addr v6, v5

    invoke-static {v0, v1, v3, v4, p1}, Landroidx/core/graphics/drawable/d;->l(Landroid/graphics/drawable/Drawable;IIII)V

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void
.end method

.method public setCenterIfNoTextEnabled(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->g:Z

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setUseMaterialThemeColors(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/checkbox/MaterialCheckBox;->f:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/checkbox/MaterialCheckBox;->getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
