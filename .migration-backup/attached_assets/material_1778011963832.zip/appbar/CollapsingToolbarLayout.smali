.class public Lcom/google/android/material/appbar/CollapsingToolbarLayout;
.super Landroid/widget/FrameLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;,
        Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;,
        Lcom/google/android/material/appbar/CollapsingToolbarLayout$e;
    }
.end annotation


# static fields
.field private static final D:I

.field private static final E:I = 0x258

.field public static final F:I = 0x0

.field public static final G:I = 0x1


# instance fields
.field private A:Z

.field private B:I

.field private C:Z

.field private a:Z

.field private b:I

.field private c:Landroid/view/ViewGroup;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Landroid/view/View;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Landroid/view/View;

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private final j:Landroid/graphics/Rect;

.field final k:Lcom/google/android/material/internal/b;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field final l:Ls4/a;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private m:Z

.field private n:Z

.field private o:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field p:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private q:I

.field private r:Z

.field private s:Landroid/animation/ValueAnimator;

.field private t:J

.field private u:I

.field private v:Lcom/google/android/material/appbar/AppBarLayout$h;

.field w:I

.field private x:I

.field y:Landroidx/core/view/y2;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private z:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    sget v0, Lcom/google/android/material/R$style;->Widget_Design_CollapsingToolbar:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    sput v0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->D:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x0

    const/4 v2, 0x2

    move v1, v0

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$attr;->collapsingToolbarLayoutStyle:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 12
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v11, 0x4

    sget v4, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->D:I

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 p1, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->a:Z

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v0, Landroid/graphics/Rect;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x4

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j:Landroid/graphics/Rect;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v6, -0x1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    iput v6, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u:I

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v7, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    iput v7, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z:I

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    iput v7, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B:I

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v9, Lcom/google/android/material/internal/b;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v9, p0}, Lcom/google/android/material/internal/b;-><init>(Landroid/view/View;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    iput-object v9, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget-object v0, Lcom/google/android/material/animation/a;->e:Landroid/animation/TimeInterpolator;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v9, v0}, Lcom/google/android/material/internal/b;->L0(Landroid/animation/TimeInterpolator;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v9, v7}, Lcom/google/android/material/internal/b;->I0(Z)V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v0, Ls4/a;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {v0, v8}, Ls4/a;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->l:Ls4/a;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout:[I

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-array v5, v7, [I

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    move v3, p3

    move v3, p3

    const/4 v11, 0x7

    move v3, p3

    move v3, p3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleGravity:I

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    const v0, 0x800053

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->v0(I)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_collapsedTitleGravity:I

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    const v0, 0x800013

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p3

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->k0(I)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleMargin:I

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    const/4 v11, 0x0

    const/4 v10, 0x6

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    const/4 v11, 0x2

    const/4 v10, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginStart:I

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-eqz v0, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    :cond_0
    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginEnd:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x5

    if-eqz v0, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginTop:I

    const/4 v10, 0x0

    and-int/2addr v11, v10

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v0, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleMarginBottom:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz v0, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    :cond_3
    const/4 v10, 0x1

    move v11, v10

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_titleEnabled:I

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    iput-boolean p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_title:I

    const/4 v11, 0x5

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object p3

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setTitle(Ljava/lang/CharSequence;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget p3, Lcom/google/android/material/R$style;->TextAppearance_Design_CollapsingToolbar_Expanded:I

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->s0(I)V

    const/4 v11, 0x6

    sget p3, Landroidx/appcompat/R$style;->TextAppearance_AppCompat_Widget_ActionBar_Title:I

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->h0(I)V

    const/4 v11, 0x7

    const/4 v10, 0x3

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleTextAppearance:I

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    if-eqz v0, :cond_4

    const/4 v10, 0x1

    move v11, v10

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->s0(I)V

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_collapsedTitleTextAppearance:I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    if-eqz v0, :cond_5

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->h0(I)V

    :cond_5
    const/4 v10, 0x1

    move v11, v10

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_expandedTitleTextColor:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eqz v0, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {v8, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->u0(Landroid/content/res/ColorStateList;)V

    :cond_6
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_collapsedTitleTextColor:I

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eqz v0, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x3

    invoke-static {v8, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v9, p3}, Lcom/google/android/material/internal/b;->j0(Landroid/content/res/ColorStateList;)V

    :cond_7
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_scrimVisibleHeightTrigger:I

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u:I

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_maxLines:I

    const/4 v10, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-eqz v0, :cond_8

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x3

    invoke-virtual {v9, p1}, Lcom/google/android/material/internal/b;->G0(I)V

    :cond_8
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_titlePositionInterpolator:I

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-eqz p3, :cond_9

    const/4 v10, 0x0

    const/4 v10, 0x7

    invoke-virtual {p2, p1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v8, p1}, Landroid/view/animation/AnimationUtils;->loadInterpolator(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v9, p1}, Lcom/google/android/material/internal/b;->H0(Landroid/animation/TimeInterpolator;)V

    :cond_9
    const/4 v11, 0x6

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_scrimAnimationDuration:I

    const/4 v11, 0x6

    const/16 p3, 0x258

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    int-to-long v0, p1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    iput-wide v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->t:J

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_contentScrim:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setContentScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_statusBarScrim:I

    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setStatusBarScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_titleCollapseMode:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p2, p1, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setTitleCollapseMode(I)V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_toolbarId:I

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p2, p1, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->b:I

    const/4 v10, 0x1

    move v11, v10

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_forceApplySystemWindowInsetTop:I

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p2, p1, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A:Z

    const/4 v11, 0x4

    const/4 v10, 0x7

    sget p1, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_extraMultilineHeightEnabled:I

    const/4 v11, 0x0

    const/4 v10, 0x6

    invoke-virtual {p2, p1, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->C:Z

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0, v7}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v11, 0x7

    new-instance p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout$a;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {p1, p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$a;-><init>(Lcom/google/android/material/appbar/CollapsingToolbarLayout;)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {p0, p1}, Landroidx/core/view/k1;->a2(Landroid/view/View;Landroidx/core/view/z0;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    return-void
.end method

.method private A(IIIIZ)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ls~~/~ o@dob@M@o  @ ~c 1~y@ a~n~~~/ @m@ isufo~@@orf @S@~  ~4~@b- ~~@@ @t i  .~@l@@~@@ov~bi ~t~K"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0}, Landroidx/core/view/k1;->O0(Landroid/view/View;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    move v6, v5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n:Z

    const/4 v6, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p5, :cond_5

    :cond_1
    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-ne v0, v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u(Z)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    :goto_1
    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j:Landroid/graphics/Rect;

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget v3, v3, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v4, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int/2addr v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    sub-int/2addr p3, p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_2

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    sub-int/2addr p3, p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    sub-int/2addr p4, p2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    sub-int/2addr p4, p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, v2, v3, p3, p4}, Lcom/google/android/material/internal/b;->p0(IIII)V

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, p5}, Lcom/google/android/material/internal/b;->d0(Z)V

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method

.method private B()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->P()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i(Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setTitle(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v2, 0x7

    return-void
.end method

.method private a(I)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x1

    or-int/2addr v4, v3

    new-instance v0, Landroid/animation/ValueAnimator;

    invoke-direct {v0}, Landroid/animation/ValueAnimator;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-le p1, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v1, Lcom/google/android/material/animation/a;->c:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v1, Lcom/google/android/material/animation/a;->d:Landroid/animation/TimeInterpolator;

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/appbar/CollapsingToolbarLayout$b;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$b;-><init>(Lcom/google/android/material/appbar/CollapsingToolbarLayout;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_2
    :goto_1
    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->t:J

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    filled-new-array {v1, p1}, [I

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/animation/ValueAnimator;->setIntValues([I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->s:Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method private b(Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;->setLiftOnScroll(Z)V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method private c()V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->a:Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x0

    move v7, v0

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d:Landroid/view/View;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->b:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v2, -0x1

    const/4 v6, 0x5

    or-int/2addr v7, v6

    if-eq v1, v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    check-cast v1, Landroid/view/ViewGroup;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    if-eqz v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p0, v1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d(Landroid/view/View;)Landroid/view/View;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d:Landroid/view/View;

    :cond_1
    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-nez v1, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v3, v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v4}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p(Landroid/view/View;)Z

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v5, :cond_2

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v6, 0x6

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    :cond_4
    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y()V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-boolean v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->a:Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-void
.end method

.method private d(Landroid/view/View;)Landroid/view/View;
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, v0, Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast p1, Landroid/view/View;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    return-object p1
.end method

.method private static g(Landroid/view/View;)I
    .locals 4
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    instance-of v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr p0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/2addr p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return p0
.end method

.method private static i(Landroid/view/View;)Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    instance-of v0, p0, Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p0, Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    instance-of v0, p0, Landroid/widget/Toolbar;

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Landroid/widget/Toolbar;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/widget/Toolbar;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method static j(Landroid/view/View;)Lcom/google/android/material/appbar/i;
    .locals 4
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v0, Lcom/google/android/material/R$id;->view_offset_helper:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v1, Lcom/google/android/material/appbar/i;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x4

    new-instance v1, Lcom/google/android/material/appbar/i;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/google/android/material/appbar/i;-><init>(Landroid/view/View;)V

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object v1
.end method

.method private n()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->x:I

    const/4 v3, 0x0

    const/4 v1, 0x1

    move v2, v1

    move v2, v1

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1
.end method

.method private static p(Landroid/view/View;)Z
    .locals 3

    instance-of v0, p0, Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    instance-of p0, p0, Landroid/widget/Toolbar;

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x1

    move v1, p0

    move v1, p0

    :goto_1
    const/4 v2, 0x4

    return p0
.end method

.method private q(Landroid/view/View;)Z
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    move v4, v3

    if-ne v0, p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    if-ne p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne p1, v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x6

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v1
.end method

.method private u(Z)V
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d:Landroid/view/View;

    const/4 v10, 0x1

    if-eqz v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h(Landroid/view/View;)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j:Landroid/graphics/Rect;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {p0, v1, v2}, Lcom/google/android/material/internal/d;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    instance-of v2, v1, Landroidx/appcompat/widget/Toolbar;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz v2, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    check-cast v1, Landroidx/appcompat/widget/Toolbar;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->getTitleMarginStart()I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->getTitleMarginEnd()I

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->getTitleMarginTop()I

    move-result v4

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v1}, Landroidx/appcompat/widget/Toolbar;->getTitleMarginBottom()I

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_1

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/16 v3, 0x18

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-lt v2, v3, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    instance-of v2, v1, Landroid/widget/Toolbar;

    const/4 v10, 0x2

    const/4 v9, 0x4

    if-eqz v2, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x0

    check-cast v1, Landroid/widget/Toolbar;

    const/4 v10, 0x3

    invoke-static {v1}, Lcom/google/android/material/appbar/b;->a(Landroid/widget/Toolbar;)I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/google/android/material/appbar/c;->a(Landroid/widget/Toolbar;)I

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v1}, Lcom/google/android/material/appbar/d;->a(Landroid/widget/Toolbar;)I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v1}, Lcom/google/android/material/appbar/e;->a(Landroid/widget/Toolbar;)I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    const/4 v10, 0x5

    move v3, v1

    move v3, v1

    const/4 v10, 0x6

    move v3, v1

    move v3, v1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    move v4, v3

    move v4, v3

    const/4 v10, 0x7

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v5, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v6, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j:Landroid/graphics/Rect;

    const/4 v9, 0x7

    move v10, v9

    iget v7, v6, Landroid/graphics/Rect;->left:I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz p1, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    move v8, v3

    move v8, v3

    const/4 v10, 0x7

    move v8, v3

    move v8, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_2

    :cond_3
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    move v8, v2

    move v8, v2

    const/4 v10, 0x7

    move v8, v2

    move v8, v2

    :goto_2
    const/4 v10, 0x0

    add-int/2addr v7, v8

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget v8, v6, Landroid/graphics/Rect;->top:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    add-int/2addr v8, v0

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/2addr v8, v4

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget v4, v6, Landroid/graphics/Rect;->right:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz p1, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto :goto_3

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x2

    move v2, v3

    move v2, v3

    const/4 v10, 0x2

    move v2, v3

    move v2, v3

    :goto_3
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    sub-int/2addr v4, v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget p1, v6, Landroid/graphics/Rect;->bottom:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    add-int/2addr p1, v0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    sub-int/2addr p1, v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v5, v7, v8, v4, p1}, Lcom/google/android/material/internal/b;->f0(IIII)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-void
.end method

.method private v()V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private w(Landroid/graphics/drawable/Drawable;II)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0, p2, p3}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->x(Landroid/graphics/drawable/Drawable;Landroid/view/View;II)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private x(Landroid/graphics/drawable/Drawable;Landroid/view/View;II)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result p4

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 p2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1, p2, p2, p3, p4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method private y()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    instance-of v1, v0, Landroid/view/ViewGroup;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v3, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Landroid/view/View;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v2, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;II)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    instance-of p1, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v1, 0x1

    const/4 v0, 0x3

    return p1
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x7

    const/4 v6, 0x3

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->draw(Landroid/graphics/Canvas;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c()V

    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x7

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v6, 0x0

    or-int/2addr v7, v6

    if-lez v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_0
    const/4 v6, 0x4

    move v7, v6

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n:Z

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    move v7, v6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x4

    or-int/2addr v7, v6

    if-eqz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-lez v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->G()F

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/internal/b;->H()F

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    cmpg-float v0, v0, v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-gez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v2, Landroid/graphics/Region$Op;->DIFFERENCE:Landroid/graphics/Region$Op;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;Landroid/graphics/Region$Op;)Z

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1, p1}, Lcom/google/android/material/internal/b;->l(Landroid/graphics/Canvas;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->l(Landroid/graphics/Canvas;)V

    :cond_2
    :goto_0
    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-lez v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v0, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroidx/core/view/y2;->r()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    move v0, v1

    const/4 v7, 0x1

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lez v0, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget v3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    neg-int v3, v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v5, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w:I

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    sub-int/2addr v0, v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, v1, v3, v4, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v6, 0x4

    move v7, v6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-void
.end method

.method protected drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-lez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0, p2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q(Landroid/view/View;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {p0, v0, p2, v3, v4}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->x(Landroid/graphics/drawable/Drawable;Landroid/view/View;II)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez p1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    move v6, v5

    move v1, v2

    move v1, v2

    const/4 v6, 0x3

    move v1, v2

    move v1, v2

    :cond_2
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    return v1
.end method

.method protected drawableStateChanged()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-super {p0}, Landroid/widget/FrameLayout;->drawableStateChanged()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    or-int/2addr v2, v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    or-int/2addr v2, v1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Lcom/google/android/material/internal/b;->J0([I)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    or-int/2addr v2, v0

    :cond_2
    const/4 v4, 0x4

    move v5, v4

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void
.end method

.method protected e()Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1, v1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;-><init>(II)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method protected f(Landroid/view/ViewGroup$LayoutParams;)Landroid/widget/FrameLayout$LayoutParams;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e()Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/widget/FrameLayout$LayoutParams;
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->e()Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->generateLayoutParams(Landroid/util/AttributeSet;)Landroid/widget/FrameLayout$LayoutParams;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-object p1
.end method

.method protected bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f(Landroid/view/ViewGroup$LayoutParams;)Landroid/widget/FrameLayout$LayoutParams;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public generateLayoutParams(Landroid/util/AttributeSet;)Landroid/widget/FrameLayout$LayoutParams;
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    new-instance v0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method public getCollapsedTitleGravity()I
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->q()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public getCollapsedTitleTypeface()Landroid/graphics/Typeface;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->v()Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getContentScrim()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getExpandedTitleGravity()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->C()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public getExpandedTitleMarginBottom()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getExpandedTitleMarginEnd()I
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public getExpandedTitleMarginStart()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getExpandedTitleMarginTop()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getExpandedTitleTypeface()Landroid/graphics/Typeface;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->F()Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getHyphenationFrequency()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->I()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public getLineCount()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->J()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getLineSpacingAdd()F
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->K()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public getLineSpacingMultiplier()F
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->L()F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public getMaxLines()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->M()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method getScrimAlpha()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    return v0
.end method

.method public getScrimAnimationDuration()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->t:J

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getScrimVisibleHeightTrigger()I
    .locals 4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroidx/core/view/y2;->r()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-lez v1, :cond_2

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    div-int/lit8 v0, v0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0
.end method

.method public getStatusBarScrim()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->P()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x1

    return-object v0
.end method

.method public getTitleCollapseMode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->x:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public getTitlePositionInterpolator()Landroid/animation/TimeInterpolator;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->O()Landroid/animation/TimeInterpolator;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method final h(Landroid/view/View;)I
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j(Landroid/view/View;)Lcom/google/android/material/appbar/i;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast v1, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/appbar/i;->c()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    sub-int/2addr v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sub-int/2addr v2, p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget p1, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sub-int/2addr v2, p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    return v2
.end method

.method public k()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->C:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public l()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public m()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/internal/b;->V()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    return v0
.end method

.method public o()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->b(Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0, v1}, Landroidx/core/view/k1;->O1(Landroid/view/View;Z)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v:Lcom/google/android/material/appbar/AppBarLayout$h;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v1, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;-><init>(Lcom/google/android/material/appbar/CollapsingToolbarLayout;)V

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v:Lcom/google/android/material/appbar/AppBarLayout$h;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v:Lcom/google/android/material/appbar/AppBarLayout$h;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/appbar/AppBarLayout;->e(Lcom/google/android/material/appbar/AppBarLayout$h;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/view/k1;->v1(Landroid/view/View;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 3
    .param p1    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->Z(Landroid/content/res/Configuration;)V

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v:Lcom/google/android/material/appbar/AppBarLayout$h;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    instance-of v2, v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/appbar/AppBarLayout;->v(Lcom/google/android/material/appbar/AppBarLayout$h;)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    const/4 v3, 0x2

    move v4, v3

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 10

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-super/range {p0 .. p5}, Landroid/widget/FrameLayout;->onLayout(ZIIII)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v0, 0x0

    move v9, v0

    const/4 v8, 0x5

    const/4 v8, 0x1

    if-eqz p1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroidx/core/view/y2;->r()I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    move v2, v0

    move v2, v0

    const/4 v9, 0x0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-ge v2, v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v3}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-nez v4, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-ge v4, p1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v3, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    move v1, v0

    move v1, v0

    const/4 v9, 0x0

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-ge v1, p1, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j(Landroid/view/View;)Lcom/google/android/material/appbar/i;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2}, Lcom/google/android/material/appbar/i;->h()V

    const/4 v9, 0x0

    const/4 v8, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    move v3, p2

    move v3, p2

    const/4 v9, 0x7

    move v3, p2

    move v3, p2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    move v4, p3

    move v4, p3

    const/4 v9, 0x3

    move v4, p3

    move v4, p3

    const/4 v8, 0x2

    shl-int/2addr v9, v8

    move v5, p4

    move v5, p4

    const/4 v9, 0x6

    move v5, p4

    move v5, p4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    move v6, p5

    move v6, p5

    const/4 v9, 0x7

    move v6, p5

    move v6, p5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct/range {v2 .. v7}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A(IIIIZ)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B()V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z()V

    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ge v0, p1, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j(Landroid/view/View;)Lcom/google/android/material/appbar/i;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/appbar/i;->a()V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_2

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-void
.end method

.method protected onMeasure(II)V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c()V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v8, 0x4

    shl-int/2addr v9, v8

    if-eqz v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v0}, Landroidx/core/view/y2;->r()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz p2, :cond_1

    const/4 v8, 0x6

    move v9, v8

    iget-boolean p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A:Z

    const/4 v9, 0x2

    if-eqz p2, :cond_2

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    if-lez v0, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iput v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v9, 0x4

    add-int/2addr p2, v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-boolean p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->C:Z

    const/4 v9, 0x3

    if-eqz p2, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/internal/b;->M()I

    move-result p2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v0, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-le p2, v0, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B()V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v7, 0x1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-direct/range {v2 .. v7}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A(IIIIZ)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/internal/b;->z()I

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-le p2, v0, :cond_3

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v2}, Lcom/google/android/material/internal/b;->B()F

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    const/4 v9, 0x0

    const/4 v8, 0x5

    sub-int/2addr p2, v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    mul-int/2addr v2, p2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    iput v2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->B:I

    const/4 v8, 0x0

    add-int/2addr p2, v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz p1, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->d:Landroid/view/View;

    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eqz p2, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-ne p2, p0, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {p2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g(Landroid/view/View;)I

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setMinimumHeight(I)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_2

    :cond_5
    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g(Landroid/view/View;)I

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p0, p1}, Landroid/view/View;->setMinimumHeight(I)V

    :cond_6
    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->onSizeChanged(IIII)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x2

    const/4 v0, 0x5

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p3, p1, p2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w(Landroid/graphics/drawable/Drawable;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method r(Landroidx/core/view/y2;)Landroidx/core/view/y2;
    .locals 4
    .param p1    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1, v0}, Landroidx/core/util/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    invoke-virtual {p1}, Landroidx/core/view/y2;->c()Landroidx/core/view/y2;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public s(IIII)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    const/4 v0, 0x0

    move v1, v0

    iput p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    const/4 v1, 0x2

    iput p3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p4, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    return-void
.end method

.method public setCollapsedTitleGravity(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->k0(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setCollapsedTitleTextAppearance(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->h0(I)V

    return-void
.end method

.method public setCollapsedTitleTextColor(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setCollapsedTitleTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public setCollapsedTitleTextColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->j0(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public setCollapsedTitleTypeface(Landroid/graphics/Typeface;)V
    .locals 3
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->m0(Landroid/graphics/Typeface;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public setContentScrim(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, p1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0, v1, p1, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w(Landroid/graphics/drawable/Drawable;II)V

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public setContentScrimColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setContentScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setContentScrimResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0, p1}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setContentScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setExpandedTitleColor(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setExpandedTitleTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setExpandedTitleGravity(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->v0(I)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setExpandedTitleMarginBottom(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->i:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public setExpandedTitleMarginEnd(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public setExpandedTitleMarginStart(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->f:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public setExpandedTitleMarginTop(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->g:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setExpandedTitleTextAppearance(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->s0(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setExpandedTitleTextColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->u0(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setExpandedTitleTypeface(Landroid/graphics/Typeface;)V
    .locals 3
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->x0(Landroid/graphics/Typeface;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public setExtraMultilineHeightEnabled(Z)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->C:Z

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public setForceApplySystemWindowInsetTop(Z)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->A:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public setHyphenationFrequency(I)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->C0(I)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public setLineSpacingAdd(F)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->E0(F)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public setLineSpacingMultiplier(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->F0(F)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public setMaxLines(I)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->G0(I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public setRtlTextDirectionHeuristicsEnabled(Z)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->I0(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method setScrimAlpha(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p1, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public setScrimAnimationDuration(J)V
    .locals 2
    .param p1    # J
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->t:J

    const/4 v1, 0x6

    return-void
.end method

.method public setScrimVisibleHeightTrigger(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->u:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public setScrimsShown(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->t(ZZ)V

    const/4 v2, 0x1

    return-void
.end method

.method public setStatusBarScrim(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    if-eq v0, p1, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_2
    const/4 v2, 0x6

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    move v0, v1

    move v0, v1

    const/4 v3, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->q:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_4
    const/4 v3, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public setStatusBarScrimColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setStatusBarScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setStatusBarScrimResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p1}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setStatusBarScrim(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->K0(Ljava/lang/CharSequence;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setTitleCollapseMode(I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->x:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->n()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->A0(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    instance-of v1, v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->b(Lcom/google/android/material/appbar/AppBarLayout;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget v0, Lcom/google/android/material/R$dimen;->design_appbar_elevation:I

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->l:Ls4/a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ls4/a;->g(F)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setContentScrimColor(I)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public setTitleEnabled(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->m:Z

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->v()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setTitlePositionInterpolator(Landroid/animation/TimeInterpolator;)V
    .locals 3
    .param p1    # Landroid/animation/TimeInterpolator;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->H0(Landroid/animation/TimeInterpolator;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public setVisibility(I)V
    .locals 4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setVisibility(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    move p1, v0

    move p1, v0

    const/4 v3, 0x0

    move p1, v0

    move p1, v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eq v1, p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1, p1, v0}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eq v1, p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1, p1, v0}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public t(ZZ)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->r:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq v0, p1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v0, 0xff

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    move v0, v1

    move v0, v1

    const/4 v3, 0x5

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->a(I)V

    const/4 v3, 0x4

    goto :goto_2

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    move v0, v1

    move v0, v1

    const/4 v3, 0x3

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setScrimAlpha(I)V

    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->r:Z

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method protected verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x5

    const/4 p1, 0x2

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x4

    move v2, v1

    const/4 p1, 0x1

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method final z()V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w:I

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr v0, v1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->getScrimVisibleHeightTrigger()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ge v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->setScrimsShown(Z)V

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method
