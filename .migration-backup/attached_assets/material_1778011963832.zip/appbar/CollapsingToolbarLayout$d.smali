.class Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/appbar/AppBarLayout$h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/CollapsingToolbarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;


# direct methods
.method constructor <init>(Lcom/google/android/material/appbar/CollapsingToolbarLayout;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/appbar/AppBarLayout;I)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "l~socb ~t sb Kio dS~~-@@n@@ t@ oo~ @v@/i ~~~~41~~@.~~~ @o@@@  ~@~@/mba~@u i M~lf@o~f@~~ @y@@   ~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput p2, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w:I

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object p1, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->y:Landroidx/core/view/y2;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v0, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz p1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p1}, Landroidx/core/view/y2;->r()I

    move-result p1

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    move p1, v0

    move p1, v0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v9, 0x2

    if-ge v2, v1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    check-cast v4, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v3}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->j(Landroid/view/View;)Lcom/google/android/material/appbar/i;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x7

    iget v6, v4, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v7, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eq v6, v7, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/4 v3, 0x2

    const/4 v9, 0x2

    if-eq v6, v3, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto :goto_2

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    neg-int v3, p2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    int-to-float v3, v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget v4, v4, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    mul-float/2addr v3, v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v5, v3}, Lcom/google/android/material/appbar/i;->k(I)Z

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_2

    :cond_2
    const/4 v8, 0x5

    const/4 v9, 0x6

    neg-int v4, p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v6, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v6, v3}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->h(Landroid/view/View;)I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v4, v0, v3}, Lo/a;->e(III)I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v5, v3}, Lcom/google/android/material/appbar/i;->k(I)Z

    :goto_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->z()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v1, v0, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->p:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    if-eqz v1, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-lez p1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v1}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    sub-int v1, v0, v1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    sub-int/2addr v1, p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->getScrimVisibleHeightTrigger()I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    sub-int/2addr v0, p1

    const/4 v8, 0x3

    move v9, v8

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x5

    const/4 v8, 0x3

    iget-object p1, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x7

    const/4 v8, 0x6

    int-to-float v0, v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    int-to-float v2, v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    div-float/2addr v0, v2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v3, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/internal/b;->B0(F)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v0, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget p1, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->w:I

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    add-int/2addr p1, v1

    const/4 v9, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->o0(I)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$d;->a:Lcom/google/android/material/appbar/CollapsingToolbarLayout;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object p1, p1, Lcom/google/android/material/appbar/CollapsingToolbarLayout;->k:Lcom/google/android/material/internal/b;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    int-to-float p2, p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    div-float/2addr p2, v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1, p2}, Lcom/google/android/material/internal/b;->z0(F)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void
.end method
