.class public Lcom/google/android/material/appbar/AppBarLayout;
.super Landroid/widget/LinearLayout;

# interfaces
.implements Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/appbar/AppBarLayout$e;,
        Lcom/google/android/material/appbar/AppBarLayout$d;,
        Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;,
        Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;,
        Lcom/google/android/material/appbar/AppBarLayout$Behavior;,
        Lcom/google/android/material/appbar/AppBarLayout$f;,
        Lcom/google/android/material/appbar/AppBarLayout$g;,
        Lcom/google/android/material/appbar/AppBarLayout$h;,
        Lcom/google/android/material/appbar/AppBarLayout$c;
    }
.end annotation


# static fields
.field static final t:I = 0x0

.field static final u:I = 0x1

.field static final v:I = 0x2

.field static final w:I = 0x4

.field static final x:I = 0x8

.field private static final y:I

.field private static final z:I = -0x1


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I

.field private e:Z

.field private f:I

.field private g:Landroidx/core/view/y2;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/material/appbar/AppBarLayout$c;",
            ">;"
        }
    .end annotation
.end field

.field private i:Z

.field private j:Z

.field private k:Z

.field private l:Z

.field private m:I
    .annotation build Landroidx/annotation/d0;
    .end annotation
.end field

.field private n:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private o:Landroid/animation/ValueAnimator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final p:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/material/appbar/AppBarLayout$g;",
            ">;"
        }
    .end annotation
.end field

.field private q:[I

.field private r:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private s:Lcom/google/android/material/appbar/AppBarLayout$Behavior;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$style;->Widget_Design_AppBarLayout:I

    const/4 v1, 0x2

    move v2, v1

    sput v0, Lcom/google/android/material/appbar/AppBarLayout;->y:I

    const/4 v1, 0x2

    and-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x0

    xor-int/2addr v2, v0

    const/4 v1, 0x4

    and-int/2addr v2, v1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    sget v0, Lcom/google/android/material/R$attr;->appBarLayoutStyle:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/appbar/AppBarLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 11
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    sget v4, Lcom/google/android/material/appbar/AppBarLayout;->y:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    const/4 p1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->b:I

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->d:I

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    iput v6, p0, Lcom/google/android/material/appbar/AppBarLayout;->f:I

    const/4 v10, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->p:Ljava/util/List;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v0, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout;->setOrientation(I)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getOutlineProvider()Landroid/view/ViewOutlineProvider;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    sget-object v1, Landroid/view/ViewOutlineProvider;->BACKGROUND:Landroid/view/ViewOutlineProvider;

    const/4 v10, 0x6

    const/4 v9, 0x7

    if-ne v0, v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/google/android/material/appbar/j;->a(Landroid/view/View;)V

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {p0, p2, p3, v4}, Lcom/google/android/material/appbar/j;->c(Landroid/view/View;Landroid/util/AttributeSet;II)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    sget-object v2, Lcom/google/android/material/R$styleable;->AppBarLayout:[I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-array v5, v6, [I

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v3, p3

    move v3, p3

    const/4 v10, 0x2

    move v3, p3

    move v3, p3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_android_background:I

    const/4 v10, 0x0

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {p0, p3}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    instance-of p3, p3, Landroid/graphics/drawable/ColorDrawable;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz p3, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    check-cast p3, Landroid/graphics/drawable/ColorDrawable;

    const/4 v10, 0x7

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-direct {v0}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p3}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result p3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {p3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, p3}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, v7}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {p0, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_expanded:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz v0, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {p0, p3, v6, v6}, Lcom/google/android/material/appbar/AppBarLayout;->y(ZZZ)V

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_elevation:I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    int-to-float p3, p3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {p0, p3}, Lcom/google/android/material/appbar/j;->b(Landroid/view/View;F)V

    :cond_3
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/16 p3, 0x1a

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-lt v8, p3, :cond_5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_android_keyboardNavigationCluster:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    if-eqz v0, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v10, 0x0

    const/4 v9, 0x3

    invoke-static {p0, p3}, Lcom/google/android/material/appbar/a;->a(Lcom/google/android/material/appbar/AppBarLayout;Z)V

    :cond_4
    const/4 v10, 0x2

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_android_touchscreenBlocksFocus:I

    const/4 v9, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz v0, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->setTouchscreenBlocksFocus(Z)V

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_liftOnScroll:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    iput-boolean p3, p0, Lcom/google/android/material/appbar/AppBarLayout;->l:Z

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->AppBarLayout_liftOnScrollTargetViewId:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->m:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    sget p1, Lcom/google/android/material/R$styleable;->AppBarLayout_statusBarForeground:I

    const/4 v10, 0x2

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->setStatusBarForeground(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-instance p1, Lcom/google/android/material/appbar/AppBarLayout$a;

    const/4 v9, 0x2

    move v10, v9

    invoke-direct {p1, p0}, Lcom/google/android/material/appbar/AppBarLayout$a;-><init>(Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {p0, p1}, Landroidx/core/view/k1;->a2(Landroid/view/View;Landroidx/core/view/z0;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-void
.end method

.method private A(Z)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@.s @S@sor@ @  M~@  y@~~ ~~f -~~@~     t/n~1@@o@~u m@ o@@4cK~~~~~i@@f@o~ ~v~d~ab~i ~oitl~/lbob@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->j:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->j:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x2

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 p1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p1
.end method

.method private E()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-lez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method private G()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-lez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/16 v3, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eq v2, v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x2

    move v5, v4

    const/4 v1, 0x1

    move v5, v1

    :cond_0
    return v1
.end method

.method private H(Lcom/google/android/material/shape/j;Z)V
    .locals 5
    .param p1    # Lcom/google/android/material/shape/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    sget v1, Lcom/google/android/material/R$dimen;->design_appbar_elevation:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p2, :cond_0

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    const/4 v4, 0x1

    move v2, v1

    move v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    move v2, v0

    move v2, v0

    const/4 v4, 0x2

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->o:Landroid/animation/ValueAnimator;

    const/4 v3, 0x7

    const/4 v3, 0x1

    if-eqz p2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x3

    new-array p2, p2, [F

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput v2, p2, v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    aput v0, p2, v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p2}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->o:Landroid/animation/ValueAnimator;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget v1, Lcom/google/android/material/R$integer;->app_bar_elevation_anim_duration:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    int-to-long v0, v0

    const/4 v4, 0x7

    invoke-virtual {p2, v0, v1}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->o:Landroid/animation/ValueAnimator;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v0, Lcom/google/android/material/animation/a;->a:Landroid/animation/TimeInterpolator;

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p2, v0}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v3, 0x0

    move v4, v3

    iget-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->o:Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$b;-><init>(Lcom/google/android/material/appbar/AppBarLayout;Lcom/google/android/material/shape/j;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->o:Landroid/animation/ValueAnimator;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private I()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->E()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/appbar/AppBarLayout;)Landroid/graphics/drawable/Drawable;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic b(Lcom/google/android/material/appbar/AppBarLayout;)Ljava/util/List;
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    iget-object p0, p0, Lcom/google/android/material/appbar/AppBarLayout;->p:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method private g()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->n:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->clear()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->n:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private h(Landroid/view/View;)Landroid/view/View;
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->n:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->m:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-eq v0, v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x4

    and-int/2addr v4, v3

    instance-of v0, v0, Landroid/view/ViewGroup;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v3, 0x7

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->m:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x4

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->n:Ljava/lang/ref/WeakReference;

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->n:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v1, Landroid/view/View;

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object v1
.end method

.method private m()Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x3

    if-ge v2, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v3, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v3}, Lcom/google/android/material/appbar/AppBarLayout$f;->e()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1
.end method

.method private o()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->s:Lcom/google/android/material/appbar/AppBarLayout$Behavior;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    and-int/2addr v4, v3

    iget v2, p0, Lcom/google/android/material/appbar/AppBarLayout;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eq v2, v1, :cond_1

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/android/material/appbar/AppBarLayout;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v2, Landroidx/customview/view/AbsSavedState;->b:Landroidx/customview/view/AbsSavedState;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v2, p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->saveScrollState(Landroid/os/Parcelable;Lcom/google/android/material/appbar/AppBarLayout;)Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v0, 0x0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->d:I

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->s:Lcom/google/android/material/appbar/AppBarLayout$Behavior;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v0, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->restoreScrollState(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;Z)V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method private y(ZZZ)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x2

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    move p2, v0

    move p2, v0

    const/4 v2, 0x2

    move p2, v0

    move p2, v0

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x2

    or-int/2addr p1, p2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p3, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v0, 0x8

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->f:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public B(Z)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;->D(ZZ)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method C(Z)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->i:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;->D(ZZ)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p1
.end method

.method D(ZZ)Z
    .locals 2

    const/4 v1, 0x6

    if-eqz p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-boolean p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->k:Z

    const/4 v1, 0x5

    if-eq p2, p1, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->k:Z

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-boolean p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->l:Z

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    instance-of p2, p2, Lcom/google/android/material/shape/j;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    check-cast p2, Lcom/google/android/material/shape/j;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->H(Lcom/google/android/material/shape/j;Z)V

    :cond_0
    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x0

    return p1
.end method

.method F(Landroid/view/View;)Z
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->h(Landroid/view/View;)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-lez p1, :cond_2

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x0

    goto :goto_1

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1
.end method

.method public c(Lcom/google/android/material/appbar/AppBarLayout$g;)V
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->p:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    instance-of p1, p1, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p1
.end method

.method public d(Lcom/google/android/material/appbar/AppBarLayout$c;)V
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->draw(Landroid/graphics/Canvas;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->E()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    neg-int v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    int-to-float v1, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method protected drawableStateChanged()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-super {p0}, Landroid/widget/LinearLayout;->drawableStateChanged()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Landroid/view/View;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method public e(Lcom/google/android/material/appbar/AppBarLayout$h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->d(Lcom/google/android/material/appbar/AppBarLayout$c;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public f()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->p:Ljava/util/List;

    const/4 v1, 0x7

    move v2, v1

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->i()Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/widget/LinearLayout$LayoutParams;
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->i()Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->j(Landroid/util/AttributeSet;)Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method protected bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->k(Landroid/view/ViewGroup$LayoutParams;)Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/widget/LinearLayout$LayoutParams;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->j(Landroid/util/AttributeSet;)Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method protected bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/widget/LinearLayout$LayoutParams;
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->k(Landroid/view/ViewGroup$LayoutParams;)Lcom/google/android/material/appbar/AppBarLayout$f;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
            "Lcom/google/android/material/appbar/AppBarLayout;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$Behavior;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/material/appbar/AppBarLayout$Behavior;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->s:Lcom/google/android/material/appbar/AppBarLayout$Behavior;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method getDownNestedPreScrollRange()I
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    if-eq v0, v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x5

    return v0

    :cond_0
    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    move v2, v1

    const/4 v10, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-ltz v0, :cond_6

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    check-cast v4, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget v6, v4, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v10, 0x3

    and-int/lit8 v7, v6, 0x5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v8, 0x5

    const/4 v10, 0x6

    if-ne v7, v8, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget v7, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v9, 0x5

    move v10, v9

    iget v4, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/2addr v7, v4

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    and-int/lit8 v4, v6, 0x8

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v4, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {v3}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v4

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    add-int/2addr v7, v4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_2

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    and-int/lit8 v4, v6, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-eqz v4, :cond_2

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v3}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v4

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    sub-int v4, v5, v4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_1

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/2addr v7, v5

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-nez v0, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {v3}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v3, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    sub-int/2addr v5, v3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v7, v5}, Ljava/lang/Math;->min(II)I

    move-result v7

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    add-int/2addr v2, v7

    const/4 v9, 0x5

    move v10, v9

    goto :goto_3

    :cond_4
    const/4 v10, 0x0

    if-lez v2, :cond_5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto :goto_4

    :cond_5
    :goto_3
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_6
    :goto_4
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->c:I

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    return v0
.end method

.method getDownNestedScrollRange()I
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->d:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v1, -0x1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eq v0, v1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    return v0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v1, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    move v2, v1

    move v2, v1

    const/4 v10, 0x3

    move v2, v1

    move v2, v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    move v3, v2

    move v3, v2

    const/4 v10, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    if-ge v2, v0, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    check-cast v5, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v7, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v8, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    add-int/2addr v7, v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    add-int/2addr v6, v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget v5, v5, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    and-int/lit8 v7, v5, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-eqz v7, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/2addr v3, v6

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    and-int/lit8 v5, v5, 0x2

    const/4 v10, 0x7

    if-eqz v5, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v4}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    sub-int/2addr v3, v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_1

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v9, 0x2

    shl-int/2addr v10, v9

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->d:I

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    return v0
.end method

.method public getLiftOnScrollTargetViewId()I
    .locals 3
    .annotation build Landroidx/annotation/d0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public final getMinimumHeightForVisibleOverlappingContent()I
    .locals 5

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    mul-int/lit8 v1, v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/2addr v1, v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-lt v1, v2, :cond_1

    const/4 v4, 0x7

    sub-int/2addr v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    div-int/lit8 v0, v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method getPendingAction()I
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->f:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public getStatusBarForeground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public getTargetElevation()F
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method final getTopInset()I
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->g:Landroidx/core/view/y2;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/core/view/y2;->r()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    return v0
.end method

.method public final getTotalScrollRange()I
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->b:I

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v1, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-eq v0, v1, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    return v0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    move v2, v1

    move v2, v1

    const/4 v10, 0x3

    move v2, v1

    move v2, v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x4

    if-ge v2, v0, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    check-cast v5, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget v7, v5, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    and-int/lit8 v8, v7, 0x1

    const/4 v10, 0x2

    if-eqz v8, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget v8, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    add-int/2addr v6, v8

    const/4 v10, 0x3

    const/4 v9, 0x7

    iget v5, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    add-int/2addr v6, v5

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    add-int/2addr v3, v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v4}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v5, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v5

    const/4 v10, 0x5

    const/4 v9, 0x3

    sub-int/2addr v3, v5

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    and-int/lit8 v5, v7, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v5, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v4}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    sub-int/2addr v3, v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_1

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->b:I

    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    return v0
.end method

.method getUpNestedPreScrollRange()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method protected i()Lcom/google/android/material/appbar/AppBarLayout$f;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, -0x2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/appbar/AppBarLayout$f;-><init>(II)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method

.method public j(Landroid/util/AttributeSet;)Lcom/google/android/material/appbar/AppBarLayout$f;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1, p1}, Lcom/google/android/material/appbar/AppBarLayout$f;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method protected k(Landroid/view/ViewGroup$LayoutParams;)Lcom/google/android/material/appbar/AppBarLayout$f;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    instance-of v0, p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lcom/google/android/material/appbar/AppBarLayout$f;-><init>(Landroid/widget/LinearLayout$LayoutParams;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    instance-of v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v2, 0x4

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/material/appbar/AppBarLayout$f;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v1, 0x5

    move v2, v1

    return-object v0

    :cond_1
    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    invoke-direct {v0, p1}, Lcom/google/android/material/appbar/AppBarLayout$f;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x5

    const/4 v1, 0x2

    return-object v0
.end method

.method l()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    return v0
.end method

.method n()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/android/material/shape/k;->e(Landroid/view/View;)V

    const/4 v1, 0x4

    return-void
.end method

.method protected onCreateDrawableState(I)[I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->q:[I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v0, 0x4

    const/4 v5, 0x5

    move v4, v0

    move v4, v0

    const/4 v5, 0x6

    new-array v0, v0, [I

    const/4 v5, 0x7

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->q:[I

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->q:[I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/2addr p1, v1

    const/4 v4, 0x7

    and-int/2addr v5, v4

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-boolean v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->j:Z

    const/4 v5, 0x5

    sget v2, Lcom/google/android/material/R$attr;->state_liftable:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    neg-int v2, v2

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    aput v2, v0, v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x2

    iget-boolean v2, p0, Lcom/google/android/material/appbar/AppBarLayout;->k:Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget v2, Lcom/google/android/material/R$attr;->state_lifted:I

    const/4 v4, 0x0

    move v5, v4

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget v2, Lcom/google/android/material/R$attr;->state_lifted:I

    const/4 v5, 0x5

    neg-int v2, v2

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    aput v2, v0, v3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget v2, Lcom/google/android/material/R$attr;->state_collapsible:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_2

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    neg-int v2, v2

    :goto_2
    const/4 v4, 0x7

    move v5, v4

    const/4 v3, 0x2

    or-int/2addr v5, v3

    const/4 v4, 0x0

    move v5, v4

    aput v2, v0, v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-boolean v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->k:Z

    const/4 v5, 0x4

    if-eqz v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget v1, Lcom/google/android/material/R$attr;->state_collapsed:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_3

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget v1, Lcom/google/android/material/R$attr;->state_collapsed:I

    const/4 v4, 0x4

    const/4 v4, 0x5

    neg-int v1, v1

    :goto_3
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput v1, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object p1
.end method

.method protected onDetachedFromWindow()V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->g()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x5

    invoke-super/range {p0 .. p5}, Landroid/widget/LinearLayout;->onLayout(ZIIII)V

    const/4 v1, 0x4

    invoke-static {p0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->G()Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    sub-int/2addr p3, p2

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    if-ltz p3, :cond_0

    const/4 v1, 0x1

    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p4

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p4, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    add-int/lit8 p3, p3, -0x1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->o()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->e:Z

    const/4 v0, 0x4

    move v1, v0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    move p4, p1

    move p4, p1

    const/4 v1, 0x3

    move p4, p1

    move p4, p1

    :goto_1
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-ge p4, p3, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p5

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p5

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    check-cast p5, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p5}, Lcom/google/android/material/appbar/AppBarLayout$f;->d()Landroid/view/animation/Interpolator;

    move-result-object p5

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-eqz p5, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-boolean p2, p0, Lcom/google/android/material/appbar/AppBarLayout;->e:Z

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    goto :goto_2

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    add-int/lit8 p4, p4, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v1, 0x5

    const/4 v0, 0x2

    iget-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x2

    if-eqz p3, :cond_3

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p4

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p5

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p3, p1, p1, p4, p5}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    :cond_3
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-boolean p3, p0, Lcom/google/android/material/appbar/AppBarLayout;->i:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-nez p3, :cond_6

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-boolean p3, p0, Lcom/google/android/material/appbar/AppBarLayout;->l:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    if-nez p3, :cond_5

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->m()Z

    move-result p3

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-eqz p3, :cond_4

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    goto :goto_3

    :cond_4
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    move p2, p1

    move p2, p1

    const/4 v1, 0x7

    move p2, p1

    move p2, p1

    :cond_5
    :goto_3
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p2}, Lcom/google/android/material/appbar/AppBarLayout;->A(Z)Z

    :cond_6
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method protected onMeasure(II)V
    .locals 4

    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eq p1, v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->G()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/high16 v1, -0x80000000

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eq p1, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/2addr p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0, p2}, Lo/a;->e(III)I

    move-result v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/view/View;->setMeasuredDimension(II)V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->o()V

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public p()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->l:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public q()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->k:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method r(I)V
    .locals 5

    const/4 v4, 0x4

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->willNotDraw()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    move v4, v3

    if-ge v1, v0, :cond_2

    const/4 v3, 0x7

    move v4, v3

    iget-object v2, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout$c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v2, p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$c;->a(Lcom/google/android/material/appbar/AppBarLayout;I)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method s(Landroidx/core/view/y2;)Landroidx/core/view/y2;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->g:Landroidx/core/view/y2;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1, v0}, Landroidx/core/util/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->g:Landroidx/core/view/y2;

    const/4 v2, 0x2

    move v3, v2

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->I()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public setElevation(F)V
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setElevation(F)V

    const/4 v0, 0x0

    or-int/2addr v1, v0

    invoke-static {p0, p1}, Lcom/google/android/material/shape/k;->d(Landroid/view/View;F)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setExpanded(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/appbar/AppBarLayout;->x(ZZ)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setLiftOnScroll(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->l:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public setLiftOnScrollTargetViewId(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->m:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->g()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public setLiftableOverrideEnabled(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->i:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public setOrientation(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string v0, "Aowmtniniydatuosacaaoprvopsrat   otrel po nerahBtsa ns tyipi zdlL esaluirto"

    const-string/jumbo v0, "o sottaLnu iitnsntvaia r Be toysnt ruaaipra  lrs calooyeoeilndohstzAppprdaw"

    const-string/jumbo v0, "trpLoano acdhspiotoarvtt iolnayospeia   drAotuenry is ownlripna ltt seBzuoa"

    const-string v0, "AppBarLayout is always vertical and does not support horizontal orientation"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    throw p1
.end method

.method public setStatusBarForeground(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq v0, p1, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_3

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    move v0, v1

    move v0, v1

    const/4 v3, 0x1

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout;->I()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p0}, Landroidx/core/view/k1;->n1(Landroid/view/View;)V

    :cond_5
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public setStatusBarForegroundColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout;->setStatusBarForeground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public setStatusBarForegroundResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->setStatusBarForeground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public setTargetElevation(F)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lcom/google/android/material/appbar/j;->b(Landroid/view/View;F)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public setVisibility(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    move p1, v0

    move p1, v0

    const/4 v3, 0x7

    move p1, v0

    move p1, v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, p1, v0}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public t(Lcom/google/android/material/appbar/AppBarLayout$g;)Z
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->p:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public u(Lcom/google/android/material/appbar/AppBarLayout$c;)V
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->h:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public v(Lcom/google/android/material/appbar/AppBarLayout$h;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->u(Lcom/google/android/material/appbar/AppBarLayout$c;)V

    const/4 v1, 0x7

    return-void
.end method

.method protected verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->r:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x7

    return p1
.end method

.method w()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public x(ZZ)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/appbar/AppBarLayout;->y(ZZZ)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public z(Z)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/appbar/AppBarLayout;->i:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout;->A(Z)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method
