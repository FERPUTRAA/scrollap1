.class public final synthetic Lcom/google/android/material/appbar/e;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/widget/Toolbar;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "s@s~r  @~~ ~o iylb~~~~@ i @~v @S1to~@@@ 4~u~m@@ot@~ ~/f/lo ~@ bo@d ~ @Mb-o@f~a @@~ @  ~~.~~K@nc@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/widget/Toolbar;->getTitleMarginBottom()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method
