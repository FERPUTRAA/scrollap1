.class public final synthetic Lcom/google/android/material/appbar/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Lcom/google/android/material/appbar/AppBarLayout;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@st~~K @b@~/@mS@~@~~~  1s~~i@~obof~  ~b@@ @4@lr@~~o.@M@ v~n@ i @dc~i@f~~t  ~@o~o ~u ~l-/o   y @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/widget/LinearLayout;->setKeyboardNavigationCluster(Z)V

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
