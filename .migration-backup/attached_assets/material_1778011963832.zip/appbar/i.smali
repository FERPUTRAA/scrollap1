.class Lcom/google/android/material/appbar/i;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/view/View;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:Z

.field private g:Z


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/appbar/i;->f:Z

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/appbar/i;->g:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/appbar/i;->a:Landroid/view/View;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s o@i1@@o-.   ~ ~sy~@o~mol~ ~t@ @~io@@~@~~u ~~~c ~ @ibb @fS@t@f/~~@nK~~@@~ar4  ~o l@@b~ Mv~@d "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/i;->a:Landroid/view/View;

    const/4 v4, 0x7

    and-int/2addr v5, v4

    iget v1, p0, Lcom/google/android/material/appbar/i;->d:I

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v3, p0, Lcom/google/android/material/appbar/i;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    sub-int/2addr v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    sub-int/2addr v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/appbar/i;->a:Landroid/view/View;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/android/material/appbar/i;->e:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/android/material/appbar/i;->c:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    sub-int/2addr v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    sub-int/2addr v1, v2

    const/4 v5, 0x2

    invoke-static {v0, v1}, Landroidx/core/view/k1;->e1(Landroid/view/View;I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/appbar/i;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/appbar/i;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public d()I
    .locals 3

    iget v0, p0, Lcom/google/android/material/appbar/i;->e:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/appbar/i;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/appbar/i;->g:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/appbar/i;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method h()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/i;->a:Landroid/view/View;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/appbar/i;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/i;->a:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/material/appbar/i;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public i(Z)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    iput-boolean p1, p0, Lcom/google/android/material/appbar/i;->g:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public j(I)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/appbar/i;->g:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/appbar/i;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/appbar/i;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/appbar/i;->a()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method public k(I)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/appbar/i;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/appbar/i;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/android/material/appbar/i;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/i;->a()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method public l(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/appbar/i;->f:Z

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
