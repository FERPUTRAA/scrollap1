.class public Lcom/google/android/material/appbar/AppBarLayout$e;
.super Lcom/google/android/material/appbar/AppBarLayout$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# static fields
.field private static final c:F = 0.3f


# instance fields
.field private final a:Landroid/graphics/Rect;

.field private final b:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout$d;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->a:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x4

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->b:Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private static b(Landroid/graphics/Rect;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@sn@@~K~t@ @i~~o ~4uot@@  @~@Sol l@ b~~@~i~~i @f -1b@~@@./@ ov ~b f dM~@~o~@ ~ r /~@s ~@~ac mo~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p2, p0}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1, p2, p0}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    neg-int p1, p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p2, p1}, Landroid/graphics/Rect;->offset(II)V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;F)V
    .locals 4
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->a:Landroid/graphics/Rect;

    const/4 v2, 0x2

    or-int/2addr v3, v2

    invoke-static {v0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$e;->b(Landroid/graphics/Rect;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->a:Landroid/graphics/Rect;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget p1, p1, Landroid/graphics/Rect;->top:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    int-to-float p1, p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    sub-float/2addr p1, p3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p3, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    cmpg-float v0, p1, p3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-gtz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->a:Landroid/graphics/Rect;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    int-to-float v0, v0

    const/4 v3, 0x4

    div-float v0, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p3, v1}, Lo/a;->d(FFF)F

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    neg-float p1, p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    sub-float p3, v1, p3

    const/4 v3, 0x3

    const/4 v2, 0x7

    mul-float/2addr p3, p3

    const/4 v3, 0x3

    sub-float/2addr v1, p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->a:Landroid/graphics/Rect;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p3}, Landroid/graphics/Rect;->height()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    int-to-float p3, p3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const v0, 0x3e99999a    # 0.3f

    const/4 v3, 0x1

    mul-float/2addr p3, v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    mul-float/2addr p3, v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    sub-float/2addr p1, p3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2, p1}, Landroid/view/View;->setTranslationY(F)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->b:Landroid/graphics/Rect;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, p3}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->b:Landroid/graphics/Rect;

    const/4 v3, 0x7

    neg-float p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    float-to-int p1, p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p3, v0, p1}, Landroid/graphics/Rect;->offset(II)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$e;->b:Landroid/graphics/Rect;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p2, p1}, Landroidx/core/view/k1;->M1(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x7

    invoke-static {p2, p1}, Landroidx/core/view/k1;->M1(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2, p3}, Landroid/view/View;->setTranslationY(F)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method
