.class public Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;
.super Landroid/widget/FrameLayout$LayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/CollapsingToolbarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# static fields
.field private static final c:F = 0.5f

.field public static final d:I = 0x0

.field public static final e:I = 0x1

.field public static final f:I = 0x2


# instance fields
.field a:I

.field b:F


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 p1, 0x0

    move v1, p1

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(III)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    shl-int/2addr v3, v0

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v4, 0x4

    const/high16 v1, 0x3f000000    # 0.5f

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v2, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_Layout:[I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, p2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_Layout_layout_collapseMode:I

    const/4 v4, 0x2

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput p2, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget p2, Lcom/google/android/material/R$styleable;->CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, p2, v1}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->d(F)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2
    .param p1    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 2
    .param p1    # Landroid/view/ViewGroup$MarginLayoutParams;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v1, 0x6

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/widget/FrameLayout$LayoutParams;)V
    .locals 2
    .param p1    # Landroid/widget/FrameLayout$LayoutParams;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/widget/FrameLayout$LayoutParams;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "u/s @~y~or b@@~t@~m~~b@ ~@~of1~~~M@o~t@@i~-@vo  @ ol/~l  sia @~ @~Sdfb~~4@@   @c@@@o.  Kn~ ~ @~i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v2, 0x1

    return v0
.end method

.method public b()F
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v2, 0x4

    return v0
.end method

.method public c(I)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public d(F)V
    .locals 2

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/appbar/CollapsingToolbarLayout$c;->b:F

    const/4 v1, 0x7

    return-void
.end method
