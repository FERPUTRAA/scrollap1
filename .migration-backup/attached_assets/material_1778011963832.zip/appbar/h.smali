.class Lcom/google/android/material/appbar/h;
.super Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Landroid/view/View;",
        ">",
        "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
        "TV;>;"
    }
.end annotation


# instance fields
.field private tempLeftRightOffset:I

.field private tempTopBottomOffset:I

.field private viewOffsetHelper:Lcom/google/android/material/appbar/i;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/appbar/h;->tempTopBottomOffset:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    iput v0, p0, Lcom/google/android/material/appbar/h;->tempLeftRightOffset:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/h;->tempTopBottomOffset:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/h;->tempLeftRightOffset:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public getLeftAndRightOffset()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "f~s~S  Mt~-~@~~~f o~ isu~@  @1@~l  ~@@@/  ~@ao~b@i~~ .@ @~bl@o r@c4~y~om@ @@@@@i@ t K/~n~ vbo~~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/appbar/i;->d()I

    move-result v0

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public getTopAndBottomOffset()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/appbar/i;->e()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public isHorizontalOffsetEnabled()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/appbar/i;->f()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x1

    shr-int/2addr v2, v0

    const/4 v1, 0x2

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public isVerticalOffsetEnabled()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/appbar/i;->g()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method protected layoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->H(Landroid/view/View;I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;I)Z"
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/appbar/h;->layoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x3

    const/4 v0, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/material/appbar/i;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Lcom/google/android/material/appbar/i;-><init>(Landroid/view/View;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/appbar/i;->h()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/appbar/i;->a()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget p1, p0, Lcom/google/android/material/appbar/h;->tempTopBottomOffset:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x1

    iget-object p3, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p3, p1}, Lcom/google/android/material/appbar/i;->k(I)Z

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/material/appbar/h;->tempTopBottomOffset:I

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/android/material/appbar/h;->tempLeftRightOffset:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    if-eqz p1, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p3, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p3, p1}, Lcom/google/android/material/appbar/i;->j(I)Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p2, p0, Lcom/google/android/material/appbar/h;->tempLeftRightOffset:I

    :cond_2
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p1
.end method

.method public setHorizontalOffsetEnabled(Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/appbar/i;->i(Z)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setLeftAndRightOffset(I)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/appbar/i;->j(I)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/h;->tempLeftRightOffset:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method public setTopAndBottomOffset(I)Z
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/appbar/i;->k(I)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/appbar/h;->tempTopBottomOffset:I

    const/4 p1, 0x3

    move v2, p1

    const/4 p1, 0x0

    shr-int/2addr v2, p1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p1
.end method

.method public setVerticalOffsetEnabled(Z)V
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/appbar/h;->viewOffsetHelper:Lcom/google/android/material/appbar/i;

    const/4 v1, 0x3

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/appbar/i;->l(Z)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method
