.class Lcom/google/android/material/appbar/j;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x15
.end annotation


# static fields
.field private static final a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const v0, 0x1010448

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/appbar/j;->a:[I

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static a(Landroid/view/View;)V
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s/~~~ .f i@y @@@ @o@~ ~ ovo @ ~ @fu~~@ioolb@ M~s l@@b@@od~~~1~ @tK  ~@@S/~@tr-@abim~ ~~c n4~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Landroid/view/ViewOutlineProvider;->BOUNDS:Landroid/view/ViewOutlineProvider;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method static b(Landroid/view/View;F)V
    .locals 13
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    sget v1, Lcom/google/android/material/R$integer;->app_bar_elevation_anim_duration:I

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    new-instance v1, Landroid/animation/StateListAnimator;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-direct {v1}, Landroid/animation/StateListAnimator;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    sget v2, Lcom/google/android/material/R$attr;->state_liftable:I

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    sget v3, Lcom/google/android/material/R$attr;->state_lifted:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    neg-int v3, v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    const v4, 0x101009e

    const/4 v12, 0x0

    filled-new-array {v4, v2, v3}, [I

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v3, 0x1

    new-array v5, v3, [F

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v6, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    const/4 v7, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    aput v7, v5, v6

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    const-string/jumbo v8, "svemoelia"

    const-string v8, "alsieeovt"

    const/4 v12, 0x0

    const-string/jumbo v8, "teavonioe"

    const-string v8, "elevation"

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-static {p0, v8, v5}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v5

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    int-to-long v9, v0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v5, v9, v10}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v1, v2, v0}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    filled-new-array {v4}, [I

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    new-array v2, v3, [F

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    aput p1, v2, v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {p0, v8, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {p1, v9, v10}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {v1, v0, p1}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    new-array p1, v6, [I

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-array v0, v3, [F

    const/4 v12, 0x3

    aput v7, v0, v6

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {p0, v8, v0}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x2

    invoke-virtual {v0, v2, v3}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {v1, p1, v0}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p0, v1}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    return-void
.end method

.method static c(Landroid/view/View;Landroid/util/AttributeSet;II)V
    .locals 10
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    sget-object v2, Lcom/google/android/material/appbar/j;->a:[I

    const/4 v9, 0x6

    const/4 v7, 0x0

    or-int/2addr v8, v7

    const/4 v9, 0x1

    new-array v5, v7, [I

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    move v3, p2

    move v3, p2

    const/4 v9, 0x0

    move v3, p2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    move v4, p3

    move v4, p3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p1, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz p2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1, v7, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v6, p2}, Landroid/animation/AnimatorInflater;->loadStateListAnimator(Landroid/content/Context;I)Landroid/animation/StateListAnimator;

    move-result-object p2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0, p2}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v9, 0x2

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    throw p0
.end method
