.class public Lcom/google/android/material/appbar/AppBarLayout$f;
.super Landroid/widget/LinearLayout$LayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/appbar/AppBarLayout$f$a;
    }
.end annotation


# static fields
.field public static final d:I = 0x0

.field public static final e:I = 0x1

.field public static final f:I = 0x2

.field public static final g:I = 0x4

.field public static final h:I = 0x8

.field public static final i:I = 0x10

.field public static final j:I = 0x20

.field static final k:I = 0x5

.field static final l:I = 0x11

.field static final m:I = 0xa

.field private static final n:I = 0x0

.field private static final o:I = 0x1


# instance fields
.field a:I

.field private b:Lcom/google/android/material/appbar/AppBarLayout$d;

.field c:Landroid/view/animation/Interpolator;


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>(IIF)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    or-int/2addr v4, v3

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v0, Lcom/google/android/material/R$styleable;->AppBarLayout_Layout:[I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget v0, Lcom/google/android/material/R$styleable;->AppBarLayout_Layout_layout_scrollFlags:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v0, Lcom/google/android/material/R$styleable;->AppBarLayout_Layout_layout_scrollEffect:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout$f;->a(I)Lcom/google/android/material/appbar/AppBarLayout$d;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout$f;->f(Lcom/google/android/material/appbar/AppBarLayout$d;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget v0, Lcom/google/android/material/R$styleable;->AppBarLayout_Layout_layout_scrollInterpolator:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, v0}, Landroid/view/animation/AnimationUtils;->loadInterpolator(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->c:Landroid/view/animation/Interpolator;

    :cond_0
    const/4 v4, 0x3

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/widget/LinearLayout$LayoutParams;)V
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/widget/LinearLayout$LayoutParams;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/appbar/AppBarLayout$f;)V
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(Landroid/widget/LinearLayout$LayoutParams;)V

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    or-int/2addr v1, v0

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p1, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/google/android/material/appbar/AppBarLayout$f;->c:Landroid/view/animation/Interpolator;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->c:Landroid/view/animation/Interpolator;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method private a(I)Lcom/google/android/material/appbar/AppBarLayout$d;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@ So~y-a~l .u1~@  t@ ~@~/@ ~@f@f ~~d~@ ~nov@ r~@~~@ob@oi@@o bm~~s~K~ ~o bi  c@/4@~@M ~t@ ~il "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p1, Lcom/google/android/material/appbar/AppBarLayout$e;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1}, Lcom/google/android/material/appbar/AppBarLayout$e;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method


# virtual methods
.method public b()Lcom/google/android/material/appbar/AppBarLayout$d;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->b:Lcom/google/android/material/appbar/AppBarLayout$d;

    const/4 v2, 0x4

    return-object v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public d()Landroid/view/animation/Interpolator;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->c:Landroid/view/animation/Interpolator;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    return-object v0
.end method

.method e()Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    and-int/lit8 v1, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ne v1, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    and-int/lit8 v0, v0, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v2
.end method

.method public f(Lcom/google/android/material/appbar/AppBarLayout$d;)V
    .locals 2
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->b:Lcom/google/android/material/appbar/AppBarLayout$d;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public g(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public h(Landroid/view/animation/Interpolator;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$f;->c:Landroid/view/animation/Interpolator;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
