.class public final synthetic Lcom/google/android/material/appbar/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/widget/Toolbar;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@osiM s@~i~4 ~.@@t~~uK fa~Sv  @~@r@@~m@ @~~~flc@~d~@@y~~@b@@n~ o ~  oo~b-o~~~ @l @/to1i@  ~  @/ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/widget/Toolbar;->getTitleMarginTop()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method
