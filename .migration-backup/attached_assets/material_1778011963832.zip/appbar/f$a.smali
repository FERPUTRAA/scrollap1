.class Lcom/google/android/material/appbar/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

.field private final b:Landroid/view/View;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field final synthetic c:Lcom/google/android/material/appbar/f;


# direct methods
.method constructor <init>(Lcom/google/android/material/appbar/f;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/appbar/f$a;->c:Lcom/google/android/material/appbar/f;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/appbar/f$a;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/material/appbar/f$a;->b:Landroid/view/View;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o~syl  ~o@~b@ @t~~a@ b~~~o~ v@@t   @idm@@ ~c ~K~ f@i~f~~ou/~@  ~~So @@~@@-4.rb@@n@@/1o~ sMl@ ~~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/f$a;->b:Landroid/view/View;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/appbar/f$a;->c:Lcom/google/android/material/appbar/f;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, v0, Lcom/google/android/material/appbar/f;->scroller:Landroid/widget/OverScroller;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/appbar/f$a;->c:Lcom/google/android/material/appbar/f;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/appbar/f$a;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/material/appbar/f$a;->b:Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v3, v0, Lcom/google/android/material/appbar/f;->scroller:Landroid/widget/OverScroller;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v3}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/f$a;->b:Landroid/view/View;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, p0}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/appbar/f$a;->c:Lcom/google/android/material/appbar/f;

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/material/appbar/f$a;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/material/appbar/f$a;->b:Landroid/view/View;

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/appbar/f;->onFlingFinished(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method
