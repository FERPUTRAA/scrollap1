.class public final synthetic Lcom/google/android/material/appbar/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/widget/Toolbar;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~rsmo~~@~K- t@f~@S~@o~~tbol@~@.M~b  @@   @o4d @inf~~l~~ @you@sc @1v@~ i ~/~@  /@a@  ~i@~o@ ~@ b~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/widget/Toolbar;->getTitleMarginEnd()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p0
.end method
