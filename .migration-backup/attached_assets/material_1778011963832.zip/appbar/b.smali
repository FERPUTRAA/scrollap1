.class public final synthetic Lcom/google/android/material/appbar/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/widget/Toolbar;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b4s1@o/  i@af~o@@~o~~t ~f~ l~~ @u@b @@ ~ m d~Mv ~~~iS~nt~@@@~ /  ~@ioo@~@@~l @~sr@co@@K  -y ~b.~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/widget/Toolbar;->getTitleMarginStart()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    return p0
.end method
