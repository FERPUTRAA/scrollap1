.class Lcom/google/android/material/navigationrail/NavigationRailView$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/navigationrail/NavigationRailView;->p()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/navigationrail/NavigationRailView;


# direct methods
.method constructor <init>(Lcom/google/android/material/navigationrail/NavigationRailView;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView$a;->a:Lcom/google/android/material/navigationrail/NavigationRailView;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;
    .locals 6
    .param p2    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/internal/y$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "-~ss ~~@/ooo~l@f @o@@l@ bv@~ o @ @  ~mb 4ot ~r@@f S~~~@@ tcdi~K~@M~~~ iu~bn ~~~~@1~~ @ a@@y.@@i/"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView$a;->a:Lcom/google/android/material/navigationrail/NavigationRailView;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/material/navigationrail/NavigationRailView;->k(Lcom/google/android/material/navigationrail/NavigationRailView;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/google/android/material/navigationrail/NavigationRailView;->l(Lcom/google/android/material/navigationrail/NavigationRailView;Ljava/lang/Boolean;)Z

    move-result v0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v0, p3, Lcom/google/android/material/internal/y$f;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {}, Landroidx/core/view/y2$m;->i()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p2, v1}, Landroidx/core/view/y2;->f(I)Landroidx/core/graphics/g0;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v1, v1, Landroidx/core/graphics/g0;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/2addr v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput v0, p3, Lcom/google/android/material/internal/y$f;->b:I

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView$a;->a:Lcom/google/android/material/navigationrail/NavigationRailView;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/google/android/material/navigationrail/NavigationRailView;->m(Lcom/google/android/material/navigationrail/NavigationRailView;)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/google/android/material/navigationrail/NavigationRailView;->l(Lcom/google/android/material/navigationrail/NavigationRailView;Ljava/lang/Boolean;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    iget v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v4, 0x6

    move v5, v4

    invoke-static {}, Landroidx/core/view/y2$m;->i()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Landroidx/core/view/y2;->f(I)Landroidx/core/graphics/g0;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v1, v1, Landroidx/core/graphics/g0;->d:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/2addr v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ne v0, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v3, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v5, 0x2

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    const/4 v5, 0x5

    move v0, v2

    move v0, v2

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/2addr v3, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput v3, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p3, p1}, Lcom/google/android/material/internal/y$f;->a(Landroid/view/View;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object p2
.end method
