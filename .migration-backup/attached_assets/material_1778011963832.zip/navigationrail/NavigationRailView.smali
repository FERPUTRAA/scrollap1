.class public Lcom/google/android/material/navigationrail/NavigationRailView;
.super Lcom/google/android/material/navigation/NavigationBarView;


# static fields
.field static final q:I = 0x31

.field static final r:I = 0x7

.field private static final s:I = 0x31

.field static final t:I = -0x1


# instance fields
.field private final m:I

.field private n:Landroid/view/View;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private o:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private p:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/navigationrail/NavigationRailView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$attr;->navigationRailStyle:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/navigationrail/NavigationRailView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_NavigationRailView:I

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/navigationrail/NavigationRailView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/navigation/NavigationBarView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v6, 0x0

    move v7, v6

    const/4 p1, 0x0

    and-int/2addr v7, p1

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    iput-object p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->o:Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->p:Ljava/lang/Boolean;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_navigation_rail_margin:I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    iput p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->m:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget-object v2, Lcom/google/android/material/R$styleable;->NavigationRailView:[I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 p1, 0x0

    const/4 v7, 0x5

    new-array v5, p1, [I

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    move v3, p3

    move v3, p3

    const/4 v7, 0x7

    move v3, p3

    move v3, p3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v4, p4

    move v4, p4

    const/4 v7, 0x0

    move v4, p4

    move v4, p4

    const/4 v7, 0x1

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->k(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroidx/appcompat/widget/n2;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->NavigationRailView_headerLayout:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p2, p3, p1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz p3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/navigationrail/NavigationRailView;->n(I)V

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->NavigationRailView_menuGravity:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/16 p4, 0x31

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, p3, p4}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result p3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, p3}, Lcom/google/android/material/navigationrail/NavigationRailView;->setMenuGravity(I)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->NavigationRailView_itemMinHeight:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p2, p3}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p4

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz p4, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 p4, -0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p2, p3, p4}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p3

    const/4 v7, 0x7

    invoke-virtual {p0, p3}, Lcom/google/android/material/navigationrail/NavigationRailView;->setItemMinimumHeight(I)V

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->NavigationRailView_paddingTopSystemWindowInsets:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p2, p3}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p4

    const/4 v7, 0x7

    const/4 v6, 0x3

    if-eqz p4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p2, p3, p1}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-object p3, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->o:Ljava/lang/Boolean;

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->NavigationRailView_paddingBottomSystemWindowInsets:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p4, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2, p3, p1}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->p:Ljava/lang/Boolean;

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2}, Landroidx/appcompat/widget/n2;->I()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->p()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-void
.end method

.method private getNavigationRailMenuView()Lcom/google/android/material/navigationrail/NavigationRailMenuView;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i4s@~~ lo~do~ @~ ~@~@/- @~~c@i @ bb@ K~@@tlM @o@rn~f~@ @y/iotvo@s~~  ~~~mS .f@~  ~~@ ub~1 a @@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarView;->getMenuView()Landroidx/appcompat/view/menu/o;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic k(Lcom/google/android/material/navigationrail/NavigationRailView;)Ljava/lang/Boolean;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->o:Ljava/lang/Boolean;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic l(Lcom/google/android/material/navigationrail/NavigationRailView;Ljava/lang/Boolean;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/navigationrail/NavigationRailView;->u(Ljava/lang/Boolean;)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    return p0
.end method

.method static synthetic m(Lcom/google/android/material/navigationrail/NavigationRailView;)Ljava/lang/Boolean;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->p:Ljava/lang/Boolean;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method private p()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/material/navigationrail/NavigationRailView$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/navigationrail/NavigationRailView$a;-><init>(Lcom/google/android/material/navigationrail/NavigationRailView;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/internal/y;->d(Landroid/view/View;Lcom/google/android/material/internal/y$e;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private r()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method private s(I)I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getSuggestedMinimumWidth()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v4, 0x0

    or-int/2addr v5, v4

    if-eq v1, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-lez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-int/2addr v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    return p1
.end method

.method private u(Ljava/lang/Boolean;)Z
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result p1

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1
.end method


# virtual methods
.method protected bridge synthetic d(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarMenuView;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigationrail/NavigationRailView;->q(Landroid/content/Context;)Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public getHeaderView()Landroid/view/View;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getItemMinimumHeight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarView;->getMenuView()Landroidx/appcompat/view/menu/o;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->getItemMinimumHeight()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getMaxItemCount()I
    .locals 3

    const/4 v2, 0x0

    const/4 v0, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getMenuGravity()I
    .locals 3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->getNavigationRailMenuView()Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->getMenuGravity()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public n(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1, p0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigationrail/NavigationRailView;->o(Landroid/view/View;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public o(Landroid/view/View;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->t()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, -0x2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v1, 0x31

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->m:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super/range {p0 .. p5}, Landroid/widget/FrameLayout;->onLayout(ZIIII)V

    const/4 v1, 0x5

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->getNavigationRailMenuView()Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->r()Z

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget p4, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->m:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    add-int/2addr p2, p4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p4

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-ge p4, p2, :cond_1

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    sub-int/2addr p2, p4

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    move p3, p2

    move p3, p2

    const/4 v2, 0x0

    move p3, p2

    move p3, p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->u()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p2, :cond_1

    const/4 v1, 0x4

    and-int/2addr v2, v1

    iget p3, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->m:I

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-lez p3, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p4

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    add-int/2addr p4, p3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result p5

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    add-int/2addr v0, p3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1, p2, p4, p5, v0}, Landroid/view/View;->layout(IIII)V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method protected onMeasure(II)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/navigationrail/NavigationRailView;->s(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->r()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p2, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sub-int/2addr p2, v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->m:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    sub-int/2addr p2, v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/high16 v0, -0x80000000

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->getNavigationRailMenuView()Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Landroid/view/ViewGroup;->measureChild(Landroid/view/View;II)V

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method protected q(Landroid/content/Context;)Lcom/google/android/material/navigationrail/NavigationRailMenuView;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public setItemMinimumHeight(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarView;->getMenuView()Landroidx/appcompat/view/menu/o;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->setItemMinimumHeight(I)V

    const/4 v2, 0x4

    return-void
.end method

.method public setMenuGravity(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/navigationrail/NavigationRailView;->getNavigationRailMenuView()Lcom/google/android/material/navigationrail/NavigationRailMenuView;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->setMenuGravity(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public t()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailView;->n:Landroid/view/View;

    :cond_0
    const/4 v2, 0x4

    return-void
.end method
