.class public Lcom/google/android/material/navigationrail/NavigationRailMenuView;
.super Lcom/google/android/material/navigation/NavigationBarMenuView;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field private G:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private final H:Landroid/widget/FrameLayout$LayoutParams;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->G:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    const/4 v1, -0x2

    const/4 v1, -0x2

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->H:Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 p1, 0x31

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorResizeable(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private v(III)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  sraoo@@o  m iofyc @~4i-~~@ t~~/t n~o @@ @@~M~@~ /~ ~@v @@ f~.@Sb i@@@bdK @~~l~~s~l~b~ @~o~@1@u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {v0, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    div-int/2addr p2, p3

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    iget p3, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->G:I

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x5

    and-int/2addr v1, v0

    const/4 v2, 0x2

    if-eq p3, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p3

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p3, p2}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p2, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1
.end method

.method private w(Landroid/view/View;II)I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0x8

    const/4 v2, 0x4

    move v3, v2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1
.end method

.method private x(IIILandroid/view/View;)I
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->v(III)I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p4, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->v(III)I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p4}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-ge v0, p3, :cond_2

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-eq v2, p4, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, v2, p1, p2}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->w(Landroid/view/View;II)I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    add-int/2addr v1, v2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method private y(III)I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getSelectedItemPosition()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->v(III)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, v0, p1, v1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->w(Landroid/view/View;II)I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    sub-int/2addr p2, v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->x(IIILandroid/view/View;)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr v1, p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1
.end method


# virtual methods
.method protected g(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarItemView;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    new-instance v0, Lcom/google/android/material/navigationrail/a;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Lcom/google/android/material/navigationrail/a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getItemMinimumHeight()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->G:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method getMenuGravity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->H:Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, 0x0

    const/4 v1, 0x0

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method protected onLayout(ZIIII)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    sub-int/2addr p4, p2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 p2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    move p3, p2

    move p3, p2

    const/4 v4, 0x7

    move p3, p2

    move p3, p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    move p5, p3

    const/4 v4, 0x1

    move p5, p3

    move p5, p3

    :goto_0
    const/4 v3, 0x1

    move v4, v3

    if-ge p3, p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v2, 0x8

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq v1, v2, :cond_0

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-int/2addr v1, p5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p2, p5, p4, v1}, Landroid/view/View;->layout(IIII)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    move p5, v1

    move p5, v1

    const/4 v4, 0x1

    move p5, v1

    move p5, v1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/lit8 p3, p3, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method protected onMeasure(II)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getMenu()Landroidx/appcompat/view/menu/g;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-le v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getLabelVisibilityMode()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v2, v1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->l(II)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, p1, v0, v1}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->y(III)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->x(IIILandroid/view/View;)I

    move-result v0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v1, p1, v2}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0, p2, v2}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    const/4 v4, 0x0

    return-void
.end method

.method public setItemMinimumHeight(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->G:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->G:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method setMenuGravity(I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->H:Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eq v1, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    return-void
.end method

.method u()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigationrail/NavigationRailMenuView;->H:Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x5

    and-int/lit8 v0, v0, 0x70

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/16 v1, 0x30

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0
.end method
