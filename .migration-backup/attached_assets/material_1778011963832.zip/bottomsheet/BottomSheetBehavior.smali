.class public Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
.super Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;,
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;,
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$g;,
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$h;,
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$i;,
        Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Landroid/view/View;",
        ">",
        "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
        "TV;>;"
    }
.end annotation


# static fields
.field public static final d0:I = 0x1

.field public static final e0:I = 0x2

.field public static final f0:I = 0x3

.field public static final g0:I = 0x4

.field public static final h0:I = 0x5

.field public static final i0:I = 0x6

.field public static final j0:I = -0x1

.field public static final k0:I = 0x1

.field public static final l0:I = 0x2

.field public static final m0:I = 0x4

.field public static final n0:I = 0x8

.field public static final o0:I = -0x1

.field public static final p0:I = 0x0

.field private static final q0:Ljava/lang/String; = "BottomSheetBehavior"

.field private static final r0:I = 0x1f4

.field private static final s0:F = 0.5f

.field private static final t0:F = 0.1f

.field private static final u0:I = 0x1f4

.field private static final v0:I = -0x1

.field private static final w0:I


# instance fields
.field private A:Landroid/animation/ValueAnimator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field B:I

.field C:I

.field D:I

.field E:F

.field F:I

.field G:F

.field H:Z

.field private I:Z

.field private J:Z

.field K:I

.field L:I

.field M:Landroidx/customview/widget/d;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private N:Z

.field private O:I

.field private P:Z

.field private Q:I

.field R:I

.field S:I

.field T:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "TV;>;"
        }
    .end annotation
.end field

.field U:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private final V:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;",
            ">;"
        }
    .end annotation
.end field

.field private W:Landroid/view/VelocityTracker;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field X:I

.field private Y:I

.field Z:Z

.field private a:I

.field private a0:Ljava/util/Map;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private b:Z

.field private b0:I

.field private c:Z

.field private final c0:Landroidx/customview/widget/d$c;

.field private d:F

.field private e:I

.field private f:Z

.field private g:I

.field private h:I

.field private i:Lcom/google/android/material/shape/j;

.field private j:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private k:I

.field private l:I

.field private m:I

.field private n:Z

.field private o:Z

.field private p:Z

.field private q:Z

.field private r:Z

.field private s:Z

.field private t:Z

.field private u:Z

.field private v:I

.field private w:I

.field private x:Lcom/google/android/material/shape/o;

.field private y:Z

.field private final z:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/bottomsheet/BottomSheetBehavior<",
            "TV;>.j;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$style;->Widget_Design_BottomSheet_Modal:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w0:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 6

    const/4 v4, 0x3

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x1

    move v5, v1

    const/4 v4, 0x6

    and-int/2addr v5, v4

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v2, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2, p0, v3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Lcom/google/android/material/bottomsheet/BottomSheetBehavior$a;)V

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->z:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/high16 v2, 0x3f000000    # 0.5f

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E:F

    const/4 v4, 0x0

    move v5, v4

    const/high16 v2, -0x40800000    # -1.0f

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:F

    const/4 v4, 0x0

    move v5, v4

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b0:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c0:Landroidx/customview/widget/d$c;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 10
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a:I

    const/4 v8, 0x0

    and-int/2addr v9, v8

    const/4 v1, 0x1

    move v9, v1

    const/4 v8, 0x3

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v2, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k:I

    const/4 v8, 0x0

    move v9, v8

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l:I

    const/4 v9, 0x0

    new-instance v3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {v3, p0, v4}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Lcom/google/android/material/bottomsheet/BottomSheetBehavior$a;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    iput-object v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->z:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/high16 v3, 0x3f000000    # 0.5f

    const/4 v9, 0x7

    const/4 v8, 0x6

    iput v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E:F

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/high16 v4, -0x40800000    # -1.0f

    const/4 v9, 0x6

    const/4 v8, 0x1

    iput v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:F

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v5, 0x4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    iput v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v9, 0x5

    iput v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    const/4 v9, 0x4

    const/4 v8, 0x0

    new-instance v5, Ljava/util/ArrayList;

    const/4 v9, 0x7

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x2

    iput-object v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b0:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    new-instance v5, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {v5, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    iput-object v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c0:Landroidx/customview/widget/d$c;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    sget v6, Lcom/google/android/material/R$dimen;->mtrl_min_touch_target_size:I

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    iput v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->h:I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget-object v5, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout:[I

    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-virtual {p1, p2, v5}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    sget v6, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_backgroundTint:I

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v5, v6}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz v7, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p1, v5, v6}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    iput-object v6, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->j:Landroid/content/res/ColorStateList;

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    sget v6, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_shapeAppearance:I

    const/4 v9, 0x1

    invoke-virtual {v5, v6}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    const/4 v9, 0x5

    const/4 v8, 0x1

    if-eqz v6, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    sget v6, Lcom/google/android/material/R$attr;->bottomSheetStyle:I

    const/4 v8, 0x4

    move v9, v8

    sget v7, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w0:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1, p2, v6, v7}, Lcom/google/android/material/shape/o;->e(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/shape/o$b;

    move-result-object p2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p2}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    iput-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x:Lcom/google/android/material/shape/o;

    :cond_1
    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x(Landroid/content/Context;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->y()V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_android_elevation:I

    const/4 v9, 0x0

    invoke-virtual {v5, p2, v4}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iput p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:F

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_android_maxWidth:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz v4, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5, p2, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l0(I)V

    :cond_2
    const/4 v9, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_android_maxHeight:I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v5, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v4, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5, p2, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k0(I)V

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x3

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_peekHeight:I

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v5, p2}, Landroid/content/res/TypedArray;->peekValue(I)Landroid/util/TypedValue;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v4, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget v4, v4, Landroid/util/TypedValue;->data:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-ne v4, v2, :cond_4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p0, v4}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m0(I)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_0

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v5, p2, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m0(I)V

    :goto_0
    const/4 v8, 0x0

    move v9, v8

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_hideable:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i0(Z)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_gestureInsetBottomIgnored:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->g0(Z)V

    const/4 v9, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_fitToContents:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v5, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f0(Z)V

    const/4 v9, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_skipCollapsed:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p0(Z)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_draggable:I

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v5, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->d0(Z)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_saveFlags:I

    const/4 v9, 0x2

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o0(I)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_halfExpandedRatio:I

    const/4 v9, 0x1

    invoke-virtual {v5, p2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->h0(F)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_behavior_expandedOffset:I

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v5, p2}, Landroid/content/res/TypedArray;->peekValue(I)Landroid/util/TypedValue;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v2, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget v3, v2, Landroid/util/TypedValue;->type:I

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/16 v4, 0x10

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-ne v3, v4, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget p2, v2, Landroid/util/TypedValue;->data:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e0(I)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto :goto_1

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e0(I)V

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_paddingBottomSystemWindowInsets:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o:Z

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_paddingLeftSystemWindowInsets:I

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x3

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p:Z

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_paddingRightSystemWindowInsets:I

    const/4 v8, 0x2

    move v9, v8

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x2

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q:Z

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_paddingTopSystemWindowInsets:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v5, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r:Z

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_marginLeftSystemWindowInsets:I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->s:Z

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_marginRightSystemWindowInsets:I

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t:Z

    const/4 v9, 0x0

    sget p2, Lcom/google/android/material/R$styleable;->BottomSheetBehavior_Layout_marginTopSystemWindowInsets:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v5, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u:Z

    const/4 v9, 0x2

    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p1}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    int-to-float p1, p1

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->d:F

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-void
.end method

.method private A0()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v0, Landroid/view/View;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x1

    move v6, v5

    return-void

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/high16 v1, 0x80000

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v1}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/high16 v1, 0x40000

    const/4 v6, 0x1

    invoke-static {v0, v1}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v6, 0x1

    const/high16 v1, 0x100000

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v1}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b0:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v2, -0x1

    const/4 v2, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eq v1, v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-static {v0, v1}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    :cond_2
    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v2, 0x6

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq v1, v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget v1, Lcom/google/android/material/R$string;->bottomsheet_action_expand_halfway:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, v0, v1, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r(Landroid/view/View;II)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b0:I

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v3, 0x5

    const/4 v6, 0x1

    if-eq v1, v3, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v1, Landroidx/core/view/accessibility/l0$a;->z:Landroidx/core/view/accessibility/l0$a;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0, v0, v1, v3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v3, 0x4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x0

    if-eq v1, v4, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eq v1, v3, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eq v1, v2, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    sget-object v1, Landroidx/core/view/accessibility/l0$a;->y:Landroidx/core/view/accessibility/l0$a;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p0, v0, v1, v3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    sget-object v1, Landroidx/core/view/accessibility/l0$a;->x:Landroidx/core/view/accessibility/l0$a;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-direct {p0, v0, v1, v4}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_7

    const/4 v6, 0x2

    move v2, v4

    move v2, v4

    const/4 v6, 0x3

    move v2, v4

    move v2, v4

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget-object v1, Landroidx/core/view/accessibility/l0$a;->x:Landroidx/core/view/accessibility/l0$a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v1, :cond_9

    const/4 v5, 0x4

    and-int/2addr v6, v5

    move v2, v3

    move v2, v3

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    :cond_9
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v1, Landroidx/core/view/accessibility/l0$a;->y:Landroidx/core/view/accessibility/l0$a;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {p0, v0, v1, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void
.end method

.method private B0(I)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-ne p1, v0, :cond_0

    const/4 v6, 0x6

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v1, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-ne p1, v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    move p1, v2

    move p1, v2

    move p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    move p1, v3

    move p1, v3

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->y:Z

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eq v1, p1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->y:Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    if-eqz v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->reverse()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x5

    goto :goto_1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    move p1, v1

    const/4 v6, 0x1

    move p1, v1

    move p1, v1

    :goto_1
    const/4 v6, 0x6

    sub-float/2addr v1, p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-array v0, v0, [F

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    aput v1, v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    aput p1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v4, v0}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    :cond_4
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method

.method public static C(Landroid/view/View;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Landroid/view/View;",
            ">(TV;)",
            "Lcom/google/android/material/bottomsheet/BottomSheetBehavior<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    instance-of v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "ihshvsteBe sTBeaoeht wr dohtimi svtewas otacoe oitn"

    const-string/jumbo v0, "noshswiacwv deB  raeiahTeSto eeieoimtttthohsvst B o"

    const/4 v2, 0x0

    const-string/jumbo v0, "idBms niBieswah teetoo cttmeTe ew hoaSvhaois rthtoi"

    const-string v0, "The view is not associated with BottomSheetBehavior"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p0

    :cond_1
    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "orTdoaaei Lu o noeoit hvtrayiiosCthnwcfo m l"

    const-string/jumbo v0, "tnom e dooeahCTnihoius iatrwo drfayvl iLtc o"

    const/4 v2, 0x3

    const-string/jumbo v0, "tni obortihia inL  rwuotsCTv eyadcfoeoahldo "

    const-string v0, "The view is not a child of CoordinatorLayout"

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    throw p0
.end method

.method private C0(Z)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v0, Landroid/view/View;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v7, 0x0

    instance-of v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v6, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz p1, :cond_3

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v2, Ljava/util/HashMap;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {v2, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void

    :cond_3
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v2, 0x6

    const/4 v2, 0x0

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ge v2, v1, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-ne v3, v4, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_2

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz p1, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v6, 0x3

    xor-int/2addr v7, v6

    invoke-virtual {v3}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v4, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-boolean v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v7, 0x7

    const/4 v6, 0x5

    if-eqz v4, :cond_6

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v4, 0x4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v3, v4}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_2

    :cond_5
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-boolean v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v7, 0x3

    if-eqz v4, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v6, 0x7

    move v7, v6

    if-eqz v4, :cond_6

    const/4 v6, 0x7

    move v7, v6

    invoke-interface {v4, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v4, :cond_6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    check-cast v4, Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v3, v4}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    :cond_6
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto/16 :goto_1

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez p1, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 p1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0:Ljava/util/Map;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_3

    :cond_8
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz p1, :cond_9

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    check-cast p1, Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/16 v0, 0x8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->sendAccessibilityEvent(I)V

    :cond_9
    :goto_3
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void
.end method

.method private D(IIII)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p1, p2, p4}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p2, -0x1

    const/4 v1, 0x3

    if-ne p3, p2, :cond_0

    const/4 v0, 0x6

    return p1

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/high16 p4, 0x40000000    # 2.0f

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eq p2, p4, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-nez p1, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    goto :goto_0

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/high16 p1, -0x80000000

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p3, p1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p1

    :cond_2
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p3}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1, p4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p1
.end method

.method private D0(Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q0(I)V

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private P(I)I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x3

    const/4 v4, 0x7

    if-eq p1, v0, :cond_3

    const/4 v0, 0x2

    const/4 v0, 0x4

    move v3, v0

    move v3, v0

    if-eq p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, v0, :cond_1

    const/4 v3, 0x6

    move v4, v3

    const/4 v0, 0x6

    move v4, v0

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    if-ne p1, v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    return p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v2, "  e:gtu fvpoosftaaotlI  idenseot "

    const-string/jumbo v2, "t tfoefonta lIa i v tot dg:speeos"

    const/4 v4, 0x2

    const-string v2, "dag fIlpvt ts ea efono:tts t toip"

    const-string v2, "Invalid state to get top offset: "

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    throw v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return p1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return p1

    :cond_3
    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return p1
.end method

.method private Q()F
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v1, 0x3e8

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->d:F

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/view/VelocityTracker;->getYVelocity(I)F

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v0
.end method

.method private V(Landroid/view/View;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)Z"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/view/ViewParent;->isLayoutRequested()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/core/view/k1;->O0(Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x2

    return p1
.end method

.method private Y(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;",
            "Landroidx/core/view/accessibility/l0$a;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w(I)Landroidx/core/view/accessibility/s0;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, p2, v0, p3}, Landroidx/core/view/k1;->u1(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;Ljava/lang/CharSequence;Landroidx/core/view/accessibility/s0;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private Z()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Landroid/view/View;IZ)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->z0(Landroid/view/View;IZ)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private a0(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;)V
    .locals 6
    .param p1    # Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    move v5, v4

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eq v0, v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    and-int/lit8 v2, v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ne v2, v3, :cond_2

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v2, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;->d:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eq v0, v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int/lit8 v2, v0, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ne v2, v3, :cond_4

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-boolean v2, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;->e:Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v0, v1, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    and-int/lit8 v2, v0, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x4

    const/4 v5, 0x5

    if-ne v2, v3, :cond_6

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-boolean v2, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;->f:Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v0, v1, :cond_7

    const/4 v4, 0x5

    and-int/2addr v5, v4

    const/16 v1, 0x8

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    and-int/2addr v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ne v0, v1, :cond_8

    :cond_7
    const/4 v5, 0x1

    iget-boolean p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;->g:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->I:Z

    :cond_8
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void
.end method

.method static synthetic b(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u:Z

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    return p0
.end method

.method private b0(Landroid/view/View;Ljava/lang/Runnable;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;",
            "Ljava/lang/Runnable;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V(Landroid/view/View;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :goto_0
    const/4 v2, 0x5

    return-void
.end method

.method static synthetic c(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic d(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D0(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic e(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic f(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic g(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)I
    .locals 2

    const/4 v1, 0x0

    iget p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic h(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->I:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic i(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Lcom/google/android/material/shape/j;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v0, 0x6

    const/4 v0, 0x5

    return-object p0
.end method

.method static synthetic j(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic k(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o:Z

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic l(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic m(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v:I

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic n(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic o(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic p(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->s:Z

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic q(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z
    .locals 2

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method private r(Landroid/view/View;II)I
    .locals 3
    .param p2    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;II)I"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w(I)Landroidx/core/view/accessibility/s0;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1, p2, p3}, Landroidx/core/view/k1;->c(Landroid/view/View;Ljava/lang/CharSequence;Landroidx/core/view/accessibility/s0;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p1
.end method

.method private t()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    sub-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    sub-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    :goto_0
    return-void
.end method

.method private t0(Landroid/view/View;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0x1d

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v2, 0x1

    move v3, v2

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->s:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v1, p0, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V

    const/4 v2, 0x1

    const/4 v2, 0x7

    invoke-static {p1, v1}, Lcom/google/android/material/internal/y;->d(Landroid/view/View;Lcom/google/android/material/internal/y$e;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private u()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    int-to-float v0, v0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E:F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    sub-float/2addr v1, v2

    mul-float/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    float-to-int v0, v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method private v()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->g:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->R:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    mul-int/lit8 v2, v2, 0x9

    const/4 v4, 0x1

    const/4 v3, 0x2

    div-int/lit8 v2, v2, 0x10

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    sub-int/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    add-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-lez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-int/2addr v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_1
    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    return v0
.end method

.method private v0()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v1
.end method

.method private w(I)Landroidx/core/view/accessibility/s0;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$e;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$e;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)V

    return-object v0
.end method

.method private x(Landroid/content/Context;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x:Lcom/google/android/material/shape/o;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x:Lcom/google/android/material/shape/o;

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->j:Landroid/content/res/ColorStateList;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Landroid/util/TypedValue;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const v1, 0x1010031

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, v0, Landroid/util/TypedValue;->data:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/shape/j;->setTint(I)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method

.method private y()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array v0, v0, [F

    const/4 v3, 0x4

    move v4, v3

    fill-array-data v0, :array_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x6

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$b;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private z0(Landroid/view/View;IZ)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v3, 0x3

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p3, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1, p1, v0}, Landroidx/customview/widget/d;->V(II)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, p1, p3, v0}, Landroidx/customview/widget/d;->X(Landroid/view/View;II)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B0(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->z:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->c(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_2

    :cond_2
    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    :goto_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method A(I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v0, Landroid/view/View;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-gt p1, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-ne v1, v2, :cond_0

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    sub-int p1, v1, p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    int-to-float p1, p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    sub-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    int-to-float v1, v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x0

    or-int/2addr v4, v3

    sub-int p1, v1, p1

    int-to-float p1, p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    sub-int/2addr v2, v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    int-to-float v1, v2

    :goto_1
    const/4 v4, 0x0

    div-float/2addr p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    shr-int/2addr v4, v1

    :goto_2
    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ge v1, v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v2, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v4, 0x2

    invoke-virtual {v2, v0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;->onSlide(Landroid/view/View;F)V

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_2

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method B(Landroid/view/View;)Landroid/view/View;
    .locals 5
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p1}, Landroidx/core/view/k1;->W0(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    instance-of v0, p1, Landroid/view/ViewGroup;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ge v1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B(Landroid/view/View;)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v2

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p1
.end method

.method public E()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w:I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method public F()F
    .locals 3
    .annotation build Landroidx/annotation/x;
        from = 0.0
        to = 1.0
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E:F

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public G()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    return v0
.end method

.method H()Lcom/google/android/material/shape/j;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public I()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public J()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public K()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method L()I
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->g:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public M()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public N()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->I:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public O()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public R()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public S()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public T()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public U()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method public W()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public X(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)V
    .locals 3
    .param p1    # Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public c0(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)V
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "tmtveoBaqtoBibheSre"

    const-string v0, "BeSrobhtBoemhvtaite"

    const/4 v3, 0x2

    const-string/jumbo v0, "ihsevreBmotettaBohS"

    const-string v0, "BottomSheetBehavior"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "hp muai,vtrtt eee olnhtT(wsnfnhB,`knciya lalobee btrk ai`rcyBelau  leetgnldCSa.tmeitctlows pe rtcti`e eo.ct era`llyiaeenl. au ssainlcbeda)aSa SoSnmss diobenv aaho)eteachteooo o`cicmB(o  uslincnBbscdtior al tiuhsepbery dbabtlaommltx n ih.(tar eroeehha  oh  uB`m elatlln etitysl o etsov rstul kn hPsaw kdusdroknl k)ammhCiulcbvsgsrCngaeuteetys"

    const-string/jumbo v1, "lleta(uivatt elicaneCe pn)csl Ctyeenk bhorlo esBssn e nsausfcmun `r lsl ktT yiwbabgPtktiscl att ayidtoniaa slnna`ypodeei(etBoirets vhme a(bSer xrua,en  tthgvosoukscanot`Ct eweygec`hoS,sdlrm tmiee  rtSdurcccioumkwdtniB e)m rtheeeriln.iurh)e bu da obbamhav d`tek.laics lul.l tlcnhiahopS. saaslohnBtah ara l  o`blooleh yeelasecatlnmtobtBuoeo  "

    const/4 v3, 0x1

    const-string v1, "BottomSheetBehavior now supports multiple callbacks. `setBottomSheetCallback()` removes all existing callbacks, including ones set internally by library authors, which may result in unintended behavior. This may change in the future. Please use `addBottomSheetCallback()` and `removeBottomSheetCallback()` instead to set your own callbacks."

    const/4 v2, 0x7

    move v3, v2

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    return-void
.end method

.method public d0(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v1, 0x1

    return-void
.end method

.method public e0(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ltz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string v0, " tusoqe bp  refnahtto lareet0oufs o grema"

    const-string v0, " fatesepgtern0qbmulttahsooe    tfrauor e "

    const/4 v2, 0x6

    const-string v0, "efes b0r qrt b aaueoet  tanogotlh truf sm"

    const-string/jumbo v0, "offset must be greater than or equal to 0"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v1, 0x4

    throw p1
.end method

.method public f0(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-ne v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t()V

    :cond_1
    const/4 v2, 0x2

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p1, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v2, 0x6

    const/4 v0, 0x6

    const/4 v2, 0x3

    or-int/2addr v1, v0

    const/4 v2, 0x2

    if-ne p1, v0, :cond_2

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A0()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public g0(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n:Z

    const/4 v1, 0x4

    return-void
.end method

.method public h0(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            fromInclusive = false
            to = 1.0
            toInclusive = false
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    cmpg-float v0, p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-lez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v1, 0x7

    const/4 v2, 0x3

    cmpl-float v0, p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-gez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E:F

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, " blt admqanwas o r 0toeettb 1faealein  uuev"

    const/4 v2, 0x0

    const-string/jumbo v0, "l rumnuftanesotl  e atvu ib 1ed e t0eaow ab"

    const-string/jumbo v0, "ratio must be a float value between 0 and 1"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    throw p1
.end method

.method public i0(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v1, 0x1

    move v2, v1

    if-eq v0, p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q0(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A0()V

    :cond_1
    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public j0(Z)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v0, 0x1

    or-int/2addr v1, v0

    return-void
.end method

.method public k0(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public l0(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public m0(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n0(IZ)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public final n0(IZ)V
    .locals 5

    const/4 v4, 0x7

    const/4 v0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eq v0, p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f:Z

    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e:I

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D0(Z)V

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public o0(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public onAttachedToLayoutParams(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onAttachedToLayoutParams(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public onDetachedFromLayoutParams()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-super {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onDetachedFromLayoutParams()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public onInterceptTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 11
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p2}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-eqz v0, :cond_c

    const/4 v10, 0x1

    const/4 v9, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-nez v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto/16 :goto_3

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-nez v0, :cond_1

    const/4 v10, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Z()V

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v10, 0x1

    const/4 v9, 0x1

    if-nez v3, :cond_2

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    iput-object v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    :cond_2
    const/4 v10, 0x6

    iget-object v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v3, p3}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    const/4 v10, 0x1

    const/4 v3, 0x0

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v4, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v5, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v0, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eq v0, v2, :cond_3

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/4 p2, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eq v0, p2, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x2

    goto/16 :goto_2

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Z:Z

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iput v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz p2, :cond_8

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v10, 0x0

    const/4 v9, 0x7

    return v1

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    float-to-int v6, v6

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    float-to-int v7, v7

    const/4 v10, 0x7

    iput v7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y:I

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget v7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eq v7, v5, :cond_6

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v7, :cond_5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v7}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v10, 0x7

    check-cast v7, Landroid/view/View;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    goto :goto_0

    :cond_5
    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v7, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget v8, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y:I

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1, v7, v6, v8}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Landroid/view/View;II)Z

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz v7, :cond_6

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p3, v7}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    iput v7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Z:Z

    :cond_6
    iget v7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-ne v7, v4, :cond_7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p1, p2, v6, v4}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Landroid/view/View;II)Z

    move-result p2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez p2, :cond_7

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    move p2, v2

    move p2, v2

    const/4 v10, 0x1

    move p2, v2

    move p2, v2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    goto :goto_1

    :cond_7
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    move p2, v1

    move p2, v1

    const/4 v10, 0x2

    move p2, v1

    move p2, v1

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    :cond_8
    :goto_2
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez p2, :cond_9

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz p2, :cond_9

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p2, p3}, Landroidx/customview/widget/d;->W(Landroid/view/MotionEvent;)Z

    move-result p2

    const/4 v10, 0x1

    const/4 v9, 0x7

    if-eqz p2, :cond_9

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    return v2

    :cond_9
    const/4 v9, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-eqz p2, :cond_a

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    check-cast v3, Landroid/view/View;

    :cond_a
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-ne v0, v5, :cond_b

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v3, :cond_b

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-nez p2, :cond_b

    const/4 v10, 0x6

    iget p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eq p2, v2, :cond_b

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    move-result p2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    float-to-int p2, p2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    float-to-int v0, v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1, v3, p2, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Landroid/view/View;II)Z

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez p1, :cond_b

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v10, 0x3

    const/4 v9, 0x5

    if-eqz p1, :cond_b

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    int-to-float p1, p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    sub-float/2addr p1, p2

    const/4 v10, 0x7

    const/4 v9, 0x3

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v10, 0x6

    invoke-virtual {p2}, Landroidx/customview/widget/d;->E()I

    move-result p2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    int-to-float p2, p2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    cmpl-float p1, p1, p2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-lez p1, :cond_b

    const/4 v10, 0x3

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    const/4 v10, 0x1

    move v1, v2

    move v1, v2

    :cond_b
    const/4 v10, 0x2

    const/4 v9, 0x1

    return v1

    :cond_c
    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v9, 0x7

    move v10, v9

    return v1
.end method

.method public onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 8
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;I)Z"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p1}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {p2}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p2, v1}, Landroid/view/View;->setFitsSystemWindows(Z)V

    :cond_0
    const/4 v6, 0x6

    move v7, v6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x3

    or-int/2addr v7, v2

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez v0, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    sget v4, Lcom/google/android/material/R$dimen;->design_bottom_sheet_peek_height_min:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v7, 0x2

    iput v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->g:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t0(Landroid/view/View;)V

    const/4 v6, 0x4

    move v7, v6

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v0, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p2, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->G:F

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/high16 v5, -0x40800000    # -1.0f

    const/4 v6, 0x3

    move v7, v6

    cmpl-float v5, v4, v5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v5, :cond_1

    const/4 v6, 0x2

    move v7, v6

    invoke-static {p2}, Landroidx/core/view/k1;->R(Landroid/view/View;)F

    move-result v4

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v4}, Lcom/google/android/material/shape/j;->n0(F)V

    const/4 v6, 0x1

    move v7, v6

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ne v0, v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    move v0, v1

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->y:Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i:Lcom/google/android/material/shape/j;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v4, v0}, Lcom/google/android/material/shape/j;->p0(F)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_2

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->j:Landroid/content/res/ColorStateList;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v0, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p2, v0}, Landroidx/core/view/k1;->J1(Landroid/view/View;Landroid/content/res/ColorStateList;)V

    :cond_5
    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A0()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {p2}, Landroidx/core/view/k1;->V(Landroid/view/View;)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v0, :cond_6

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p2, v1}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-nez v0, :cond_7

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c0:Landroidx/customview/widget/d$c;

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-static {p1, v0}, Landroidx/customview/widget/d;->q(Landroid/view/ViewGroup;Landroidx/customview/widget/d$c;)Landroidx/customview/widget/d;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    :cond_7
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->H(Landroid/view/View;I)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->R:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    sub-int p1, p3, p1

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    iget v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-ge p1, v4, :cond_9

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r:Z

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p1, :cond_8

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    goto :goto_3

    :cond_8
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    sub-int p1, p3, v4

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q:I

    :cond_9
    :goto_3
    const/4 v7, 0x1

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    sub-int/2addr p3, p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-static {v3, p3}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ne p1, v2, :cond_a

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p2, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_4

    :cond_a
    const/4 v7, 0x6

    const/4 p3, 0x6

    const/4 v7, 0x5

    const/4 p3, 0x6

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ne p1, p3, :cond_b

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p2, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v7, 0x3

    goto :goto_4

    :cond_b
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-boolean p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v6, 0x5

    move v7, v6

    if-eqz p3, :cond_c

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 p3, 0x5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne p1, p3, :cond_c

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v6, 0x5

    const/4 v6, 0x0

    invoke-static {p2, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    goto :goto_4

    :cond_c
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 p3, 0x4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ne p1, p3, :cond_d

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v6, 0x6

    const/4 v6, 0x2

    invoke-static {p2, p1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    goto :goto_4

    :cond_d
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eq p1, v1, :cond_e

    const/4 v7, 0x5

    const/4 p3, 0x5

    const/4 v7, 0x6

    const/4 p3, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-ne p1, p3, :cond_f

    :cond_e
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v7, 0x6

    sub-int/2addr v0, p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p2, v0}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    :cond_f
    :goto_4
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance p1, Ljava/lang/ref/WeakReference;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B(Landroid/view/View;)Landroid/view/View;

    move-result-object p3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {p1, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    :goto_5
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ge v3, p1, :cond_10

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    check-cast p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;->onLayout(Landroid/view/View;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_5

    :cond_10
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    return v1
.end method

.method public onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    .locals 5
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;IIII)Z"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    add-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/2addr v1, p4

    const/4 v4, 0x6

    const/4 v3, 0x4

    iget p4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k:I

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, p3, v1, p4, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D(IIII)I

    move-result p3

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result p4

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    add-int/2addr p4, p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/2addr p4, p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/2addr p4, p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    add-int/2addr p4, p6

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget p6, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, p5, p4, p1, p6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D(IIII)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p2, p3, p1}, Landroid/view/View;->measure(II)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    return p1
.end method

.method public onNestedPreFling(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;FF)Z
    .locals 5
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "FF)Z"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    or-int/2addr v4, v1

    const/4 v3, 0x6

    move v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne p3, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ne v0, v2, :cond_0

    const/4 v4, 0x5

    invoke-super/range {p0 .. p5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onNestedPreFling(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;FF)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    :cond_0
    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return v1
.end method

.method public onNestedPreScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;II[II)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p6    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "II[II)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-ne p7, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p4, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p4

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p4, Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p4, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W()Z

    move-result p7

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p7, :cond_2

    const/4 v1, 0x4

    move v2, v1

    if-eq p3, p4, :cond_2

    const/4 v2, 0x5

    return-void

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p4

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sub-int p7, p4, p5

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-lez p5, :cond_5

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-ge p7, p3, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    sub-int/2addr p4, p3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    aput p4, p6, p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    neg-int p3, p4

    const/4 v2, 0x6

    invoke-static {p2, p3}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p3, 0x3

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    invoke-virtual {p0, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto/16 :goto_2

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v1, 0x1

    const/4 v1, 0x1

    if-nez p3, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_4
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    aput p5, p6, p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    neg-int p3, p5

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p2, p3}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_2

    :cond_5
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-gez p5, :cond_9

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v0, -0x4

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p3, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez p3, :cond_9

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-le p7, p3, :cond_7

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-boolean p7, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p7, :cond_6

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_1

    :cond_6
    const/4 v2, 0x7

    const/4 v1, 0x0

    sub-int/2addr p4, p3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    aput p4, p6, p1

    const/4 v2, 0x3

    neg-int p3, p4

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p2, p3}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p3, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_2

    :cond_7
    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p3, :cond_8

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_8
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    aput p5, p6, p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    neg-int p3, p5

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p2, p3}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    :cond_9
    :goto_2
    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A(I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O:I

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public onNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;IIIII[I)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p9    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "IIIII[I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/os/Parcelable;)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/os/Parcelable;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p3}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-super {p0, p1, p2, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/os/Parcelable;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a0(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget p1, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;->c:I

    const/4 v1, 0x2

    move v2, v1

    const/4 p2, 0x0

    const/4 p2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p1, p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-ne p1, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 p1, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Landroid/os/Parcelable;
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;)",
            "Landroid/os/Parcelable;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p1, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$SavedState;-><init>(Landroid/os/Parcelable;Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "Landroid/view/View;",
            "II)Z"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P:Z

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    and-int/lit8 p2, p5, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/4 p1, 0x1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p1
.end method

.method public onStopNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I)V
    .locals 4
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne p1, p4, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x4

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne p3, p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P:Z

    if-nez p1, :cond_2

    :cond_1
    const/4 v3, 0x2

    return-void

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p3, 0x6

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-lez p1, :cond_4

    const/4 v3, 0x7

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto/16 :goto_2

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget p4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-le p1, p4, :cond_d

    const/4 v3, 0x3

    const/4 v2, 0x4

    goto/16 :goto_1

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v3, 0x0

    if-eqz p1, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Q()F

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p2, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w0(Landroid/view/View;F)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eqz p1, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto/16 :goto_2

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p4, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p1, :cond_9

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    sub-int p3, p1, p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    sub-int/2addr p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ge p3, p1, :cond_a

    const/4 v3, 0x5

    const/4 v2, 0x2

    goto/16 :goto_2

    :cond_6
    const/4 v3, 0x1

    const/4 v2, 0x1

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    if-ge p1, v1, :cond_8

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sub-int v1, p1, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ge p1, v1, :cond_7

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_2

    :cond_7
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x0()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-eqz p1, :cond_c

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_8
    const/4 v3, 0x5

    const/4 v2, 0x5

    sub-int v0, p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sub-int/2addr p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ge v0, p1, :cond_a

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_1

    :cond_9
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p1, :cond_b

    :cond_a
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    move v0, p4

    move v0, p4

    const/4 v3, 0x3

    move v0, p4

    const/4 v2, 0x6

    move v3, v2

    goto :goto_2

    :cond_b
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    sub-int v0, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sub-int/2addr p1, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ge v0, p1, :cond_a

    :cond_c
    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    move v0, p3

    move v0, p3

    const/4 v3, 0x7

    move v0, p3

    move v0, p3

    :cond_d
    :goto_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, p2, v0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->z0(Landroid/view/View;IZ)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public onTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 4
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2}, Landroid/view/View;->isShown()Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x0

    xor-int/2addr v3, p1

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    if-ne v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v0()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p3}, Landroidx/customview/widget/d;->M(Landroid/view/MotionEvent;)V

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez p1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Z()V

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v3, 0x5

    if-nez v0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->W:Landroid/view/VelocityTracker;

    const/4 v3, 0x6

    invoke-virtual {v0, p3}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v0()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne p1, v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_5

    const/4 v2, 0x1

    move v3, v2

    iget p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Y:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    int-to-float p1, p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    sub-float/2addr p1, v0

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/customview/widget/d;->E()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    int-to-float v0, v0

    const/4 v3, 0x3

    cmpl-float p1, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-lez p1, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p3, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, p2, p3}, Landroidx/customview/widget/d;->d(Landroid/view/View;I)V

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->N:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    xor-int/2addr p1, v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return p1
.end method

.method public p0(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->I:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public q0(I)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eq p1, v0, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-ne p1, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto/16 :goto_3

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v0, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne p1, v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    move v5, v4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v1, "n teCt:paats stos "

    const-string/jumbo v1, "n s eaCo:t tttessa"

    const/4 v5, 0x6

    const-string v1, "e t  aosqteantnCt:"

    const-string v1, "Cannot set state: "

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const-string v0, "ehsBrtoiShtmoBaevot"

    const-string/jumbo v0, "mttmoeahvoioSBBreht"

    const/4 v5, 0x5

    const-string v0, "eSBmhtvrotmiooteeBh"

    const-string v0, "BottomSheetBehavior"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x7

    const/4 v0, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ne p1, v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b:Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->P(I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-gt v0, v1, :cond_2

    const/4 v5, 0x2

    const/4 v0, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    if-eqz v1, :cond_4

    const/4 v4, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast p1, Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$a;

    invoke-direct {v1, p0, p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$a;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Landroid/view/View;I)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0, p1, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b0(Landroid/view/View;Ljava/lang/Runnable;)V

    const/4 v5, 0x5

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :cond_5
    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const-string v3, "AE_Soo"

    const-string v3, "SAT_oE"

    const/4 v5, 0x0

    const-string v3, "_STETb"

    const-string v3, "STATE_"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ne p1, v0, :cond_6

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p1, "RGbNIAuG"

    const-string p1, "GNGIAbGR"

    const/4 v5, 0x7

    const-string p1, "NGGARDIp"

    const-string p1, "DRAGGING"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_4

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo p1, "quTSGNIT"

    const-string p1, "NTISGLuT"

    const/4 v5, 0x4

    const-string p1, "EIsLGSTN"

    const-string p1, "SETTLING"

    :goto_4
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string p1, "asdmp l oney etlo. bhteurn sel"

    const-string/jumbo p1, "tlauxnop e  ylstnl eesoh br.ed"

    const-string/jumbo p1, "oebuotx shatoernyeltd nsel l  "

    const-string p1, " should not be set externally."

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v1, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw v1
.end method

.method r0(I)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ne v0, p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v0, 0x5

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x6

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v2, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v3, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eq p1, v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eq p1, v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    if-eq p1, v1, :cond_1

    const/4 v7, 0x0

    iget-boolean v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v4, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ne p1, v0, :cond_2

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L:I

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v4, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast v4, Landroid/view/View;

    const/4 v7, 0x1

    if-nez v4, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    return-void

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne p1, v2, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v0, 0x1

    shl-int/2addr v7, v0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C0(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eq p1, v1, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eq p1, v0, :cond_6

    if-ne p1, v3, :cond_7

    :cond_6
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {p0, v5}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C0(Z)V

    :cond_7
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->B0(I)V

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ge v5, v0, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    check-cast v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v4, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;->onStateChanged(Landroid/view/View;I)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_1

    :cond_8
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A0()V

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-void
.end method

.method public s(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)V
    .locals 3
    .param p1    # Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->V:Ljava/util/ArrayList;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public s0(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c:Z

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public u0(JF)Z
    .locals 2
    .param p3    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 100.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method w0(Landroid/view/View;F)Z
    .locals 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->I:Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ge v0, v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v3

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    int-to-float p1, p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const v2, 0x3dcccccd    # 0.1f

    const/4 v5, 0x6

    const/4 v4, 0x3

    mul-float/2addr p2, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-float/2addr p1, p2

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    int-to-float p2, p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    sub-float/2addr p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    int-to-float p2, v0

    const/4 v4, 0x2

    const/4 v5, 0x4

    div-float/2addr p1, p2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/high16 p2, 0x3f000000    # 0.5f

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    cmpl-float p1, p1, p2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-lez p1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    move v1, v3

    move v1, v3

    const/4 v5, 0x2

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v1
.end method

.method public x0()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public y0()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public z()V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    or-int/2addr v2, v1

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A:Landroid/animation/ValueAnimator;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
