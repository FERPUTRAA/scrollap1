.class Lcom/google/android/material/bottomsheet/a$c;
.super Landroidx/core/view/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomsheet/a;->r(ILandroid/view/View;Landroid/view/ViewGroup$LayoutParams;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomsheet/a;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomsheet/a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/a$c;->a:Lcom/google/android/material/bottomsheet/a;

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/core/view/a;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V
    .locals 2
    .param p2    # Landroidx/core/view/accessibility/l0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Landroidx/core/view/a;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a$c;->a:Lcom/google/android/material/bottomsheet/a;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget-boolean p1, p1, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/high16 p1, 0x100000

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->a(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->d1(Z)V

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->d1(Z)V

    :goto_0
    const/4 v1, 0x1

    return-void
.end method

.method public performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 4

    const/4 v3, 0x4

    const/high16 v0, 0x100000

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne p2, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a$c;->a:Lcom/google/android/material/bottomsheet/a;

    const/4 v3, 0x7

    iget-boolean v1, v0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/a;->cancel()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-super {p0, p1, p2, p3}, Landroidx/core/view/a;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return p1
.end method
