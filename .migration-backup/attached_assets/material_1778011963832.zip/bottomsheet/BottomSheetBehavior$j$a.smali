.class Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "t s@~u@~o b@~ad~ ~@l~o@n@oi~@io. f ~~b@ m~f ~~S  ~@@b~o@ @s@l -~@@ ~~o@~@4K@~M @  r~1~y/c~ti  /@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->a(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;Z)Z

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v5, 0x7

    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->M:Landroidx/customview/widget/d;

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroidx/customview/widget/d;->o(Z)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-static {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->b(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->c(I)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;->a:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v2, v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne v2, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->b(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method
