.class Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "j"
.end annotation


# instance fields
.field private a:I

.field private b:Z

.field private final c:Ljava/lang/Runnable;

.field final synthetic d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method private constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j$a;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->c:Ljava/lang/Runnable;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Lcom/google/android/material/bottomsheet/BottomSheetBehavior$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;-><init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->b:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic b(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;)I
    .locals 2

    const/4 v1, 0x5

    iget p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p0
.end method


# virtual methods
.method c(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->b:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->d:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p1, Landroid/view/View;

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->c:Ljava/lang/Runnable;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$j;->b:Z

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
