.class public Lcom/google/android/material/bottomsheet/a;
.super Landroidx/appcompat/app/l;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/bottomsheet/a$f;
    }
.end annotation


# instance fields
.field private c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/bottomsheet/BottomSheetBehavior<",
            "Landroid/widget/FrameLayout;",
            ">;"
        }
    .end annotation
.end field

.field private d:Landroid/widget/FrameLayout;

.field private e:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

.field private f:Landroid/widget/FrameLayout;

.field g:Z

.field h:Z

.field private i:Z

.field private j:Z

.field private k:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

.field private l:Z

.field private m:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/bottomsheet/a;-><init>(Landroid/content/Context;I)V

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget v1, Lcom/google/android/material/R$attr;->enableEdgeToEdge:I

    const/4 v3, 0x1

    filled-new-array {v1}, [I

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/android/material/bottomsheet/a;->c(Landroid/content/Context;I)I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/app/l;-><init>(Landroid/content/Context;I)V

    const/4 v1, 0x7

    const/4 p1, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v0, 0x4

    or-int/2addr v1, v0

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->i:Z

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p2, Lcom/google/android/material/bottomsheet/a$e;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p2, p0}, Lcom/google/android/material/bottomsheet/a$e;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/bottomsheet/a;->m:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/app/l;->e(I)Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    sget p2, Lcom/google/android/material/R$attr;->enableEdgeToEdge:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 p2, 0x0

    move v1, p2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p2, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method protected constructor <init>(Landroid/content/Context;ZLandroid/content/DialogInterface$OnCancelListener;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/app/l;-><init>(Landroid/content/Context;ZLandroid/content/DialogInterface$OnCancelListener;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->i:Z

    const/4 v0, 0x1

    new-instance p3, Lcom/google/android/material/bottomsheet/a$e;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p3, p0}, Lcom/google/android/material/bottomsheet/a$e;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p3, p0, Lcom/google/android/material/bottomsheet/a;->m:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/app/l;->e(I)Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    sget p2, Lcom/google/android/material/R$attr;->enableEdgeToEdge:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p2, p2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method private static c(Landroid/content/Context;I)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p1, Landroid/util/TypedValue;

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    invoke-direct {p1}, Landroid/util/TypedValue;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget v0, Lcom/google/android/material/R$attr;->bottomSheetDialogTheme:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v1, 0x1

    or-int/2addr v3, v1

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v0, p1, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget p1, p1, Landroid/util/TypedValue;->resourceId:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget p1, Lcom/google/android/material/R$style;->Theme_Design_Light_BottomSheetDialog:I

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1
.end method

.method static synthetic f(Lcom/google/android/material/bottomsheet/a;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
    .locals 2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/bottomsheet/a;->k:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic g(Lcom/google/android/material/bottomsheet/a;Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/a;->k:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic h(Lcom/google/android/material/bottomsheet/a;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic i(Lcom/google/android/material/bottomsheet/a;)Landroid/widget/FrameLayout;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method private j()Landroid/widget/FrameLayout;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v4, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget v1, Lcom/google/android/material/R$layout;->design_bottom_sheet_dialog:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x0

    and-int/2addr v4, v2

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v0, Landroid/widget/FrameLayout;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget v1, Lcom/google/android/material/R$id;->coordinator:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/a;->e:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v4, 0x6

    const/4 v3, 0x0

    sget v1, Lcom/google/android/material/R$id;->design_bottom_sheet:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast v0, Landroid/widget/FrameLayout;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C(Landroid/view/View;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/a;->m:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->s(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)V

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i0(Z)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v0
.end method

.method public static p(Landroid/view/View;Z)V
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    or-int/lit16 p1, v0, 0x2000

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    and-int/lit16 p1, v0, -0x2001

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/4 v1, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private r(ILandroid/view/View;Landroid/view/ViewGroup$LayoutParams;)Landroid/view/View;
    .locals 4
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/a;->j()Landroid/widget/FrameLayout;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v1, Lcom/google/android/material/R$id;->coordinator:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/app/Dialog;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p2, p1, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/material/bottomsheet/a$a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/google/android/material/bottomsheet/a$a;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, v1}, Landroidx/core/view/k1;->a2(Landroid/view/View;Landroidx/core/view/z0;)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v3, 0x1

    if-nez p3, :cond_2

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget p1, Lcom/google/android/material/R$id;->touch_outside:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p2, Lcom/google/android/material/bottomsheet/a$b;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p2, p0}, Lcom/google/android/material/bottomsheet/a$b;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    new-instance p2, Lcom/google/android/material/bottomsheet/a$c;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p2, p0}, Lcom/google/android/material/bottomsheet/a$c;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v3, 0x6

    invoke-static {p1, p2}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->f:Landroid/widget/FrameLayout;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p2, Lcom/google/android/material/bottomsheet/a$d;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p2, p0}, Lcom/google/android/material/bottomsheet/a$d;-><init>(Lcom/google/android/material/bottomsheet/a;)V

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1
.end method


# virtual methods
.method public cancel()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/bottomsheet/a;->k()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/a;->g:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne v1, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q0(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-super {p0}, Landroid/app/Dialog;->cancel()V

    :goto_1
    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public k()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/bottomsheet/BottomSheetBehavior<",
            "Landroid/widget/FrameLayout;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/a;->j()Landroid/widget/FrameLayout;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->g:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method n()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/a;->m:Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X(Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public o(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->g:Z

    const/4 v1, 0x6

    return-void
.end method

.method public onAttachedToWindow()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-super {p0}, Landroid/app/Dialog;->onAttachedToWindow()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/a;->l:Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/Window;->getNavigationBarColor()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1}, Landroid/graphics/Color;->alpha(I)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/16 v2, 0xff

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-ge v1, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/a;->d:Landroid/widget/FrameLayout;

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    xor-int/lit8 v3, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Landroid/view/View;->setFitsSystemWindows(Z)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/a;->e:Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    xor-int/lit8 v3, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2, v3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->setFitsSystemWindows(Z)V

    :cond_2
    const/4 v5, 0x6

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v1, 0x300

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/app/l;->onCreate(Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/high16 v0, -0x80000000

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setLayout(II)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method protected onStart()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->O()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q0(I)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method q()Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->j:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const v1, 0x101035b

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    filled-new-array {v1}, [I

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    move v4, v3

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean v1, p0, Lcom/google/android/material/bottomsheet/a;->i:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-boolean v2, p0, Lcom/google/android/material/bottomsheet/a;->j:Z

    :cond_0
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->i:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v0
.end method

.method public setCancelable(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/app/Dialog;->setCancelable(Z)V

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v1, 0x6

    move v2, v1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/a;->c:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->i0(Z)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public setCanceledOnTouchOutside(Z)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-super {p0, p1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x2

    move v2, v0

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-boolean v1, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->h:Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a;->i:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/google/android/material/bottomsheet/a;->j:Z

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public setContentView(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0, v0}, Lcom/google/android/material/bottomsheet/a;->r(ILandroid/view/View;Landroid/view/ViewGroup$LayoutParams;)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/app/l;->setContentView(Landroid/view/View;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, v0, p1, v1}, Lcom/google/android/material/bottomsheet/a;->r(ILandroid/view/View;Landroid/view/ViewGroup$LayoutParams;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/app/l;->setContentView(Landroid/view/View;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1, p2}, Lcom/google/android/material/bottomsheet/a;->r(ILandroid/view/View;Landroid/view/ViewGroup$LayoutParams;)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroidx/appcompat/app/l;->setContentView(Landroid/view/View;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method
