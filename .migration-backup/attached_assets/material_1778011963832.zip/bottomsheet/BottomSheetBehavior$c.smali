.class Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t0(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->a:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "/~sv~@a tib@on  @y@~K@i1/ ~@@ ot@o~@br 4~~ ~~@~~~@~ ~ s olcufo~i   l~o .@~- @m ~ ~@@~~@M@@dS@~bf"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x5

    invoke-static {}, Landroidx/core/view/y2$m;->i()I

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p2, v0}, Landroidx/core/view/y2;->f(I)Landroidx/core/graphics/g0;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {}, Landroidx/core/view/y2$m;->f()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {p2, v1}, Landroidx/core/view/y2;->f(I)Landroidx/core/graphics/g0;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x5

    iget v3, v0, Landroidx/core/graphics/g0;->b:I

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v2, v3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->j(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I

    const/4 v11, 0x4

    invoke-static {p1}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v6, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-eqz v6, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->o()I

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {v3, v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget v3, p3, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object v6, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-static {v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->l(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)I

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    add-int/2addr v3, v6

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object v6, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x1

    invoke-static {v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->n(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v6

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v6, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v2, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget v4, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_0

    :cond_1
    const/4 v11, 0x1

    iget v4, p3, Lcom/google/android/material/internal/y$f;->a:I

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v6, v0, Landroidx/core/graphics/g0;->a:I

    const/4 v11, 0x1

    add-int/2addr v4, v6

    :cond_2
    const/4 v11, 0x5

    iget-object v6, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v6

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz v6, :cond_4

    const/4 v11, 0x1

    if-eqz v2, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget p3, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v10, 0x0

    goto :goto_1

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x3

    iget p3, p3, Lcom/google/android/material/internal/y$f;->c:I

    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget v2, v0, Landroidx/core/graphics/g0;->c:I

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    add-int v5, p3, v2

    :cond_4
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p3

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    check-cast p3, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x7

    if-eqz v2, :cond_5

    const/4 v11, 0x1

    iget v2, p3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget v8, v0, Landroidx/core/graphics/g0;->a:I

    const/4 v11, 0x0

    if-eq v2, v8, :cond_5

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    iput v8, p3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    move v2, v7

    move v2, v7

    const/4 v11, 0x5

    goto :goto_2

    :cond_5
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v2, v6

    move v2, v6

    const/4 v11, 0x5

    move v2, v6

    move v2, v6

    :goto_2
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object v8, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-static {v8}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v8, :cond_6

    const/4 v10, 0x1

    move v11, v10

    iget v8, p3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget v9, v0, Landroidx/core/graphics/g0;->c:I

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eq v8, v9, :cond_6

    const/4 v11, 0x6

    iput v9, p3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    move v2, v7

    move v2, v7

    const/4 v11, 0x2

    move v2, v7

    move v2, v7

    :cond_6
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-object v8, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v8}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->b(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result v8

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v8, :cond_7

    const/4 v11, 0x2

    const/4 v10, 0x3

    iget v8, p3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget v0, v0, Landroidx/core/graphics/g0;->b:I

    const/4 v11, 0x1

    const/4 v10, 0x0

    if-eq v8, v0, :cond_7

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    iput v0, p3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_3

    :cond_7
    const/4 v10, 0x7

    const/4 v10, 0x1

    move v7, v2

    move v7, v2

    const/4 v11, 0x7

    move v7, v2

    move v7, v2

    :goto_3
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v7, :cond_8

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p1, p3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_8
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result p3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p1, v4, p3, v5, v3}, Landroid/view/View;->setPadding(IIII)V

    const/4 v10, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->a:Z

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz p1, :cond_9

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v10, 0x7

    iget p3, v1, Landroidx/core/graphics/g0;->d:I

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {p1, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->c(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;I)I

    :cond_9
    const/4 v11, 0x3

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->k(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-nez p1, :cond_a

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-boolean p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->a:Z

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-eqz p1, :cond_b

    :cond_a
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$c;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {p1, v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->d(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V

    :cond_b
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    return-object p2
.end method
