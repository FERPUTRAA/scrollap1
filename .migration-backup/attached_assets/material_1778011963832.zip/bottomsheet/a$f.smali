.class Lcom/google/android/material/bottomsheet/a$f;
.super Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomsheet/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "f"
.end annotation


# instance fields
.field private final a:Z

.field private final b:Z

.field private final c:Landroidx/core/view/y2;


# direct methods
.method private constructor <init>(Landroid/view/View;Landroidx/core/view/y2;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$f;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/android/material/bottomsheet/a$f;->c:Landroidx/core/view/y2;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    and-int/lit16 p2, p2, 0x2000

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/a$f;->b:Z

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C(Landroid/view/View;)Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->y()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Landroidx/core/view/k1;->N(Landroid/view/View;)Landroid/content/res/ColorStateList;

    move-result-object v0

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/android/material/color/s;->k(I)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a$f;->a:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_2

    :cond_2
    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    instance-of v0, v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/color/s;->k(I)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/bottomsheet/a$f;->a:Z

    goto :goto_2

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/google/android/material/bottomsheet/a$f;->a:Z

    :goto_2
    const/4 v2, 0x1

    return-void
.end method

.method synthetic constructor <init>(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/bottomsheet/a$a;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/bottomsheet/a$f;-><init>(Landroid/view/View;Landroidx/core/view/y2;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private a(Landroid/view/View;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  sf@ o@@l~. @o  ~@tr@Ko~ ~Sa@d ~st ~ ~b~y  @~/~@M~ ~@~@~f~@@oio~cvi/ ~m@ b~4@@@n~~u l@~1i@ -b~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/a$f;->c:Landroidx/core/view/y2;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroidx/core/view/y2;->r()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v0, v1, :cond_0

    const/4 v5, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a$f;->a:Z

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p1, v0}, Lcom/google/android/material/bottomsheet/a;->p(Landroid/view/View;Z)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/a$f;->c:Landroidx/core/view/y2;

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroidx/core/view/y2;->r()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    sub-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/view/View;->setPadding(IIII)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/bottomsheet/a$f;->b:Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lcom/google/android/material/bottomsheet/a;->p(Landroid/view/View;Z)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1, v0, v3, v1, v2}, Landroid/view/View;->setPadding(IIII)V

    :cond_1
    :goto_0
    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method onLayout(Landroid/view/View;)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/a$f;->a(Landroid/view/View;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public onSlide(Landroid/view/View;F)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/a$f;->a(Landroid/view/View;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public onStateChanged(Landroid/view/View;I)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/a$f;->a(Landroid/view/View;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method
