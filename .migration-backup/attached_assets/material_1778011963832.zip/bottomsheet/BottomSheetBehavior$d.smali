.class Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;
.super Landroidx/customview/widget/d$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomsheet/BottomSheetBehavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:J

.field final synthetic b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/customview/widget/d$c;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method private n(Landroid/view/View;)Z
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-@s~~@~ui@~f~ @b~mK~ ~oi@ ot@i ra  o@Mb~ ~/@o @@vt/@~@~4@ ~Slc  f @@~~b.ooyl~n~~~ ~@d1~@ s@   @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-le p1, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 p1, 0x1

    shr-int/2addr v3, p1

    const/4 v2, 0x4

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return p1
.end method


# virtual methods
.method public a(Landroid/view/View;II)I
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1
.end method

.method public b(Landroid/view/View;II)I
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-boolean v0, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p2, p1, p3}, Lo/a;->e(III)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p1
.end method

.method public e(Landroid/view/View;)I
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget p1, p1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v2, 0x3

    return p1
.end method

.method public j(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->e(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->r0(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public k(Landroid/view/View;IIII)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->A(I)V

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    return-void
.end method

.method public l(Landroid/view/View;FF)V
    .locals 9
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    cmpg-float v1, p3, v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v2, 0x6

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v3, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v4, 0x4

    const/4 v8, 0x4

    if-gez v1, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz p2, :cond_1

    :cond_0
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    move v2, v3

    move v2, v3

    const/4 v8, 0x6

    move v2, v3

    move v2, v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-wide v5, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->a:J

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    sub-long/2addr v0, v5

    const/4 v8, 0x5

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x0()Z

    move-result p3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-eqz p3, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    int-to-float p2, p2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/high16 p3, 0x42c80000    # 100.0f

    const/4 v7, 0x7

    move v8, v7

    mul-float/2addr p2, p3

    const/4 v8, 0x1

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x7

    const/4 v7, 0x1

    iget v2, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->S:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    int-to-float v2, v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    div-float/2addr p2, v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p3, v0, v1, p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u0(JF)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p2, :cond_a

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-le p2, p3, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    goto/16 :goto_3

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-boolean v5, v1, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->H:Z

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v5, :cond_8

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    invoke-virtual {v1, p1, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w0(Landroid/view/View;F)Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v1, :cond_8

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result p2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    cmpg-float p2, p2, v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-gez p2, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/high16 p2, 0x43fa0000    # 500.0f

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    cmpl-float p2, p3, p2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-gtz p2, :cond_5

    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->n(Landroid/view/View;)Z

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz p2, :cond_6

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v2, 0x5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    goto/16 :goto_3

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz p2, :cond_7

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_7
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->E()I

    move-result p3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    sub-int/2addr p2, p3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    sub-int/2addr p3, v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ge p2, p3, :cond_10

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto/16 :goto_0

    :cond_8
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    cmpl-float v0, p3, v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v0, :cond_c

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    cmpl-float p2, p2, p3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-lez p2, :cond_9

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    goto :goto_2

    :cond_9
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz p2, :cond_b

    :cond_a
    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    move v2, v4

    move v2, v4

    const/4 v8, 0x7

    move v2, v4

    move v2, v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto/16 :goto_3

    :cond_b
    const/4 v8, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v7, 0x2

    move v8, v7

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    sub-int p3, p2, p3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    sub-int/2addr p2, v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ge p3, p2, :cond_a

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x0()Z

    move-result p2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz p2, :cond_10

    const/4 v8, 0x0

    goto :goto_1

    :cond_c
    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->f(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;)Z

    move-result p3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz p3, :cond_d

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->C:I

    const/4 v8, 0x5

    sub-int p3, p2, p3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x0

    iget v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    sub-int/2addr p2, v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge p3, p2, :cond_a

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto/16 :goto_0

    :cond_d
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object p3, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget v0, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->D:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ge p2, v0, :cond_f

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget p3, p3, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    sub-int p3, p2, p3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ge p2, p3, :cond_e

    const/4 v8, 0x1

    const/4 v7, 0x0

    goto/16 :goto_0

    :cond_e
    const/4 v8, 0x5

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x0()Z

    move-result p2

    const/4 v8, 0x5

    const/4 v7, 0x1

    if-eqz p2, :cond_10

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto/16 :goto_1

    :cond_f
    const/4 v8, 0x5

    sub-int p3, p2, v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {p3}, Ljava/lang/Math;->abs(I)I

    move-result p3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x2

    const/4 v7, 0x1

    iget v0, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->F:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    sub-int/2addr p2, v0

    const/4 v7, 0x0

    move v8, v7

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-ge p3, p2, :cond_a

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->x0()Z

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz p2, :cond_10

    const/4 v7, 0x6

    const/4 v8, 0x0

    goto/16 :goto_1

    :cond_10
    :goto_3
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-virtual {p2}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->y0()Z

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p2, p1, v2, p3}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->a(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Landroid/view/View;IZ)V

    const/4 v8, 0x7

    return-void
.end method

.method public m(Landroid/view/View;I)Z
    .locals 7
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ne v1, v3, :cond_0

    const/4 v6, 0x7

    return v2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-boolean v4, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->Z:Z

    const/4 v6, 0x7

    if-eqz v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    return v2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v4, 0x3

    const/4 v6, 0x0

    if-ne v1, v4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v1, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->X:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ne v1, p2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object p2, v0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->U:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz p2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    check-cast p2, Landroid/view/View;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 p2, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz p2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p2, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz p2, :cond_3

    const/4 v5, 0x5

    move v6, v5

    return v2

    :cond_3
    const/4 v6, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    iput-wide v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->a:J

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior$d;->b:Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p2, p2, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->T:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz p2, :cond_4

    const/4 v6, 0x4

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x5

    if-ne p2, p1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    move v2, v3

    move v2, v3

    const/4 v6, 0x3

    move v2, v3

    move v2, v3

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    return v2
.end method
