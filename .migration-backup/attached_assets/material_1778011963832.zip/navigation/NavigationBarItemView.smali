.class public abstract Lcom/google/android/material/navigation/NavigationBarItemView;
.super Landroid/widget/FrameLayout;

# interfaces
.implements Landroidx/appcompat/view/menu/o$a;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/navigation/NavigationBarItemView$e;,
        Lcom/google/android/material/navigation/NavigationBarItemView$d;
    }
.end annotation


# static fields
.field private static final C:I = -0x1

.field private static final D:[I

.field private static final E:Lcom/google/android/material/navigation/NavigationBarItemView$d;

.field private static final F:Lcom/google/android/material/navigation/NavigationBarItemView$d;


# instance fields
.field private A:I

.field private B:Lcom/google/android/material/badge/a;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private a:Z

.field private b:I

.field private c:I

.field private d:F

.field private e:F

.field private f:F

.field private g:I

.field private h:Z

.field private final i:Landroid/widget/FrameLayout;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final j:Landroid/view/View;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final k:Landroid/widget/ImageView;

.field private final l:Landroid/view/ViewGroup;

.field private final m:Landroid/widget/TextView;

.field private final n:Landroid/widget/TextView;

.field private o:I

.field private p:Landroidx/appcompat/view/menu/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private q:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private r:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private s:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private t:Landroid/animation/ValueAnimator;

.field private u:Lcom/google/android/material/navigation/NavigationBarItemView$d;

.field private v:F

.field private w:Z

.field private x:I

.field private y:I

.field private z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const v0, 0x10100a0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->D:[I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView$d;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView$a;)V

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->E:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/material/navigation/NavigationBarItemView$e;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView$e;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView$a;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->F:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x3

    move v7, v6

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x4

    const/4 v0, 0x6

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->a:Z

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v1, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->o:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v1, Lcom/google/android/material/navigation/NavigationBarItemView;->E:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->u:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x2

    move v7, v6

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->v:F

    const/4 v6, 0x0

    move v7, v6

    iput-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->w:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->x:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->y:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->z:Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->A:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getItemLayoutResId()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1, v0, p0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget p1, Lcom/google/android/material/R$id;->navigation_bar_item_icon_container:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    check-cast p1, Landroid/widget/FrameLayout;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->i:Landroid/widget/FrameLayout;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget p1, Lcom/google/android/material/R$id;->navigation_bar_item_active_indicator_view:I

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget p1, Lcom/google/android/material/R$id;->navigation_bar_item_icon_view:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    check-cast p1, Landroid/widget/ImageView;

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget v0, Lcom/google/android/material/R$id;->navigation_bar_item_labels_group:I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget v2, Lcom/google/android/material/R$id;->navigation_bar_item_small_label_view:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    check-cast v2, Landroid/widget/TextView;

    const/4 v7, 0x3

    const/4 v6, 0x7

    iput-object v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget v3, Lcom/google/android/material/R$id;->navigation_bar_item_large_label_view:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    check-cast v3, Landroid/widget/TextView;

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    iput-object v3, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getItemBackgroundResId()I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0, v4}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getItemDefaultMarginResId()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    iput v4, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getPaddingBottom()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x6

    const/4 v6, 0x5

    invoke-static {v2, v0}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v3, v0}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0, v1}, Landroid/view/View;->setFocusable(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3}, Landroid/widget/TextView;->getTextSize()F

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0, v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->i(FF)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Lcom/google/android/material/navigation/NavigationBarItemView$a;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/material/navigation/NavigationBarItemView$a;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/navigation/NavigationBarItemView;)Landroid/widget/ImageView;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ros~i~@~  n~   tl ~@ @bM@~o~~1/~@@  @o~i @fi@ou@o~~~.d@ f~b@  lb@~c@/y~~4 t@ -@am ~~@@~K~o~vs @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/navigation/NavigationBarItemView;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->w(Landroid/view/View;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic e(Lcom/google/android/material/navigation/NavigationBarItemView;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->x(I)V

    const/4 v1, 0x0

    return-void
.end method

.method private getIconOrContainer()Landroid/view/View;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->i:Landroid/widget/FrameLayout;

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method private getItemVisiblePosition()I
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-ge v2, v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    instance-of v5, v4, Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz v5, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    return v3
.end method

.method private getSuggestedIconHeight()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    div-int/lit8 v0, v0, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    add-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    add-int/2addr v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    return v1
.end method

.method private getSuggestedIconWidth()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/android/material/badge/a;->q()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    sub-int/2addr v0, v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v2, v1, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredWidth()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    add-int/2addr v2, v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v2
.end method

.method static synthetic h(Lcom/google/android/material/navigation/NavigationBarItemView;FF)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->q(FF)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private i(FF)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    sub-float v0, p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->d:F

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    mul-float v1, p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    div-float/2addr v1, p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->e:F

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    mul-float/2addr p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    div-float/2addr p1, p2

    const/4 v2, 0x4

    move v3, v2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->f:F

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method private k(Landroid/view/View;)Landroid/widget/FrameLayout;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    if-ne p1, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-boolean p1, Lcom/google/android/material/badge/e;->a:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v1, Landroid/widget/FrameLayout;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v1
.end method

.method private l()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v1, 0x2

    or-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method private m()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->z:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->g:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return v0
.end method

.method private n(F)V
    .locals 6
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->w:Z

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->a:Z

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p0}, Landroidx/core/view/k1;->O0(Landroid/view/View;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-array v0, v0, [F

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->v:F

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    aput v2, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    aput p1, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Lcom/google/android/material/navigation/NavigationBarItemView$c;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1, p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView$c;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView;F)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget v1, Lcom/google/android/material/R$attr;->motionEasingStandard:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v2, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v1, v2}, Lv4/a;->e(Landroid/content/Context;ILandroid/animation/TimeInterpolator;)Landroid/animation/TimeInterpolator;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget v1, Lcom/google/android/material/R$attr;->motionDurationLong1:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget v3, Lcom/google/android/material/R$integer;->material_motion_duration_long_1:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0, v1, v2}, Lv4/a;->d(Landroid/content/Context;II)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    int-to-long v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->t:Landroid/animation/ValueAnimator;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v4, 0x0

    move v5, v4

    return-void

    :cond_2
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0, p1, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->q(FF)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method

.method private o()V
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->isChecked()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->setChecked(Z)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method private q(FF)V
    .locals 4
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->u:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, p1, p2, v0}, Lcom/google/android/material/navigation/NavigationBarItemView$d;->d(FFLandroid/view/View;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->v:F

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method private static r(Landroid/widget/TextView;I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1}, Landroidx/core/widget/q;->E(Landroid/widget/TextView;I)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    invoke-static {v0, p1, v1}, Lcom/google/android/material/resources/c;->h(Landroid/content/Context;II)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    int-to-float p1, p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v1, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private static s(Landroid/view/View;FFI)V
    .locals 2
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->setScaleX(F)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p2}, Landroid/view/View;->setScaleY(F)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-virtual {p0, p3}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private static t(Landroid/view/View;II)V
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x7

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    const/4 v2, 0x6

    iput p2, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private u(Landroid/view/View;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->l()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->k(Landroid/view/View;)Landroid/widget/FrameLayout;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, p1, v1}, Lcom/google/android/material/badge/e;->d(Lcom/google/android/material/badge/a;Landroid/view/View;Landroid/widget/FrameLayout;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private v(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->l()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/google/android/material/badge/e;->j(Lcom/google/android/material/badge/a;Landroid/view/View;)V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private w(Landroid/view/View;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->l()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->k(Landroid/view/View;)Landroid/widget/FrameLayout;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, p1, v1}, Lcom/google/android/material/badge/e;->m(Lcom/google/android/material/badge/a;Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method private x(I)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->x:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->A:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    sub-int/2addr p1, v1

    const/4 v3, 0x2

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->m()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    move v1, p1

    move v1, p1

    const/4 v3, 0x3

    move v1, p1

    move v1, p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->y:I

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x4

    return-void
.end method

.method private y()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->m()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    sget-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->F:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->u:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->E:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    const/4 v1, 0x6

    move v2, v1

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->u:Lcom/google/android/material/navigation/NavigationBarItemView$d;

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method private static z(Landroid/view/View;I)V
    .locals 5
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v0, v1, v2, p1}, Landroid/view/View;->setPadding(IIII)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method public b(ZC)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-void
.end method

.method public d(Landroidx/appcompat/view/menu/j;I)V
    .locals 4
    .param p1    # Landroidx/appcompat/view/menu/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isCheckable()Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setCheckable(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isChecked()Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setChecked(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isEnabled()Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setEnabled(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setIcon(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTitle(Ljava/lang/CharSequence;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Landroid/view/View;->setId(I)V

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object p2

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v1, 0x17

    const/4 v2, 0x7

    move v3, v2

    if-le v0, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p0, p2}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isVisible()Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 p1, 0x8

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->a:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public getActiveIndicatorDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getBadge()Lcom/google/android/material/badge/a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method protected getItemBackgroundResId()I
    .locals 3
    .annotation build Landroidx/annotation/v;
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$drawable;->mtrl_navigation_bar_item_background:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getItemData()Landroidx/appcompat/view/menu/j;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method protected getItemDefaultMarginResId()I
    .locals 3
    .annotation build Landroidx/annotation/q;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_navigation_bar_item_default_margin:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method protected abstract getItemLayoutResId()I
    .annotation build Landroidx/annotation/j0;
    .end annotation
.end method

.method public getItemPosition()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->o:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method protected getSuggestedMinimumHeight()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getSuggestedIconHeight()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v4, 0x2

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    const/4 v3, 0x6

    move v4, v3

    add-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    const/4 v3, 0x0

    move v4, v3

    add-int/2addr v1, v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v1
.end method

.method protected getSuggestedMinimumWidth()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    add-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getSuggestedIconWidth()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method j()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->p()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->v:F

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onCreateDrawableState(I)[I
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->isCheckable()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->isChecked()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/material/navigation/NavigationBarItemView;->D:[I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 8
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    move v7, v6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const-string v0, ", "

    const-string v0, ", "

    const/4 v7, 0x5

    const-string v0, ", "

    const-string v0, ", "

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/badge/a;->o()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p1}, Landroidx/core/view/accessibility/l0;->X1(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroidx/core/view/accessibility/l0;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getItemVisiblePosition()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Landroidx/core/view/accessibility/l0$c;->h(IIIIZZ)Landroidx/core/view/accessibility/l0$c;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->Z0(Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/view/View;->isSelected()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->X0(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->j:Landroidx/core/view/accessibility/l0$a;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->K0(Landroidx/core/view/accessibility/l0$a;)Z

    :cond_2
    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget v1, Lcom/google/android/material/R$string;->item_view_role_description:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->D1(Ljava/lang/CharSequence;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->onSizeChanged(IIII)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p2, Lcom/google/android/material/navigation/NavigationBarItemView$b;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p2, p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView$b;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView;I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method p()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->v(Landroid/view/View;)V

    return-void
.end method

.method public setActiveIndicatorDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public setActiveIndicatorEnabled(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->w:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->j:Landroid/view/View;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 p1, 0x8

    :goto_0
    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public setActiveIndicatorHeight(I)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->y:I

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->x(I)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public setActiveIndicatorMarginHorizontal(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->A:I

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->x(I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method

.method public setActiveIndicatorResizeable(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->z:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setActiveIndicatorWidth(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->x:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->x(I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method setBadge(Lcom/google/android/material/badge/a;)V
    .locals 4
    .param p1    # Lcom/google/android/material/badge/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->l()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const-string v0, "aNomgtiBsrnav"

    const-string/jumbo v0, "grsatiiNnoaBv"

    const/4 v3, 0x3

    const-string/jumbo v0, "tnaNoiBavraig"

    const-string v0, "NavigationBar"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "dntusb boet pdm lMtoo /lt tii nem./hceateubsdghe ea"

    const-string/jumbo v1, "ustm oaetnMsce/l/eoeeli ddmnohg btp buelthti.t  a d"

    const/4 v3, 0x0

    const-string/jumbo v1, "ghmd  ula tiee.staeMuunhd e eptsitn /dota/eoclbltb "

    const-string v1, "Multiple badges shouldn\'t be attached to one item."

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->v(Landroid/view/View;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->B:Lcom/google/android/material/badge/a;

    const/4 v2, 0x2

    move v3, v2

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->u(Landroid/view/View;)V

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public setCheckable(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    const/4 v1, 0x0

    return-void
.end method

.method public setChecked(Z)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v2, 0x2

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    div-int/2addr v1, v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    int-to-float v1, v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setPivotX(F)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/widget/TextView;->getBaseline()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    int-to-float v1, v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setPivotY(F)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    div-int/2addr v1, v2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    int-to-float v1, v1

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->setPivotX(F)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v0}, Landroid/widget/TextView;->getBaseline()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    int-to-float v1, v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setPivotY(F)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz p1, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    move v1, v0

    move v1, v0

    const/4 v9, 0x3

    move v1, v0

    move v1, v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {p0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->n(F)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->g:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v3, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/16 v4, 0x11

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/16 v5, 0x31

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v6, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v7, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eq v1, v3, :cond_6

    const/4 v9, 0x4

    if-eqz v1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v3, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eq v1, v3, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eq v1, v2, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto/16 :goto_3

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-static {v0, v1, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/16 v1, 0x8

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto/16 :goto_3

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v1, v2}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz p1, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    int-to-float v2, v2

    const/4 v8, 0x1

    move v9, v8

    iget v3, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->d:F

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    add-float/2addr v2, v3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    float-to-int v2, v2

    const/4 v9, 0x4

    invoke-static {v1, v2, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x0

    invoke-static {v1, v0, v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->e:F

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v0, v1, v1, v6}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto/16 :goto_3

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v1, v2, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x2

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->f:F

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v1, v2, v2, v6}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v1, v0, v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    goto/16 :goto_3

    :cond_4
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz p1, :cond_5

    const/4 v9, 0x6

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x1

    invoke-static {v0, v1, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_1

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v8, 0x7

    move v9, v8

    invoke-static {v0, v1, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    :goto_1
    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto/16 :goto_3

    :cond_6
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->h:Z

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz v1, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz p1, :cond_7

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v0, v1, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    invoke-static {v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v8, 0x0

    const/4 v8, 0x0

    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto :goto_2

    :cond_7
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {v0, v1, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_3

    :cond_8
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->l:Landroid/view/ViewGroup;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    invoke-static {v1, v2}, Lcom/google/android/material/navigation/NavigationBarItemView;->z(Landroid/view/View;I)V

    const/4 v8, 0x5

    move v9, v8

    if-eqz p1, :cond_9

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    int-to-float v2, v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget v3, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->d:F

    const/4 v9, 0x0

    add-float/2addr v2, v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    float-to-int v2, v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {v1, v2, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v1, v0, v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->e:F

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v0, v1, v1, v6}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_3

    :cond_9
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->getIconOrContainer()Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x7

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v9, 0x6

    const/4 v8, 0x2

    invoke-static {v1, v2, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->t(Landroid/view/View;II)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget v2, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->f:F

    const/4 v9, 0x7

    invoke-static {v1, v2, v2, v6}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v1, v0, v0, v7}, Lcom/google/android/material/navigation/NavigationBarItemView;->s(Landroid/view/View;FFI)V

    :goto_3
    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    const/4 v9, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->setSelected(Z)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void
.end method

.method public setEnabled(Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setEnabled(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/16 v0, 0x3ea

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroidx/core/view/d1;->c(Landroid/content/Context;I)Landroidx/core/view/d1;

    move-result-object p1

    const/4 v2, 0x1

    invoke-static {p0, p1}, Landroidx/core/view/k1;->g2(Landroid/view/View;Landroidx/core/view/d1;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, p1}, Landroidx/core/view/k1;->g2(Landroid/view/View;Landroidx/core/view/d1;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->r:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->r:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->s:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->q:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public setIconSize(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    const/4 v2, 0x3

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->k:Landroid/widget/ImageView;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->q:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->s:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->s:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setItemBackground(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public setItemBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p1}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public setItemPaddingBottom(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->o()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setItemPaddingTop(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->o()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public setItemPosition(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->o:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public setLabelVisibilityMode(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->g:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->y()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->x(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->o()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setShifting(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->h:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->h:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView;->o()V

    :cond_0
    const/4 v2, 0x2

    return-void
.end method

.method public setTextAppearanceActive(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->r(Landroid/widget/TextView;I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/widget/TextView;->getTextSize()F

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->i(FF)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setTextAppearanceInactive(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->r(Landroid/widget/TextView;I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/widget/TextView;->getTextSize()F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->i(FF)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public setTextColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 4
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->m:Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->n:Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView;->p:Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object p1

    :cond_3
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 v1, 0x17

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-le v0, v1, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method
