.class Lcom/google/android/material/navigation/NavigationBarItemView$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/navigation/NavigationBarItemView;->onSizeChanged(IIII)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/google/android/material/navigation/NavigationBarItemView;


# direct methods
.method constructor <init>(Lcom/google/android/material/navigation/NavigationBarItemView;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView$b;->b:Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/android/material/navigation/NavigationBarItemView$b;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~osvn m@@@~obi@~b ~o M@b~-K@iofa  ~/@ @~@1~ @4u~ c@d/@l~~@tl ~f~@@y~So~  os@~@ @ ~@  tr~~~@~  ~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView$b;->b:Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView$b;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->e(Lcom/google/android/material/navigation/NavigationBarItemView;I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
