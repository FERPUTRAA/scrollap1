.class Lcom/google/android/material/navigation/NavigationView$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/navigation/NavigationView;->p()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/navigation/NavigationView;


# direct methods
.method constructor <init>(Lcom/google/android/material/navigation/NavigationView;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "l~s  /v@fbnt@~i~~f@M~r~o ~   ~@@~@~@ o-~o~u@@~ ~y~@ b@l1S@@ob4~@/da~t~s~@@@ i c   @ ~~. K o@m@o~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/google/android/material/navigation/NavigationView;->b(Lcom/google/android/material/navigation/NavigationView;)[I

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/android/material/navigation/NavigationView;->b(Lcom/google/android/material/navigation/NavigationView;)[I

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x0

    aget v0, v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v3}, Lcom/google/android/material/navigation/NavigationView;->c(Lcom/google/android/material/navigation/NavigationView;)Lcom/google/android/material/internal/j;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v3, v0}, Lcom/google/android/material/internal/j;->F(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/google/android/material/navigation/NavigationView;->m()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v3, v0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->setDrawTopInsetForeground(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/google/android/material/internal/c;->a(Landroid/content/Context;)Landroid/app/Activity;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v5, 0x7

    const/4 v5, 0x0

    const v3, 0x1020002

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v0, v3}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v3, v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    move v3, v1

    move v3, v1

    const/4 v6, 0x2

    move v3, v1

    move v3, v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_2

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    move v3, v2

    move v3, v2

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/view/Window;->getNavigationBarColor()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    goto :goto_3

    :cond_3
    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationView$b;->a:Lcom/google/android/material/navigation/NavigationView;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v3, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v0, :cond_4

    const/4 v6, 0x1

    invoke-virtual {v4}, Lcom/google/android/material/navigation/NavigationView;->l()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v0, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x0

    goto :goto_4

    :cond_4
    move v1, v2

    move v1, v2

    const/4 v6, 0x5

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v4, v1}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->setDrawBottomInsetForeground(Z)V

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void
.end method
