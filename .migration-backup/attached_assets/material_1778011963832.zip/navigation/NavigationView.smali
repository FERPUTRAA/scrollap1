.class public Lcom/google/android/material/navigation/NavigationView;
.super Lcom/google/android/material/internal/ScrimInsetsFrameLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/navigation/NavigationView$SavedState;,
        Lcom/google/android/material/navigation/NavigationView$c;
    }
.end annotation


# static fields
.field private static final s:[I

.field private static final t:[I

.field private static final u:I

.field private static final v:I = 0x1


# instance fields
.field private final f:Lcom/google/android/material/internal/i;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final g:Lcom/google/android/material/internal/j;

.field h:Lcom/google/android/material/navigation/NavigationView$c;

.field private final i:I

.field private final j:[I

.field private k:Landroid/view/MenuInflater;

.field private l:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field private m:Z

.field private n:Z

.field private o:I

.field private p:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private q:Landroid/graphics/Path;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final r:Landroid/graphics/RectF;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const v0, 0x10100a0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/navigation/NavigationView;->s:[I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const v0, -0x101009e

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/navigation/NavigationView;->t:[I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$style;->Widget_Design_NavigationView:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput v0, Lcom/google/android/material/navigation/NavigationView;->u:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/navigation/NavigationView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget v0, Lcom/google/android/material/R$attr;->navigationViewStyle:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/navigation/NavigationView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 16
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    move/from16 v8, p3

    move/from16 v8, p3

    sget v9, Lcom/google/android/material/navigation/NavigationView;->u:I

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    invoke-static {v1, v7, v8, v9}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, v7, v8}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance v10, Lcom/google/android/material/internal/j;

    invoke-direct {v10}, Lcom/google/android/material/internal/j;-><init>()V

    iput-object v10, v0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v1, 0x2

    new-array v1, v1, [I

    iput-object v1, v0, Lcom/google/android/material/navigation/NavigationView;->j:[I

    const/4 v11, 0x1

    iput-boolean v11, v0, Lcom/google/android/material/navigation/NavigationView;->m:Z

    iput-boolean v11, v0, Lcom/google/android/material/navigation/NavigationView;->n:Z

    const/4 v12, 0x0

    iput v12, v0, Lcom/google/android/material/navigation/NavigationView;->o:I

    iput v12, v0, Lcom/google/android/material/navigation/NavigationView;->p:I

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, v0, Lcom/google/android/material/navigation/NavigationView;->r:Landroid/graphics/RectF;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    new-instance v14, Lcom/google/android/material/internal/i;

    invoke-direct {v14, v13}, Lcom/google/android/material/internal/i;-><init>(Landroid/content/Context;)V

    iput-object v14, v0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    sget-object v3, Lcom/google/android/material/R$styleable;->NavigationView:[I

    new-array v6, v12, [I

    move-object v1, v13

    move-object v1, v13

    move-object v1, v13

    move-object v1, v13

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move/from16 v4, p3

    move/from16 v4, p3

    move/from16 v4, p3

    move v5, v9

    move v5, v9

    move v5, v9

    move v5, v9

    invoke-static/range {v1 .. v6}, Lcom/google/android/material/internal/q;->k(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroidx/appcompat/widget/n2;

    move-result-object v1

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_android_background:I

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-static {v0, v2}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    :cond_0
    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_drawerLayoutCornerSize:I

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v2

    iput v2, v0, Lcom/google/android/material/navigation/NavigationView;->p:I

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_android_layout_gravity:I

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v2

    iput v2, v0, Lcom/google/android/material/navigation/NavigationView;->o:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    instance-of v2, v2, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v2, :cond_3

    :cond_1
    invoke-static {v13, v7, v8, v9}, Lcom/google/android/material/shape/o;->e(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/shape/o$b;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    new-instance v4, Lcom/google/android/material/shape/j;

    invoke-direct {v4, v2}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    instance-of v2, v3, Landroid/graphics/drawable/ColorDrawable;

    if-eqz v2, :cond_2

    check-cast v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v3}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v2

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    :cond_2
    invoke-virtual {v4, v13}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    invoke-static {v0, v4}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    :cond_3
    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_elevation:I

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v2}, Lcom/google/android/material/navigation/NavigationView;->setElevation(F)V

    :cond_4
    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_android_fitsSystemWindows:I

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setFitsSystemWindows(Z)V

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_android_maxWidth:I

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v2

    iput v2, v0, Lcom/google/android/material/navigation/NavigationView;->i:I

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_subheaderColor:I

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_5

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    goto :goto_0

    :cond_5
    move-object v2, v4

    :goto_0
    sget v3, Lcom/google/android/material/R$styleable;->NavigationView_subheaderTextAppearance:I

    invoke-virtual {v1, v3}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-virtual {v1, v3, v12}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v3

    goto :goto_1

    :cond_6
    move v3, v12

    move v3, v12

    move v3, v12

    :goto_1
    const v5, 0x1010038

    if-nez v3, :cond_7

    if-nez v2, :cond_7

    invoke-direct {v0, v5}, Lcom/google/android/material/navigation/NavigationView;->e(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    :cond_7
    sget v6, Lcom/google/android/material/R$styleable;->NavigationView_itemIconTint:I

    invoke-virtual {v1, v6}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v7

    if-eqz v7, :cond_8

    invoke-virtual {v1, v6}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    goto :goto_2

    :cond_8
    invoke-direct {v0, v5}, Lcom/google/android/material/navigation/NavigationView;->e(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    :goto_2
    sget v6, Lcom/google/android/material/R$styleable;->NavigationView_itemTextAppearance:I

    invoke-virtual {v1, v6}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v7

    if-eqz v7, :cond_9

    invoke-virtual {v1, v6, v12}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v6

    goto :goto_3

    :cond_9
    move v6, v12

    move v6, v12

    :goto_3
    sget v7, Lcom/google/android/material/R$styleable;->NavigationView_itemIconSize:I

    invoke-virtual {v1, v7}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v8

    if-eqz v8, :cond_a

    invoke-virtual {v1, v7, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v7

    invoke-virtual {v0, v7}, Lcom/google/android/material/navigation/NavigationView;->setItemIconSize(I)V

    :cond_a
    sget v7, Lcom/google/android/material/R$styleable;->NavigationView_itemTextColor:I

    invoke-virtual {v1, v7}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v8

    if-eqz v8, :cond_b

    invoke-virtual {v1, v7}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    goto :goto_4

    :cond_b
    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    :goto_4
    if-nez v6, :cond_c

    if-nez v7, :cond_c

    const v7, 0x1010036

    invoke-direct {v0, v7}, Lcom/google/android/material/navigation/NavigationView;->e(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    :cond_c
    sget v8, Lcom/google/android/material/R$styleable;->NavigationView_itemBackground:I

    invoke-virtual {v1, v8}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    if-nez v8, :cond_d

    invoke-direct {v0, v1}, Lcom/google/android/material/navigation/NavigationView;->i(Landroidx/appcompat/widget/n2;)Z

    move-result v9

    if-eqz v9, :cond_d

    invoke-direct {v0, v1}, Lcom/google/android/material/navigation/NavigationView;->f(Landroidx/appcompat/widget/n2;)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    sget v9, Lcom/google/android/material/R$styleable;->NavigationView_itemRippleColor:I

    invoke-static {v13, v1, v9}, Lcom/google/android/material/resources/c;->b(Landroid/content/Context;Landroidx/appcompat/widget/n2;I)Landroid/content/res/ColorStateList;

    move-result-object v9

    if-eqz v9, :cond_d

    invoke-direct {v0, v1, v4}, Lcom/google/android/material/navigation/NavigationView;->g(Landroidx/appcompat/widget/n2;Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Drawable;

    move-result-object v15

    new-instance v11, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v9}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v9

    invoke-direct {v11, v9, v4, v15}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v10, v11}, Lcom/google/android/material/internal/j;->L(Landroid/graphics/drawable/RippleDrawable;)V

    :cond_d
    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_itemHorizontalPadding:I

    invoke-virtual {v1, v4}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v9

    if-eqz v9, :cond_e

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setItemHorizontalPadding(I)V

    :cond_e
    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_itemVerticalPadding:I

    invoke-virtual {v1, v4}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v9

    if-eqz v9, :cond_f

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setItemVerticalPadding(I)V

    :cond_f
    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_dividerInsetStart:I

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setDividerInsetStart(I)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_dividerInsetEnd:I

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setDividerInsetEnd(I)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_subheaderInsetStart:I

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setSubheaderInsetStart(I)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_subheaderInsetEnd:I

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setSubheaderInsetEnd(I)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_topInsetScrimEnabled:I

    iget-boolean v9, v0, Lcom/google/android/material/navigation/NavigationView;->m:Z

    invoke-virtual {v1, v4, v9}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setTopInsetScrimEnabled(Z)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_bottomInsetScrimEnabled:I

    iget-boolean v9, v0, Lcom/google/android/material/navigation/NavigationView;->n:Z

    invoke-virtual {v1, v4, v9}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v4

    invoke-virtual {v0, v4}, Lcom/google/android/material/navigation/NavigationView;->setBottomInsetScrimEnabled(Z)V

    sget v4, Lcom/google/android/material/R$styleable;->NavigationView_itemIconPadding:I

    invoke-virtual {v1, v4, v12}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v4

    sget v9, Lcom/google/android/material/R$styleable;->NavigationView_itemMaxLines:I

    const/4 v11, 0x1

    invoke-virtual {v1, v9, v11}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v9

    invoke-virtual {v0, v9}, Lcom/google/android/material/navigation/NavigationView;->setItemMaxLines(I)V

    new-instance v9, Lcom/google/android/material/navigation/NavigationView$a;

    invoke-direct {v9, v0}, Lcom/google/android/material/navigation/NavigationView$a;-><init>(Lcom/google/android/material/navigation/NavigationView;)V

    invoke-virtual {v14, v9}, Landroidx/appcompat/view/menu/g;->X(Landroidx/appcompat/view/menu/g$a;)V

    invoke-virtual {v10, v11}, Lcom/google/android/material/internal/j;->J(I)V

    invoke-virtual {v10, v13, v14}, Lcom/google/android/material/internal/j;->m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V

    if-eqz v3, :cond_10

    invoke-virtual {v10, v3}, Lcom/google/android/material/internal/j;->Y(I)V

    :cond_10
    invoke-virtual {v10, v2}, Lcom/google/android/material/internal/j;->V(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v10, v5}, Lcom/google/android/material/internal/j;->P(Landroid/content/res/ColorStateList;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getOverScrollMode()I

    move-result v2

    invoke-virtual {v10, v2}, Lcom/google/android/material/internal/j;->U(I)V

    if-eqz v6, :cond_11

    invoke-virtual {v10, v6}, Lcom/google/android/material/internal/j;->R(I)V

    :cond_11
    invoke-virtual {v10, v7}, Lcom/google/android/material/internal/j;->S(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v10, v8}, Lcom/google/android/material/internal/j;->K(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v10, v4}, Lcom/google/android/material/internal/j;->N(I)V

    invoke-virtual {v14, v10}, Landroidx/appcompat/view/menu/g;->b(Landroidx/appcompat/view/menu/n;)V

    invoke-virtual {v10, v0}, Lcom/google/android/material/internal/j;->h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_menu:I

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    if-eqz v3, :cond_12

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v2

    invoke-virtual {v0, v2}, Lcom/google/android/material/navigation/NavigationView;->k(I)V

    :cond_12
    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_headerLayout:I

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    if-eqz v3, :cond_13

    invoke-virtual {v1, v2, v12}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v2

    invoke-virtual {v0, v2}, Lcom/google/android/material/navigation/NavigationView;->j(I)Landroid/view/View;

    :cond_13
    invoke-virtual {v1}, Landroidx/appcompat/widget/n2;->I()V

    invoke-direct/range {p0 .. p0}, Lcom/google/android/material/navigation/NavigationView;->p()V

    return-void
.end method

.method static synthetic b(Lcom/google/android/material/navigation/NavigationView;)[I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Ms@d /l mi~~ ~@/ob~@to@y@ ~i@~i ~@f @4@~ 1o  @@K c@ ~f~n~@@~-b~.l@b~~@@rSu ~ so@  ~ @ tvoa~~~o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationView;->j:[I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/navigation/NavigationView;)Lcom/google/android/material/internal/j;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method private e(I)Landroid/content/res/ColorStateList;
    .locals 9
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v0, Landroid/util/TypedValue;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x1

    shl-int/2addr v8, v7

    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v1, p1, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    if-nez p1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-object v1

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget v3, v0, Landroid/util/TypedValue;->resourceId:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p1, v3}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    sget v4, Landroidx/appcompat/R$attr;->colorPrimary:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3, v4, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-nez v3, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object v1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget v0, v0, Landroid/util/TypedValue;->data:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v3, Landroid/content/res/ColorStateList;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v4, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-array v4, v4, [[I

    const/4 v8, 0x7

    const/4 v7, 0x5

    sget-object v5, Lcom/google/android/material/navigation/NavigationView;->t:[I

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v6, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    aput-object v5, v4, v6

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget-object v6, Lcom/google/android/material/navigation/NavigationView;->s:[I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    aput-object v6, v4, v2

    const/4 v8, 0x5

    const/4 v2, 0x2

    const/4 v8, 0x0

    move v7, v2

    move v7, v2

    const/4 v8, 0x3

    sget-object v6, Landroid/widget/FrameLayout;->EMPTY_STATE_SET:[I

    const/4 v8, 0x3

    aput-object v6, v4, v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p1, v5, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    filled-new-array {p1, v0, v1}, [I

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v3, v4, p1}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-object v3
.end method

.method private f(Landroidx/appcompat/widget/n2;)Landroid/graphics/drawable/Drawable;
    .locals 4
    .param p1    # Landroidx/appcompat/widget/n2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeFillColor:I

    const/4 v3, 0x1

    invoke-static {v0, p1, v1}, Lcom/google/android/material/resources/c;->b(Landroid/content/Context;Landroidx/appcompat/widget/n2;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/navigation/NavigationView;->g(Landroidx/appcompat/widget/n2;Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p1
.end method

.method private g(Landroidx/appcompat/widget/n2;Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Drawable;
    .locals 11
    .param p1    # Landroidx/appcompat/widget/n2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeAppearance:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    sget v2, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeAppearanceOverlay:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p1, v2, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    new-instance v4, Lcom/google/android/material/shape/j;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v3, v0, v2}, Lcom/google/android/material/shape/o;->b(Landroid/content/Context;II)Lcom/google/android/material/shape/o$b;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {v4, v0}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v4, p2}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    sget p2, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeInsetStart:I

    invoke-virtual {p1, p2, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    sget p2, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeInsetTop:I

    const/4 v10, 0x2

    invoke-virtual {p1, p2, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget p2, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeInsetEnd:I

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1, p2, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v7

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeInsetBottom:I

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1, p2, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p1, Landroid/graphics/drawable/InsetDrawable;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct/range {v3 .. v8}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-object p1
.end method

.method private getMenuInflater()Landroid/view/MenuInflater;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->k:Landroid/view/MenuInflater;

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Landroidx/appcompat/view/g;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Landroidx/appcompat/view/g;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->k:Landroid/view/MenuInflater;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->k:Landroid/view/MenuInflater;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method private i(Landroidx/appcompat/widget/n2;)Z
    .locals 3
    .param p1    # Landroidx/appcompat/widget/n2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeAppearance:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$styleable;->NavigationView_itemShapeAppearanceOverlay:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x1

    :goto_1
    const/4 v1, 0x1

    move v2, v1

    return p1
.end method

.method private n(II)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    instance-of v0, v0, Landroidx/drawerlayout/widget/DrawerLayout;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/android/material/navigation/NavigationView;->p:I

    const/4 v5, 0x5

    if-lez v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    instance-of v0, v0, Lcom/google/android/material/shape/j;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast v0, Lcom/google/android/material/shape/j;

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object v1

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/material/shape/o;->v()Lcom/google/android/material/shape/o$b;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/android/material/navigation/NavigationView;->o:I

    const/4 v4, 0x3

    move v5, v4

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v2, v3}, Landroidx/core/view/b0;->d(II)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    shl-int/2addr v5, v3

    const/4 v4, 0x4

    and-int/2addr v5, v4

    if-ne v2, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/android/material/navigation/NavigationView;->p:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    int-to-float v2, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/o$b;->P(F)Lcom/google/android/material/shape/o$b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/android/material/navigation/NavigationView;->p:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    int-to-float v2, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/o$b;->C(F)Lcom/google/android/material/shape/o$b;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/android/material/navigation/NavigationView;->p:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    int-to-float v2, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/o$b;->K(F)Lcom/google/android/material/shape/o$b;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/android/material/navigation/NavigationView;->p:I

    const/4 v5, 0x7

    int-to-float v2, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/o$b;->x(F)Lcom/google/android/material/shape/o$b;

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    if-nez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v1, Landroid/graphics/Path;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    const/4 v4, 0x3

    move v5, v4

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->r:Landroid/graphics/RectF;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    int-to-float p1, p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    int-to-float p2, p2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v2, p1, p2}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/android/material/shape/p;->k()Lcom/google/android/material/shape/p;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->z()F

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->r:Landroid/graphics/RectF;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    const/4 v5, 0x7

    invoke-virtual {p1, p2, v0, v1, v2}, Lcom/google/android/material/shape/p;->d(Lcom/google/android/material/shape/o;FLandroid/graphics/RectF;Landroid/graphics/Path;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationView;->r:Landroid/graphics/RectF;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/graphics/RectF;->setEmpty()V

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method private p()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/navigation/NavigationView$b;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/navigation/NavigationView$b;-><init>(Lcom/google/android/material/navigation/NavigationView;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->l:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->l:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method protected a(Landroidx/core/view/y2;)V
    .locals 3
    .param p1    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->n(Landroidx/core/view/y2;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public d(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->b(Landroid/view/View;)V

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 4
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->dispatchDraw(Landroid/graphics/Canvas;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->q:Landroid/graphics/Path;

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->dispatchDraw(Landroid/graphics/Canvas;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v3, 0x6

    return-void
.end method

.method public getCheckedItem()Landroid/view/MenuItem;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->o()Landroidx/appcompat/view/menu/j;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getDividerInsetEnd()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->p()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public getDividerInsetStart()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->q()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getHeaderCount()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->r()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getItemBackground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->t()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getItemHorizontalPadding()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->u()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public getItemIconPadding()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->v()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getItemIconTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->y()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getItemMaxLines()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->w()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getItemTextColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->x()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getItemVerticalPadding()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->z()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return-object v0
.end method

.method public getSubheaderInsetEnd()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->A()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public getSubheaderInsetStart()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/j;->B()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public h(I)Landroid/view/View;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->s(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1
.end method

.method public j(I)Landroid/view/View;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->C(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method

.method public k(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/internal/j;->Z(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationView;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p1, v1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/material/internal/j;->Z(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/internal/j;->j(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationView;->n:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationView;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    return v0
.end method

.method public o(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->E(Landroid/view/View;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method protected onAttachedToWindow()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-super {p0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->onAttachedToWindow()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/android/material/shape/k;->e(Landroid/view/View;)V

    const/4 v1, 0x3

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-super {p0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->onDetachedFromWindow()V

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationView;->l:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method protected onMeasure(II)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/high16 v1, -0x80000000

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v0, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget p1, p0, Lcom/google/android/material/navigation/NavigationView;->i:I

    const/4 v4, 0x2

    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/material/navigation/NavigationView;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    instance-of v0, p1, Lcom/google/android/material/navigation/NavigationView$SavedState;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p1, Lcom/google/android/material/navigation/NavigationView$SavedState;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-super {p0, v0}, Landroid/widget/FrameLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object p1, p1, Lcom/google/android/material/navigation/NavigationView$SavedState;->c:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->U(Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-super {p0}, Landroid/widget/FrameLayout;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/navigation/NavigationView$SavedState;

    const/4 v3, 0x2

    move v4, v3

    invoke-direct {v1, v0}, Lcom/google/android/material/navigation/NavigationView$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v0, v1, Lcom/google/android/material/navigation/NavigationView$SavedState;->c:Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Landroidx/appcompat/view/menu/g;->W(Landroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v3, 0x1

    return-object v1
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->onSizeChanged(IIII)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationView;->n(II)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public setBottomInsetScrimEnabled(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationView;->n:Z

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setCheckedItem(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->G(Landroidx/appcompat/view/menu/j;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public setCheckedItem(Landroid/view/MenuItem;)V
    .locals 3
    .param p1    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->f:Lcom/google/android/material/internal/i;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->G(Landroidx/appcompat/view/menu/j;)V

    const/4 v1, 0x3

    move v2, v1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "htim)t rmhiiutIum uiedCt mateenhesenhMst eers e(el  ccae n.  kewltmnotCnI adn"

    const-string v0, "emstoet.aeke hl  denln)ted m i uteatCniei rICue anIc(eMurm shttcs hwemnntih t"

    const/4 v2, 0x3

    const-string v0, " sIho eartnmhnlrtMnhuciik(w)enIa  otenmtC ee.deltue ttee dmh iciet as  teumCt"

    const-string v0, "Called setCheckedItem(MenuItem) with an item that is not in the current menu."

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1
.end method

.method public setDividerInsetEnd(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->H(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setDividerInsetStart(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->I(I)V

    const/4 v1, 0x6

    move v2, v1

    return-void
.end method

.method public setElevation(F)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setElevation(F)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/shape/k;->d(Landroid/view/View;F)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public setItemBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->K(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public setItemBackgroundResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public setItemHorizontalPadding(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->M(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setItemHorizontalPaddingResource(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->M(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public setItemIconPadding(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->N(I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setItemIconPaddingResource(I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->N(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public setItemIconSize(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->O(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setItemIconTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->P(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public setItemMaxLines(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->Q(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public setItemTextAppearance(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->R(I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public setItemTextColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->S(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public setItemVerticalPadding(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->T(I)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public setItemVerticalPaddingResource(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->T(I)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public setNavigationItemSelectedListener(Lcom/google/android/material/navigation/NavigationView$c;)V
    .locals 2
    .param p1    # Lcom/google/android/material/navigation/NavigationView$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationView;->h:Lcom/google/android/material/navigation/NavigationView$c;

    const/4 v1, 0x5

    return-void
.end method

.method public setOverScrollMode(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setOverScrollMode(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->U(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setSubheaderInsetEnd(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->X(I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public setSubheaderInsetStart(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationView;->g:Lcom/google/android/material/internal/j;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j;->X(I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public setTopInsetScrimEnabled(Z)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationView;->m:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
