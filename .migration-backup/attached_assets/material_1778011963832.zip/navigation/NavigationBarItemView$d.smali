.class Lcom/google/android/material/navigation/NavigationBarItemView$d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/navigation/NavigationBarItemView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# static fields
.field private static final a:F = 0.4f

.field private static final b:F = 1.0f

.field private static final c:F = 0.2f


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/navigation/NavigationBarItemView$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView$d;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected a(FF)F
    .locals 5
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ s~@ t@@  @b~@~o~ u-v@nt@oKi~o/rc~@  @~~. @~b~@l@ d @b~~~@4i@fSo @iy1am   ~~  ~ o~~~o@l/fs~@@@M"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    cmpl-float p2, p2, v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const v1, 0x3f4ccccd    # 0.8f

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    move p2, v2

    move p2, v2

    const/4 v4, 0x4

    move p2, v2

    move p2, v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const p2, 0x3e4ccccd    # 0.2f

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0, v2, v1, p2, p1}, Lcom/google/android/material/animation/a;->b(FFFFF)F

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    return p1
.end method

.method protected b(FF)F
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const p2, 0x3ecccccd    # 0.4f

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2, v0, p1}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p1
.end method

.method protected c(FF)F
    .locals 2
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method public d(FFLandroid/view/View;)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarItemView$d;->b(FF)F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Landroid/view/View;->setScaleX(F)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarItemView$d;->c(FF)F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarItemView$d;->a(FF)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {p3, p1}, Landroid/view/View;->setAlpha(F)V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method
