.class public abstract Lcom/google/android/material/navigation/NavigationBarView;
.super Landroid/widget/FrameLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/navigation/NavigationBarView$SavedState;,
        Lcom/google/android/material/navigation/NavigationBarView$c;,
        Lcom/google/android/material/navigation/NavigationBarView$d;,
        Lcom/google/android/material/navigation/NavigationBarView$b;
    }
.end annotation


# static fields
.field public static final h:I = -0x1

.field public static final i:I = 0x0

.field public static final j:I = 0x1

.field public static final k:I = 0x2

.field private static final l:I = 0x1


# instance fields
.field private final a:Lcom/google/android/material/navigation/a;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Lcom/google/android/material/navigation/NavigationBarMenuView;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Lcom/google/android/material/navigation/NavigationBarPresenter;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private d:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Landroid/view/MenuInflater;

.field private f:Lcom/google/android/material/navigation/NavigationBarView$d;

.field private g:Lcom/google/android/material/navigation/NavigationBarView$c;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 11
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {p1, p2, p3, p4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-direct {p1}, Lcom/google/android/material/navigation/NavigationBarPresenter;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    sget-object v2, Lcom/google/android/material/R$styleable;->NavigationBarView:[I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget v7, Lcom/google/android/material/R$styleable;->NavigationBarView_itemTextAppearanceInactive:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    sget v8, Lcom/google/android/material/R$styleable;->NavigationBarView_itemTextAppearanceActive:I

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    filled-new-array {v7, v8}, [I

    move-result-object v5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    move v3, p3

    move v3, p3

    move v3, p3

    const/4 v10, 0x4

    move v4, p4

    const/4 v10, 0x7

    move v4, p4

    move v4, p4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->k(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroidx/appcompat/widget/n2;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance p3, Lcom/google/android/material/navigation/a;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarView;->getMaxItemCount()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-direct {p3, v6, p4, v0}, Lcom/google/android/material/navigation/a;-><init>(Landroid/content/Context;Ljava/lang/Class;I)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    iput-object p3, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v10, 0x4

    invoke-virtual {p0, v6}, Lcom/google/android/material/navigation/NavigationBarView;->d(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarMenuView;

    move-result-object p4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    iput-object p4, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p1, p4}, Lcom/google/android/material/navigation/NavigationBarPresenter;->b(Lcom/google/android/material/navigation/NavigationBarMenuView;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v0, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/material/navigation/NavigationBarPresenter;->a(I)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p4, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setPresenter(Lcom/google/android/material/navigation/NavigationBarPresenter;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p3, p1}, Landroidx/appcompat/view/menu/g;->b(Landroidx/appcompat/view/menu/n;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1, v1, p3}, Lcom/google/android/material/navigation/NavigationBarPresenter;->m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemIconTint:I

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v1, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v10, 0x4

    invoke-virtual {p4, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setIconTintList(Landroid/content/res/ColorStateList;)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    const p1, 0x1010038

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p4, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->e(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p4, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setIconTintList(Landroid/content/res/ColorStateList;)V

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemIconSize:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_navigation_bar_item_default_icon_size:I

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemIconSize(I)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p2, v7}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-eqz p1, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p2, v7, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemTextAppearanceInactive(I)V

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p2, v8}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz p1, :cond_2

    const/4 v10, 0x7

    invoke-virtual {p2, v8, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemTextAppearanceActive(I)V

    :cond_2
    const/4 v10, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemTextColor:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz v2, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemTextColor(Landroid/content/res/ColorStateList;)V

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz p1, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    instance-of p1, p1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz p1, :cond_5

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct {p0, v6}, Lcom/google/android/material/navigation/NavigationBarView;->c(Landroid/content/Context;)Lcom/google/android/material/shape/j;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p0, p1}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemPaddingTop:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-eqz v2, :cond_6

    const/4 v10, 0x7

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemPaddingTop(I)V

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemPaddingBottom:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-eqz v2, :cond_7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemPaddingBottom(I)V

    :cond_7
    const/4 v9, 0x4

    const/4 v10, 0x4

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_elevation:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eqz v2, :cond_8

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p1

    const/4 v9, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    int-to-float p1, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setElevation(F)V

    :cond_8
    const/4 v10, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_backgroundTint:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {v6, p2, p1}, Lcom/google/android/material/resources/c;->b(Landroid/content/Context;Landroidx/appcompat/widget/n2;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v2, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v9, 0x0

    shr-int/2addr v10, v9

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_labelVisibilityMode:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v2}, Landroidx/appcompat/widget/n2;->p(II)I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setLabelVisibilityMode(I)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemBackground:I

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz p1, :cond_9

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p4, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackgroundRes(I)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_1

    :cond_9
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemRippleColor:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v6, p2, p1}, Lcom/google/android/material/resources/c;->b(Landroid/content/Context;Landroidx/appcompat/widget/n2;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemRippleColor(Landroid/content/res/ColorStateList;)V

    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_itemActiveIndicatorStyle:I

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz p1, :cond_a

    const/4 v10, 0x2

    const/4 v9, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorEnabled(Z)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    sget-object v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator:[I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v6, p1, v0}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator_android_width:I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorWidth(I)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    sget v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator_android_height:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorHeight(I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator_marginHorizontal:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorMarginHorizontal(I)V

    const/4 v10, 0x6

    sget v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator_android_color:I

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v6, p1, v0}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorColor(Landroid/content/res/ColorStateList;)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    sget v0, Lcom/google/android/material/R$styleable;->NavigationBarActiveIndicator_shapeAppearance:I

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v6, v0, v1}, Lcom/google/android/material/shape/o;->b(Landroid/content/Context;II)Lcom/google/android/material/shape/o$b;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarView;->setItemActiveIndicatorShapeAppearance(Lcom/google/android/material/shape/o;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_a
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    sget p1, Lcom/google/android/material/R$styleable;->NavigationBarView_menu:I

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2, p1}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v0, :cond_b

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p2, p1, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->g(I)V

    :cond_b
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p2}, Landroidx/appcompat/widget/n2;->I()V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p0, p4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    new-instance p1, Lcom/google/android/material/navigation/NavigationBarView$a;

    const/4 v10, 0x0

    invoke-direct {p1, p0}, Lcom/google/android/material/navigation/NavigationBarView$a;-><init>(Lcom/google/android/material/navigation/NavigationBarView;)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p3, p1}, Landroidx/appcompat/view/menu/g;->X(Landroidx/appcompat/view/menu/g$a;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/navigation/NavigationBarView;)Lcom/google/android/material/navigation/NavigationBarView$c;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationBarView;->g:Lcom/google/android/material/navigation/NavigationBarView$c;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic b(Lcom/google/android/material/navigation/NavigationBarView;)Lcom/google/android/material/navigation/NavigationBarView$d;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationBarView;->f:Lcom/google/android/material/navigation/NavigationBarView$d;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method private c(Landroid/content/Context;)Lcom/google/android/material/shape/j;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    instance-of v2, v1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v1, Landroid/graphics/drawable/ColorDrawable;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method private getMenuInflater()Landroid/view/MenuInflater;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->e:Landroid/view/MenuInflater;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Landroidx/appcompat/view/g;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroidx/appcompat/view/g;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->e:Landroid/view/MenuInflater;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->e:Landroid/view/MenuInflater;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method


# virtual methods
.method protected abstract d(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarMenuView;
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public e(I)Lcom/google/android/material/badge/a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->i(I)Lcom/google/android/material/badge/a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1
.end method

.method public f(I)Lcom/google/android/material/badge/a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->j(I)Lcom/google/android/material/badge/a;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public g(I)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarView;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v2}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v3, 0x0

    move v4, v3

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Lcom/google/android/material/navigation/NavigationBarPresenter;->j(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public getItemActiveIndicatorColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorColor()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getItemActiveIndicatorHeight()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorHeight()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public getItemActiveIndicatorMarginHorizontal()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorMarginHorizontal()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public getItemActiveIndicatorShapeAppearance()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorShapeAppearance()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public getItemActiveIndicatorWidth()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorWidth()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getItemBackground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getItemBackgroundResource()I
    .locals 3
    .annotation build Landroidx/annotation/v;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemBackgroundRes()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method

.method public getItemIconSize()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemIconSize()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public getItemIconTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getIconTintList()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getItemPaddingBottom()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemPaddingBottom()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getItemPaddingTop()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemPaddingTop()I

    move-result v0

    const/4 v1, 0x4

    move v2, v1

    return v0
.end method

.method public getItemRippleColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getItemTextAppearanceActive()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemTextAppearanceActive()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public getItemTextAppearanceInactive()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemTextAppearanceInactive()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public getItemTextColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemTextColor()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public getLabelVisibilityMode()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getLabelVisibilityMode()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public abstract getMaxItemCount()I
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object v0
.end method

.method public getMenuView()Landroidx/appcompat/view/menu/o;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getPresenter()Lcom/google/android/material/navigation/NavigationBarPresenter;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSelectedItemId()I
    .locals 3
    .annotation build Landroidx/annotation/d0;
    .end annotation

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getSelectedItemId()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemActiveIndicatorEnabled()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public i(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->n(I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public j(ILandroid/view/View$OnTouchListener;)V
    .locals 3
    .param p2    # Landroid/view/View$OnTouchListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarMenuView;->q(ILandroid/view/View$OnTouchListener;)V

    const/4 v2, 0x3

    return-void
.end method

.method protected onAttachedToWindow()V
    .locals 2

    const/4 v1, 0x7

    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/android/material/shape/k;->e(Landroid/view/View;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3
    .param p1    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    instance-of v0, p1, Lcom/google/android/material/navigation/NavigationBarView$SavedState;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/material/navigation/NavigationBarView$SavedState;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, v0}, Landroid/widget/FrameLayout;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p1, Lcom/google/android/material/navigation/NavigationBarView$SavedState;->c:Landroid/os/Bundle;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->U(Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-super {p0}, Landroid/widget/FrameLayout;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Lcom/google/android/material/navigation/NavigationBarView$SavedState;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v0}, Lcom/google/android/material/navigation/NavigationBarView$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, v1, Lcom/google/android/material/navigation/NavigationBarView$SavedState;->c:Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Landroidx/appcompat/view/menu/g;->W(Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v1
.end method

.method public setElevation(F)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setElevation(F)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/android/material/shape/k;->d(Landroid/view/View;F)V

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    return-void
.end method

.method public setItemActiveIndicatorColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorColor(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x7

    return-void
.end method

.method public setItemActiveIndicatorEnabled(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorEnabled(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public setItemActiveIndicatorHeight(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorHeight(I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public setItemActiveIndicatorMarginHorizontal(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorMarginHorizontal(I)V

    const/4 v2, 0x4

    return-void
.end method

.method public setItemActiveIndicatorShapeAppearance(Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorShapeAppearance(Lcom/google/android/material/shape/o;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setItemActiveIndicatorWidth(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemActiveIndicatorWidth(I)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public setItemBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public setItemBackgroundResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackgroundRes(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public setItemIconSize(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemIconSize(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setItemIconSizeRes(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarView;->setItemIconSize(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public setItemIconTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setIconTintList(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x7

    return-void
.end method

.method public setItemPaddingBottom(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemPaddingBottom(I)V

    const/4 v2, 0x7

    return-void
.end method

.method public setItemPaddingTop(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemPaddingTop(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setItemRippleColor(Landroid/content/res/ColorStateList;)V
    .locals 5
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->d:Landroid/content/res/ColorStateList;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne v0, p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getItemBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1, v1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    return-void

    :cond_1
    const/4 v4, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->d:Landroid/content/res/ColorStateList;

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-nez p1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->a(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v2, Landroid/graphics/drawable/RippleDrawable;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, p1, v1, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method public setItemTextAppearanceActive(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemTextAppearanceActive(I)V

    const/4 v2, 0x6

    return-void
.end method

.method public setItemTextAppearanceInactive(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemTextAppearanceInactive(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public setItemTextColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setItemTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setLabelVisibilityMode(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getLabelVisibilityMode()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->b:Lcom/google/android/material/navigation/NavigationBarMenuView;

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setLabelVisibilityMode(I)V

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/navigation/NavigationBarPresenter;->j(Z)V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method public setOnItemReselectedListener(Lcom/google/android/material/navigation/NavigationBarView$c;)V
    .locals 2
    .param p1    # Lcom/google/android/material/navigation/NavigationBarView$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->g:Lcom/google/android/material/navigation/NavigationBarView$c;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public setOnItemSelectedListener(Lcom/google/android/material/navigation/NavigationBarView$d;)V
    .locals 2
    .param p1    # Lcom/google/android/material/navigation/NavigationBarView$d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarView;->f:Lcom/google/android/material/navigation/NavigationBarView$d;

    const/4 v1, 0x6

    return-void
.end method

.method public setSelectedItemId(I)V
    .locals 5
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarView;->a:Lcom/google/android/material/navigation/a;

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarView;->c:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1, v2}, Landroidx/appcompat/view/menu/g;->P(Landroid/view/MenuItem;Landroidx/appcompat/view/menu/n;I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x0

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method
