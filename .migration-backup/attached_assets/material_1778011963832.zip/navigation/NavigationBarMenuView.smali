.class public abstract Lcom/google/android/material/navigation/NavigationBarMenuView;
.super Landroid/view/ViewGroup;

# interfaces
.implements Landroidx/appcompat/view/menu/o;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final C:I = 0x5

.field private static final D:I = -0x1

.field private static final E:[I

.field private static final F:[I


# instance fields
.field private A:Lcom/google/android/material/navigation/NavigationBarPresenter;

.field private B:Landroidx/appcompat/view/menu/g;

.field private final a:Landroidx/transition/o0;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Landroid/view/View$OnClickListener;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Landroidx/core/util/p$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/core/util/p$a<",
            "Lcom/google/android/material/navigation/NavigationBarItemView;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Landroid/util/SparseArray;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/view/View$OnTouchListener;",
            ">;"
        }
    .end annotation
.end field

.field private e:I

.field private f:[Lcom/google/android/material/navigation/NavigationBarItemView;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private g:I

.field private h:I

.field private i:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private k:Landroid/content/res/ColorStateList;

.field private final l:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private m:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private n:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private o:Landroid/graphics/drawable/Drawable;

.field private p:I

.field private final q:Landroid/util/SparseArray;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lcom/google/android/material/badge/a;",
            ">;"
        }
    .end annotation
.end field

.field private r:I

.field private s:I

.field private t:Z

.field private u:I

.field private v:I

.field private w:I

.field private x:Lcom/google/android/material/shape/o;

.field private y:Z

.field private z:Landroid/content/res/ColorStateList;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const v0, 0x10100a0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/navigation/NavigationBarMenuView;->E:[I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const v0, -0x101009e

    const/4 v1, 0x2

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/navigation/NavigationBarMenuView;->F:[I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x1

    new-instance p1, Landroidx/core/util/p$c;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x5

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p1, v0}, Landroidx/core/util/p$c;-><init>(I)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->c:Landroidx/core/util/p$a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance p1, Landroid/util/SparseArray;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->d:Landroid/util/SparseArray;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Landroid/util/SparseArray;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v1, v0}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v0, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->r:I

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->s:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->y:Z

    const/4 v5, 0x3

    const v0, 0x1010038

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->e(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->l:Landroid/content/res/ColorStateList;

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->a:Landroidx/transition/o0;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v0, Landroidx/transition/c;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0}, Landroidx/transition/c;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->a:Landroidx/transition/o0;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroidx/transition/o0;->S0(I)Landroidx/transition/o0;

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget v1, Lcom/google/android/material/R$attr;->motionDurationLong1:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget v3, Lcom/google/android/material/R$integer;->material_motion_duration_long_1:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v2

    const/4 v5, 0x4

    invoke-static {p1, v1, v2}, Lv4/a;->d(Landroid/content/Context;II)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    int-to-long v1, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Landroidx/transition/o0;->Q0(J)Landroidx/transition/o0;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    sget v1, Lcom/google/android/material/R$attr;->motionEasingStandard:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v2, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1, v1, v2}, Lv4/a;->e(Landroid/content/Context;ILandroid/animation/TimeInterpolator;)Landroid/animation/TimeInterpolator;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroidx/transition/o0;->R0(Landroid/animation/TimeInterpolator;)Landroidx/transition/o0;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/material/internal/o;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1}, Lcom/google/android/material/internal/o;-><init>()V

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Landroidx/transition/o0;->F0(Landroidx/transition/j0;)Landroidx/transition/o0;

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance p1, Lcom/google/android/material/navigation/NavigationBarMenuView$a;

    const/4 v5, 0x0

    invoke-direct {p1, p0}, Lcom/google/android/material/navigation/NavigationBarMenuView$a;-><init>(Lcom/google/android/material/navigation/NavigationBarMenuView;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->b:Landroid/view/View$OnClickListener;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x4

    invoke-static {p0, p1}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method static synthetic b(Lcom/google/android/material/navigation/NavigationBarMenuView;)Lcom/google/android/material/navigation/NavigationBarPresenter;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~@~~@S~i@~   M@@@c~y1~ob~br mlod~ K~~. i@~ @ i@on~  -@@/~f~ @~@4 tsoa ~ v~u ~@@t@@~boo@f/  l"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/navigation/NavigationBarMenuView;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method private f()Landroid/graphics/drawable/Drawable;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->x:Lcom/google/android/material/shape/o;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->z:Landroid/content/res/ColorStateList;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->x:Lcom/google/android/material/shape/o;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->z:Landroid/content/res/ColorStateList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x2

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    and-int/2addr v3, v2

    return-object v0
.end method

.method private getNewItem()Lcom/google/android/material/navigation/NavigationBarItemView;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->c:Landroidx/core/util/p$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Landroidx/core/util/p$a;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->g(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarItemView;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method private m(I)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 p1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1
.end method

.method private o()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    move v2, v1

    move v2, v1

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ge v2, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v3, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v3}, Landroid/view/MenuItem;->getItemId()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    :goto_1
    const/4 v4, 0x6

    move v5, v4

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v1, v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->delete(I)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method private setBadgeIfNeeded(Lcom/google/android/material/navigation/NavigationBarItemView;)V
    .locals 4
    .param p1    # Lcom/google/android/material/navigation/NavigationBarItemView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->m(I)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/material/badge/a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->setBadge(Lcom/google/android/material/badge/a;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method private t(I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->m(I)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string p1, " ltmvn siwedad visiiao "

    const-string/jumbo p1, "ias diltvs w diie n aov"

    const/4 v3, 0x6

    const-string p1, "d oaod lineiia i t  wvv"

    const-string p1, " is not a valid view id"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    throw v0
.end method


# virtual methods
.method public a(Landroidx/appcompat/view/menu/g;)V
    .locals 2
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public d()V
    .locals 8
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    array-length v2, v0

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ge v3, v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget-object v4, v0, v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v4, :cond_0

    iget-object v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->c:Landroidx/core/util/p$a;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v5, v4}, Landroidx/core/util/p$a;->a(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->j()V

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->o()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    new-array v0, v0, [Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0, v0, v2}, Lcom/google/android/material/navigation/NavigationBarMenuView;->l(II)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v2, v1

    move v2, v1

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ge v2, v3, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v3, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v3, v4}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, v1}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getNewItem()Lcom/google/android/material/navigation/NavigationBarItemView;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    aput-object v3, v4, v2

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->i:Landroid/content/res/ColorStateList;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setIconTintList(Landroid/content/res/ColorStateList;)V

    const/4 v6, 0x5

    const/4 v6, 0x6

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->j:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setIconSize(I)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->l:Landroid/content/res/ColorStateList;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->m:I

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextAppearanceInactive(I)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->n:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextAppearanceActive(I)V

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->k:Landroid/content/res/ColorStateList;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->r:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v5, -0x1

    const/4 v7, 0x4

    if-eq v4, v5, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemPaddingTop(I)V

    :cond_3
    const/4 v6, 0x7

    move v7, v6

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->s:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eq v4, v5, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemPaddingBottom(I)V

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x7

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->u:I

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorWidth(I)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->v:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorHeight(I)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->w:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorMarginHorizontal(I)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-boolean v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->y:Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorResizeable(Z)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-boolean v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->t:Z

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorEnabled(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->o:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x1

    if-eqz v4, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_2

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->p:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemBackground(I)V

    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->setShifting(Z)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setLabelVisibilityMode(I)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v4, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3, v4, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->d(Landroidx/appcompat/view/menu/j;I)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3, v2}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemPosition(I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->d:Landroid/util/SparseArray;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v5, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    check-cast v5, Landroid/view/View$OnTouchListener;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->b:Landroid/view/View$OnClickListener;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v7, 0x2

    if-eqz v5, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ne v4, v5, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    iput v2, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, v3}, Lcom/google/android/material/navigation/NavigationBarMenuView;->setBadgeIfNeeded(Lcom/google/android/material/navigation/NavigationBarItemView;)V

    const/4 v7, 0x3

    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_7
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    sub-int/2addr v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    iput v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v6, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v0, v4}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-void
.end method

.method public e(I)Landroid/content/res/ColorStateList;
    .locals 9
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v0, Landroid/util/TypedValue;

    const/4 v8, 0x3

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v1, p1, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez p1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-object v1

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v3, v0, Landroid/util/TypedValue;->resourceId:I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {p1, v3}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    sget v4, Landroidx/appcompat/R$attr;->colorPrimary:I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v3, v4, v0, v2}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v3, :cond_1

    const/4 v7, 0x6

    or-int/2addr v8, v7

    return-object v1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x1

    iget v0, v0, Landroid/util/TypedValue;->data:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v3, Landroid/content/res/ColorStateList;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-array v4, v4, [[I

    const/4 v8, 0x6

    sget-object v5, Lcom/google/android/material/navigation/NavigationBarMenuView;->F:[I

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x1

    aput-object v5, v4, v6

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget-object v6, Lcom/google/android/material/navigation/NavigationBarMenuView;->E:[I

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    aput-object v6, v4, v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v2, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget-object v6, Landroid/view/ViewGroup;->EMPTY_STATE_SET:[I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    aput-object v6, v4, v2

    invoke-virtual {p1, v5, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    filled-new-array {p1, v0, v1}, [I

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {v3, v4, p1}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    return-object v3
.end method

.method protected abstract g(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarItemView;
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method getBadgeDrawables()Landroid/util/SparseArray;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/util/SparseArray<",
            "Lcom/google/android/material/badge/a;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    return-object v0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->i:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public getItemActiveIndicatorColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->z:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getItemActiveIndicatorEnabled()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->t:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getItemActiveIndicatorHeight()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->v:I

    return v0
.end method

.method public getItemActiveIndicatorMarginHorizontal()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->w:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getItemActiveIndicatorShapeAppearance()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->x:Lcom/google/android/material/shape/o;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getItemActiveIndicatorWidth()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->u:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getItemBackground()Landroid/graphics/drawable/Drawable;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    array-length v1, v0

    const/4 v3, 0x2

    if-lez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    aget-object v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->o:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method public getItemBackgroundRes()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->p:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getItemIconSize()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->j:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getItemPaddingBottom()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->s:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getItemPaddingTop()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->r:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getItemTextAppearanceActive()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->n:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public getItemTextAppearanceInactive()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public getItemTextColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->k:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getLabelVisibilityMode()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method protected getMenu()Landroidx/appcompat/view/menu/g;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getSelectedItemId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method protected getSelectedItemPosition()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getWindowAnimations()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public h(I)Lcom/google/android/material/navigation/NavigationBarItemView;
    .locals 7
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->t(I)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    array-length v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    if-ge v2, v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-object v3, v0, v2

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    invoke-virtual {v3}, Landroid/view/View;->getId()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ne v4, p1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object v3

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 p1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object p1
.end method

.method public i(I)Lcom/google/android/material/badge/a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    check-cast p1, Lcom/google/android/material/badge/a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method j(I)Lcom/google/android/material/badge/a;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->t(I)V

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/material/badge/a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/material/badge/a;->d(Landroid/content/Context;)Lcom/google/android/material/badge/a;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1, p1, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->h(I)Lcom/google/android/material/navigation/NavigationBarItemView;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/navigation/NavigationBarItemView;->setBadge(Lcom/google/android/material/badge/a;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method

.method protected k()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->y:Z

    const/4 v2, 0x6

    return v0
.end method

.method protected l(II)Z
    .locals 5

    const/4 v3, 0x2

    const/4 v0, -0x1

    move v4, v0

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-le p2, p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    if-nez p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v3, 0x1

    const/4 v4, 0x0

    return v1
.end method

.method n(I)V
    .locals 4

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->t(I)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/google/android/material/badge/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;->h(I)Lcom/google/android/material/navigation/NavigationBarItemView;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->p()V

    :cond_0
    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->remove(I)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 5
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Landroidx/core/view/accessibility/l0;->X1(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroidx/core/view/accessibility/l0;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v2, v0, v1, v2}, Landroidx/core/view/accessibility/l0$b;->f(IIZI)Landroidx/core/view/accessibility/l0$b;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->Y0(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method

.method p(Landroid/util/SparseArray;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray<",
            "Lcom/google/android/material/badge/a;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-ge v1, v2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-gez v3, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v3, v2, v4}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    array-length v1, p1

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ge v0, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    aget-object v2, p1, v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->q:Landroid/util/SparseArray;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v3, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    check-cast v3, Lcom/google/android/material/badge/a;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Lcom/google/android/material/navigation/NavigationBarItemView;->setBadge(Lcom/google/android/material/badge/a;)V

    const/4 v6, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-void
.end method

.method public q(ILandroid/view/View$OnTouchListener;)V
    .locals 7
    .param p2    # Landroid/view/View$OnTouchListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez p2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->d:Landroid/util/SparseArray;

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->remove(I)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->d:Landroid/util/SparseArray;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, p1, p2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :goto_0
    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x2

    array-length v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ge v2, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-object v3, v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/google/android/material/navigation/NavigationBarItemView;->getItemData()Landroidx/appcompat/view/menu/j;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v4, p1, :cond_1

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {v3, p2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    or-int/2addr v6, v5

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void
.end method

.method r(I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ge v1, v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v2}, Landroid/view/MenuItem;->getItemId()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne p1, v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    const/4 v4, 0x0

    move v5, v4

    const/4 p1, 0x1

    or-int/2addr v5, p1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v2, p1}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-void
.end method

.method public s()V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v0, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto/16 :goto_2

    :cond_0
    const/4 v6, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    array-length v1, v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eq v0, v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->d()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ge v3, v0, :cond_3

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-interface {v4}, Landroid/view/MenuItem;->isChecked()Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v5, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {v4}, Landroid/view/MenuItem;->getItemId()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->h:I

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->g:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eq v1, v3, :cond_4

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->a:Landroidx/transition/o0;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v1, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p0, v1}, Landroidx/transition/m0;->b(Landroid/view/ViewGroup;Landroidx/transition/j0;)V

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0, v1, v3}, Lcom/google/android/material/navigation/NavigationBarMenuView;->l(II)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v7, 0x0

    if-ge v3, v0, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v5, 0x1

    const/4 v7, 0x3

    invoke-virtual {v4, v5}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    aget-object v4, v4, v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Lcom/google/android/material/navigation/NavigationBarItemView;->setLabelVisibilityMode(I)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    aget-object v4, v4, v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setShifting(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v7, 0x0

    const/4 v6, 0x1

    aget-object v4, v4, v3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v5, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v5, v3}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast v5, Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v4, v5, v2}, Lcom/google/android/material/navigation/NavigationBarItemView;->d(Landroidx/appcompat/view/menu/j;I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v2}, Lcom/google/android/material/navigation/NavigationBarPresenter;->n(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_1

    :cond_5
    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    return-void
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)V
    .locals 6
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->i:Landroid/content/res/ColorStateList;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    aget-object v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setIconTintList(Landroid/content/res/ColorStateList;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method

.method public setItemActiveIndicatorColor(Landroid/content/res/ColorStateList;)V
    .locals 6
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->z:Landroid/content/res/ColorStateList;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v1, 0x4

    const/4 v5, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x2

    if-ge v1, v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    aget-object v2, p1, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method

.method public setItemActiveIndicatorEnabled(Z)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->t:Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    array-length v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ge v2, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    aget-object v3, v0, v2

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorEnabled(Z)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void
.end method

.method public setItemActiveIndicatorHeight(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x1

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->v:I

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    array-length v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    aget-object v3, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorHeight(I)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void
.end method

.method public setItemActiveIndicatorMarginHorizontal(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->w:I

    const/4 v4, 0x1

    move v5, v4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-object v3, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorMarginHorizontal(I)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void
.end method

.method protected setItemActiveIndicatorResizeable(Z)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->y:Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    array-length v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-ge v2, v1, :cond_0

    const/4 v5, 0x3

    aget-object v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorResizeable(Z)V

    const/4 v4, 0x3

    move v5, v4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void
.end method

.method public setItemActiveIndicatorShapeAppearance(Lcom/google/android/material/shape/o;)V
    .locals 6
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->x:Lcom/google/android/material/shape/o;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    array-length v0, p1

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    move v5, v4

    if-ge v1, v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    aget-object v2, p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->f()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public setItemActiveIndicatorWidth(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v5, 0x4

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->u:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    array-length v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ge v2, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    aget-object v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setActiveIndicatorWidth(I)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void
.end method

.method public setItemBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 6
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->o:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    array-length v1, v0

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x0

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v5, 0x2

    if-ge v2, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    aget-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    return-void
.end method

.method public setItemBackgroundRes(I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->p:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    aget-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemBackground(I)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method

.method public setItemIconSize(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->j:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    array-length v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    aget-object v3, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setIconSize(I)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void
.end method

.method public setItemPaddingBottom(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->s:I

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ge v2, v1, :cond_0

    const/4 v4, 0x4

    const/4 v4, 0x4

    aget-object v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemPaddingBottom(I)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method

.method public setItemPaddingTop(I)V
    .locals 6
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->r:I

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    array-length v1, v0

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x5

    xor-int/2addr v4, v2

    :goto_0
    const/4 v5, 0x6

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    aget-object v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setItemPaddingTop(I)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method public setItemTextAppearanceActive(I)V
    .locals 7
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->n:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    array-length v1, v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ge v2, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    aget-object v3, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextAppearanceActive(I)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->k:Landroid/content/res/ColorStateList;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-void
.end method

.method public setItemTextAppearanceInactive(I)V
    .locals 7
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->m:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    array-length v1, v0

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-ge v2, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    aget-object v3, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextAppearanceInactive(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->k:Landroid/content/res/ColorStateList;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method

.method public setItemTextColor(Landroid/content/res/ColorStateList;)V
    .locals 6
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->k:Landroid/content/res/ColorStateList;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->f:[Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    aget-object v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lcom/google/android/material/navigation/NavigationBarItemView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public setLabelVisibilityMode(I)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setPresenter(Lcom/google/android/material/navigation/NavigationBarPresenter;)V
    .locals 2
    .param p1    # Lcom/google/android/material/navigation/NavigationBarPresenter;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarMenuView;->A:Lcom/google/android/material/navigation/NavigationBarPresenter;

    const/4 v1, 0x6

    return-void
.end method
