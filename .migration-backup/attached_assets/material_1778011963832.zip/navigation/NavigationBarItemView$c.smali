.class Lcom/google/android/material/navigation/NavigationBarItemView$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/navigation/NavigationBarItemView;->n(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:F

.field final synthetic b:Lcom/google/android/material/navigation/NavigationBarItemView;


# direct methods
.method constructor <init>(Lcom/google/android/material/navigation/NavigationBarItemView;F)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/navigation/NavigationBarItemView$c;->b:Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/material/navigation/NavigationBarItemView$c;->a:F

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @sio ~~n@b. bSi@  @~ f@~~~@~ /o~M@ ~o1@ or~@@o~@d @~K@ t bs@lva ~4~  -@t ~@~~cm~y@u/f@~l~o i@~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast p1, Ljava/lang/Float;

    const/4 v2, 0x2

    or-int/2addr v3, v2

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/navigation/NavigationBarItemView$c;->b:Lcom/google/android/material/navigation/NavigationBarItemView;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/navigation/NavigationBarItemView$c;->a:F

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, p1, v1}, Lcom/google/android/material/navigation/NavigationBarItemView;->h(Lcom/google/android/material/navigation/NavigationBarItemView;FF)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method
