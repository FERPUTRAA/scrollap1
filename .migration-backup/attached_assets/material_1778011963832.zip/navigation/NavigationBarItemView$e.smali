.class Lcom/google/android/material/navigation/NavigationBarItemView$e;
.super Lcom/google/android/material/navigation/NavigationBarItemView$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/navigation/NavigationBarItemView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "e"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/material/navigation/NavigationBarItemView$d;-><init>(Lcom/google/android/material/navigation/NavigationBarItemView$a;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/navigation/NavigationBarItemView$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/navigation/NavigationBarItemView$e;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected c(FF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ts~oMnb@.~ o    o@mbo@c ~@@ i~@u-d@@o ~ry~~f~/~l@ ~S~~~ab@lfs@@~@@  K~ @~~i~~t  @o 4 @~~1 i@@v/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/navigation/NavigationBarItemView$d;->b(FF)F

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method
