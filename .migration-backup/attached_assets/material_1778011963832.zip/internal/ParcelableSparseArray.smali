.class public Lcom/google/android/material/internal/ParcelableSparseArray;
.super Landroid/util/SparseArray;

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/SparseArray<",
        "Landroid/os/Parcelable;",
        ">;",
        "Landroid/os/Parcelable;"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/material/internal/ParcelableSparseArray;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/internal/ParcelableSparseArray$a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/android/material/internal/ParcelableSparseArray$a;-><init>()V

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/material/internal/ParcelableSparseArray;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/util/SparseArray;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V
    .locals 6
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/ClassLoader;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p0}, Landroid/util/SparseArray;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-array v1, v0, [I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->readParcelableArray(Ljava/lang/ClassLoader;)[Landroid/os/Parcelable;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 p2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ge p2, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    aget v2, v1, p2

    const/4 v4, 0x1

    move v5, v4

    aget-object v3, p1, p2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/lit8 p2, p2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t@sa@ ~~~r~~ / K@@@@oMi@.o~vo~o t f~~l ~~~/~~@ @@o~f  @i @S~4n~  @~m@c u @ @ b@@~@~-b1 l@y~sod~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 7
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/util/SparseArray;->size()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-array v1, v0, [I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-array v2, v0, [Landroid/os/Parcelable;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ge v3, v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, v3}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    aput v4, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    check-cast v4, Landroid/os/Parcelable;

    const/4 v6, 0x2

    const/4 v5, 0x1

    aput-object v4, v2, v3

    const/4 v6, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1, v2, p2}, Landroid/os/Parcel;->writeParcelableArray([Landroid/os/Parcelable;I)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    return-void
.end method
