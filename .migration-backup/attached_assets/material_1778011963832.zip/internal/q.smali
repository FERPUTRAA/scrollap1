.class public final Lcom/google/android/material/internal/q;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final a:[I

.field private static final b:Ljava/lang/String; = "Theme.AppCompat"

.field private static final c:[I

.field private static final d:Ljava/lang/String; = "Theme.MaterialComponents"


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$attr;->colorPrimary:I

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/material/internal/q;->a:[I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$attr;->colorPrimaryVariant:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/material/internal/q;->c:[I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ias~@ o@1~~K u~v~~~l@c~-    fb@~@oSo y ~ M i@o@o@~r~ @~@n~lm~@~@@~ @d~/ s@@tbt@ o~@ ~.@if4/ b~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/material/internal/q;->a:[I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "Theme.AppCompat"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0, v0, v1}, Lcom/google/android/material/internal/q;->e(Landroid/content/Context;[ILjava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private static b(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v1, 0x2

    move v2, v1

    sget-object v0, Lcom/google/android/material/R$styleable;->ThemeEnforcement:[I

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0, p2, p3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->ThemeEnforcement_enforceMaterialTheme:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Landroid/util/TypedValue;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1}, Landroid/util/TypedValue;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget p3, Lcom/google/android/material/R$attr;->isMaterialTheme:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p2, p3, p1, v0}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p2, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget p2, p1, Landroid/util/TypedValue;->type:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/16 p3, 0x12

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ne p2, p3, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget p1, p1, Landroid/util/TypedValue;->data:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez p1, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/android/material/internal/q;->c(Landroid/content/Context;)V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/google/android/material/internal/q;->a(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    sget-object v0, Lcom/google/android/material/internal/q;->c:[I

    const/4 v3, 0x4

    const-string v1, "CMsrhanlTaeteooseempntm."

    const/4 v3, 0x0

    const-string/jumbo v1, "lmMmrsnThepaaoCoe.tmtein"

    const-string v1, "Theme.MaterialComponents"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, v0, v1}, Lcom/google/android/material/internal/q;->e(Landroid/content/Context;[ILjava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method private static varargs d(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p5    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v0, Lcom/google/android/material/R$styleable;->ThemeEnforcement:[I

    const/4 v4, 0x7

    invoke-virtual {p0, p1, v0, p3, p4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget v1, Lcom/google/android/material/R$styleable;->ThemeEnforcement_enforceTextAppearance:I

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p5, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    array-length v1, p5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static/range {p0 .. p5}, Lcom/google/android/material/internal/q;->g(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Z

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget p0, Lcom/google/android/material/R$styleable;->ThemeEnforcement_android_textAppearance:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p1, -0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p0, p1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eq p0, p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x1

    :cond_3
    const/4 v4, 0x4

    move p0, v2

    move p0, v2

    const/4 v4, 0x1

    move p0, v2

    move p0, v2

    :goto_1
    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :cond_4
    const/4 v3, 0x4

    move v4, v3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p1, "This component requires that you specify a valid TextAppearance attribute. Update your app theme to inherit from Theme.MaterialComponents (or a descendant)."

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    throw p0
.end method

.method private static e(Landroid/content/Context;[ILjava/lang/String;)V
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    move v2, v1

    invoke-static {p0, p1}, Lcom/google/android/material/internal/q;->i(Landroid/content/Context;[I)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "o nsoy iTaehenpr the rto  toubme hspceqe noretlpim su tye "

    const-string/jumbo v0, "toym toTe  nubeipp enoetc qoe psrsehs lhu m   heotartyiern"

    const/4 v2, 0x0

    const-string v0, "eelutbetnimp ucoooyr eqmehy eotb tha tsne   os r Tpsinhpre"

    const-string v0, "The style on this component requires your app theme to be "

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const-string/jumbo p2, "nt ds u.dna a(e)coe"

    const-string p2, " (or a descendant)."

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    throw p0
.end method

.method public static f(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/material/internal/q;->a:[I

    const/4 v1, 0x3

    move v2, v1

    invoke-static {p0, v0}, Lcom/google/android/material/internal/q;->i(Landroid/content/Context;[I)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p0
.end method

.method private static varargs g(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p5    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    array-length p1, p5

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 p2, 0x0

    and-int/2addr v2, p2

    const/4 v1, 0x0

    move v2, v1

    move p3, p2

    move p3, p2

    const/4 v2, 0x7

    move p3, p2

    move p3, p2

    :goto_0
    const/4 v2, 0x1

    if-ge p3, p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    aget p4, p5, p3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, -0x1

    invoke-virtual {p0, p4, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-ne p4, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p2

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    add-int/lit8 p3, p3, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x1

    const/4 v2, 0x3

    return p0
.end method

.method public static h(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/material/internal/q;->c:[I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/internal/q;->i(Landroid/content/Context;[I)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p0
.end method

.method private static i(Landroid/content/Context;[I)Z
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    move v4, v3

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    array-length v2, p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ge v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x7

    const/4 p0, 0x1

    const/4 v4, 0x5

    return p0
.end method

.method public static varargs j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p5    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1, p3, p4}, Lcom/google/android/material/internal/q;->b(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static/range {p0 .. p5}, Lcom/google/android/material/internal/q;->d(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public static varargs k(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroidx/appcompat/widget/n2;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p5    # [I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p3, p4}, Lcom/google/android/material/internal/q;->b(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-static/range {p0 .. p5}, Lcom/google/android/material/internal/q;->d(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1, p2, p3, p4}, Landroidx/appcompat/widget/n2;->G(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/n2;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method
