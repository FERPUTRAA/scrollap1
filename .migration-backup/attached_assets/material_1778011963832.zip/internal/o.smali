.class public Lcom/google/android/material/internal/o;
.super Landroidx/transition/j0;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final W:Ljava/lang/String; = "android:textscale:scale"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/transition/j0;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private A0(Landroidx/transition/r0;)V
    .locals 4
    .param p1    # Landroidx/transition/r0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~soo@~  ~i~sb~~ @b@~~4 f@i~@@@ @~~cl o@@@~@@ vo~S  @~u oaK~@~ /t@ ~1M~dr~~@@  /@yb-~tln~ fi  mo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p1, Landroidx/transition/r0;->b:Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x7

    instance-of v1, v0, Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p1, Landroidx/transition/r0;->a:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getScaleX()F

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const-string/jumbo v1, "rdameitns:xesaceatslco:"

    const-string v1, "edssil:tsnaccadra:teoxe"

    const/4 v3, 0x5

    const-string/jumbo v1, "rcdiotnel:al:cexetaasod"

    const-string v1, "android:textscale:scale"

    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public j(Landroidx/transition/r0;)V
    .locals 2
    .param p1    # Landroidx/transition/r0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/internal/o;->A0(Landroidx/transition/r0;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public m(Landroidx/transition/r0;)V
    .locals 2
    .param p1    # Landroidx/transition/r0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/internal/o;->A0(Landroidx/transition/r0;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public q(Landroid/view/ViewGroup;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;
    .locals 6
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/transition/r0;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroidx/transition/r0;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p2, :cond_4

    const/4 v4, 0x0

    move v5, v4

    if-eqz p3, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p2, Landroidx/transition/r0;->b:Landroid/view/View;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    instance-of v0, v0, Landroid/widget/TextView;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p3, Landroidx/transition/r0;->b:Landroid/view/View;

    const/4 v5, 0x7

    instance-of v1, v0, Landroid/widget/TextView;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v0, Landroid/widget/TextView;

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    iget-object p2, p2, Landroidx/transition/r0;->a:Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object p3, p3, Landroidx/transition/r0;->a:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v1, "xsilmbecldtncaartoesed:"

    const-string v1, "caemtrlioeneas:lcds:xtd"

    const/4 v5, 0x7

    const-string/jumbo v1, "xaoediudtcrl::asanselce"

    const-string v1, "android:textscale:scale"

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast p2, Ljava/lang/Float;

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    move p2, v3

    move p2, v3

    const/4 v5, 0x3

    move p2, v3

    move p2, v3

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {p3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    check-cast p3, Ljava/lang/Float;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    cmpl-float p3, p2, v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez p3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 p1, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-array p1, p1, [F

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 p3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    aput p2, p1, p3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 p2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    aput v3, p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance p2, Lcom/google/android/material/internal/o$a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p2, p0, v0}, Lcom/google/android/material/internal/o$a;-><init>(Lcom/google/android/material/internal/o;Landroid/widget/TextView;)V

    const/4 v5, 0x6

    invoke-virtual {p1, p2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    :cond_4
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p1
.end method
