.class public Lcom/google/android/material/internal/i;
.super Landroidx/appcompat/view/menu/g;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p2, Lcom/google/android/material/internal/k;

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object p3

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p2, p3, p0, p1}, Lcom/google/android/material/internal/k;-><init>(Landroid/content/Context;Lcom/google/android/material/internal/i;Landroidx/appcompat/view/menu/j;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/j;->A(Landroidx/appcompat/view/menu/s;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p2
.end method
