.class public Lcom/google/android/material/internal/ForegroundLinearLayout;
.super Landroidx/appcompat/widget/LinearLayoutCompat;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field private B:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final C:Landroid/graphics/Rect;

.field private final D:Landroid/graphics/Rect;

.field private E:I

.field protected F:Z

.field G:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/internal/ForegroundLinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/internal/ForegroundLinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 10
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v9, 0x1

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v0, Landroid/graphics/Rect;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    iput-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->C:Landroid/graphics/Rect;

    const/4 v8, 0x6

    shl-int/2addr v9, v8

    new-instance v0, Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    iput-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->D:Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/16 v0, 0x77

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    iput v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v0, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->F:Z

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    iput-boolean v1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    sget-object v4, Lcom/google/android/material/R$styleable;->ForegroundLinearLayout:[I

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v6, 0x0

    const/4 v9, 0x1

    new-array v7, v1, [I

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    move v5, p3

    const/4 v9, 0x4

    move v5, p3

    move v5, p3

    const/4 v8, 0x3

    move v9, v8

    invoke-static/range {v2 .. v7}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    sget p2, Lcom/google/android/material/R$styleable;->ForegroundLinearLayout_android_foregroundGravity:I

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget p3, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iput p2, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    sget p2, Lcom/google/android/material/R$styleable;->ForegroundLinearLayout_android_foreground:I

    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz p2, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/material/internal/ForegroundLinearLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v8, 0x2

    const/4 v9, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->ForegroundLinearLayout_foregroundInsidePadding:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->F:Z

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@~s~~/s  ~nly v  u @cmao o  @~~~@@S@@@ol~~@@ @~~MKo@  bf~@ ~~if ~~@~@@/ r~@~. @ db@t@o-~oi4b~1i~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-boolean v1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v1, :cond_1

    const/4 v8, 0x3

    and-int/2addr v9, v8

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    iput-boolean v1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->C:Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->D:Landroid/graphics/Rect;

    invoke-virtual {p0}, Landroid/view/View;->getRight()I

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    sub-int/2addr v4, v5

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x0

    sub-int/2addr v5, v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-boolean v6, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->F:Z

    const/4 v9, 0x1

    if-eqz v6, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v2, v1, v1, v4, v5}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v6

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v7

    const/4 v9, 0x2

    sub-int/2addr v4, v7

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v7

    const/4 v9, 0x1

    const/4 v8, 0x3

    sub-int/2addr v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2, v1, v6, v4, v5}, Landroid/graphics/Rect;->set(IIII)V

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget v1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v4

    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v1, v4, v5, v2, v3}, Landroid/view/Gravity;->apply(IIILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_1
    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    return-void
.end method

.method public drawableHotspotChanged(FF)V
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->drawableHotspotChanged(FF)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->setHotspot(FF)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method protected drawableStateChanged()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public getForeground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public getForegroundGravity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public jumpDrawablesToCurrentState()V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0xb
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-super {p0}, Landroid/view/ViewGroup;->jumpDrawablesToCurrentState()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x1

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/LinearLayoutCompat;->onLayout(ZIIII)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-boolean p2, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v1, 0x0

    or-int/2addr p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->G:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public setForeground(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eq v0, p1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0x77

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v0, v1, :cond_3

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->setWillNotDraw(Z)V

    :cond_3
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public setForegroundGravity(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    if-eq v0, p1, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const v0, 0x800007

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    and-int/2addr v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const v0, 0x800003

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    or-int/2addr p1, v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    and-int/lit8 v0, p1, 0x70

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x30

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->E:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 v0, 0x77

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ne p1, v0, :cond_2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    if-eqz p1, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method protected verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/internal/ForegroundLinearLayout;->B:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x1

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v1, 0x0

    const/4 v2, 0x1

    return p1
.end method
