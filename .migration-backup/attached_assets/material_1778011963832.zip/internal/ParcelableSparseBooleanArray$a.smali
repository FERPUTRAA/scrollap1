.class Lcom/google/android/material/internal/ParcelableSparseBooleanArray$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/ParcelableSparseBooleanArray;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/google/android/material/internal/ParcelableSparseBooleanArray;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/google/android/material/internal/ParcelableSparseBooleanArray;
    .locals 8
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " @svbio4~@r~  ~boSK   -@ u@~@@ls@~f @@@~~n./ci~t~~mol~@ /@ @@~@~y1bM @  ~@@  ~~d~~a~@~@~io f~o t"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v1, Lcom/google/android/material/internal/ParcelableSparseBooleanArray;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v1, v0}, Lcom/google/android/material/internal/ParcelableSparseBooleanArray;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-array v2, v0, [I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-array v3, v0, [Z

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readIntArray([I)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1, v3}, Landroid/os/Parcel;->readBooleanArray([Z)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ge p1, v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    aget v4, v2, p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    aget-boolean v5, v3, p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v5}, Landroid/util/SparseBooleanArray;->put(IZ)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object v1
.end method

.method public b(I)[Lcom/google/android/material/internal/ParcelableSparseBooleanArray;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    new-array p1, p1, [Lcom/google/android/material/internal/ParcelableSparseBooleanArray;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/ParcelableSparseBooleanArray$a;->a(Landroid/os/Parcel;)Lcom/google/android/material/internal/ParcelableSparseBooleanArray;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/ParcelableSparseBooleanArray$a;->b(I)[Lcom/google/android/material/internal/ParcelableSparseBooleanArray;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-object p1
.end method
