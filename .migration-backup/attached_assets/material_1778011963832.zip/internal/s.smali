.class Lcom/google/android/material/internal/s;
.super Lcom/google/android/material/internal/v;

# interfaces
.implements Lcom/google/android/material/internal/u;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/internal/v;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;)V

    const/4 v1, 0x2

    return-void
.end method

.method static f(Landroid/view/ViewGroup;)Lcom/google/android/material/internal/s;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s ~ /~oyb~t~mi@ @~f ~r~o i v@@bS@.@~ @@ @~@l o1ns@ @t@ u@~d~ b~Ka4@~i@/@~@~~@o ~~ l-~~Mco f o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/android/material/internal/v;->e(Landroid/view/View;)Lcom/google/android/material/internal/v;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    check-cast p0, Lcom/google/android/material/internal/s;

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public c(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/v;->a:Lcom/google/android/material/internal/v$a;

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/v$a;->b(Landroid/view/View;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public d(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/v;->a:Lcom/google/android/material/internal/v$a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/v$a;->h(Landroid/view/View;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method
