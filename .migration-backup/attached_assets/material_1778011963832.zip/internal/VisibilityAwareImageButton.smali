.class public Lcom/google/android/material/internal/VisibilityAwareImageButton;
.super Landroid/widget/ImageButton;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "AppCompatCustomView"
    }
.end annotation

.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field private a:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/internal/VisibilityAwareImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/internal/VisibilityAwareImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a:I

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final a(IZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s ~bc~@ @~s@MK nm~1 ~ud@~S~~i /i@~@~ boo of@@tv~l @@l @ a - ~.~~rof~ 4@o@t~@~b@o  ~~y@/~@  ~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setVisibility(I)V

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a:I

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public final getUserSetVisibility()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public setVisibility(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a(IZ)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method
