.class public Lcom/google/android/material/internal/y$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "f"
.end annotation


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I


# direct methods
.method public constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/android/material/internal/y$f;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p3, p0, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p4, p0, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/internal/y$f;)V
    .locals 3
    .param p1    # Lcom/google/android/material/internal/y$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p1, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p1, Lcom/google/android/material/internal/y$f;->b:I

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/material/internal/y$f;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p1, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v2, 0x5

    iget p1, p1, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/android/material/internal/y$f;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v3, p0, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v5, 0x5

    invoke-static {p1, v0, v1, v2, v3}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method
