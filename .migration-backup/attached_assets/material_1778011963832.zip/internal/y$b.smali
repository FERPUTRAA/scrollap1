.class Lcom/google/android/material/internal/y$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/internal/y;->c(Landroid/view/View;Landroid/util/AttributeSet;IILcom/google/android/material/internal/y$e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Z

.field final synthetic c:Z

.field final synthetic d:Lcom/google/android/material/internal/y$e;


# direct methods
.method constructor <init>(ZZZLcom/google/android/material/internal/y$e;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/internal/y$b;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/internal/y$b;->b:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p3, p0, Lcom/google/android/material/internal/y$b;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    iput-object p4, p0, Lcom/google/android/material/internal/y$b;->d:Lcom/google/android/material/internal/y$e;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;
    .locals 5
    .param p2    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/internal/y$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, ".~s@y@v @  @@ 4~@~u o@ ~~s~~tri c~o o@ @@/~o~ol@i no~/@~a 1@ ~id~ bSM@@~l@~fm~@fK-~b~t ~  ~@@~b@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/internal/y$b;->a:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroidx/core/view/y2;->o()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    iput v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-boolean v1, p0, Lcom/google/android/material/internal/y$b;->b:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    add-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    iput v1, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    iget v1, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v2

    const/4 v4, 0x2

    add-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    iput v1, p3, Lcom/google/android/material/internal/y$f;->a:I

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/internal/y$b;->c:Z

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    if-eqz v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    goto :goto_1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    add-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    iput v0, p3, Lcom/google/android/material/internal/y$f;->c:I

    :cond_4
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p3, p1}, Lcom/google/android/material/internal/y$f;->a(Landroid/view/View;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/y$b;->d:Lcom/google/android/material/internal/y$e;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0, p1, p2, p3}, Lcom/google/android/material/internal/y$e;->a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;

    move-result-object p2

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p2
.end method
