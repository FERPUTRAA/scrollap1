.class Lcom/google/android/material/internal/j$g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/j$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "g"
.end annotation


# instance fields
.field private final a:Landroidx/appcompat/view/menu/j;

.field b:Z


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/j;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/material/internal/j$g;->a:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Landroidx/appcompat/view/menu/j;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~so~~m@  b ~ ~@ @ ~.@~@K  ~o@@~ b~~s@1~d@ftcM@ r~@@i~i~t@ ~/@@@@ io/~@~lvo-a n o~@b @fo4~ l~uS~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/j$g;->a:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method
