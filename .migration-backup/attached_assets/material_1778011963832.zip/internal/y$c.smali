.class Lcom/google/android/material/internal/y$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/view/z0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/internal/y;->d(Landroid/view/View;Lcom/google/android/material/internal/y$e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/y$e;

.field final synthetic b:Lcom/google/android/material/internal/y$f;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/y$e;Lcom/google/android/material/internal/y$f;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/internal/y$c;->a:Lcom/google/android/material/internal/y$e;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/material/internal/y$c;->b:Lcom/google/android/material/internal/y$f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;)Landroidx/core/view/y2;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  sdbs~ @o~@ @~.K@b/~  c@@o@o@rn@@ ~ tu~i ~@@@l~iafy~@~~b  1fm@@o@M~t ~~~S ~@~ ~~~@~v ioo-@4~/l "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/y$c;->a:Lcom/google/android/material/internal/y$e;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Lcom/google/android/material/internal/y$f;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/android/material/internal/y$c;->b:Lcom/google/android/material/internal/y$f;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Lcom/google/android/material/internal/y$f;-><init>(Lcom/google/android/material/internal/y$f;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0, p1, p2, v1}, Lcom/google/android/material/internal/y$e;->a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    return-object p1
.end method
