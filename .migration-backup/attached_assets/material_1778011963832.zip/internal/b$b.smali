.class Lcom/google/android/material/internal/b$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/resources/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/internal/b;->s0(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/b;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/internal/b$b;->a:Lcom/google/android/material/internal/b;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Typeface;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@sin~~l@su~@@@ci~@ l~@fb@~rK ~M@@~o~ @ @~~~ m ~a~@ood@bS4@  ~o@~-t v~@@~   .oo t @ /~ ib~@1~f~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/b$b;->a:Lcom/google/android/material/internal/b;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->x0(Landroid/graphics/Typeface;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
