.class public Lcom/google/android/material/internal/n;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/internal/n$b;
    }
.end annotation


# instance fields
.field private final a:Landroid/text/TextPaint;

.field private final b:Lcom/google/android/material/resources/f;

.field private c:F

.field private d:Z

.field private e:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/google/android/material/internal/n$b;",
            ">;"
        }
    .end annotation
.end field

.field private f:Lcom/google/android/material/resources/d;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/android/material/internal/n$b;)V
    .locals 4
    .param p1    # Lcom/google/android/material/internal/n$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Landroid/text/TextPaint;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/material/internal/n$a;

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/internal/n$a;-><init>(Lcom/google/android/material/internal/n;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/internal/n;->b:Lcom/google/android/material/resources/f;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-boolean v1, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/material/internal/n;->e:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/n;->h(Lcom/google/android/material/internal/n$b;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/internal/n;Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput-boolean p1, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic b(Lcom/google/android/material/internal/n;)Ljava/lang/ref/WeakReference;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/internal/n;->e:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method private c(Ljava/lang/CharSequence;)F
    .locals 5
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/CharSequence;II)F

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    return p1
.end method


# virtual methods
.method public d()Lcom/google/android/material/resources/d;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/internal/n;->f:Lcom/google/android/material/resources/d;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public e()Landroid/text/TextPaint;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public f(Ljava/lang/String;)F
    .locals 3

    iget-boolean v0, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    iget p1, p0, Lcom/google/android/material/internal/n;->c:F

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/internal/n;->c(Ljava/lang/CharSequence;)F

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p1, p0, Lcom/google/android/material/internal/n;->c:F

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    return v0
.end method

.method public h(Lcom/google/android/material/internal/n$b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/internal/n$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/internal/n;->e:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public i(Lcom/google/android/material/resources/d;Landroid/content/Context;)V
    .locals 4
    .param p1    # Lcom/google/android/material/resources/d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/n;->f:Lcom/google/android/material/resources/d;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq v0, p1, :cond_2

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/google/android/material/internal/n;->f:Lcom/google/android/material/resources/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/internal/n;->b:Lcom/google/android/material/resources/f;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p2, v0, v1}, Lcom/google/android/material/resources/d;->o(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/n;->e:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/material/internal/n$b;

    const/4 v2, 0x3

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    iget-object v1, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/google/android/material/internal/n$b;->getState()[I

    move-result-object v0

    const/4 v3, 0x2

    iput-object v0, v1, Landroid/text/TextPaint;->drawableState:[I

    :cond_0
    iget-object v0, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/internal/n;->b:Lcom/google/android/material/resources/f;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, p2, v0, v1}, Lcom/google/android/material/resources/d;->n(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/internal/n;->d:Z

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/internal/n;->e:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p1, Lcom/google/android/material/internal/n$b;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1}, Lcom/google/android/material/internal/n$b;->a()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p1}, Lcom/google/android/material/internal/n$b;->getState()[I

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, p2}, Lcom/google/android/material/internal/n$b;->onStateChange([I)Z

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public j(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/internal/n;->d:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public k(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/n;->f:Lcom/google/android/material/resources/d;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/material/internal/n;->a:Landroid/text/TextPaint;

    iget-object v2, p0, Lcom/google/android/material/internal/n;->b:Lcom/google/android/material/resources/f;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/material/resources/d;->n(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method
