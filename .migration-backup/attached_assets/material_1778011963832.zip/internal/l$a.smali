.class Lcom/google/android/material/internal/l$a;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/l;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/l;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/internal/l$a;->a:Lcom/google/android/material/internal/l;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c so @ i~ b s@~~i@dM~@1~l@~u~4r  @~~o @K @~v@~@lb~/~@o~y@ ~ /b@@S@o~@a@o-.m@~ ~@ftfi ~ ~~   t@n~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/l$a;->a:Lcom/google/android/material/internal/l;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    iget-object v1, v0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object p1, v0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
