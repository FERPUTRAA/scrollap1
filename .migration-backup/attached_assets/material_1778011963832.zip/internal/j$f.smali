.class Lcom/google/android/material/internal/j$f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/j$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "f"
.end annotation


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/internal/j$f;->a:I

    const/4 v0, 0x2

    move v1, v0

    iput p2, p0, Lcom/google/android/material/internal/j$f;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/s~o/ ~@ f@~@ lS-u@~@dK ~~@@ cts @bbo~ on@.o if yt~@ro~1~~@ @@@@~~~ ~a~i4 @~lmi @  ~o @~@v ~@Mb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/internal/j$f;->b:I

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/internal/j$f;->a:I

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method
