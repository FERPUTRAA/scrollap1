.class final Lcom/google/android/material/internal/m;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/internal/m$a;
    }
.end annotation


# static fields
.field static final n:I

.field static final o:F = 0.0f

.field static final p:F = 1.0f

.field private static final q:Ljava/lang/String; = "android.text.TextDirectionHeuristic"

.field private static final r:Ljava/lang/String; = "android.text.TextDirectionHeuristics"

.field private static final s:Ljava/lang/String; = "LTR"

.field private static final t:Ljava/lang/String; = "RTL"

.field private static u:Z

.field private static v:Ljava/lang/reflect/Constructor;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/reflect/Constructor<",
            "Landroid/text/StaticLayout;",
            ">;"
        }
    .end annotation
.end field

.field private static w:Ljava/lang/Object;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# instance fields
.field private a:Ljava/lang/CharSequence;

.field private final b:Landroid/text/TextPaint;

.field private final c:I

.field private d:I

.field private e:I

.field private f:Landroid/text/Layout$Alignment;

.field private g:I

.field private h:F

.field private i:F

.field private j:I

.field private k:Z

.field private l:Z

.field private m:Landroid/text/TextUtils$TruncateAt;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput v0, Lcom/google/android/material/internal/m;->n:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/android/material/internal/m;->a:Ljava/lang/CharSequence;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/material/internal/m;->b:Landroid/text/TextPaint;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p3, p0, Lcom/google/android/material/internal/m;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x6

    iput p2, p0, Lcom/google/android/material/internal/m;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/internal/m;->e:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    sget-object p1, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/internal/m;->f:Landroid/text/Layout$Alignment;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    const p1, 0x7fffffff

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/internal/m;->h:F

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v0, 0x1

    move v1, v0

    iput p1, p0, Lcom/google/android/material/internal/m;->i:F

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    sget p1, Lcom/google/android/material/internal/m;->n:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/internal/m;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/internal/m;->k:Z

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/internal/m;->m:Landroid/text/TextUtils$TruncateAt;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private b()V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/material/internal/m$a;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~os b 1a@~~lo@i@@ ~~@~@ @f/K-c Mi4 ./ @@~@f  @@@v~@tSn@u~~o @~ oy~@s mt~b  drl@~~ ~b~  ~~@o~~~io"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    sget-boolean v0, Lcom/google/android/material/internal/m;->u:Z

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/internal/m;->l:Z

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    move v0, v2

    move v0, v2

    const/4 v7, 0x0

    move v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v0, v1

    move v0, v1

    const/4 v7, 0x2

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-class v3, Landroid/text/TextDirectionHeuristic;

    const-class v3, Landroid/text/TextDirectionHeuristic;

    const-class v3, Landroid/text/TextDirectionHeuristic;

    const-class v3, Landroid/text/TextDirectionHeuristic;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget-object v0, Landroid/text/TextDirectionHeuristics;->RTL:Landroid/text/TextDirectionHeuristic;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v0, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    sput-object v0, Lcom/google/android/material/internal/m;->w:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 v0, 0xd

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-array v0, v0, [Ljava/lang/Class;

    const/4 v7, 0x2

    const-class v4, Ljava/lang/CharSequence;

    const-class v4, Ljava/lang/CharSequence;

    const/4 v7, 0x3

    const-class v4, Ljava/lang/CharSequence;

    const-class v4, Ljava/lang/CharSequence;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-object v4, v0, v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    aput-object v1, v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v4, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    aput-object v1, v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-class v4, Landroid/text/TextPaint;

    const-class v4, Landroid/text/TextPaint;

    const/4 v7, 0x1

    const-class v4, Landroid/text/TextPaint;

    const-class v4, Landroid/text/TextPaint;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v5, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    aput-object v4, v0, v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v4, 0x4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    aput-object v1, v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-class v4, Landroid/text/Layout$Alignment;

    const-class v4, Landroid/text/Layout$Alignment;

    const/4 v7, 0x7

    const-class v4, Landroid/text/Layout$Alignment;

    const-class v4, Landroid/text/Layout$Alignment;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v5, 0x5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    aput-object v4, v0, v5

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v4, 0x6

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    aput-object v3, v0, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    sget-object v3, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v4, 0x7

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    aput-object v3, v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/16 v4, 0x8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    aput-object v3, v0, v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x6

    move v7, v6

    const/16 v4, 0x9

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    aput-object v3, v0, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-class v3, Landroid/text/TextUtils$TruncateAt;

    const-class v3, Landroid/text/TextUtils$TruncateAt;

    const/4 v7, 0x5

    const-class v3, Landroid/text/TextUtils$TruncateAt;

    const-class v3, Landroid/text/TextUtils$TruncateAt;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/16 v4, 0xa

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-object v3, v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v3, 0xb

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    aput-object v1, v0, v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v3, 0xc

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    aput-object v1, v0, v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-class v1, Landroid/text/StaticLayout;

    const-class v1, Landroid/text/StaticLayout;

    const/4 v7, 0x7

    const-class v1, Landroid/text/StaticLayout;

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    sput-object v0, Lcom/google/android/material/internal/m;->v:Ljava/lang/reflect/Constructor;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    sput-boolean v2, Lcom/google/android/material/internal/m;->u:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Lcom/google/android/material/internal/m$a;

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v1, v0}, Lcom/google/android/material/internal/m$a;-><init>(Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    throw v1
.end method

.method public static c(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)Lcom/google/android/material/internal/m;
    .locals 3
    .param p0    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/internal/m;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, p2}, Lcom/google/android/material/internal/m;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public a()Landroid/text/StaticLayout;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/material/internal/m$a;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/android/material/internal/m;->a:Ljava/lang/CharSequence;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/google/android/material/internal/m;->a:Ljava/lang/CharSequence;

    :cond_0
    const/4 v6, 0x5

    move v7, v6

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/android/material/internal/m;->c:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/android/material/internal/m;->a:Ljava/lang/CharSequence;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v2, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v3, 0x1

    const/4 v7, 0x7

    if-ne v2, v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/material/internal/m;->b:Landroid/text/TextPaint;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    int-to-float v4, v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v5, p0, Lcom/google/android/material/internal/m;->m:Landroid/text/TextUtils$TruncateAt;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v1, v2, v4, v5}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v4, p0, Lcom/google/android/material/internal/m;->e:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput v2, p0, Lcom/google/android/material/internal/m;->e:I

    const/4 v7, 0x7

    iget-boolean v4, p0, Lcom/google/android/material/internal/m;->l:Z

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget v4, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-ne v4, v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v4, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-object v4, p0, Lcom/google/android/material/internal/m;->f:Landroid/text/Layout$Alignment;

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x2

    iget v4, p0, Lcom/google/android/material/internal/m;->d:I

    const/4 v7, 0x2

    iget-object v5, p0, Lcom/google/android/material/internal/m;->b:Landroid/text/TextPaint;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v1, v4, v2, v5, v0}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/internal/m;->f:Landroid/text/Layout$Alignment;

    const/4 v6, 0x6

    or-int/2addr v7, v6

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-boolean v1, p0, Lcom/google/android/material/internal/m;->k:Z

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/internal/m;->l:Z

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    sget-object v1, Landroid/text/TextDirectionHeuristics;->RTL:Landroid/text/TextDirectionHeuristic;

    const/4 v7, 0x5

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v1, Landroid/text/TextDirectionHeuristics;->LTR:Landroid/text/TextDirectionHeuristic;

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setTextDirection(Landroid/text/TextDirectionHeuristic;)Landroid/text/StaticLayout$Builder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/internal/m;->m:Landroid/text/TextUtils$TruncateAt;

    const/4 v6, 0x4

    and-int/2addr v7, v6

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v1, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v1, p0, Lcom/google/android/material/internal/m;->h:F

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    cmpl-float v2, v1, v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v2, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v2, p0, Lcom/google/android/material/internal/m;->i:F

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    cmpl-float v2, v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v2, :cond_6

    :cond_5
    const/4 v7, 0x2

    iget v2, p0, Lcom/google/android/material/internal/m;->i:F

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/text/StaticLayout$Builder;->setLineSpacing(FF)Landroid/text/StaticLayout$Builder;

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v1, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v6, 0x1

    move v7, v6

    if-le v1, v3, :cond_7

    const/4 v7, 0x4

    iget v1, p0, Lcom/google/android/material/internal/m;->j:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/text/StaticLayout$Builder;->setHyphenationFrequency(I)Landroid/text/StaticLayout$Builder;

    :cond_7
    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-object v0
.end method

.method public d(Landroid/text/Layout$Alignment;)Lcom/google/android/material/internal/m;
    .locals 2
    .param p1    # Landroid/text/Layout$Alignment;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/internal/m;->f:Landroid/text/Layout$Alignment;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public e(Landroid/text/TextUtils$TruncateAt;)Lcom/google/android/material/internal/m;
    .locals 2
    .param p1    # Landroid/text/TextUtils$TruncateAt;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    iput-object p1, p0, Lcom/google/android/material/internal/m;->m:Landroid/text/TextUtils$TruncateAt;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public f(I)Lcom/google/android/material/internal/m;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/internal/m;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public g(I)Lcom/google/android/material/internal/m;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/internal/m;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public h(Z)Lcom/google/android/material/internal/m;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/internal/m;->k:Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public i(Z)Lcom/google/android/material/internal/m;
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/internal/m;->l:Z

    const/4 v0, 0x7

    move v1, v0

    return-object p0
.end method

.method public j(FF)Lcom/google/android/material/internal/m;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/internal/m;->h:F

    const/4 v1, 0x7

    const/4 v0, 0x5

    iput p2, p0, Lcom/google/android/material/internal/m;->i:F

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public k(I)Lcom/google/android/material/internal/m;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    iput p1, p0, Lcom/google/android/material/internal/m;->g:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public l(I)Lcom/google/android/material/internal/m;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/internal/m;->d:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method
