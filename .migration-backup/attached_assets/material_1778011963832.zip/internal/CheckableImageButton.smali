.class public Lcom/google/android/material/internal/CheckableImageButton;
.super Landroidx/appcompat/widget/AppCompatImageButton;

# interfaces
.implements Landroid/widget/Checkable;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/internal/CheckableImageButton$SavedState;
    }
.end annotation


# static fields
.field private static final g:[I


# instance fields
.field private d:Z

.field private e:Z

.field private f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const v0, 0x10100a0

    const/4 v2, 0x1

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/internal/CheckableImageButton;->g:[I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/internal/CheckableImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget v0, Landroidx/appcompat/R$attr;->imageButtonStyle:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/internal/CheckableImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/internal/CheckableImageButton;->e:Z

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Lcom/google/android/material/internal/CheckableImageButton$a;

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-direct {p1, p0}, Lcom/google/android/material/internal/CheckableImageButton$a;-><init>(Lcom/google/android/material/internal/CheckableImageButton;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~so o@~@~l~~~ @a~@1  dro@m K@~f@/~4o~@@b~n@@ ~~ lo ut. My@@@bf i @@~@~@~~@~o St~s/@~~~v i -cb  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public isChecked()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public onCreateDrawableState(I)[I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/google/android/material/internal/CheckableImageButton;->g:[I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    array-length v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr p1, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/android/material/internal/CheckableImageButton$SavedState;

    const/4 v2, 0x6

    const/4 v1, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/material/internal/CheckableImageButton$SavedState;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-super {p0, v0}, Landroid/widget/ImageButton;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean p1, p1, Lcom/google/android/material/internal/CheckableImageButton$SavedState;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/CheckableImageButton;->setChecked(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/widget/ImageButton;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/google/android/material/internal/CheckableImageButton$SavedState;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v1, v0}, Lcom/google/android/material/internal/CheckableImageButton$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-boolean v0, v1, Lcom/google/android/material/internal/CheckableImageButton$SavedState;->c:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v1
.end method

.method public setCheckable(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/internal/CheckableImageButton;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->sendAccessibilityEvent(I)V

    :cond_0
    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public setChecked(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    const/4 v2, 0x7

    const/16 p1, 0x800

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->sendAccessibilityEvent(I)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setPressable(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public setPressed(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->f:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setPressed(Z)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public toggle()V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/internal/CheckableImageButton;->d:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/internal/CheckableImageButton;->setChecked(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
