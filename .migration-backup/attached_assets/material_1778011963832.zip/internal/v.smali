.class Lcom/google/android/material/internal/v;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/x;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/internal/v$a;
    }
.end annotation


# instance fields
.field protected a:Lcom/google/android/material/internal/v$a;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/internal/v$a;

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0, p1, p2, p3, p0}, Lcom/google/android/material/internal/v$a;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;Lcom/google/android/material/internal/v;)V

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/internal/v;->a:Lcom/google/android/material/internal/v$a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method static e(Landroid/view/View;)Lcom/google/android/material/internal/v;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  s 41/@@ @i@ t/~~@b~ob~sro@@@@@ ~@@ ~~ y l K~t~~@~@@m@M@@ @oo~~ ~b~S~ ~do@ l~ii~f  c. nv~o~ua-f"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    invoke-static {p0}, Lcom/google/android/material/internal/y;->g(Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v2, v1, :cond_1

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    instance-of v4, v3, Lcom/google/android/material/internal/v$a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v3, Lcom/google/android/material/internal/v$a;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object p0, v3, Lcom/google/android/material/internal/v$a;->d:Lcom/google/android/material/internal/v;

    const/4 v6, 0x0

    const/4 v5, 0x3

    return-object p0

    :cond_0
    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v1, Lcom/google/android/material/internal/s;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1, v2, v0, p0}, Lcom/google/android/material/internal/s;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-object v1

    :cond_2
    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 p0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    return-object p0
.end method


# virtual methods
.method public a(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/v;->a:Lcom/google/android/material/internal/v$a;

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/v$a;->a(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public b(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/v;->a:Lcom/google/android/material/internal/v$a;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/v$a;->g(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
