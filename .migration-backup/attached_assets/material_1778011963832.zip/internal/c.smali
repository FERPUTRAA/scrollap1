.class public Lcom/google/android/material/internal/c;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/Context;)Landroid/app/Activity;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    :goto_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@s@~@@t~ii @ d@soS1lo~bo@ ~ v ~  @ ~r~~n@i~ ~ol~@4~ ~ ./~ @@@ Mubm ~tc~~@ o~@~/f-fbo@@~  a~K@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    instance-of v0, p0, Landroid/content/ContextWrapper;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Landroid/app/Activity;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p0, Landroid/content/ContextWrapper;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method
