.class public Lcom/google/android/material/internal/ScrimInsetsFrameLayout;
.super Landroid/widget/FrameLayout;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field a:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field b:Landroid/graphics/Rect;

.field private c:Landroid/graphics/Rect;

.field private d:Z

.field private e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v0, Landroid/graphics/Rect;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    iput-object v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v7, 0x0

    shr-int/2addr v8, v7

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->d:Z

    const/4 v7, 0x1

    or-int/2addr v8, v7

    iput-boolean v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->e:Z

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget-object v3, Lcom/google/android/material/R$styleable;->ScrimInsetsFrameLayout:[I

    const/4 v7, 0x4

    move v8, v7

    sget v5, Lcom/google/android/material/R$style;->Widget_Design_ScrimInsetsFrameLayout:I

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-array v6, v1, [I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    move v4, p3

    move v4, p3

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-static/range {v1 .. v6}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->ScrimInsetsFrameLayout_insetForeground:I

    const/4 v8, 0x6

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object p2, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance p1, Lcom/google/android/material/internal/ScrimInsetsFrameLayout$a;

    invoke-direct {p1, p0}, Lcom/google/android/material/internal/ScrimInsetsFrameLayout$a;-><init>(Lcom/google/android/material/internal/ScrimInsetsFrameLayout;)V

    const/4 v7, 0x3

    const/4 v7, 0x3

    invoke-static {p0, p1}, Landroidx/core/view/k1;->a2(Landroid/view/View;Landroidx/core/view/z0;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method protected a(Landroidx/core/view/y2;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~is/ m@t@~ K~@~ ~o  o@fua~~1~@ if~~@l~d~@~M~@~oo4s  o@@ @.~  ~o   y/bv~c nb@b@~li @S@tr@@@-~~~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->draw(Landroid/graphics/Canvas;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->b:Landroid/graphics/Rect;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v2, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-eqz v2, :cond_2

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    int-to-float v3, v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    int-to-float v4, v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-boolean v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->d:Z

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-eqz v3, :cond_0

    const/4 v8, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->b:Landroid/graphics/Rect;

    const/4 v8, 0x7

    move v9, v8

    iget v5, v5, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x7

    invoke-virtual {v3, v4, v4, v0, v5}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-boolean v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->e:Z

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v3, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->b:Landroid/graphics/Rect;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    sub-int v5, v1, v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v3, v4, v5, v0, v1}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->b:Landroid/graphics/Rect;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget v6, v5, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget v7, v5, Landroid/graphics/Rect;->left:I

    const/4 v9, 0x4

    const/4 v8, 0x2

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    sub-int v5, v1, v5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v3, v4, v6, v7, v5}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v3, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->b:Landroid/graphics/Rect;

    const/4 v9, 0x7

    iget v5, v4, Landroid/graphics/Rect;->right:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    sub-int v5, v0, v5

    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget v6, v4, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x0

    sub-int/2addr v1, v4

    const/4 v9, 0x6

    invoke-virtual {v3, v5, v6, v0, v1}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->c:Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v9, 0x7

    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-void
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public setDrawBottomInsetForeground(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->e:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setDrawTopInsetForeground(Z)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iput-boolean p1, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->d:Z

    const/4 v0, 0x2

    shl-int/2addr v1, v0

    return-void
.end method

.method public setScrimInsetForeground(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/internal/ScrimInsetsFrameLayout;->a:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
