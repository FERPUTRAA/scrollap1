.class Lcom/google/android/material/internal/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/resources/a$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/internal/b;->h0(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/b;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/internal/b$a;->a:Lcom/google/android/material/internal/b;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Typeface;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " Ms/@Kb@ @@n~ @m@ i o l -~@@~@~@f4yt  b r@ab@o@c~d@@i o~ f. ~~ /S@~~s~ou@~o~@l~~ ~v~~o~~1 ~@ti~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/internal/b$a;->a:Lcom/google/android/material/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/b;->m0(Landroid/graphics/Typeface;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
