.class Lcom/google/android/material/internal/j$h;
.super Landroidx/recyclerview/widget/b0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "h"
.end annotation


# instance fields
.field final synthetic c:Lcom/google/android/material/internal/j;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/j;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2
    .param p1    # Lcom/google/android/material/internal/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/internal/j$h;->c:Lcom/google/android/material/internal/j;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/b0;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V
    .locals 3
    .param p2    # Landroidx/core/view/accessibility/l0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ss ~@~@d@b MK~r@l ~~yb@@  i-~b @ tc~@n@~ov@~~ @/ ~ ~~o@4@ ~o f @oiiu @@a~@.@ ~~~~~m/S~l @o1fot "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/b0;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/internal/j$h;->c:Lcom/google/android/material/internal/j;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p1, p1, Lcom/google/android/material/internal/j;->f:Lcom/google/android/material/internal/j$c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/internal/j$c;->d()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0, v0}, Landroidx/core/view/accessibility/l0$b;->e(IIZ)Landroidx/core/view/accessibility/l0$b;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->Y0(Ljava/lang/Object;)V

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
