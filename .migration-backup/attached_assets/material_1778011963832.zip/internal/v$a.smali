.class Lcom/google/android/material/internal/v$a;
.super Landroid/view/ViewGroup;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "ViewConstructor",
        "PrivateApi"
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field static f:Ljava/lang/reflect/Method;


# instance fields
.field a:Landroid/view/ViewGroup;

.field b:Landroid/view/View;

.field c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/graphics/drawable/Drawable;",
            ">;"
        }
    .end annotation
.end field

.field d:Lcom/google/android/material/internal/v;

.field private e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 7

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-class v0, Landroid/view/ViewGroup;

    const-class v0, Landroid/view/ViewGroup;

    const/4 v6, 0x4

    const-class v0, Landroid/view/ViewGroup;

    const-class v0, Landroid/view/ViewGroup;

    const/4 v6, 0x7

    const-string/jumbo v1, "lasnriCPeaaIanetshstinviddl"

    const-string v1, "aisvdeeFCrdstPnhnatllianaIi"

    const/4 v6, 0x3

    const-string v1, "annmnveitCirItPaiaelhsldFta"

    const-string/jumbo v1, "invalidateChildInParentFast"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x3

    const/4 v5, 0x1

    move v6, v5

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    const/4 v4, 0x0

    move v6, v4

    const/4 v5, 0x0

    move v6, v5

    aput-object v3, v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x4

    aput-object v3, v2, v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-class v3, Landroid/graphics/Rect;

    const-class v3, Landroid/graphics/Rect;

    const/4 v6, 0x5

    const-class v3, Landroid/graphics/Rect;

    const-class v3, Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    move v6, v5

    aput-object v3, v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object v0, Lcom/google/android/material/internal/v$a;->f:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/view/View;Lcom/google/android/material/internal/v;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p3, p0, Lcom/google/android/material/internal/v$a;->b:Landroid/view/View;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setRight(I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setBottom(I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p2, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    iput-object p4, p0, Lcom/google/android/material/internal/v$a;->d:Lcom/google/android/material/internal/v;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method private c()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  l@o o@ ~t /~@i o@ l ~@  ~b-i~@ @~ob@a~~t@@@onK/S ~o s~u@f1 r~vdi  ~@@~4@f@m@~~~~ o~@~~~M.y~@b@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/internal/v$a;->e:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, " wiavbeas.r onw.leyspe iaGtPss(eaymdasoa h  lsd epgTea ruarvli ioeeenV w eysdr)ulovOeUi"

    const-string v1, " (nmysnwtrer usipleo visy)e.aalhliiUe e  ipadsres vae.aw eweseardv ylodToP GsaOao uVleg"

    const/4 v3, 0x0

    const-string/jumbo v1, "is)wipuaioiaw yosl(GlVeavessd  dawp lrls PgvroaaT hUsl sdu ye.ttean.uneiveere ye  Oaere"

    const-string v1, "This overlay was disposed already. Please use a new one via ViewGroupUtils.getOverlay()"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    throw v0
.end method

.method private d()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/internal/v$a;->e:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private e([I)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v1, v0, [I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/android/material/internal/v$a;->b:Landroid/view/View;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    aget v3, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    aget v4, v1, v2

    sub-int/2addr v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    aput v3, p1, v2

    const/4 v5, 0x7

    move v6, v5

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    aget v0, v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    aget v1, v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    sub-int/2addr v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput v0, p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/internal/v$a;->c()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public b(Landroid/view/View;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/google/android/material/internal/v$a;->c()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    instance-of v0, v0, Landroid/view/ViewGroup;

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eq v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0}, Landroidx/core/view/k1;->O0(Landroid/view/View;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v1, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-array v2, v1, [I

    const/4 v5, 0x2

    move v6, v5

    new-array v1, v1, [I

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v0, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    aget v4, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget v3, v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    sub-int/2addr v4, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1, v4}, Landroidx/core/view/k1;->e1(Landroid/view/View;I)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget v2, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    aget v1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p1, v2}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void
.end method

.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v5, 0x6

    move v6, v5

    const/4 v0, 0x2

    move v6, v0

    const/4 v5, 0x2

    and-int/2addr v6, v5

    new-array v1, v0, [I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-array v0, v0, [I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/google/android/material/internal/v$a;->b:Landroid/view/View;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    aget v3, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    aget v4, v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    sub-int/2addr v3, v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    int-to-float v3, v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    aget v0, v0, v4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    aget v1, v1, v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    sub-int/2addr v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    int-to-float v0, v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, v3, v0}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v0, Landroid/graphics/Rect;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/material/internal/v$a;->b:Landroid/view/View;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/material/internal/v$a;->b:Landroid/view/View;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v0, v2, v2, v1, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x4

    and-int/2addr v6, v5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ge v2, v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v1, Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method public dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x0

    and-int/2addr v1, v0

    return p1
.end method

.method protected f(IILandroid/graphics/Rect;)Landroid/view/ViewParent;
    .locals 7
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object v0, Lcom/google/android/material/internal/v$a;->f:Ljava/lang/reflect/Method;

    const/4 v6, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v0, 0x2

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-array v1, v0, [I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/internal/v$a;->e([I)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v1, Lcom/google/android/material/internal/v$a;->f:Ljava/lang/reflect/Method;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v5, 0x3

    move v6, v5

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    aput-object p1, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 p2, 0x1

    const/4 p2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    aput-object p1, v3, p2

    aput-object p3, v3, v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :catch_1
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    return-object p1
.end method

.method public g(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/internal/v$a;->d()V

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public h(Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    invoke-direct {p0}, Lcom/google/android/material/internal/v$a;->d()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public invalidateChildInParent([ILandroid/graphics/Rect;)Landroid/view/ViewParent;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    and-int/2addr v5, v0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    aget v1, p1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    aget v3, p1, v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p2, v1, v3}, Landroid/graphics/Rect;->offset(II)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/material/internal/v$a;->a:Landroid/view/ViewGroup;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    aput v0, p1, v0

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput v0, p1, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-array v1, v1, [I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p0, v1}, Lcom/google/android/material/internal/v$a;->e([I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    aget v0, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    aget v1, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2, v0, v1}, Landroid/graphics/Rect;->offset(II)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->invalidateChildInParent([ILandroid/graphics/Rect;)Landroid/view/ViewParent;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object p1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0, p2}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-object p1
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroid/view/View;->invalidate(Landroid/graphics/Rect;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method protected verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/internal/v$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1
.end method
