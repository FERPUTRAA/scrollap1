.class Lcom/google/android/material/internal/j$b;
.super Lcom/google/android/material/internal/j$l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/internal/j$l;-><init>(Landroid/view/View;)V

    const/4 v1, 0x2

    return-void
.end method
