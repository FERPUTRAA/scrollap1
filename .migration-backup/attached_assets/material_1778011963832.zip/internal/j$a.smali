.class Lcom/google/android/material/internal/j$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/j;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/j;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    check-cast p1, Lcom/google/android/material/internal/NavigationMenuItemView;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/internal/j;->Z(Z)V

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-virtual {p1}, Lcom/google/android/material/internal/NavigationMenuItemView;->getItemData()Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, v0, Lcom/google/android/material/internal/j;->d:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2, p1, v0, v3}, Landroidx/appcompat/view/menu/g;->P(Landroid/view/MenuItem;Landroidx/appcompat/view/menu/n;I)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isCheckable()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/google/android/material/internal/j;->f:Lcom/google/android/material/internal/j$c;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/j$c;->j(Landroidx/appcompat/view/menu/j;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    move v1, v3

    move v1, v3

    const/4 v5, 0x1

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, v3}, Lcom/google/android/material/internal/j;->Z(Z)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/google/android/material/internal/j$a;->a:Lcom/google/android/material/internal/j;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1, v3}, Lcom/google/android/material/internal/j;->j(Z)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void
.end method
