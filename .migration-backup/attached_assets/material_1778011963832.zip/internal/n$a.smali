.class Lcom/google/android/material/internal/n$a;
.super Lcom/google/android/material/resources/f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/internal/n;


# direct methods
.method constructor <init>(Lcom/google/android/material/internal/n;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/internal/n$a;->a:Lcom/google/android/material/internal/n;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/resources/f;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~o/~s~~    @Sl @.@f~i c@n/  ~~b~~i@M@tm@@b@~@a@u@b~y@~~@o~~ ooo r~ ~~ @o 4@id-~@f t vK~l~@~ 1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/internal/n$a;->a:Lcom/google/android/material/internal/n;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/material/internal/n;->a(Lcom/google/android/material/internal/n;Z)Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/internal/n$a;->a:Lcom/google/android/material/internal/n;

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/material/internal/n;->b(Lcom/google/android/material/internal/n;)Ljava/lang/ref/WeakReference;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/material/internal/n$b;

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    invoke-interface {p1}, Lcom/google/android/material/internal/n$b;->a()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public b(Landroid/graphics/Typeface;Z)V
    .locals 2
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    iget-object p1, p0, Lcom/google/android/material/internal/n$a;->a:Lcom/google/android/material/internal/n;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p2, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/android/material/internal/n;->a(Lcom/google/android/material/internal/n;Z)Z

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/material/internal/n$a;->a:Lcom/google/android/material/internal/n;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/material/internal/n;->b(Lcom/google/android/material/internal/n;)Ljava/lang/ref/WeakReference;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/material/internal/n$b;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-interface {p1}, Lcom/google/android/material/internal/n$b;->a()V

    :cond_1
    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method
