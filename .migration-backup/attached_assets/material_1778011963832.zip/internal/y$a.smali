.class Lcom/google/android/material/internal/y$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/internal/y;->p(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/internal/y$a;->a:Landroid/view/View;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~rs -@~@ /@m~4@~  l~~~@~@~@ ~ o~~@a ot@dt@~vbo n @o ~b~@~ of@~@@ .K~~~i@ ~@ /@s1cM@i@S~u fbl  io"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/internal/y$a;->a:Landroid/view/View;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "oimmnsth_ued"

    const-string v1, "_usmpodenthi"

    const/4 v4, 0x4

    const-string/jumbo v1, "t_hoontuepdm"

    const-string/jumbo v1, "input_method"

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/internal/y$a;->a:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method
