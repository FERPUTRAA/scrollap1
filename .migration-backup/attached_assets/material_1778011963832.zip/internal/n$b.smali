.class public interface abstract Lcom/google/android/material/internal/n$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract a()V
.end method

.method public abstract getState()[I
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method

.method public abstract onStateChange([I)Z
.end method
