.class Lcom/google/android/material/internal/j$k;
.super Lcom/google/android/material/internal/j$l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/internal/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "k"
.end annotation


# direct methods
.method public constructor <init>(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)V
    .locals 4
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget v0, Lcom/google/android/material/R$layout;->design_navigation_item_subheader:I

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    move v2, v1

    move v2, v1

    const/4 v3, 0x1

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/internal/j$l;-><init>(Landroid/view/View;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method
