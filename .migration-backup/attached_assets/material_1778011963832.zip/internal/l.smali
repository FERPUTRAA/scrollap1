.class public final Lcom/google/android/material/internal/l;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/internal/l$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/google/android/material/internal/l$b;",
            ">;"
        }
    .end annotation
.end field

.field private b:Lcom/google/android/material/internal/l$b;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field c:Landroid/animation/ValueAnimator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final d:Landroid/animation/Animator$AnimatorListener;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/internal/l;->a:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/internal/l;->b:Lcom/google/android/material/internal/l$b;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    new-instance v0, Lcom/google/android/material/internal/l$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/internal/l$a;-><init>(Lcom/google/android/material/internal/l;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/internal/l;->d:Landroid/animation/Animator$AnimatorListener;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method private b()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ncs-i~~~orb@~1~@ti~~i@~@@ ~@ /.o@~v~K @@la@ ~@~fst    @~ ~ @@u~S@~yb4@bl oo M ~/~@@~m~f~ @oo  @d"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method private e(Lcom/google/android/material/internal/l$b;)V
    .locals 2
    .param p1    # Lcom/google/android/material/internal/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p1, p1, Lcom/google/android/material/internal/l$b;->b:Landroid/animation/ValueAnimator;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a([ILandroid/animation/ValueAnimator;)V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/internal/l$b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2}, Lcom/google/android/material/internal/l$b;-><init>([ILandroid/animation/ValueAnimator;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/internal/l;->d:Landroid/animation/Animator$AnimatorListener;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p2, p1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/internal/l;->a:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->end()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/internal/l;->c:Landroid/animation/ValueAnimator;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public d([I)V
    .locals 6

    const/4 v4, 0x6

    move v5, v4

    iget-object v0, p0, Lcom/google/android/material/internal/l;->a:Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v1, v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/internal/l;->a:Ljava/util/ArrayList;

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    check-cast v2, Lcom/google/android/material/internal/l$b;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, v2, Lcom/google/android/material/internal/l$b;->a:[I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v3, p1}, Landroid/util/StateSet;->stateSetMatches([I[I)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v2, 0x0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/material/internal/l;->b:Lcom/google/android/material/internal/l$b;

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-ne v2, p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/internal/l;->b()V

    :cond_3
    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/google/android/material/internal/l;->b:Lcom/google/android/material/internal/l$b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_4

    const/4 v5, 0x2

    invoke-direct {p0, v2}, Lcom/google/android/material/internal/l;->e(Lcom/google/android/material/internal/l$b;)V

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void
.end method
