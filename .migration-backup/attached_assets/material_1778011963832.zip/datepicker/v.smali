.class Lcom/google/android/material/datepicker/v;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/datepicker/v$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Lcom/google/android/material/datepicker/v$b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lcom/google/android/material/datepicker/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/g<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/g<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/datepicker/v;)Lcom/google/android/material/datepicker/g;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~@rysf~o/.-1~l ~@/@ ~~Soc~oM~ii @tb@ @ b ~@4@~ v@on t@  ma ~ o~i~@@~u~o@K f @@b ~@ ~~~~ ~~@@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method private b(I)Landroid/view/View$OnClickListener;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/material/datepicker/v$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/datepicker/v$a;-><init>(Lcom/google/android/material/datepicker/v;I)V

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method c(I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->t0()Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    sub-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p1
.end method

.method d(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->t0()Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    add-int/2addr v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public e(Lcom/google/android/material/datepicker/v$b;I)V
    .locals 9
    .param p1    # Lcom/google/android/material/datepicker/v$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/v;->d(I)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x0

    iget-object v0, p1, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget v1, Lcom/google/android/material/R$string;->mtrl_picker_navigate_to_year_description:I

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v1, p1, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    aput-object v5, v4, v6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string v5, "%d"

    const/4 v8, 0x2

    const-string v5, "%d"

    const-string v5, "%d"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v2, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object v1, p1, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    aput-object v4, v2, v6

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v1, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v8, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->v0()Lcom/google/android/material/datepicker/b;

    move-result-object v0

    const/4 v8, 0x7

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    if-ne v2, p2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v2, v0, Lcom/google/android/material/datepicker/b;->f:Lcom/google/android/material/datepicker/a;

    const/4 v7, 0x1

    move v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v2, v0, Lcom/google/android/material/datepicker/b;->d:Lcom/google/android/material/datepicker/a;

    :goto_0
    const/4 v7, 0x5

    move v8, v7

    iget-object v4, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v4}, Lcom/google/android/material/datepicker/g;->e0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {v4}, Lcom/google/android/material/datepicker/DateSelector;->f2()Ljava/util/Collection;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    if-eqz v5, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast v5, Ljava/lang/Long;

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    const/4 v8, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1, v5, v6}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-ne v5, p2, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object v2, v0, Lcom/google/android/material/datepicker/b;->e:Lcom/google/android/material/datepicker/a;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_1

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v0, p1, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v8, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2, v0}, Lcom/google/android/material/datepicker/a;->f(Landroid/widget/TextView;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object p1, p1, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {p0, p2}, Lcom/google/android/material/datepicker/v;->b(I)Landroid/view/View$OnClickListener;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-void
.end method

.method public f(Landroid/view/ViewGroup;I)Lcom/google/android/material/datepicker/v$b;
    .locals 4
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget v0, Lcom/google/android/material/R$layout;->mtrl_calendar_year:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p1, Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p2, Lcom/google/android/material/datepicker/v$b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-direct {p2, p1}, Lcom/google/android/material/datepicker/v$b;-><init>(Landroid/widget/TextView;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p2
.end method

.method public getItemCount()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/v;->a:Lcom/google/android/material/datepicker/g;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->t0()Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->q()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView$g0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/material/datepicker/v$b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/datepicker/v;->e(Lcom/google/android/material/datepicker/v$b;I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/datepicker/v;->f(Landroid/view/ViewGroup;I)Lcom/google/android/material/datepicker/v$b;

    move-result-object p1

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method
