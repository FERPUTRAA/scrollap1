.class Lcom/google/android/material/datepicker/CompositeDateValidator$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/CompositeDateValidator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/google/android/material/datepicker/CompositeDateValidator;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/google/android/material/datepicker/CompositeDateValidator;
    .locals 5
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~smy ~~@@ ol ~~Sa~ui~~@~@@@s   ~@no~ol@ ~c1b~  @@~b@~ -~b@~td@ ~@.  /o ~v /M@@f @@Kf~4@to~@ roi"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v4, 0x2

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readArrayList(Ljava/lang/ClassLoader;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ne p1, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/android/material/datepicker/CompositeDateValidator;->a()Lcom/google/android/material/datepicker/CompositeDateValidator$d;

    move-result-object p1

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne p1, v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/android/material/datepicker/CompositeDateValidator;->c()Lcom/google/android/material/datepicker/CompositeDateValidator$d;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/CompositeDateValidator;->a()Lcom/google/android/material/datepicker/CompositeDateValidator$d;

    move-result-object p1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/datepicker/CompositeDateValidator;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast v0, Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v1, v0, p1, v2}, Lcom/google/android/material/datepicker/CompositeDateValidator;-><init>(Ljava/util/List;Lcom/google/android/material/datepicker/CompositeDateValidator$d;Lcom/google/android/material/datepicker/CompositeDateValidator$a;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v1
.end method

.method public b(I)[Lcom/google/android/material/datepicker/CompositeDateValidator;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    new-array p1, p1, [Lcom/google/android/material/datepicker/CompositeDateValidator;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/CompositeDateValidator$c;->a(Landroid/os/Parcel;)Lcom/google/android/material/datepicker/CompositeDateValidator;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/CompositeDateValidator$c;->b(I)[Lcom/google/android/material/datepicker/CompositeDateValidator;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method
