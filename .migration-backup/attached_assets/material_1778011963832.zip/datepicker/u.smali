.class Lcom/google/android/material/datepicker/u;
.super Ljava/lang/Object;


# static fields
.field static final a:Ljava/lang/String; = "UTC"

.field static b:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lcom/google/android/material/datepicker/q;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/material/datepicker/u;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method static A(Lcom/google/android/material/datepicker/q;)V
    .locals 3
    .param p0    # Lcom/google/android/material/datepicker/q;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/~s@~ @i1c~~idoo~.@@~~@yl @4~~~f ~~@@M@o~ sta~@o~@@  @@bfl@ ~   b~o~~@~b @r/ ~~Km@ tu S oin@ -@v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/material/datepicker/u;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method static a(J)J
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->f(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-wide p0
.end method

.method private static b(Ljava/lang/String;Ljava/lang/String;II)I
    .locals 4
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    :goto_0
    const/4 v2, 0x0

    move v3, v2

    if-ltz p3, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-ge p3, v0, :cond_1

    const/4 v3, 0x3

    invoke-virtual {p0, p3}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, p3}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0x27

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    add-int/2addr p3, p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ltz p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ge p3, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, p3}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/2addr p3, p2

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p3
.end method

.method static c(Ljava/util/Locale;)Landroid/icu/text/DateFormat;
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "MMMd"

    const-string v0, "MMMd"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->e(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method static d(Ljava/util/Locale;)Landroid/icu/text/DateFormat;
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "dsEmM"

    const-string v0, "dMsEM"

    const-string v0, "MdEMo"

    const-string v0, "MMMEd"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->e(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method private static e(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;
    .locals 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/google/android/material/datepicker/s;->a(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->u()Landroid/icu/util/TimeZone;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-static {p0, p1}, Lcom/google/android/material/datepicker/t;->a(Landroid/icu/text/DateFormat;Landroid/icu/util/TimeZone;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static f(Ljava/util/Calendar;)Ljava/util/Calendar;
    .locals 6

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/material/datepicker/u;->w(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v3}, Ljava/util/Calendar;->get(I)I

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, p0}, Ljava/util/Calendar;->set(III)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object v0
.end method

.method private static g(ILjava/util/Locale;)Ljava/text/DateFormat;
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-static {p0, p1}, Ljava/text/DateFormat;->getDateInstance(ILjava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->s()Ljava/util/TimeZone;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method static h()Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->i(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method static i(Ljava/util/Locale;)Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->g(ILjava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method static j()Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->k(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method static k(Ljava/util/Locale;)Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->g(ILjava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method static l()Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->m(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method static m(Ljava/util/Locale;)Ljava/text/DateFormat;
    .locals 3

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/google/android/material/datepicker/u;->k(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p0, Ljava/text/SimpleDateFormat;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/text/SimpleDateFormat;->toPattern()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->z(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/text/SimpleDateFormat;->applyPattern(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method static n(Ljava/lang/String;)Ljava/text/SimpleDateFormat;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/google/android/material/datepicker/u;->o(Ljava/lang/String;Ljava/util/Locale;)Ljava/text/SimpleDateFormat;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method private static o(Ljava/lang/String;Ljava/util/Locale;)Ljava/text/SimpleDateFormat;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->s()Ljava/util/TimeZone;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method static p()Ljava/text/SimpleDateFormat;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Ljava/text/DateFormat;->getDateInstance(ILjava/util/Locale;)Ljava/text/DateFormat;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v0, Ljava/text/SimpleDateFormat;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/text/SimpleDateFormat;->toPattern()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "+/s/"

    const-string v1, "//+s"

    const/4 v4, 0x2

    const-string/jumbo v1, "s//+"

    const-string v1, "\\s+"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-direct {v1, v0, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->s()Ljava/util/TimeZone;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->setLenient(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object v1
.end method

.method static q(Landroid/content/res/Resources;Ljava/text/SimpleDateFormat;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/text/SimpleDateFormat;->toPattern()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget v0, Lcom/google/android/material/R$string;->mtrl_picker_text_input_year_abbr:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    sget v1, Lcom/google/android/material/R$string;->mtrl_picker_text_input_month_abbr:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget v2, Lcom/google/android/material/R$string;->mtrl_picker_text_input_day_abbr:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v2, "y[^]"

    const-string v2, "]^[y"

    const/4 v6, 0x7

    const-string v2, "[y^]"

    const-string v2, "[^y]"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x1

    const-string/jumbo v4, "y"

    const-string/jumbo v4, "y"

    const/4 v6, 0x7

    const-string/jumbo v4, "y"

    const-string/jumbo v4, "y"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne v2, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "yyyy"

    const-string/jumbo v2, "yyyy"

    const/4 v6, 0x5

    const-string/jumbo v2, "yyyy"

    const-string/jumbo v2, "yyyy"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, v4, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v2, "d"

    const-string v2, "d"

    const-string v2, "d"

    const-string v2, "d"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p1, v2, p0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string p1, "M"

    const-string p1, "M"

    const/4 v6, 0x3

    const-string p1, "M"

    const-string p1, "M"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, v4, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    return-object p0
.end method

.method static r()Lcom/google/android/material/datepicker/q;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/material/datepicker/u;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/material/datepicker/q;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/material/datepicker/q;->e()Lcom/google/android/material/datepicker/q;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method private static s()Ljava/util/TimeZone;
    .locals 3

    const/4 v2, 0x2

    const-string v0, "CUT"

    const-string v0, "CTU"

    const/4 v2, 0x4

    const-string v0, "TCU"

    const-string v0, "UTC"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method static t()Ljava/util/Calendar;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/android/material/datepicker/u;->r()Lcom/google/android/material/datepicker/q;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/q;->c()Ljava/util/Calendar;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v1, 0xb

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 v1, 0xc

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v1, 0xd

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v1, 0xe

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->set(II)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->s()Ljava/util/TimeZone;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0
.end method

.method private static u()Landroid/icu/util/TimeZone;
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "UTC"

    const-string v0, "CTU"

    const/4 v2, 0x7

    const-string v0, "TCU"

    const-string v0, "UTC"

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/material/datepicker/r;->a(Ljava/lang/String;)Landroid/icu/util/TimeZone;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method static v()Ljava/util/Calendar;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->w(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method static w(Ljava/util/Calendar;)Ljava/util/Calendar;
    .locals 5
    .param p0    # Ljava/util/Calendar;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->s()Ljava/util/TimeZone;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/util/Calendar;->clear()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v0
.end method

.method static x(Ljava/util/Locale;)Landroid/icu/text/DateFormat;
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "bdyMm"

    const-string v0, "MdymM"

    const/4 v2, 0x1

    const-string v0, "MudMy"

    const-string/jumbo v0, "yMMMd"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->e(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method static y(Ljava/util/Locale;)Landroid/icu/text/DateFormat;
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo v0, "ypEMMd"

    const-string/jumbo v0, "yMMMEd"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/android/material/datepicker/u;->e(Ljava/lang/String;Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method private static z(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v1, "yY"

    const-string v1, "Yy"

    const/4 v6, 0x7

    const-string v1, "Yy"

    const-string/jumbo v1, "yY"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-static {p0, v1, v2, v0}, Lcom/google/android/material/datepicker/u;->b(Ljava/lang/String;Ljava/lang/String;II)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-lt v0, v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, "dEM"

    const-string v1, "EMd"

    const/4 v6, 0x2

    const-string v1, "dME"

    const-string v1, "EMd"

    const/4 v5, 0x1

    or-int/2addr v6, v5

    invoke-static {p0, v1, v2, v0}, Lcom/google/android/material/datepicker/u;->b(Ljava/lang/String;Ljava/lang/String;II)I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    if-ge v3, v4, :cond_1

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    or-int/2addr v6, v5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x7

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v4, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p0, v1, v4, v0}, Lcom/google/android/material/datepicker/u;->b(Ljava/lang/String;Ljava/lang/String;II)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/2addr v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v1, " "

    const-string v1, " "

    const/4 v6, 0x1

    const-string v1, " "

    const-string v1, " "

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-object p0
.end method
