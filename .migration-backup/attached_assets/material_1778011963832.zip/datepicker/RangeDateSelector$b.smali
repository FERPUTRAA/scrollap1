.class Lcom/google/android/material/datepicker/RangeDateSelector$b;
.super Lcom/google/android/material/datepicker/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/RangeDateSelector;->G1(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;Lcom/google/android/material/datepicker/CalendarConstraints;Lcom/google/android/material/datepicker/n;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic h:Lcom/google/android/material/textfield/TextInputLayout;

.field final synthetic i:Lcom/google/android/material/textfield/TextInputLayout;

.field final synthetic j:Lcom/google/android/material/datepicker/n;

.field final synthetic k:Lcom/google/android/material/datepicker/RangeDateSelector;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/RangeDateSelector;Ljava/lang/String;Ljava/text/DateFormat;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/CalendarConstraints;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/n;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->k:Lcom/google/android/material/datepicker/RangeDateSelector;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p6, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->h:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p7, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->i:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p8, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->j:Lcom/google/android/material/datepicker/n;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p2, p3, p4, p5}, Lcom/google/android/material/datepicker/c;-><init>(Ljava/lang/String;Ljava/text/DateFormat;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/CalendarConstraints;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method e()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " osu@f@do@@~~/-~ si@@~~c@t~y~@~  it@ bbo@@olbi/lSfo ~~.@~~ ~4  @@n~@~~ ~o1  M~v  @aK@@~~@@~rm ~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->k:Lcom/google/android/material/datepicker/RangeDateSelector;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/RangeDateSelector;->d(Lcom/google/android/material/datepicker/RangeDateSelector;Ljava/lang/Long;)Ljava/lang/Long;

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->k:Lcom/google/android/material/datepicker/RangeDateSelector;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->h:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->i:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->j:Lcom/google/android/material/datepicker/n;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/google/android/material/datepicker/RangeDateSelector;->c(Lcom/google/android/material/datepicker/RangeDateSelector;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/n;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void
.end method

.method f(Ljava/lang/Long;)V
    .locals 5
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->k:Lcom/google/android/material/datepicker/RangeDateSelector;

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lcom/google/android/material/datepicker/RangeDateSelector;->d(Lcom/google/android/material/datepicker/RangeDateSelector;Ljava/lang/Long;)Ljava/lang/Long;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->k:Lcom/google/android/material/datepicker/RangeDateSelector;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->h:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v4, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->i:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/material/datepicker/RangeDateSelector$b;->j:Lcom/google/android/material/datepicker/n;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v0, v1, v2}, Lcom/google/android/material/datepicker/RangeDateSelector;->c(Lcom/google/android/material/datepicker/RangeDateSelector;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/n;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method
