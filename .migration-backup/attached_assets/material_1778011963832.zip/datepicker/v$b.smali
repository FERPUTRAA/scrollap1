.class public Lcom/google/android/material/datepicker/v$b;
.super Landroidx/recyclerview/widget/RecyclerView$g0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field final a:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Landroid/widget/TextView;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$g0;-><init>(Landroid/view/View;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/datepicker/v$b;->a:Landroid/widget/TextView;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
