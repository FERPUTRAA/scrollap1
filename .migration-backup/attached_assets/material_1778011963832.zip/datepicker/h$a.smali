.class Lcom/google/android/material/datepicker/h$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/h;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/h;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/h;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/datepicker/h$a;->a:Lcom/google/android/material/datepicker/h;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/@st~ do m@f@bs c@u@4i @@@~nyta @~~1  ~o ~@@@l~@o @ ~M ~~Srb~b-@@iv~o~o@@i  Kl  ~~~~f/~~~ o~@@~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$a;->a:Lcom/google/android/material/datepicker/h;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->e0(Lcom/google/android/material/datepicker/h;)Ljava/util/LinkedHashSet;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Lcom/google/android/material/datepicker/i;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/h$a;->a:Lcom/google/android/material/datepicker/h;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/h;->G0()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lcom/google/android/material/datepicker/i;->a(Ljava/lang/Object;)V

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$a;->a:Lcom/google/android/material/datepicker/h;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroidx/fragment/app/c;->dismiss()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
