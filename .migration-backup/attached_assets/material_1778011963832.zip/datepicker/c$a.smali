.class Lcom/google/android/material/datepicker/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/c;-><init>(Ljava/lang/String;Ljava/text/DateFormat;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/CalendarConstraints;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lcom/google/android/material/datepicker/c;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/c;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/datepicker/c$a;->b:Lcom/google/android/material/datepicker/c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/material/datepicker/c$a;->a:Ljava/lang/String;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 13

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v11, "@ su~~ 1o~f@b@~@vs~@i@~r o~/~/ tfl~n@  -~@t~@~y ilc@Mm@~.@oS ~bo~ ~ ~  d@@~@i@ ~ @ @4a@@Ko~ b~~ "

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/c$a;->b:Lcom/google/android/material/datepicker/c;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-static {v0}, Lcom/google/android/material/datepicker/c;->a(Lcom/google/android/material/datepicker/c;)Lcom/google/android/material/textfield/TextInputLayout;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget-object v1, p0, Lcom/google/android/material/datepicker/c$a;->b:Lcom/google/android/material/datepicker/c;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v1}, Lcom/google/android/material/datepicker/c;->b(Lcom/google/android/material/datepicker/c;)Ljava/text/DateFormat;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    sget v3, Lcom/google/android/material/R$string;->mtrl_picker_invalid_format:I

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    sget v4, Lcom/google/android/material/R$string;->mtrl_picker_invalid_format_use:I

    const/4 v12, 0x3

    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v5, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    new-array v6, v5, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v7, p0, Lcom/google/android/material/datepicker/c$a;->a:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    const/4 v8, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    aput-object v7, v6, v8

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {v4, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    sget v6, Lcom/google/android/material/R$string;->mtrl_picker_invalid_format_example:I

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-virtual {v2, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v11, 0x0

    move v12, v11

    new-instance v6, Ljava/util/Date;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v7}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v9

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-direct {v6, v9, v10}, Ljava/util/Date;-><init>(J)V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v1, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x4

    aput-object v1, v5, v8

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-static {v2, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v3, "/n"

    const-string v3, "/n"

    const/4 v12, 0x4

    const-string/jumbo v3, "n/"

    const-string v3, "\n"

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/c$a;->b:Lcom/google/android/material/datepicker/c;

    const/4 v12, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/c;->e()V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-void
.end method
