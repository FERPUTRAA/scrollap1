.class Lcom/google/android/material/datepicker/q;
.super Ljava/lang/Object;


# static fields
.field private static final c:Lcom/google/android/material/datepicker/q;


# instance fields
.field private final a:Ljava/lang/Long;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Ljava/util/TimeZone;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/material/datepicker/q;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1, v1}, Lcom/google/android/material/datepicker/q;-><init>(Ljava/lang/Long;Ljava/util/TimeZone;)V

    const/4 v2, 0x6

    move v3, v2

    sput-object v0, Lcom/google/android/material/datepicker/q;->c:Lcom/google/android/material/datepicker/q;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/Long;Ljava/util/TimeZone;)V
    .locals 2
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/util/TimeZone;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/android/material/datepicker/q;->a:Ljava/lang/Long;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/material/datepicker/q;->b:Ljava/util/TimeZone;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static a(J)Lcom/google/android/material/datepicker/q;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s /~~1  b@@f ~~yKoc ~/~ @~@ t~~Sl-Ma@~od~r~omb v~@ .@o@@~@luo@ ~@s~~ii4b~ ~ @ @@i@to ~@@ @~~ n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/datepicker/q;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x0

    or-int/2addr v2, p1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/datepicker/q;-><init>(Ljava/lang/Long;Ljava/util/TimeZone;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method static b(JLjava/util/TimeZone;)Lcom/google/android/material/datepicker/q;
    .locals 3
    .param p2    # Ljava/util/TimeZone;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/datepicker/q;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0, p2}, Lcom/google/android/material/datepicker/q;-><init>(Ljava/lang/Long;Ljava/util/TimeZone;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method static e()Lcom/google/android/material/datepicker/q;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/material/datepicker/q;->c:Lcom/google/android/material/datepicker/q;

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-object v0
.end method


# virtual methods
.method c()Ljava/util/Calendar;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/q;->b:Ljava/util/TimeZone;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/datepicker/q;->d(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method d(Ljava/util/TimeZone;)Ljava/util/Calendar;
    .locals 4
    .param p1    # Ljava/util/TimeZone;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/q;->a:Ljava/lang/Long;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-virtual {p1, v0, v1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p1
.end method
