.class Lcom/google/android/material/datepicker/g$g;
.super Landroidx/recyclerview/widget/RecyclerView$u;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/g;->q0(Landroid/view/View;Lcom/google/android/material/datepicker/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/m;

.field final synthetic b:Lcom/google/android/material/button/MaterialButton;

.field final synthetic c:Lcom/google/android/material/datepicker/g;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;Lcom/google/android/material/button/MaterialButton;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/android/material/datepicker/g$g;->c:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/material/datepicker/g$g;->a:Lcom/google/android/material/datepicker/m;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/google/android/material/datepicker/g$g;->b:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$u;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onScrollStateChanged(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    if-nez p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/material/datepicker/g$g;->b:Lcom/google/android/material/button/MaterialButton;

    const/4 v0, 0x3

    const/4 v0, 0x3

    invoke-virtual {p2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/view/View;->announceForAccessibility(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public onScrolled(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-gez p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$g;->c:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/g;->B0()Landroidx/recyclerview/widget/LinearLayoutManager;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$g;->c:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/g;->B0()Landroidx/recyclerview/widget/LinearLayoutManager;

    move-result-object p1

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result p1

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/datepicker/g$g;->c:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x2

    iget-object p3, p0, Lcom/google/android/material/datepicker/g$g;->a:Lcom/google/android/material/datepicker/m;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p3, p1}, Lcom/google/android/material/datepicker/m;->b(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p3

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p2, p3}, Lcom/google/android/material/datepicker/g;->o0(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/Month;)Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x0

    const/4 v0, 0x0

    iget-object p2, p0, Lcom/google/android/material/datepicker/g$g;->b:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget-object p3, p0, Lcom/google/android/material/datepicker/g$g;->a:Lcom/google/android/material/datepicker/m;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p3, p1}, Lcom/google/android/material/datepicker/m;->c(I)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
