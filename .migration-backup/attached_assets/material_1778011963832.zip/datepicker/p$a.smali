.class Lcom/google/android/material/datepicker/p$a;
.super Landroidx/recyclerview/widget/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/p;->smoothScrollToPosition(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/p;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/p;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/datepicker/p$a;->a:Lcom/google/android/material/datepicker/p;

    const/4 v0, 0x2

    move v1, v0

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/s;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected calculateSpeedPerPixel(Landroid/util/DisplayMetrics;)F
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@1s u~i ~@~ ~ ~ ~lf~s~~@@~So~M ~K~@o-@@@@o@@y b @nl ~~v~o~ o4f.i  @i@@btbm~oc~ @@r @t@d~// ~ ~@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    int-to-float p1, p1

    const/4 v2, 0x0

    const/high16 v0, 0x42c80000    # 100.0f

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    div-float/2addr v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method
