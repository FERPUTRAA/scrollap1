.class Lcom/google/android/material/datepicker/v$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/v;->b(I)Landroid/view/View$OnClickListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/google/android/material/datepicker/v;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/v;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/datepicker/v$a;->b:Lcom/google/android/material/datepicker/v;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/material/datepicker/v$a;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s m@@oo1b@@b ~~s@ 4~l@d~~ ~~~@~~b ~ol~~v~f~~ ~@@- @ tSn  @  ~o~~~/i @c@ayM @ouii@r~.@oft/@@ @K"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget p1, p0, Lcom/google/android/material/datepicker/v$a;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/v$a;->b:Lcom/google/android/material/datepicker/v;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/android/material/datepicker/v;->a(Lcom/google/android/material/datepicker/v;)Lcom/google/android/material/datepicker/g;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->x0()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/android/material/datepicker/Month;->c(II)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/v$a;->b:Lcom/google/android/material/datepicker/v;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/material/datepicker/v;->a(Lcom/google/android/material/datepicker/v;)Lcom/google/android/material/datepicker/g;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/g;->t0()Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/CalendarConstraints;->g(Lcom/google/android/material/datepicker/Month;)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/android/material/datepicker/v$a;->b:Lcom/google/android/material/datepicker/v;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/datepicker/v;->a(Lcom/google/android/material/datepicker/v;)Lcom/google/android/material/datepicker/g;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/g;->E0(Lcom/google/android/material/datepicker/Month;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/datepicker/v$a;->b:Lcom/google/android/material/datepicker/v;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/material/datepicker/v;->a(Lcom/google/android/material/datepicker/v;)Lcom/google/android/material/datepicker/g;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/g;->F0(Lcom/google/android/material/datepicker/g$k;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
