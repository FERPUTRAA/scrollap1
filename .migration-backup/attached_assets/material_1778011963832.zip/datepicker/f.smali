.class Lcom/google/android/material/datepicker/f;
.super Landroid/widget/BaseAdapter;


# static fields
.field private static final d:I = 0x4

.field private static final e:I


# instance fields
.field private final a:Ljava/util/Calendar;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:I

.field private final c:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v1, 0x1a

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v0, 0x4

    const/4 v3, 0x5

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput v0, Lcom/google/android/material/datepicker/f;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/datepicker/f;->a:Ljava/util/Calendar;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->getMaximum(I)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v1, p0, Lcom/google/android/material/datepicker/f;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/Calendar;->getFirstDayOfWeek()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/android/material/datepicker/f;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private b(I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "d@sMS @ yl~o ~m~ ~.~@~r~u sb~@t @-~~i~@ nvo @@l~@@~~ba~tfi@~1@@bc~~~ @~ @ @o  o@  f @@//~Ko ~@4i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/datepicker/f;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    add-int/2addr p1, v0

    const/4 v1, 0x2

    or-int/2addr v2, v1

    iget v0, p0, Lcom/google/android/material/datepicker/f;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-le p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    sub-int/2addr p1, v0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    return p1
.end method


# virtual methods
.method public a(I)Ljava/lang/Integer;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/datepicker/f;->b:I

    const/4 v2, 0x4

    if-lt p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/datepicker/f;->b(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method

.method public getCount()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/material/datepicker/f;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/f;->a(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p1
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 7
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v0, Landroid/widget/TextView;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez p2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    sget v0, Lcom/google/android/material/R$layout;->mtrl_calendar_day_of_week:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p2, v0, p3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v0, Landroid/widget/TextView;

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object p2, p0, Lcom/google/android/material/datepicker/f;->a:Ljava/util/Calendar;

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/datepicker/f;->b(I)I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x7

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p2, v2, p1}, Ljava/util/Calendar;->set(II)V

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p1, p1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/google/android/material/datepicker/f;->a:Ljava/util/Calendar;

    const/4 v5, 0x3

    move v6, v5

    sget v3, Lcom/google/android/material/datepicker/f;->e:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-virtual {p2, v2, v3, p1}, Ljava/util/Calendar;->getDisplayName(IILjava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget p2, Lcom/google/android/material/R$string;->mtrl_picker_day_of_week_column_header:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 p2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object p3, p0, Lcom/google/android/material/datepicker/f;->a:Ljava/util/Calendar;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p3, v2, v3, v4}, Ljava/util/Calendar;->getDisplayName(IILjava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    aput-object p3, p2, v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object v0
.end method
