.class Lcom/google/android/material/datepicker/g$j;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/g;->q0(Landroid/view/View;Lcom/google/android/material/datepicker/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/m;

.field final synthetic b:Lcom/google/android/material/datepicker/g;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/datepicker/g$j;->b:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/material/datepicker/g$j;->a:Lcom/google/android/material/datepicker/m;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "itsKo  o~1@@cn~fb~r~~ ~~ @~@~~~ .~@a@~ ~@M yv4-@ @m@~f/~@o @o b~s   ~@ uitd~i@ @@@S@@/@o~~l~ l o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$j;->b:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/g;->B0()Landroidx/recyclerview/widget/LinearLayoutManager;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ltz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/g$j;->b:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/google/android/material/datepicker/g$j;->a:Lcom/google/android/material/datepicker/m;

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Lcom/google/android/material/datepicker/m;->b(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/g;->E0(Lcom/google/android/material/datepicker/Month;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method
