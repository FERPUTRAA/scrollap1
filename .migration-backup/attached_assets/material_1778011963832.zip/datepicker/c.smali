.class abstract Lcom/google/android/material/datepicker/c;
.super Lcom/google/android/material/internal/p;


# static fields
.field private static final g:I = 0x3e8


# instance fields
.field private final a:Lcom/google/android/material/textfield/TextInputLayout;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Ljava/text/DateFormat;

.field private final c:Lcom/google/android/material/datepicker/CalendarConstraints;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/Runnable;

.field private f:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/text/DateFormat;Lcom/google/android/material/textfield/TextInputLayout;Lcom/google/android/material/datepicker/CalendarConstraints;)V
    .locals 2
    .param p3    # Lcom/google/android/material/textfield/TextInputLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/internal/p;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/material/datepicker/c;->b:Ljava/text/DateFormat;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/google/android/material/datepicker/c;->c:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    sget p3, Lcom/google/android/material/R$string;->mtrl_picker_out_of_range:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2, p3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    iput-object p2, p0, Lcom/google/android/material/datepicker/c;->d:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p2, Lcom/google/android/material/datepicker/c$a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1}, Lcom/google/android/material/datepicker/c$a;-><init>(Lcom/google/android/material/datepicker/c;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/google/android/material/datepicker/c;->e:Ljava/lang/Runnable;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/datepicker/c;)Lcom/google/android/material/textfield/TextInputLayout;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s @u~~~m~@ait@yb@ @~@/1  -or~~@~ bs~4c@~~ Mv ~ i@@.~~of@ l @So~ n@~@o  ~@/l@ @f~~o  @bt~diK@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic b(Lcom/google/android/material/datepicker/c;)Ljava/text/DateFormat;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/datepicker/c;->b:Ljava/text/DateFormat;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/datepicker/c;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/datepicker/c;->d:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method private d(J)Ljava/lang/Runnable;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/material/datepicker/c$b;

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1, p2}, Lcom/google/android/material/datepicker/c$b;-><init>(Lcom/google/android/material/datepicker/c;J)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method e()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method abstract f(Ljava/lang/Long;)V
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method

.method public g(Landroid/view/View;Ljava/lang/Runnable;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x5

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p3, p0, Lcom/google/android/material/datepicker/c;->e:Ljava/lang/Runnable;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p2, p3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p3, p0, Lcom/google/android/material/datepicker/c;->f:Ljava/lang/Runnable;

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-virtual {p2, p3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p3, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-virtual {p2, p3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/datepicker/c;->f(Ljava/lang/Long;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void

    :cond_0
    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->b:Ljava/text/DateFormat;

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p2, p3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    move-result-wide p2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p4, p0, Lcom/google/android/material/datepicker/c;->c:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p4}, Lcom/google/android/material/datepicker/CalendarConstraints;->h()Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    move-result-object p4

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-interface {p4, p2, p3}, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;->u0(J)Z

    move-result p4

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p4, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p4, p0, Lcom/google/android/material/datepicker/c;->c:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p4, p2, p3}, Lcom/google/android/material/datepicker/CalendarConstraints;->r(J)Z

    move-result p4

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-eqz p4, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/util/Date;->getTime()J

    move-result-wide p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/c;->f(Ljava/lang/Long;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/datepicker/c;->d(J)Ljava/lang/Runnable;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/datepicker/c;->f:Ljava/lang/Runnable;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p2, p1}, Lcom/google/android/material/datepicker/c;->g(Landroid/view/View;Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    goto :goto_0

    :catch_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/datepicker/c;->a:Lcom/google/android/material/textfield/TextInputLayout;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/google/android/material/datepicker/c;->e:Ljava/lang/Runnable;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/datepicker/c;->g(Landroid/view/View;Ljava/lang/Runnable;)V

    :goto_0
    const/4 v1, 0x1

    return-void
.end method
