.class Lcom/google/android/material/datepicker/CalendarConstraints$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/CalendarConstraints;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/google/android/material/datepicker/CalendarConstraints;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/google/android/material/datepicker/CalendarConstraints;
    .locals 10
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~osi@~Sl~atoor@ n K~~@/ ~bc l1@~t @ m~@fs ~@u@@~@@@bid~~  ~v  ~~f/~@ .Mo~y4@~ o~@@o-~ @@@b  ~@ i"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    const-class v0, Lcom/google/android/material/datepicker/Month;

    const-class v0, Lcom/google/android/material/datepicker/Month;

    const/4 v9, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    check-cast v3, Lcom/google/android/material/datepicker/Month;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    check-cast v4, Lcom/google/android/material/datepicker/Month;

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    check-cast v6, Lcom/google/android/material/datepicker/Month;

    const/4 v9, 0x1

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v9, 0x3

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const-class v0, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    check-cast v5, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p1, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v8, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v7, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct/range {v2 .. v7}, Lcom/google/android/material/datepicker/CalendarConstraints;-><init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$a;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    return-object p1
.end method

.method public b(I)[Lcom/google/android/material/datepicker/CalendarConstraints;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    new-array p1, p1, [Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/CalendarConstraints$a;->a(Landroid/os/Parcel;)Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/CalendarConstraints$a;->b(I)[Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method
