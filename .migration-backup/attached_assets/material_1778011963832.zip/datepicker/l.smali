.class Lcom/google/android/material/datepicker/l;
.super Landroid/widget/BaseAdapter;


# static fields
.field static final f:I


# instance fields
.field final a:Lcom/google/android/material/datepicker/Month;

.field final b:Lcom/google/android/material/datepicker/DateSelector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/DateSelector<",
            "*>;"
        }
    .end annotation
.end field

.field private c:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Collection<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field d:Lcom/google/android/material/datepicker/b;

.field final e:Lcom/google/android/material/datepicker/CalendarConstraints;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->getMaximum(I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    sput v0, Lcom/google/android/material/datepicker/l;->f:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method constructor <init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/DateSelector;Lcom/google/android/material/datepicker/CalendarConstraints;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/Month;",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "*>;",
            "Lcom/google/android/material/datepicker/CalendarConstraints;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/datepicker/l;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/material/datepicker/l;->e:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-interface {p2}, Lcom/google/android/material/datepicker/DateSelector;->f2()Ljava/util/Collection;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/material/datepicker/l;->c:Ljava/util/Collection;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private e(Landroid/content/Context;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@/co~ @m4~o@r ib~ t so~a~ ~@@ lM~.   - ~ bt/1@~oK ~@~of@~l~o~fb @~~S~@~y@~@@~~i@vd n~ @@i@@@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    const/4 v2, 0x6

    const/4 v1, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/datepicker/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Lcom/google/android/material/datepicker/b;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private h(J)Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v0}, Lcom/google/android/material/datepicker/DateSelector;->f2()Ljava/util/Collection;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v1, Ljava/lang/Long;

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1, p2}, Lcom/google/android/material/datepicker/u;->a(J)J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v1, v2}, Lcom/google/android/material/datepicker/u;->a(J)J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    cmp-long v1, v3, v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 p1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    return p1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x6

    move v6, v5

    return p1
.end method

.method private k(Landroid/widget/TextView;J)V
    .locals 4
    .param p1    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->e:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->h()Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0, p2, p3}, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;->u0(J)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/datepicker/l;->h(J)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    move v3, v2

    iget-object p2, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget-object p2, p2, Lcom/google/android/material/datepicker/b;->b:Lcom/google/android/material/datepicker/a;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    cmp-long p2, v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p2, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object p2, p2, Lcom/google/android/material/datepicker/b;->c:Lcom/google/android/material/datepicker/a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p2, p2, Lcom/google/android/material/datepicker/b;->a:Lcom/google/android/material/datepicker/a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x2

    const/4 p2, 0x2

    const/4 p2, 0x1

    const/4 p2, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p2, p2, Lcom/google/android/material/datepicker/b;->g:Lcom/google/android/material/datepicker/a;

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Lcom/google/android/material/datepicker/a;->f(Landroid/widget/TextView;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method private l(Lcom/google/android/material/datepicker/MaterialCalendarGridView;J)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {p2, p3}, Lcom/google/android/material/datepicker/Month;->d(J)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/datepicker/Month;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p2, p3}, Lcom/google/android/material/datepicker/Month;->i(J)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v1, v0}, Lcom/google/android/material/datepicker/l;->a(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast p1, Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/datepicker/l;->k(Landroid/widget/TextView;J)V

    :cond_0
    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method a(I)I
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    add-int/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method b()I
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/Month;->g()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public c(I)Ljava/lang/Long;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/Month;->g()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-lt p1, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->i()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-le p1, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/l;->j(I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/Month;->h(I)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1
.end method

.method public d(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/widget/TextView;
    .locals 7
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/datepicker/l;->e(Landroid/content/Context;)V

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast v0, Landroid/widget/TextView;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez p2, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget v0, Lcom/google/android/material/R$layout;->mtrl_calendar_day:I

    const/4 v6, 0x5

    invoke-virtual {p2, v0, p3, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v0, Landroid/widget/TextView;

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->b()I

    move-result p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    sub-int p2, p1, p2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ltz p2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object p3, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget v2, p3, Lcom/google/android/material/datepicker/Month;->e:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-lt p2, v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/2addr p2, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p3

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-virtual {p3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p3, p3, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v5, 0x1

    or-int/2addr v6, v5

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    aput-object v4, v3, v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v4, "%d"

    const-string v4, "%d"

    const-string v4, "d%"

    const-string v4, "%d"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p3, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object p3, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p3, p2}, Lcom/google/android/material/datepicker/Month;->h(I)J

    move-result-wide p2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v3, v3, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {}, Lcom/google/android/material/datepicker/Month;->e()Lcom/google/android/material/datepicker/Month;

    move-result-object v4

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v4, v4, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ne v3, v4, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p2, p3}, Lcom/google/android/material/datepicker/e;->g(J)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_0

    :cond_2
    const/4 v6, 0x5

    invoke-static {p2, p3}, Lcom/google/android/material/datepicker/e;->l(J)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :goto_0
    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v5, 0x4

    move v6, v5

    const/16 p2, 0x8

    const/4 v6, 0x7

    invoke-virtual {v0, p2}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEnabled(Z)V

    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/l;->c(I)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez p1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object v0

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p0, v0, p1, p2}, Lcom/google/android/material/datepicker/l;->k(Landroid/widget/TextView;J)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object v0
.end method

.method f(I)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    rem-int/2addr p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method

.method g(I)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/2addr p1, v0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, v1, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    rem-int/2addr p1, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v0, 0x0

    move v3, v0

    :goto_0
    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v0
.end method

.method public getCount()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->e:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/l;->c(I)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    div-int/2addr p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    int-to-long v0, p1

    const/4 v3, 0x0

    return-wide v0
.end method

.method public bridge synthetic getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/datepicker/l;->d(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/widget/TextView;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method public hasStableIds()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    return v0
.end method

.method i()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/Month;->g()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, v1, Lcom/google/android/material/datepicker/Month;->e:I

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0
.end method

.method j(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/Month;->g()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sub-int/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method public m(Lcom/google/android/material/datepicker/MaterialCalendarGridView;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->c:Ljava/util/Collection;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1, v1, v2}, Lcom/google/android/material/datepicker/l;->l(Lcom/google/android/material/datepicker/MaterialCalendarGridView;J)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Lcom/google/android/material/datepicker/l;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/google/android/material/datepicker/DateSelector;->f2()Ljava/util/Collection;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, p1, v1, v2}, Lcom/google/android/material/datepicker/l;->l(Lcom/google/android/material/datepicker/MaterialCalendarGridView;J)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/datepicker/l;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p1}, Lcom/google/android/material/datepicker/DateSelector;->f2()Ljava/util/Collection;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/google/android/material/datepicker/l;->c:Ljava/util/Collection;

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method n(I)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-lt p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/l;->i()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-gt p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1
.end method
