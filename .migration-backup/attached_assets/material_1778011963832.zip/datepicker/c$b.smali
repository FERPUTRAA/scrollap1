.class Lcom/google/android/material/datepicker/c$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/c;->d(J)Ljava/lang/Runnable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Lcom/google/android/material/datepicker/c;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/c;J)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/datepicker/c$b;->b:Lcom/google/android/material/datepicker/c;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-wide p2, p0, Lcom/google/android/material/datepicker/c$b;->a:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "m~s@  @@Mo  /~@/~y~@ 1b@~~a@n~t @i ~S@ ~lr~@bi~oto @~u~sb~~~ocd~@f@-~o~@o@l@4  ~@i   v~ f@K  @.@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/c$b;->b:Lcom/google/android/material/datepicker/c;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/google/android/material/datepicker/c;->a(Lcom/google/android/material/datepicker/c;)Lcom/google/android/material/textfield/TextInputLayout;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/material/datepicker/c$b;->b:Lcom/google/android/material/datepicker/c;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/google/android/material/datepicker/c;->c(Lcom/google/android/material/datepicker/c;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x6

    iget-wide v3, p0, Lcom/google/android/material/datepicker/c$b;->a:J

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lcom/google/android/material/datepicker/e;->c(J)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    aput-object v3, v2, v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/c$b;->b:Lcom/google/android/material/datepicker/c;

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/c;->e()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void
.end method
