.class public final Lcom/google/android/material/datepicker/CalendarConstraints;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/datepicker/CalendarConstraints$b;,
        Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/material/datepicker/CalendarConstraints;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lcom/google/android/material/datepicker/Month;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Lcom/google/android/material/datepicker/Month;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private d:Lcom/google/android/material/datepicker/Month;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final e:I

.field private final f:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/material/datepicker/CalendarConstraints$a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/material/datepicker/CalendarConstraints$a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/material/datepicker/CalendarConstraints;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;Lcom/google/android/material/datepicker/Month;)V
    .locals 2
    .param p1    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p4, :cond_1

    const/4 v1, 0x3

    invoke-virtual {p1, p4}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result p3

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-gtz p3, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    const-string p2, "c scnteo n tsMhrt n rotnhteat eanMatbfros"

    const-string/jumbo p2, "r stnaeMo nh  choMnnno etbtrae rttttrfcsa"

    const/4 v1, 0x2

    const-string p2, "aoMmottettno thtnnsr tu a chfrMeera  brnn"

    const-string/jumbo p2, "start Month cannot be after current Month"

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    throw p1

    :cond_1
    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    if-eqz p4, :cond_3

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p4, p2}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result p3

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    if-gtz p3, :cond_2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    goto :goto_1

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    const-string/jumbo p2, "rn MotbodMnurotnhefna  arcetetto  e nch"

    const-string p2, "current Month cannot be after end Month"

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    throw p1

    :cond_3
    :goto_1
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/material/datepicker/Month;->s(Lcom/google/android/material/datepicker/Month;)I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    add-int/lit8 p3, p3, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p3, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->f:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p2, p2, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    iget p1, p1, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    sub-int/2addr p2, p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    add-int/lit8 p2, p2, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->e:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/datepicker/CalendarConstraints;-><init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;Lcom/google/android/material/datepicker/Month;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v~b@nbo@i~b ~@~/~f@ 4Kd-i~@@@ @M@~@@~@@o/@~u  s ~@loSta~@~~o 1@@~ y~  ~ @  i c~r~ fm~to@l.~b~ ~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic d(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    iget-object p0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic e(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne p0, p1, :cond_0

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    instance-of v1, p1, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast p1, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v3, p1, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Lcom/google/android/material/datepicker/Month;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Lcom/google/android/material/datepicker/Month;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x0

    move v5, v4

    iget-object v3, p1, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1, v3}, Landroidx/core/util/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p1, p1, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v0
.end method

.method g(Lcom/google/android/material/datepicker/Month;)Lcom/google/android/material/datepicker/Month;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-gez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-lez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method public h()Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    move v4, v3

    iget-object v2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v1, 0x1

    move v3, v1

    move v3, v1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v0
.end method

.method i()Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x7

    return-object v0
.end method

.method k()I
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method n()Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method o()Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    return-object v0
.end method

.method q()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->e:I

    const/4 v2, 0x7

    return v0
.end method

.method r(J)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/material/datepicker/Month;->h(I)J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    cmp-long v0, v2, p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-gtz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x0

    iget v2, v0, Lcom/google/android/material/datepicker/Month;->e:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Lcom/google/android/material/datepicker/Month;->h(I)J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    cmp-long p1, p1, v2

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    if-gtz p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x0

    move v5, v1

    :goto_0
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v1
.end method

.method s(Lcom/google/android/material/datepicker/Month;)V
    .locals 2
    .param p1    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->b:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->d:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/material/datepicker/CalendarConstraints;->c:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v2, 0x3

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method
