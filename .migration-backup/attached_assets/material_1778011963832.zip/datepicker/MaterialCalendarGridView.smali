.class final Lcom/google/android/material/datepicker/MaterialCalendarGridView;
.super Landroid/widget/GridView;


# instance fields
.field private final a:Ljava/util/Calendar;

.field private final b:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/GridView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a:Ljava/util/Calendar;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    sget p1, Lcom/google/android/material/R$id;->cancel_button:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/view/View;->setNextFocusLeftId(I)V

    const/4 v0, 0x2

    move v1, v0

    sget p1, Lcom/google/android/material/R$id;->confirm_button:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setNextFocusRightId(I)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->K0(Landroid/content/Context;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    new-instance p1, Lcom/google/android/material/datepicker/MaterialCalendarGridView$a;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1, p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView$a;-><init>(Lcom/google/android/material/datepicker/MaterialCalendarGridView;)V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p0, p1}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private a(ILandroid/graphics/Rect;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sl~ ~@/Kbs i~@@ul  r~bo~@~@ o~/~n1t~@~@@@y  @v~m@o@ ~ @@ @@-@~@~i.t4 ~~ a~oc@fi@o S  ~~fbod~M~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/16 v0, 0x21

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/l;->i()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->setSelection(I)V

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/16 v0, 0x82

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne p1, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/l;->b()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->setSelection(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-super {p0, v0, p1, p2}, Landroid/widget/GridView;->onFocusChanged(ZILandroid/graphics/Rect;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private c(I)Landroid/view/View;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    sub-int/2addr p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method

.method private static d(Landroid/view/View;)I
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    div-int/lit8 p0, p0, 0x2

    const/4 v2, 0x5

    add-int/2addr v0, p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method private static e(Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;)Z
    .locals 5
    .param p0    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p0, :cond_2

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p2, :cond_2

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    if-nez p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    cmp-long p1, v1, p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-gtz p1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    cmp-long p0, p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-gez p0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v0, 0x0

    :cond_2
    :goto_0
    const/4 v3, 0x3

    move v4, v3

    return v0
.end method


# virtual methods
.method public b()Lcom/google/android/material/datepicker/l;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/widget/GridView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/material/datepicker/l;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getAdapter()Landroid/widget/Adapter;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getAdapter()Landroid/widget/ListAdapter;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    return-object v0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-super {p0}, Landroid/widget/GridView;->onAttachedToWindow()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method protected final onDraw(Landroid/graphics/Canvas;)V
    .locals 26
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-super/range {p0 .. p1}, Landroid/widget/GridView;->onDraw(Landroid/graphics/Canvas;)V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v1

    iget-object v2, v1, Lcom/google/android/material/datepicker/l;->b:Lcom/google/android/material/datepicker/DateSelector;

    iget-object v3, v1, Lcom/google/android/material/datepicker/l;->d:Lcom/google/android/material/datepicker/b;

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/l;->i()I

    move-result v5

    invoke-virtual/range {p0 .. p0}, Landroid/widget/AdapterView;->getLastVisiblePosition()I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-virtual {v1, v4}, Lcom/google/android/material/datepicker/l;->c(I)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v1, v5}, Lcom/google/android/material/datepicker/l;->c(I)Ljava/lang/Long;

    move-result-object v7

    invoke-interface {v2}, Lcom/google/android/material/datepicker/DateSelector;->e1()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroidx/core/util/m;

    iget-object v9, v8, Landroidx/core/util/m;->a:Ljava/lang/Object;

    if-eqz v9, :cond_e

    iget-object v10, v8, Landroidx/core/util/m;->b:Ljava/lang/Object;

    if-nez v10, :cond_0

    goto :goto_0

    :cond_0
    check-cast v9, Ljava/lang/Long;

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    iget-object v8, v8, Landroidx/core/util/m;->b:Ljava/lang/Object;

    check-cast v8, Ljava/lang/Long;

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    invoke-static {v6, v7, v8, v13}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->e(Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;)Z

    move-result v8

    if-eqz v8, :cond_1

    goto :goto_0

    :cond_1
    invoke-static/range {p0 .. p0}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result v8

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    cmp-long v13, v9, v13

    const/4 v14, 0x5

    if-gez v13, :cond_4

    invoke-virtual {v1, v4}, Lcom/google/android/material/datepicker/l;->f(I)Z

    move-result v9

    if-eqz v9, :cond_2

    const/4 v9, 0x0

    goto :goto_1

    :cond_2
    if-nez v8, :cond_3

    add-int/lit8 v9, v4, -0x1

    invoke-direct {v0, v9}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getRight()I

    move-result v9

    goto :goto_1

    :cond_3
    add-int/lit8 v9, v4, -0x1

    invoke-direct {v0, v9}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getLeft()I

    move-result v9

    :goto_1
    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    move v9, v4

    move v9, v4

    move v9, v4

    move v9, v4

    goto :goto_2

    :cond_4
    iget-object v13, v0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a:Ljava/util/Calendar;

    invoke-virtual {v13, v9, v10}, Ljava/util/Calendar;->setTimeInMillis(J)V

    iget-object v9, v0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a:Ljava/util/Calendar;

    invoke-virtual {v9, v14}, Ljava/util/Calendar;->get(I)I

    move-result v9

    invoke-virtual {v1, v9}, Lcom/google/android/material/datepicker/l;->a(I)I

    move-result v9

    invoke-direct {v0, v9}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v10

    invoke-static {v10}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->d(Landroid/view/View;)I

    move-result v10

    :goto_2
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v16

    cmp-long v13, v11, v16

    if-lez v13, :cond_7

    invoke-virtual {v1, v5}, Lcom/google/android/material/datepicker/l;->g(I)Z

    move-result v11

    if-eqz v11, :cond_5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v11

    goto :goto_3

    :cond_5
    if-nez v8, :cond_6

    invoke-direct {v0, v5}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v11}, Landroid/view/View;->getRight()I

    move-result v11

    goto :goto_3

    :cond_6
    invoke-direct {v0, v5}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v11}, Landroid/view/View;->getLeft()I

    move-result v11

    :goto_3
    move v12, v11

    move v12, v11

    move v12, v11

    move v11, v5

    move v11, v5

    move v11, v5

    move v11, v5

    goto :goto_4

    :cond_7
    iget-object v13, v0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a:Ljava/util/Calendar;

    invoke-virtual {v13, v11, v12}, Ljava/util/Calendar;->setTimeInMillis(J)V

    iget-object v11, v0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a:Ljava/util/Calendar;

    invoke-virtual {v11, v14}, Ljava/util/Calendar;->get(I)I

    move-result v11

    invoke-virtual {v1, v11}, Lcom/google/android/material/datepicker/l;->a(I)I

    move-result v11

    invoke-direct {v0, v11}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v12

    invoke-static {v12}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->d(Landroid/view/View;)I

    move-result v12

    :goto_4
    invoke-virtual {v1, v9}, Lcom/google/android/material/datepicker/l;->getItemId(I)J

    move-result-wide v13

    long-to-int v13, v13

    move v14, v4

    move v14, v4

    move v14, v4

    move v14, v4

    move/from16 v16, v5

    move/from16 v16, v5

    move/from16 v16, v5

    move/from16 v16, v5

    invoke-virtual {v1, v11}, Lcom/google/android/material/datepicker/l;->getItemId(I)J

    move-result-wide v4

    long-to-int v4, v4

    :goto_5
    if-gt v13, v4, :cond_d

    invoke-virtual/range {p0 .. p0}, Landroid/widget/GridView;->getNumColumns()I

    move-result v5

    mul-int/2addr v5, v13

    invoke-virtual/range {p0 .. p0}, Landroid/widget/GridView;->getNumColumns()I

    move-result v17

    add-int v17, v5, v17

    add-int/lit8 v15, v17, -0x1

    invoke-direct {v0, v5}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->c(I)Landroid/view/View;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Landroid/view/View;->getTop()I

    move-result v18

    iget-object v0, v3, Lcom/google/android/material/datepicker/b;->a:Lcom/google/android/material/datepicker/a;

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/a;->e()I

    move-result v0

    add-int v0, v18, v0

    invoke-virtual/range {v17 .. v17}, Landroid/view/View;->getBottom()I

    move-result v17

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    move-object/from16 v18, v1

    iget-object v1, v3, Lcom/google/android/material/datepicker/b;->a:Lcom/google/android/material/datepicker/a;

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/a;->b()I

    move-result v1

    sub-int v1, v17, v1

    if-nez v8, :cond_a

    if-le v5, v9, :cond_8

    const/4 v5, 0x0

    goto :goto_6

    :cond_8
    move v5, v10

    move v5, v10

    move v5, v10

    :goto_6
    if-le v11, v15, :cond_9

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v15

    goto :goto_9

    :cond_9
    move v15, v12

    move v15, v12

    move v15, v12

    move v15, v12

    goto :goto_9

    :cond_a
    if-le v11, v15, :cond_b

    const/4 v15, 0x0

    goto :goto_7

    :cond_b
    move v15, v12

    move v15, v12

    :goto_7
    if-le v5, v9, :cond_c

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v5

    goto :goto_8

    :cond_c
    move v5, v10

    move v5, v10

    move v5, v10

    move v5, v10

    :goto_8
    move/from16 v25, v15

    move/from16 v25, v15

    move/from16 v25, v15

    move/from16 v25, v15

    move v15, v5

    move v15, v5

    move v15, v5

    move v15, v5

    move/from16 v5, v25

    move/from16 v5, v25

    move/from16 v5, v25

    move/from16 v5, v25

    :goto_9
    int-to-float v5, v5

    int-to-float v0, v0

    int-to-float v15, v15

    int-to-float v1, v1

    move-object/from16 v17, v2

    move-object/from16 v17, v2

    move-object/from16 v17, v2

    iget-object v2, v3, Lcom/google/android/material/datepicker/b;->h:Landroid/graphics/Paint;

    move-object/from16 v19, p1

    move-object/from16 v19, p1

    move-object/from16 v19, p1

    move-object/from16 v19, p1

    move/from16 v20, v5

    move/from16 v20, v5

    move/from16 v20, v5

    move/from16 v21, v0

    move/from16 v21, v0

    move/from16 v21, v0

    move/from16 v21, v0

    move/from16 v22, v15

    move/from16 v22, v15

    move/from16 v22, v15

    move/from16 v22, v15

    move/from16 v23, v1

    move/from16 v23, v1

    move/from16 v23, v1

    move/from16 v23, v1

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    invoke-virtual/range {v19 .. v24}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v13, v13, 0x1

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v1, v18

    move-object/from16 v1, v18

    goto/16 :goto_5

    :cond_d
    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move v4, v14

    move v4, v14

    move v4, v14

    move v4, v14

    move/from16 v5, v16

    move/from16 v5, v16

    move/from16 v5, v16

    move/from16 v5, v16

    goto/16 :goto_0

    :cond_e
    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    goto/16 :goto_0

    :cond_f
    return-void
.end method

.method protected onFocusChanged(ZILandroid/graphics/Rect;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->a(ILandroid/graphics/Rect;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x3

    xor-int/2addr v1, v0

    invoke-super {p0, p1, p2, p3}, Landroid/widget/GridView;->onFocusChanged(ZILandroid/graphics/Rect;)V

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-super {p0, p1, p2}, Landroid/widget/GridView;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-nez p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eq p2, v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-lt p2, v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 p2, 0x13

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p2, p1, :cond_2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/l;->b()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->setSelection(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    return v2

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    return v0

    :cond_3
    :goto_0
    const/4 v4, 0x0

    return v2
.end method

.method public onMeasure(II)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    const p2, 0xffffff

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-super {p0, p1, p2}, Landroid/widget/GridView;->onMeasure(II)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p2, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    invoke-super {p0, p1, p2}, Landroid/widget/GridView;->onMeasure(II)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public bridge synthetic setAdapter(Landroid/widget/Adapter;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Landroid/widget/ListAdapter;

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->setAdapter(Landroid/widget/ListAdapter;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-void
.end method

.method public final setAdapter(Landroid/widget/ListAdapter;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    instance-of v0, p1, Lcom/google/android/material/datepicker/l;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-super {p0, p1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v0, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-class v1, Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const-class v1, Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-class v1, Lcom/google/android/material/datepicker/l;

    const-class v1, Lcom/google/android/material/datepicker/l;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const-string v1, "  tms$es% rs1hAe u taamde  tspos%v2 $tis"

    const-string/jumbo v1, "sest A $%%ta  s tdptms$1i assee o2uvhr a"

    const/4 v4, 0x2

    const-string v1, "est2ohvp%u $e$ m  oAsadir  saate ttss1t%"

    const-string v1, "%1$s must have its Adapter set to a %2$s"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    throw p1
.end method

.method public setSelection(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/l;->b()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-ge p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/l;->b()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/GridView;->setSelection(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/widget/GridView;->setSelection(I)V

    :goto_0
    const/4 v2, 0x3

    return-void
.end method
