.class Lcom/google/android/material/datepicker/h$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/view/z0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/h;->C0(Landroid/view/Window;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Landroid/view/View;

.field final synthetic c:I

.field final synthetic d:Lcom/google/android/material/datepicker/h;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/h;ILandroid/view/View;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/datepicker/h$c;->d:Lcom/google/android/material/datepicker/h;

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/material/datepicker/h$c;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p4, p0, Lcom/google/android/material/datepicker/h$c;->c:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;)Landroidx/core/view/y2;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@sy~ib~@@@ ~t @@fl m4@~~o ~@~iu~~Mlo~@ d @/~-~@f  ~~oc~~~ ~1o bt @@ ~@.@sio n ~@ @v~K o @r/Sa~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    invoke-static {}, Landroidx/core/view/y2$m;->i()I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Landroidx/core/view/y2;->f(I)Landroidx/core/graphics/g0;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget p1, p1, Landroidx/core/graphics/g0;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/android/material/datepicker/h$c;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ltz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v1, p0, Lcom/google/android/material/datepicker/h$c;->a:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    add-int/2addr v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/android/material/datepicker/h$c;->c:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/2addr v2, p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/android/material/datepicker/h$c;->b:Landroid/view/View;

    const/4 v5, 0x2

    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, p1, v3}, Landroid/view/View;->setPadding(IIII)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object p2
.end method
