.class Lcom/google/android/material/datepicker/h$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/h;->I0(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/h;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/h;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s  ~. yb@@K~~@t l~d  @~  @@lmob@~S@~c/@o-~~ @~ t~i @@@i @@~s/u@oo4~Mv~f1a@n~ ~r~@ b  o o~i~@~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->i0(Lcom/google/android/material/datepicker/h;)Landroid/widget/Button;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/material/datepicker/h;->h0(Lcom/google/android/material/datepicker/h;)Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0}, Lcom/google/android/material/datepicker/DateSelector;->X1()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->setEnabled(Z)V

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->j0(Lcom/google/android/material/datepicker/h;)Lcom/google/android/material/internal/CheckableImageButton;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/internal/CheckableImageButton;->toggle()V

    const/4 v1, 0x6

    move v2, v1

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->j0(Lcom/google/android/material/datepicker/h;)Lcom/google/android/material/internal/CheckableImageButton;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/android/material/datepicker/h;->l0(Lcom/google/android/material/datepicker/h;Lcom/google/android/material/internal/CheckableImageButton;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/datepicker/h$e;->a:Lcom/google/android/material/datepicker/h;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->n0(Lcom/google/android/material/datepicker/h;)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method
