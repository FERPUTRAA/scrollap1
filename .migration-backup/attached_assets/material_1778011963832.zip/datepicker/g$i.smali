.class Lcom/google/android/material/datepicker/g$i;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/g;->q0(Landroid/view/View;Lcom/google/android/material/datepicker/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/datepicker/m;

.field final synthetic b:Lcom/google/android/material/datepicker/g;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/datepicker/g$i;->b:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/datepicker/g$i;->a:Lcom/google/android/material/datepicker/m;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$i;->b:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/g;->B0()Landroidx/recyclerview/widget/LinearLayoutManager;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/g$i;->b:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/android/material/datepicker/g;->g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemCount()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ge p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/g$i;->b:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/datepicker/g$i;->a:Lcom/google/android/material/datepicker/m;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Lcom/google/android/material/datepicker/m;->b(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/g;->E0(Lcom/google/android/material/datepicker/Month;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x5

    return-void
.end method
