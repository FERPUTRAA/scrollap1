.class final Lcom/google/android/material/datepicker/a;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/graphics/Rect;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Landroid/content/res/ColorStateList;

.field private final c:Landroid/content/res/ColorStateList;

.field private final d:Landroid/content/res/ColorStateList;

.field private final e:I

.field private final f:Lcom/google/android/material/shape/o;


# direct methods
.method private constructor <init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILcom/google/android/material/shape/o;Landroid/graphics/Rect;)V
    .locals 3
    .param p6    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    iget v0, p6, Landroid/graphics/Rect;->left:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Landroidx/core/util/q;->i(I)I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p6, Landroid/graphics/Rect;->top:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/util/q;->i(I)I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p6, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/util/q;->i(I)I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p6, Landroid/graphics/Rect;->bottom:I

    const/4 v1, 0x0

    move v2, v1

    invoke-static {v0}, Landroidx/core/util/q;->i(I)I

    const/4 v2, 0x0

    iput-object p6, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/google/android/material/datepicker/a;->b:Landroid/content/res/ColorStateList;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/datepicker/a;->c:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p3, p0, Lcom/google/android/material/datepicker/a;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    iput p4, p0, Lcom/google/android/material/datepicker/a;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p5, p0, Lcom/google/android/material/datepicker/a;->f:Lcom/google/android/material/shape/o;

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/content/Context;I)Lcom/google/android/material/datepicker/a;
    .locals 13
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v12, " Ks~o1~b @@rb ~~@@ cf@ ~~@s ~m ~4 lf~ @oot/~ @~b~oid oyu~@~  @@~i ta/ vn@~~@~@S  ~@-o@@i@M.~l~@~"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    const/4 v12, 0x6

    if-eqz p1, :cond_0

    const/4 v12, 0x0

    const/4 v1, 0x1

    const/4 v12, 0x0

    goto :goto_0

    :cond_0
    const/4 v12, 0x0

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v12, 0x6

    const-string v2, "eisweha n a rm crI Rns td tClsaSte0Cteloa eleoyIdtynfata"

    const-string v2, "ehfmaleCeye ntstIter0idteySce oaaR  marlI nwCnata dlt os"

    const-string v2, "Cannot create a CalendarItemStyle with a styleResId of 0"

    const/4 v12, 0x3

    invoke-static {v1, v2}, Landroidx/core/util/q;->b(ZLjava/lang/Object;)V

    const/4 v12, 0x4

    sget-object v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem:[I

    const/4 v12, 0x2

    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v12, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_android_insetLeft:I

    const/4 v12, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v1

    const/4 v12, 0x1

    sget v2, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_android_insetTop:I

    const/4 v12, 0x6

    invoke-virtual {p1, v2, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v2

    const/4 v12, 0x3

    sget v3, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_android_insetRight:I

    const/4 v12, 0x3

    invoke-virtual {p1, v3, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v3

    const/4 v12, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_android_insetBottom:I

    const/4 v12, 0x4

    invoke-virtual {p1, v4, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    const/4 v12, 0x4

    new-instance v11, Landroid/graphics/Rect;

    const/4 v12, 0x1

    invoke-direct {v11, v1, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v12, 0x5

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemFillColor:I

    const/4 v12, 0x1

    invoke-static {p0, p1, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v6

    const/4 v12, 0x2

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemTextColor:I

    const/4 v12, 0x0

    invoke-static {p0, p1, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v7

    const/4 v12, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemStrokeColor:I

    const/4 v12, 0x1

    invoke-static {p0, p1, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v8

    const/4 v12, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemStrokeWidth:I

    const/4 v12, 0x4

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v9

    const/4 v12, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemShapeAppearance:I

    const/4 v12, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    const/4 v12, 0x4

    sget v2, Lcom/google/android/material/R$styleable;->MaterialCalendarItem_itemShapeAppearanceOverlay:I

    const/4 v12, 0x2

    invoke-virtual {p1, v2, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    const/4 v12, 0x1

    invoke-static {p0, v1, v0}, Lcom/google/android/material/shape/o;->b(Landroid/content/Context;II)Lcom/google/android/material/shape/o$b;

    move-result-object p0

    const/4 v12, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v10

    const/4 v12, 0x6

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v12, 0x4

    new-instance p0, Lcom/google/android/material/datepicker/a;

    move-object v5, p0

    move-object v5, p0

    const/4 v12, 0x6

    invoke-direct/range {v5 .. v11}, Lcom/google/android/material/datepicker/a;-><init>(Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;ILcom/google/android/material/shape/o;Landroid/graphics/Rect;)V

    const/4 v12, 0x4

    return-object p0
.end method


# virtual methods
.method b()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method c()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, v0, Landroid/graphics/Rect;->left:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method d()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, v0, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method e()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, v0, Landroid/graphics/Rect;->top:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method f(Landroid/widget/TextView;)V
    .locals 11
    .param p1    # Landroid/widget/TextView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {v0}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    new-instance v1, Lcom/google/android/material/shape/j;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-direct {v1}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/google/android/material/datepicker/a;->f:Lcom/google/android/material/shape/o;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v0, v2}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/google/android/material/datepicker/a;->f:Lcom/google/android/material/shape/o;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/google/android/material/datepicker/a;->c:Landroid/content/res/ColorStateList;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v0, v2}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget v2, p0, Lcom/google/android/material/datepicker/a;->e:I

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    int-to-float v2, v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v3, p0, Lcom/google/android/material/datepicker/a;->d:Landroid/content/res/ColorStateList;

    const/4 v9, 0x4

    move v10, v9

    invoke-virtual {v0, v2, v3}, Lcom/google/android/material/shape/j;->E0(FLandroid/content/res/ColorStateList;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/google/android/material/datepicker/a;->b:Landroid/content/res/ColorStateList;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v9, 0x2

    move v10, v9

    new-instance v4, Landroid/graphics/drawable/RippleDrawable;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/google/android/material/datepicker/a;->b:Landroid/content/res/ColorStateList;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/16 v3, 0x1e

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Landroid/content/res/ColorStateList;->withAlpha(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v4, v2, v0, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    new-instance v0, Landroid/graphics/drawable/InsetDrawable;

    const/4 v10, 0x4

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/a;->a:Landroid/graphics/Rect;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v5, v1, Landroid/graphics/Rect;->left:I

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget v6, v1, Landroid/graphics/Rect;->top:I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget v7, v1, Landroid/graphics/Rect;->right:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget v8, v1, Landroid/graphics/Rect;->bottom:I

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-direct/range {v3 .. v8}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {p1, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void
.end method
