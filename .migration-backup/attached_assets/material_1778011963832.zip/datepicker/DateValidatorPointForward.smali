.class public Lcom/google/android/material/datepicker/DateValidatorPointForward;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/material/datepicker/DateValidatorPointForward;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/datepicker/DateValidatorPointForward$a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/material/datepicker/DateValidatorPointForward$a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(JLcom/google/android/material/datepicker/DateValidatorPointForward$a;)V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/datepicker/DateValidatorPointForward;-><init>(J)V

    const/4 v1, 0x0

    return-void
.end method

.method public static a(J)Lcom/google/android/material/datepicker/DateValidatorPointForward;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~fs  o ob~r~o il-~  @u~@@ @@@@~Kv~~S@d@t~@~ s    int li/@@@o~~o~o @~ b~1~ @/~@abM@4fc~@@ ~~~@~.y"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/datepicker/DateValidatorPointForward;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/datepicker/DateValidatorPointForward;-><init>(J)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public static c()Lcom/google/android/material/datepicker/DateValidatorPointForward;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a(J)Lcom/google/android/material/datepicker/DateValidatorPointForward;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v0, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-ne p0, p1, :cond_0

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    return v0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    instance-of v1, p1, Lcom/google/android/material/datepicker/DateValidatorPointForward;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x4

    move v8, v7

    if-nez v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    return v2

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    check-cast p1, Lcom/google/android/material/datepicker/DateValidatorPointForward;

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    iget-wide v3, p0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-wide v5, p1, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    cmp-long p1, v3, v5

    const/4 v7, 0x7

    move v8, v7

    if-nez p1, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v0, v2

    const/4 v8, 0x3

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    return v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v0
.end method

.method public u0(J)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    cmp-long p1, p1, v0

    const/4 v2, 0x7

    move v3, v2

    if-ltz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    return p1
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 4
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a:J

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
