.class final enum Lcom/google/android/material/datepicker/g$k;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/android/material/datepicker/g$k;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lcom/google/android/material/datepicker/g$k;

.field public static final enum b:Lcom/google/android/material/datepicker/g$k;

.field private static final synthetic c:[Lcom/google/android/material/datepicker/g$k;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Lcom/google/android/material/datepicker/g$k;

    const/4 v5, 0x0

    move v6, v5

    const-string v1, "DAY"

    const-string v1, "DYA"

    const/4 v6, 0x6

    const-string v1, "YAD"

    const-string v1, "DAY"

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/datepicker/g$k;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x5

    sput-object v0, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v1, Lcom/google/android/material/datepicker/g$k;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v3, "REYA"

    const-string v3, "YAER"

    const/4 v6, 0x0

    const-string v3, "AEYR"

    const-string v3, "YEAR"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v1, v3, v4}, Lcom/google/android/material/datepicker/g$k;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    sput-object v1, Lcom/google/android/material/datepicker/g$k;->b:Lcom/google/android/material/datepicker/g$k;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x3

    new-array v3, v3, [Lcom/google/android/material/datepicker/g$k;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    aput-object v0, v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    aput-object v1, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    sput-object v3, Lcom/google/android/material/datepicker/g$k;->c:[Lcom/google/android/material/datepicker/g$k;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/android/material/datepicker/g$k;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cdsoM@@ o- ~~4~f~l@y @@~@@~ s @@o@~~/om@S@  o@ab~ nl~  tK~~iu ~@ v.~~~  1 i~@/~@tr~f@@~  bi@o~b@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-class v0, Lcom/google/android/material/datepicker/g$k;

    const-class v0, Lcom/google/android/material/datepicker/g$k;

    const/4 v2, 0x6

    const-class v0, Lcom/google/android/material/datepicker/g$k;

    const-class v0, Lcom/google/android/material/datepicker/g$k;

    const/4 v1, 0x2

    const/4 v1, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/material/datepicker/g$k;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lcom/google/android/material/datepicker/g$k;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/material/datepicker/g$k;->c:[Lcom/google/android/material/datepicker/g$k;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/google/android/material/datepicker/g$k;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast v0, [Lcom/google/android/material/datepicker/g$k;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method
