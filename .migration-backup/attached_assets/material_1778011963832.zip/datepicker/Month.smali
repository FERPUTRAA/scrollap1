.class final Lcom/google/android/material/datepicker/Month;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Comparable;
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lcom/google/android/material/datepicker/Month;",
        ">;",
        "Landroid/os/Parcelable;"
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/material/datepicker/Month;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Ljava/util/Calendar;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field final b:I

.field final c:I

.field final d:I

.field final e:I

.field final f:J

.field private g:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/datepicker/Month$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/material/datepicker/Month$a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/datepicker/Month;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/util/Calendar;)V
    .locals 5
    .param p1    # Ljava/util/Calendar;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x3

    move v3, v1

    move v3, v1

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Ljava/util/Calendar;->set(II)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/android/material/datepicker/u;->f(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object p1, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v4, 0x1

    const/4 v2, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v2, p0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v4, 0x7

    const/4 v1, 0x7

    const/4 v4, 0x1

    move v3, v1

    move v3, v1

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Ljava/util/Calendar;->getMaximum(I)I

    move-result v1

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput v1, p0, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/util/Calendar;->getActualMaximum(I)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/android/material/datepicker/Month;->e:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-wide v0, p0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v4, 0x2

    return-void
.end method

.method static c(II)Lcom/google/android/material/datepicker/Month;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4 s/fit~ . ~o fd@ @@@/ @~l~~m@~~~1y Kl~~@ ~bvS~a@o@Mi@ ~o~trsc@ u@ ~i~@b @@ o@o@~@ ~ -~~~ ~@b o@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p0}, Ljava/util/Calendar;->set(II)V

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->set(II)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p0, Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/datepicker/Month;-><init>(Ljava/util/Calendar;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0
.end method

.method static d(J)Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p0, Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/datepicker/Month;-><init>(Ljava/util/Calendar;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method static e()Lcom/google/android/material/datepicker/Month;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/material/datepicker/Month;-><init>(Ljava/util/Calendar;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method


# virtual methods
.method public a(Lcom/google/android/material/datepicker/Month;)I
    .locals 3
    .param p1    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-virtual {v0, p1}, Ljava/util/Calendar;->compareTo(Ljava/util/Calendar;)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p1
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    check-cast p1, Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    return p1
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne p0, p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    instance-of v1, p1, Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v2

    :cond_1
    const/4 v5, 0x0

    check-cast p1, Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x2

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v3, p1, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne v1, v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget p1, p1, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-ne v1, p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v0
.end method

.method g()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x1

    const/4 v1, 0x7

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v1}, Ljava/util/Calendar;->getFirstDayOfWeek()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-gez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr v0, v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method h(I)J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->f(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x5

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Ljava/util/Calendar;->set(II)V

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-wide v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x2

    const/4 v4, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v4, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move v4, v3

    aput-object v1, v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0
.end method

.method i(J)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->f(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p1, 0x5

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Ljava/util/Calendar;->get(I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p1
.end method

.method o()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->g:Ljava/lang/String;

    const/4 v2, 0x4

    or-int/2addr v3, v2

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/e;->i(J)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/datepicker/Month;->g:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->g:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method q()J
    .locals 4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-wide v0
.end method

.method r(I)Lcom/google/android/material/datepicker/Month;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/android/material/datepicker/u;->f(Ljava/util/Calendar;)Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p1}, Ljava/util/Calendar;->add(II)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Lcom/google/android/material/datepicker/Month;-><init>(Ljava/util/Calendar;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p1
.end method

.method s(Lcom/google/android/material/datepicker/Month;)I
    .locals 4
    .param p1    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/Month;->a:Ljava/util/Calendar;

    const/4 v3, 0x2

    const/4 v2, 0x6

    instance-of v0, v0, Ljava/util/GregorianCalendar;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p1, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    sub-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    mul-int/lit8 v0, v0, 0xc

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget p1, p1, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sub-int/2addr p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "n ems. lrdendOgGr raepir aescroynltpuaa"

    const-string v0, "Only Gregorian calendars are supported."

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    throw p1
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p2, p0, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget p2, p0, Lcom/google/android/material/datepicker/Month;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
