.class public final synthetic Lcom/google/android/material/datepicker/t;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/icu/text/DateFormat;Landroid/icu/util/TimeZone;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t~s a~@i~@@@b~/~/~ s@oo@ bon1~ @~f~ yul~~  @o M@ o@ ~i ~@m@ ~~@-4~vcro~S~@ ~ K~@~ .@@ ilb@@tf ~d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/icu/text/DateFormat;->setTimeZone(Landroid/icu/util/TimeZone;)V

    const/4 v1, 0x0

    return-void
.end method
