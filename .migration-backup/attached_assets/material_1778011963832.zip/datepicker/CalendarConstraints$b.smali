.class public final Lcom/google/android/material/datepicker/CalendarConstraints$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/CalendarConstraints;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field static final e:J

.field static final f:J

.field private static final g:Ljava/lang/String; = "DEEP_COPY_VALIDATOR_KEY"


# instance fields
.field private a:J

.field private b:J

.field private c:Ljava/lang/Long;

.field private d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/16 v0, 0x76c

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/Month;->c(II)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/u;->a(J)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->e:J

    const/4 v3, 0x0

    const/16 v0, 0x834

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v1, 0xb

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/Month;->c(II)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/u;->a(J)J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    sput-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->f:J

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->e:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->f:J

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->b:J

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a(J)Lcom/google/android/material/datepicker/DateValidatorPointForward;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method constructor <init>(Lcom/google/android/material/datepicker/CalendarConstraints;)V
    .locals 4
    .param p1    # Lcom/google/android/material/datepicker/CalendarConstraints;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->e:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a:J

    const/4 v2, 0x2

    move v3, v2

    sget-wide v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->f:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->b:J

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x4

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/datepicker/DateValidatorPointForward;->a(J)Lcom/google/android/material/datepicker/DateValidatorPointForward;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/material/datepicker/CalendarConstraints;->a(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/material/datepicker/CalendarConstraints;->c(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->b:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/material/datepicker/CalendarConstraints;->d(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->c:Ljava/lang/Long;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/material/datepicker/CalendarConstraints;->e(Lcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method


# virtual methods
.method public a()Lcom/google/android/material/datepicker/CalendarConstraints;
    .locals 11
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~@s ~of f@d/ ~@c oou@ M ~ m@@Sbl@1 b~ @~ ~@@iy i~tsl-otK@@~ /b~@vr@~~~ao@o~  @i~ ~ 4~ n~@~@~@~.~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v9, 0x4

    move v10, v9

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string v2, "AC_msLEY_DEVDKOAP_EOPYT"

    const-string v2, "POsCT_YEE_L_POVDDEAYARK"

    const/4 v10, 0x6

    const-string v2, "VADTo_KP_CYI_EPDYEEOORA"

    const-string v2, "DEEP_COPY_VALIDATOR_KEY"

    const/4 v9, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v1, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-wide v3, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v3, v4}, Lcom/google/android/material/datepicker/Month;->d(J)Lcom/google/android/material/datepicker/Month;

    move-result-object v4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-wide v5, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->b:J

    const/4 v9, 0x1

    move v10, v9

    invoke-static {v5, v6}, Lcom/google/android/material/datepicker/Month;->d(J)Lcom/google/android/material/datepicker/Month;

    move-result-object v5

    const/4 v10, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    check-cast v6, Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->c:Ljava/lang/Long;

    const/4 v10, 0x2

    const/4 v9, 0x3

    if-nez v0, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v0, 0x0

    const/4 v9, 0x7

    move v10, v9

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {v2, v3}, Lcom/google/android/material/datepicker/Month;->d(J)Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    :goto_0
    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v8, 0x0

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct/range {v3 .. v8}, Lcom/google/android/material/datepicker/CalendarConstraints;-><init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/CalendarConstraints$a;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    return-object v1
.end method

.method public b(J)Lcom/google/android/material/datepicker/CalendarConstraints$b;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->b:J

    const/4 v1, 0x5

    return-object p0
.end method

.method public c(J)Lcom/google/android/material/datepicker/CalendarConstraints$b;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x1

    move v1, v0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->c:Ljava/lang/Long;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public d(J)Lcom/google/android/material/datepicker/CalendarConstraints$b;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-wide p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a:J

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public e(Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;)Lcom/google/android/material/datepicker/CalendarConstraints$b;
    .locals 2
    .param p1    # Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lcom/google/android/material/datepicker/CalendarConstraints$b;->d:Lcom/google/android/material/datepicker/CalendarConstraints$DateValidator;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method
