.class Lcom/google/android/material/datepicker/m;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/datepicker/m$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Lcom/google/android/material/datepicker/m$b;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Lcom/google/android/material/datepicker/CalendarConstraints;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Lcom/google/android/material/datepicker/DateSelector;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/DateSelector<",
            "*>;"
        }
    .end annotation
.end field

.field private final c:Lcom/google/android/material/datepicker/g$l;

.field private final d:I


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/google/android/material/datepicker/DateSelector;Lcom/google/android/material/datepicker/CalendarConstraints;Lcom/google/android/material/datepicker/g$l;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/datepicker/CalendarConstraints;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "*>;",
            "Lcom/google/android/material/datepicker/CalendarConstraints;",
            "Lcom/google/android/material/datepicker/g$l;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p3}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p3}, Lcom/google/android/material/datepicker/CalendarConstraints;->i()Lcom/google/android/material/datepicker/Month;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p3}, Lcom/google/android/material/datepicker/CalendarConstraints;->n()Lcom/google/android/material/datepicker/Month;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-gtz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v2, v1}, Lcom/google/android/material/datepicker/Month;->a(Lcom/google/android/material/datepicker/Month;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-gtz v0, :cond_1

    const/4 v4, 0x0

    sget v0, Lcom/google/android/material/datepicker/l;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->z0(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    mul-int/2addr v0, v1

    const/4 v3, 0x7

    move v4, v3

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->z0(Landroid/content/Context;)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 p1, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/2addr v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/android/material/datepicker/m;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object p3, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v3, 0x2

    or-int/2addr v4, v3

    iput-object p2, p0, Lcom/google/android/material/datepicker/m;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    iput-object p4, p0, Lcom/google/android/material/datepicker/m;->c:Lcom/google/android/material/datepicker/g$l;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->setHasStableIds(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string p2, " rsaraoPngafcn uPtert a eabceeesntsg"

    const-string p2, " ascnPt artneu eetgtafsgaoenPerrcba "

    const-string p2, "b emcearfctse ra taPgotealrtg nannPe"

    const-string p2, "currentPage cannot be after lastPage"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    throw p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo p2, "scftoPrgrPabe tfaarnutceoein ng r emt"

    const-string p2, "  ome PnPantgaretinfs rrutgbcctfeeear"

    const/4 v4, 0x2

    const-string p2, "ebraib Pur at ogestnecregtcffPnar tan"

    const-string/jumbo p2, "firstPage cannot be after currentPage"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    throw p1
.end method

.method static synthetic a(Lcom/google/android/material/datepicker/m;)Lcom/google/android/material/datepicker/g$l;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "y-@o~su /@@ ofl ~@M. @~~~~4@~bKc i~oa~@~@@ @~@ ~  ~@1i@~/~i~ o~~d@r v~ nm@t@f  otbSobl~ ~u@ @ @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/datepicker/m;->c:Lcom/google/android/material/datepicker/g$l;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method b(I)Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/Month;->r(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method c(I)Ljava/lang/CharSequence;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/m;->b(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/Month;->o()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-object p1
.end method

.method d(Lcom/google/android/material/datepicker/Month;)I
    .locals 3
    .param p1    # Lcom/google/android/material/datepicker/Month;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/Month;->s(Lcom/google/android/material/datepicker/Month;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1
.end method

.method public e(Lcom/google/android/material/datepicker/m$b;I)V
    .locals 5
    .param p1    # Lcom/google/android/material/datepicker/m$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p2}, Lcom/google/android/material/datepicker/Month;->r(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-object v0, p1, Lcom/google/android/material/datepicker/m$b;->a:Landroid/widget/TextView;

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/datepicker/Month;->o()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/google/android/material/datepicker/m$b;->b:Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget v0, Lcom/google/android/material/R$id;->month_grid:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast p1, Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, v0, Lcom/google/android/material/datepicker/l;->a:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Lcom/google/android/material/datepicker/Month;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->b()Lcom/google/android/material/datepicker/l;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p2, p1}, Lcom/google/android/material/datepicker/l;->m(Lcom/google/android/material/datepicker/MaterialCalendarGridView;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/material/datepicker/l;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/m;->b:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x3

    move v4, v3

    iget-object v2, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, p2, v1, v2}, Lcom/google/android/material/datepicker/l;-><init>(Lcom/google/android/material/datepicker/Month;Lcom/google/android/material/datepicker/DateSelector;Lcom/google/android/material/datepicker/CalendarConstraints;)V

    const/4 v4, 0x5

    iget p2, p2, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroid/widget/GridView;->setNumColumns(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/datepicker/MaterialCalendarGridView;->setAdapter(Landroid/widget/ListAdapter;)V

    :goto_0
    const/4 v4, 0x6

    new-instance p2, Lcom/google/android/material/datepicker/m$a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p2, p0, p1}, Lcom/google/android/material/datepicker/m$a;-><init>(Lcom/google/android/material/datepicker/m;Lcom/google/android/material/datepicker/MaterialCalendarGridView;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public f(Landroid/view/ViewGroup;I)Lcom/google/android/material/datepicker/m$b;
    .locals 4
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget v0, Lcom/google/android/material/R$layout;->mtrl_calendar_month_labeled:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p2, v0, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast p2, Landroid/widget/LinearLayout;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    new-instance p1, Landroidx/recyclerview/widget/RecyclerView$q;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/android/material/datepicker/m;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1, v0, v1}, Landroidx/recyclerview/widget/RecyclerView$q;-><init>(II)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p2, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/material/datepicker/m$b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1, p2, v0}, Lcom/google/android/material/datepicker/m$b;-><init>(Landroid/widget/LinearLayout;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/material/datepicker/m$b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p1, p2, v1}, Lcom/google/android/material/datepicker/m$b;-><init>(Landroid/widget/LinearLayout;Z)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p1
.end method

.method public getItemCount()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->k()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/m;->a:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/Month;->r(I)Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/Month;->q()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-wide v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView$g0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/material/datepicker/m$b;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/datepicker/m;->e(Lcom/google/android/material/datepicker/m$b;I)V

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/datepicker/m;->f(Landroid/view/ViewGroup;I)Lcom/google/android/material/datepicker/m$b;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method
