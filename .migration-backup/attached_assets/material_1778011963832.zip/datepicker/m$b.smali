.class public Lcom/google/android/material/datepicker/m$b;
.super Landroidx/recyclerview/widget/RecyclerView$g0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/datepicker/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field final a:Landroid/widget/TextView;

.field final b:Lcom/google/android/material/datepicker/MaterialCalendarGridView;


# direct methods
.method constructor <init>(Landroid/widget/LinearLayout;Z)V
    .locals 4
    .param p1    # Landroid/widget/LinearLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$g0;-><init>(Landroid/view/View;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget v0, Lcom/google/android/material/R$id;->month_title:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/material/datepicker/m$b;->a:Landroid/widget/TextView;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroidx/core/view/k1;->C1(Landroid/view/View;Z)V

    const/4 v3, 0x7

    sget v1, Lcom/google/android/material/R$id;->month_grid:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/material/datepicker/m$b;->b:Lcom/google/android/material/datepicker/MaterialCalendarGridView;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 p1, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method
