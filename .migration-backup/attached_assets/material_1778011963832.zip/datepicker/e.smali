.class Lcom/google/android/material/datepicker/e;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method static a(Ljava/lang/Long;Ljava/lang/Long;)Landroidx/core/util/m;
    .locals 3
    .param p0    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ")",
            "Landroidx/core/util/m<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~aso @fnl loK@1tf@@ i/~-i@~M@ 4 b @@ru.@~s~~@~ ~~oy@ @~ ~@ biS@~@@ob @~@ @~to@md~~~~~/~ cov   ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->b(Ljava/lang/Long;Ljava/lang/Long;Ljava/text/SimpleDateFormat;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method static b(Ljava/lang/Long;Ljava/lang/Long;Ljava/text/SimpleDateFormat;)Landroidx/core/util/m;
    .locals 7
    .param p0    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/text/SimpleDateFormat;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            "Ljava/text/SimpleDateFormat;",
            ")",
            "Landroidx/core/util/m<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez p0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v0}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    if-nez p0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {p0, p1, p2}, Lcom/google/android/material/datepicker/e;->d(JLjava/text/SimpleDateFormat;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, p0}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-object p0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p0, p1, p2}, Lcom/google/android/material/datepicker/e;->d(JLjava/text/SimpleDateFormat;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p0, v0}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object p0

    :cond_2
    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz p2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x1

    new-instance v0, Ljava/util/Date;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v0, v1, v2}, Ljava/util/Date;-><init>(J)V

    const/4 v6, 0x2

    new-instance p0, Ljava/util/Date;

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, v1, v2}, Ljava/util/Date;-><init>(J)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p2, p0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p1, p0}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object p0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 p2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1, p2}, Ljava/util/Calendar;->get(I)I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, p2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-ne v3, v2, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, p2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, p2}, Ljava/util/Calendar;->get(I)I

    move-result p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ne v1, p2, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v0, v1, p0}, Lcom/google/android/material/datepicker/e;->f(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1, p2, v0}, Lcom/google/android/material/datepicker/e;->f(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p0, p1}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object p0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v1, p0}, Lcom/google/android/material/datepicker/e;->f(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1, p2, v0}, Lcom/google/android/material/datepicker/e;->k(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p0, p1}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p0

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0, v1, p0}, Lcom/google/android/material/datepicker/e;->k(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1, p2, v0}, Lcom/google/android/material/datepicker/e;->k(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p0, p1}, Landroidx/core/util/m;->a(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/core/util/m;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x0

    return-object p0
.end method

.method static c(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->d(JLjava/text/SimpleDateFormat;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method static d(JLjava/text/SimpleDateFormat;)Ljava/lang/String;
    .locals 4
    .param p2    # Ljava/text/SimpleDateFormat;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/material/datepicker/u;->v()Ljava/util/Calendar;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v1, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x3

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1, p2}, Ljava/util/Calendar;->get(I)I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ne v0, p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lcom/google/android/material/datepicker/e;->e(J)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lcom/google/android/material/datepicker/e;->j(J)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p0
.end method

.method static e(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->f(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method static f(JLjava/util/Locale;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v1, 0x18

    const/4 v2, 0x1

    move v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->c(Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/google/android/material/datepicker/d;->a(Landroid/icu/text/DateFormat;Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->m(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method static g(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->h(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method static h(JLjava/util/Locale;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 v1, 0x18

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->d(Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p2, v0}, Lcom/google/android/material/datepicker/d;->a(Landroid/icu/text/DateFormat;Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->i(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method static i(J)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 v0, 0x2024

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {v1, p0, p1, v0}, Landroid/text/format/DateUtils;->formatDateTime(Landroid/content/Context;JI)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0
.end method

.method static j(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->k(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method static k(JLjava/util/Locale;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0x18

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->x(Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/google/android/material/datepicker/d;->a(Landroid/icu/text/DateFormat;Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->k(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p0
.end method

.method static l(J)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Lcom/google/android/material/datepicker/e;->m(JLjava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method static m(JLjava/util/Locale;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0x18

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->y(Ljava/util/Locale;)Landroid/icu/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p2, v0}, Lcom/google/android/material/datepicker/d;->a(Landroid/icu/text/DateFormat;Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/google/android/material/datepicker/u;->i(Ljava/util/Locale;)Ljava/text/DateFormat;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x1

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    invoke-virtual {p2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0
.end method
