.class public final synthetic Lcom/google/android/material/badge/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/util/Locale$Category;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/@s@~~~~dm  @~ o~@~/@M4o~~f~@~ @ o@oynSab @@i~ K~@l1@  @ b s~rb@@ol~@o~ ~~i@t-@@t~@u c v  .~~~if"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Ljava/util/Locale$Category;->FORMAT:Ljava/util/Locale$Category;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
