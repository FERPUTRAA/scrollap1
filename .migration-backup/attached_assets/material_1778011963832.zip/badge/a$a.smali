.class Lcom/google/android/material/badge/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/badge/a;->e0(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/view/View;

.field final synthetic b:Landroid/widget/FrameLayout;

.field final synthetic c:Lcom/google/android/material/badge/a;


# direct methods
.method constructor <init>(Lcom/google/android/material/badge/a;Landroid/view/View;Landroid/widget/FrameLayout;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/badge/a$a;->c:Lcom/google/android/material/badge/a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/material/badge/a$a;->a:Landroid/view/View;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/material/badge/a$a;->b:Landroid/widget/FrameLayout;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~sol  i@ lf~~@b~~SoKoy @~du@n~~@@/.o@-~f  ~bti~b@ @@~~/vc~~@ as~@@ @@ ~4 @~r1 @@m@@   ~o~o Mti "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a$a;->c:Lcom/google/android/material/badge/a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/material/badge/a$a;->a:Landroid/view/View;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/badge/a$a;->b:Landroid/widget/FrameLayout;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/badge/a;->i0(Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    return-void
.end method
