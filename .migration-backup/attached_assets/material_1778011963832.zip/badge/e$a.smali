.class Lcom/google/android/material/badge/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/badge/e;->f(Lcom/google/android/material/badge/a;Landroidx/appcompat/widget/Toolbar;ILandroid/widget/FrameLayout;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/Toolbar;

.field final synthetic b:I

.field final synthetic c:Lcom/google/android/material/badge/a;

.field final synthetic d:Landroid/widget/FrameLayout;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/Toolbar;ILcom/google/android/material/badge/a;Landroid/widget/FrameLayout;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/android/material/badge/e$a;->a:Landroidx/appcompat/widget/Toolbar;

    const/4 v0, 0x4

    and-int/2addr v1, v0

    iput p2, p0, Lcom/google/android/material/badge/e$a;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/google/android/material/badge/e$a;->c:Lcom/google/android/material/badge/a;

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/google/android/material/badge/e$a;->d:Landroid/widget/FrameLayout;

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~vs o4~  @l  ~~o @@o@o~is@~ @@~@/~~Sbmb@uM  d@@ ~ @ n~r i@b/~@.~~@ -c@~tal ~~K@i ~~o@ y~~ff@t~1o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/e$a;->a:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x6

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/badge/e$a;->b:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/internal/r;->a(Landroidx/appcompat/widget/Toolbar;I)Landroidx/appcompat/view/menu/ActionMenuItemView;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/material/badge/e$a;->c:Lcom/google/android/material/badge/a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/material/badge/e$a;->a:Landroidx/appcompat/widget/Toolbar;

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lcom/google/android/material/badge/e;->n(Lcom/google/android/material/badge/a;Landroid/content/res/Resources;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/badge/e$a;->c:Lcom/google/android/material/badge/a;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/android/material/badge/e$a;->d:Landroid/widget/FrameLayout;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v1, v0, v2}, Lcom/google/android/material/badge/e;->d(Lcom/google/android/material/badge/a;Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/badge/e$a;->c:Lcom/google/android/material/badge/a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1, v0}, Lcom/google/android/material/badge/e;->a(Lcom/google/android/material/badge/a;Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x3

    return-void
.end method
