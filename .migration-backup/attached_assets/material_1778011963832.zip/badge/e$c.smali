.class Lcom/google/android/material/badge/e$c;
.super Landroidx/core/view/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/badge/e;->b(Lcom/google/android/material/badge/a;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/badge/a;


# direct methods
.method constructor <init>(Lcom/google/android/material/badge/a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/badge/e$c;->a:Lcom/google/android/material/badge/a;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/core/view/a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "i s~~o@f~ b@ol~s@ni~@~4 f@d@@ @o~ ~-t~o@M~ r@u~~iy~ ~@//~m@b  ~l~c ~o @b @ @t~K~@~~aS.@o@    @1v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-super {p0, p1, p2}, Landroidx/core/view/a;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/badge/e$c;->a:Lcom/google/android/material/badge/a;

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/badge/a;->o()Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->a1(Ljava/lang/CharSequence;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
