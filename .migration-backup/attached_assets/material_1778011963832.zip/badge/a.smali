.class public Lcom/google/android/material/badge/a;
.super Landroid/graphics/drawable/Drawable;

# interfaces
.implements Lcom/google/android/material/internal/n$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/badge/a$b;
    }
.end annotation


# static fields
.field public static final n:I = 0x800035

.field public static final o:I = 0x800033

.field public static final p:I = 0x800055

.field public static final q:I = 0x800053

.field private static final r:I = 0x9

.field private static final s:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private static final t:I
    .annotation build Landroidx/annotation/f;
    .end annotation
.end field

.field static final u:Ljava/lang/String; = "+"


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/content/Context;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lcom/google/android/material/shape/j;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Lcom/google/android/material/internal/n;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final d:Landroid/graphics/Rect;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final e:Lcom/google/android/material/badge/BadgeState;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private f:F

.field private g:F

.field private h:I

.field private i:F

.field private j:F

.field private k:F

.field private l:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private m:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/widget/FrameLayout;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_Badge:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput v0, Lcom/google/android/material/badge/a;->s:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$attr;->badgeStyle:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput v0, Lcom/google/android/material/badge/a;->t:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;IIILcom/google/android/material/badge/BadgeState$State;)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/m1;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p5    # Lcom/google/android/material/badge/BadgeState$State;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x2

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    iput-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/google/android/material/internal/q;->c(Landroid/content/Context;)V

    const/4 v8, 0x0

    new-instance v0, Landroid/graphics/Rect;

    const/4 v8, 0x0

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-object v0, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {v0}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v7, 0x5

    xor-int/2addr v8, v7

    iput-object v0, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v0, Lcom/google/android/material/internal/n;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/internal/n;-><init>(Lcom/google/android/material/internal/n$b;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object v1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    sget v0, Lcom/google/android/material/R$style;->TextAppearance_MaterialComponents_Badge:I

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/badge/a;->Z(I)V

    const/4 v8, 0x0

    new-instance v0, Lcom/google/android/material/badge/BadgeState;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    move v3, p2

    move v3, p2

    const/4 v8, 0x5

    move v3, p2

    move v3, p2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    move v4, p3

    move v4, p3

    const/4 v8, 0x0

    move v4, p3

    move v4, p3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    move v5, p4

    move v5, p4

    const/4 v8, 0x3

    move v5, p4

    move v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct/range {v1 .. v6}, Lcom/google/android/material/badge/BadgeState;-><init>(Landroid/content/Context;IIILcom/google/android/material/badge/BadgeState$State;)V

    const/4 v7, 0x6

    move v8, v7

    iput-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->J()V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-void
.end method

.method private C()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @sl~~ ~m~ys~i~~b@l n~~~o@@~o@~@oi@1/~o .cd- u@ @ @~~Mb@@i~@~ @@~~ S~f r@   @~ v/t@a @ tbof@4~Ko"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->getAlpha()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method

.method private D()V
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->f()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/shape/j;->y()Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eq v1, v0, :cond_0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method private E()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/badge/a;->l:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->l:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    check-cast v0, Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v1, Landroid/widget/FrameLayout;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/google/android/material/badge/a;->i0(Landroid/view/View;Landroid/widget/FrameLayout;)V

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private F()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->h()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private G()V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->k0()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v2, 0x6

    move v3, v2

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/material/internal/n;->j(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x6

    return-void
.end method

.method private H()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x5

    xor-int/2addr v2, v1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/internal/n;->j(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private I()V
    .locals 4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->u()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-boolean v1, Lcom/google/android/material/badge/e;->a:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->p()Landroid/widget/FrameLayout;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->p()Landroid/widget/FrameLayout;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private J()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->G()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->H()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->C()V

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->D()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->F()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->E()V

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->I()V

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private Y(Lcom/google/android/material/resources/d;)V
    .locals 4
    .param p1    # Lcom/google/android/material/resources/d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v0, p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v1, p1, v0}, Lcom/google/android/material/internal/n;->i(Lcom/google/android/material/resources/d;Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method private Z(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/material/resources/d;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v1, v0, p1}, Lcom/google/android/material/resources/d;-><init>(Landroid/content/Context;I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Lcom/google/android/material/badge/a;->Y(Lcom/google/android/material/resources/d;)V

    const/4 v3, 0x7

    return-void
.end method

.method private b(Landroid/content/Context;Landroid/graphics/Rect;Landroid/view/View;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->x()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->g()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const v2, 0x800053

    const/4 v5, 0x1

    const/4 v4, 0x5

    if-eq v1, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const v3, 0x800055

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v1, v3, :cond_0

    const/4 v4, 0x0

    move v5, v4

    iget v1, p2, Landroid/graphics/Rect;->top:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    int-to-float v0, v1

    const/4 v5, 0x3

    iput v0, p0, Lcom/google/android/material/badge/a;->g:F

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    iget v1, p2, Landroid/graphics/Rect;->bottom:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    sub-int/2addr v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    int-to-float v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/android/material/badge/a;->g:F

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 v1, 0x9

    const/4 v5, 0x3

    if-gt v0, v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, v0, Lcom/google/android/material/badge/BadgeState;->c:F

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v0, v0, Lcom/google/android/material/badge/BadgeState;->d:F

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput v0, p0, Lcom/google/android/material/badge/a;->i:F

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput v0, p0, Lcom/google/android/material/badge/a;->k:F

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_2

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x3

    iget v0, v0, Lcom/google/android/material/badge/BadgeState;->d:F

    const/4 v4, 0x1

    or-int/2addr v5, v4

    iput v0, p0, Lcom/google/android/material/badge/a;->i:F

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v0, p0, Lcom/google/android/material/badge/a;->k:F

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->m()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Lcom/google/android/material/internal/n;->f(Ljava/lang/String;)F

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    div-float/2addr v0, v1

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v1, v1, Lcom/google/android/material/badge/BadgeState;->e:F

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-float/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v0, p0, Lcom/google/android/material/badge/a;->j:F

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_badge_text_horizontal_edge_offset:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_3

    :cond_3
    const/4 v5, 0x2

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_badge_horizontal_edge_offset:I

    :goto_3
    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->w()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->g()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const v3, 0x800033

    const/4 v5, 0x5

    if-eq v1, v3, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v1, v2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p3}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez p3, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget p2, p2, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    int-to-float p2, p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget p3, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-float/2addr p2, p3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    int-to-float p1, p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    sub-float/2addr p2, p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    int-to-float p1, v0

    const/4 v5, 0x0

    sub-float/2addr p2, p1

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_4

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p2, p2, Landroid/graphics/Rect;->left:I

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    int-to-float p2, p2

    const/4 v5, 0x3

    iget p3, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    sub-float/2addr p2, p3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    int-to-float p1, p1

    const/4 v5, 0x2

    add-float/2addr p2, p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    int-to-float p1, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-float/2addr p2, p1

    :goto_4
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput p2, p0, Lcom/google/android/material/badge/a;->f:F

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_6

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p3}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p3, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget p2, p2, Landroid/graphics/Rect;->left:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    int-to-float p2, p2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p3, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    sub-float/2addr p2, p3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    int-to-float p1, p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    add-float/2addr p2, p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    int-to-float p1, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-float/2addr p2, p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    goto :goto_5

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget p2, p2, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    int-to-float p2, p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget p3, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-float/2addr p2, p3

    const/4 v5, 0x5

    int-to-float p1, p1

    const/4 v5, 0x1

    sub-float/2addr p2, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    int-to-float p1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    sub-float/2addr p2, p1

    :goto_5
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput p2, p0, Lcom/google/android/material/badge/a;->f:F

    :goto_6
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method public static d(Landroid/content/Context;)Lcom/google/android/material/badge/a;
    .locals 9
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x7

    new-instance v6, Lcom/google/android/material/badge/a;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    sget v3, Lcom/google/android/material/badge/a;->t:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    sget v4, Lcom/google/android/material/badge/a;->s:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v5, 0x0

    and-int/2addr v8, v5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/badge/a;-><init>(Landroid/content/Context;IIILcom/google/android/material/badge/BadgeState$State;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    return-object v6
.end method

.method public static e(Landroid/content/Context;I)Lcom/google/android/material/badge/a;
    .locals 9
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/m1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v6, Lcom/google/android/material/badge/a;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget v3, Lcom/google/android/material/badge/a;->t:I

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget v4, Lcom/google/android/material/badge/a;->s:I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    move v2, p1

    move v2, p1

    const/4 v8, 0x5

    move v2, p1

    move v2, p1

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/badge/a;-><init>(Landroid/content/Context;IIILcom/google/android/material/badge/BadgeState$State;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-object v6
.end method

.method private e0(Landroid/view/View;)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget v2, Lcom/google/android/material/R$id;->mtrl_anchor_parent:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq v1, v2, :cond_1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    if-ne v1, v0, :cond_2

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-void

    :cond_2
    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/android/material/badge/a;->f0(Landroid/view/View;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v1, Landroid/widget/FrameLayout;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    sget v2, Lcom/google/android/material/R$id;->mtrl_anchor_parent:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Landroid/view/View;->setId(I)V

    const/4 v5, 0x7

    move v6, v5

    const/4 v2, 0x0

    and-int/2addr v6, v2

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Landroid/view/View;->setMinimumWidth(I)V

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/view/View;->setMinimumHeight(I)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, 0x6

    const/4 v4, -0x1

    move v5, v4

    move v5, v4

    const/4 v6, 0x6

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v6, 0x5

    invoke-virtual {p1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    const/4 v6, 0x6

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Lcom/google/android/material/badge/a$a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/material/badge/a$a;-><init>(Lcom/google/android/material/badge/a;Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x4

    const/4 v5, 0x7

    return-void
.end method

.method static f(Landroid/content/Context;Lcom/google/android/material/badge/BadgeState$State;)Lcom/google/android/material/badge/a;
    .locals 9
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/badge/BadgeState$State;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x4

    new-instance v6, Lcom/google/android/material/badge/a;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget v3, Lcom/google/android/material/badge/a;->t:I

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget v4, Lcom/google/android/material/badge/a;->s:I

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/badge/a;-><init>(Landroid/content/Context;IIILcom/google/android/material/badge/BadgeState$State;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object v6
.end method

.method private static f0(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method private g(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v0, Landroid/graphics/Rect;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->m()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2, v1, v4, v3, v0}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/android/material/badge/a;->f:F

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v3, p0, Lcom/google/android/material/badge/a;->g:F

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    div-int/lit8 v0, v0, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    int-to-float v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    add-float/2addr v3, v0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1, v1, v2, v3, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method

.method private j0()V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    check-cast v0, Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/material/badge/a;->l:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v1, :cond_0

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    check-cast v1, Landroid/view/View;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v0, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez v1, :cond_1

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x4

    new-instance v3, Landroid/graphics/Rect;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v4, Landroid/graphics/Rect;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v5, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v5, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v5}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    check-cast v2, Landroid/widget/FrameLayout;

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-boolean v5, Lcom/google/android/material/badge/e;->a:Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v5, :cond_5

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-nez v2, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast v2, Landroid/view/ViewGroup;

    :cond_4
    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2, v1, v4}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0, v0, v4, v1}, Lcom/google/android/material/badge/a;->b(Landroid/content/Context;Landroid/graphics/Rect;Landroid/view/View;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/android/material/badge/a;->f:F

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget v2, p0, Lcom/google/android/material/badge/a;->g:F

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget v4, p0, Lcom/google/android/material/badge/a;->j:F

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v5, p0, Lcom/google/android/material/badge/a;->k:F

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v0, v1, v2, v4, v5}, Lcom/google/android/material/badge/e;->o(Landroid/graphics/Rect;FFFF)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/android/material/badge/a;->i:F

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->k0(F)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v0, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_6
    :goto_1
    const/4 v7, 0x4

    return-void
.end method

.method private k0()V
    .locals 6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->t()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    int-to-double v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const/4 v4, 0x0

    move v5, v4

    sub-double/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v5, 0x2

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    double-to-int v0, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/android/material/badge/a;->h:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void
.end method

.method private m()Ljava/lang/String;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/android/material/badge/a;->h:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gt v0, v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->p()Ljava/util/Locale;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0}, Ljava/text/NumberFormat;->getInstance(Ljava/util/Locale;)Ljava/text/NumberFormat;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    int-to-long v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/text/NumberFormat;->format(J)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v0, Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object v0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v6, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->p()Ljava/util/Locale;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget v2, Lcom/google/android/material/R$string;->mtrl_exceed_max_badge_number_suffix:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    iget v3, p0, Lcom/google/android/material/badge/a;->h:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput-object v3, v2, v4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v4, "+"

    const-string v4, "+"

    const/4 v6, 0x7

    const-string v4, "+"

    const-string v4, "+"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    aput-object v4, v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v1, v0, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-object v0
.end method

.method private w()I
    .locals 4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->l()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->m()I

    move-result v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->c()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v0
.end method

.method private x()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->r()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->s()I

    move-result v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v3, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->d()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v0
.end method


# virtual methods
.method public A()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->s()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public B()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->t()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method K(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->w(I)V

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method L(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->x(I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public M(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->z(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->D()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public N(I)V
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->g()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->A(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->E()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public O(Ljava/util/Locale;)V
    .locals 3
    .param p1    # Ljava/util/Locale;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->p()Ljava/util/Locale;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/util/Locale;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->J(Ljava/util/Locale;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public P(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->B(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->F()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public Q(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->C(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public R(Ljava/lang/CharSequence;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->D(Ljava/lang/CharSequence;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public S(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/t0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->E(I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public T(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/badge/a;->V(I)V

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/badge/a;->U(I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public U(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->F(I)V

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public V(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->G(I)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public W(I)V
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->n()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->H(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->G()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public X(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->o()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->I(I)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->H()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public a()V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public a0(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/badge/a;->c0(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/badge/a;->b0(I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public b0(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->K(I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->a()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->H()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public c0(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->L(I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public d0(Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->M(Z)V

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->I()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->getAlpha()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->draw(Landroid/graphics/Canvas;)V

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/badge/a;->g(Landroid/graphics/Canvas;)V

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public g0(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/badge/a;->i0(Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v2, 0x6

    return-void
.end method

.method public getAlpha()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->e()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->d:Landroid/graphics/Rect;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return v0
.end method

.method public getOpacity()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, -0x3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method h()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->c()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public h0(Landroid/view/View;Landroid/view/ViewGroup;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    instance-of v0, p2, Landroid/widget/FrameLayout;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p2, Landroid/widget/FrameLayout;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/badge/a;->i0(Landroid/view/View;Landroid/widget/FrameLayout;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string p2, "brmmcd u aeaaaurenaFBtt tLotoyess Pmume"

    const-string p2, "eesLgmeutm saubtaatoyartorumdae cB nFP "

    const/4 v2, 0x5

    const-string p2, "customBadgeParent must be a FrameLayout"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    move v2, v1

    throw p1
.end method

.method i()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->d()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public i0(Landroid/view/View;Landroid/widget/FrameLayout;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/widget/FrameLayout;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/badge/a;->l:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-boolean v0, Lcom/google/android/material/badge/e;->a:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/badge/a;->e0(Landroid/view/View;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x6

    invoke-direct {v1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-static {p1}, Lcom/google/android/material/badge/a;->f0(Landroid/view/View;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->j0()V

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public j()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->b:Lcom/google/android/material/shape/j;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->y()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->g()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public l()Ljava/util/Locale;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->p()Ljava/util/Locale;

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method

.method public n()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->c:Lcom/google/android/material/internal/n;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public o()Ljava/lang/CharSequence;
    .locals 8
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x7

    move v7, v6

    return-object v1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v0, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->k()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->a:Ljava/lang/ref/WeakReference;

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast v0, Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget v2, p0, Lcom/google/android/material/badge/a;->h:I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-gt v1, v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->k()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->u()I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    aput-object v5, v4, v3

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v0, v1, v2, v4}, Landroid/content/res/Resources;->getQuantityString(II[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    return-object v0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1}, Lcom/google/android/material/badge/BadgeState;->i()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-array v2, v4, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget v4, p0, Lcom/google/android/material/badge/a;->h:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    aput-object v4, v2, v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v1

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->j()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-object v0
.end method

.method public onStateChange([I)Z
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onStateChange([I)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    return p1
.end method

.method public p()Landroid/widget/FrameLayout;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->m:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast v0, Landroid/widget/FrameLayout;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public q()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->m()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public r()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->l()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public s()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->m()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public setAlpha(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/badge/BadgeState;->y(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/badge/a;->C()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public t()I
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->n()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public u()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/badge/a;->B()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->o()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method v()Lcom/google/android/material/badge/BadgeState$State;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->q()Lcom/google/android/material/badge/BadgeState$State;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public y()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->s()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public z()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/badge/a;->e:Lcom/google/android/material/badge/BadgeState;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/badge/BadgeState;->r()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method
