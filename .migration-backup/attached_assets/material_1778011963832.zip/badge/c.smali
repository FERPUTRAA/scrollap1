.class public final synthetic Lcom/google/android/material/badge/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/util/Locale$Category;)Ljava/util/Locale;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s~m@ca~o oio/d/@@~ o@~b o ~ ro K.@@@@ @flb@S~~~y@~~~f@@-@ ~st  b~n1i~@~@ ~@@ ~~ ~@ul~tiM  v4~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Ljava/util/Locale;->getDefault(Ljava/util/Locale$Category;)Ljava/util/Locale;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method
