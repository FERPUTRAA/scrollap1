.class public final Lcom/google/android/material/badge/BadgeState$State;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/badge/BadgeState;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "State"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/material/badge/BadgeState$State;",
            ">;"
        }
    .end annotation
.end field

.field private static final s:I = -0x1

.field private static final t:I = -0x2


# instance fields
.field private a:I
    .annotation build Landroidx/annotation/m1;
    .end annotation
.end field

.field private b:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private c:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private d:I

.field private e:I

.field private f:I

.field private g:Ljava/util/Locale;

.field private h:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:I
    .annotation build Landroidx/annotation/t0;
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private k:Ljava/lang/Integer;

.field private l:Ljava/lang/Boolean;

.field private m:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private n:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private o:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private p:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private q:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field

.field private r:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/r;
        unit = 0x1
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/badge/BadgeState$State$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/material/badge/BadgeState$State$a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/badge/BadgeState$State;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/16 v0, 0xff

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, -0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>(Landroid/os/Parcel;)V
    .locals 3
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/16 v0, 0xff

    const/4 v1, 0x2

    and-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, -0x2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->b:Ljava/lang/Integer;

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->c:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->h:Ljava/lang/CharSequence;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/badge/BadgeState$State;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->k:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->m:Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->n:Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->o:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    check-cast v0, Ljava/lang/Integer;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->p:Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->q:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->r:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    check-cast v0, Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object p1

    const/4 v2, 0x6

    check-cast p1, Ljava/util/Locale;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->g:Ljava/util/Locale;

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic A(Lcom/google/android/material/badge/BadgeState$State;Ljava/util/Locale;)Ljava/util/Locale;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "oos  yo@~t~@ ~  @@~@-/@~dl l/oci@~~@@u  ~~~f@o@r@ ob 4M@n~ st~v.~~ ~~@m~i 1i@ ~b~@bf  @a@K ~~@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->g:Ljava/util/Locale;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic B(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/CharSequence;
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->h:Ljava/lang/CharSequence;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic C(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->h:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method static synthetic D(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->i:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic E(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->i:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic F(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->j:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    return p0
.end method

.method static synthetic G(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->j:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    return p1
.end method

.method static synthetic H(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Boolean;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-object p0
.end method

.method static synthetic J(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic L(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic M(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic O(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic P(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic R(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->b:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic S(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->b:Ljava/lang/Integer;

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic T(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->c:Ljava/lang/Integer;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic U(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->c:Ljava/lang/Integer;

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic a(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->a:I

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic c(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method static synthetic d(Lcom/google/android/material/badge/BadgeState$State;)I
    .locals 2

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic e(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->k:Ljava/lang/Integer;

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic g(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->k:Ljava/lang/Integer;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic h(Lcom/google/android/material/badge/BadgeState$State;I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic i(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->m:Ljava/lang/Integer;

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic k(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->m:Ljava/lang/Integer;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic n(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->n:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic o(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->n:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic q(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->o:Ljava/lang/Integer;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic r(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->o:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic s(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->p:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic u(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->p:Ljava/lang/Integer;

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic v(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->q:Ljava/lang/Integer;

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-object p0
.end method

.method static synthetic w(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->q:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic x(Lcom/google/android/material/badge/BadgeState$State;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->r:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic y(Lcom/google/android/material/badge/BadgeState$State;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/badge/BadgeState$State;->r:Ljava/lang/Integer;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic z(Lcom/google/android/material/badge/BadgeState$State;)Ljava/util/Locale;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/badge/BadgeState$State;->g:Ljava/util/Locale;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p2, p0, Lcom/google/android/material/badge/BadgeState$State;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->b:Ljava/lang/Integer;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->c:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p2, p0, Lcom/google/android/material/badge/BadgeState$State;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    iget p2, p0, Lcom/google/android/material/badge/BadgeState$State;->e:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget p2, p0, Lcom/google/android/material/badge/BadgeState$State;->f:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->h:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-nez p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p2, p0, Lcom/google/android/material/badge/BadgeState$State;->i:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->k:Ljava/lang/Integer;

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->m:Ljava/lang/Integer;

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->n:Ljava/lang/Integer;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->o:Ljava/lang/Integer;

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->p:Ljava/lang/Integer;

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->q:Ljava/lang/Integer;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->r:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->l:Ljava/lang/Boolean;

    const/4 v0, 0x7

    and-int/2addr v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/material/badge/BadgeState$State;->g:Ljava/util/Locale;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method
