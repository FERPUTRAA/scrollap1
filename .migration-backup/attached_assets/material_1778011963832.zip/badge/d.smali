.class public final synthetic Lcom/google/android/material/badge/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/View;)Landroid/view/View$AccessibilityDelegate;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1us~  S@o@ ~m~ @~~@n~oa~ @~b@@~ @@  s~~.d@o~o@@  @boy@i4c @-i iMrb~~t@Klo/@t fl~ ~ ~@~~ / ~~v@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getAccessibilityDelegate()Landroid/view/View$AccessibilityDelegate;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method
