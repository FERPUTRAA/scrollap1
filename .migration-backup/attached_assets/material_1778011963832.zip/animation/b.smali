.class public Lcom/google/android/material/animation/b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/animation/AnimatorSet;Ljava/util/List;)V
    .locals 12
    .param p0    # Landroid/animation/AnimatorSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/animation/AnimatorSet;",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;)V"
        }
    .end annotation

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "d s~~b~@lfM~1@4~cr o~ ~@ ~@/@ @m~-i~@~~o i/~@  s  ~@~@@@.~bn@u@o@@@~t~b ovi fao~ ~@  Kloy ~~S@ t"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v11, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v3, 0x0

    move v11, v3

    const/4 v10, 0x5

    const/4 v11, 0x0

    move v4, v3

    move v4, v3

    const/4 v11, 0x2

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-ge v4, v0, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    check-cast v5, Landroid/animation/Animator;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v5}, Landroid/animation/Animator;->getStartDelay()J

    move-result-wide v6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v5}, Landroid/animation/Animator;->getDuration()J

    move-result-wide v8

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    add-long/2addr v6, v8

    const/4 v11, 0x2

    const/4 v10, 0x0

    invoke-static {v1, v2, v6, v7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    filled-new-array {v3, v3}, [I

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofInt([I)Landroid/animation/ValueAnimator;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-interface {p1, v3, v0}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0, p1}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    const/4 v10, 0x5

    move v11, v10

    return-void
.end method
