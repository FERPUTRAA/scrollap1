.class public Lcom/google/android/material/animation/i;
.super Ljava/lang/Object;


# instance fields
.field private a:J

.field private b:J

.field private c:Landroid/animation/TimeInterpolator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:I

.field private e:I


# direct methods
.method public constructor <init>(JJ)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/animation/i;->c:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/animation/i;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/animation/i;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-wide p1, p0, Lcom/google/android/material/animation/i;->a:J

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-wide p3, p0, Lcom/google/android/material/animation/i;->b:J

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(JJLandroid/animation/TimeInterpolator;)V
    .locals 3
    .param p5    # Landroid/animation/TimeInterpolator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    move v2, v1

    iput v0, p0, Lcom/google/android/material/animation/i;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/android/material/animation/i;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/google/android/material/animation/i;->a:J

    iput-wide p3, p0, Lcom/google/android/material/animation/i;->b:J

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p5, p0, Lcom/google/android/material/animation/i;->c:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method static b(Landroid/animation/ValueAnimator;)Lcom/google/android/material/animation/i;
    .locals 9
    .param p0    # Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x1

    new-instance v6, Lcom/google/android/material/animation/i;

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getStartDelay()J

    move-result-wide v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getDuration()J

    move-result-wide v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p0}, Lcom/google/android/material/animation/i;->f(Landroid/animation/ValueAnimator;)Landroid/animation/TimeInterpolator;

    move-result-object v5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/animation/i;-><init>(JJLandroid/animation/TimeInterpolator;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getRepeatCount()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    iput v0, v6, Lcom/google/android/material/animation/i;->d:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getRepeatMode()I

    move-result p0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput p0, v6, Lcom/google/android/material/animation/i;->e:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object v6
.end method

.method private static f(Landroid/animation/ValueAnimator;)Landroid/animation/TimeInterpolator;
    .locals 3
    .param p0    # Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    instance-of v0, p0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of v0, p0, Landroid/view/animation/AccelerateInterpolator;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object p0, Lcom/google/android/material/animation/a;->c:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object p0

    :cond_1
    const/4 v1, 0x5

    move v2, v1

    instance-of v0, p0, Landroid/view/animation/DecelerateInterpolator;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object p0, Lcom/google/android/material/animation/a;->d:Landroid/animation/TimeInterpolator;

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0

    :cond_3
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object p0, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method


# virtual methods
.method public a(Landroid/animation/Animator;)V
    .locals 4
    .param p1    # Landroid/animation/Animator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/animation/Animator;->setStartDelay(J)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->e()Landroid/animation/TimeInterpolator;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    instance-of v0, p1, Landroid/animation/ValueAnimator;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    check-cast p1, Landroid/animation/ValueAnimator;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->g()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->h()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->setRepeatMode(I)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public c()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/google/android/material/animation/i;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-wide v0
.end method

.method public d()J
    .locals 4

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/google/android/material/animation/i;->b:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-wide v0
.end method

.method public e()Landroid/animation/TimeInterpolator;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/animation/i;->c:Landroid/animation/TimeInterpolator;

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    :goto_0
    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ne p0, p1, :cond_0

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    const/4 p1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    return p1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    instance-of v0, p1, Lcom/google/android/material/animation/i;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    shl-int/2addr v7, v1

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    return v1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    check-cast p1, Lcom/google/android/material/animation/i;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    cmp-long v0, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    return v1

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    cmp-long v0, v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_3

    const/4 v7, 0x0

    return v1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->g()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/animation/i;->g()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eq v0, v2, :cond_4

    const/4 v7, 0x1

    return v1

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->h()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/animation/i;->h()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eq v0, v2, :cond_5

    const/4 v7, 0x5

    return v1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->e()Landroid/animation/TimeInterpolator;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/animation/i;->e()Landroid/animation/TimeInterpolator;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    return p1
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/animation/i;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public h()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget v0, p0, Lcom/google/android/material/animation/i;->e:I

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return v0
.end method

.method public hashCode()I
    .locals 9

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/16 v4, 0x20

    const/4 v7, 0x4

    move v8, v7

    ushr-long/2addr v2, v4

    const/4 v8, 0x6

    xor-long/2addr v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    long-to-int v0, v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    mul-int/lit8 v0, v0, 0x1f

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    ushr-long v3, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    xor-long/2addr v1, v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    long-to-int v1, v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    add-int/2addr v0, v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->e()Landroid/animation/TimeInterpolator;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/2addr v0, v1

    const/4 v8, 0x2

    mul-int/lit8 v0, v0, 0x1f

    const/4 v8, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->g()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    add-int/2addr v0, v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    mul-int/lit8 v0, v0, 0x1f

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->h()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    add-int/2addr v0, v1

    const/4 v8, 0x3

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v1, 0xa

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 v1, 0x7b

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "ylsdes  "

    const-string v1, "  s:leyd"

    const/4 v4, 0x5

    const-string v1, ":e m lda"

    const-string v1, " delay: "

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "drimou :ant"

    const-string/jumbo v1, "rn:mid auot"

    const-string v1, "aru ibo :tn"

    const-string v1, " duration: "

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "o:alniuop r oer"

    const-string/jumbo v1, "pnarooro:t l ie"

    const/4 v4, 0x7

    const-string/jumbo v1, "torar:np tlp ei"

    const-string v1, " interpolator: "

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->e()Landroid/animation/TimeInterpolator;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, " u btoaeqprtne"

    const-string v1, ":naetbor tpeu "

    const/4 v4, 0x5

    const-string/jumbo v1, "tesneo at:Cpru"

    const-string v1, " repeatCount: "

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->g()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "ptemeo :erMa "

    const-string v1, ":t e auMeopre"

    const/4 v4, 0x0

    const-string v1, "eerdoe o t:Mp"

    const-string v1, " repeatMode: "

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/animation/i;->h()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string/jumbo v1, "}n/"

    const-string/jumbo v1, "}\n"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method
