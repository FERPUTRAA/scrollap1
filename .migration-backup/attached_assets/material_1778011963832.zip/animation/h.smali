.class public Lcom/google/android/material/animation/h;
.super Ljava/lang/Object;


# static fields
.field private static final c:Ljava/lang/String; = "MotionSpec"


# instance fields
.field private final a:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "Ljava/lang/String;",
            "Lcom/google/android/material/animation/i;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "Ljava/lang/String;",
            "[",
            "Landroid/animation/PropertyValuesHolder;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Landroidx/collection/m;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/animation/h;->b:Landroidx/collection/m;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method private static a(Lcom/google/android/material/animation/h;Landroid/animation/Animator;)V
    .locals 4
    .param p0    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l s1 ~@@~ib@t a~~4 Kot M~~@~@n~@ ~@bdo    u@. ~cv ~~~~@oi~So flb@@@@@so/ @~~@~ -~@/r~i@o~ ~@m@yf"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    instance-of v0, p1, Landroid/animation/ObjectAnimator;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    check-cast p1, Landroid/animation/ObjectAnimator;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->getPropertyName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getValues()[Landroid/animation/PropertyValuesHolder;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->getPropertyName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/animation/i;->b(Landroid/animation/ValueAnimator;)Lcom/google/android/material/animation/i;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/google/android/material/animation/h;->m(Ljava/lang/String;Lcom/google/android/material/animation/i;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, " jamtsrmOo teibcutare nnoi AAmmnb ta"

    const-string v1, "Animator must be an ObjectAnimator: "

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p0
.end method

.method private b([Landroid/animation/PropertyValuesHolder;)[Landroid/animation/PropertyValuesHolder;
    .locals 5
    .param p1    # [Landroid/animation/PropertyValuesHolder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    array-length v0, p1

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v0, v0, [Landroid/animation/PropertyValuesHolder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    array-length v2, p1

    const/4 v4, 0x1

    if-ge v1, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    aget-object v2, p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2}, Landroid/animation/PropertyValuesHolder;->clone()Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v0
.end method

.method public static c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/animation/h;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p0, p1}, Landroid/animation/AnimatorInflater;->loadAnimator(Landroid/content/Context;I)Landroid/animation/Animator;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    instance-of v1, p0, Landroid/animation/AnimatorSet;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast p0, Landroid/animation/AnimatorSet;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/animation/AnimatorSet;->getChildAnimations()Ljava/util/ArrayList;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/google/android/material/animation/h;->e(Ljava/util/List;)Lcom/google/android/material/animation/h;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/google/android/material/animation/h;->e(Ljava/util/List;)Lcom/google/android/material/animation/h;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0

    :catch_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "o teon0/C/x ul n#e riaosoamstaid nIac"

    const-string/jumbo v2, "oasu eD/ me0 #arCxdIntniotaasl/c noi "

    const/4 v4, 0x2

    const-string v2, "0 neubrt/io n nrCdclsaaea#iaox/oD  mt"

    const-string v2, "Can\'t load animation resource ID #0x"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "oMtnpSucie"

    const-string v1, "MntmeicoSp"

    const/4 v4, 0x3

    const-string/jumbo v1, "otecoSppin"

    const-string v1, "MotionSpec"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method private static e(Ljava/util/List;)Lcom/google/android/material/animation/h;
    .locals 6
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;)",
            "Lcom/google/android/material/animation/h;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/material/animation/h;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v0}, Lcom/google/android/material/animation/h;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ge v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v3, Landroid/animation/Animator;

    const/4 v5, 0x1

    invoke-static {v0, v3}, Lcom/google/android/material/animation/h;->a(Lcom/google/android/material/animation/h;Landroid/animation/Animator;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x7

    if-ne p0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v1, 0x6

    instance-of v0, p1, Lcom/google/android/material/animation/h;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/material/animation/h;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p1, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroidx/collection/m;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method

.method public f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/util/Property;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "TT;",
            "Landroid/util/Property<",
            "TT;*>;)",
            "Landroid/animation/ObjectAnimator;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p2, v0}, Landroid/animation/ObjectAnimator;->ofPropertyValuesHolder(Ljava/lang/Object;[Landroid/animation/PropertyValuesHolder;)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Landroid/animation/ObjectAnimator;->setProperty(Landroid/util/Property;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/h;->h(Ljava/lang/String;)Lcom/google/android/material/animation/i;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p2
.end method

.method public g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/animation/h;->b:Landroidx/collection/m;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p1, [Landroid/animation/PropertyValuesHolder;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/animation/h;->b([Landroid/animation/PropertyValuesHolder;)[Landroid/animation/PropertyValuesHolder;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p1
.end method

.method public h(Ljava/lang/String;)Lcom/google/android/material/animation/i;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/h;->k(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/material/animation/i;

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/collection/m;->hashCode()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public i()J
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v10, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v3, 0x0

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-ge v3, v0, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v9, 0x6

    and-int/2addr v10, v9

    invoke-virtual {v4, v3}, Landroidx/collection/m;->p(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    check-cast v4, Lcom/google/android/material/animation/i;

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v4}, Lcom/google/android/material/animation/i;->c()J

    move-result-wide v5

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v4}, Lcom/google/android/material/animation/i;->d()J

    move-result-wide v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    add-long/2addr v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v1, v2, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    return-wide v1
.end method

.method public j(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/animation/h;->b:Landroidx/collection/m;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method public k(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 p1, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method public l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/animation/h;->b:Landroidx/collection/m;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public m(Ljava/lang/String;Lcom/google/android/material/animation/i;)V
    .locals 3
    .param p2    # Lcom/google/android/material/animation/i;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v1, 0x7b

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "sognit: qi"

    const-string/jumbo v1, "gintos  :i"

    const/4 v3, 0x0

    const-string/jumbo v1, "gis:s ntmi"

    const-string v1, " timings: "

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/animation/h;->a:Landroidx/collection/m;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "}/n"

    const-string/jumbo v1, "n/}"

    const/4 v3, 0x1

    const-string/jumbo v1, "}/n"

    const-string/jumbo v1, "}\n"

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method
