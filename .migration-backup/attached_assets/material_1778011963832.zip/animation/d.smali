.class public Lcom/google/android/material/animation/d;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Landroid/view/ViewGroup;",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Landroid/view/ViewGroup;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/animation/d;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "alsrpcsdlneAi"

    const-string v1, "alslehiAdnprc"

    const/4 v3, 0x5

    const-string/jumbo v1, "hnamAhcpdillr"

    const-string v1, "childrenAlpha"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/android/material/animation/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/material/animation/d;->a:Landroid/util/Property;

    const/4 v3, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method


# virtual methods
.method public a(Landroid/view/ViewGroup;)Ljava/lang/Float;
    .locals 3
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oa@lo~@ ~@@n@ ~@@@@ ~~~r@y@@f/v~~i-4@  ~ @s@ @~~oM~ 1~ bd~@b~u ~t o imf@S@ .~c~~K @o ~lb~i /t~ o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$id;->mtrl_internal_children_alpha_tag:I

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Ljava/lang/Float;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    move v2, v1

    return-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1
.end method

.method public b(Landroid/view/ViewGroup;Ljava/lang/Float;)V
    .locals 5
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Float;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    sget v0, Lcom/google/android/material/R$id;->mtrl_internal_children_alpha_tag:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ge v1, v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2, p2}, Landroid/view/View;->setAlpha(F)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/d;->a(Landroid/view/ViewGroup;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    check-cast p2, Ljava/lang/Float;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/animation/d;->b(Landroid/view/ViewGroup;Ljava/lang/Float;)V

    const/4 v1, 0x5

    return-void
.end method
