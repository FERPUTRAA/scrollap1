.class public Lcom/google/android/material/animation/a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field public static final a:Landroid/animation/TimeInterpolator;

.field public static final b:Landroid/animation/TimeInterpolator;

.field public static final c:Landroid/animation/TimeInterpolator;

.field public static final d:Landroid/animation/TimeInterpolator;

.field public static final e:Landroid/animation/TimeInterpolator;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Landroid/view/animation/LinearInterpolator;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    sput-object v0, Lcom/google/android/material/animation/a;->a:Landroid/animation/TimeInterpolator;

    const/4 v1, 0x3

    and-int/2addr v2, v1

    new-instance v0, Landroidx/interpolator/view/animation/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Landroidx/interpolator/view/animation/b;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    sput-object v0, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Landroidx/interpolator/view/animation/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Landroidx/interpolator/view/animation/a;-><init>()V

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/material/animation/a;->c:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x2

    new-instance v0, Landroidx/interpolator/view/animation/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Landroidx/interpolator/view/animation/c;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/animation/a;->d:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/material/animation/a;->e:Landroid/animation/TimeInterpolator;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public static a(FFF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~.s o @i~ l- @@~ @@~b~~ @@4aol @K~u~  ~r@fo~ @ ~~@~~@m/icb~@y @b~M~@o@t~i ~  ~osn ft@@o/1v ~d@@S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    sub-float/2addr p1, p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    mul-float/2addr p2, p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    add-float/2addr p0, p2

    const/4 v0, 0x2

    const/4 v0, 0x5

    return p0
.end method

.method public static b(FFFFF)F
    .locals 3
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p3    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p4    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    cmpg-float v0, p4, p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-gez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    cmpl-float v0, p4, p3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-lez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    sub-float/2addr p4, p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sub-float/2addr p3, p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    div-float/2addr p4, p3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0, p1, p4}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0
.end method

.method public static c(IIF)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    sub-int/2addr p1, p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    int-to-float p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    mul-float/2addr p2, p1

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    add-int/2addr p0, p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return p0
.end method
