.class public Lcom/google/android/material/animation/f;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Landroid/widget/ImageView;",
        "Landroid/graphics/Matrix;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-class v0, Landroid/graphics/Matrix;

    const-class v0, Landroid/graphics/Matrix;

    const/4 v3, 0x2

    const-class v0, Landroid/graphics/Matrix;

    const-class v0, Landroid/graphics/Matrix;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v1, "mysePoaispgtrriMxae"

    const-string v1, "eMsprrxematPrgyoiai"

    const/4 v3, 0x7

    const-string/jumbo v1, "imymirMeaaPtorrpxtg"

    const-string/jumbo v1, "imageMatrixProperty"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0, v1}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/animation/f;->a:Landroid/graphics/Matrix;

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/widget/ImageView;)Landroid/graphics/Matrix;
    .locals 3
    .param p1    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ @ o/@4io o~~~u~@n@ @@mo@  1@~ ~~f~iK@lla~~ ~ ~ o vc/t .t~Mo~-@@f~o@y@ib~~@~@  @ ~b s @rS~~d~b@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/animation/f;->a:Landroid/graphics/Matrix;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/widget/ImageView;->getImageMatrix()Landroid/graphics/Matrix;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/animation/f;->a:Landroid/graphics/Matrix;

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p1
.end method

.method public b(Landroid/widget/ImageView;Landroid/graphics/Matrix;)V
    .locals 2
    .param p1    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Matrix;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    check-cast p1, Landroid/widget/ImageView;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/animation/f;->a(Landroid/widget/ImageView;)Landroid/graphics/Matrix;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x3

    move v1, v0

    check-cast p1, Landroid/widget/ImageView;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p2, Landroid/graphics/Matrix;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/animation/f;->b(Landroid/widget/ImageView;Landroid/graphics/Matrix;)V

    const/4 v1, 0x0

    return-void
.end method
