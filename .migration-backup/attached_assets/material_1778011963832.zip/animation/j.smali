.class public Lcom/google/android/material/animation/j;
.super Ljava/lang/Object;


# instance fields
.field public final a:I

.field public final b:F

.field public final c:F


# direct methods
.method public constructor <init>(IFF)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/animation/j;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/material/animation/j;->b:F

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/material/animation/j;->c:F

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method
