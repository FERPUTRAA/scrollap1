.class public Lcom/google/android/material/animation/g;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/TypeEvaluator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/animation/TypeEvaluator<",
        "Landroid/graphics/Matrix;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:[F

.field private final b:[F

.field private final c:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v0, 0x9

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-array v1, v0, [F

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/android/material/animation/g;->a:[F

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-array v0, v0, [F

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/animation/g;->b:[F

    const/4 v3, 0x1

    const/4 v2, 0x1

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/material/animation/g;->c:Landroid/graphics/Matrix;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a(FLandroid/graphics/Matrix;Landroid/graphics/Matrix;)Landroid/graphics/Matrix;
    .locals 4
    .param p2    # Landroid/graphics/Matrix;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/Matrix;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ysl~  c~@@@@b~a@~~~Sli-r@@ id~~~ 4@n.miKtf ~ @@ @ @o1/@t~ ~s u~~ @b~@ oo@@~@fb@ M ~~@~~oo~ /vo "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/animation/g;->a:[F

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Landroid/graphics/Matrix;->getValues([F)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/google/android/material/animation/g;->b:[F

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p3, p2}, Landroid/graphics/Matrix;->getValues([F)V

    const/4 v3, 0x4

    const/4 p2, 0x0

    const/4 v3, 0x4

    move v2, p2

    move v2, p2

    :goto_0
    const/4 v3, 0x5

    const/16 p3, 0x9

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ge p2, p3, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-object p3, p0, Lcom/google/android/material/animation/g;->b:[F

    const/4 v3, 0x3

    aget v0, p3, p2

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/animation/g;->a:[F

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    aget v1, v1, p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    sub-float/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    mul-float/2addr v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-float/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    aput v1, p3, p2

    const/4 v3, 0x5

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/animation/g;->c:Landroid/graphics/Matrix;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/google/android/material/animation/g;->b:[F

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/graphics/Matrix;->setValues([F)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/animation/g;->c:Landroid/graphics/Matrix;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1
.end method

.method public bridge synthetic evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p2, Landroid/graphics/Matrix;

    const/4 v0, 0x7

    move v1, v0

    check-cast p3, Landroid/graphics/Matrix;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/animation/g;->a(FLandroid/graphics/Matrix;Landroid/graphics/Matrix;)Landroid/graphics/Matrix;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method
