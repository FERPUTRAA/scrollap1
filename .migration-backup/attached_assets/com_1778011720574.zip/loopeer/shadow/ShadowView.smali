.class public Lcom/loopeer/shadow/ShadowView;
.super Landroid/view/ViewGroup;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/loopeer/shadow/ShadowView$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nShadowView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ShadowView.kt\ncom/loopeer/shadow/ShadowView\n*L\n1#1,482:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/i0;
    d1 = {
        "\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0017\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\r\n\u0002\u0008\u000b\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0002\u0008=\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u0008\u0016\u0018\u00002\u00020\u0001:\u0001FB/\u0008\u0007\u0012\n\u0010\u0095\u0001\u001a\u0005\u0018\u00010\u0094\u0001\u0012\u000b\u0008\u0002\u0010\u0096\u0001\u001a\u0004\u0018\u000108\u0012\t\u0008\u0002\u0010\u0097\u0001\u001a\u00020\u0008\u00a2\u0006\u0006\u0008\u0098\u0001\u0010\u0099\u0001J\u0008\u0010\u0003\u001a\u00020\u0002H\u0002J(\u0010\n\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0008H\u0002J0\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\u00082\u0006\u0010\u000c\u001a\u00020\u00082\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u00082\u0006\u0010\u0010\u001a\u00020\u000fH\u0002J\u0008\u0010\u0012\u001a\u00020\u0004H\u0002J\u0008\u0010\u0013\u001a\u00020\u0002H\u0002J\u0008\u0010\u0014\u001a\u00020\u0008H\u0002J\u0008\u0010\u0015\u001a\u00020\u0008H\u0002J\u0018\u0010\u0018\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u00082\u0006\u0010\u0017\u001a\u00020\u0008H\u0014J0\u0010\u001a\u001a\u00020\u00022\u0006\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\u000b\u001a\u00020\u00082\u0006\u0010\u000c\u001a\u00020\u00082\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u0008H\u0014J\u0012\u0010\u001d\u001a\u00020\u00022\u0008\u0010\u001c\u001a\u0004\u0018\u00010\u001bH\u0014J\u0012\u0010\u001e\u001a\u00020\u00022\u0008\u0010\u001c\u001a\u0004\u0018\u00010\u001bH\u0016J\u0010\u0010\u001f\u001a\u00020\u00022\u0008\u0010\u001c\u001a\u0004\u0018\u00010\u001bJ\n\u0010!\u001a\u0004\u0018\u00010 H\u0016J(\u0010%\u001a\u00020\u00022\u0006\u0010\"\u001a\u00020\u00082\u0006\u0010\u0013\u001a\u00020\u00082\u0006\u0010#\u001a\u00020\u00082\u0006\u0010$\u001a\u00020\u0008H\u0014J\u0008\u0010&\u001a\u00020\u0008H\u0016J\u0010\u0010(\u001a\u00020\u00022\u0006\u0010\'\u001a\u00020\u0008H\u0016J\u0010\u0010*\u001a\u00020\u000f2\u0006\u0010)\u001a\u00020 H\u0014J\u0008\u0010+\u001a\u00020\u0002H\u0016J\u0008\u0010,\u001a\u00020\u0002H\u0014J\u0012\u0010.\u001a\u00020\u00022\u0008\u0010-\u001a\u0004\u0018\u00010 H\u0016J\u0018\u00101\u001a\u00020\u00022\u0006\u0010/\u001a\u00020\u00042\u0006\u00100\u001a\u00020\u0004H\u0016J&\u00102\u001a\u00020\u00022\u0006\u0010\u000b\u001a\u00020\u00082\u0006\u0010\u000c\u001a\u00020\u00082\u0006\u0010\r\u001a\u00020\u00082\u0006\u0010\u000e\u001a\u00020\u0008J&\u00107\u001a\u00020\u00022\u0006\u00103\u001a\u00020\u00042\u0006\u00104\u001a\u00020\u00042\u0006\u00105\u001a\u00020\u00042\u0006\u00106\u001a\u00020\u0004J\u0010\u0010;\u001a\u00020:2\u0006\u00109\u001a\u000208H\u0016J\u0008\u0010<\u001a\u00020\u000fH\u0016J\u0010\u0010?\u001a\u00020\u000f2\u0006\u0010>\u001a\u00020=H\u0014J\u0010\u0010A\u001a\u00020=2\u0006\u0010@\u001a\u00020=H\u0014J\u0008\u0010C\u001a\u00020BH\u0016J\u0006\u0010D\u001a\u00020\u0008J\u0006\u0010E\u001a\u00020\u0008R\u0014\u0010H\u001a\u00020\u00088\u0002X\u0082D\u00a2\u0006\u0006\n\u0004\u0008F\u0010GR\u0016\u0010J\u001a\u00020\u00088\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008I\u0010GR\u0016\u0010K\u001a\u00020\u00088\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u001f\u0010GR\u0018\u0010M\u001a\u0004\u0018\u00010 8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008;\u0010LR\u0014\u0010P\u001a\u00020N8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\u0011\u0010OR\u0014\u0010Q\u001a\u00020N8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u00087\u0010OR\u0016\u0010R\u001a\u00020\u00088\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u00082\u0010GR\u0016\u0010T\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0013\u0010SR\u0016\u0010U\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e\u00a2\u0006\u0006\n\u0004\u0008\u0003\u0010SR\u0014\u0010X\u001a\u00020V8\u0002X\u0082\u0004\u00a2\u0006\u0006\n\u0004\u0008\n\u0010WR*\u0010_\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008Z\u0010G\u001a\u0004\u0008[\u0010\\\"\u0004\u0008]\u0010^R*\u0010c\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008`\u0010G\u001a\u0004\u0008a\u0010\\\"\u0004\u0008b\u0010^R*\u0010g\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008d\u0010G\u001a\u0004\u0008e\u0010\\\"\u0004\u0008f\u0010^R*\u0010n\u001a\u00020\u00042\u0006\u0010Y\u001a\u00020\u00048F@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008h\u0010i\u001a\u0004\u0008j\u0010k\"\u0004\u0008l\u0010mR*\u0010r\u001a\u00020\u00042\u0006\u0010Y\u001a\u00020\u00048\u0006@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008o\u0010i\u001a\u0004\u0008p\u0010k\"\u0004\u0008q\u0010mR*\u0010u\u001a\u00020\u00042\u0006\u0010Y\u001a\u00020\u00048\u0006@FX\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008>\u0010i\u001a\u0004\u0008s\u0010k\"\u0004\u0008t\u0010mR\"\u0010y\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008v\u0010i\u001a\u0004\u0008w\u0010k\"\u0004\u0008x\u0010mR\"\u0010}\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0012\n\u0004\u0008z\u0010i\u001a\u0004\u0008{\u0010k\"\u0004\u0008|\u0010mR$\u0010\u0081\u0001\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0013\n\u0004\u0008~\u0010i\u001a\u0004\u0008\u007f\u0010k\"\u0005\u0008\u0080\u0001\u0010mR&\u0010\u0085\u0001\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0015\n\u0005\u0008\u0082\u0001\u0010i\u001a\u0005\u0008\u0083\u0001\u0010k\"\u0005\u0008\u0084\u0001\u0010mR.\u0010\u0089\u0001\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0015\n\u0005\u0008\u0086\u0001\u0010G\u001a\u0005\u0008\u0087\u0001\u0010\\\"\u0005\u0008\u0088\u0001\u0010^R.\u0010\u008d\u0001\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0015\n\u0005\u0008\u008a\u0001\u0010G\u001a\u0005\u0008\u008b\u0001\u0010\\\"\u0005\u0008\u008c\u0001\u0010^R-\u0010\u0090\u0001\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0014\n\u0004\u0008\"\u0010G\u001a\u0005\u0008\u008e\u0001\u0010\\\"\u0005\u0008\u008f\u0001\u0010^R-\u0010\u0093\u0001\u001a\u00020\u00082\u0006\u0010Y\u001a\u00020\u00088\u0006@FX\u0086\u000e\u00a2\u0006\u0014\n\u0004\u0008/\u0010G\u001a\u0005\u0008\u0091\u0001\u0010\\\"\u0005\u0008\u0092\u0001\u0010^\u00a8\u0006\u009a\u0001"
    }
    d2 = {
        "Lcom/loopeer/shadow/ShadowView;",
        "Landroid/view/ViewGroup;",
        "Lkotlin/s2;",
        "i",
        "",
        "radius",
        "dx",
        "dy",
        "",
        "color",
        "j",
        "left",
        "top",
        "right",
        "bottom",
        "",
        "forceLeftGravity",
        "e",
        "getShadowMarginMax",
        "h",
        "getPaddingTopWithForeground",
        "getPaddingBottomWithForeground",
        "widthMeasureSpec",
        "heightMeasureSpec",
        "onMeasure",
        "changed",
        "onLayout",
        "Landroid/graphics/Canvas;",
        "canvas",
        "onDraw",
        "draw",
        "c",
        "Landroid/graphics/drawable/Drawable;",
        "getForeground",
        "w",
        "oldw",
        "oldh",
        "onSizeChanged",
        "getForegroundGravity",
        "foregroundGravity",
        "setForegroundGravity",
        "who",
        "verifyDrawable",
        "jumpDrawablesToCurrentState",
        "drawableStateChanged",
        "drawable",
        "setForeground",
        "x",
        "y",
        "drawableHotspotChanged",
        "g",
        "tl",
        "tr",
        "br",
        "bl",
        "f",
        "Landroid/util/AttributeSet;",
        "attrs",
        "Lcom/loopeer/shadow/ShadowView$a;",
        "d",
        "shouldDelayChildPressedState",
        "Landroid/view/ViewGroup$LayoutParams;",
        "p",
        "checkLayoutParams",
        "lp",
        "generateLayoutParams",
        "",
        "getAccessibilityClassName",
        "getPaddingLeftWithForeground",
        "getPaddingRightWithForeground",
        "a",
        "I",
        "DEFAULT_CHILD_GRAVITY",
        "b",
        "SIZE_UNSET",
        "SIZE_DEFAULT",
        "Landroid/graphics/drawable/Drawable;",
        "foregroundDraw",
        "Landroid/graphics/Rect;",
        "Landroid/graphics/Rect;",
        "selfBounds",
        "overlayBounds",
        "foregroundDrawGravity",
        "Z",
        "foregroundDrawInPadding",
        "foregroundDrawBoundsChanged",
        "Landroid/graphics/Paint;",
        "Landroid/graphics/Paint;",
        "bgPaint",
        "value",
        "k",
        "getShadowColor",
        "()I",
        "setShadowColor",
        "(I)V",
        "shadowColor",
        "l",
        "getForegroundColor",
        "setForegroundColor",
        "foregroundColor",
        "m",
        "getBackgroundClr",
        "setBackgroundClr",
        "backgroundClr",
        "n",
        "F",
        "getShadowRadius",
        "()F",
        "setShadowRadius",
        "(F)V",
        "shadowRadius",
        "o",
        "getShadowDx",
        "setShadowDx",
        "shadowDx",
        "getShadowDy",
        "setShadowDy",
        "shadowDy",
        "q",
        "getCornerRadiusTL",
        "setCornerRadiusTL",
        "cornerRadiusTL",
        "r",
        "getCornerRadiusTR",
        "setCornerRadiusTR",
        "cornerRadiusTR",
        "s",
        "getCornerRadiusBL",
        "setCornerRadiusBL",
        "cornerRadiusBL",
        "t",
        "getCornerRadiusBR",
        "setCornerRadiusBR",
        "cornerRadiusBR",
        "u",
        "getShadowMarginTop",
        "setShadowMarginTop",
        "shadowMarginTop",
        "v",
        "getShadowMarginLeft",
        "setShadowMarginLeft",
        "shadowMarginLeft",
        "getShadowMarginRight",
        "setShadowMarginRight",
        "shadowMarginRight",
        "getShadowMarginBottom",
        "setShadowMarginBottom",
        "shadowMarginBottom",
        "Landroid/content/Context;",
        "context",
        "attributeSet",
        "defStyleInt",
        "<init>",
        "(Landroid/content/Context;Landroid/util/AttributeSet;I)V",
        "shadow_release"
    }
    k = 0x1
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation


# instance fields
.field private final a:I

.field private b:I

.field private c:I

.field private d:Landroid/graphics/drawable/Drawable;

.field private final e:Landroid/graphics/Rect;

.field private final f:Landroid/graphics/Rect;

.field private g:I

.field private h:Z

.field private i:Z

.field private final j:Landroid/graphics/Paint;

.field private k:I

.field private l:I

.field private m:I

.field private n:F

.field private o:F

.field private p:F

.field private q:F

.field private r:F

.field private s:F

.field private t:F

.field private u:I

.field private v:I

.field private w:I

.field private x:I

.field private y:Ljava/util/HashMap;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v4, 0x6

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/loopeer/shadow/ShadowView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILkotlin/jvm/internal/w;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/loopeer/shadow/ShadowView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILkotlin/jvm/internal/w;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    const v0, 0x800033

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput v0, p0, Lcom/loopeer/shadow/ShadowView;->a:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v0, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput v0, p0, Lcom/loopeer/shadow/ShadowView;->b:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v1, Landroid/graphics/Rect;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-object v1, p0, Lcom/loopeer/shadow/ShadowView;->e:Landroid/graphics/Rect;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance v1, Landroid/graphics/Rect;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object v1, p0, Lcom/loopeer/shadow/ShadowView;->f:Landroid/graphics/Rect;

    const/4 v7, 0x5

    const/16 v1, 0x77

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput v1, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-boolean v1, p0, Lcom/loopeer/shadow/ShadowView;->h:Z

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v2, Landroid/graphics/Paint;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v2, p0, Lcom/loopeer/shadow/ShadowView;->j:Landroid/graphics/Paint;

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    sget-object v4, Lcom/loopeer/shadow/R$styleable;->ShadowView:[I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {v3, p2, v4, p3, v5}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x5

    sget p3, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowColor:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez p1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {}, Lkotlin/jvm/internal/l0;->L()V

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget v3, Lcom/loopeer/shadow/R$color;->shadow_view_default_shadow_color:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p1, v3}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p2, p3, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0, p3}, Lcom/loopeer/shadow/ShadowView;->setShadowColor(I)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget p3, Lcom/loopeer/shadow/R$styleable;->ShadowView_foregroundColor:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget v3, Lcom/loopeer/shadow/R$color;->shadow_view_foreground_color_dark:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p1, v3}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setForegroundColor(I)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_backgroundColor:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setBackgroundClr(I)V

    const/4 v7, 0x6

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowDx:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 p3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowDx(F)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowDy:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/high16 p3, 0x3f800000    # 1.0f

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowDy(F)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowRadius:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    int-to-float p1, p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowRadius(F)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_android_foreground:I

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz p1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowMargin:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->b:I

    const/4 v7, 0x4

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ltz p1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginTop(I)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginLeft(I)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginRight(I)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginBottom(I)V

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowMarginTop:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginTop(I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowMarginLeft:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginLeft(I)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowMarginRight:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginRight(I)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_shadowMarginBottom:I

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginBottom(I)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_cornerRadius:I

    const/4 v7, 0x0

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->b:I

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    int-to-float p1, p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    int-to-float p3, v5

    const/4 v7, 0x7

    const/4 v6, 0x7

    cmpl-float p3, p1, p3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ltz p3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_cornerRadiusTL:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    int-to-float p1, p1

    const/4 v6, 0x3

    move v7, v6

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_cornerRadiusTR:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    int-to-float p1, p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_cornerRadiusBL:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    int-to-float p1, p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget p1, Lcom/loopeer/shadow/R$styleable;->ShadowView_cornerRadiusBR:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget p3, p0, Lcom/loopeer/shadow/ShadowView;->c:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    int-to-float p1, p1

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v6, 0x1

    move v7, v6

    iget p1, p0, Lcom/loopeer/shadow/ShadowView;->m:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object p1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 p1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0, v1, p1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v5}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;IILkotlin/jvm/internal/w;)V
    .locals 2
    .annotation build Lh8/i;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    and-int/lit8 p5, p4, 0x2

    const/4 v1, 0x4

    if-eqz p5, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p2, 0x0

    :cond_0
    const/4 v0, 0x5

    const/4 v1, 0x0

    and-int/lit8 p4, p4, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-eqz p4, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p3, 0x0

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/loopeer/shadow/ShadowView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method private final e(IIIIZ)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Lcom/loopeer/shadow/ShadowView;->getPaddingLeftWithForeground()I

    move-result v2

    sub-int v3, p3, p1

    invoke-virtual/range {p0 .. p0}, Lcom/loopeer/shadow/ShadowView;->getPaddingRightWithForeground()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-direct/range {p0 .. p0}, Lcom/loopeer/shadow/ShadowView;->getPaddingTopWithForeground()I

    move-result v4

    sub-int v5, p4, p2

    invoke-direct/range {p0 .. p0}, Lcom/loopeer/shadow/ShadowView;->getPaddingBottomWithForeground()I

    move-result v6

    sub-int/2addr v5, v6

    const/4 v6, 0x1

    sub-int/2addr v1, v6

    if-ltz v1, :cond_a

    const/4 v7, 0x0

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    :goto_0
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    const-string v10, "dhsis"

    const-string v10, "dhsil"

    const-string v10, "dciml"

    const-string v10, "child"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9}, Landroid/view/View;->getVisibility()I

    move-result v10

    const/16 v11, 0x8

    if-eq v10, v11, :cond_9

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    if-eqz v10, :cond_8

    check-cast v10, Lcom/loopeer/shadow/ShadowView$a;

    invoke-virtual {v9}, Landroid/view/View;->getMeasuredWidth()I

    move-result v11

    invoke-virtual {v9}, Landroid/view/View;->getMeasuredHeight()I

    move-result v12

    invoke-virtual {v10}, Lcom/loopeer/shadow/ShadowView$a;->b()I

    move-result v13

    const/4 v14, -0x1

    if-ne v13, v14, :cond_0

    iget v13, v0, Lcom/loopeer/shadow/ShadowView;->a:I

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getLayoutDirection()I

    move-result v14

    invoke-static {v13, v14}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result v14

    and-int/lit8 v13, v13, 0x70

    and-int/lit8 v14, v14, 0x7

    if-eq v14, v6, :cond_4

    const/4 v15, 0x3

    if-eq v14, v15, :cond_3

    const/4 v15, 0x5

    if-eq v14, v15, :cond_1

    iget v14, v10, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v14, v2

    iget v15, v0, Lcom/loopeer/shadow/ShadowView;->v:I

    :goto_1
    add-int/2addr v14, v15

    goto :goto_3

    :cond_1
    if-nez p5, :cond_2

    sub-int v14, v3, v11

    iget v15, v10, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    sub-int/2addr v14, v15

    iget v15, v0, Lcom/loopeer/shadow/ShadowView;->w:I

    :goto_2
    sub-int/2addr v14, v15

    goto :goto_3

    :cond_2
    move v14, v7

    move v14, v7

    move v14, v7

    move v14, v7

    goto :goto_3

    :cond_3
    iget v14, v10, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v14, v2

    iget v15, v0, Lcom/loopeer/shadow/ShadowView;->v:I

    goto :goto_1

    :cond_4
    sub-int v14, v3, v2

    sub-int/2addr v14, v11

    div-int/lit8 v14, v14, 0x2

    add-int/2addr v14, v2

    iget v15, v10, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v14, v15

    iget v15, v10, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    sub-int/2addr v14, v15

    iget v15, v0, Lcom/loopeer/shadow/ShadowView;->v:I

    add-int/2addr v14, v15

    iget v15, v0, Lcom/loopeer/shadow/ShadowView;->w:I

    goto :goto_2

    :goto_3
    const/16 v15, 0x10

    if-eq v13, v15, :cond_7

    const/16 v15, 0x30

    if-eq v13, v15, :cond_6

    const/16 v15, 0x50

    if-eq v13, v15, :cond_5

    iget v10, v10, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v10, v4

    iget v13, v0, Lcom/loopeer/shadow/ShadowView;->u:I

    goto :goto_4

    :cond_5
    sub-int v13, v5, v12

    iget v10, v10, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    sub-int/2addr v13, v10

    iget v10, v0, Lcom/loopeer/shadow/ShadowView;->x:I

    goto :goto_5

    :cond_6
    iget v10, v10, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v10, v4

    iget v13, v0, Lcom/loopeer/shadow/ShadowView;->u:I

    :goto_4
    add-int/2addr v10, v13

    goto :goto_6

    :cond_7
    sub-int v13, v5, v4

    sub-int/2addr v13, v12

    div-int/lit8 v13, v13, 0x2

    add-int/2addr v13, v4

    iget v15, v10, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v13, v15

    iget v10, v10, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    sub-int/2addr v13, v10

    iget v10, v0, Lcom/loopeer/shadow/ShadowView;->u:I

    add-int/2addr v13, v10

    iget v10, v0, Lcom/loopeer/shadow/ShadowView;->x:I

    :goto_5
    sub-int v10, v13, v10

    :goto_6
    add-int/2addr v11, v14

    add-int/2addr v12, v10

    invoke-virtual {v9, v14, v10, v11, v12}, Landroid/view/View;->layout(IIII)V

    goto :goto_7

    :cond_8
    new-instance v1, Lkotlin/s1;

    const-string v2, "e lloel oea nutpwotnty.. -nedsSwhcusao.p  omyaoanuwroctctal.rbLamPoiedn onhaolm"

    const-string/jumbo v2, "ncmm-racohwaycotb  saPesdVoal.i amloyennLdnpu.tn.a rlletSoulothoweonwp e ou .at"

    const-string v2, "Larm btnaonwnac au.e topoeo Sulshor latlnPmothanosweledol . .ueVysp.tcnic-wobad"

    const-string/jumbo v2, "null cannot be cast to non-null type com.loopeer.shadow.ShadowView.LayoutParams"

    invoke-direct {v1, v2}, Lkotlin/s1;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_9
    :goto_7
    if-eq v8, v1, :cond_a

    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_0

    :cond_a
    return-void
.end method

.method private final getPaddingBottomWithForeground()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ @@r@u@1~ ~b  @li@/~@@~~@~  y~M~tf@4ol@ @~~oms~~@ S@no./i b ~~u-@ f@  @ @vao ~~ ~i ctoob@@~K~d~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method private final getPaddingTopWithForeground()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method private final getShadowMarginMax()F
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v3, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0}, Lkotlin/collections/l;->h2([I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    int-to-float v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v0
.end method

.method private final h()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x5

    check-cast v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->l:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v3, 0x0

    return-void
.end method

.method private final i()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowRadius()F

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v3, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/loopeer/shadow/ShadowView;->j(FFFI)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void
.end method

.method private final j(FFFI)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->j:Landroid/graphics/Paint;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->y:Ljava/util/HashMap;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    :cond_0
    const/4 v2, 0x6

    return-void
.end method

.method public b(I)Landroid/view/View;
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->y:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x3

    and-int/2addr v3, v2

    iput-object v0, p0, Lcom/loopeer/shadow/ShadowView;->y:Ljava/util/HashMap;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->y:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/loopeer/shadow/ShadowView;->y:Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public final c(Landroid/graphics/Canvas;)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-boolean v1, p0, Lcom/loopeer/shadow/ShadowView;->i:Z

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x1

    and-int/2addr v8, v7

    iput-boolean v1, p0, Lcom/loopeer/shadow/ShadowView;->i:Z

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getRight()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    sub-int/2addr v2, v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    sub-int/2addr v3, v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-boolean v4, p0, Lcom/loopeer/shadow/ShadowView;->h:Z

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz v4, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v4, p0, Lcom/loopeer/shadow/ShadowView;->e:Landroid/graphics/Rect;

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {v4, v1, v1, v2, v3}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/loopeer/shadow/ShadowView;->e:Landroid/graphics/Rect;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v6

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    sub-int/2addr v2, v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    sub-int/2addr v3, v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v4, v5, v2, v3}, Landroid/graphics/Rect;->set(IIII)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object v4, p0, Lcom/loopeer/shadow/ShadowView;->e:Landroid/graphics/Rect;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v5, p0, Lcom/loopeer/shadow/ShadowView;->f:Landroid/graphics/Rect;

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-static {v1, v2, v3, v4, v5}, Landroid/view/Gravity;->apply(IIILandroid/graphics/Rect;Landroid/graphics/Rect;)V

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/loopeer/shadow/ShadowView;->f:Landroid/graphics/Rect;

    const/4 v8, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-void
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 3
    .param p1    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "p"

    const-string/jumbo v0, "p"

    const/4 v2, 0x5

    const-string/jumbo v0, "p"

    const-string/jumbo v0, "p"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    instance-of p1, p1, Lcom/loopeer/shadow/ShadowView$a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p1
.end method

.method public d(Landroid/util/AttributeSet;)Lcom/loopeer/shadow/ShadowView$a;
    .locals 5
    .param p1    # Landroid/util/AttributeSet;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, "aspto"

    const-string/jumbo v0, "tasto"

    const/4 v4, 0x7

    const-string/jumbo v0, "satqt"

    const-string v0, "attrs"

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lcom/loopeer/shadow/ShadowView$a;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "otsxnet"

    const-string/jumbo v2, "xonttbe"

    const/4 v4, 0x5

    const-string v2, "cotmnxe"

    const-string v2, "context"

    const/4 v3, 0x1

    const/4 v3, 0x1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-direct {v0, v1, p1}, Lcom/loopeer/shadow/ShadowView$a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 13
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V

    if-eqz p1, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    sget-object v2, Lcom/loopeer/shadow/b;->a:Lcom/loopeer/shadow/b;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget v3, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    int-to-float v3, v3

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget v4, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    int-to-float v4, v4

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget v5, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    sub-int/2addr v0, v5

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    int-to-float v5, v0

    const/4 v12, 0x0

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    sub-int/2addr v1, v0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-float v6, v1

    const/4 v12, 0x1

    const/4 v11, 0x0

    iget v7, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget v8, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget v9, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget v10, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual/range {v2 .. v10}, Lcom/loopeer/shadow/b;->a(FFFFFFFF)Landroid/graphics/Path;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x4

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v12, 0x4

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->c(Landroid/graphics/Canvas;)V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    return-void
.end method

.method public drawableHotspotChanged(FF)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->drawableHotspotChanged(FF)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/Drawable;->setHotspot(FF)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method protected drawableStateChanged()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/view/ViewGroup;->drawableStateChanged()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public final f(FFFF)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p3, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v1, 0x1

    iput p4, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public final g(IIII)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginLeft(I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p2}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginTop(I)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p3}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginRight(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-virtual {p0, p4}, Lcom/loopeer/shadow/ShadowView;->setShadowMarginBottom(I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x0

    return-void
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/loopeer/shadow/ShadowView;->d(Landroid/util/AttributeSet;)Lcom/loopeer/shadow/ShadowView$a;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method protected generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 3
    .param p1    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "lp"

    const-string/jumbo v0, "lp"

    const/4 v2, 0x6

    const-string/jumbo v0, "pl"

    const-string/jumbo v0, "lp"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/loopeer/shadow/ShadowView$a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-direct {v0, p1}, Lcom/loopeer/shadow/ShadowView$a;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-class v0, Landroid/widget/FrameLayout;

    const/4 v3, 0x2

    const-class v0, Landroid/widget/FrameLayout;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const-string/jumbo v1, "mcyeoLvsFsljaaauatur.:aen.om"

    const-string/jumbo v1, "ua.mvcusaLa.emryaljaa:Fnetso"

    const/4 v3, 0x7

    const-string/jumbo v1, "l.cvabsaauLFma:jare.easym:no"

    const-string v1, "FrameLayout::class.java.name"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    move v3, v2

    return-object v0
.end method

.method public final getBackgroundClr()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->m:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public final getCornerRadiusBL()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public final getCornerRadiusBR()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public final getCornerRadiusTL()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public final getCornerRadiusTR()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public getForeground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-object v0
.end method

.method public final getForegroundColor()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->l:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public getForegroundGravity()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public final getPaddingLeftWithForeground()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public final getPaddingRightWithForeground()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public final getShadowColor()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public final getShadowDx()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public final getShadowDy()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public final getShadowMarginBottom()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public final getShadowMarginLeft()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public final getShadowMarginRight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public final getShadowMarginTop()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public final getShadowRadius()F
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->n:F

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    cmpl-float v0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-lez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    cmpg-float v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->n:F

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public jumpDrawablesToCurrentState()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/view/ViewGroup;->jumpDrawablesToCurrentState()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 13
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz p1, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    sget-object v2, Lcom/loopeer/shadow/b;->a:Lcom/loopeer/shadow/b;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget v3, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    int-to-float v3, v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget v4, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    const/4 v12, 0x5

    int-to-float v4, v4

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget v5, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    sub-int/2addr v0, v5

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    int-to-float v5, v0

    const/4 v12, 0x2

    const/4 v11, 0x3

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    sub-int/2addr v1, v0

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    int-to-float v6, v1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget v7, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget v8, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget v9, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget v10, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v12, 0x4

    invoke-virtual/range {v2 .. v10}, Lcom/loopeer/shadow/b;->a(FFFFFFFF)Landroid/graphics/Path;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget-object v1, p0, Lcom/loopeer/shadow/ShadowView;->j:Landroid/graphics/Paint;

    const/4 v12, 0x3

    const/4 v11, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x3

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 8

    const/4 v6, 0x5

    move v7, v6

    const/4 v5, 0x5

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v1, p2

    move v1, p2

    const/4 v7, 0x0

    move v1, p2

    move v1, p2

    const/4 v7, 0x0

    const/4 v6, 0x5

    move v2, p3

    move v2, p3

    const/4 v7, 0x0

    move v2, p3

    move v2, p3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    move v3, p4

    move v3, p4

    const/4 v7, 0x2

    move v3, p4

    move v3, p4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    move v4, p5

    move v4, p5

    const/4 v7, 0x7

    move v4, p5

    move v4, p5

    const/4 v7, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/loopeer/shadow/ShadowView;->e(IIIIZ)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-boolean p1, p0, Lcom/loopeer/shadow/ShadowView;->i:Z

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void
.end method

.method protected onMeasure(II)V
    .locals 13

    const/4 v0, 0x0

    invoke-static {v0, p1}, Landroid/view/View;->getDefaultSize(II)I

    move-result v1

    invoke-static {v0, p2}, Landroid/view/View;->getDefaultSize(II)I

    move-result v2

    invoke-virtual {p0, v1, v2}, Landroid/view/View;->setMeasuredDimension(II)V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v2, 0x1

    const/4 v3, -0x1

    if-ne v1, v3, :cond_0

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    goto :goto_0

    :cond_0
    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    iget v4, v4, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-ne v4, v3, :cond_1

    goto :goto_1

    :cond_1
    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_1
    const/high16 v3, 0x40000000    # 2.0f

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    iget v5, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    sub-int/2addr v4, v5

    iget v5, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    sub-int/2addr v4, v5

    invoke-static {v4, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    goto :goto_2

    :cond_2
    move v4, p1

    move v4, p1

    move v4, p1

    move v4, p1

    :goto_2
    if-eqz v2, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    iget v6, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    sub-int/2addr v5, v6

    iget v6, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    sub-int/2addr v5, v6

    invoke-static {v5, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    goto :goto_3

    :cond_3
    move v3, p2

    move v3, p2

    :goto_3
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    const-string/jumbo v5, "puclh"

    const-string/jumbo v5, "ilphc"

    const-string/jumbo v5, "ilpcd"

    const-string v5, "child"

    invoke-static {v11, v5}, Lkotlin/jvm/internal/l0;->h(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v11}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/16 v6, 0x8

    if-eq v5, v6, :cond_7

    const/4 v8, 0x0

    const/4 v10, 0x0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move v7, v4

    move v7, v4

    move v7, v4

    move v7, v4

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    invoke-virtual/range {v5 .. v10}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    invoke-virtual {v11}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    if-eqz v5, :cond_6

    check-cast v5, Lcom/loopeer/shadow/ShadowView$a;

    if-eqz v1, :cond_4

    invoke-virtual {v11}, Landroid/view/View;->getMeasuredWidth()I

    move-result v6

    iget v7, v5, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v6, v7

    iget v7, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v6, v7

    invoke-static {v0, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    goto :goto_4

    :cond_4
    invoke-virtual {v11}, Landroid/view/View;->getMeasuredWidth()I

    move-result v6

    iget v7, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    add-int/2addr v6, v7

    iget v7, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    add-int/2addr v6, v7

    iget v7, v5, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    add-int/2addr v6, v7

    iget v7, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    add-int/2addr v6, v7

    invoke-static {v0, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    :goto_4
    if-eqz v2, :cond_5

    invoke-virtual {v11}, Landroid/view/View;->getMeasuredHeight()I

    move-result v7

    iget v8, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v7, v8

    iget v5, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v7, v5

    invoke-static {v0, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    goto :goto_5

    :cond_5
    invoke-virtual {v11}, Landroid/view/View;->getMeasuredHeight()I

    move-result v7

    iget v8, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    add-int/2addr v7, v8

    iget v8, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    add-int/2addr v7, v8

    iget v8, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    add-int/2addr v7, v8

    iget v5, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    add-int/2addr v7, v5

    invoke-static {v0, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    :goto_5
    invoke-virtual {v11}, Landroid/view/View;->getMeasuredState()I

    move-result v7

    invoke-static {v0, v7}, Landroid/view/View;->combineMeasuredStates(II)I

    move-result v0

    move v12, v6

    move v12, v6

    move v12, v6

    move v12, v6

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    move v0, v12

    move v0, v12

    move v0, v12

    goto :goto_6

    :cond_6
    new-instance p1, Lkotlin/s1;

    const-string p2, " sroco eqerwahmdeolecaPiwVyoeaotl .ou tS.npnllh- tnalnuuwsttyqacopbnma .no. asd"

    const-string p2, "e.loloawqPoy ayoaia ttdoaVhnscmeho-w.l wa.pS ooct meesbn rad.n clptentsuuonnlru"

    const-string/jumbo p2, "o.sV SouenyslnohnaPao l e-ualctbaocawnrtacohwtieLmseplmyrulno. dt w t.on p.ados"

    const-string/jumbo p2, "null cannot be cast to non-null type com.loopeer.shadow.ShadowView.LayoutParams"

    invoke-direct {p1, p2}, Lkotlin/s1;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    move v5, v0

    move v5, v0

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :goto_6
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v8

    add-int/2addr v7, v8

    add-int/2addr v0, v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v8

    add-int/2addr v7, v8

    add-int/2addr v5, v7

    invoke-virtual {p0}, Landroid/view/View;->getSuggestedMinimumHeight()I

    move-result v7

    invoke-static {v5, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual {p0}, Landroid/view/View;->getSuggestedMinimumWidth()I

    move-result v7

    invoke-static {v0, v7}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Lcom/loopeer/shadow/ShadowView;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    if-eqz v7, :cond_8

    invoke-virtual {v7}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v8

    invoke-static {v5, v8}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual {v7}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v7

    invoke-static {v0, v7}, Ljava/lang/Math;->max(II)I

    move-result v0

    :cond_8
    if-eqz v1, :cond_9

    goto :goto_7

    :cond_9
    move p1, v4

    move p1, v4

    move p1, v4

    :goto_7
    invoke-static {v0, p1, v6}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p1

    if-eqz v2, :cond_a

    goto :goto_8

    :cond_a
    move p2, v3

    move p2, v3

    :goto_8
    shl-int/lit8 v0, v6, 0x10

    invoke-static {v5, p2, v0}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    iput-boolean p1, p0, Lcom/loopeer/shadow/ShadowView;->i:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public final setBackgroundClr(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->m:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public final setCornerRadiusBL(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->s:F

    const/4 v1, 0x6

    return-void
.end method

.method public final setCornerRadiusBR(F)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->t:F

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public final setCornerRadiusTL(F)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->q:F

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public final setCornerRadiusTR(F)V
    .locals 2

    const/4 v1, 0x1

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->r:F

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public setForeground(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    move v3, v2

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->h()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    shl-int/2addr v3, v0

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_2
    const/4 v3, 0x5

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/16 v1, 0x77

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v0, v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    :cond_3
    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public final setForegroundColor(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->l:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->h()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setForegroundGravity(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eq v0, p1, :cond_3

    const/4 v2, 0x3

    const v0, 0x800007

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    and-int/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const v0, 0x800003

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    or-int/2addr p1, v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    and-int/lit8 v0, p1, 0x70

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    or-int/lit8 p1, p1, 0x30

    :cond_1
    const/4 v2, 0x5

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->g:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v0, 0x77

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-ne p1, v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_2

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x5

    if-eqz v0, :cond_2

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    :cond_2
    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public final setShadowColor(I)V
    .locals 5

    const/4 v4, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowRadius()F

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, v0, v1, v2, p1}, Lcom/loopeer/shadow/ShadowView;->j(FFFI)V

    const/4 v4, 0x0

    return-void
.end method

.method public final setShadowDx(F)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowRadius()F

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v3, 0x1

    move v4, v3

    invoke-direct {p0, v0, p1, v1, v2}, Lcom/loopeer/shadow/ShadowView;->j(FFFI)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method public final setShadowDy(F)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowRadius()F

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-direct {p0, v0, v1, p1, v2}, Lcom/loopeer/shadow/ShadowView;->j(FFFI)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method public final setShadowMarginBottom(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->x:I

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->i()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public final setShadowMarginLeft(I)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->v:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->i()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public final setShadowMarginRight(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->w:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->i()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public final setShadowMarginTop(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->u:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->i()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public final setShadowRadius(F)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    cmpl-float v0, p1, v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-lez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    cmpg-float v0, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/loopeer/shadow/ShadowView;->getShadowMarginMax()F

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    move v0, p1

    move v0, p1

    const/4 v4, 0x5

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput p1, p0, Lcom/loopeer/shadow/ShadowView;->n:F

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget p1, p0, Lcom/loopeer/shadow/ShadowView;->o:F

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/loopeer/shadow/ShadowView;->p:F

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v2, p0, Lcom/loopeer/shadow/ShadowView;->k:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0, v0, p1, v1, v2}, Lcom/loopeer/shadow/ShadowView;->j(FFFI)V

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public shouldDelayChildPressedState()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method protected verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "ohw"

    const/4 v2, 0x6

    const-string/jumbo v0, "owh"

    const-string/jumbo v0, "who"

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/loopeer/shadow/ShadowView;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method
