.class public final Lcom/loopeer/shadow/ShadowView$a;
.super Landroid/view/ViewGroup$MarginLayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/loopeer/shadow/ShadowView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/loopeer/shadow/ShadowView$a$a;
    }
.end annotation


# static fields
# The value of this static final field might be set in the static constructor
.field private static final b:I = -0x1

.field public static final c:Lcom/loopeer/shadow/ShadowView$a$a;


# instance fields
.field private a:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/loopeer/shadow/ShadowView$a$a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/loopeer/shadow/ShadowView$a$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object v0, Lcom/loopeer/shadow/ShadowView$a;->c:Lcom/loopeer/shadow/ShadowView$a$a;

    const/4 v0, -0x3

    const/4 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput v0, Lcom/loopeer/shadow/ShadowView$a;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "c"

    const-string v0, "c"

    const/4 v3, 0x1

    const-string v0, "c"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v0, Lcom/loopeer/shadow/ShadowView$a;->c:Lcom/loopeer/shadow/ShadowView$a$a;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/loopeer/shadow/ShadowView$a$a;->a()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lcom/loopeer/shadow/ShadowView$a;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v1, Lcom/loopeer/shadow/R$styleable;->ShadowView_Layout:[I

    const/4 v3, 0x1

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget p2, Lcom/loopeer/shadow/R$styleable;->ShadowView_Layout_layout_gravity:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/loopeer/shadow/ShadowView$a$a;->a()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    iput p2, p0, Lcom/loopeer/shadow/ShadowView$a;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 3
    .param p1    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "eosssr"

    const-string/jumbo v0, "rsseoc"

    const/4 v2, 0x5

    const-string/jumbo v0, "osrmcu"

    const-string/jumbo v0, "source"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->q(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x2

    and-int/2addr v2, v1

    sget-object p1, Lcom/loopeer/shadow/ShadowView$a;->c:Lcom/loopeer/shadow/ShadowView$a$a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/loopeer/shadow/ShadowView$a$a;->a()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/loopeer/shadow/ShadowView$a;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static final synthetic a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ 1/o~@f~ ~ @@ .a~~@l@vo~b@~ /@~n @K~os@@ i~~itb@~ M~~S~ c@f t4oro@~y ~~m~~ ~ l@b  @@oud-~@@  io"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget v0, Lcom/loopeer/shadow/ShadowView$a;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    return v0
.end method


# virtual methods
.method public final b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/loopeer/shadow/ShadowView$a;->a:I

    const/4 v2, 0x5

    return v0
.end method

.method public final c(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/loopeer/shadow/ShadowView$a;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method
