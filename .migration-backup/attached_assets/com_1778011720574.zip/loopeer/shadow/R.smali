.class public final Lcom/loopeer/shadow/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/loopeer/shadow/R$anim;,
        Lcom/loopeer/shadow/R$attr;,
        Lcom/loopeer/shadow/R$bool;,
        Lcom/loopeer/shadow/R$color;,
        Lcom/loopeer/shadow/R$dimen;,
        Lcom/loopeer/shadow/R$drawable;,
        Lcom/loopeer/shadow/R$id;,
        Lcom/loopeer/shadow/R$integer;,
        Lcom/loopeer/shadow/R$layout;,
        Lcom/loopeer/shadow/R$string;,
        Lcom/loopeer/shadow/R$style;,
        Lcom/loopeer/shadow/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    or-int/2addr v1, v0

    return-void
.end method
