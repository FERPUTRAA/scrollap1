.class public final Lcom/loopeer/shadow/R$integer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/loopeer/shadow/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "integer"
.end annotation


# static fields
.field public static final abc_config_activityDefaultDur:I = 0x7f0a0000

.field public static final abc_config_activityShortDur:I = 0x7f0a0001

.field public static final cancel_button_image_alpha:I = 0x7f0a0005

.field public static final config_tooltipAnimTime:I = 0x7f0a0006

.field public static final status_bar_notification_info_maxnum:I = 0x7f0a0036


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
