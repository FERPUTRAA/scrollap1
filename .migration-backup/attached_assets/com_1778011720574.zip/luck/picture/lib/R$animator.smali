.class public final Lcom/luck/picture/lib/R$animator;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "animator"
.end annotation


# static fields
.field public static final fragment_close_enter:I = 0x7f020003

.field public static final fragment_close_exit:I = 0x7f020004

.field public static final fragment_fade_enter:I = 0x7f020005

.field public static final fragment_fade_exit:I = 0x7f020006

.field public static final fragment_open_enter:I = 0x7f020007

.field public static final fragment_open_exit:I = 0x7f020008


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method
