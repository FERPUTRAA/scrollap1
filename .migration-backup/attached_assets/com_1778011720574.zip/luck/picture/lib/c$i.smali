.class Lcom/luck/picture/lib/c$i;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->M1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/c$i;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s @~ c~ti1~@ @fof~@uo@ ~@i~v   oy@o@@~@  @4~m/~@~b~Mln~~ b@~ l@~@@S~oKas@/~ t r @~.o @i~ bd ~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c$i;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/c;->B1(Lcom/luck/picture/lib/c;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$i;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/c;->C1(Lcom/luck/picture/lib/c;)V

    :cond_1
    :goto_0
    const/4 v2, 0x0

    return-void
.end method

.method public b(II)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c$i;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/c;->A1(Lcom/luck/picture/lib/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
