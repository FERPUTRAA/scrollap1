.class public final Lcom/luck/picture/lib/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final NO_DEBUG:I = 0x7f090011

.field public static final SHOW_ALL:I = 0x7f090015

.field public static final SHOW_PATH:I = 0x7f090016

.field public static final SHOW_PROGRESS:I = 0x7f090017

.field public static final accelerate:I = 0x7f09001f

.field public static final accessibility_action_clickable_span:I = 0x7f090020

.field public static final accessibility_custom_action_0:I = 0x7f090021

.field public static final accessibility_custom_action_1:I = 0x7f090022

.field public static final accessibility_custom_action_10:I = 0x7f090023

.field public static final accessibility_custom_action_11:I = 0x7f090024

.field public static final accessibility_custom_action_12:I = 0x7f090025

.field public static final accessibility_custom_action_13:I = 0x7f090026

.field public static final accessibility_custom_action_14:I = 0x7f090027

.field public static final accessibility_custom_action_15:I = 0x7f090028

.field public static final accessibility_custom_action_16:I = 0x7f090029

.field public static final accessibility_custom_action_17:I = 0x7f09002a

.field public static final accessibility_custom_action_18:I = 0x7f09002b

.field public static final accessibility_custom_action_19:I = 0x7f09002c

.field public static final accessibility_custom_action_2:I = 0x7f09002d

.field public static final accessibility_custom_action_20:I = 0x7f09002e

.field public static final accessibility_custom_action_21:I = 0x7f09002f

.field public static final accessibility_custom_action_22:I = 0x7f090030

.field public static final accessibility_custom_action_23:I = 0x7f090031

.field public static final accessibility_custom_action_24:I = 0x7f090032

.field public static final accessibility_custom_action_25:I = 0x7f090033

.field public static final accessibility_custom_action_26:I = 0x7f090034

.field public static final accessibility_custom_action_27:I = 0x7f090035

.field public static final accessibility_custom_action_28:I = 0x7f090036

.field public static final accessibility_custom_action_29:I = 0x7f090037

.field public static final accessibility_custom_action_3:I = 0x7f090038

.field public static final accessibility_custom_action_30:I = 0x7f090039

.field public static final accessibility_custom_action_31:I = 0x7f09003a

.field public static final accessibility_custom_action_4:I = 0x7f09003b

.field public static final accessibility_custom_action_5:I = 0x7f09003c

.field public static final accessibility_custom_action_6:I = 0x7f09003d

.field public static final accessibility_custom_action_7:I = 0x7f09003e

.field public static final accessibility_custom_action_8:I = 0x7f09003f

.field public static final accessibility_custom_action_9:I = 0x7f090040

.field public static final action0:I = 0x7f090043

.field public static final actionDown:I = 0x7f090045

.field public static final actionDownUp:I = 0x7f090046

.field public static final actionUp:I = 0x7f09004a

.field public static final action_bar:I = 0x7f09004b

.field public static final action_bar_activity_content:I = 0x7f09004c

.field public static final action_bar_container:I = 0x7f09004d

.field public static final action_bar_root:I = 0x7f09004e

.field public static final action_bar_spinner:I = 0x7f09004f

.field public static final action_bar_subtitle:I = 0x7f090050

.field public static final action_bar_title:I = 0x7f090051

.field public static final action_container:I = 0x7f090052

.field public static final action_context_bar:I = 0x7f090053

.field public static final action_divider:I = 0x7f090054

.field public static final action_image:I = 0x7f090055

.field public static final action_menu_divider:I = 0x7f090056

.field public static final action_menu_presenter:I = 0x7f090057

.field public static final action_mode_bar:I = 0x7f090058

.field public static final action_mode_bar_stub:I = 0x7f090059

.field public static final action_mode_close_button:I = 0x7f09005a

.field public static final action_text:I = 0x7f09005b

.field public static final actions:I = 0x7f09005d

.field public static final activity_chooser_view_content:I = 0x7f09005f

.field public static final add:I = 0x7f090061

.field public static final alertTitle:I = 0x7f090071

.field public static final aligned:I = 0x7f090072

.field public static final allStates:I = 0x7f090074

.field public static final always:I = 0x7f090075

.field public static final animateToEnd:I = 0x7f090079

.field public static final animateToStart:I = 0x7f09007a

.field public static final antiClockwise:I = 0x7f09007b

.field public static final anticipate:I = 0x7f09007c

.field public static final asConfigured:I = 0x7f090081

.field public static final async:I = 0x7f090082

.field public static final auto:I = 0x7f090083

.field public static final autoComplete:I = 0x7f090084

.field public static final autoCompleteToEnd:I = 0x7f090085

.field public static final autoCompleteToStart:I = 0x7f090086

.field public static final baseline:I = 0x7f0900ab

.field public static final bestChoice:I = 0x7f0900b0

.field public static final blocking:I = 0x7f0900b8

.field public static final bottom:I = 0x7f0900bb

.field public static final bottom_line:I = 0x7f0900c2

.field public static final bottom_nar_bar:I = 0x7f0900c6

.field public static final bounce:I = 0x7f0900cd

.field public static final btnCheck:I = 0x7f0900e8

.field public static final btnOk:I = 0x7f0900f6

.field public static final btn_cancel:I = 0x7f090102

.field public static final btn_commit:I = 0x7f090108

.field public static final buttonPanel:I = 0x7f090133

.field public static final callMeasure:I = 0x7f090137

.field public static final cancel_action:I = 0x7f09013a

.field public static final carryVelocity:I = 0x7f09013d

.field public static final cb_original:I = 0x7f090142

.field public static final center:I = 0x7f090143

.field public static final chain:I = 0x7f09014b

.field public static final chain2:I = 0x7f09014c

.field public static final checkbox:I = 0x7f090155

.field public static final checked:I = 0x7f090156

.field public static final chronometer:I = 0x7f090161

.field public static final clockwise:I = 0x7f090189

.field public static final closest:I = 0x7f09018f

.field public static final constraint:I = 0x7f0901a5

.field public static final content:I = 0x7f0901b5

.field public static final contentPanel:I = 0x7f0901b7

.field public static final continuousVelocity:I = 0x7f0901bc

.field public static final cos:I = 0x7f0901c4

.field public static final currentState:I = 0x7f0901dd

.field public static final custom:I = 0x7f0901de

.field public static final customPanel:I = 0x7f0901df

.field public static final decelerate:I = 0x7f0901f7

.field public static final decelerateAndComplete:I = 0x7f0901f8

.field public static final decor_content_parent:I = 0x7f0901f9

.field public static final default_activity_button:I = 0x7f0901fb

.field public static final deltaRelative:I = 0x7f0901ff

.field public static final dialog_button:I = 0x7f09020c

.field public static final dragAnticlockwise:I = 0x7f090228

.field public static final dragClockwise:I = 0x7f090229

.field public static final dragDown:I = 0x7f09022a

.field public static final dragEnd:I = 0x7f09022b

.field public static final dragLeft:I = 0x7f09022c

.field public static final dragRight:I = 0x7f09022d

.field public static final dragStart:I = 0x7f09022e

.field public static final dragUp:I = 0x7f09022f

.field public static final easeIn:I = 0x7f090235

.field public static final easeInOut:I = 0x7f090236

.field public static final easeOut:I = 0x7f090237

.field public static final east:I = 0x7f090238

.field public static final edit_query:I = 0x7f090247

.field public static final end:I = 0x7f09025f

.field public static final end_padder:I = 0x7f090261

.field public static final expand_activities_button:I = 0x7f090280

.field public static final expanded_menu:I = 0x7f090281

.field public static final fill:I = 0x7f090286

.field public static final first_image:I = 0x7f09028b

.field public static final flip:I = 0x7f0902a4

.field public static final folder_list:I = 0x7f0902a6

.field public static final forever:I = 0x7f0902a7

.field public static final fragment_container:I = 0x7f0902a9

.field public static final fragment_container_view_tag:I = 0x7f0902aa

.field public static final frost:I = 0x7f0902ad

.field public static final gone:I = 0x7f0902db

.field public static final group_divider:I = 0x7f0902eb

.field public static final home:I = 0x7f090307

.field public static final honorRequest:I = 0x7f09030a

.field public static final horizontal_only:I = 0x7f09030d

.field public static final icon:I = 0x7f090318

.field public static final icon_group:I = 0x7f09031a

.field public static final ignore:I = 0x7f09031d

.field public static final ignoreRequest:I = 0x7f09031e

.field public static final image:I = 0x7f09031f

.field public static final immediateStop:I = 0x7f090369

.field public static final included:I = 0x7f090382

.field public static final info:I = 0x7f090385

.field public static final invisible:I = 0x7f09038a

.field public static final italic:I = 0x7f090391

.field public static final item1:I = 0x7f090393

.field public static final item2:I = 0x7f090395

.field public static final item3:I = 0x7f090396

.field public static final item4:I = 0x7f090397

.field public static final item_touch_helper_previous_elevation:I = 0x7f09039e

.field public static final ivEditor:I = 0x7f0903b4

.field public static final ivImage:I = 0x7f0903bd

.field public static final ivPicture:I = 0x7f0903c9

.field public static final ivPlay:I = 0x7f0903cc

.field public static final iv_play_back:I = 0x7f090433

.field public static final iv_play_fast:I = 0x7f090435

.field public static final iv_play_video:I = 0x7f090436

.field public static final jumpToEnd:I = 0x7f09046d

.field public static final jumpToStart:I = 0x7f09046e

.field public static final layout:I = 0x7f0904a6

.field public static final left:I = 0x7f0904db

.field public static final line1:I = 0x7f0904ef

.field public static final line3:I = 0x7f0904f1

.field public static final linear:I = 0x7f0904f5

.field public static final listMode:I = 0x7f0904fb

.field public static final list_item:I = 0x7f0904fd

.field public static final ll_play_menu:I = 0x7f090555

.field public static final loading:I = 0x7f090576

.field public static final magical:I = 0x7f09058d

.field public static final match_constraint:I = 0x7f090595

.field public static final match_parent:I = 0x7f090596

.field public static final media_actions:I = 0x7f0905ab

.field public static final message:I = 0x7f0905b3

.field public static final middle:I = 0x7f0905ba

.field public static final motion_base:I = 0x7f0905cb

.field public static final multiply:I = 0x7f0905e3

.field public static final music_seek_bar:I = 0x7f0905e4

.field public static final never:I = 0x7f0905f5

.field public static final neverCompleteToEnd:I = 0x7f0905f6

.field public static final neverCompleteToStart:I = 0x7f0905f7

.field public static final noState:I = 0x7f0905fc

.field public static final none:I = 0x7f0905fe

.field public static final normal:I = 0x7f0905ff

.field public static final north:I = 0x7f090600

.field public static final notification_background:I = 0x7f090602

.field public static final notification_main_column:I = 0x7f090603

.field public static final notification_main_column_container:I = 0x7f090604

.field public static final off:I = 0x7f090626

.field public static final on:I = 0x7f09062a

.field public static final overshoot:I = 0x7f09063c

.field public static final packed:I = 0x7f09063e

.field public static final parent:I = 0x7f090645

.field public static final parentPanel:I = 0x7f090646

.field public static final parentRelative:I = 0x7f090647

.field public static final path:I = 0x7f09064f

.field public static final pathRelative:I = 0x7f090650

.field public static final percent:I = 0x7f09065b

.field public static final playerView:I = 0x7f09066d

.field public static final position:I = 0x7f090678

.field public static final postLayout:I = 0x7f09067c

.field public static final preview_image:I = 0x7f09067d

.field public static final progress:I = 0x7f090684

.field public static final progress_circular:I = 0x7f090687

.field public static final progress_horizontal:I = 0x7f090688

.field public static final ps_complete_select:I = 0x7f09068c

.field public static final ps_iv_arrow:I = 0x7f09068d

.field public static final ps_iv_delete:I = 0x7f09068e

.field public static final ps_iv_left_back:I = 0x7f09068f

.field public static final ps_rl_album_bg:I = 0x7f090690

.field public static final ps_rl_album_click:I = 0x7f090691

.field public static final ps_tv_cancel:I = 0x7f090692

.field public static final ps_tv_complete:I = 0x7f090693

.field public static final ps_tv_editor:I = 0x7f090694

.field public static final ps_tv_photo:I = 0x7f090695

.field public static final ps_tv_preview:I = 0x7f090696

.field public static final ps_tv_select_num:I = 0x7f090697

.field public static final ps_tv_selected:I = 0x7f090698

.field public static final ps_tv_selected_word:I = 0x7f090699

.field public static final ps_tv_title:I = 0x7f09069a

.field public static final ps_tv_video:I = 0x7f09069b

.field public static final radio:I = 0x7f0906aa

.field public static final rectangles:I = 0x7f0906b0

.field public static final recycler:I = 0x7f0906b1

.field public static final reverseSawtooth:I = 0x7f0906c6

.field public static final right:I = 0x7f0906c8

.field public static final right_icon:I = 0x7f0906ca

.field public static final right_side:I = 0x7f0906cb

.field public static final rl_title_bar:I = 0x7f0906d5

.field public static final rootView:I = 0x7f0906da

.field public static final rootViewBg:I = 0x7f0906db

.field public static final round_group:I = 0x7f0906dd

.field public static final sawtooth:I = 0x7f090705

.field public static final screen:I = 0x7f090709

.field public static final scrollIndicatorDown:I = 0x7f09070b

.field public static final scrollIndicatorUp:I = 0x7f09070c

.field public static final scrollView:I = 0x7f09070d

.field public static final search_badge:I = 0x7f090713

.field public static final search_bar:I = 0x7f090714

.field public static final search_button:I = 0x7f090715

.field public static final search_close_btn:I = 0x7f090716

.field public static final search_edit_frame:I = 0x7f090718

.field public static final search_go_btn:I = 0x7f090719

.field public static final search_mag_icon:I = 0x7f09071a

.field public static final search_plate:I = 0x7f09071b

.field public static final search_src_text:I = 0x7f09071c

.field public static final search_voice_btn:I = 0x7f09071d

.field public static final select_click_area:I = 0x7f090726

.field public static final select_dialog_listview:I = 0x7f090727

.field public static final sharedValueSet:I = 0x7f090735

.field public static final sharedValueUnset:I = 0x7f090736

.field public static final shortcut:I = 0x7f090737

.field public static final sin:I = 0x7f09073d

.field public static final skipped:I = 0x7f090741

.field public static final south:I = 0x7f090748

.field public static final spacer:I = 0x7f090752

.field public static final special_effects_controller_view_tag:I = 0x7f090753

.field public static final spline:I = 0x7f090755

.field public static final split_action_bar:I = 0x7f090756

.field public static final spread:I = 0x7f090757

.field public static final spread_inside:I = 0x7f090758

.field public static final spring:I = 0x7f090759

.field public static final square:I = 0x7f09075a

.field public static final src_atop:I = 0x7f09075b

.field public static final src_in:I = 0x7f09075c

.field public static final src_over:I = 0x7f09075d

.field public static final standard:I = 0x7f090767

.field public static final start:I = 0x7f090768

.field public static final startHorizontal:I = 0x7f090769

.field public static final startVertical:I = 0x7f09076b

.field public static final staticLayout:I = 0x7f09076e

.field public static final staticPostLayout:I = 0x7f09076f

.field public static final status_bar_latest_event_content:I = 0x7f090775

.field public static final stop:I = 0x7f090776

.field public static final submenuarrow:I = 0x7f090778

.field public static final submit_area:I = 0x7f09077b

.field public static final support_container:I = 0x7f09077e

.field public static final tabMode:I = 0x7f09079c

.field public static final tag_accessibility_actions:I = 0x7f0907a1

.field public static final tag_accessibility_clickable_spans:I = 0x7f0907a2

.field public static final tag_accessibility_heading:I = 0x7f0907a3

.field public static final tag_accessibility_pane_title:I = 0x7f0907a4

.field public static final tag_on_apply_window_listener:I = 0x7f0907a7

.field public static final tag_on_receive_content_listener:I = 0x7f0907a8

.field public static final tag_on_receive_content_mime_types:I = 0x7f0907a9

.field public static final tag_screen_reader_focusable:I = 0x7f0907aa

.field public static final tag_state_description:I = 0x7f0907ab

.field public static final tag_transition_group:I = 0x7f0907ad

.field public static final tag_unhandled_key_event_manager:I = 0x7f0907af

.field public static final tag_unhandled_key_listeners:I = 0x7f0907b0

.field public static final tag_window_insets_animation_callback:I = 0x7f0907b1

.field public static final text:I = 0x7f0907b7

.field public static final text2:I = 0x7f0907ba

.field public static final textSpacerNoButtons:I = 0x7f0907c0

.field public static final textSpacerNoTitle:I = 0x7f0907c1

.field public static final time:I = 0x7f09082f

.field public static final title:I = 0x7f090834

.field public static final titleDividerNoCustom:I = 0x7f090836

.field public static final title_bar:I = 0x7f090839

.field public static final title_bar_line:I = 0x7f09083a

.field public static final title_template:I = 0x7f09083d

.field public static final top:I = 0x7f090845

.field public static final topPanel:I = 0x7f090846

.field public static final top_line:I = 0x7f090849

.field public static final top_status_bar:I = 0x7f09084a

.field public static final triangle:I = 0x7f090862

.field public static final tvCamera:I = 0x7f090882

.field public static final tvCheck:I = 0x7f090888

.field public static final tvTitle:I = 0x7f090938

.field public static final tv_audio_name:I = 0x7f090981

.field public static final tv_content:I = 0x7f090992

.field public static final tv_current_data_time:I = 0x7f09099b

.field public static final tv_current_time:I = 0x7f09099c

.field public static final tv_data_empty:I = 0x7f09099f

.field public static final tv_duration:I = 0x7f0909a7

.field public static final tv_folder_name:I = 0x7f0909b2

.field public static final tv_media_tag:I = 0x7f0909ea

.field public static final tv_select_tag:I = 0x7f090a3d

.field public static final tv_total_duration:I = 0x7f090a6a

.field public static final unchecked:I = 0x7f090a88

.field public static final uniform:I = 0x7f090a89

.field public static final up:I = 0x7f090a8c

.field public static final vertical_only:I = 0x7f090aa4

.field public static final video_line:I = 0x7f090aa6

.field public static final viewBorder:I = 0x7f090ab4

.field public static final view_transition:I = 0x7f090ac0

.field public static final view_tree_lifecycle_owner:I = 0x7f090ac1

.field public static final view_tree_saved_state_registry_owner:I = 0x7f090ac3

.field public static final view_tree_view_model_store_owner:I = 0x7f090ac4

.field public static final visible:I = 0x7f090ac6

.field public static final visible_removing_fragment_view_tag:I = 0x7f090ac7

.field public static final west:I = 0x7f090adb

.field public static final wrap:I = 0x7f090aec

.field public static final wrap_content:I = 0x7f090aed

.field public static final wrap_content_constrained:I = 0x7f090aee

.field public static final x_left:I = 0x7f090af3

.field public static final x_right:I = 0x7f090af4


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method
