.class Lcom/luck/picture/lib/d$j;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/dialog/c$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->V1(Lcom/luck/picture/lib/entity/LocalMedia;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/d$j;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "b~s~n@y~@~v~ i~c~/ ~@i~ ~u  o~@.o M@ @  ~ @/bt So-b@~@@oal~ 1 @ ~d@@@~@~o~@s4@fl~@om~~K t~ @ f@i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d$j;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->f(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/basic/e;->J()V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/d$j;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v3, Lcom/luck/picture/lib/d$j$a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v3, p0}, Lcom/luck/picture/lib/d$j$a;-><init>(Lcom/luck/picture/lib/d$j;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1, v0, v2, v3}, Lcom/luck/picture/lib/utils/g;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ls6/c;)V

    const/4 v5, 0x3

    return-void
.end method
