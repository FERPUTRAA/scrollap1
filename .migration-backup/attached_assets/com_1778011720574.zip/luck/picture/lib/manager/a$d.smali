.class Lcom/luck/picture/lib/manager/a$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/manager/a;->c(Landroid/content/Context;ZLs6/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/io/File;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/io/File;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/manager/a$d;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/luck/picture/lib/manager/a$d;->b:Ljava/io/File;

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@as @S@o @dtb 1~@ b~~4 @bs@o @@ ~ @@m K~ /~ ii ~@~@r/l~~~~@~~My@lo@o. uo~@-~~cn  ~f~@i~~@~@ o tv"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lcom/luck/picture/lib/basic/h;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/manager/a$d;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/manager/a$d;->b:Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/basic/h;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method
