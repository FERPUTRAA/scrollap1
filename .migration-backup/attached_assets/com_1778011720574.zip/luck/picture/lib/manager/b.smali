.class public final Lcom/luck/picture/lib/manager/b;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = -0x1

.field public static final b:I = 0x0

.field public static final c:I = 0x1

.field public static final d:I = 0xc8

.field private static final e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private static final f:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private static final g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private static final h:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation
.end field

.field private static i:Lcom/luck/picture/lib/entity/LocalMediaFolder;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object v0, Lcom/luck/picture/lib/manager/b;->f:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lcom/luck/picture/lib/manager/b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lcom/luck/picture/lib/manager/b;->h:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@so~~b/ ~i~   @@b~@l ~-~d~M@u@ 1~o~@ 4@b@@ @no ~~s~~t / im~o.~c Sl @o@K@ r   vyo~@@@t~~afi~@@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->f()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/luck/picture/lib/manager/b;->h:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static declared-synchronized b(Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p0
.end method

.method public static c(Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->g()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/luck/picture/lib/manager/b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static declared-synchronized d(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v3, 0x3

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v1, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw p0
.end method

.method public static e(Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->h()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/manager/b;->f:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public static f()V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Lcom/luck/picture/lib/manager/b;->h:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-lez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public static g()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lcom/luck/picture/lib/manager/b;->g:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-lez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public static h()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v0, Lcom/luck/picture/lib/manager/b;->f:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-lez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public static declared-synchronized i()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v4, 0x2

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v1, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-lez v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x5

    throw v1
.end method

.method public static j()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    sget-object v0, Lcom/luck/picture/lib/manager/b;->h:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method public static k()Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/luck/picture/lib/manager/b;->i:Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static l()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    sget-object v0, Lcom/luck/picture/lib/manager/b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x0

    return-object v0
.end method

.method public static m()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public static n()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/luck/picture/lib/manager/b;->f:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public static declared-synchronized o()Ljava/util/ArrayList;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v3, 0x2

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const-class v0, Lcom/luck/picture/lib/manager/b;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    sget-object v1, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    throw v1
.end method

.method public static p()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/luck/picture/lib/manager/b;->e:Ljava/util/ArrayList;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-lez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public static q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 2

    const/4 v1, 0x2

    sput-object p0, Lcom/luck/picture/lib/manager/b;->i:Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method
