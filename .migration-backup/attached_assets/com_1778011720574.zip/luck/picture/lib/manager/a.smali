.class public Lcom/luck/picture/lib/manager/a;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @si ~~ ~ l. ~/v @o@@@ o  f~~Ksl n~ur ~ S~~@ii~~@t~@d o~o -~~@b@b@y~bac~f4@@  @@@1/o~M@@t@~~~o@m"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/manager/a;->c(Landroid/content/Context;ZLs6/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public static b(Landroid/content/Context;Ls6/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ls6/c<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0, p1}, Lcom/luck/picture/lib/manager/a;->c(Landroid/content/Context;ZLs6/c;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method private static c(Landroid/content/Context;ZLs6/c;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Z",
            "Ls6/c<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v0, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    array-length v2, v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v3, v1

    move v3, v1

    const/4 v7, 0x6

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    if-ge v3, v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    aget-object v4, v0, v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v5, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v5, Lcom/luck/picture/lib/manager/a$b;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v5, p0, v4}, Lcom/luck/picture/lib/manager/a$b;-><init>(Landroid/content/Context;Ljava/io/File;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v5}, Lcom/luck/picture/lib/thread/a;->s0(Ljava/lang/Runnable;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz p2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {p2, v4}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_1
    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v0, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    array-length v2, v0

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ge v3, v2, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    aget-object v4, v0, v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v5, :cond_4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v5, :cond_4

    if-eqz p1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v5, Lcom/luck/picture/lib/manager/a$c;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v5, p0, v4}, Lcom/luck/picture/lib/manager/a$c;-><init>(Landroid/content/Context;Ljava/io/File;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v5}, Lcom/luck/picture/lib/thread/a;->s0(Ljava/lang/Runnable;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_3

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz p2, :cond_4

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {p2, v4}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_4
    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_2

    :cond_5
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v0, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v0, :cond_8

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    array-length v2, v0

    :goto_4
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ge v1, v2, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x7

    aget-object v3, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v4, :cond_7

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v4, :cond_7

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz p1, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v4, Lcom/luck/picture/lib/manager/a$d;

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v4, p0, v3}, Lcom/luck/picture/lib/manager/a$d;-><init>(Landroid/content/Context;Ljava/io/File;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v4}, Lcom/luck/picture/lib/thread/a;->s0(Ljava/lang/Runnable;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_5

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz p2, :cond_7

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-interface {p2, v3}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_7
    :goto_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_4

    :cond_8
    return-void
.end method

.method public static d(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/manager/a;->c(Landroid/content/Context;ZLs6/c;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public static e(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1}, Lcom/luck/picture/lib/manager/a;->g(Landroid/content/Context;IZLs6/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public static f(Landroid/content/Context;ILs6/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I",
            "Ls6/c<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, v0, p2}, Lcom/luck/picture/lib/manager/a;->g(Landroid/content/Context;IZLs6/c;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private static g(Landroid/content/Context;IZLs6/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "IZ",
            "Ls6/c<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->c()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-ne p1, v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    sget-object p1, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object p1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p1, :cond_3

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    array-length v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ge v1, v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-object v2, p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v3, Lcom/luck/picture/lib/manager/a$a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v3, p0, v2}, Lcom/luck/picture/lib/manager/a$a;-><init>(Landroid/content/Context;Ljava/io/File;)V

    const/4 v5, 0x4

    invoke-static {v3}, Lcom/luck/picture/lib/thread/a;->s0(Ljava/lang/Runnable;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-interface {p3, v2}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_2
    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void
.end method

.method public static h(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/luck/picture/lib/manager/a;->i(Ljava/lang/String;Ls6/c;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static i(Ljava/lang/String;Ls6/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ls6/c<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x0

    new-instance v0, Ljava/io/File;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz p0, :cond_1

    const/4 v5, 0x0

    array-length v0, p0

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x5

    or-int/2addr v4, v1

    :goto_0
    const/4 v5, 0x7

    if-ge v1, v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    aget-object v2, p0, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {p1, v2}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    move v5, v4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void
.end method

.method public static j(Landroid/content/Context;I)V
    .locals 4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0, p1, v0, v1}, Lcom/luck/picture/lib/manager/a;->g(Landroid/content/Context;IZLs6/c;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    return-void
.end method
