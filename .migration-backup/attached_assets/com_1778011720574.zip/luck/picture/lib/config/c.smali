.class public final Lcom/luck/picture/lib/config/c;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0x1

.field public static final b:I = 0x2

.field public static final c:I = 0x3

.field public static final d:I = 0x4

.field public static final e:I = 0x5

.field public static final f:I = 0x6

.field public static final g:I = 0x7

.field public static final h:I = 0x8

.field public static final i:I = 0x9

.field public static final j:I = 0xa


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s1~S  b  ~@~b/@l~ @~-v4~fo@b~~i@~@@@~   u~ om@~ ~o.~~@i~s K~~/  cd y @t @t@il@@n@@~f~oM@@raoo~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j1:Ls6/f;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Ls6/f;->a(Landroid/content/Context;I)I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p0
.end method
