.class public Lcom/luck/picture/lib/config/b;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "customExtraData"

.field public static final b:Ljava/lang/String; = "outPutPath"

.field public static final c:Ljava/lang/String; = "imageWidth"

.field public static final d:Ljava/lang/String; = "imageHeight"

.field public static final e:Ljava/lang/String; = "offsetX"

.field public static final f:Ljava/lang/String; = "offsetY"

.field public static final g:Ljava/lang/String; = "aspectRatio"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method
