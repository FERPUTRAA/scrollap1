.class public final Lcom/luck/picture/lib/config/PictureSelectionConfig;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/config/PictureSelectionConfig;",
            ">;"
        }
    .end annotation
.end field

.field public static X0:Lq6/d;

.field public static Y0:Lq6/a;

.field public static Z0:Lq6/b;

.field public static a1:Lq6/f;

.field public static b1:Lq6/c;

.field public static c1:Lcom/luck/picture/lib/style/a;

.field public static d1:Ls6/d;

.field public static e1:Ls6/x;

.field public static f1:Ls6/v;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field public static g1:Ls6/e;

.field public static h1:Ls6/h;

.field public static i1:Ls6/k;

.field public static j1:Ls6/f;

.field public static k1:Ls6/l;

.field public static l1:Ls6/w;

.field public static m1:Ls6/j;

.field public static n1:Ls6/i;

.field public static o1:Ls6/q;

.field private static p1:Lcom/luck/picture/lib/config/PictureSelectionConfig;


# instance fields
.field public A:J

.field public A0:I

.field public B:I

.field public B0:Z

.field public C:Z

.field public C0:Z

.field public D:Z

.field public D0:Z

.field public E:Z

.field public E0:I

.field public F:Z

.field public F0:Z

.field public G:Z

.field public G0:Z

.field public H:Z

.field public H0:Z

.field public I:Z

.field public I0:Z

.field public J:Z

.field public J0:Z

.field public K:Z

.field public K0:I

.field public L:Z

.field public L0:Z

.field public M:Z

.field public M0:Z

.field public N:Z

.field public N0:Z

.field public O:Z

.field public O0:Z

.field public P:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public P0:Z

.field public Q:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public Q0:Z

.field public R:Z

.field public R0:Z

.field public S:Ljava/lang/String;

.field public S0:Z

.field public T:Ljava/lang/String;

.field public T0:Z

.field public U:Ljava/lang/String;

.field public U0:Z

.field public V:Ljava/lang/String;

.field public V0:Z

.field public W:Ljava/lang/String;

.field public W0:Z

.field public X:Ljava/lang/String;

.field public Y:Ljava/lang/String;

.field public Z:Ljava/lang/String;

.field public a:I

.field public b:Z

.field public c:Z

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:I

.field public i:Z

.field public j:I

.field public k:I

.field public k0:Ljava/lang/String;

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:I

.field public x:J

.field public y:J

.field public z:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/luck/picture/lib/config/PictureSelectionConfig$a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/luck/picture/lib/config/PictureSelectionConfig$a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x0

    move v6, v5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v5, 0x2

    move v6, v5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i:Z

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l:I

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->u:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->v:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->w:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    iput-wide v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput-wide v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput-wide v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-wide v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    const/4 v6, 0x1

    goto :goto_3

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_3
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v0, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_4

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v5, 0x5

    move v6, v5

    if-eqz v0, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_5

    :cond_5
    const/4 v5, 0x4

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    :goto_5
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E:Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v0, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    goto :goto_6

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_6
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F:Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v0, :cond_7

    const/4 v6, 0x4

    const/4 v5, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_7

    :cond_7
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_7
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G:Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_8

    :cond_8
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_8
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v0, :cond_9

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_9

    :cond_9
    const/4 v5, 0x0

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    :goto_9
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_a

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    goto :goto_a

    :cond_a
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_a
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v0, :cond_b

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    goto :goto_b

    :cond_b
    const/4 v6, 0x5

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_b
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v0, :cond_c

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    goto :goto_c

    :cond_c
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    :goto_c
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L:Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_d

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_d

    :cond_d
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_d
    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M:Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_e

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_e

    :cond_e
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_e
    const/4 v6, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N:Z

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_f

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    goto :goto_f

    :cond_f
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    :goto_f
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O:Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q:Ljava/util/List;

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v0, :cond_10

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_10

    :cond_10
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_10
    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_11

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_11

    :cond_11
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_11
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v0, :cond_12

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    goto :goto_12

    :cond_12
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_12
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_13

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_13

    :cond_13
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_13
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D0:Z

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E0:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_14

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_14

    :cond_14
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_14
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F0:Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v0, :cond_15

    const/4 v6, 0x7

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_15

    :cond_15
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    :goto_15
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G0:Z

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v0, :cond_16

    const/4 v6, 0x7

    const/4 v5, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_16

    :cond_16
    const/4 v6, 0x1

    const/4 v5, 0x0

    move v0, v2

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_16
    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H0:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_17

    const/4 v6, 0x6

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_17

    :cond_17
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_17
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I0:Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_18

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_18

    :cond_18
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    :goto_18
    const/4 v6, 0x7

    const/4 v5, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J0:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K0:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_19

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_19

    :cond_19
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    :goto_19
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_1a

    const/4 v6, 0x4

    const/4 v5, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    goto :goto_1a

    :cond_1a
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_1a
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_1b

    const/4 v5, 0x2

    move v6, v5

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_1b

    :cond_1b
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_1b
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v0, :cond_1c

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_1c

    :cond_1c
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_1c
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O0:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v0, :cond_1d

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1d

    :cond_1d
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_1d
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v5, 0x6

    move v6, v5

    if-eqz v0, :cond_1e

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_1e

    :cond_1e
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    :goto_1e
    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_1f

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_1f

    :cond_1f
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    :goto_1f
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R0:Z

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_20

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    const/4 v5, 0x3

    move v6, v5

    goto :goto_20

    :cond_20
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    const/4 v6, 0x1

    move v0, v2

    :goto_20
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_21

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_21

    :cond_21
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_21
    const/4 v6, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v0, :cond_22

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_22

    :cond_22
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_22
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v0, :cond_23

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_23

    :cond_23
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    :goto_23
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz p1, :cond_24

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_24

    :cond_24
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    move v1, v2

    move v1, v2

    const/4 v6, 0x7

    move v1, v2

    move v1, v2

    :goto_24
    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W0:Z

    const/4 v6, 0x0

    return-void
.end method

.method public static a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s/@~@~~.t~a -s b@~o~@ ~ 4 @~@~ l~~K d y~u@r~t So ~@@omncio@ @lif v @@~~@@~~bbo~/@ o@i1~  ~f~@M"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d1:Ls6/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g1:Ls6/e;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h1:Ls6/h;

    const/4 v3, 0x5

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j1:Ls6/f;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k1:Ls6/l;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e1:Ls6/x;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l1:Ls6/w;

    const/4 v3, 0x1

    const/4 v2, 0x3

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m1:Ls6/j;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n1:Ls6/i;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o1:Ls6/q;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->k0()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/thread/a;->f(Ljava/util/concurrent/ExecutorService;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->i()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {}, Lcom/luck/picture/lib/magical/a;->a()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v3, 0x4

    return-void
.end method

.method public static c()Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 3

    const/4 v2, 0x3

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static d()Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p1:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-class v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const-class v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x3

    const-class v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const-class v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p1:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v1}, Lcom/luck/picture/lib/config/PictureSelectionConfig;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p1:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e()V

    :cond_0
    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p1:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method protected e()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/h;->c()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v6, 0x0

    and-int/2addr v7, v6

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v1}, Lcom/luck/picture/lib/style/a;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    sput-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 v1, 0x9

    const/4 v7, 0x2

    iput v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v6, 0x1

    move v7, v6

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o:I

    const/4 v6, 0x6

    move v7, v6

    iput v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v2, -0x2

    const/4 v7, 0x1

    const/4 v6, 0x7

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v6, 0x6

    move v7, v6

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/16 v2, 0x3e8

    const/4 v7, 0x7

    const/4 v6, 0x3

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v6, 0x1

    const/4 v6, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    iput-wide v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-wide/16 v4, 0x400

    const-wide/16 v4, 0x400

    const/4 v7, 0x5

    const-wide/16 v4, 0x400

    const-wide/16 v4, 0x400

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v4, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-wide v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/16 v2, 0x3c

    const/4 v7, 0x4

    const/4 v6, 0x5

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->u:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    iput v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->v:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v3, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x3

    iput v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->w:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i:Z

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O:Z

    const/4 v7, 0x2

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v7, 0x0

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E:Z

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F:Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G:Z

    const/4 v7, 0x3

    const/4 v6, 0x6

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H:Z

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I:Z

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L:Z

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M:Z

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v3, "gejms"

    const-string/jumbo v3, "pgsje"

    const/4 v7, 0x3

    const-string v3, "e.jgo"

    const-string v3, ".jpeg"

    const/4 v7, 0x4

    const/4 v6, 0x6

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v3, ".mp4"

    const-string v3, "4p.m"

    const/4 v7, 0x2

    const-string v3, ".mp4"

    const/4 v7, 0x6

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v3, "m/gambijep"

    const-string v3, "ep/magjeim"

    const/4 v7, 0x2

    const-string v3, "ggpieeujm/"

    const-string/jumbo v3, "image/jpeg"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v3, "o4m/pvdpi"

    const-string v3, "dp/4oiemv"

    const/4 v7, 0x0

    const-string/jumbo v3, "opimed/vq"

    const-string/jumbo v3, "video/mp4"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x5

    const-string v3, ""

    const/4 v7, 0x1

    const/4 v6, 0x7

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v4, Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object v4, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v7, 0x7

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D0:Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v2, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E0:I

    const/4 v7, 0x0

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F0:Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G0:Z

    const/4 v7, 0x1

    const/4 v6, 0x3

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H0:Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I0:Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    xor-int/2addr v4, v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-boolean v4, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J0:Z

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput v4, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K0:I

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v7, 0x7

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R0:Z

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eq v2, v4, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    const/4 v7, 0x3

    move v2, v1

    move v2, v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput-boolean v2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O0:Z

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v7, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q:Ljava/util/List;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput-object v3, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput-boolean v1, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W0:Z

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v2, 0x1

    move v3, v2

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-byte p2, p2

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l:I

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x7

    move v3, v2

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n:I

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->u:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->v:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->w:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    int-to-byte p2, p2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E:Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    int-to-byte p2, p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    int-to-byte p2, p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    int-to-byte p2, p2

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    int-to-byte p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    int-to-byte p2, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    int-to-byte p2, p2

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x0

    and-int/2addr v3, v2

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D0:Z

    const/4 v2, 0x7

    move v3, v2

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v2, 0x0

    move v3, v2

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E0:I

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F0:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    int-to-byte p2, p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G0:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    int-to-byte p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H0:Z

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I0:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J0:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K0:I

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O0:Z

    const/4 v2, 0x5

    move v3, v2

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R0:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    int-to-byte p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v2, 0x5

    move v3, v2

    iget-boolean p2, p0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W0:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    return-void
.end method
