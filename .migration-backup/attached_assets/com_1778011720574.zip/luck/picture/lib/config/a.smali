.class public Lcom/luck/picture/lib/config/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0x2b8

.field public static final b:I = 0x45

.field public static final c:I = 0x60

.field private static final d:Ljava/lang/String; = "com.yalantis.ucrop"

.field public static final e:Ljava/lang/String; = "com.yalantis.ucrop.CropAspectRatio"

.field public static final f:Ljava/lang/String; = "com.yalantis.ucrop.ImageWidth"

.field public static final g:Ljava/lang/String; = "com.yalantis.ucrop.ImageHeight"

.field public static final h:Ljava/lang/String; = "com.yalantis.ucrop.OffsetX"

.field public static final i:Ljava/lang/String; = "com.yalantis.ucrop.OffsetY"

.field public static final j:Ljava/lang/String; = "com.yalantis.ucrop.Error"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/Intent;)Ljava/lang/Throwable;
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os~@@~1~~d/Kc y@Sb~o.~  @   fb~~~t o~~@~4~@f-i@@al  vr@u@@ s @~/o~nb ~~~~~@  o @@l mM@@@t ~ii@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-string/jumbo v0, "soamtp.raylmsE..occnirro"

    const-string v0, ".csrmloEsanrypc.at.rioro"

    const/4 v2, 0x5

    const-string v0, "cps.oonuarrtrrEaylmcio.o"

    const-string v0, "com.yalantis.ucrop.Error"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object p0

    const/4 v2, 0x2

    check-cast p0, Ljava/lang/Throwable;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static b(Landroid/content/Intent;)Landroid/net/Uri;
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const-string/jumbo v0, "pttumb"

    const-string/jumbo v0, "uttmpo"

    const/4 v2, 0x2

    const-string/jumbo v0, "uttupu"

    const-string/jumbo v0, "output"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Landroid/net/Uri;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public static c(Landroid/content/Intent;)F
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, "coaatonpo..iRprl.emratAspcucosCyot"

    const-string v0, ".cpooyitascntosAolotcRrrmau.aCpe.p"

    const/4 v3, 0x1

    const-string/jumbo v0, "oapCenscq.p.ri.csotaomtpaluAtriyoc"

    const-string v0, "com.yalantis.ucrop.CropAspectRatio"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getFloatExtra(Ljava/lang/String;F)F

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p0
.end method

.method public static d(Landroid/content/Intent;)Ljava/lang/String;
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "Exsorsbattcmaut"

    const-string/jumbo v0, "xutEabatamstroc"

    const-string/jumbo v0, "trsmtaaucoDtxma"

    const-string v0, "customExtraData"

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static e(Landroid/content/Intent;)I
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "a.epo.Hle.roiItuuaymontgciscam"

    const-string v0, ".aayguuHmtmIitrnle.icsocoep.ah"

    const/4 v3, 0x3

    const-string v0, "alIenb.goarumg.iycmcehs.ptoitH"

    const-string v0, "com.yalantis.ucrop.ImageHeight"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p0
.end method

.method public static f(Landroid/content/Intent;)I
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v0, ".nturauyalecocpfXistpo.sfO"

    const-string v0, "fcoteXppasf.Oominu.atrcsly"

    const/4 v3, 0x0

    const-string/jumbo v0, "iuaayccppn.Xeos.sflmtOft.r"

    const-string v0, "com.yalantis.ucrop.OffsetX"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return p0
.end method

.method public static g(Landroid/content/Intent;)I
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "elsatu.oqof..sYOipqyfaccmr"

    const-string/jumbo v0, "rcuYsnaaq.s.cmetoly.Ofipof"

    const/4 v3, 0x2

    const-string v0, "eisyspo.lacnmOutoffsctar.."

    const-string v0, "com.yalantis.ucrop.OffsetY"

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    return p0
.end method

.method public static h(Landroid/content/Intent;)I
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v0, "m.oma.hgsae.lmudopWiatsnitrcc"

    const-string v0, "iascugpioocdharnIttm.emlW.sa."

    const/4 v3, 0x6

    const-string v0, "eaicopWtaha.yu.nclomdiIrs.tmg"

    const-string v0, "com.yalantis.ucrop.ImageWidth"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p0
.end method
