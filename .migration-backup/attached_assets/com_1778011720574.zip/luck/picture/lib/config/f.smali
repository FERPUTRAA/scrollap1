.class public final Lcom/luck/picture/lib/config/f;
.super Ljava/lang/Object;


# static fields
.field public static final A:Ljava/lang/String; = ".mp4"

.field public static final B:Ljava/lang/String; = ".avi"

.field public static final C:Ljava/lang/String; = "image/jpeg"

.field public static final D:Ljava/lang/String; = "image/png"

.field public static final E:Ljava/lang/String; = "video/mp4"

.field public static final F:Ljava/lang/String; = "video/avi"

.field public static final G:Ljava/lang/String; = "audio/amr"

.field public static final H:Ljava/lang/String; = "audio/x-wav"

.field public static final I:Ljava/lang/String; = "audio/mpeg"

.field public static final J:Ljava/lang/String; = "DCIM/Camera"

.field public static final K:Ljava/lang/String; = "Camera"

.field public static final a:Ljava/lang/String; = "image/jpeg"

.field public static final b:Ljava/lang/String; = "video/mp4"

.field public static final c:Ljava/lang/String; = "audio/mpeg"

.field public static final d:Ljava/lang/String; = "audio/amr"

.field public static final e:Ljava/lang/String; = "image"

.field public static final f:Ljava/lang/String; = "video"

.field public static final g:Ljava/lang/String; = "audio"

.field private static final h:Ljava/lang/String; = "image/png"

.field public static final i:Ljava/lang/String; = "image/jpeg"

.field private static final j:Ljava/lang/String; = "image/jpg"

.field private static final k:Ljava/lang/String; = "image/bmp"

.field private static final l:Ljava/lang/String; = "image/gif"

.field private static final m:Ljava/lang/String; = "image/webp"

.field private static final n:Ljava/lang/String; = "video/3gp"

.field private static final o:Ljava/lang/String; = "video/mp4"

.field private static final p:Ljava/lang/String; = "video/mpeg"

.field private static final q:Ljava/lang/String; = "video/avi"

.field public static final r:Ljava/lang/String; = ".jpeg"

.field public static final s:Ljava/lang/String; = ".jpg"

.field public static final t:Ljava/lang/String; = ".png"

.field public static final u:Ljava/lang/String; = ".webp"

.field public static final v:Ljava/lang/String; = ".gif"

.field public static final w:Ljava/lang/String; = ".bmp"

.field public static final x:Ljava/lang/String; = ".amr"

.field public static final y:Ljava/lang/String; = ".wav"

.field public static final z:Ljava/lang/String; = ".mp3"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i@sb@~~~fi ~o~~@@@n~@@ ~ @@ @ c  @S~vfKt ~~~~b @Mo~4olso 1bm r ~ l@  u@~/y@@~.@a/~o~- t~i~ @o@@d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const-string v0, "/"

    const-string v0, "/"

    const-string v0, "/"

    const-string v0, "/"

    :try_start_0
    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const-string v1, "."

    const-string v1, "."

    const/4 v3, 0x4

    const-string v1, "."

    const-string v1, "."

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0

    :catch_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const-string p0, ".pgj"

    const-string p0, ".pgj"

    const/4 v3, 0x0

    const-string p0, "gp.j"

    const-string p0, ".jpg"

    const/4 v3, 0x3

    return-object p0
.end method

.method public static b(Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v3, 0x3

    const-string v0, "dsomv"

    const-string v0, "dosvi"

    const-string/jumbo v0, "idveo"

    const-string/jumbo v0, "video"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "buamo"

    const-string v0, "iaomu"

    const/4 v3, 0x5

    const-string v0, "duoau"

    const-string v0, "audio"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p0, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p0

    :cond_2
    const/4 v3, 0x1

    return v1
.end method

.method public static c(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "e/ttnonp/:"

    const-string/jumbo v0, "no/:oten/t"

    const/4 v2, 0x6

    const-string v0, "ct/neno:q/"

    const-string v0, "content://"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p0
.end method

.method public static d(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "iasbu"

    const-string v0, "budai"

    const/4 v2, 0x0

    const-string v0, "diamu"

    const-string v0, "audio"

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0
.end method

.method public static e(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "g/iuoifmg"

    const-string v0, "gg/fieumi"

    const/4 v2, 0x7

    const-string v0, "emigfbagi"

    const-string/jumbo v0, "image/gif"

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "meGFIpug/"

    const-string v0, "/meGgFipI"

    const/4 v2, 0x7

    const-string v0, "IF/geGipa"

    const-string/jumbo v0, "image/GIF"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 p0, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p0
.end method

.method public static f(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "ttph"

    const-string v0, "hptt"

    const/4 v3, 0x2

    const-string/jumbo v0, "ptht"

    const-string v0, "http"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "shtqt"

    const-string v0, "https"

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-eqz p0, :cond_2

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x1

    :cond_2
    const/4 v2, 0x5

    const/4 v2, 0x4

    return v1
.end method

.method public static g(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "qgsim"

    const-string v0, "eigqm"

    const/4 v2, 0x6

    const-string v0, "agmme"

    const-string/jumbo v0, "image"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 p0, 0x5

    const/4 p0, 0x1

    const/4 v2, 0x0

    and-int/2addr v1, p0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0
.end method

.method public static h(Ljava/lang/String;)Z
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "sivdo"

    const-string v0, "disov"

    const/4 v2, 0x1

    const-string v0, "bevoi"

    const-string/jumbo v0, "video"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x4

    move v1, p0

    move v1, p0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p0
.end method

.method public static i(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "mweibaupeg"

    const-string/jumbo v0, "image/webp"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    const/4 p0, 0x0

    and-int/2addr v2, p0

    :goto_0
    const/4 v1, 0x0

    const/4 v2, 0x4

    return p0
.end method

.method public static j(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, "geimepjg/a"

    const/4 v3, 0x5

    const-string v0, "iap/eggpej"

    const-string/jumbo v0, "image/jpeg"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x3

    move v3, v2

    const-string/jumbo v0, "igeaomjpq"

    const-string/jumbo v0, "ige/ompaj"

    const/4 v3, 0x1

    const-string/jumbo v0, "jgseipmg/"

    const-string/jumbo v0, "image/jpg"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p0, :cond_2

    :cond_1
    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v1
.end method

.method public static k(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "iegmpbagm"

    const-string/jumbo v0, "ijgpgbeam"

    const/4 v2, 0x5

    const-string/jumbo v0, "imago/peg"

    const-string/jumbo v0, "image/jpg"

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0
.end method

.method public static l(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x5

    or-int/2addr v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/config/f;->b(Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->b(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-ne p0, p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v1
.end method

.method public static m(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v1, "mr.a"

    const-string v1, ".rma"

    const-string/jumbo v1, "rma."

    const-string v1, ".amr"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "mp3."

    const-string/jumbo v0, "mp.3"

    const/4 v3, 0x7

    const-string v0, ".mp3"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v2, 0x5

    move v3, v2

    return p0
.end method

.method public static n(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, ".igf"

    const-string v0, "gf.i"

    const/4 v2, 0x0

    const-string v0, "fi.g"

    const-string v0, ".gif"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p0
.end method

.method public static o(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const-string v1, "g.jp"

    const-string/jumbo v1, "pg.j"

    const-string/jumbo v1, "j.gp"

    const-string v1, ".jpg"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "bgu.e"

    const-string v1, ".ugpe"

    const/4 v3, 0x4

    const-string/jumbo v1, "pujge"

    const-string v1, ".jpeg"

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "g.np"

    const-string v1, ".gpn"

    const/4 v3, 0x5

    const-string/jumbo v1, "ngp."

    const-string v1, ".png"

    const/4 v2, 0x1

    and-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v0, ".hpip"

    const-string v0, ".ephi"

    const/4 v3, 0x0

    const-string/jumbo v0, "iecqh"

    const-string v0, ".heic"

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p0
.end method

.method public static p(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "4pm."

    const-string v0, ".mp4"

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p0
.end method

.method public static q(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "wps.q"

    const-string v0, "e.wqp"

    const/4 v2, 0x5

    const-string v0, "ep.mw"

    const-string v0, ".webp"

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p0
.end method

.method public static r()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "d3e/ogpoi"

    const-string/jumbo v0, "video/3gp"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static s()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "iov/ibdva"

    const-string/jumbo v0, "vdsoiiva/"

    const/4 v2, 0x2

    const-string/jumbo v0, "video/avi"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public static t()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const-string/jumbo v0, "m/ipgmume"

    const-string v0, "eg/mmpmbi"

    const/4 v2, 0x0

    const-string v0, "a/ibegmpm"

    const-string/jumbo v0, "image/bmp"

    const/4 v1, 0x4

    or-int/2addr v2, v1

    return-object v0
.end method

.method public static u()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, "gmoai/ifq"

    const-string v0, "gmafoi/ig"

    const/4 v2, 0x3

    const-string v0, "egs/miagf"

    const-string/jumbo v0, "image/gif"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static v()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "giemm/pbej"

    const-string/jumbo v0, "pgmeebji/g"

    const/4 v2, 0x3

    const-string v0, "gj/poegiem"

    const-string/jumbo v0, "image/jpeg"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public static w()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "ve4mobp/u"

    const-string v0, "/pov4eudm"

    const/4 v2, 0x6

    const-string v0, "i4e/dpuov"

    const-string/jumbo v0, "video/mp4"

    const/4 v2, 0x2

    return-object v0
.end method

.method public static x()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "peidpe/pmv"

    const-string/jumbo v0, "p/evmeipgd"

    const/4 v2, 0x1

    const-string/jumbo v0, "pg/ieomeqv"

    const-string/jumbo v0, "video/mpeg"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static y()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "gqs/inemg"

    const-string/jumbo v0, "mggpi/neq"

    const/4 v2, 0x6

    const-string v0, "gnem/aipg"

    const-string/jumbo v0, "image/png"

    const/4 v2, 0x7

    return-object v0
.end method

.method public static z()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "meweosbga/"

    const-string v0, "eeswmabi/g"

    const/4 v2, 0x0

    const-string/jumbo v0, "wmeipb/age"

    const-string/jumbo v0, "image/webp"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method
