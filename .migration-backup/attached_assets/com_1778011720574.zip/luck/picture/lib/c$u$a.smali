.class Lcom/luck/picture/lib/c$u$a;
.super Ls6/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c$u;->a(ILcom/luck/picture/lib/entity/LocalMediaFolder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ls6/o<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c$u;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c$u;)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    iput-object p1, p0, Lcom/luck/picture/lib/c$u$a;->a:Lcom/luck/picture/lib/c$u;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ls6/o;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Ljava/util/ArrayList;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c$u$a;->a:Lcom/luck/picture/lib/c$u;

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, v0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1, p2}, Lcom/luck/picture/lib/c;->i1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method
