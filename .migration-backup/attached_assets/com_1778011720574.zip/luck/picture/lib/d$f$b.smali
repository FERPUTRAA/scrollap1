.class Lcom/luck/picture/lib/d$f$b;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d$f;->clearView(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$g0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d$f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d$f;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/d$f$b;->a:Lcom/luck/picture/lib/d$f;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~ @@@~l@@~r@bl nui@ ~@ooKo/io~ i@cs~-@1~bf @v@ ~ta/~~~M @4~Sm  @~ ~tb ~.@fyo~@@o~d@   ~@@ ~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/d$f$b;->a:Lcom/luck/picture/lib/d$f;

    const/4 v1, 0x2

    const/4 v1, 0x3

    iget-object p1, p1, Lcom/luck/picture/lib/d$f;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean v0, p1, Lcom/luck/picture/lib/d;->J:Z

    const/4 v2, 0x1

    return-void
.end method
