.class Lcom/luck/picture/lib/magical/MagicalView$f;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/magical/MagicalView;->y(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Lcom/luck/picture/lib/magical/MagicalView;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/magical/MagicalView;Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->b:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-boolean p2, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->a:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "scs  @ @@  @@~@/K@a/o~ ~f~~~il ibi~~@o@~rb@n@ ~S~ lyt ~-v~o@~b@  @@ t.~d ~@~ ~~~oo@~f4@M1o m~@@u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->b:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-static {p1, v0}, Lcom/luck/picture/lib/magical/MagicalView;->h(Lcom/luck/picture/lib/magical/MagicalView;Z)Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget-boolean p1, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->a:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->b:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    move v2, v1

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$f;->b:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/luck/picture/lib/magical/c;->e()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method
