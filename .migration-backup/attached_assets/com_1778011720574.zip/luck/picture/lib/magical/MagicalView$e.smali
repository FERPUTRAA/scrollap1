.class Lcom/luck/picture/lib/magical/MagicalView$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/magical/MagicalView;->y(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/magical/MagicalView;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/magical/MagicalView;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s~K@b~~ f@M@b @@m/~ @~4~~Sis ~@c  @~ro@lo~i    no1-o@a~@df. ~ @ ~o~~~~@@ @~ /@uivt @~bo~~l@yt@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->h(Lcom/luck/picture/lib/magical/MagicalView;Z)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lcom/luck/picture/lib/magical/MagicalView;->j(Lcom/luck/picture/lib/magical/MagicalView;F)F

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->k(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->i(Lcom/luck/picture/lib/magical/MagicalView;)F

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$e;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x0

    move v3, v2

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->i(Lcom/luck/picture/lib/magical/MagicalView;)F

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/magical/c;->a(F)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method
