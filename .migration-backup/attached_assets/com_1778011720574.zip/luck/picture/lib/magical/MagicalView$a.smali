.class Lcom/luck/picture/lib/magical/MagicalView$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/magical/MagicalView;->x(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/magical/MagicalView;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/magical/MagicalView;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@@s@~@ r@ ~~~i  /b~t~ilb@S~c~m~~~ @u-@@~M 1f i@ .~  @@ o ~o~@fs~v@o ~lo@~d~~a4/o@K@@y@n~ot   @b "

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x2

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    check-cast p1, Ljava/lang/Float;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x1

    move v11, v10

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->a(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    int-to-float v2, p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->b(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    int-to-float v3, p1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->l(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    int-to-float v4, p1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->m(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    int-to-float v5, p1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->n(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    int-to-float v6, p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->o(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    int-to-float v7, p1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->p(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    int-to-float v8, p1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$a;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->q(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result p1

    const/4 v11, 0x0

    int-to-float v9, p1

    const/4 v10, 0x5

    and-int/2addr v11, v10

    invoke-static/range {v0 .. v9}, Lcom/luck/picture/lib/magical/MagicalView;->r(Lcom/luck/picture/lib/magical/MagicalView;FFFFFFFFF)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    return-void
.end method
