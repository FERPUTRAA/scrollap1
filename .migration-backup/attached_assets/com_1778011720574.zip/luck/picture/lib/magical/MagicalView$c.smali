.class Lcom/luck/picture/lib/magical/MagicalView$c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/magical/MagicalView;->u()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/magical/MagicalView;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/magical/MagicalView;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ sit nM~@oiofb~ m~~ 4s~i~@S1 ~ @~@~f~~ @b~~@o ~@o-~a@@  ~/od @  @@@~@c~lu @b~~ @ @K/vy@lr t@@.o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->c(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/widget/FrameLayout;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v5, 0x2

    new-instance v1, Landroid/transition/TransitionSet;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1}, Landroid/transition/TransitionSet;-><init>()V

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-wide/16 v2, 0xfa

    const/4 v5, 0x0

    const-wide/16 v2, 0xfa

    const-wide/16 v2, 0xfa

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/transition/TransitionSet;->setDuration(J)Landroid/transition/TransitionSet;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v2, Landroid/transition/ChangeBounds;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v2}, Landroid/transition/ChangeBounds;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Landroid/transition/TransitionSet;->addTransition(Landroid/transition/Transition;)Landroid/transition/TransitionSet;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v2, Landroid/transition/ChangeTransform;

    invoke-direct {v2}, Landroid/transition/ChangeTransform;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/transition/TransitionSet;->addTransition(Landroid/transition/Transition;)Landroid/transition/TransitionSet;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v2, Landroid/transition/ChangeImageTransform;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2}, Landroid/transition/ChangeImageTransform;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/transition/TransitionSet;->addTransition(Landroid/transition/Transition;)Landroid/transition/TransitionSet;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1}, Landroid/transition/TransitionManager;->beginDelayedTransition(Landroid/view/ViewGroup;Landroid/transition/Transition;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->d(Lcom/luck/picture/lib/magical/MagicalView;Z)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->c(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/widget/FrameLayout;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Landroid/view/View;->setTranslationX(F)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->c(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/widget/FrameLayout;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroid/view/View;->setTranslationY(F)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->e(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/magical/MagicalView;->n(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    int-to-float v2, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->e(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/magical/MagicalView;->p(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-float v2, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/magical/b;->g(F)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->e(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/b;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/magical/MagicalView;->a(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/magical/b;->k(I)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/magical/MagicalView;->e(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/b;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/magical/MagicalView;->l(Lcom/luck/picture/lib/magical/MagicalView;)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/magical/b;->i(I)V

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView$c;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->f(Lcom/luck/picture/lib/magical/MagicalView;Z)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    return-void
.end method
