.class public Lcom/luck/picture/lib/magical/MagicalView;
.super Landroid/widget/FrameLayout;


# instance fields
.field private a:F

.field private final b:J

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private final i:I

.field private j:I

.field private k:I

.field private l:I

.field private m:I

.field private n:I

.field private o:I

.field private p:Z

.field private final q:Landroid/widget/FrameLayout;

.field private final r:Landroid/view/View;

.field private final s:Lcom/luck/picture/lib/magical/b;

.field private final t:Z

.field private u:I

.field private v:I

.field private w:Lcom/luck/picture/lib/magical/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x5

    or-int/2addr v2, v1

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/magical/MagicalView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Lcom/luck/picture/lib/magical/MagicalView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 p2, 0x0

    move v2, p2

    const/4 v1, 0x6

    move v2, v1

    iput p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-wide/16 p2, 0xfa

    const-wide/16 p2, 0xfa

    const/4 v2, 0x2

    const-wide/16 p2, 0xfa

    const-wide/16 p2, 0xfa

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-wide p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->b:J

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p2, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->p:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-boolean p2, p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->t:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/luck/picture/lib/utils/e;->e(Landroid/content/Context;)I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->i:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->getScreenSize()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p2, Landroid/view/View;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p2, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p3, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p2, p3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget p3, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p2, p3}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p2, Landroid/widget/FrameLayout;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p2, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v2, 0x6

    const/4 v1, 0x5

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance p1, Lcom/luck/picture/lib/magical/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-direct {p1, p2}, Lcom/luck/picture/lib/magical/b;-><init>(Landroid/view/View;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private D()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " Ksf~~~ boo@~1c~@@ o r~@n@fS ~lb  tm~ u~i@l/sd ~o4a~o.~@ @~v @~@~~ @iM@  /@~@@ytb@~ @~ i~~@o- ~@"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    const/4 v0, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-array v1, v0, [I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->m:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->g:I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    int-to-float v3, v2

    const/4 v9, 0x0

    xor-int/2addr v10, v9

    iget v4, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    int-to-float v5, v4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    div-float/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget v5, p0, Lcom/luck/picture/lib/magical/MagicalView;->n:I

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    int-to-float v6, v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget v7, p0, Lcom/luck/picture/lib/magical/MagicalView;->o:I

    const/4 v10, 0x3

    int-to-float v8, v7

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    div-float/2addr v6, v8

    const/4 v10, 0x7

    const/4 v9, 0x7

    cmpg-float v3, v3, v6

    const/4 v10, 0x1

    if-gez v3, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    iput v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v9, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    int-to-float v1, v2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    int-to-float v2, v7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    int-to-float v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    div-float/2addr v2, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    mul-float/2addr v1, v2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    float-to-int v1, v1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v10, 0x7

    sub-int/2addr v4, v1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    div-int/2addr v4, v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    iput v4, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput v4, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    int-to-float v3, v4

    const/4 v10, 0x1

    const/4 v9, 0x3

    int-to-float v4, v5

    const/4 v9, 0x7

    and-int/2addr v10, v9

    int-to-float v5, v7

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    div-float/2addr v4, v5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    mul-float/2addr v3, v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    float-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput v3, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v9, 0x0

    and-int/2addr v10, v9

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    sub-int/2addr v2, v3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    div-int/2addr v2, v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    iput v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->m:I

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->f:I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    int-to-float v1, v1

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->e:I

    const/4 v9, 0x2

    and-int/2addr v10, v9

    int-to-float v1, v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->g(F)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v10, 0x4

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->c:I

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->i(I)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->d:I

    const/4 v9, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->k(I)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    return-void
.end method

.method private E()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->p:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->z()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->w:Lcom/luck/picture/lib/magical/c;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v1, p0, v0}, Lcom/luck/picture/lib/magical/c;->d(Lcom/luck/picture/lib/magical/MagicalView;Z)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private G(FFFF)V
    .locals 11

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move v4, p1

    move v4, p1

    move v4, p1

    move v4, p1

    move v6, p2

    move v6, p2

    move v6, p2

    move v6, p2

    move v8, p3

    move v8, p3

    move v8, p3

    move v10, p4

    move v10, p4

    move v10, p4

    move v10, p4

    invoke-direct/range {v0 .. v10}, Lcom/luck/picture/lib/magical/MagicalView;->I(ZFFFFFFFFF)V

    return-void
.end method

.method private H(FFFFFFFFF)V
    .locals 11

    const/4 v1, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move v4, p3

    move v4, p3

    move v4, p3

    move v4, p3

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    move/from16 v6, p5

    move/from16 v6, p5

    move/from16 v6, p5

    move/from16 v6, p5

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v8, p7

    move/from16 v8, p7

    move/from16 v9, p8

    move/from16 v9, p8

    move/from16 v9, p8

    move/from16 v9, p8

    move/from16 v10, p9

    move/from16 v10, p9

    move/from16 v10, p9

    move/from16 v10, p9

    invoke-direct/range {v0 .. v10}, Lcom/luck/picture/lib/magical/MagicalView;->I(ZFFFFFFFFF)V

    return-void
.end method

.method private I(ZFFFFFFFFF)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p8}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p10}, Lcom/luck/picture/lib/magical/b;->g(F)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    float-to-int p2, p6

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/b;->i(I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    float-to-int p2, p4

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/b;->k(I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    sub-float/2addr p6, p5

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    mul-float/2addr p6, p2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    sub-float/2addr p8, p7

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    mul-float/2addr p8, p2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    sub-float/2addr p10, p9

    const/4 v1, 0x5

    mul-float/2addr p10, p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    sub-float/2addr p4, p3

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    mul-float/2addr p2, p4

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    add-float/2addr p7, p8

    const/4 v1, 0x4

    invoke-virtual {p1, p7}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    add-float/2addr p9, p10

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1, p9}, Lcom/luck/picture/lib/magical/b;->g(F)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    add-float/2addr p5, p6

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    float-to-int p4, p5

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1, p4}, Lcom/luck/picture/lib/magical/b;->i(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    add-float/2addr p3, p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    float-to-int p2, p3

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/b;->k(I)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic b(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic c(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/widget/FrameLayout;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic d(Lcom/luck/picture/lib/magical/MagicalView;Z)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/magical/MagicalView;->w(Z)V

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic e(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/b;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic f(Lcom/luck/picture/lib/magical/MagicalView;Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/magical/MagicalView;->y(Z)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-void
.end method

.method static synthetic g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->w:Lcom/luck/picture/lib/magical/c;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method private getScreenSize()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->f(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->g:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->t:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->h(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic h(Lcom/luck/picture/lib/magical/MagicalView;Z)Z
    .locals 2

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->p:Z

    const/4 v0, 0x7

    const/4 v0, 0x6

    return p1
.end method

.method static synthetic i(Lcom/luck/picture/lib/magical/MagicalView;)F
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic j(Lcom/luck/picture/lib/magical/MagicalView;F)F
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic k(Lcom/luck/picture/lib/magical/MagicalView;)Landroid/view/View;
    .locals 2

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic l(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic m(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->m:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    return p0
.end method

.method static synthetic n(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->f:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic o(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x1

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic p(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    return p0
.end method

.method static synthetic q(Lcom/luck/picture/lib/magical/MagicalView;)I
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p0, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic r(Lcom/luck/picture/lib/magical/MagicalView;FFFFFFFFF)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct/range {p0 .. p9}, Lcom/luck/picture/lib/magical/MagicalView;->H(FFFFFFFFF)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic s(Lcom/luck/picture/lib/magical/MagicalView;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->E()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method private u()V
    .locals 4
    .annotation build Landroidx/annotation/w0;
        api = 0x15
    .end annotation

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v1, Lcom/luck/picture/lib/magical/MagicalView$c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/magical/MagicalView$c;-><init>(Lcom/luck/picture/lib/magical/MagicalView;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method private v()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-wide/16 v2, 0xfa

    const-wide/16 v2, 0xfa

    const/4 v6, 0x3

    const-wide/16 v2, 0xfa

    const-wide/16 v2, 0xfa

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v4, Lcom/luck/picture/lib/magical/MagicalView$d;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v4, p0}, Lcom/luck/picture/lib/magical/MagicalView$d;-><init>(Lcom/luck/picture/lib/magical/MagicalView;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, v4}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    return-void
.end method

.method private w(Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->w:Lcom/luck/picture/lib/magical/c;

    const/4 v2, 0x3

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/magical/c;->c(Z)V

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private x(Z)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x0

    or-int/2addr v4, v3

    iget p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    int-to-float p1, p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->m:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    int-to-float v0, v0

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    int-to-float v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    int-to-float v2, v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/luck/picture/lib/magical/MagicalView;->G(FFFF)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->E()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 p1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x3

    new-array p1, p1, [F

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    fill-array-data p1, :array_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/luck/picture/lib/magical/MagicalView$a;

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/magical/MagicalView$a;-><init>(Lcom/luck/picture/lib/magical/MagicalView;)V

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Lcom/luck/picture/lib/magical/MagicalView$b;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/magical/MagicalView$b;-><init>(Lcom/luck/picture/lib/magical/MagicalView;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v3, 0x0

    move v4, v3

    const-wide/16 v0, 0xfa

    const/4 v4, 0x0

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/magical/MagicalView;->y(Z)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private y(Z)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    :goto_0
    const/4 v5, 0x4

    const/4 v1, 0x5

    const/4 v5, 0x5

    const/4 v1, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-array v1, v1, [F

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x0

    shl-int/2addr v5, v2

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v3, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    aput v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    aput v0, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Lcom/luck/picture/lib/magical/MagicalView$e;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/magical/MagicalView$e;-><init>(Lcom/luck/picture/lib/magical/MagicalView;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Lcom/luck/picture/lib/magical/MagicalView$f;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v1, p0, p1}, Lcom/luck/picture/lib/magical/MagicalView$f;-><init>(Lcom/luck/picture/lib/magical/MagicalView;Z)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const-wide/16 v1, 0xfa

    const-wide/16 v1, 0xfa

    const/4 v5, 0x5

    const-wide/16 v1, 0xfa

    const-wide/16 v1, 0xfa

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    const/4 v5, 0x1

    return-void
.end method

.method private z()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v4, 0x5

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v4, 0x7

    const/4 v3, 0x2

    int-to-float v0, v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v2, v0}, Lcom/luck/picture/lib/magical/b;->g(F)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v2, p0, Lcom/luck/picture/lib/magical/MagicalView;->g:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    int-to-float v2, v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->k(I)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/b;->i(I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method


# virtual methods
.method public A(IIZ)V
    .locals 4

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->t:Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->g:I

    const/4 v3, 0x0

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-le v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    int-to-float p1, p1

    const/4 v3, 0x1

    int-to-float p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    div-float/2addr p1, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    int-to-float p2, v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    div-float/2addr p2, p1

    const/4 v2, 0x4

    move v3, v2

    float-to-int p1, p2

    const/4 v2, 0x7

    or-int/2addr v3, v2

    if-le p1, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->i:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p3, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    int-to-float p2, v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/b;->l(F)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->s:Lcom/luck/picture/lib/magical/b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    iget p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->h:I

    const/4 v3, 0x0

    int-to-float p2, p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/b;->g(F)V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method public B()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->getScreenSize()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/magical/MagicalView;->J(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public C(IIZ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->getScreenSize()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/luck/picture/lib/magical/MagicalView;->K(IIZ)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-void
.end method

.method public F(IIIIII)V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    iput p5, p0, Lcom/luck/picture/lib/magical/MagicalView;->n:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p6, p0, Lcom/luck/picture/lib/magical/MagicalView;->o:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p3, p0, Lcom/luck/picture/lib/magical/MagicalView;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p4, p0, Lcom/luck/picture/lib/magical/MagicalView;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public J(Z)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x2

    move v3, v2

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v2, 0x6

    move v3, v2

    iget-object v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->D()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/magical/MagicalView;->x(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public K(IIZ)V
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->n:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->o:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->d:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->f:I

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->D()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->j:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-float p1, p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->m:I

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    int-to-float p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->k:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    int-to-float v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->l:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    int-to-float v1, v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->G(FFFF)V

    const/4 v3, 0x2

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p3, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2, p1}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p2, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p3, p2}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p3, p2}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2}, Landroid/view/ViewPropertyAnimator;->start()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->E()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    instance-of v1, v0, Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast v0, Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x1

    if-eq v1, v2, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eq v1, v3, :cond_1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v1, v3, :cond_3

    const/4 v5, 0x0

    move v6, v5

    goto/16 :goto_1

    :cond_1
    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    float-to-int v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    float-to-int v3, v3

    const/4 v5, 0x4

    const/4 v5, 0x2

    iget v4, p0, Lcom/luck/picture/lib/magical/MagicalView;->u:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    sub-int/2addr v1, v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v4, p0, Lcom/luck/picture/lib/magical/MagicalView;->v:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    sub-int v4, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-le v1, v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v0, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->setUserInputEnabled(Z)V

    goto :goto_1

    :cond_2
    const/4 v5, 0x0

    move v6, v5

    if-eqz v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->v:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    sub-int/2addr v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->setUserInputEnabled(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->setUserInputEnabled(Z)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_1

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    float-to-int v1, v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->u:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    float-to-int v1, v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput v1, p0, Lcom/luck/picture/lib/magical/MagicalView;->v:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v0, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->setUserInputEnabled(Z)V

    :cond_5
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    return p1
.end method

.method public setBackgroundAlpha(F)V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->a:F

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setBackgroundColor(I)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->r:Landroid/view/View;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setMagicalContent(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->q:Landroid/widget/FrameLayout;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setOnMojitoViewCallback(Lcom/luck/picture/lib/magical/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView;->w:Lcom/luck/picture/lib/magical/c;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public t()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->p:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->f:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    if-eqz v0, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->e:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/magical/MagicalView;->w:Lcom/luck/picture/lib/magical/c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/luck/picture/lib/magical/c;->b()V

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/magical/MagicalView;->w(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->u()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void

    :cond_3
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/magical/MagicalView;->v()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method
