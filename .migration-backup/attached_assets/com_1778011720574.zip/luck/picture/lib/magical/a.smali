.class public Lcom/luck/picture/lib/magical/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/magical/ViewParams;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Lcom/luck/picture/lib/magical/a;->a:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, ".ys@~ ~c~f @/toS ~~oia@l@M@4o  @Kb-@~~@d@~  ~ ~~o/~r~~ @ o@t b~@m ~@ni ~@@ ~ vs@lfu~ ~bi@~1~o@ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lcom/luck/picture/lib/magical/a;->a:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-lez v1, :cond_0

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->clear()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method private static b(Ljava/util/List;III)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;III)V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-lez p2, :cond_0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-lt p2, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p0, v2, v0}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    add-int/lit8 p2, p2, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-ge p3, p1, :cond_1

    const/4 v4, 0x3

    sub-int/2addr p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    sub-int/2addr p1, p3

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-lt p1, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public static c(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    const/4 v7, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ge v3, v1, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    check-cast p0, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez p0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$p;->getItemCount()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-le p0, v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    add-int/lit8 p0, v1, -0x1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v0, v1, v3, p0}, Lcom/luck/picture/lib/magical/a;->b(Ljava/util/List;III)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    sget-object p0, Lcom/luck/picture/lib/magical/a;->a:Ljava/util/List;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {p0}, Ljava/util/List;->clear()V

    const/4 v7, 0x7

    move p0, v2

    move p0, v2

    move p0, v2

    move p0, v2

    :goto_2
    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-ge p0, v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    check-cast v1, Landroid/view/View;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v3, Lcom/luck/picture/lib/magical/ViewParams;

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-direct {v3}, Lcom/luck/picture/lib/magical/ViewParams;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-nez v1, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Lcom/luck/picture/lib/magical/ViewParams;->d(I)V

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v3, v2}, Lcom/luck/picture/lib/magical/ViewParams;->e(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v3, v2}, Lcom/luck/picture/lib/magical/ViewParams;->Y1(I)V

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {v3, v2}, Lcom/luck/picture/lib/magical/ViewParams;->U1(I)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_3

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v4, 0x2

    const/4 v7, 0x4

    const/4 v6, 0x4

    new-array v4, v4, [I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    aget v5, v4, v2

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v3, v5}, Lcom/luck/picture/lib/magical/ViewParams;->d(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v5, 0x1

    shl-int/2addr v7, v5

    const/4 v6, 0x7

    xor-int/2addr v7, v6

    aget v4, v4, v5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    sub-int/2addr v4, p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/magical/ViewParams;->e(I)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/magical/ViewParams;->Y1(I)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/magical/ViewParams;->U1(I)V

    :goto_3
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object v1, Lcom/luck/picture/lib/magical/a;->a:Ljava/util/List;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    add-int/lit8 p0, p0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto/16 :goto_2

    :cond_5
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method public static d(I)Lcom/luck/picture/lib/magical/ViewParams;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lcom/luck/picture/lib/magical/a;->a:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-le v1, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast p0, Lcom/luck/picture/lib/magical/ViewParams;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x7

    return-object p0
.end method
