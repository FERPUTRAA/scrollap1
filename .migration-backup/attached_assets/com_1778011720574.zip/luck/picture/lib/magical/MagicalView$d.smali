.class Lcom/luck/picture/lib/magical/MagicalView$d;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/magical/MagicalView;->v()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/magical/MagicalView;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/magical/MagicalView;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$d;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b~so~ @   n@m~@so ~~@@ tl~ ~~ -~@@/o@yoci @ @  d.~~M v/l1bb4u@@@ @@t~~ of~ i@~i~a~~K@@~@S~o@r~f~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$d;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/magical/MagicalView$d;->a:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/magical/MagicalView;->g(Lcom/luck/picture/lib/magical/MagicalView;)Lcom/luck/picture/lib/magical/c;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-interface {p1}, Lcom/luck/picture/lib/magical/c;->e()V

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method
