.class public Lcom/luck/picture/lib/magical/b;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/view/ViewGroup$MarginLayoutParams;

.field private final b:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    check-cast p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const v0, 0x800003

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput v0, p1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c s @ ~o~@dtb b-@~.@o ~~@~1~i~u~f~   r ~/l~ao@@@@ ~ o@@o@@@l4@~ot~ ~@~@ms @vnM~ ~ fi~@Sib @/Ky ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x2

    const/4 v1, 0x4

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x1

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public g(F)V
    .locals 3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public h(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public i(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x5

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public j(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public k(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public l(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/magical/b;->b:Landroid/view/View;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/magical/b;->a:Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    return-void
.end method
