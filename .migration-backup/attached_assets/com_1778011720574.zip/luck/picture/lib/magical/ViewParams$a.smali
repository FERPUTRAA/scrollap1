.class Lcom/luck/picture/lib/magical/ViewParams$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/magical/ViewParams;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/luck/picture/lib/magical/ViewParams;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/luck/picture/lib/magical/ViewParams;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f@s@~f@~o@@K~@~i~n@ d.~m @~r-~@  1St~o~ ~@~  / @al yo ~Mt@b@bo ~@io/@~@~ is~@v~c @~~l@  ~4@ou b~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    new-instance v0, Lcom/luck/picture/lib/magical/ViewParams;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lcom/luck/picture/lib/magical/ViewParams;-><init>(Landroid/os/Parcel;)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public b(I)[Lcom/luck/picture/lib/magical/ViewParams;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    new-array p1, p1, [Lcom/luck/picture/lib/magical/ViewParams;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/magical/ViewParams$a;->a(Landroid/os/Parcel;)Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/magical/ViewParams$a;->b(I)[Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method
