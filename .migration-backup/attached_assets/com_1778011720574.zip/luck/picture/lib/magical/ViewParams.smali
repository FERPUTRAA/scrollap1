.class public Lcom/luck/picture/lib/magical/ViewParams;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/magical/ViewParams;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/magical/ViewParams$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/luck/picture/lib/magical/ViewParams$a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Lcom/luck/picture/lib/magical/ViewParams;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput p1, p0, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method


# virtual methods
.method public U1(I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s crn atd~@ Mv~~@@ bs~~lf@@f@b@@ t~il /~~@ o@~~ m@u@o1~ @ @ .o/S@o-K y~@ ~~~~4o@b ~~@  i~~~@ i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public Y1(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput p1, p0, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public a()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public d(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public e(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public f()I
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p2, p0, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
