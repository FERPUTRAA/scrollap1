.class public Lcom/luck/picture/lib/c;
.super Lcom/luck/picture/lib/basic/e;

# interfaces
.implements Ls6/r;
.implements Lcom/luck/picture/lib/basic/d;


# static fields
.field public static final A:Ljava/lang/String; = "c"

.field private static final B:I = 0x87

.field private static final C:Ljava/lang/Object;


# instance fields
.field private l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

.field private m:Landroid/widget/TextView;

.field private n:Lcom/luck/picture/lib/widget/TitleBar;

.field private o:Lcom/luck/picture/lib/widget/BottomNavBar;

.field private p:Lcom/luck/picture/lib/widget/CompleteSelectView;

.field private q:Landroid/widget/TextView;

.field private r:J

.field private s:I

.field private t:I

.field private u:Z

.field private v:Z

.field private w:Z

.field private x:Lcom/luck/picture/lib/adapter/b;

.field private y:Lcom/luck/picture/lib/dialog/a;

.field private z:Lcom/luck/picture/lib/widget/a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object v0, Lcom/luck/picture/lib/c;->C:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/e;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/luck/picture/lib/c;->r:J

    const/4 v3, 0x3

    const/4 v0, -0x5

    const/4 v3, 0x1

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput v0, p0, Lcom/luck/picture/lib/c;->t:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic A1(Lcom/luck/picture/lib/c;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tos~~ -libo~@i vl~b@@@~ ~  ~SM~ o@ftK1~@@u  ~n~@o@@~~c b@@i @ /~~r4@~/ a~  ~o@~ @o m.@~ @sy@~@df"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->n2()V

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic B1(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->o2()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic C1(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->V1()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic D1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->m2(Ljava/util/ArrayList;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic E1(Lcom/luck/picture/lib/c;Ljava/util/List;Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/c;->S1(Ljava/util/List;Z)V

    return-void
.end method

.method static synthetic F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;
    .locals 2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v0, 0x1

    move v1, v0

    return-object p0
.end method

.method static synthetic G1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/dialog/a;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic H1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic I1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/TitleBar;
    .locals 2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic J1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v0, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic K1(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->N1()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private L1()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v1, Lcom/luck/picture/lib/c$u;

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$u;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/dialog/a;->k(Ls6/a;)V

    return-void
.end method

.method private M1()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Lcom/luck/picture/lib/c$g;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$g;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/b;->k(Lcom/luck/picture/lib/adapter/b$b;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Lcom/luck/picture/lib/c$h;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$h;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setOnRecyclerViewScrollStateListener(Ls6/t;)V

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v4, 0x3

    const/4 v3, 0x5

    new-instance v1, Lcom/luck/picture/lib/c$i;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$i;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setOnRecyclerViewScrollListener(Ls6/s;)V

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x4

    move v4, v3

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Ljava/util/HashSet;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v4, 0x6

    new-instance v1, Lcom/luck/picture/lib/widget/b;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v2, Lcom/luck/picture/lib/c$j;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v2, p0, v0}, Lcom/luck/picture/lib/c$j;-><init>(Lcom/luck/picture/lib/c;Ljava/util/HashSet;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Lcom/luck/picture/lib/widget/b;-><init>(Lcom/luck/picture/lib/widget/b$a;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lcom/luck/picture/lib/widget/a;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/widget/a;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v2}, Lcom/luck/picture/lib/adapter/b;->e()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/widget/a;->n(I)Lcom/luck/picture/lib/widget/a;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/a;->v(Lcom/luck/picture/lib/widget/a$c;)Lcom/luck/picture/lib/widget/a;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/c;->z:Lcom/luck/picture/lib/widget/a;

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->addOnItemTouchListener(Landroidx/recyclerview/widget/RecyclerView$t;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method private N1()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->T()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->u()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method private O1(Z)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D0:Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_6

    const/4 v5, 0x0

    iget-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O:Z

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-ne v0, v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq v0, v1, :cond_5

    const/4 v5, 0x5

    if-nez p1, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    sub-int/2addr v0, v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne p1, v0, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne v0, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->p()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    move v5, v4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-lez v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq v0, v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez p1, :cond_6

    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    sub-int/2addr v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ne p1, v1, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v0, v1, :cond_5

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez p1, :cond_6

    const/4 v5, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x0

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    sub-int/2addr v0, v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne p1, v0, :cond_6

    :cond_5
    :goto_1
    const/4 v5, 0x2

    move v2, v3

    move v2, v3

    :cond_6
    :goto_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    return v2
.end method

.method private P1(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-lez v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Lcom/luck/picture/lib/dialog/a;->c(Ljava/util/List;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/c;->O(J)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    goto :goto_1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->p2()V

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method private Q1(Ljava/util/ArrayList;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b()Z

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x0

    if-eqz p2, :cond_1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->A()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private R1(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    new-instance v2, Ljava/io/File;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v2, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v2, v0}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    const/4 v4, 0x7

    goto :goto_2

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->p2()V

    :cond_3
    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method private S1(Ljava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b()Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p2, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->j2(Ljava/util/List;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lez p2, :cond_1

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->getItemCount()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p2, v1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemRangeChanged(II)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->A()V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 p2, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ge p1, p2, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getScrollX()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1, p2, v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->onScrolled(II)V

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method private T1(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-lez v0, :cond_3

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Lcom/luck/picture/lib/dialog/a;->c(Ljava/util/List;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->l()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/c;->Q1(Ljava/util/ArrayList;Z)V

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_1

    :cond_3
    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->p2()V

    :goto_1
    const/4 v4, 0x6

    return-void
.end method

.method private U1(Ljava/util/ArrayList;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, p2, p2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->onScrolled(II)V

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->smoothScrollToPosition(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method private V1()V
    .locals 5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-lez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->q:Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-wide/16 v1, 0xfa

    const/4 v4, 0x4

    const-wide/16 v1, 0xfa

    const-wide/16 v1, 0xfa

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method static synthetic W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method private W1()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v2, 0x4

    move v3, v2

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic X0(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method private X1()V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/dialog/a;->d(Landroid/content/Context;)Lcom/luck/picture/lib/dialog/a;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v2, 0x6

    move v3, v2

    new-instance v1, Lcom/luck/picture/lib/c$r;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$r;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v2, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/dialog/a;->l(Lcom/luck/picture/lib/dialog/a$d;)V

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->L1()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic Y0(Lcom/luck/picture/lib/c;)Z
    .locals 2

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method

.method private Y1()V
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->f()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Lcom/luck/picture/lib/c$v;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$v;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/BottomNavBar;->setOnBottomNavBarListener(Lcom/luck/picture/lib/widget/BottomNavBar$b;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->h()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic Z0(Lcom/luck/picture/lib/c;Z)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method private Z1()V
    .locals 6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x3

    xor-int/2addr v4, v3

    if-ne v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->d()Lcom/luck/picture/lib/style/TitleBarStyle;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v3}, Lcom/luck/picture/lib/style/TitleBarStyle;->D(Z)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/TitleBar;->getTitleCancelView()Landroid/widget/TextView;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/16 v1, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/CompleteSelectView;->c()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v3}, Lcom/luck/picture/lib/widget/CompleteSelectView;->setSelectedChange(Z)V

    const/4 v5, 0x0

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->d0()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    instance-of v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget v1, Lcom/luck/picture/lib/R$id;->title_bar:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v5, 0x6

    iput v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    move v5, v4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    instance-of v0, v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v1, v0, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    :cond_2
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v1, Lcom/luck/picture/lib/c$p;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$p;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void
.end method

.method static synthetic a1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic b1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method private b2(Landroid/view/View;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget v0, Lcom/luck/picture/lib/R$id;->recycler:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->F()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget v3, Lcom/luck/picture/lib/R$color;->ps_color_black:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v2, v3}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x2

    move v6, v5

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->w:I

    const/4 v5, 0x7

    move v6, v5

    if-gtz v1, :cond_1

    const/4 v6, 0x5

    const/4 v1, 0x4

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getItemDecorationCount()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->s()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v2, Lp6/a;

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->s()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->c0()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v2, v1, v3, v0}, Lp6/a;-><init>(IIZ)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$o;)V

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v3, Lp6/a;

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1, v4}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->c0()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v3, v1, p1, v0}, Lp6/a;-><init>(IIZ)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$o;)V

    :cond_3
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v0, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v0, v2, v1}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;I)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getItemAnimator()Landroidx/recyclerview/widget/RecyclerView$m;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast p1, Landroidx/recyclerview/widget/e0;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/e0;->Y(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x3

    xor-int/2addr v5, v0

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$m;)V

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v0, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setReachBottomRow(I)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1, p0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setOnRecyclerViewPreloadListener(Ls6/r;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    goto :goto_2

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    :goto_2
    const/4 v5, 0x3

    move v6, v5

    new-instance p1, Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {p1, v2, v3}, Lcom/luck/picture/lib/adapter/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-boolean v2, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, v2}, Lcom/luck/picture/lib/adapter/b;->j(Z)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x4

    move v6, v5

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E0:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq p1, v1, :cond_7

    const/4 v6, 0x0

    if-eq p1, v0, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    goto :goto_3

    :cond_6
    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-instance v0, Lcom/luck/picture/lib/animators/d;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v0, v1}, Lcom/luck/picture/lib/animators/d;-><init>(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_3

    :cond_7
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v0, Lcom/luck/picture/lib/animators/a;

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Lcom/luck/picture/lib/animators/a;-><init>(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    :goto_3
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->M1()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method static synthetic c1(Lcom/luck/picture/lib/c;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget p0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method private c2()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->d()Lcom/luck/picture/lib/style/TitleBarStyle;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->A()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x8

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/TitleBar;->d()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v1, Lcom/luck/picture/lib/c$q;

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$q;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/TitleBar;->setOnTitleBarListener(Lcom/luck/picture/lib/widget/TitleBar$a;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic d1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method private d2(I)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, p0, Lcom/luck/picture/lib/c;->s:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-lez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ge v1, p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method static synthetic e1(Lcom/luck/picture/lib/c;I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method private e2(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 12

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/dialog/a;->f()Ljava/util/List;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/dialog/a;->i()I

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v11, 0x6

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v4, 0x0

    move v11, v4

    const/4 v10, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez v1, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x6

    new-instance v1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object v5, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v5, v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-ne v5, v6, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget v5, Lcom/luck/picture/lib/R$string;->ps_all_audio:I

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    goto :goto_0

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    sget v5, Lcom/luck/picture/lib/R$string;->ps_camera_roll:I

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->v(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v5, ""

    const-string v5, ""

    const/4 v11, 0x1

    const-string v5, ""

    const-string v5, ""

    const/4 v11, 0x7

    const/4 v10, 0x0

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    const/4 v11, 0x7

    invoke-virtual {v1, v2, v3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->o(J)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-interface {v0, v4, v1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    const/4 v11, 0x5

    goto :goto_1

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-virtual {v1, v4}, Lcom/luck/picture/lib/dialog/a;->h(I)Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v1

    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->u(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object v5, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v5}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v5

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->r(Ljava/util/ArrayList;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v1, v2, v3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->o(J)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-direct {p0, v5}, Lcom/luck/picture/lib/c;->d2(I)Z

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v6, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    if-eqz v5, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    goto :goto_2

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    add-int/2addr v5, v6

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v1, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->w(I)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v5

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-nez v5, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    :cond_3
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    move v5, v4

    move v5, v4

    const/4 v11, 0x5

    move v5, v4

    move v5, v4

    :goto_3
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v7

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-ge v5, v7, :cond_5

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    check-cast v7, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v8, v9}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v11, 0x6

    const/4 v10, 0x3

    if-eqz v8, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    goto :goto_4

    :cond_4
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    goto :goto_3

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/4 v7, 0x0

    :goto_4
    const/4 v11, 0x3

    if-nez v7, :cond_6

    const/4 v11, 0x1

    new-instance v7, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    invoke-direct {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x3

    invoke-interface {v0, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    or-int/2addr v11, v10

    invoke-virtual {v7, v5}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->v(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v8

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    cmp-long v2, v8, v2

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-eqz v2, :cond_7

    const/4 v11, 0x2

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x1

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    cmp-long v2, v2, v8

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-nez v2, :cond_8

    :cond_7
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->d()J

    move-result-wide v2

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v7, v2, v3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->o(J)V

    :cond_8
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-boolean v2, v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v10, 0x6

    move v11, v10

    if-eqz v2, :cond_9

    const/4 v11, 0x5

    const/4 v10, 0x5

    invoke-virtual {v7, v6}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->x(Z)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto :goto_5

    :cond_9
    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {p0, v2}, Lcom/luck/picture/lib/c;->d2(I)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v2, :cond_a

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v2, v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-eqz v2, :cond_a

    const/4 v10, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object v2, v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-nez v2, :cond_b

    :cond_a
    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v2, v4, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_b
    :goto_5
    const/4 v11, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-direct {p0, v1}, Lcom/luck/picture/lib/c;->d2(I)Z

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz v1, :cond_c

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    goto :goto_6

    :cond_c
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v7}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    add-int/2addr v1, v6

    :goto_6
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v7, v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->w(I)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x6

    xor-int/2addr v11, v10

    iget-object v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v7, v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v7, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->u(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v11, 0x6

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/dialog/a;->c(Ljava/util/List;)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-void
.end method

.method static synthetic f1(Lcom/luck/picture/lib/c;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method public static f2()Lcom/luck/picture/lib/c;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/luck/picture/lib/c;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/luck/picture/lib/c;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v1, Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method static synthetic g1(Lcom/luck/picture/lib/c;)I
    .locals 2

    const/4 v1, 0x2

    iget p0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    return p0
.end method

.method private g2(IZ)V
    .locals 13

    const/4 v12, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v12, 0x3

    sget-object v10, Lcom/luck/picture/lib/d;->P:Ljava/lang/String;

    const/4 v12, 0x7

    invoke-static {v0, v10}, Lcom/luck/picture/lib/utils/a;->b(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;)Z

    move-result v0

    const/4 v12, 0x6

    if-eqz v0, :cond_4

    const/4 v12, 0x5

    if-eqz p2, :cond_0

    const/4 v12, 0x7

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v12, 0x6

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v12, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v12, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    const/4 v12, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v12, 0x0

    invoke-virtual {v1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v12, 0x5

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v1

    const/4 v12, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v1

    const/4 v12, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v2

    const/4 v12, 0x1

    invoke-virtual {v2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v2

    :goto_0
    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    const/4 v12, 0x0

    move v5, v1

    move v5, v1

    move v5, v1

    move v5, v1

    move-wide v7, v2

    const/4 v12, 0x6

    if-nez p2, :cond_2

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v12, 0x1

    iget-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v12, 0x5

    if-eqz v1, :cond_2

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v12, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v12, 0x5

    if-eqz v0, :cond_1

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v12, 0x7

    goto :goto_1

    :cond_1
    const/4 v12, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v12, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v0

    :goto_1
    const/4 v12, 0x5

    invoke-static {v1, v0}, Lcom/luck/picture/lib/magical/a;->c(Landroidx/recyclerview/widget/RecyclerView;I)V

    :cond_2
    const/4 v12, 0x2

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k1:Ls6/l;

    const/4 v12, 0x6

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v12, 0x1

    iget v4, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v12, 0x7

    invoke-virtual {v2}, Lcom/luck/picture/lib/widget/TitleBar;->getTitleText()Ljava/lang/String;

    move-result-object v10

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v12, 0x3

    invoke-virtual {v2}, Lcom/luck/picture/lib/adapter/b;->e()Z

    move-result v11

    const/4 v12, 0x4

    move v2, p1

    move v2, p1

    move v2, p1

    const/4 v12, 0x0

    move v3, v5

    move v3, v5

    move v3, v5

    move-wide v5, v7

    move-object v7, v10

    move-object v7, v10

    const/4 v12, 0x2

    move v8, v11

    move v8, v11

    move v8, v11

    move v8, v11

    const/4 v12, 0x7

    move v10, p2

    move v10, p2

    move v10, p2

    move v10, p2

    const/4 v12, 0x7

    invoke-interface/range {v0 .. v10}, Ls6/l;->a(Landroid/content/Context;IIIJLjava/lang/String;ZLjava/util/ArrayList;Z)V

    const/4 v12, 0x1

    goto :goto_2

    :cond_3
    const/4 v12, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v12, 0x7

    invoke-static {v0, v10}, Lcom/luck/picture/lib/utils/a;->b(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;)Z

    move-result v0

    const/4 v12, 0x3

    if-eqz v0, :cond_4

    const/4 v12, 0x3

    invoke-static {}, Lcom/luck/picture/lib/d;->R1()Lcom/luck/picture/lib/d;

    move-result-object v11

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v12, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/TitleBar;->getTitleText()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->e()Z

    move-result v3

    const/4 v12, 0x1

    iget v6, p0, Lcom/luck/picture/lib/basic/e;->c:I

    move-object v0, v11

    move-object v0, v11

    const/4 v12, 0x1

    move v1, p2

    move v1, p2

    move v1, p2

    move v1, p2

    const/4 v12, 0x6

    move v4, p1

    move v4, p1

    move v4, p1

    move v4, p1

    const/4 v12, 0x3

    invoke-virtual/range {v0 .. v9}, Lcom/luck/picture/lib/d;->Z1(ZLjava/lang/String;ZIIIJLjava/util/ArrayList;)V

    const/4 v12, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v12, 0x0

    invoke-static {v0, v10, v11}, Lcom/luck/picture/lib/basic/a;->a(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    :cond_4
    :goto_2
    const/4 v12, 0x7

    return-void
.end method

.method static synthetic h1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method private h2()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-boolean v1, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/b;->j(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->P0(J)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/c;->R1(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v2, 0x7

    and-int/2addr v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->j()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/c;->T1(Ljava/util/List;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method static synthetic i1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/c;->U1(Ljava/util/ArrayList;Z)V

    const/4 v1, 0x1

    return-void
.end method

.method private i2()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, p0, Lcom/luck/picture/lib/c;->t:I

    const/4 v2, 0x6

    move v3, v2

    if-lez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v1, Lcom/luck/picture/lib/c$f;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$f;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic j1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method private j2(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x5

    const/4 v4, 0x5

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-boolean v1, p0, Lcom/luck/picture/lib/c;->u:Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v1, Lcom/luck/picture/lib/c;->C:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    monitor-enter v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    monitor-exit v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_2

    :catch_0
    move-exception p1

    :try_start_3
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_2
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/c;->u:Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void

    :goto_2
    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/c;->u:Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    throw p1
.end method

.method static synthetic k1(Lcom/luck/picture/lib/c;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p0
.end method

.method private k2()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/b;->j(Z)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lu6/a;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->N1()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v0, Lu6/b;->b:[Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v0}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v0}, Lcom/luck/picture/lib/c;->x(I[Ljava/lang/String;)V

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lu6/a;->b()Lu6/a;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v2, Lcom/luck/picture/lib/c$s;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v2, p0}, Lcom/luck/picture/lib/c$s;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p0, v0, v2}, Lu6/a;->j(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Lu6/c;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method static synthetic l1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method private l2(Ljava/util/ArrayList;)V
    .locals 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->A0()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    cmp-long v2, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-lez v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireView()Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v3, Lcom/luck/picture/lib/c$l;

    const/4 v5, 0x0

    invoke-direct {v3, p0, p1}, Lcom/luck/picture/lib/c$l;-><init>(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->m2(Ljava/util/ArrayList;)V

    :goto_0
    const/4 v5, 0x1

    return-void
.end method

.method static synthetic m1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/loader/a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v1, 0x7

    return-object p0
.end method

.method private m2(Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->P0(J)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/c;->e(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/b;->i(Ljava/util/ArrayList;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->f()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->g()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->i2()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/b;->d()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->p2()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->W1()V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method static synthetic n1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/c;->z:Lcom/luck/picture/lib/widget/a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-object p0
.end method

.method private n2()V
    .locals 8

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->getFirstVisiblePosition()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v1, -0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eq v0, v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v7, 0x6

    if-le v2, v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    check-cast v2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2}, Lcom/luck/picture/lib/entity/LocalMedia;->u()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    cmp-long v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lez v2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/c;->q:Landroid/widget/TextView;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->u()J

    move-result-wide v0

    const/4 v7, 0x1

    invoke-static {v3, v0, v1}, Lcom/luck/picture/lib/utils/d;->g(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void
.end method

.method static synthetic o1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method private o2()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-lez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->q:Landroid/widget/TextView;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getAlpha()F

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v4, v3

    cmpl-float v0, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c;->q:Landroid/widget/TextView;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-wide/16 v1, 0x96

    const-wide/16 v1, 0x96

    const/4 v4, 0x0

    const-wide/16 v1, 0x96

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alphaBy(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic p1(Lcom/luck/picture/lib/c;IZ)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/c;->g2(IZ)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method private p2()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v2, -0x1

    const/4 v5, 0x4

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_3

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/16 v1, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x7

    if-ne v0, v1, :cond_1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget v1, Lcom/luck/picture/lib/R$drawable;->ps_ic_no_data:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1, v2, v2}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ne v0, v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget v0, Lcom/luck/picture/lib/R$string;->ps_audio_empty:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_empty:I

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method static synthetic q1(Lcom/luck/picture/lib/c;Ljava/util/List;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->P1(Ljava/util/List;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic r1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/c;->Q1(Ljava/util/ArrayList;Z)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic s1(Lcom/luck/picture/lib/c;Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->R1(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic t1(Lcom/luck/picture/lib/c;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p0, p0, Lcom/luck/picture/lib/c;->t:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic u1(Lcom/luck/picture/lib/c;)J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/luck/picture/lib/c;->r:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-wide v0
.end method

.method static synthetic v1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic w1(Lcom/luck/picture/lib/c;J)J
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/luck/picture/lib/c;->r:J

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-wide p1
.end method

.method static synthetic x1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic y1(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic z1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public A()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-boolean v0, p0, Lcom/luck/picture/lib/c;->v:Z

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Lcom/luck/picture/lib/c$m;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$m;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide/16 v2, 0x15e

    const-wide/16 v2, 0x15e

    const/4 v5, 0x6

    const-wide/16 v2, 0x15e

    const-wide/16 v2, 0x15e

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->i()V

    :goto_0
    const/4 v5, 0x4

    return-void
.end method

.method public B0()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/luck/picture/lib/c;->A:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public D(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/dialog/a;->g()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/c;->d2(I)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-boolean v1, p0, Lcom/luck/picture/lib/c;->u:Z

    :cond_0
    const/4 v6, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget v3, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ne v3, v1, :cond_1

    const/4 v6, 0x7

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->i()V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0, p1, v2}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0, p1, v2}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    :cond_2
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemInserted(I)V

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v5, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v3}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemRangeChanged(II)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;-><init>()V

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/t;->j(Ljava/lang/Object;)J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, v3, v4}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->o(J)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->v(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->u(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->w(I)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget p1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->q(I)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->x(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->r(Ljava/util/ArrayList;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1, v2}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v5, 0x1

    or-int/2addr v6, v5

    goto :goto_1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->e2(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput v2, p0, Lcom/luck/picture/lib/c;->s:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-gtz p1, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz p1, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_2

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->p2()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_3

    :cond_6
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->W1()V

    :goto_3
    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-void
.end method

.method public K()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->g()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public O(J)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v1, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz v2, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    iget v6, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    mul-int v7, v6, v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    new-instance v8, Lcom/luck/picture/lib/c$b;

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    invoke-direct {v8, p0}, Lcom/luck/picture/lib/c$b;-><init>(Lcom/luck/picture/lib/c;)V

    move-wide v4, p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface/range {v2 .. v8}, Lq6/c;->c(Landroid/content/Context;JIILs6/o;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget v1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget v2, v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    mul-int/2addr v1, v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-instance v2, Lcom/luck/picture/lib/c$c;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v2, p0}, Lcom/luck/picture/lib/c$c;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v0, p1, p2, v1, v2}, Lcom/luck/picture/lib/loader/a;->i(JILs6/o;)V

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-void
.end method

.method public P(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget p1, p1, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/b;->f(I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public T()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v2, Lcom/luck/picture/lib/c$d;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v2, p0}, Lcom/luck/picture/lib/c$d;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lq6/c;->a(Landroid/content/Context;Ls6/m;)V

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Lcom/luck/picture/lib/c$e;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$e;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/loader/a;->j(Ls6/m;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method public a()V
    .locals 3

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireView()Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/basic/e;->R0(Landroid/view/View;)V

    const/4 v2, 0x0

    return-void
.end method

.method protected a2()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Lcom/luck/picture/lib/loader/d;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/loader/d;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v3, 0x5

    move v4, v3

    iput-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Lcom/luck/picture/lib/loader/b;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/loader/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public c([Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0, v1, v0}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    aget-object v0, p1, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v2, Lu6/b;->d:[Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    aget-object v1, v2, v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-interface {v1, p0, p1}, Ls6/k;->b(Landroidx/fragment/app/Fragment;[Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lu6/a;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lu6/a;->e(Landroid/content/Context;[Ljava/lang/String;)Z

    move-result p1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz p1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->N1()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_1

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_camera:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_1

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget v0, Lcom/luck/picture/lib/R$string;->ps_jurisdiction:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method

.method public e(Z)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->l0()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v0, 0x0

    :cond_0
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    if-ge v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y0(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v1, v1, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Lcom/luck/picture/lib/adapter/b;->f(I)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method public f()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget v0, Lcom/luck/picture/lib/R$layout;->ps_fragment_selector:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v0
.end method

.method public i()V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b()Z

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz v0, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget v0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v11, 0x6

    const/4 v10, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    iput v0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v11, 0x3

    const/4 v10, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v0, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v11, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    sget-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v2, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget v6, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget-object v4, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x3

    const/4 v10, 0x0

    iget v8, v4, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-instance v9, Lcom/luck/picture/lib/c$n;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {v9, p0}, Lcom/luck/picture/lib/c$n;-><init>(Lcom/luck/picture/lib/c;)V

    move-wide v4, v0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    move v7, v8

    const/4 v11, 0x0

    move v7, v8

    move v7, v8

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface/range {v2 .. v9}, Lq6/c;->b(Landroid/content/Context;JIIILs6/o;)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_1

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget v5, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget-object v3, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v7, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    new-instance v8, Lcom/luck/picture/lib/c$o;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v8, p0}, Lcom/luck/picture/lib/c$o;-><init>(Lcom/luck/picture/lib/c;)V

    move-wide v3, v0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    move v6, v7

    move v6, v7

    const/4 v11, 0x2

    move v6, v7

    move v6, v7

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual/range {v2 .. v8}, Lcom/luck/picture/lib/loader/a;->k(JIIILs6/o;)V

    :cond_2
    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    return-void
.end method

.method public n(Landroid/os/Bundle;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v0, "ei.maociflcrlu.se_bclk.eilpzotuml_ds"

    const-string v0, "_lslcl..buouermfeikiirzcltds_ca.oelp"

    const/4 v3, 0x5

    const-string v0, "..e.oe_uoskrezpoiml.alcrlccutildbfi_"

    const-string v0, "com.luck.picture.lib.all_folder_size"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v0, p0, Lcom/luck/picture/lib/c;->s:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "umpbebkuc.ueaec_trlmpncrglioct.r."

    const-string v0, "gkmmu.oe.bpc_.tuicpullrnraierccet"

    const/4 v3, 0x2

    const-string v0, "com.luck.picture.lib.current_page"

    const/4 v3, 0x6

    iget v1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput v0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, "._ri.uutclieoreertouwmrcl_kcp.cobtsi.iiuevpop"

    const-string/jumbo v0, "uosco_uibpcrkeroeincuwv.etle.rtr.lci.tpmpio_i"

    const/4 v3, 0x6

    const-string v0, "eokrci.ppcbuvcponnrtewu_ieom.rscrletpt.i_liui"

    const-string v0, "com.luck.picture.lib.current_preview_position"

    const/4 v3, 0x1

    iget v1, p0, Lcom/luck/picture/lib/c;->t:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lcom/luck/picture/lib/c;->t:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v3, 0x3

    const-string v1, "amrc.pelqu.us.ac.lelyc_ipartbocdkii"

    const-string v1, "be.lrbc_mydlsrp.liuoucciak.pac.tiae"

    const/4 v3, 0x0

    const-string/jumbo v1, "rcsilpr.y.ad.aceusekm.lubimclcat_pi"

    const-string v1, "com.luck.picture.lib.display_camera"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/luck/picture/lib/c;->w:Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/luck/picture/lib/c;->w:Z

    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public onDestroyView()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c;->z:Lcom/luck/picture/lib/widget/a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/a;->q()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    move v3, v2

    invoke-super {p0, p1}, Lcom/luck/picture/lib/basic/e;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v3, 0x0

    const-string v0, "_lti.zulcu.uadecrcl.elooep.lm_fsiikr"

    const/4 v3, 0x4

    const-string/jumbo v0, "pucm.fellebmioc.zdorlicilua._ktrlse."

    const-string v0, "com.luck.picture.lib.all_folder_size"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/luck/picture/lib/c;->s:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v0, "_.ucoirrgtcceli.rpampb.cuk.ptuoen"

    const-string v0, "ceiaepgptoumc.i.lk.c.pucunlr_btrr"

    const/4 v3, 0x4

    const-string v0, "cci.nb.a.gerleoure.plbttiupmrccuk"

    const-string v0, "com.luck.picture.lib.current_page"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->getLastVisiblePosition()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v1, "ottlsruumiot.be.lpcwenrqiipoinvccpi_rcur.euk_"

    const-string/jumbo v1, "murpnu.sqlcvbocn.c.irii_o_cotuetperkilteriw.p"

    const/4 v3, 0x3

    const-string v1, ".i.renipowls.inpporr__tuctrelemivebcc.ckutoui"

    const-string v1, "com.luck.picture.lib.current_preview_position"

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->e()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "udcmoaacqerab.imci_cktp.silrl.pl.es"

    const-string v1, "ias.pbstacl_.moruiprmldceac.le.kciu"

    const/4 v3, 0x0

    const-string v1, ".lseosubelp_cdtaaapmr.ly..mckcrciiu"

    const-string v1, "com.luck.picture.lib.display_camera"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c;->y:Lcom/luck/picture/lib/dialog/a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/dialog/a;->f()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/manager/b;->a(Ljava/util/List;)V

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-static {p1}, Lcom/luck/picture/lib/manager/b;->c(Ljava/util/ArrayList;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/basic/e;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Lcom/luck/picture/lib/c;->n(Landroid/os/Bundle;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p2, 0x0

    :goto_0
    const/4 v1, 0x3

    iput-boolean p2, p0, Lcom/luck/picture/lib/c;->v:Z

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    sget p2, Lcom/luck/picture/lib/R$id;->tv_data_empty:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p2, Landroid/widget/TextView;

    const/4 v0, 0x5

    move v1, v0

    iput-object p2, p0, Lcom/luck/picture/lib/c;->m:Landroid/widget/TextView;

    const/4 v1, 0x4

    const/4 v0, 0x4

    sget p2, Lcom/luck/picture/lib/R$id;->ps_complete_select:I

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    check-cast p2, Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    sget p2, Lcom/luck/picture/lib/R$id;->title_bar:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p2, Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/c;->n:Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget p2, Lcom/luck/picture/lib/R$id;->bottom_nar_bar:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    check-cast p2, Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    sget p2, Lcom/luck/picture/lib/R$id;->tv_current_data_time:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p2, Landroid/widget/TextView;

    const/4 v0, 0x7

    const/4 v0, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/c;->q:Landroid/widget/TextView;

    const/4 v0, 0x0

    move v1, v0

    invoke-virtual {p0}, Lcom/luck/picture/lib/c;->a2()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->X1()V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->c2()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->Z1()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->b2(Landroid/view/View;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->Y1()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-boolean p1, p0, Lcom/luck/picture/lib/c;->v:Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p1, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->h2()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/c;->k2()V

    :goto_1
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public u()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v2, Lcom/luck/picture/lib/c$w;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v2, p0}, Lcom/luck/picture/lib/c$w;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lq6/c;->d(Landroid/content/Context;Ls6/n;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Lcom/luck/picture/lib/c$a;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/c$a;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/loader/a;->h(Ls6/n;)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public x(I[Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/basic/e;->x(I[Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v2, 0x5

    const/4 v1, 0x0

    new-instance v0, Lcom/luck/picture/lib/c$t;

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/c$t;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v2, 0x0

    invoke-interface {p1, p0, p2, v0}, Ls6/k;->a(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Ls6/u;)V

    :goto_0
    const/4 v2, 0x1

    return-void
.end method

.method public z(ZLcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->o:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->h()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->p:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/CompleteSelectView;->setSelectedChange(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/c;->O1(Z)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget p2, p2, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/adapter/b;->f(I)V

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    iget-object p2, p0, Lcom/luck/picture/lib/c;->l:Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Lcom/luck/picture/lib/c$k;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/c$k;-><init>(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-wide/16 v1, 0x87

    const-wide/16 v1, 0x87

    const/4 v4, 0x7

    const-wide/16 v1, 0x87

    const-wide/16 v1, 0x87

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c;->x:Lcom/luck/picture/lib/adapter/b;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget p2, p2, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/adapter/b;->f(I)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/c;->e(Z)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method
