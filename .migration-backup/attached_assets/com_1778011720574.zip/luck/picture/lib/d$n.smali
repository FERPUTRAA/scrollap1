.class Lcom/luck/picture/lib/d$n;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/m;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->P1(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/m<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$n;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~asb  @ u~d@~~K yv@f@@@~-~i~~o /@~fb@~~M llr@@n~o~~t~is@ m~c o @ t~@@@@  ~.  o /@~bo~4i1o@~~ @S@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/d$n;->b(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public b(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$n;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/d;->X0(Lcom/luck/picture/lib/d;Ljava/util/ArrayList;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
