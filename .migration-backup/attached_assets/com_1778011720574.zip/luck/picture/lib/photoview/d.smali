.class public interface abstract Lcom/luck/picture/lib/photoview/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/graphics/RectF;)V
.end method
