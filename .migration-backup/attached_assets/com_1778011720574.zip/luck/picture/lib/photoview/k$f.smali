.class Lcom/luck/picture/lib/photoview/k$f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/photoview/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "f"
.end annotation


# instance fields
.field private final a:Landroid/widget/OverScroller;

.field private b:I

.field private c:I

.field final synthetic d:Lcom/luck/picture/lib/photoview/k;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/photoview/k;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$f;->d:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    new-instance p1, Landroid/widget/OverScroller;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p1, p2}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " osls@ o~@ / /~~t ~v~i@b~f@ @d4  b@@@~~~~o nr~@~o~Km@~@~@@~@ io@.o ~u ~M~~t1@ @~l@ Sy@@ fi -c~ b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/OverScroller;->forceFinished(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public b(IIII)V
    .locals 14

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    iget-object v1, v0, Lcom/luck/picture/lib/photoview/k$f;->d:Lcom/luck/picture/lib/photoview/k;

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/k;->C()Landroid/graphics/RectF;

    move-result-object v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget v2, v1, Landroid/graphics/RectF;->left:F

    neg-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v4

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    int-to-float v2, v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    cmpg-float v3, v2, v3

    const/4 v5, 0x0

    if-gez v3, :cond_1

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    sub-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    move v9, v2

    move v9, v2

    move v9, v2

    move v9, v2

    move v8, v5

    move v8, v5

    move v8, v5

    move v8, v5

    goto :goto_0

    :cond_1
    move v8, v4

    move v8, v4

    move v8, v4

    move v8, v4

    move v9, v8

    move v9, v8

    move v9, v8

    move v9, v8

    :goto_0
    iget v2, v1, Landroid/graphics/RectF;->top:F

    neg-float v2, v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    move/from16 v3, p2

    move/from16 v3, p2

    int-to-float v3, v3

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v6

    cmpg-float v6, v3, v6

    if-gez v6, :cond_2

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v1

    sub-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    move v11, v1

    move v11, v1

    move v10, v5

    move v10, v5

    move v10, v5

    move v10, v5

    goto :goto_1

    :cond_2
    move v10, v2

    move v10, v2

    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    :goto_1
    iput v4, v0, Lcom/luck/picture/lib/photoview/k$f;->b:I

    iput v2, v0, Lcom/luck/picture/lib/photoview/k$f;->c:I

    if-ne v4, v9, :cond_3

    if-eq v2, v11, :cond_4

    :cond_3
    iget-object v3, v0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v12, 0x0

    const/4 v13, 0x0

    move v5, v2

    move v5, v2

    move v5, v2

    move v5, v2

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    invoke-virtual/range {v3 .. v13}, Landroid/widget/OverScroller;->fling(IIIIIIIIII)V

    :cond_4
    return-void
.end method

.method public run()V
    .locals 7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$f;->a:Landroid/widget/OverScroller;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$f;->d:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->m(Lcom/luck/picture/lib/photoview/k;)Landroid/graphics/Matrix;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v3, p0, Lcom/luck/picture/lib/photoview/k$f;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    sub-int/2addr v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    int-to-float v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget v4, p0, Lcom/luck/picture/lib/photoview/k$f;->c:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    sub-int/2addr v4, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    int-to-float v4, v4

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v2, v3, v4}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$f;->d:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->q(Lcom/luck/picture/lib/photoview/k;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput v0, p0, Lcom/luck/picture/lib/photoview/k$f;->b:I

    const/4 v6, 0x4

    iput v1, p0, Lcom/luck/picture/lib/photoview/k$f;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$f;->d:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-static {v0, p0}, Lcom/luck/picture/lib/photoview/a;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    return-void
.end method
