.class synthetic Lcom/luck/picture/lib/photoview/l$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/photoview/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Landroid/widget/ImageView$ScaleType;->values()[Landroid/widget/ImageView$ScaleType;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    array-length v0, v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-array v0, v0, [I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    sput-object v0, Lcom/luck/picture/lib/photoview/l$a;->a:[I

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Landroid/widget/ImageView$ScaleType;->MATRIX:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method
