.class Lcom/luck/picture/lib/photoview/l;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-void
.end method

.method static a(FFF)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@ l@@ ~@ybv  ~ o@   iouo~/~c~a-~@b~ M/ ~i@~ob@~fo~Ki~~rl@t~4~o@t~  ~~~@ f@S@@m@ 1s. ~@ @d @~n"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    cmpl-float p0, p0, p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    if-gez p0, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    cmpl-float p0, p1, p2

    const/4 v1, 0x5

    const/4 v0, 0x6

    if-gez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const-string/jumbo p1, "rMmmaxolhm m(Mu.iZutlaxbapa osznoh emhwm peatipsaeaost ) its eo v uedmoio emComo eazaMm ult i r r"

    const-string p1, "a sm.Cevh z moo sipulaattxas  ilweaohZM(aaMmm i uz rat)drom iore tbie pmlos loeemeout pmmnahouMx "

    const/4 v1, 0x0

    const-string p1, " laeoaaaCouneo msumoil t  sio  rte(tpmr aouextZrhmmp MaoasvhohbmM)ewlldie izzieM  mtamo p.suo x a"

    const-string p1, "Medium zoom has to be less than Maximum zoom. Call setMaximumZoom() with a more appropriate value"

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    throw p0

    :cond_1
    const/4 v1, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x1

    const-string/jumbo p1, "toem b aiur we  otmlmishmhlevoa.aMz)Zn mi boomozrmsaa    e upiiMmM(remelpn asmoiidutptheooaut  sn"

    const-string p1, " o mvsioo haauh i.Mwmn mtbtln memMo uia)rnamlm mpz o  oeeiar eeZiouimu d spoh sptersillMmzaeta(to"

    const/4 v1, 0x3

    const-string/jumbo p1, "ttvueourmoh.rplmalMeanaleieaoshs)mpbwm r iuimM moaastoaoCmuiz ihte n   nz is mio t e (mMuop  Zled"

    const-string p1, "Minimum zoom has to be less than Medium zoom. Call setMinimumZoom() with a more appropriate value"

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    throw p0
.end method

.method static b(I)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    const v0, 0xff00

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    and-int/2addr p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    shr-int/lit8 p0, p0, 0x8

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p0
.end method

.method static c(Landroid/widget/ImageView;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p0, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method static d(Landroid/widget/ImageView$ScaleType;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/photoview/l$a;->a:[I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    aget p0, v0, p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p0, v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "si   t ptonrtsrisa xopeceMplyptaod"

    const-string/jumbo v0, "pd tolnret siscuaoo itasyprpM etx "

    const/4 v2, 0x7

    const-string/jumbo v0, "l dxyt cqaprtipnpe Muisoes o estat"

    const-string v0, "Matrix scale type is not supported"

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    throw p0
.end method
