.class public interface abstract Lcom/luck/picture/lib/photoview/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/widget/ImageView;)V
.end method
