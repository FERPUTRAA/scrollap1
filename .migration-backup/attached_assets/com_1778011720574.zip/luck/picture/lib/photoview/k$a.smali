.class Lcom/luck/picture/lib/photoview/k$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/photoview/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/photoview/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/photoview/k;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/photoview/k;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(FF)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @s ~i@ i@@~~f@ ~r t~i ~/m1c~ ~d o~~~~Sov@ ~@~o@ulo~@M @o@@/t@~@.nf ~~bb l@ ~~a@o@~@b @  Ks~4 @-"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->a(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/b;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/b;->e()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->b(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/i;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->b(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/i;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v0, p1, p2}, Lcom/luck/picture/lib/photoview/i;->a(FF)V

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->m(Lcom/luck/picture/lib/photoview/k;)Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, p1, p2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->q(Lcom/luck/picture/lib/photoview/k;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->s(Lcom/luck/picture/lib/photoview/k;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->a(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/b;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/b;->e()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v1, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->t(Lcom/luck/picture/lib/photoview/k;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v1, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->u(Lcom/luck/picture/lib/photoview/k;)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq v1, v3, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->u(Lcom/luck/picture/lib/photoview/k;)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    cmpl-float v1, p1, v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    if-gez v1, :cond_5

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->u(Lcom/luck/picture/lib/photoview/k;)I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/high16 v4, -0x40800000    # -1.0f

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ne v1, v2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    cmpg-float p1, p1, v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-lez p1, :cond_5

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->v(Lcom/luck/picture/lib/photoview/k;)I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-nez p1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    cmpl-float p1, p2, v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-gez p1, :cond_5

    :cond_4
    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->v(Lcom/luck/picture/lib/photoview/k;)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ne p1, v2, :cond_7

    const/4 v5, 0x3

    const/4 v5, 0x0

    cmpg-float p1, p2, v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-gtz p1, :cond_7

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 p1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-interface {v0, p1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_7
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method public b(FFFFF)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->e(Lcom/luck/picture/lib/photoview/k;)F

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    cmpg-float v0, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    cmpg-float v0, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-gez v0, :cond_2

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->f(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/g;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->f(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/g;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0, p1, p2, p3}, Lcom/luck/picture/lib/photoview/g;->a(FFF)V

    :cond_1
    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->m(Lcom/luck/picture/lib/photoview/k;)Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p1, p2, p3}, Landroid/graphics/Matrix;->postScale(FFFF)Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->m(Lcom/luck/picture/lib/photoview/k;)Landroid/graphics/Matrix;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, p4, p5}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->q(Lcom/luck/picture/lib/photoview/k;)V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public c(FFF)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v1, p1

    move v1, p1

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    move v2, p2

    move v2, p2

    const/4 v7, 0x5

    move v2, p2

    move v2, p2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v3, p3

    move v3, p3

    move v3, p3

    move v3, p3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual/range {v0 .. v5}, Lcom/luck/picture/lib/photoview/k$a;->b(FFFFF)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void
.end method

.method public d(FFFF)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p2, Lcom/luck/picture/lib/photoview/k$f;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p2, p1, v0}, Lcom/luck/picture/lib/photoview/k$f;-><init>(Lcom/luck/picture/lib/photoview/k;Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, p2}, Lcom/luck/picture/lib/photoview/k;->x(Lcom/luck/picture/lib/photoview/k;Lcom/luck/picture/lib/photoview/k$f;)Lcom/luck/picture/lib/photoview/k$f;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->w(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/k$f;

    move-result-object p1

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2, v0}, Lcom/luck/picture/lib/photoview/k;->c(Lcom/luck/picture/lib/photoview/k;Landroid/widget/ImageView;)I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-static {v0, v1}, Lcom/luck/picture/lib/photoview/k;->d(Lcom/luck/picture/lib/photoview/k;Landroid/widget/ImageView;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    float-to-int p3, p3

    const/4 v2, 0x7

    move v3, v2

    float-to-int p4, p4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, p2, v0, p3, p4}, Lcom/luck/picture/lib/photoview/k$f;->b(IIII)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/photoview/k$a;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/luck/picture/lib/photoview/k;->w(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/k$f;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method
