.class public interface abstract Lcom/luck/picture/lib/photoview/g;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(FFF)V
.end method
