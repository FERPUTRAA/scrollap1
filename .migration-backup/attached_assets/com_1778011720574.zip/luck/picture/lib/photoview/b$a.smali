.class Lcom/luck/picture/lib/photoview/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ScaleGestureDetector$OnScaleGestureListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/photoview/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/photoview/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:F

.field private b:F

.field final synthetic c:Lcom/luck/picture/lib/photoview/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/photoview/b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/b$a;->c:Lcom/luck/picture/lib/photoview/b;

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    move v1, v0

    const/4 p1, 0x0

    xor-int/2addr v1, p1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/photoview/b$a;->b:F

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onScale(Landroid/view/ScaleGestureDetector;)Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~~s~ oo@@f~~@d@ tc-i@~4 o ~~o@~ .ob@@ @l@ 1aiy@f  lio@ ~ ~t ~@~Mu/ b@~K @S@ m~~~~@~br @/@~ ns~v@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getScaleFactor()F

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-nez v0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/Float;->isInfinite(F)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    cmpl-float v0, v1, v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-ltz v0, :cond_1

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b$a;->c:Lcom/luck/picture/lib/photoview/b;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/b;->a(Lcom/luck/picture/lib/photoview/b;)Lcom/luck/picture/lib/photoview/c;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusX()F

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusY()F

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusX()F

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget v5, p0, Lcom/luck/picture/lib/photoview/b$a;->a:F

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    sub-float/2addr v4, v5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusY()F

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget v6, p0, Lcom/luck/picture/lib/photoview/b$a;->b:F

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    sub-float/2addr v5, v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface/range {v0 .. v5}, Lcom/luck/picture/lib/photoview/c;->b(FFFFF)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusX()F

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    iput v0, p0, Lcom/luck/picture/lib/photoview/b$a;->a:F

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusY()F

    move-result p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput p1, p0, Lcom/luck/picture/lib/photoview/b$a;->b:F

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 p1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    return p1

    :cond_2
    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 p1, 0x0

    const/4 v8, 0x7

    return p1
.end method

.method public onScaleBegin(Landroid/view/ScaleGestureDetector;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusX()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/luck/picture/lib/photoview/b$a;->a:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/ScaleGestureDetector;->getFocusY()F

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput p1, p0, Lcom/luck/picture/lib/photoview/b$a;->b:F

    const/4 p1, 0x1

    move v2, p1

    move v1, p1

    move v1, p1

    const/4 v2, 0x5

    return p1
.end method

.method public onScaleEnd(Landroid/view/ScaleGestureDetector;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method
