.class public interface abstract Lcom/luck/picture/lib/photoview/i;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(FF)V
.end method
