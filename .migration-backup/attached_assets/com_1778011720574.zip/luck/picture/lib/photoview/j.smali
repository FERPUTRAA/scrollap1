.class public interface abstract Lcom/luck/picture/lib/photoview/j;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/view/View;FF)V
.end method
