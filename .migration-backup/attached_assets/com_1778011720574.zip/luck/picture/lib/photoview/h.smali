.class public interface abstract Lcom/luck/picture/lib/photoview/h;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
.end method
