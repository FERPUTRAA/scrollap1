.class public interface abstract Lcom/luck/picture/lib/photoview/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Landroid/widget/ImageView;FF)V
.end method
