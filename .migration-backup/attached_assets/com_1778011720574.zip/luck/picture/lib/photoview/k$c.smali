.class Lcom/luck/picture/lib/photoview/k$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/GestureDetector$OnDoubleTapListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/photoview/k;-><init>(Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/photoview/k;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/photoview/k;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onDoubleTap(Landroid/view/MotionEvent;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@nsf~b~o d oM~~ @/i@m  @ ~i@~uco~b  @@o@/S@@v@@  @~~@i yl~@4@  ~~K~@~@@ a lr- 1~b~f~~.t ost~~o~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const/4 v0, 0x1

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3}, Lcom/luck/picture/lib/photoview/k;->J()F

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    cmpg-float v3, v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-gez v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/k;->J()F

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, v3, v2, p1, v0}, Lcom/luck/picture/lib/photoview/k;->m0(FFFZ)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v3}, Lcom/luck/picture/lib/photoview/k;->J()F

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    cmpl-float v3, v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ltz v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v3}, Lcom/luck/picture/lib/photoview/k;->I()F

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    cmpg-float v1, v1, v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-gez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/k;->I()F

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v3, v2, p1, v0}, Lcom/luck/picture/lib/photoview/k;->m0(FFFZ)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/photoview/k;->K()F

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v3, v2, p1, v0}, Lcom/luck/picture/lib/photoview/k;->m0(FFFZ)V
    :try_end_0
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    const/4 v5, 0x1

    return v0
.end method

.method public onDoubleTapEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method public onSingleTapConfirmed(Landroid/view/MotionEvent;)Z
    .locals 6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->i(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnClickListener;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->i(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnClickListener;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v0, v1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->C()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->j(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/j;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->j(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/j;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v3}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v2, v3, v1, p1}, Lcom/luck/picture/lib/photoview/j;->a(Landroid/view/View;FF)V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v2, v0, Landroid/graphics/RectF;->left:F

    const/4 v5, 0x3

    const/4 v4, 0x6

    sub-float/2addr v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    div-float/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v2, v0, Landroid/graphics/RectF;->top:F

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    sub-float/2addr p1, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    div-float/2addr p1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->k(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/f;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->k(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/f;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0, v2, v1, p1}, Lcom/luck/picture/lib/photoview/f;->a(Landroid/widget/ImageView;FF)V

    :cond_2
    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x3

    return p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->l(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/e;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->l(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/e;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$c;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/photoview/e;->a(Landroid/widget/ImageView;)V

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    return p1
.end method
