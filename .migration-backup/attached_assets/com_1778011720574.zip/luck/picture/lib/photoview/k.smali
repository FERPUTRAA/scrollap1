.class public Lcom/luck/picture/lib/photoview/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/photoview/k$f;,
        Lcom/luck/picture/lib/photoview/k$e;
    }
.end annotation


# static fields
.field private static final F:F = 3.0f

.field private static final G:F = 1.75f

.field private static final H:F = 1.0f

.field private static final I:I = 0xc8

.field private static final J:I = -0x1

.field private static final K:I = 0x0

.field private static final L:I = 0x1

.field private static final M:I = 0x2

.field private static final N:I = -0x1

.field private static final O:I = 0x0

.field private static final P:I = 0x1

.field private static final Q:I = 0x2

.field private static final R:I = 0x1


# instance fields
.field private A:I

.field private B:F

.field private C:Z

.field private D:Landroid/widget/ImageView$ScaleType;

.field private final E:Lcom/luck/picture/lib/photoview/c;

.field private a:Landroid/view/animation/Interpolator;

.field private b:I

.field private c:F

.field private d:F

.field private e:F

.field private f:Z

.field private g:Z

.field private final h:Landroid/widget/ImageView;

.field private i:Landroid/view/GestureDetector;

.field private j:Lcom/luck/picture/lib/photoview/b;

.field private final k:Landroid/graphics/Matrix;

.field private final l:Landroid/graphics/Matrix;

.field private final m:Landroid/graphics/Matrix;

.field private final n:Landroid/graphics/RectF;

.field private final o:[F

.field private p:Lcom/luck/picture/lib/photoview/d;

.field private q:Lcom/luck/picture/lib/photoview/f;

.field private r:Lcom/luck/picture/lib/photoview/e;

.field private s:Lcom/luck/picture/lib/photoview/j;

.field private t:Landroid/view/View$OnClickListener;

.field private u:Landroid/view/View$OnLongClickListener;

.field private v:Lcom/luck/picture/lib/photoview/g;

.field private w:Lcom/luck/picture/lib/photoview/h;

.field private x:Lcom/luck/picture/lib/photoview/i;

.field private y:Lcom/luck/picture/lib/photoview/k$f;

.field private z:I


# direct methods
.method public constructor <init>(Landroid/widget/ImageView;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/k;->a:Landroid/view/animation/Interpolator;

    const/4 v4, 0x4

    const/16 v0, 0xc8

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/photoview/k;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v0, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v4, 0x0

    const/high16 v0, 0x3fe00000    # 1.75f

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v0, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/high16 v0, 0x40400000    # 3.0f

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->f:Z

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/luck/picture/lib/photoview/k;->g:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Landroid/graphics/Matrix;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Landroid/graphics/Matrix;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->l:Landroid/graphics/Matrix;

    const/4 v4, 0x7

    new-instance v1, Landroid/graphics/Matrix;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1}, Landroid/graphics/Matrix;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Landroid/graphics/RectF;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->n:Landroid/graphics/RectF;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 v1, 0x9

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array v1, v1, [F

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->o:[F

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    const/4 v4, 0x5

    iput v1, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Lcom/luck/picture/lib/photoview/k$a;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/photoview/k$a;-><init>(Lcom/luck/picture/lib/photoview/k;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/k;->E:Lcom/luck/picture/lib/photoview/c;

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, p0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->isInEditMode()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, p0, Lcom/luck/picture/lib/photoview/k;->B:F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Lcom/luck/picture/lib/photoview/b;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, v2, v0}, Lcom/luck/picture/lib/photoview/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/photoview/c;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Landroid/view/GestureDetector;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Lcom/luck/picture/lib/photoview/k$b;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/photoview/k$b;-><init>(Lcom/luck/picture/lib/photoview/k;)V

    const/4 v4, 0x3

    invoke-direct {v0, p1, v1}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/k;->i:Landroid/view/GestureDetector;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance p1, Lcom/luck/picture/lib/photoview/k$c;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p1, p0}, Lcom/luck/picture/lib/photoview/k$c;-><init>(Lcom/luck/picture/lib/photoview/k;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->setOnDoubleTapListener(Landroid/view/GestureDetector$OnDoubleTapListener;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method private A()Z
    .locals 15

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v13, "~~ss dc~f@r@@@@f~~  K~~ @@.o @ @ @@@~o M4~1~ b ~@~ ~ / ~oti-~bm~@@vb@ t@ / @ioln~~~~S~~o@lu@iayo"

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->E()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->D(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object v0

    const/4 v14, 0x1

    const/4 v1, 0x7

    const/4 v14, 0x5

    const/4 v1, 0x0

    const/4 v14, 0x4

    if-nez v0, :cond_0

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x1

    return v1

    :cond_0
    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x2

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v2

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x2

    iget-object v4, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x6

    invoke-direct {p0, v4}, Lcom/luck/picture/lib/photoview/k;->G(Landroid/widget/ImageView;)I

    move-result v4

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x1

    int-to-float v4, v4

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x2

    cmpg-float v5, v2, v4

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x5

    const/4 v6, -0x1

    const/4 v13, 0x7

    move v14, v13

    const/high16 v7, 0x40000000    # 2.0f

    const/4 v14, 0x6

    const/4 v8, 0x7

    const/4 v14, 0x6

    const/4 v8, 0x3

    const/4 v14, 0x3

    const/4 v9, 0x1

    const/4 v14, 0x7

    move v13, v9

    move v13, v9

    const/4 v14, 0x1

    const/4 v10, 0x7

    const/4 v14, 0x5

    const/4 v10, 0x2

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x2

    const/4 v11, 0x0

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x1

    if-gtz v5, :cond_3

    const/4 v13, 0x0

    move v14, v13

    sget-object v5, Lcom/luck/picture/lib/photoview/k$d;->a:[I

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x7

    iget-object v12, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v12

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x6

    aget v5, v5, v12

    const/4 v13, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x2

    if-eq v5, v10, :cond_2

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x7

    if-eq v5, v8, :cond_1

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x2

    sub-float/2addr v4, v2

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x4

    div-float/2addr v4, v7

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x5

    iget v2, v0, Landroid/graphics/RectF;->top:F

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x5

    goto :goto_0

    :cond_1
    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x4

    sub-float/2addr v4, v2

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget v2, v0, Landroid/graphics/RectF;->top:F

    :goto_0
    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x1

    sub-float/2addr v4, v2

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x0

    goto :goto_1

    :cond_2
    const/4 v14, 0x1

    const/4 v13, 0x1

    iget v2, v0, Landroid/graphics/RectF;->top:F

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x3

    neg-float v4, v2

    :goto_1
    const/4 v14, 0x1

    iput v10, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x1

    goto :goto_2

    :cond_3
    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x0

    iget v2, v0, Landroid/graphics/RectF;->top:F

    const/4 v14, 0x3

    cmpl-float v5, v2, v11

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x5

    if-lez v5, :cond_4

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x4

    iput v1, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x4

    neg-float v4, v2

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x0

    goto :goto_2

    :cond_4
    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x0

    iget v2, v0, Landroid/graphics/RectF;->bottom:F

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x0

    cmpg-float v5, v2, v4

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x5

    if-gez v5, :cond_5

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x1

    iput v9, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x5

    sub-float/2addr v4, v2

    goto :goto_2

    :cond_5
    const/4 v14, 0x1

    iput v6, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v14, 0x6

    move v4, v11

    move v4, v11

    const/4 v14, 0x4

    move v4, v11

    move v4, v11

    :goto_2
    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x2

    invoke-direct {p0, v2}, Lcom/luck/picture/lib/photoview/k;->H(Landroid/widget/ImageView;)I

    move-result v2

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x4

    int-to-float v2, v2

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x7

    cmpg-float v5, v3, v2

    const/4 v14, 0x0

    const/4 v13, 0x7

    if-gtz v5, :cond_8

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x2

    sget-object v1, Lcom/luck/picture/lib/photoview/k$d;->a:[I

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x6

    iget-object v5, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    const/4 v14, 0x5

    const/4 v13, 0x2

    aget v1, v1, v5

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x3

    if-eq v1, v10, :cond_7

    const/4 v13, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x1

    if-eq v1, v8, :cond_6

    const/4 v14, 0x4

    const/4 v13, 0x5

    sub-float/2addr v2, v3

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x3

    div-float/2addr v2, v7

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x6

    iget v0, v0, Landroid/graphics/RectF;->left:F

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x3

    goto :goto_3

    :cond_6
    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x0

    sub-float/2addr v2, v3

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x1

    iget v0, v0, Landroid/graphics/RectF;->left:F

    :goto_3
    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    sub-float/2addr v2, v0

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x4

    move v11, v2

    move v11, v2

    const/4 v14, 0x7

    move v11, v2

    move v11, v2

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x6

    goto :goto_4

    :cond_7
    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x6

    iget v0, v0, Landroid/graphics/RectF;->left:F

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    neg-float v0, v0

    const/4 v14, 0x4

    move v11, v0

    move v11, v0

    const/4 v14, 0x2

    move v11, v0

    move v11, v0

    :goto_4
    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x3

    iput v10, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    const/4 v13, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x3

    goto :goto_5

    :cond_8
    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x4

    iget v3, v0, Landroid/graphics/RectF;->left:F

    const/4 v14, 0x1

    const/4 v13, 0x7

    cmpl-float v5, v3, v11

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x0

    if-lez v5, :cond_9

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x5

    iput v1, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x6

    neg-float v11, v3

    const/4 v14, 0x6

    goto :goto_5

    :cond_9
    const/4 v14, 0x7

    iget v0, v0, Landroid/graphics/RectF;->right:F

    const/4 v14, 0x2

    cmpg-float v1, v0, v2

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x4

    if-gez v1, :cond_a

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x5

    sub-float v11, v2, v0

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x5

    iput v9, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    const/4 v14, 0x6

    goto :goto_5

    :cond_a
    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x7

    iput v6, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    :goto_5
    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v0, v11, v4}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x2

    return v9
.end method

.method private D(Landroid/graphics/Matrix;)Landroid/graphics/RectF;
    .locals 6

    const/4 v4, 0x4

    move v5, v4

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->n:Landroid/graphics/RectF;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    int-to-float v2, v2

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    int-to-float v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v3, v3, v2, v0}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->n:Landroid/graphics/RectF;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->n:Landroid/graphics/RectF;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-object p1

    :cond_0
    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    return-object p1
.end method

.method private E()Landroid/graphics/Matrix;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->l:Landroid/graphics/Matrix;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->l:Landroid/graphics/Matrix;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->postConcat(Landroid/graphics/Matrix;)Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->l:Landroid/graphics/Matrix;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method private G(Landroid/widget/ImageView;)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sub-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sub-int/2addr v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method private H(Landroid/widget/ImageView;)I
    .locals 4

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getPaddingRight()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    sub-int/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0
.end method

.method private O(Landroid/graphics/Matrix;I)F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->o:[F

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->getValues([F)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->o:[F

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    aget p1, p1, p2

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return p1
.end method

.method private R()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->B:F

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/photoview/k;->j0(F)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->E()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->V(Landroid/graphics/Matrix;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->A()Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method private V(Landroid/graphics/Matrix;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->p:Lcom/luck/picture/lib/photoview/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/k;->D(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->p:Lcom/luck/picture/lib/photoview/d;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/luck/picture/lib/photoview/d;->a(Landroid/graphics/RectF;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/b;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic b(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/i;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->x:Lcom/luck/picture/lib/photoview/i;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic c(Lcom/luck/picture/lib/photoview/k;Landroid/widget/ImageView;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/k;->H(Landroid/widget/ImageView;)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic d(Lcom/luck/picture/lib/photoview/k;Landroid/widget/ImageView;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/k;->G(Landroid/widget/ImageView;)I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic e(Lcom/luck/picture/lib/photoview/k;)F
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p0, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic f(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/g;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->v:Lcom/luck/picture/lib/photoview/g;

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic g(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnLongClickListener;
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->u:Landroid/view/View$OnLongClickListener;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic h(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/h;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->w:Lcom/luck/picture/lib/photoview/h;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic i(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnClickListener;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->t:Landroid/view/View$OnClickListener;

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic j(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/j;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->s:Lcom/luck/picture/lib/photoview/j;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic k(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/f;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->q:Lcom/luck/picture/lib/photoview/f;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic l(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/e;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->r:Lcom/luck/picture/lib/photoview/e;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic m(Lcom/luck/picture/lib/photoview/k;)Landroid/graphics/Matrix;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic n(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/c;
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->E:Lcom/luck/picture/lib/photoview/c;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic o(Lcom/luck/picture/lib/photoview/k;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget p0, p0, Lcom/luck/picture/lib/photoview/k;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic p(Lcom/luck/picture/lib/photoview/k;)Landroid/view/animation/Interpolator;
    .locals 2

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->a:Landroid/view/animation/Interpolator;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic q(Lcom/luck/picture/lib/photoview/k;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic s(Lcom/luck/picture/lib/photoview/k;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/luck/picture/lib/photoview/k;->f:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic t(Lcom/luck/picture/lib/photoview/k;)Z
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/luck/picture/lib/photoview/k;->g:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic u(Lcom/luck/picture/lib/photoview/k;)I
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget p0, p0, Lcom/luck/picture/lib/photoview/k;->z:I

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p0
.end method

.method private u0(Landroid/graphics/drawable/Drawable;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x4

    if-nez p1, :cond_0

    const/4 v9, 0x2

    return-void

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->H(Landroid/widget/ImageView;)I

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    int-to-float v0, v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {p0, v1}, Lcom/luck/picture/lib/photoview/k;->G(Landroid/widget/ImageView;)I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    int-to-float v1, v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v8, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3}, Landroid/graphics/Matrix;->reset()V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    int-to-float v2, v2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    div-float v3, v0, v2

    const/4 v8, 0x5

    move v9, v8

    int-to-float p1, p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    div-float v4, v1, p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/high16 v7, 0x40000000    # 2.0f

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-ne v5, v6, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x6

    sub-float/2addr v0, v2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    div-float/2addr v0, v7

    const/4 v8, 0x1

    move v9, v8

    sub-float/2addr v1, p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    div-float/2addr v1, v7

    const/4 v8, 0x7

    shl-int/2addr v9, v8

    invoke-virtual {v3, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-ne v5, v6, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v4, v3, v3}, Landroid/graphics/Matrix;->postScale(FF)Z

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    mul-float/2addr v2, v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    sub-float/2addr v0, v2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    div-float/2addr v0, v7

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    mul-float/2addr p1, v3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    sub-float/2addr v1, p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    div-float/2addr v1, v7

    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-virtual {v4, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-ne v5, v6, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v5, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v4, v3, v3}, Landroid/graphics/Matrix;->postScale(FF)Z

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v4, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    mul-float/2addr v2, v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    sub-float/2addr v0, v2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    div-float/2addr v0, v7

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    mul-float/2addr p1, v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    sub-float/2addr v1, p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    div-float/2addr v1, v7

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v4, v0, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    new-instance v3, Landroid/graphics/RectF;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-direct {v3, v4, v4, v2, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    new-instance v5, Landroid/graphics/RectF;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {v5, v4, v4, v0, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->B:F

    const/4 v8, 0x4

    move v9, v8

    float-to-int v0, v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    rem-int/lit16 v0, v0, 0xb4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v0, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance v3, Landroid/graphics/RectF;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v3, v4, v4, p1, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    sget-object p1, Lcom/luck/picture/lib/photoview/k$d;->a:[I

    const/4 v9, 0x7

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v9, 0x5

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    aget p1, p1, v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v0, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    if-eq p1, v0, :cond_8

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v0, 0x2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eq p1, v0, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v0, 0x3

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eq p1, v0, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v0, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eq p1, v0, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_0

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->FILL:Landroid/graphics/Matrix$ScaleToFit;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p1, v3, v5, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    const/4 v9, 0x4

    const/4 v8, 0x4

    goto :goto_0

    :cond_6
    const/4 v9, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->END:Landroid/graphics/Matrix$ScaleToFit;

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    invoke-virtual {p1, v3, v5, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto :goto_0

    :cond_7
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->START:Landroid/graphics/Matrix$ScaleToFit;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1, v3, v5, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto :goto_0

    :cond_8
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->k:Landroid/graphics/Matrix;

    const/4 v8, 0x4

    const/4 v9, 0x6

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p1, v3, v5, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->R()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-void
.end method

.method static synthetic v(Lcom/luck/picture/lib/photoview/k;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p0, p0, Lcom/luck/picture/lib/photoview/k;->A:I

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic w(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/k$f;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/k;->y:Lcom/luck/picture/lib/photoview/k$f;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic x(Lcom/luck/picture/lib/photoview/k;Lcom/luck/picture/lib/photoview/k$f;)Lcom/luck/picture/lib/photoview/k$f;
    .locals 2

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->y:Lcom/luck/picture/lib/photoview/k$f;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method private y()V
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->y:Lcom/luck/picture/lib/photoview/k$f;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k$f;->a()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/k;->y:Lcom/luck/picture/lib/photoview/k$f;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method private z()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->A()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->E()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->V(Landroid/graphics/Matrix;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public B(Landroid/graphics/Matrix;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->E()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public C()Landroid/graphics/RectF;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->A()Z

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->E()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->D(Landroid/graphics/Matrix;)Landroid/graphics/RectF;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public F()Landroid/graphics/Matrix;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->l:Landroid/graphics/Matrix;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public I()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public J()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    return v0
.end method

.method public K()F
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public L()F
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {p0, v0, v1}, Lcom/luck/picture/lib/photoview/k;->O(Landroid/graphics/Matrix;I)F

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    float-to-double v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    double-to-float v0, v0

    const/4 v6, 0x4

    move v7, v6

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v4, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p0, v1, v4}, Lcom/luck/picture/lib/photoview/k;->O(Landroid/graphics/Matrix;I)F

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    float-to-double v4, v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    double-to-float v1, v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-float/2addr v0, v1

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    float-to-double v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    double-to-float v0, v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    return v0
.end method

.method public M()Landroid/widget/ImageView$ScaleType;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public N(Landroid/graphics/Matrix;)V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v2, 0x5

    return-void
.end method

.method public P()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v1, 0x7

    const/4 v1, 0x6

    return v0
.end method

.method public Q()Z
    .locals 3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public S(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/luck/picture/lib/photoview/k;->f:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public T(F)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/high16 v0, 0x43b40000    # 360.0f

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    rem-float/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->B:F

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->t0()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget p1, p0, Lcom/luck/picture/lib/photoview/k;->B:F

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/photoview/k;->j0(F)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    const/4 v2, 0x5

    return-void
.end method

.method public U(Landroid/graphics/Matrix;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p1

    :cond_1
    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "arsm i cte xanunlMtln"

    const-string v0, " asrt cltnueoxin Maln"

    const/4 v2, 0x2

    const-string v0, " a ionatxM lbtcnerlon"

    const-string v0, "Matrix cannot be null"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    throw p1
.end method

.method public W(F)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    iget v1, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, v1, p1}, Lcom/luck/picture/lib/photoview/l;->a(FFF)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public X(F)V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, p1, v1}, Lcom/luck/picture/lib/photoview/l;->a(FFF)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    return-void
.end method

.method public Y(F)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, v0, v1}, Lcom/luck/picture/lib/photoview/l;->a(FFF)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public Z(Landroid/view/View$OnClickListener;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->t:Landroid/view/View$OnClickListener;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public a0(Landroid/view/GestureDetector$OnDoubleTapListener;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->i:Landroid/view/GestureDetector;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Landroid/view/GestureDetector;->setOnDoubleTapListener(Landroid/view/GestureDetector$OnDoubleTapListener;)V

    const/4 v2, 0x1

    return-void
.end method

.method public b0(Landroid/view/View$OnLongClickListener;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->u:Landroid/view/View$OnLongClickListener;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public c0(Lcom/luck/picture/lib/photoview/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->p:Lcom/luck/picture/lib/photoview/d;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public d0(Lcom/luck/picture/lib/photoview/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->r:Lcom/luck/picture/lib/photoview/e;

    const/4 v1, 0x1

    return-void
.end method

.method public e0(Lcom/luck/picture/lib/photoview/f;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->q:Lcom/luck/picture/lib/photoview/f;

    const/4 v1, 0x4

    return-void
.end method

.method public f0(Lcom/luck/picture/lib/photoview/g;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->v:Lcom/luck/picture/lib/photoview/g;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public g0(Lcom/luck/picture/lib/photoview/h;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->w:Lcom/luck/picture/lib/photoview/h;

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-void
.end method

.method public h0(Lcom/luck/picture/lib/photoview/i;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->x:Lcom/luck/picture/lib/photoview/i;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public i0(Lcom/luck/picture/lib/photoview/j;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->s:Lcom/luck/picture/lib/photoview/j;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public j0(F)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/high16 v1, 0x43b40000    # 360.0f

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    rem-float/2addr p1, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->postRotate(F)Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public k0(F)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/high16 v1, 0x43b40000    # 360.0f

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    rem-float/2addr p1, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->setRotate(F)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public l0(F)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/luck/picture/lib/photoview/k;->n0(FZ)V

    const/4 v2, 0x2

    return-void
.end method

.method public m0(FFFZ)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    cmpg-float v0, p1, v0

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ltz v0, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    iget v0, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    cmpl-float v0, p1, v0

    const/4 v7, 0x5

    move v8, v7

    if-gtz v0, :cond_1

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    if-eqz p4, :cond_0

    const/4 v7, 0x3

    move v8, v7

    iget-object p4, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v6, Lcom/luck/picture/lib/photoview/k$e;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v2

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    move v3, p1

    move v3, p1

    const/4 v8, 0x1

    move v3, p1

    move v3, p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v4, p2

    move v4, p2

    const/4 v8, 0x1

    move v4, p2

    move v4, p2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    move v5, p3

    move v5, p3

    const/4 v8, 0x1

    move v5, p3

    move v5, p3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/luck/picture/lib/photoview/k$e;-><init>(Lcom/luck/picture/lib/photoview/k;FFFF)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p4, v6}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object p4, p0, Lcom/luck/picture/lib/photoview/k;->m:Landroid/graphics/Matrix;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p4, p1, p1, p2, p3}, Landroid/graphics/Matrix;->setScale(FFFF)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->z()V

    :goto_0
    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x4

    const-string p2, "acaelblnaiec  omuemSchi Swfnnb eg dt t tm  raenaemhxisS"

    const-string p2, "ahemw ntasSb olSnxiSefg tnr tmeca ecehd mminel uaaac  i"

    const/4 v8, 0x3

    const-string p2, "emsSmou tie xm ad bc euthahigenacreana  aecl n tfwlSlSn"

    const-string p2, "Scale must be within the range of minScale and maxScale"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    throw p1
.end method

.method public n0(FZ)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    div-int/lit8 v0, v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    int-to-float v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getBottom()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    int-to-float v1, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, p1, v0, v1, p2}, Lcom/luck/picture/lib/photoview/k;->m0(FFFZ)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public o0(FFF)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1, p2, p3}, Lcom/luck/picture/lib/photoview/l;->a(FFF)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p2, p0, Lcom/luck/picture/lib/photoview/k;->d:F

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p3, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-ne p2, p6, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-ne p3, p7, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-ne p4, p8, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eq p5, p9, :cond_1

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/k;->u0(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v1, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v0, :cond_9

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    check-cast v0, Landroid/widget/ImageView;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/l;->c(Landroid/widget/ImageView;)Z

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v0, :cond_9

    const/4 v10, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v2, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-eqz v0, :cond_2

    const/4 v11, 0x1

    if-eq v0, v2, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eq v0, v3, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget v3, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    cmpg-float v0, v0, v3

    const/4 v11, 0x0

    const/4 v10, 0x5

    if-gez v0, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->C()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-eqz v0, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    new-instance v9, Lcom/luck/picture/lib/photoview/k$e;

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v5

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget v6, p0, Lcom/luck/picture/lib/photoview/k;->c:F

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v7

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v8

    move-object v3, v9

    move-object v3, v9

    move-object v3, v9

    move-object v3, v9

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v11, 0x3

    const/4 v10, 0x4

    invoke-direct/range {v3 .. v8}, Lcom/luck/picture/lib/photoview/k$e;-><init>(Lcom/luck/picture/lib/photoview/k;FFFF)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p1, v9}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    goto :goto_0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    iget v3, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    cmpl-float v0, v0, v3

    const/4 v11, 0x0

    if-lez v0, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->C()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eqz v0, :cond_4

    const/4 v11, 0x5

    new-instance v9, Lcom/luck/picture/lib/photoview/k$e;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget v6, p0, Lcom/luck/picture/lib/photoview/k;->e:F

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v7

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v8

    move-object v3, v9

    move-object v3, v9

    move-object v3, v9

    move-object v3, v9

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct/range {v3 .. v8}, Lcom/luck/picture/lib/photoview/k$e;-><init>(Lcom/luck/picture/lib/photoview/k;FFFF)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1, v9}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    move p1, v2

    move p1, v2

    const/4 v11, 0x5

    move p1, v2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto :goto_2

    :cond_2
    const/4 v11, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-eqz p1, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-interface {p1, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->y()V

    :cond_4
    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    move p1, v1

    move p1, v1

    const/4 v11, 0x4

    move p1, v1

    move p1, v1

    :goto_2
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eqz v0, :cond_8

    const/4 v10, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/b;->e()Z

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v11, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/b;->d()Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-object v3, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-virtual {v3, p2}, Lcom/luck/picture/lib/photoview/b;->f(Landroid/view/MotionEvent;)Z

    move-result v3

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-nez p1, :cond_5

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/photoview/b;->e()Z

    move-result p1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-nez p1, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    move p1, v2

    move p1, v2

    const/4 v11, 0x4

    move p1, v2

    move p1, v2

    const/4 v10, 0x4

    const/4 v10, 0x7

    goto :goto_3

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    move p1, v1

    move p1, v1

    const/4 v11, 0x4

    move p1, v1

    move p1, v1

    :goto_3
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-nez v0, :cond_6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->j:Lcom/luck/picture/lib/photoview/b;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/b;->d()Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-nez v0, :cond_6

    const/4 v11, 0x7

    const/4 v10, 0x0

    move v0, v2

    move v0, v2

    const/4 v11, 0x1

    move v0, v2

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto :goto_4

    :cond_6
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    move v0, v1

    move v0, v1

    const/4 v11, 0x0

    move v0, v1

    move v0, v1

    :goto_4
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz p1, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v0, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    move v1, v2

    const/4 v11, 0x7

    move v1, v2

    move v1, v2

    :cond_7
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    iput-boolean v1, p0, Lcom/luck/picture/lib/photoview/k;->g:Z

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    move v1, v3

    move v1, v3

    const/4 v11, 0x5

    move v1, v3

    move v1, v3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_5

    :cond_8
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    move v1, p1

    move v1, p1

    const/4 v11, 0x6

    move v1, p1

    move v1, p1

    :goto_5
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k;->i:Landroid/view/GestureDetector;

    const/4 v10, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eqz p1, :cond_9

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p1, p2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz p1, :cond_9

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    move v1, v2

    move v1, v2

    const/4 v11, 0x2

    move v1, v2

    :cond_9
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    return v1
.end method

.method public p0(Landroid/widget/ImageView$ScaleType;)V
    .locals 3

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/l;->d(Landroid/widget/ImageView$ScaleType;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->D:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->t0()V

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public q0(Landroid/view/animation/Interpolator;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k;->a:Landroid/view/animation/Interpolator;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public r0(I)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/photoview/k;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public s0(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/photoview/k;->t0()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public t0()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/k;->C:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k;->h:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/photoview/k;->u0(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k;->R()V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method
