.class Lcom/luck/picture/lib/photoview/k$b;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/photoview/k;-><init>(Landroid/widget/ImageView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/photoview/k;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/photoview/k;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@us~rm@ K ~ ~/@~  o @oy@l~@i@~~c~ 1~@~~d@@ ~i~ @ ~v 4@o@~@ b~~oo~ /~ @i@.l s@~~fb@taofM~ nb@@t -"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->h(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/h;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    cmpl-float v0, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-lez v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v2, 0x1

    move v4, v2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-gt v0, v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-le v0, v2, :cond_1

    const/4 v3, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->h(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/h;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/luck/picture/lib/photoview/h;->onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p1

    :cond_2
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v1
.end method

.method public onLongPress(Landroid/view/MotionEvent;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->g(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnLongClickListener;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/photoview/k;->g(Lcom/luck/picture/lib/photoview/k;)Landroid/view/View$OnLongClickListener;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$b;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {p1, v0}, Landroid/view/View$OnLongClickListener;->onLongClick(Landroid/view/View;)Z

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method
