.class Lcom/luck/picture/lib/photoview/b;
.super Ljava/lang/Object;


# static fields
.field private static final k:I = -0x1


# instance fields
.field private a:I

.field private b:I

.field private final c:Landroid/view/ScaleGestureDetector;

.field private d:Landroid/view/VelocityTracker;

.field private e:Z

.field private f:F

.field private g:F

.field private final h:F

.field private final i:F

.field private j:Lcom/luck/picture/lib/photoview/c;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/luck/picture/lib/photoview/c;)V
    .locals 4

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v0, -0x2

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->b:I

    const/4 v2, 0x2

    move v3, v2

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-float v1, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput v1, p0, Lcom/luck/picture/lib/photoview/b;->i:F

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    int-to-float v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->h:F

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/photoview/b;->j:Lcom/luck/picture/lib/photoview/c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p2, Lcom/luck/picture/lib/photoview/b$a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p2, p0}, Lcom/luck/picture/lib/photoview/b$a;-><init>(Lcom/luck/picture/lib/photoview/b;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Landroid/view/ScaleGestureDetector;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, p1, p2}, Landroid/view/ScaleGestureDetector;-><init>(Landroid/content/Context;Landroid/view/ScaleGestureDetector$OnScaleGestureListener;)V

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/b;->c:Landroid/view/ScaleGestureDetector;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/photoview/b;)Lcom/luck/picture/lib/photoview/c;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "sbs@ ~b@  4@@~~ymi ~@S~ clo~~o~a.~f~1n/to@i@-~ @/~Mv~  @~o~@~dr @ @ ~ o ~@t@i@@~o u@lb ~@~@K@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/photoview/b;->j:Lcom/luck/picture/lib/photoview/c;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method private b(Landroid/view/MotionEvent;)F
    .locals 3

    :try_start_0
    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/photoview/b;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1

    :catch_0
    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p1
.end method

.method private c(Landroid/view/MotionEvent;)F
    .locals 3

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/photoview/b;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1
.end method

.method private g(Landroid/view/MotionEvent;)Z
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    and-int/lit16 v0, v0, 0xff

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v1, -0x1

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/4 v3, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-eqz v0, :cond_8

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    const/4 v4, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-eq v0, v2, :cond_6

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    const/4 v5, 0x2

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-eq v0, v5, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/4 v5, 0x3

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x2

    if-eq v0, v5, :cond_2

    const/4 v11, 0x2

    move v12, v11

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eq v0, v4, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    goto/16 :goto_2

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/l;->b(I)I

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v4

    const/4 v12, 0x0

    const/4 v11, 0x3

    iget v5, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    if-ne v4, v5, :cond_a

    const/4 v12, 0x5

    const/4 v11, 0x0

    if-nez v0, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x0

    move v0, v2

    move v0, v2

    const/4 v12, 0x4

    move v0, v2

    move v0, v2

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto :goto_0

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    move v0, v3

    move v0, v3

    const/4 v12, 0x2

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    iput v4, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v4

    const/4 v12, 0x4

    const/4 v11, 0x7

    iput v4, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x4

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    goto/16 :goto_2

    :cond_2
    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    iput v1, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eqz v0, :cond_a

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x7

    iput-object v4, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    goto/16 :goto_2

    :cond_3
    const/4 v12, 0x2

    const/4 v11, 0x0

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->b(Landroid/view/MotionEvent;)F

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->c(Landroid/view/MotionEvent;)F

    move-result v4

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget v5, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    sub-float v5, v0, v5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v6, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    sub-float v6, v4, v6

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-boolean v7, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    if-nez v7, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x2

    mul-float v7, v5, v5

    const/4 v11, 0x0

    xor-int/2addr v12, v11

    mul-float v8, v6, v6

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    add-float/2addr v7, v8

    const/4 v11, 0x0

    move v12, v11

    float-to-double v7, v7

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v7

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget v9, p0, Lcom/luck/picture/lib/photoview/b;->h:F

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    float-to-double v9, v9

    const/4 v12, 0x3

    const/4 v11, 0x1

    cmpl-double v7, v7, v9

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-ltz v7, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    move v7, v2

    move v7, v2

    const/4 v12, 0x5

    move v7, v2

    move v7, v2

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    goto :goto_1

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    move v7, v3

    move v7, v3

    const/4 v12, 0x1

    move v7, v3

    move v7, v3

    :goto_1
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    iput-boolean v7, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    :cond_5
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-boolean v7, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-eqz v7, :cond_a

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v7, p0, Lcom/luck/picture/lib/photoview/b;->j:Lcom/luck/picture/lib/photoview/c;

    const/4 v11, 0x5

    const/4 v11, 0x2

    invoke-interface {v7, v5, v6}, Lcom/luck/picture/lib/photoview/c;->a(FF)V

    const/4 v12, 0x5

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v11, 0x7

    move v12, v11

    iput v4, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-eqz v0, :cond_a

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    const/4 v12, 0x6

    goto/16 :goto_2

    :cond_6
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput v1, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-eqz v0, :cond_7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-eqz v0, :cond_7

    const/4 v12, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->b(Landroid/view/MotionEvent;)F

    move-result v0

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->c(Landroid/view/MotionEvent;)F

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/16 v5, 0x3e8

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v0, v5}, Landroid/view/VelocityTracker;->computeCurrentVelocity(I)V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->getXVelocity()F

    move-result v0

    const/4 v12, 0x4

    const/4 v11, 0x5

    iget-object v5, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v5}, Landroid/view/VelocityTracker;->getYVelocity()F

    move-result v5

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v6

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v7

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    move-result v6

    const/4 v12, 0x6

    const/4 v11, 0x6

    iget v7, p0, Lcom/luck/picture/lib/photoview/b;->i:F

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    cmpl-float v6, v6, v7

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-ltz v6, :cond_7

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v6, p0, Lcom/luck/picture/lib/photoview/b;->j:Lcom/luck/picture/lib/photoview/c;

    const/4 v11, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget v7, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget v8, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v11, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    neg-float v0, v0

    const/4 v11, 0x1

    const/4 v12, 0x0

    neg-float v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-interface {v6, v7, v8, v0, v5}, Lcom/luck/picture/lib/photoview/c;->d(FFFF)V

    :cond_7
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    if-eqz v0, :cond_a

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    const/4 v12, 0x3

    const/4 v11, 0x2

    iput-object v4, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    goto :goto_2

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/b;->d:Landroid/view/VelocityTracker;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-eqz v0, :cond_9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v0, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    :cond_9
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->b(Landroid/view/MotionEvent;)F

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->f:F

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->c(Landroid/view/MotionEvent;)F

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    iput v0, p0, Lcom/luck/picture/lib/photoview/b;->g:F

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    iput-boolean v3, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    :cond_a
    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget v0, p0, Lcom/luck/picture/lib/photoview/b;->a:I

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-eq v0, v1, :cond_b

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    move v3, v0

    const/4 v12, 0x2

    move v3, v0

    move v3, v0

    :cond_b
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {p1, v3}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result p1

    const/4 v12, 0x7

    const/4 v11, 0x2

    iput p1, p0, Lcom/luck/picture/lib/photoview/b;->b:I

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    return v2
.end method


# virtual methods
.method public d()Z
    .locals 3

    const/4 v1, 0x4

    iget-boolean v0, p0, Lcom/luck/picture/lib/photoview/b;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public e()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->c:Landroid/view/ScaleGestureDetector;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/view/ScaleGestureDetector;->isInProgress()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public f(Landroid/view/MotionEvent;)Z
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/b;->c:Landroid/view/ScaleGestureDetector;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/view/ScaleGestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/photoview/b;->g(Landroid/view/MotionEvent;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1

    :catch_0
    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x2

    move v1, p1

    move v1, p1

    const/4 v2, 0x6

    return p1
.end method
