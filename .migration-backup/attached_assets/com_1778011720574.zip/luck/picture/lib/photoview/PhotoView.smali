.class public Lcom/luck/picture/lib/photoview/PhotoView;
.super Landroidx/appcompat/widget/AppCompatImageView;


# instance fields
.field private a:Lcom/luck/picture/lib/photoview/k;

.field private b:Landroid/widget/ImageView$ScaleType;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/photoview/PhotoView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, v0}, Lcom/luck/picture/lib/photoview/PhotoView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/PhotoView;->e()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method private e()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s@~ a1~u@r n~-ob @~@  ~ d f@~l ~~@@lb@~ oit~ @@4   o~~~@~ovmo@@~scM~t~f@K@b@~/@ /@y ~o@~S.i@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/photoview/k;-><init>(Landroid/widget/ImageView;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Landroid/widget/ImageView$ScaleType;->MATRIX:Landroid/widget/ImageView$ScaleType;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-super {p0, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->b:Landroid/widget/ImageView$ScaleType;

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->b:Landroid/widget/ImageView$ScaleType;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public b(Landroid/graphics/Matrix;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->B(Landroid/graphics/Matrix;)V

    const/4 v2, 0x2

    return-void
.end method

.method public d(Landroid/graphics/Matrix;)V
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->N(Landroid/graphics/Matrix;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->Q()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public g(Landroid/graphics/Matrix;)Z
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->U(Landroid/graphics/Matrix;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method public getAttacher()Lcom/luck/picture/lib/photoview/k;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x6

    move v2, v1

    return-object v0
.end method

.method public getDisplayRect()Landroid/graphics/RectF;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->C()Landroid/graphics/RectF;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public getImageMatrix()Landroid/graphics/Matrix;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->F()Landroid/graphics/Matrix;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public getMaximumScale()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->I()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public getMediumScale()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->J()F

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getMinimumScale()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->K()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public getScale()F
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getScaleType()Landroid/widget/ImageView$ScaleType;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/photoview/k;->M()Landroid/widget/ImageView$ScaleType;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public h(FFFZ)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/luck/picture/lib/photoview/k;->m0(FFFZ)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public i(FZ)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/luck/picture/lib/photoview/k;->n0(FZ)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public j(FFF)V
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2, p3}, Lcom/luck/picture/lib/photoview/k;->o0(FFF)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public k(Landroid/graphics/Matrix;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->U(Landroid/graphics/Matrix;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1
.end method

.method public setAllowParentInterceptOnEdge(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->S(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method protected setFrame(IIII)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->setFrame(IIII)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/photoview/k;->t0()V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/photoview/k;->t0()V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public setImageResource(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatImageView;->setImageResource(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v0, 0x3

    move v1, v0

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/photoview/k;->t0()V

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setImageURI(Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatImageView;->setImageURI(Landroid/net/Uri;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/photoview/k;->t0()V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setMaximumScale(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->W(F)V

    const/4 v2, 0x1

    return-void
.end method

.method public setMediumScale(F)V
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->X(F)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setMinimumScale(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->Y(F)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public setOnClickListener(Landroid/view/View$OnClickListener;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->Z(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public setOnDoubleTapListener(Landroid/view/GestureDetector$OnDoubleTapListener;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->a0(Landroid/view/GestureDetector$OnDoubleTapListener;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->b0(Landroid/view/View$OnLongClickListener;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public setOnMatrixChangeListener(Lcom/luck/picture/lib/photoview/d;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->c0(Lcom/luck/picture/lib/photoview/d;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public setOnOutsidePhotoTapListener(Lcom/luck/picture/lib/photoview/e;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->d0(Lcom/luck/picture/lib/photoview/e;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setOnPhotoTapListener(Lcom/luck/picture/lib/photoview/f;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->e0(Lcom/luck/picture/lib/photoview/f;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public setOnScaleChangeListener(Lcom/luck/picture/lib/photoview/g;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->f0(Lcom/luck/picture/lib/photoview/g;)V

    const/4 v2, 0x0

    return-void
.end method

.method public setOnSingleFlingListener(Lcom/luck/picture/lib/photoview/h;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->g0(Lcom/luck/picture/lib/photoview/h;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public setOnViewDragListener(Lcom/luck/picture/lib/photoview/i;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->h0(Lcom/luck/picture/lib/photoview/i;)V

    const/4 v2, 0x7

    return-void
.end method

.method public setOnViewTapListener(Lcom/luck/picture/lib/photoview/j;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->i0(Lcom/luck/picture/lib/photoview/j;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public setRotationBy(F)V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->j0(F)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setRotationTo(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->k0(F)V

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public setScale(F)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->l0(F)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public setScaleType(Landroid/widget/ImageView$ScaleType;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/PhotoView;->b:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->p0(Landroid/widget/ImageView$ScaleType;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public setZoomTransitionDuration(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->r0(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public setZoomable(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/PhotoView;->a:Lcom/luck/picture/lib/photoview/k;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/k;->s0(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method
