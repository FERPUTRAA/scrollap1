.class Lcom/luck/picture/lib/photoview/k$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/photoview/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "e"
.end annotation


# instance fields
.field private final a:F

.field private final b:F

.field private final c:J

.field private final d:F

.field private final e:F

.field final synthetic f:Lcom/luck/picture/lib/photoview/k;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/photoview/k;FFFF)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p4, p0, Lcom/luck/picture/lib/photoview/k$e;->a:F

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p5, p0, Lcom/luck/picture/lib/photoview/k$e;->b:F

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p4

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-wide p4, p0, Lcom/luck/picture/lib/photoview/k$e;->c:J

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput p2, p0, Lcom/luck/picture/lib/photoview/k$e;->d:F

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p3, p0, Lcom/luck/picture/lib/photoview/k$e;->e:F

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private a()F
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "ots~@il@-@@@b~@~~ ty @@ ~1 4m~@~v~sM   @ @~o~  ib~/~ d@~i~@ o@K~~ ~nbo.~ rou @~l @ c~S~@/@f~o@f@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/luck/picture/lib/photoview/k$e;->c:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    sub-long/2addr v0, v2

    const/4 v5, 0x6

    long-to-float v0, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    mul-float/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->o(Lcom/luck/picture/lib/photoview/k;)I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    int-to-float v2, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    div-float/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/photoview/k;->p(Lcom/luck/picture/lib/photoview/k;)Landroid/view/animation/Interpolator;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v1, v0}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    return v0
.end method


# virtual methods
.method public run()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/photoview/k$e;->a()F

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget v1, p0, Lcom/luck/picture/lib/photoview/k$e;->d:F

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget v2, p0, Lcom/luck/picture/lib/photoview/k$e;->e:F

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    sub-float/2addr v2, v1

    const/4 v5, 0x3

    move v6, v5

    mul-float/2addr v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-float/2addr v1, v2

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/luck/picture/lib/photoview/k;->L()F

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    div-float/2addr v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/photoview/k;->n(Lcom/luck/picture/lib/photoview/k;)Lcom/luck/picture/lib/photoview/c;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v3, p0, Lcom/luck/picture/lib/photoview/k$e;->a:F

    iget v4, p0, Lcom/luck/picture/lib/photoview/k$e;->b:F

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v2, v1, v3, v4}, Lcom/luck/picture/lib/photoview/c;->c(FFF)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    cmpg-float v0, v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-gez v0, :cond_0

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/photoview/k$e;->f:Lcom/luck/picture/lib/photoview/k;

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/photoview/k;->r(Lcom/luck/picture/lib/photoview/k;)Landroid/widget/ImageView;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, p0}, Lcom/luck/picture/lib/photoview/a;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method
