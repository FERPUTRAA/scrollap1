.class public final Lcom/luck/picture/lib/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0c0000

.field public static final abc_action_bar_up_container:I = 0x7f0c0001

.field public static final abc_action_menu_item_layout:I = 0x7f0c0002

.field public static final abc_action_menu_layout:I = 0x7f0c0003

.field public static final abc_action_mode_bar:I = 0x7f0c0004

.field public static final abc_action_mode_close_item_material:I = 0x7f0c0005

.field public static final abc_activity_chooser_view:I = 0x7f0c0006

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0c0007

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0c0008

.field public static final abc_alert_dialog_material:I = 0x7f0c0009

.field public static final abc_alert_dialog_title_material:I = 0x7f0c000a

.field public static final abc_cascading_menu_item_layout:I = 0x7f0c000b

.field public static final abc_dialog_title_material:I = 0x7f0c000c

.field public static final abc_expanded_menu_layout:I = 0x7f0c000d

.field public static final abc_list_menu_item_checkbox:I = 0x7f0c000e

.field public static final abc_list_menu_item_icon:I = 0x7f0c000f

.field public static final abc_list_menu_item_layout:I = 0x7f0c0010

.field public static final abc_list_menu_item_radio:I = 0x7f0c0011

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0c0012

.field public static final abc_popup_menu_item_layout:I = 0x7f0c0013

.field public static final abc_screen_content_include:I = 0x7f0c0014

.field public static final abc_screen_simple:I = 0x7f0c0015

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0c0016

.field public static final abc_screen_toolbar:I = 0x7f0c0017

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0c0018

.field public static final abc_search_view:I = 0x7f0c0019

.field public static final abc_select_dialog_material:I = 0x7f0c001a

.field public static final abc_tooltip:I = 0x7f0c001b

.field public static final custom_dialog:I = 0x7f0c0084

.field public static final notification_action:I = 0x7f0c0215

.field public static final notification_action_tombstone:I = 0x7f0c0216

.field public static final notification_media_action:I = 0x7f0c0217

.field public static final notification_media_cancel_action:I = 0x7f0c0218

.field public static final notification_template_big_media:I = 0x7f0c0219

.field public static final notification_template_big_media_custom:I = 0x7f0c021a

.field public static final notification_template_big_media_narrow:I = 0x7f0c021b

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0c021c

.field public static final notification_template_custom_big:I = 0x7f0c021d

.field public static final notification_template_icon_group:I = 0x7f0c021e

.field public static final notification_template_lines_media:I = 0x7f0c021f

.field public static final notification_template_media:I = 0x7f0c0220

.field public static final notification_template_media_custom:I = 0x7f0c0221

.field public static final notification_template_part_chronometer:I = 0x7f0c0222

.field public static final notification_template_part_time:I = 0x7f0c0223

.field public static final ps_activity_container:I = 0x7f0c0242

.field public static final ps_album_folder_item:I = 0x7f0c0243

.field public static final ps_alert_dialog:I = 0x7f0c0244

.field public static final ps_bottom_nav_bar:I = 0x7f0c0245

.field public static final ps_common_dialog:I = 0x7f0c0246

.field public static final ps_complete_selected_layout:I = 0x7f0c0247

.field public static final ps_custom_preview_image:I = 0x7f0c0248

.field public static final ps_dialog_camera_selected:I = 0x7f0c0249

.field public static final ps_empty:I = 0x7f0c024a

.field public static final ps_fragment_preview:I = 0x7f0c024b

.field public static final ps_fragment_selector:I = 0x7f0c024c

.field public static final ps_item_grid_audio:I = 0x7f0c024d

.field public static final ps_item_grid_camera:I = 0x7f0c024e

.field public static final ps_item_grid_image:I = 0x7f0c024f

.field public static final ps_item_grid_video:I = 0x7f0c0250

.field public static final ps_preview_audio:I = 0x7f0c0251

.field public static final ps_preview_gallery_item:I = 0x7f0c0252

.field public static final ps_preview_image:I = 0x7f0c0253

.field public static final ps_preview_video:I = 0x7f0c0254

.field public static final ps_remind_dialog:I = 0x7f0c0255

.field public static final ps_title_bar:I = 0x7f0c0256

.field public static final ps_window_folder:I = 0x7f0c0257

.field public static final select_dialog_item_material:I = 0x7f0c0259

.field public static final select_dialog_multichoice_material:I = 0x7f0c025a

.field public static final select_dialog_singlechoice_material:I = 0x7f0c025b

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0c0260


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-void
.end method
