.class Lcom/luck/picture/lib/d$l;
.super Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public onPageScrolled(IFI)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/sl.@~ t~~f~ ~-S4~@@i@i ~o@u ~@@l @~o bo~1s~~c  @Matfv~ @@@b  @~~~o@bid~@  @~ ~n r Ko~/@@~ ~@mo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p2, p2, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-le p2, p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p2, Lcom/luck/picture/lib/d;->C:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    div-int/lit8 v0, v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p2, p2, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-ge p3, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    add-int/lit8 p1, p1, 0x1

    :goto_0
    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p3, p2, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/d;->O1(Lcom/luck/picture/lib/entity/LocalMedia;)Z

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lcom/luck/picture/lib/d;->v1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/d;->U1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public onPageSelected(I)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput p1, v0, Lcom/luck/picture/lib/d;->s:I

    const/4 v5, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v2, v2, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    const/4 v3, 0x1

    move v5, v3

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/2addr v2, v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "/"

    const-string v2, "/"

    const/4 v5, 0x5

    const-string v2, "/"

    const-string v2, "/"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x6

    iget v2, v2, Lcom/luck/picture/lib/d;->B:I

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-le v0, p1, :cond_6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/d;->U1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/d;->j1(Lcom/luck/picture/lib/d;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1, p1}, Lcom/luck/picture/lib/d;->k1(Lcom/luck/picture/lib/d;I)V

    :cond_0
    const/4 v4, 0x7

    move v5, v4

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/d;->l1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-boolean v2, v1, Lcom/luck/picture/lib/d;->u:Z

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-boolean v2, v1, Lcom/luck/picture/lib/d;->t:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, p1}, Lcom/luck/picture/lib/adapter/c;->h(I)V

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/luck/picture/lib/d;->v1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    move v0, v3

    move v0, v3

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;->i(Z)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v1, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v5, 0x6

    if-nez v1, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/d;->m1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v0, :cond_6

    const/4 v4, 0x4

    and-int/2addr v5, v4

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/d;->n1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->r:Z

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v1, :cond_6

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/c;->getItemCount()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    sub-int/2addr v0, v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v0, v0, -0xa

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq p1, v0, :cond_5

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/c;->getItemCount()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    sub-int/2addr v0, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ne p1, v0, :cond_6

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/d$l;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/d;->o1(Lcom/luck/picture/lib/d;)V

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method
