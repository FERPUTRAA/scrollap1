.class Lcom/luck/picture/lib/d$m;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->x1(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:[I

.field final synthetic c:I

.field final synthetic d:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;[II)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d$m;->d:Lcom/luck/picture/lib/d;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/luck/picture/lib/d$m;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/luck/picture/lib/d$m;->b:[I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p4, p0, Lcom/luck/picture/lib/d$m;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    check-cast p1, Landroid/graphics/Bitmap;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/d$m;->b(Landroid/graphics/Bitmap;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public b(Landroid/graphics/Bitmap;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->d:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->Y1(I)V

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->U1(I)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/i;->q(II)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d$m;->b:[I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->d:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v3, v0, Lcom/luck/picture/lib/d;->C:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput v3, p1, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, v0, Lcom/luck/picture/lib/d;->D:I

    const/4 v5, 0x1

    aput v0, p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->b:[I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    aput v3, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->b:[I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    aput p1, v0, v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d$m;->d:Lcom/luck/picture/lib/d;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$m;->b:[I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    aget v2, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    aget v0, v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v1, p0, Lcom/luck/picture/lib/d$m;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1, v2, v0, v1}, Lcom/luck/picture/lib/d;->p1(Lcom/luck/picture/lib/d;III)V

    const/4 v5, 0x0

    return-void
.end method
