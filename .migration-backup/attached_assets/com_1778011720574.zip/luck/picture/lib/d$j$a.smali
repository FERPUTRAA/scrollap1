.class Lcom/luck/picture/lib/d$j$a;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d$j;->a()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d$j;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d$j;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ts/~@~ ~~m~o o @~ ~~1~ @@ i@il@ ~v/@b4o ~bs  Sbc~o@@@~o @~nu@dy@@~ti~@f@l  .f-r  @~o~  ~M@K@a~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/String;

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/d$j$a;->b(Ljava/lang/String;)V

    const/4 v1, 0x1

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 6

    iget-object v0, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->h()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/luck/picture/lib/d$j;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p1, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget v0, Lcom/luck/picture/lib/R$string;->ps_save_audio_error:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/luck/picture/lib/d$j;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz p1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p1, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget v0, Lcom/luck/picture/lib/R$string;->ps_save_video_error:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget v0, Lcom/luck/picture/lib/R$string;->ps_save_image_error:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, v0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0, p1}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    new-instance v0, Lcom/luck/picture/lib/basic/h;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v0, v1, p1}, Lcom/luck/picture/lib/basic/h;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/d$j$a;->a:Lcom/luck/picture/lib/d$j;

    const/4 v5, 0x5

    const/4 v4, 0x1

    iget-object v2, v2, Lcom/luck/picture/lib/d$j;->b:Lcom/luck/picture/lib/d;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget v3, Lcom/luck/picture/lib/R$string;->ps_save_success:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v2, "/n"

    const-string/jumbo v2, "n/"

    const-string v2, "/n"

    const-string v2, "\n"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method
