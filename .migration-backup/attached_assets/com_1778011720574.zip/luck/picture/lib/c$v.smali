.class Lcom/luck/picture/lib/c$v;
.super Lcom/luck/picture/lib/widget/BottomNavBar$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->Y1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/c$v;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/BottomNavBar$b;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f sb@@~@ @~ to~~@~o@t~ ~~n~-~@ii@b @~@1f~~~S~~ @r    @@yo/boi@@@@@/m o~lM l~v~~u@4@.dc aKo ~s ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c$v;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->y()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public d()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c$v;->a:Lcom/luck/picture/lib/c;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1, v2}, Lcom/luck/picture/lib/c;->p1(Lcom/luck/picture/lib/c;IZ)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method
