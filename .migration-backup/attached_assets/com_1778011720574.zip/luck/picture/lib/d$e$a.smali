.class Lcom/luck/picture/lib/d$e$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d$e;->a(ILcom/luck/picture/lib/entity/LocalMedia;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/luck/picture/lib/d$e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d$e;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d$e$a;->b:Lcom/luck/picture/lib/d$e;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p2, p0, Lcom/luck/picture/lib/d$e$a;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$e$a;->b:Lcom/luck/picture/lib/d$e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/d;->w1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$e$a;->b:Lcom/luck/picture/lib/d$e;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v1, p0, Lcom/luck/picture/lib/d$e$a;->a:I

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/c;->h(I)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
