.class Lcom/luck/picture/lib/thread/a$i$a;
.super Ljava/lang/Thread;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/thread/a$i;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/thread/a$i;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/thread/a$i;Ljava/lang/Runnable;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$i$a;->a:Lcom/luck/picture/lib/thread/a$i;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p2, p3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ s s@~o@@a @@ i@~o@ivK@~4~So /tb b o~M@@~~~o@-~mf t ~@~  ~~ni@~~~@.@@  @  ~/bly~f1ol~ @@ru~~d@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-super {p0}, Ljava/lang/Thread;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "dTrmasethsi"

    const-string/jumbo v1, "lrsaedthsiT"

    const/4 v4, 0x6

    const-string v1, "ThreadUtils"

    const/4 v4, 0x3

    const-string/jumbo v2, "tao ohhlceenqg Rbtustuhrmrwutawe"

    const-string v2, "hehmaenc uRthqgtwrotwtserlbu uae"

    const/4 v4, 0x6

    const-string/jumbo v2, "saowtbhuq a etlbcuRwguhehtee rtr"

    const-string v2, "Request threw uncaught throwable"

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method
