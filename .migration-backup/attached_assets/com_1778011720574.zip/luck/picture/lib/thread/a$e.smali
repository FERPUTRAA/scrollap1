.class public abstract Lcom/luck/picture/lib/thread/a$e;
.super Lcom/luck/picture/lib/thread/a$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/thread/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/luck/picture/lib/thread/a$g<",
        "TT;>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$g;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public j()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s~icyf@@~ ol@@~ ~~-~@bo@@bb~n f@1@ m4.@~~@t~d@K~aoo M/ so~@ @@vt@~   ~~~@@/rSi~ u i~~l@ o~ ~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "sCem:cnnol"

    const-string/jumbo v1, "nasn:elcoC"

    const/4 v3, 0x6

    const-string v1, ":oceon nal"

    const-string/jumbo v1, "onCancel: "

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "thaTdbsrUml"

    const-string v1, "UldmirsthTa"

    const/4 v3, 0x4

    const-string v1, "hersdlutaiU"

    const-string v1, "ThreadUtils"

    const/4 v3, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public l(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, "aiTUeosplth"

    const-string v0, "TshrolUeati"

    const/4 v3, 0x0

    const-string/jumbo v0, "rltUhiedqsa"

    const-string v0, "ThreadUtils"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, ":iso aFb"

    const-string v1, "F:io ban"

    const/4 v3, 0x7

    const-string/jumbo v1, "li mnaF:"

    const-string/jumbo v1, "onFail: "

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method
