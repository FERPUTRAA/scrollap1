.class Lcom/luck/picture/lib/thread/a$g$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/thread/a$g;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Object;

.field final synthetic b:Lcom/luck/picture/lib/thread/a$g;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/thread/a$g;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$g$b;->b:Lcom/luck/picture/lib/thread/a$g;

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/thread/a$g$b;->a:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@os  ~~@ iu@@v~ ~~/sS4/  do@@~imn~ o~t   ~ @~o@b@@lb~ @c~o~~ @ @@~y rK@i~@b ~~a-~t~@f.~o@f1~@M @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$b;->b:Lcom/luck/picture/lib/thread/a$g;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/thread/a$g$b;->a:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/thread/a$g;->m(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method
