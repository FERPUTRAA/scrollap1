.class Lcom/luck/picture/lib/thread/a$g$a;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/thread/a$g;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/thread/a$g;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4 sb@~~d @~@@~~S ~. -u@ @ @@v~@s~ @o ~@lnr@i~~@1/@@o/oc~ ~o~t bab@oi ~ Mt~f~~~ lm~~@ i@f @Ky  @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/thread/a$g;->i()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a$g;->b(Lcom/luck/picture/lib/thread/a$g;)Lcom/luck/picture/lib/thread/a$g$f;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a$g;->c(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a$g;->b(Lcom/luck/picture/lib/thread/a$g;)Lcom/luck/picture/lib/thread/a$g$f;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-interface {v0}, Lcom/luck/picture/lib/thread/a$g$f;->onTimeout()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$g$a;->a:Lcom/luck/picture/lib/thread/a$g;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/thread/a$g;->k()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method
