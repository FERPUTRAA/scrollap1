.class Lcom/luck/picture/lib/thread/a$a;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/thread/a;->i(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/ExecutorService;

.field final synthetic b:Lcom/luck/picture/lib/thread/a$g;


# direct methods
.method constructor <init>(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V
    .locals 2

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$a;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/thread/a$a;->b:Lcom/luck/picture/lib/thread/a$g;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "K@sc~t@~~ ~  l i~/r 4~bb@o~-o~  ~~~~~@ @ i~@~@n a1Mf l @ @y ~.v~ou@bf@S/@@@d@so@~@   m~@@o@t~i~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$a;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/thread/a$a;->b:Lcom/luck/picture/lib/thread/a$g;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method
