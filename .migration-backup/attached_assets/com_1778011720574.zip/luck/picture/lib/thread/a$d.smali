.class final Lcom/luck/picture/lib/thread/a$d;
.super Ljava/util/concurrent/LinkedBlockingQueue;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/thread/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/LinkedBlockingQueue<",
        "Ljava/lang/Runnable;",
        ">;"
    }
.end annotation


# instance fields
.field private mCapacity:I

.field private volatile mPool:Lcom/luck/picture/lib/thread/a$h;


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const v0, 0x7fffffff

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Lcom/luck/picture/lib/thread/a$d;->mCapacity:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(I)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    iput p1, p0, Lcom/luck/picture/lib/thread/a$d;->mCapacity:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method constructor <init>(Z)V
    .locals 3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v2, 0x6

    const v0, 0x7fffffff

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Lcom/luck/picture/lib/thread/a$d;->mCapacity:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput p1, p0, Lcom/luck/picture/lib/thread/a$d;->mCapacity:I

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/thread/a$d;Lcom/luck/picture/lib/thread/a$h;)Lcom/luck/picture/lib/thread/a$h;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "oos~@ @@nlbi~~1ao~f~ @v/s~b@@y~~ @@~@~  M~r@~ ~ @o oStl~t~@~ /~u -i@o @K  4@~d@.@ ~b~ @i@fm~c@~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$d;->mPool:Lcom/luck/picture/lib/thread/a$h;

    const/4 v1, 0x1

    return-object p1
.end method


# virtual methods
.method public b(Ljava/lang/Runnable;)Z
    .locals 4
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Lcom/luck/picture/lib/thread/a$d;->mCapacity:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-gt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$d;->mPool:Lcom/luck/picture/lib/thread/a$h;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$d;->mPool:Lcom/luck/picture/lib/thread/a$h;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ThreadPoolExecutor;->getPoolSize()I

    move-result v0

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/thread/a$d;->mPool:Lcom/luck/picture/lib/thread/a$h;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/ThreadPoolExecutor;->getMaximumPoolSize()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-super {p0, p1}, Ljava/util/concurrent/LinkedBlockingQueue;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1
.end method

.method public bridge synthetic offer(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p1, Ljava/lang/Runnable;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/thread/a$d;->b(Ljava/lang/Runnable;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p1
.end method
