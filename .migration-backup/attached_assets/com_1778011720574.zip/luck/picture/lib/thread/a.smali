.class public final Lcom/luck/picture/lib/thread/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/thread/a$f;,
        Lcom/luck/picture/lib/thread/a$g;,
        Lcom/luck/picture/lib/thread/a$e;,
        Lcom/luck/picture/lib/thread/a$i;,
        Lcom/luck/picture/lib/thread/a$d;,
        Lcom/luck/picture/lib/thread/a$h;
    }
.end annotation


# static fields
.field private static final a:Landroid/os/Handler;

.field private static final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/util/concurrent/ExecutorService;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/luck/picture/lib/thread/a$g;",
            "Ljava/util/concurrent/ExecutorService;",
            ">;"
        }
    .end annotation
.end field

.field private static final d:I

.field private static final e:Ljava/util/Timer;

.field private static final f:B = -0x1t

.field private static final g:B = -0x2t

.field private static final h:B = -0x4t

.field private static final i:B = -0x8t

.field private static j:Ljava/util/concurrent/Executor;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-object v0, Lcom/luck/picture/lib/thread/a;->a:Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lcom/luck/picture/lib/thread/a;->b:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/luck/picture/lib/thread/a;->c:Ljava/util/Map;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput v0, Lcom/luck/picture/lib/thread/a;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Ljava/util/Timer;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/Timer;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sput-object v0, Lcom/luck/picture/lib/thread/a;->e:Ljava/util/Timer;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static A(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static B(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static/range {p0 .. p6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static C(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x2

    const-wide/16 v2, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v4, p2

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    return-void
.end method

.method public static D(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static E(ILcom/luck/picture/lib/thread/a$g;)V
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public static F(ILcom/luck/picture/lib/thread/a$g;I)V
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p2}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static G(ILcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 8
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v2, p2

    move-wide v4, p4

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v7, 0x7

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v7, 0x7

    return-void
.end method

.method public static H(ILcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;I)V
    .locals 7
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .param p7    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    invoke-static {p0, p7}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v2, p2

    move-wide v4, p4

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method public static I(ILcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v4, p2

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-void
.end method

.method public static J(ILcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 9
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v8, 0x3

    invoke-static {p0, p5}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v4, p2

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void
.end method

.method public static K(ILcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static L(ILcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0, p5}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static M(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, -0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public static N(Lcom/luck/picture/lib/thread/a$g;I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, -0x4

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public static O(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v0, -0x4

    const/4 v8, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    const/4 v8, 0x6

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x2

    return-void
.end method

.method public static P(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;I)V
    .locals 8
    .param p6    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v0, -0x4

    invoke-static {v0, p6}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method public static Q(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v0, -0x4

    const/4 v8, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    return-void
.end method

.method public static R(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 10
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v0, -0x4

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    return-void
.end method

.method public static S(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, -0x4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public static T(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 3
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, -0x4

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p4, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public static U(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public static V(Lcom/luck/picture/lib/thread/a$g;I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public static W(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v0, -0x1

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    const/4 v8, 0x1

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x3

    return-void
.end method

.method public static X(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;I)V
    .locals 8
    .param p6    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v0, -0x1

    invoke-static {v0, p6}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method public static Y(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v0, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x1

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    return-void
.end method

.method public static Z(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 10
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v0, -0x1

    const/4 v8, 0x5

    const/4 v8, 0x0

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-void
.end method

.method static synthetic a()I
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    sget v0, Lcom/luck/picture/lib/thread/a;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public static a0(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v0, -0x4

    const/4 v0, -0x5

    const/4 v0, -0x1

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic b()Ljava/util/concurrent/Executor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->j0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static b0(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 3
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p4

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p4, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic c()Ljava/util/Map;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x2

    sget-object v0, Lcom/luck/picture/lib/thread/a;->c:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method private static c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v2, p2

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->i(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-void
.end method

.method public static d(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/thread/a$g;->d()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static d0()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v0, -0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static e(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/thread/a$g;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Lcom/luck/picture/lib/thread/a$g;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/thread/a$g;->d()V

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public static e0(I)Ljava/util/concurrent/ExecutorService;
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, -0x2

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static f(Ljava/util/concurrent/ExecutorService;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    instance-of v0, p0, Lcom/luck/picture/lib/thread/a$h;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v0, Lcom/luck/picture/lib/thread/a;->c:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v3, 0x3

    and-int/2addr v4, v3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ne v2, p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v1, Lcom/luck/picture/lib/thread/a$g;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string p0, "adsireslUtT"

    const/4 v4, 0x2

    const-string p0, "Ussretahidl"

    const-string p0, "ThreadUtils"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v0, "T  mrlhsio/xTteinsol cs.croaephu ieevoUSmet/tre"

    const-string v0, "a.imtloecio eedSrcTul iTsporheoxhU/et /vsterns "

    const/4 v4, 0x7

    const-string v0, "The executorService is not ThreadUtils\'s pool."

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p0, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public static f0()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v0, -0x8

    move v2, v0

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static varargs g([Lcom/luck/picture/lib/thread/a$g;)V
    .locals 5

    const/4 v4, 0x5

    if-eqz p0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    array-length v0, p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_2

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    array-length v0, p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ge v1, v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    aget-object v2, p0, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v2}, Lcom/luck/picture/lib/thread/a$g;->d()V

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public static g0(I)Ljava/util/concurrent/ExecutorService;
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, -0x8

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method private static h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v6, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static/range {v0 .. v6}, Lcom/luck/picture/lib/thread/a;->i(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    return-void
.end method

.method public static h0(I)Ljava/util/concurrent/ExecutorService;
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method private static i(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v0, Lcom/luck/picture/lib/thread/a;->c:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p0, "trlooTehaUd"

    const-string/jumbo p0, "srUtodehlaT"

    const/4 v4, 0x3

    const-string/jumbo p0, "sdtlebUrhTi"

    const-string p0, "ThreadUtils"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo p1, "ta aneucoeuTbyn ee eclbkd xs. c"

    const-string p1, "c cenbl b.ux anoaektc sdyo eeTe"

    const/4 v4, 0x6

    const-string/jumbo p1, "nTestoupxayc blcn e. eoeedn c k"

    const-string p1, "Task can only be executed once."

    const/4 v3, 0x2

    const/4 v3, 0x3

    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0, p1, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    cmp-long v2, p4, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    cmp-long p4, p2, v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez p4, :cond_1

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    invoke-interface {p0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance p4, Lcom/luck/picture/lib/thread/a$a;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p4, p0, p1}, Lcom/luck/picture/lib/thread/a$a;-><init>(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    sget-object p0, Lcom/luck/picture/lib/thread/a;->e:Ljava/util/Timer;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p6, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p4, p1, p2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/luck/picture/lib/thread/a$g;->a(Lcom/luck/picture/lib/thread/a$g;Z)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Lcom/luck/picture/lib/thread/a$b;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/thread/a$b;-><init>(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object p0, Lcom/luck/picture/lib/thread/a;->e:Ljava/util/Timer;

    const/4 v3, 0x1

    and-int/2addr v4, v3

    invoke-virtual {p6, p2, p3}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p6, p4, p5}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide p4

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual/range {p0 .. p5}, Ljava/util/Timer;->scheduleAtFixedRate(Ljava/util/TimerTask;JJ)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x4

    move v4, v3

    throw p0
.end method

.method public static i0(II)Ljava/util/concurrent/ExecutorService;
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method private static j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/ExecutorService;",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-static/range {p0 .. p6}, Lcom/luck/picture/lib/thread/a;->i(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method private static j0()Ljava/util/concurrent/Executor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/luck/picture/lib/thread/a;->j:Ljava/util/concurrent/Executor;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    new-instance v0, Lcom/luck/picture/lib/thread/a$c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/luck/picture/lib/thread/a$c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/luck/picture/lib/thread/a;->j:Ljava/util/concurrent/Executor;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/thread/a;->j:Ljava/util/concurrent/Executor;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public static k(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, -0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static k0()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const/4 v2, 0x6

    const/4 v0, -0x4

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static l(Lcom/luck/picture/lib/thread/a$g;I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, -0x2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static l0(I)Ljava/util/concurrent/ExecutorService;
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v0, -0x4

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static m(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v0, -0x2

    const/4 v8, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    const/4 v8, 0x4

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method public static m0()Landroid/os/Handler;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/thread/a;->a:Landroid/os/Handler;

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object v0
.end method

.method public static n(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;I)V
    .locals 8
    .param p6    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v0, -0x2

    invoke-static {v0, p6}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method private static n0(I)Ljava/util/concurrent/ExecutorService;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static o(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v0, -0x2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    return-void
.end method

.method private static o0(II)Ljava/util/concurrent/ExecutorService;
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v0, Lcom/luck/picture/lib/thread/a;->b:Ljava/util/Map;

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    check-cast v1, Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a$h;->a(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast v2, Ljava/util/concurrent/ExecutorService;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a$h;->a(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v1, p0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static p(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 10
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v0, -0x2

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-void
.end method

.method public static p0()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public static q(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, -0x2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public static q0(I)Ljava/util/concurrent/ExecutorService;
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, -0x1

    move v2, v0

    const/4 v1, 0x0

    move v2, v1

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public static r(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 3
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, -0x2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p4

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p4, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x6

    return-void
.end method

.method public static r0()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    return v0
.end method

.method public static s(Lcom/luck/picture/lib/thread/a$g;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, -0x8

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public static s0(Ljava/lang/Runnable;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lcom/luck/picture/lib/thread/a;->a:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public static t(Lcom/luck/picture/lib/thread/a$g;I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, -0x8

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, p0}, Lcom/luck/picture/lib/thread/a;->h(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public static t0(Ljava/lang/Runnable;J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/luck/picture/lib/thread/a;->a:Landroid/os/Handler;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v2, 0x2

    return-void
.end method

.method public static u(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v0, -0x8

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    const/4 v8, 0x1

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v8, 0x2

    return-void
.end method

.method public static u0(Ljava/util/concurrent/Executor;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    sput-object p0, Lcom/luck/picture/lib/thread/a;->j:Ljava/util/concurrent/Executor;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static v(Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;I)V
    .locals 8
    .param p6    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v0, -0x8

    invoke-static {v0, p6}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p1

    move-wide v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    return-void
.end method

.method public static w(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v0, -0x8

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x7

    return-void
.end method

.method public static x(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 10
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v0, -0x8

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v5, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static/range {v1 .. v7}, Lcom/luck/picture/lib/thread/a;->j(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JJLjava/util/concurrent/TimeUnit;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    return-void
.end method

.method public static y(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v0, -0x5

    const/4 v0, -0x8

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->n0(I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static z(Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;I)V
    .locals 3
    .param p4    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x1L
            to = 0xaL
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/luck/picture/lib/thread/a$g<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, -0x8

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p4}, Lcom/luck/picture/lib/thread/a;->o0(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p4, p0, p1, p2, p3}, Lcom/luck/picture/lib/thread/a;->c0(Ljava/util/concurrent/ExecutorService;Lcom/luck/picture/lib/thread/a$g;JLjava/util/concurrent/TimeUnit;)V

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
