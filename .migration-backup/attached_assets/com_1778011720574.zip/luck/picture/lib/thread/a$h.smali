.class final Lcom/luck/picture/lib/thread/a$h;
.super Ljava/util/concurrent/ThreadPoolExecutor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/thread/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "h"
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/atomic/AtomicInteger;

.field private b:Lcom/luck/picture/lib/thread/a$d;


# direct methods
.method constructor <init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct/range {p0 .. p7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/thread/a$h;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-static {p6, p0}, Lcom/luck/picture/lib/thread/a$d;->a(Lcom/luck/picture/lib/thread/a$d;Lcom/luck/picture/lib/thread/a$h;)Lcom/luck/picture/lib/thread/a$h;

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput-object p6, p0, Lcom/luck/picture/lib/thread/a$h;->b:Lcom/luck/picture/lib/thread/a$d;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a(II)Ljava/util/concurrent/ExecutorService;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tns of~o@@o~@l  @@~~ 4~rbf/M~~@~~b@1K~a m c ~~~t@@   S v~il-@ @@~/i@@o.@~@ ~ ~o@ ~~bu~ds~ @@oi@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/luck/picture/lib/thread/a$h;->b(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method private static b(II)Ljava/util/concurrent/ExecutorService;
    .locals 24

    move/from16 v2, p0

    move/from16 v2, p0

    move/from16 v2, p0

    move/from16 v2, p0

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    const/4 v1, -0x8

    const/4 v3, 0x1

    if-eq v2, v1, :cond_3

    const/4 v1, -0x4

    if-eq v2, v1, :cond_2

    const/4 v1, -0x2

    if-eq v2, v1, :cond_1

    const/4 v1, -0x1

    if-eq v2, v1, :cond_0

    new-instance v8, Lcom/luck/picture/lib/thread/a$h;

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Lcom/luck/picture/lib/thread/a$d;

    invoke-direct {v6}, Lcom/luck/picture/lib/thread/a$d;-><init>()V

    new-instance v7, Lcom/luck/picture/lib/thread/a$i;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "f(smie"

    const-string v9, "fis(xe"

    const-string v9, "(xfioe"

    const-string v9, "fixed("

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, ")"

    const-string v9, ")"

    const-string v9, ")"

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v7, v1, v0}, Lcom/luck/picture/lib/thread/a$i;-><init>(Ljava/lang/String;I)V

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move/from16 v1, p0

    move/from16 v1, p0

    move/from16 v1, p0

    move/from16 v1, p0

    move/from16 v2, p0

    move/from16 v2, p0

    move/from16 v2, p0

    move/from16 v2, p0

    invoke-direct/range {v0 .. v7}, Lcom/luck/picture/lib/thread/a$h;-><init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V

    return-object v8

    :cond_0
    new-instance v1, Lcom/luck/picture/lib/thread/a$h;

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    sget-object v14, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v15, Lcom/luck/picture/lib/thread/a$d;

    invoke-direct {v15}, Lcom/luck/picture/lib/thread/a$d;-><init>()V

    new-instance v2, Lcom/luck/picture/lib/thread/a$i;

    const-string/jumbo v3, "mlgnib"

    const-string v3, "gslmin"

    const-string/jumbo v3, "uiglne"

    const-string/jumbo v3, "single"

    invoke-direct {v2, v3, v0}, Lcom/luck/picture/lib/thread/a$i;-><init>(Ljava/lang/String;I)V

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    invoke-direct/range {v9 .. v16}, Lcom/luck/picture/lib/thread/a$h;-><init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V

    return-object v1

    :cond_1
    new-instance v1, Lcom/luck/picture/lib/thread/a$h;

    const/16 v17, 0x0

    const/16 v18, 0x80

    const-wide/16 v19, 0x3c

    const-wide/16 v19, 0x3c

    const-wide/16 v19, 0x3c

    const-wide/16 v19, 0x3c

    sget-object v21, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v2, Lcom/luck/picture/lib/thread/a$d;

    invoke-direct {v2, v3}, Lcom/luck/picture/lib/thread/a$d;-><init>(Z)V

    new-instance v3, Lcom/luck/picture/lib/thread/a$i;

    const-string/jumbo v4, "opceah"

    const-string v4, "edchoa"

    const-string v4, "hcqadc"

    const-string v4, "cached"

    invoke-direct {v3, v4, v0}, Lcom/luck/picture/lib/thread/a$i;-><init>(Ljava/lang/String;I)V

    move-object/from16 v16, v1

    move-object/from16 v16, v1

    move-object/from16 v16, v1

    move-object/from16 v16, v1

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    move-object/from16 v23, v3

    move-object/from16 v23, v3

    invoke-direct/range {v16 .. v23}, Lcom/luck/picture/lib/thread/a$h;-><init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V

    return-object v1

    :cond_2
    new-instance v1, Lcom/luck/picture/lib/thread/a$h;

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->a()I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    add-int/lit8 v6, v2, 0x1

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->a()I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    add-int/lit8 v7, v2, 0x1

    const-wide/16 v8, 0x1e

    const-wide/16 v8, 0x1e

    const-wide/16 v8, 0x1e

    const-wide/16 v8, 0x1e

    sget-object v10, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v11, Lcom/luck/picture/lib/thread/a$d;

    invoke-direct {v11}, Lcom/luck/picture/lib/thread/a$d;-><init>()V

    new-instance v12, Lcom/luck/picture/lib/thread/a$i;

    const-string/jumbo v2, "io"

    const-string/jumbo v2, "oi"

    const-string/jumbo v2, "io"

    const-string/jumbo v2, "io"

    invoke-direct {v12, v2, v0}, Lcom/luck/picture/lib/thread/a$i;-><init>(Ljava/lang/String;I)V

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    invoke-direct/range {v5 .. v12}, Lcom/luck/picture/lib/thread/a$h;-><init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V

    return-object v1

    :cond_3
    new-instance v1, Lcom/luck/picture/lib/thread/a$h;

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->a()I

    move-result v2

    add-int/lit8 v14, v2, 0x1

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->a()I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    add-int/lit8 v15, v2, 0x1

    const-wide/16 v16, 0x1e

    const-wide/16 v16, 0x1e

    const-wide/16 v16, 0x1e

    const-wide/16 v16, 0x1e

    sget-object v18, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v2, Lcom/luck/picture/lib/thread/a$d;

    invoke-direct {v2, v3}, Lcom/luck/picture/lib/thread/a$d;-><init>(Z)V

    new-instance v3, Lcom/luck/picture/lib/thread/a$i;

    const-string/jumbo v4, "pcu"

    const-string/jumbo v4, "ucp"

    const-string/jumbo v4, "upc"

    const-string v4, "cpu"

    invoke-direct {v3, v4, v0}, Lcom/luck/picture/lib/thread/a$i;-><init>(Ljava/lang/String;I)V

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v13 .. v20}, Lcom/luck/picture/lib/thread/a$h;-><init>(IIJLjava/util/concurrent/TimeUnit;Lcom/luck/picture/lib/thread/a$d;Ljava/util/concurrent/ThreadFactory;)V

    return-object v1
.end method

.method private c()I
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$h;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method


# virtual methods
.method protected afterExecute(Ljava/lang/Runnable;Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$h;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v1, 0x2

    move v2, v1

    invoke-super {p0, p1, p2}, Ljava/util/concurrent/ThreadPoolExecutor;->afterExecute(Ljava/lang/Runnable;Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public execute(Ljava/lang/Runnable;)V
    .locals 4
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$h;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-super {p0, p1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/thread/a$h;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "lTsiatdhbsU"

    const-string v0, "TirlhbUdsta"

    const/4 v3, 0x7

    const-string v0, "UtTmhldrasi"

    const-string v0, "ThreadUtils"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "i nl puapswT!hotnheil"

    const/4 v3, 0x1

    const-string/jumbo v1, "lpaToohhsl inp t! enw"

    const-string v1, "This will not happen!"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/thread/a$h;->b:Lcom/luck/picture/lib/thread/a$d;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/thread/a$d;->b(Ljava/lang/Runnable;)Z

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method
