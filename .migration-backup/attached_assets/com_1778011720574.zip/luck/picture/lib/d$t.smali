.class Lcom/luck/picture/lib/d$t;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->I1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/style/SelectMainStyle;

.field final synthetic b:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/style/SelectMainStyle;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$t;->b:Lcom/luck/picture/lib/d;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/d$t;->a:Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os@ ~~@ - @~li@arn @~@Kto~@~1t@bf~~oi cs~ ~v~ ~~o@~/ ybb@Moo  . @~ @/@~@lS@ @mf4~@ ~ @@~ ~ ~du~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d$t;->a:Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/SelectMainStyle;->d0()Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    or-int/2addr v4, v3

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d$t;->b:Lcom/luck/picture/lib/d;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p1, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p1, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v2}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    move v0, v2

    move v0, v2

    const/4 v4, 0x0

    move v0, v2

    move v0, v2

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d$t;->b:Lcom/luck/picture/lib/d;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/d;->q1(Lcom/luck/picture/lib/d;)V

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method
