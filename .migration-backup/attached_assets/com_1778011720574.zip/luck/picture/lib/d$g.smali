.class Lcom/luck/picture/lib/d$g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/adapter/holder/g$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->K1(Landroid/view/ViewGroup;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/recyclerview/widget/o;

.field final synthetic b:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;Landroidx/recyclerview/widget/o;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d$g;->b:Lcom/luck/picture/lib/d;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/d$g;->a:Landroidx/recyclerview/widget/o;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Landroidx/recyclerview/widget/RecyclerView$g0;ILandroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/d$g;->b:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p3, "vrssaibt"

    const-string/jumbo p3, "vtsroabi"

    const/4 v3, 0x5

    const-string/jumbo p3, "trimobva"

    const-string/jumbo p3, "vibrator"

    const/4 v3, 0x7

    invoke-virtual {p2, p3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p2, Landroid/os/Vibrator;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, 0x32

    const-wide/16 v0, 0x32

    const/4 v3, 0x1

    const-wide/16 v0, 0x32

    const-wide/16 v0, 0x32

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/os/Vibrator;->vibrate(J)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/d$g;->b:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p2, p2, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/luck/picture/lib/adapter/holder/g;->getItemCount()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/luck/picture/lib/d$g;->b:Lcom/luck/picture/lib/d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p3}, Lcom/luck/picture/lib/d;->Y0(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget p3, p3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    if-eq p2, p3, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/d$g;->a:Landroidx/recyclerview/widget/o;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/o;->w(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$g0;->getLayoutPosition()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/luck/picture/lib/d$g;->b:Lcom/luck/picture/lib/d;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p3, p3, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p3}, Lcom/luck/picture/lib/adapter/holder/g;->getItemCount()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p2, p3, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/d$g;->a:Landroidx/recyclerview/widget/o;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/o;->w(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method
