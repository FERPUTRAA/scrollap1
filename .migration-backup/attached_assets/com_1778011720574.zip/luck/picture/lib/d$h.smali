.class Lcom/luck/picture/lib/d$h;
.super Lcom/luck/picture/lib/widget/BottomNavBar$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->H1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/BottomNavBar$b;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cds~ ~K ~f@ o~s~~o~r@~vi@lyo ~ltu/@ @1~~~4@ @~ /@~@@ m@@o~~@@i-@o@@ @ @S a~~o. t bbb~@ i~~~fM n "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->y()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public b()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h1:Ls6/h;

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, v0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, v0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x4

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h1:Ls6/h;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/16 v3, 0x2b8

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v1, v2, v0, v3}, Ls6/h;->a(Landroidx/fragment/app/Fragment;Lcom/luck/picture/lib/entity/LocalMedia;I)V

    :cond_0
    const/4 v5, 0x6

    return-void
.end method

.method public c()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-le v1, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, v1, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d$h;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v0, v2}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method
