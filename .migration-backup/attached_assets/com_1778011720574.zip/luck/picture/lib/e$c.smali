.class Lcom/luck/picture/lib/e$c;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/u;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->x(I[Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/e$c;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a([Ljava/lang/String;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@nsb @@~~c/s@ l~~4o-o@@i~/@ ~  t1~ l@f r@@@ ~~~@~~b ~@~i@t.mduy~~~ Kf @o o ~@@~ ~MS@~boav @io@  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/e$c;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/e;->W0(Lcom/luck/picture/lib/e;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/e$c;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method
