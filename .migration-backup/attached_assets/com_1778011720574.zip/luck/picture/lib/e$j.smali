.class Lcom/luck/picture/lib/e$j;
.super Ld/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->f1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Ljava/lang/String;",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/e$j;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " mss@@/f-~yo @to@~v@~~@  ~r4o@@   @b @o~@~~a~@~ bMinu~t @@~/i~K~.~l@ ~o ~~ @o@@c bSid l1~f  ~~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/e$j;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/e$j;->e(ILandroid/content/Intent;)Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string p1, "dsomi/*"

    const-string p1, "*/sieod"

    const/4 v2, 0x6

    const-string p1, "d/*vooi"

    const-string/jumbo p1, "video/*"

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    invoke-static {p1, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "CnoirbPaacKi.odetinnInmd.."

    const-string v0, "dCima.t.oPcItdnennriKna.oi"

    const/4 v2, 0x1

    const-string v0, "android.intent.action.PICK"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x5

    sget-object p2, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p1, v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string p1, "ao/duiu"

    const-string p1, "audio/*"

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x1

    sget-object p2, Landroid/provider/MediaStore$Audio$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-direct {p1, v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p2, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p1, v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method

.method public e(ILandroid/content/Intent;)Landroid/net/Uri;
    .locals 2
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method
