.class Lcom/luck/picture/lib/d$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->L1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/d$c;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ sb@  /@dyv@@~~  @1 o~-ll~b@ i ~~a~@@@~@@S@c~~oKis@~@~@otrui  ~~@~~   .@ ft4M ofm  ~~o~~n~b~o/@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d$c;->a:Lcom/luck/picture/lib/d;

    const/4 v0, 0x0

    move v1, v0

    iget-object p1, p1, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    const/4 v1, 0x7

    const/4 v0, 0x0

    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method
