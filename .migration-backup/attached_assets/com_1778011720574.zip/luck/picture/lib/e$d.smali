.class Lcom/luck/picture/lib/e$d;
.super Ld/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->h1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld/a<",
        "Ljava/lang/String;",
        "Ljava/util/List<",
        "Landroid/net/Uri;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/e$d;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ld/a;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~ ~~ ~@~c~iM @i@obd  @~l@tSt1@.y 4~@~ f~~ a@@~o  @~/i~~ ~@@-@@ ~oK @ub @m@~~o ls@  v~fn/oorb@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p2, Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/e$d;->d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic c(ILandroid/content/Intent;)Ljava/lang/Object;
    .locals 2
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/e$d;->e(ILandroid/content/Intent;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public d(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "Ctamn.itn.oKciPIndo.rsieda"

    const-string/jumbo v0, "iosanKtnIdc.onar.idt.PiteC"

    const/4 v3, 0x5

    const-string/jumbo v0, "naeioonC.r.PtdcnIti.taidoK"

    const-string v0, "android.intent.action.PICK"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v0, "EoiLdbt.ITnderAPxL.imrUtnLLWa.O_Mna"

    const-string/jumbo v0, "nTPmLtLILdALnntredeOx.Ea.Uaio.MrW_i"

    const/4 v3, 0x0

    const-string/jumbo v0, "rrtLeMuEdnAiOt.dTLaixeWoaPUt._.InLn"

    const-string v0, "android.intent.extra.ALLOW_MULTIPLE"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x6

    return-object p1
.end method

.method public e(ILandroid/content/Intent;)Ljava/util/List;
    .locals 5
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    new-instance p1, Ljava/util/ArrayList;

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/content/Intent;->getClipData()Landroid/content/ClipData;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2}, Landroid/content/Intent;->getClipData()Landroid/content/ClipData;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/content/ClipData;->getItemCount()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ge v1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, v1}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v2}, Landroid/content/ClipData$Item;->getUri()Landroid/net/Uri;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {p1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p1, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-object p1
.end method
