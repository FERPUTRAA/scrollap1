.class public Lcom/luck/picture/lib/style/BottomNavBarStyle;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/style/BottomNavBarStyle;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I

.field private g:Ljava/lang/String;

.field private h:I

.field private i:Ljava/lang/String;

.field private j:I

.field private k:I

.field private l:I

.field private m:Ljava/lang/String;

.field private n:I

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/style/BottomNavBarStyle$a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-direct {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle$a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->d:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->f:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->g:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->j:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k:I

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->l:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->m:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->o:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->p:I

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r:I

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public A(Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "iis ~~~~t c~v 4~@ @a~d ~@@o /@@~ ~ .@~ io~~~om@~t Kb~Su@@@1 y/~ @ ~o-  lr@~o@ sob@nMlf@~bf~ @@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method

.method public B(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public C(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public D(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public E(I)V
    .locals 2

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public F(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->l:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public G(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->m:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public H(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->o:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public J(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n:I

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public L(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->b:I

    const/4 v1, 0x6

    return-void
.end method

.method public M(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->d:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public O(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->f:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public P(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->e:I

    const/4 v1, 0x7

    return-void
.end method

.method public R(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->g:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public S(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public T(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->p:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public U(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public V(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public W(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->j:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    return v0
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public h()I
    .locals 3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->l:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->m:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->o:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public n()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public o()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public q()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->d:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public r()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public s()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public u()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->g:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public v()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public w()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->p:I

    const/4 v2, 0x0

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->b:I

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x4

    move v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->d:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->g:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i:Ljava/lang/String;

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->l:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->m:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x1

    move v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->o:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->p:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v1, 0x6

    int-to-byte p2, p2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public x()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public y()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public z()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method
