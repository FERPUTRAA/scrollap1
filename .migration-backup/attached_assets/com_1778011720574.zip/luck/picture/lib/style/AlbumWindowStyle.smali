.class public Lcom/luck/picture/lib/style/AlbumWindowStyle;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/style/AlbumWindowStyle;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/style/AlbumWindowStyle$a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle$a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    iput v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ons b ~@@ ~~~ 1@ ~i@~~  ~/~ o@~moa~~~doK@icv@@@ bu@4@f @~/l@i @@oy~t-@b~s~ . @@ Mlr ~~~t @~ f@~S"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->a:I

    const/4 v2, 0x6

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public g(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public h(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public i(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public k(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->c:I

    const/4 v1, 0x1

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->b:I

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/AlbumWindowStyle;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
