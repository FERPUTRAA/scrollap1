.class public Lcom/luck/picture/lib/style/a;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/luck/picture/lib/style/AlbumWindowStyle;

.field private b:Lcom/luck/picture/lib/style/TitleBarStyle;

.field private c:Lcom/luck/picture/lib/style/SelectMainStyle;

.field private d:Lcom/luck/picture/lib/style/BottomNavBarStyle;

.field private e:Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Lcom/luck/picture/lib/style/AlbumWindowStyle;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "nvsoyob~tu -  @@@~b @@~l@@i  @~f4~M@S~~@.f ~oaK o@~/@1l ~ ~c@i@  /@ @s@~r~~ ~dobm  ~ i~~@~o~@~~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->a:Lcom/luck/picture/lib/style/AlbumWindowStyle;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/style/AlbumWindowStyle;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle;-><init>()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public b()Lcom/luck/picture/lib/style/BottomNavBarStyle;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->d:Lcom/luck/picture/lib/style/BottomNavBarStyle;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/luck/picture/lib/style/BottomNavBarStyle;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;-><init>()V

    :cond_0
    const/4 v2, 0x2

    return-object v0
.end method

.method public c()Lcom/luck/picture/lib/style/SelectMainStyle;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->c:Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    new-instance v0, Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;-><init>()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public d()Lcom/luck/picture/lib/style/TitleBarStyle;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->b:Lcom/luck/picture/lib/style/TitleBarStyle;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/luck/picture/lib/style/TitleBarStyle;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;-><init>()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->e:Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    const/4 v1, 0x3

    move v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    invoke-static {}, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->g()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/style/a;->e:Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/a;->e:Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public f(Lcom/luck/picture/lib/style/AlbumWindowStyle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/style/a;->a:Lcom/luck/picture/lib/style/AlbumWindowStyle;

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public g(Lcom/luck/picture/lib/style/BottomNavBarStyle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/style/a;->d:Lcom/luck/picture/lib/style/BottomNavBarStyle;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public h(Lcom/luck/picture/lib/style/SelectMainStyle;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/style/a;->c:Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public i(Lcom/luck/picture/lib/style/TitleBarStyle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/style/a;->b:Lcom/luck/picture/lib/style/TitleBarStyle;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public j(Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;)V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lcom/luck/picture/lib/style/a;->e:Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
