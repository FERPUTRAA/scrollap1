.class public Lcom/luck/picture/lib/style/TitleBarStyle;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/style/TitleBarStyle;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Z

.field private b:I

.field private c:I

.field private d:Ljava/lang/String;

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:Z

.field private l:I

.field private m:I

.field private n:Z

.field private o:I

.field private p:Ljava/lang/String;

.field private q:I

.field private r:I

.field private s:I

.field private t:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Lcom/luck/picture/lib/style/TitleBarStyle$a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/luck/picture/lib/style/TitleBarStyle$a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    sput-object v0, Lcom/luck/picture/lib/style/TitleBarStyle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    move v0, v1

    move v0, v1

    const/4 v4, 0x4

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->a:Z

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->c:I

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->e:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->f:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->g:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->i:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->j:I

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    move v0, v2

    move v0, v2

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->k:Z

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->l:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->m:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_2

    :cond_2
    const/4 v4, 0x4

    move v0, v2

    move v0, v2

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->n:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->o:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->p:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->q:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->r:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->s:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_3

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->t:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method public A()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~ u~oo@i ~~f4@@~i  t ~f@@~~/@-@tod@~ v@@b@@r@/yo~obl bm i~o~~ns~ . K @@ @@@ ~ ~@~~ 1@c MSl~a~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public B(Z)V
    .locals 2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->k:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public C(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->t:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public D(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->n:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public E(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-void
.end method

.method public F(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->o:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public G(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->h:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public H(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public J(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->j:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public L(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->g:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public M(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->i:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public O(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->s:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public P(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->m:I

    const/4 v1, 0x7

    return-void
.end method

.method public R(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->p:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public S(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->r:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public T(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->q:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public U(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->d:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public V(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->l:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public W(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public Y(I)V
    .locals 2

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->f:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public Z(I)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    iput p1, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->e:I

    const/4 v1, 0x3

    return-void
.end method

.method public a()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->o:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public e()I
    .locals 3

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->j:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->g:I

    const/4 v2, 0x7

    return v0
.end method

.method public h()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public i()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->s:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->m:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public n()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->p:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v1, 0x4

    return-object v0
.end method

.method public o()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->r:I

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public q()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->q:I

    return v0
.end method

.method public r()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->d:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public s()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->l:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public u()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public v()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->f:I

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public w()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->e:I

    const/4 v2, 0x6

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    int-to-byte p2, p2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->d:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->e:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->f:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->g:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->h:I

    const/4 v0, 0x4

    const/4 v0, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->i:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->j:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->k:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    int-to-byte p2, p2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->l:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->m:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->n:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    int-to-byte p2, p2

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->o:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->p:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->q:I

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->r:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->s:I

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->t:Z

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    int-to-byte p2, p2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public x()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->k:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public y()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->t:Z

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return v0
.end method

.method public z()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/TitleBarStyle;->n:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method
