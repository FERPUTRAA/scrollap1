.class public Lcom/luck/picture/lib/style/SelectMainStyle;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/style/SelectMainStyle;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private A:I

.field private B:I

.field private C:I

.field private D:[I

.field private E:I

.field private F:I

.field private G:I

.field private H:[I

.field private I:I

.field private J:I

.field private K:I

.field private L:Ljava/lang/String;

.field private M:I

.field private N:I

.field private O:I

.field private P:I

.field private Q:I

.field private R:[I

.field private S:I

.field private T:[I

.field private U:I

.field private V:I

.field private W:I

.field private a:I

.field private b:I

.field private c:Z

.field private d:Z

.field private e:Z

.field private f:Z

.field private g:I

.field private h:I

.field private i:Ljava/lang/String;

.field private j:I

.field private k:I

.field private l:I

.field private m:I

.field private n:Z

.field private o:Z

.field private p:I

.field private q:Ljava/lang/String;

.field private r:I

.field private s:I

.field private t:I

.field private u:Ljava/lang/String;

.field private v:I

.field private w:I

.field private x:I

.field private y:I

.field private z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/style/SelectMainStyle$a;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/luck/picture/lib/style/SelectMainStyle$a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/luck/picture/lib/style/SelectMainStyle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 5

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->b:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    move v1, v2

    move v1, v2

    const/4 v4, 0x4

    move v1, v2

    move v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    move v1, v2

    move v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x6

    move v4, v3

    move v1, v0

    move v1, v0

    const/4 v4, 0x4

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->d:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_2

    :cond_2
    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    :goto_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    goto :goto_3

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :goto_3
    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->f:Z

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->h:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->i:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->j:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->k:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->l:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->m:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    move v1, v2

    const/4 v4, 0x5

    move v1, v2

    move v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    goto :goto_4

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    :goto_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->n:Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v1, :cond_5

    const/4 v3, 0x2

    move v4, v3

    move v1, v2

    move v1, v2

    const/4 v4, 0x2

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_5

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    move v1, v0

    move v1, v0

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    :goto_5
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-boolean v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->o:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->p:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->q:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->r:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->s:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->t:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->u:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->v:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->w:I

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->x:I

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->y:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    move v0, v2

    move v0, v2

    const/4 v4, 0x7

    move v0, v2

    move v0, v2

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->z:Z

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->A:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->B:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->C:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->D:[I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->E:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->F:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->G:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->H:[I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->I:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->J:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->K:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->L:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->M:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->N:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->O:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->P:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->Q:I

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->R:[I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->S:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->T:[I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->U:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->V:I

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->W:I

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method public A()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b~s/~@~ul@ ~dMiym-~@K@s~/  Sb  on~o io@@t~~~ @~r @@ac l @i@  @~~ ~o@o@@@@@~~f f~bv o1t4@@ ~~ ~~."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->A:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public B()I
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->O:I

    const/4 v2, 0x6

    return v0
.end method

.method public B0(I)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->F:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public C()[I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->R:[I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public C0([I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->T:[I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public D()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->Q:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    return v0
.end method

.method public E()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->P:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public E0(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->S:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public F()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->p:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public F0(Z)V
    .locals 2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->z:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public G()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->b:I

    const/4 v2, 0x7

    return v0
.end method

.method public H()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public H0(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->y:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public I0(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->V:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public J()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->m:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public J0(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->U:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public K0(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->W:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public L()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->g:I

    const/4 v1, 0x7

    move v2, v1

    return v0
.end method

.method public L0(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->B:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public M()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->i:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public M0([I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->D:[I

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public N0(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->C:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method public O()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->k:I

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public O0(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->A:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public P()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->j:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public P0(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->O:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public R()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->l:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public R0([I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->R:[I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public S()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->x:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    return v0
.end method

.method public S0(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->Q:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public T()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->t:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public T0(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->P:I

    return-void
.end method

.method public U()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->q:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public U0(Z)V
    .locals 2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->d:Z

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public V()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->s:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public V0(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public W()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->r:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public X0(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->p:I

    const/4 v1, 0x5

    return-void
.end method

.method public Y()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->u:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object v0
.end method

.method public Y0(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public Z()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->w:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public Z0(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method

.method public a()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->J:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public a0()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->v:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public a1(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->f:Z

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public b0()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->a:I

    const/4 v2, 0x0

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->K:I

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public c0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->z:Z

    const/4 v2, 0x6

    return v0
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->L:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public d0()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->d:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public d1(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->m:I

    const/4 v1, 0x1

    return-void
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->M:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public f0()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public f1(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->g:I

    const/4 v1, 0x2

    return-void
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->N:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public g0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    return v0
.end method

.method public g1(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->o:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public h()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->I:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public h1(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->e:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public i()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->E:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public i0()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->o:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public j0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->e:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public j1(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->i:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public k()[I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->H:[I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public k1(I)V
    .locals 2

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->k:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public l0()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->n:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public l1(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->j:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public m0(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->J:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public m1(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->l:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public n()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->G:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public n0(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->K:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public n1(I)V
    .locals 2

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->x:I

    const/4 v1, 0x6

    return-void
.end method

.method public o()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->F:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public o0(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->L:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public o1(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->t:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public p1(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->q:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public q()[I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->T:[I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public q0(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->M:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public q1(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->s:I

    const/4 v1, 0x6

    return-void
.end method

.method public r()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->S:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public r1(I)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->r:I

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public s()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->y:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public s1(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->n:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public t0(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->N:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public u()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->V:I

    const/4 v2, 0x0

    return v0
.end method

.method public u1(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->u:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public v()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->U:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public v1(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->w:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public w()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->W:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public w0(I)V
    .locals 2

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->I:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public w1(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->v:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->c:Z

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    int-to-byte p2, p2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v0, 0x6

    move v1, v0

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->d:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    int-to-byte p2, p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->e:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    int-to-byte p2, p2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->f:Z

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    int-to-byte p2, p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v0, 0x3

    move v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->g:I

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->i:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->j:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x4

    move v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->k:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->l:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->m:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->n:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    int-to-byte p2, p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->o:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    int-to-byte p2, p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->p:I

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->q:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->r:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->s:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->t:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->u:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->v:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->w:I

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->x:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->y:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-boolean p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->z:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    int-to-byte p2, p2

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->A:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->B:I

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->C:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->D:[I

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->E:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->F:I

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->G:I

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->H:[I

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->I:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->J:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->K:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->L:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->M:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->N:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->O:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->P:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->Q:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->R:[I

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->S:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->T:[I

    const/4 v1, 0x2

    const/4 v0, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->U:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->V:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->W:I

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public x()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->B:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public x0(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->E:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public y()[I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->D:[I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public y0([I)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->H:[I

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method public z()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->C:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public z0(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->G:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public z1(I)V
    .locals 2

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/SelectMainStyle;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
