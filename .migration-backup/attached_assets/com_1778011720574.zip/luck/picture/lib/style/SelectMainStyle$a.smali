.class Lcom/luck/picture/lib/style/SelectMainStyle$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/style/SelectMainStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/luck/picture/lib/style/SelectMainStyle;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/luck/picture/lib/style/SelectMainStyle;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@as~@ @f@/@o1   @ id@t@@m~4c@  n~~ o o~S~@u@vo ~ ~r/tb~~b@o@i~@~~@K@~ ~y@oM .~ bl @~~  ~isf~~-~l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lcom/luck/picture/lib/style/SelectMainStyle;-><init>(Landroid/os/Parcel;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public b(I)[Lcom/luck/picture/lib/style/SelectMainStyle;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    new-array p1, p1, [Lcom/luck/picture/lib/style/SelectMainStyle;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/style/SelectMainStyle$a;->a(Landroid/os/Parcel;)Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/style/SelectMainStyle$a;->b(I)[Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method
