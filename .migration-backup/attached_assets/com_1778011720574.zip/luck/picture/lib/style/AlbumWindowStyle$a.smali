.class Lcom/luck/picture/lib/style/AlbumWindowStyle$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/style/AlbumWindowStyle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/luck/picture/lib/style/AlbumWindowStyle;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/luck/picture/lib/style/AlbumWindowStyle;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tfs~y~@@@m~/@v~o~oKllu ~~ ~ d~ - 4o t~ni@@@fc~@~b@b~  M @~~@@~@ os/@~a@  ~b~o ~~ @~Sri@.o  @@ i@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Lcom/luck/picture/lib/style/AlbumWindowStyle;

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lcom/luck/picture/lib/style/AlbumWindowStyle;-><init>(Landroid/os/Parcel;)V

    const/4 v2, 0x2

    return-object v0
.end method

.method public b(I)[Lcom/luck/picture/lib/style/AlbumWindowStyle;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-array p1, p1, [Lcom/luck/picture/lib/style/AlbumWindowStyle;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/style/AlbumWindowStyle$a;->a(Landroid/os/Parcel;)Lcom/luck/picture/lib/style/AlbumWindowStyle;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/style/AlbumWindowStyle$a;->b(I)[Lcom/luck/picture/lib/style/AlbumWindowStyle;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method
