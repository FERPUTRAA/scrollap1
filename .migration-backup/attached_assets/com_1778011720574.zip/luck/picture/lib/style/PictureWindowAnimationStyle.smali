.class public Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public a:I
    .annotation build Landroidx/annotation/a;
    .end annotation
.end field

.field public b:I
    .annotation build Landroidx/annotation/a;
    .end annotation
.end field

.field public c:I
    .annotation build Landroidx/annotation/a;
    .end annotation
.end field

.field public d:I
    .annotation build Landroidx/annotation/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    new-instance v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle$a;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle$a;-><init>()V

    const/4 v2, 0x4

    sput-object v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(II)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/a;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/a;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static g()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "i@s~a.~ l1~~~~ o@@~fuM-o /f~@ ~  @@@~@oscr~d ~b~n/m@lt@v@  ~K@@@S ~~  @ @~b4b~io@ io~@@  ~~t~o @"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_enter:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget v2, Lcom/luck/picture/lib/R$anim;->ps_anim_exit:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;-><init>(II)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v0
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x0

    and-int/2addr v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public h(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public i(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public k(I)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public n(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iget p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    iget p2, p0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    return-void
.end method
