.class public Lcom/luck/picture/lib/service/ForegroundService;
.super Landroid/app/Service;


# static fields
.field private static final a:Ljava/lang/String;

.field private static final b:Ljava/lang/String; = "com.luck.picture.lib"

.field private static final c:I = 0x1

.field private static d:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "ctslcmeukcoir.ui.sbpl"

    const-string/jumbo v1, "p.stcboecuclur.imikl."

    const/4 v3, 0x7

    const-string v1, "com.luck.picture.lib."

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v0, Lcom/luck/picture/lib/service/ForegroundService;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-boolean v0, Lcom/luck/picture/lib/service/ForegroundService;->d:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private a()Landroid/app/Notification;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~o/ma~o~Sf ~ bodn@~ @r  @@~tlts@@1m ~ib@v i@@uc~f@oK@@~. ~ ~M~~yi4~~@ b~ o- ~~@@ ~ @/@~@o  l~ @@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->a()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v0, 0x4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->d()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Landroidx/core/app/o0;->a()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    sget-object v2, Lcom/luck/picture/lib/service/ForegroundService;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const-string/jumbo v4, "lr..ocpmcluketibu.oi"

    const-string/jumbo v4, "ll.mp.rbtecku.uccoii"

    const/4 v6, 0x4

    const-string/jumbo v4, "lpcuub.ktbocricil.e."

    const-string v4, "com.luck.picture.lib"

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-static {v2, v4, v0}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const v2, -0xffff01

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2}, Landroidx/core/app/k0;->a(Landroid/app/NotificationChannel;I)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0}, Landroidx/core/app/s0;->a(Landroid/app/NotificationChannel;)Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0, v3}, Lv6/a;->a(Landroid/app/NotificationChannel;Z)V

    const/4 v5, 0x7

    move v6, v5

    invoke-static {v0, v1}, Lo3/d;->a(Landroid/app/NotificationChannel;I)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v1, "inaitfuntioo"

    const-string v1, "ftnioontiaio"

    const/4 v6, 0x1

    const-string/jumbo v1, "ntioiatpofic"

    const-string/jumbo v1, "notification"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v6, 0x1

    invoke-static {v1, v0}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v0, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_use_sound:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget v0, Lcom/luck/picture/lib/R$string;->ps_use_camera:I

    :goto_1
    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-instance v1, Landroidx/core/app/x1$g;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v2, Lcom/luck/picture/lib/service/ForegroundService;->a:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v1, p0, v2}, Landroidx/core/app/x1$g;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget v2, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/service/ForegroundService;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Landroidx/core/app/x1$g;->P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1, v0}, Landroidx/core/app/x1$g;->O(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v3}, Landroidx/core/app/x1$g;->i0(Z)Landroidx/core/app/x1$g;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroidx/core/app/x1$g;->h()Landroid/app/Notification;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object v0
.end method

.method private b()Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    move v4, v3

    return-object v0
.end method

.method public static c(Landroid/content/Context;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-boolean v0, Lcom/luck/picture/lib/service/ForegroundService;->d:Z

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const/4 v3, 0x4

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->d()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroidx/media/session/a;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public static d(Landroid/content/Context;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    sget-boolean v0, Lcom/luck/picture/lib/service/ForegroundService;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const/4 v3, 0x5

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const-class v1, Lcom/luck/picture/lib/service/ForegroundService;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v0, 0x4

    move v1, v0

    return-object p1
.end method

.method public onCreate()V
    .locals 4

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-direct {p0}, Lcom/luck/picture/lib/service/ForegroundService;->a()Landroid/app/Notification;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v1, v0}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public onDestroy()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    sput-boolean v0, Lcom/luck/picture/lib/service/ForegroundService;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    sput-boolean v0, Lcom/luck/picture/lib/service/ForegroundService;->d:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-super {p0, p1, p2, p3}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p1
.end method
