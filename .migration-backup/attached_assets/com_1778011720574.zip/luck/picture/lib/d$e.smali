.class Lcom/luck/picture/lib/d$e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/adapter/holder/g$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->K1(Landroid/view/ViewGroup;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    or-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a(ILcom/luck/picture/lib/entity/LocalMedia;Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-boolean v0, p3, Lcom/luck/picture/lib/d;->t:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p3, Lcom/luck/picture/lib/d;->w:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget v1, Lcom/luck/picture/lib/R$string;->ps_camera_roll:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p3, v1}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-static {v0, p3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p3, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/d;->w:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p3, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p3, :cond_5

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean v0, p3, Lcom/luck/picture/lib/d;->t:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    or-int/2addr v3, v2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-boolean p1, p3, Lcom/luck/picture/lib/d;->x:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget p1, p2, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    iget p1, p2, Lcom/luck/picture/lib/entity/LocalMedia;->k:I

    :goto_0
    const/4 v3, 0x3

    iget-object p3, p3, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p3}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ne p1, p3, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->H()Z

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p3, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p3, p3, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    invoke-virtual {p3}, Landroidx/viewpager2/widget/ViewPager2;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p3, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    iget-object p3, p3, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p3, v0}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p3, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p3, p3, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p3}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x7

    const/4 v2, 0x2

    iget-object p3, p3, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p3, p1, v0}, Landroidx/viewpager2/widget/ViewPager2;->setCurrentItem(IZ)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p3, p2}, Lcom/luck/picture/lib/d;->v1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/d$e;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p2, p2, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance p3, Lcom/luck/picture/lib/d$e$a;

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {p3, p0, p1}, Lcom/luck/picture/lib/d$e$a;-><init>(Lcom/luck/picture/lib/d$e;I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2, p3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method
