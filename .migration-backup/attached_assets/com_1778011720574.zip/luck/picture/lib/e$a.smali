.class Lcom/luck/picture/lib/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->f1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/activity/result/a<",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v@su~/ ~~~@ @@c~on~S @ @~~~@@ora@ d@/@K~ ~@o  M@t~@  @@~ f@f1@i~ sbblo~.  t@4~~o~b~~yi@i ~~mo  -"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Landroid/net/Uri;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/e$a;->b(Landroid/net/Uri;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public b(Landroid/net/Uri;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lcom/luck/picture/lib/e;->d1(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->E()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->E0(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p1, :cond_2

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/e;->e1(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x5

    goto :goto_1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/e$a;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method
