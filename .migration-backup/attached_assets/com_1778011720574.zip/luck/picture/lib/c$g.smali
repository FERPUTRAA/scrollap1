.class Lcom/luck/picture/lib/c$g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/adapter/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->M1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;ILcom/luck/picture/lib/entity/LocalMedia;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@om~~ ud@/~ @@@o@of@.b@r1~@~~o ~a~f  /@~b4l~@M@b~@@@ lo     t~ivo i i y~~ctn K~ @@~-~s@S~@@~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/View;->isSelected()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p2, p3, v0}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x1

    invoke-virtual {p3}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget v0, Lcom/luck/picture/lib/R$anim;->ps_anim_modal_in:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p3, v0}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, p3}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p2
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->I()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public c(Landroid/view/View;ILcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/c;->v1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    if-ne p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/c;->x1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->i()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, p3, v1}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/c;->y1(Lcom/luck/picture/lib/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, p2, v1}, Lcom/luck/picture/lib/c;->p1(Lcom/luck/picture/lib/c;IZ)V

    :cond_2
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public d(Landroid/view/View;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/c;->n1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/a;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/c;->z1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "arstrivo"

    const/4 v3, 0x7

    const-string/jumbo v0, "vtrmrabo"

    const-string/jumbo v0, "vibrator"

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast p1, Landroid/os/Vibrator;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-wide/16 v0, 0x32

    const-wide/16 v0, 0x32

    const/4 v3, 0x4

    const-wide/16 v0, 0x32

    const-wide/16 v0, 0x32

    const/4 v2, 0x7

    and-int/2addr v3, v2

    invoke-virtual {p1, v0, v1}, Landroid/os/Vibrator;->vibrate(J)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$g;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/c;->n1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/a;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/widget/a;->p(I)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
