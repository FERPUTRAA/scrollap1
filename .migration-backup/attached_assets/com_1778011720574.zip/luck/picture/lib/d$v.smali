.class Lcom/luck/picture/lib/d$v;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/adapter/holder/b$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "v"
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method private constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/d$k;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d$v;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c sy~onb~o @~a do@~@~@~ ~~@@- @~@f~s~~@  ~~ urt~~li@Mi@@m @4~/ o@@~o~ f~  @b~ ~@lib Kot Sv@1/. @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/d;->g1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/luck/picture/lib/d;->i1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public b()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->u:Z

    const/4 v4, 0x3

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/d;->b1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x1

    move v4, v1

    move v3, v1

    move v3, v1

    const/4 v4, 0x5

    iput-boolean v1, v0, Lcom/luck/picture/lib/d;->u:Z

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v2, v2}, Lcom/luck/picture/lib/magical/MagicalView;->K(IIZ)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundAlpha(F)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, v0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    if-ge v2, v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast v0, Landroid/view/View;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method public c(IILs6/c;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ls6/c<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->v:Z

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-nez v1, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->u:Z

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-nez v1, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v10, 0x6

    const/4 v9, 0x1

    if-nez v1, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v9, 0x4

    move v10, v9

    if-eqz v1, :cond_0

    const/4 v10, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/d;->Z0(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p3, v0}, Ls6/c;->a(Ljava/lang/Object;)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object p3, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {p3}, Lcom/luck/picture/lib/d;->a1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-boolean p3, p3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz p3, :cond_5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object p3, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v0, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput-boolean v0, p3, Lcom/luck/picture/lib/d;->u:Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object p3, p3, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p3, p1, p2, v1}, Lcom/luck/picture/lib/magical/MagicalView;->A(IIZ)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object p3, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-boolean v2, p3, Lcom/luck/picture/lib/d;->x:Z

    const/4 v9, 0x4

    move v10, v9

    iget p3, p3, Lcom/luck/picture/lib/d;->s:I

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-eqz v2, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    add-int/2addr p3, v0

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {p3}, Lcom/luck/picture/lib/magical/a;->d(I)Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object p3

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-nez p3, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object p3, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object p3, p3, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p3, p1, p2, v1}, Lcom/luck/picture/lib/magical/MagicalView;->K(IIZ)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x7

    iget-object p1, p1, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/high16 p2, 0x3f800000    # 1.0f

    const/4 v9, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundAlpha(F)V

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object p1, p1, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ge v1, p1, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object p1, p1, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v10, 0x2

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    check-cast p1, Landroid/view/View;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_0

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v2, v0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x2

    iget v3, p3, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v9, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v4, p3, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget v5, p3, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v10, 0x3

    iget v6, p3, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v10, 0x0

    move v7, p1

    move v7, p1

    const/4 v10, 0x3

    move v7, p1

    move v7, p1

    const/4 v10, 0x1

    move v8, p2

    move v8, p2

    const/4 v10, 0x0

    move v8, p2

    move v8, p2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual/range {v2 .. v8}, Lcom/luck/picture/lib/magical/MagicalView;->F(IIIIII)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object p1, p1, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p1, v1}, Lcom/luck/picture/lib/magical/MagicalView;->J(Z)V

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object p1, p1, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 p2, 0x2

    const/4 p2, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-array p2, p2, [F

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    fill-array-data p2, :array_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string/jumbo p3, "lahmp"

    const-string p3, "alpha"

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-static {p1, p3, p2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-wide/16 p2, 0x32

    const-wide/16 p2, 0x32

    const/4 v10, 0x5

    const-wide/16 p2, 0x32

    const-wide/16 p2, 0x32

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v10, 0x3

    const/4 v9, 0x7

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v10, 0x5

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {p3, p1}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_5
    :goto_2
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public d(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p1, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v1, Lcom/luck/picture/lib/d;->s:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string v1, "/"

    const-string v1, "/"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v1, v1, Lcom/luck/picture/lib/d;->B:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public onBackPressed()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/d;->c1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x5

    move v3, v2

    invoke-static {v0}, Lcom/luck/picture/lib/d;->d1(Lcom/luck/picture/lib/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/d;->r1(Lcom/luck/picture/lib/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/d;->e1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0}, Lcom/luck/picture/lib/magical/MagicalView;->t()V

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$v;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/d;->f1(Lcom/luck/picture/lib/d;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method
