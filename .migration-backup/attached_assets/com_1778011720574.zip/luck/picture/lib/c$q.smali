.class Lcom/luck/picture/lib/c$q;
.super Lcom/luck/picture/lib/widget/TitleBar$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->c2()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/TitleBar$a;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@is~t/@do~~rM@o @~@ ~~iyo~  @bsa@~~@n @ @@4/.  c ~@mKb u  l@~~@o~~~iol ff~~b~-@@ t~ o~~1v~@@S@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x1

    move v2, v1

    invoke-static {v0}, Lcom/luck/picture/lib/c;->G1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/dialog/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/widget/PopupWindow;->isShowing()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/c;->G1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/dialog/a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/dialog/a;->dismiss()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public b(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/c;->G1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/dialog/a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/dialog/a;->showAsDropDown(Landroid/view/View;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public c()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/c;->j1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F0:Z

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/c;->u1(Lcom/luck/picture/lib/c;)J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/16 v2, 0x1f4

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    int-to-long v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-gez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-static {v0}, Lcom/luck/picture/lib/c;->W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->getItemCount()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-lez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/c$q;->a:Lcom/luck/picture/lib/c;

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1, v2}, Lcom/luck/picture/lib/c;->w1(Lcom/luck/picture/lib/c;J)J

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void
.end method
