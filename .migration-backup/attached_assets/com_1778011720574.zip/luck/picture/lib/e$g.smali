.class Lcom/luck/picture/lib/e$g;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->i1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/activity/result/a<",
        "Landroid/net/Uri;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~l@d@c~~@ @ lo@~~o i@ Kn f@  b~~~~   ~4~a~~@y @ @oo~S~~m@Mt ~-@@b1/~b@fr@s @itou vi@/~. ~@ o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p1, Landroid/net/Uri;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/e$g;->b(Landroid/net/Uri;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public b(Landroid/net/Uri;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lcom/luck/picture/lib/e;->Z0(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->E()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->E0(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p1, v1}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p1, :cond_2

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/e;->a1(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/e$g;->a:Lcom/luck/picture/lib/e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method
