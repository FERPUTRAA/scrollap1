.class Lcom/luck/picture/lib/d$u;
.super Lcom/luck/picture/lib/widget/TitleBar$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->L1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/d$u;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/TitleBar$a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b.s~1csf~o ~i~@lr~~ @Ky~ l~o@ ~tv@  @d-o@/m@~@4 i ~n @ @@b ~ to~io@  u~@S@~@~o@~/@ a~@  f~~@M~@b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$u;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/d;->r1(Lcom/luck/picture/lib/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    iget-boolean v1, v0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/d;->s1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$u;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/magical/MagicalView;->t()V

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d$u;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/d;->t1(Lcom/luck/picture/lib/d;)V

    :goto_0
    const/4 v2, 0x7

    move v3, v2

    return-void
.end method
