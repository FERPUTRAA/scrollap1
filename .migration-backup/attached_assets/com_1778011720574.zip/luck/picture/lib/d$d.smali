.class Lcom/luck/picture/lib/d$d;
.super Lcom/luck/picture/lib/decoration/WrapContentLinearLayoutManager;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->K1(Landroid/view/ViewGroup;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d$d;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p2}, Lcom/luck/picture/lib/decoration/WrapContentLinearLayoutManager;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public smoothScrollToPosition(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " bs i. K@ ~o~ @soi~~~~/r ~@@o @b @@@  @ f@a~~~l@v~m@u@ M~ @@@~@t/~o@dy~t  @~~~4~biS@~ o~ o-n~l1c"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->smoothScrollToPosition(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    new-instance p2, Lcom/luck/picture/lib/d$d$a;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p2, p0, p1}, Lcom/luck/picture/lib/d$d$a;-><init>(Lcom/luck/picture/lib/d$d;Landroid/content/Context;)V

    const/4 v1, 0x5

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/RecyclerView$b0;->setTargetPosition(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/RecyclerView$p;->startSmoothScroll(Landroidx/recyclerview/widget/RecyclerView$b0;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
