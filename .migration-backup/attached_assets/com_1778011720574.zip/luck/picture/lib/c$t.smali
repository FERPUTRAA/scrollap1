.class Lcom/luck/picture/lib/c$t;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/u;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->x(I[Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/c$t;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public a([Ljava/lang/String;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~@~bvo~c  ~f  o~ ~@~d@~K   ~~ 4 @@@b. ~~ito~i@S~~ o~s~@oyo@n// @~@-t @Ml@@1l @r~m@~@i fa@ ~u"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$t;->a:Lcom/luck/picture/lib/c;

    const/4 v0, 0x4

    move v1, v0

    invoke-static {p1}, Lcom/luck/picture/lib/c;->K1(Lcom/luck/picture/lib/c;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/c$t;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
