.class Lcom/luck/picture/lib/d$k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/magical/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->a2()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iput-object p1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a(F)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "s s~i @S y~~ro1@~~l@@ ~~ ~~~c b~~oM@@t@~@  @~o@~ @@-lun@od/iKb.~@~bv 4t~i~/a m@ o f@@f @~o @~  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, v1, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ge v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, v1, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v1, v1, Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, v1, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v1, Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Landroid/view/View;->setAlpha(F)V

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    return-void
.end method

.method public b()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, v0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/adapter/c;->b(I)Lcom/luck/picture/lib/adapter/holder/b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/16 v2, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ne v1, v2, :cond_1

    const/4 v5, 0x4

    iget-object v1, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    instance-of v1, v0, Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v0, Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, v0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method public c(Z)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v4, 0x1

    iget-boolean v0, p1, Lcom/luck/picture/lib/d;->x:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget p1, p1, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 p1, p1, 0x1

    :cond_0
    const/4 v4, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/magical/a;->d(I)Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, v0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v4, 0x5

    const/4 v3, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/adapter/c;->b(I)Lcom/luck/picture/lib/adapter/holder/b;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v2, p1, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget p1, p1, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v4, 0x3

    iput p1, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public d(Lcom/luck/picture/lib/magical/MagicalView;Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x3

    const/4 v1, 0x7

    iget-object p2, p1, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/adapter/c;->b(I)Lcom/luck/picture/lib/adapter/holder/b;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p2, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v1, 0x5

    move v2, v1

    iget-object p2, p2, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p2}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-lez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-lez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result p2

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0, p2}, Lcom/luck/picture/lib/utils/i;->q(II)Z

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p2, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p2, p1, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x3

    const/4 v1, 0x6

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, v0}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_1

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p2, p1, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x1

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p2, v0}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    instance-of p2, p1, Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p2, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p1, Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p2, p1, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getVisibility()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-ne p2, v0, :cond_3

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d$k;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/d;->W0(Lcom/luck/picture/lib/d;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method
