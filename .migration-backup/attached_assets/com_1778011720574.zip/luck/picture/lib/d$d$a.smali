.class Lcom/luck/picture/lib/d$d$a;
.super Landroidx/recyclerview/widget/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d$d;->smoothScrollToPosition(Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d$d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d$d;Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    iput-object p1, p0, Lcom/luck/picture/lib/d$d$a;->a:Lcom/luck/picture/lib/d$d;

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0, p2}, Landroidx/recyclerview/widget/s;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method protected calculateSpeedPerPixel(Landroid/util/DisplayMetrics;)F
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sb @~@o s~~fr-by@~/u  ~to@ o~K@ oiMt ~ @ ~~~ ~@@ ~~ovc.~@n4~da ~ il~@~/~Sbi@o1l~@@@  @@f@ @@~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget p1, p1, Landroid/util/DisplayMetrics;->densityDpi:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    int-to-float p1, p1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/high16 v0, 0x43960000    # 300.0f

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    div-float/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method
