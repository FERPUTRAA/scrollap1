.class Lcom/luck/picture/lib/c$f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->i2()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/c$f;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/c$f;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/c$f;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/c;->t1(Lcom/luck/picture/lib/c;)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c$f;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/c$f;->a:Lcom/luck/picture/lib/c;

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/c;->t1(Lcom/luck/picture/lib/c;)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setLastVisiblePosition(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
