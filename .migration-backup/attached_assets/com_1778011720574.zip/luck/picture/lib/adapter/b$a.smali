.class Lcom/luck/picture/lib/adapter/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/b;->g(Lcom/luck/picture/lib/adapter/holder/c;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/b$a;->a:Lcom/luck/picture/lib/adapter/b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ ssMm@ b@t@ @@ ~~ la@@ @@  ~n@~o~ic/if  @~l @@@f~.o~ o-b~ ~vSt~@o1b~y~@~ ~ ~~@@~~@4~@K ~ordu /i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/b$a;->a:Lcom/luck/picture/lib/adapter/b;

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/b;->a(Lcom/luck/picture/lib/adapter/b;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/b$a;->a:Lcom/luck/picture/lib/adapter/b;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/b;->a(Lcom/luck/picture/lib/adapter/b;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v1, 0x3

    invoke-interface {p1}, Lcom/luck/picture/lib/adapter/b$b;->b()V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method
