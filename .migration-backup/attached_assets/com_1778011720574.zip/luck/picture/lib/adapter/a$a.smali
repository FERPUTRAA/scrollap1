.class Lcom/luck/picture/lib/adapter/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/a;->d(Lcom/luck/picture/lib/adapter/a$b;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/luck/picture/lib/entity/LocalMediaFolder;

.field final synthetic c:Lcom/luck/picture/lib/adapter/a;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/a;ILcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/a$a;->c:Lcom/luck/picture/lib/adapter/a;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p2, p0, Lcom/luck/picture/lib/adapter/a$a;->a:I

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/luck/picture/lib/adapter/a$a;->b:Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bts  r/yn @l ~~~a~o@@@ i ~i~~l @ ~@ @~ot @@~~@ ~u~@v~K @~  @~o4c@bMsmf @~ -f@d .o@o/1@~~ib@S@~~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/a$a;->c:Lcom/luck/picture/lib/adapter/a;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/a;->a(Lcom/luck/picture/lib/adapter/a;)Ls6/a;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/a$a;->c:Lcom/luck/picture/lib/adapter/a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/a;->a(Lcom/luck/picture/lib/adapter/a;)Ls6/a;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, p0, Lcom/luck/picture/lib/adapter/a$a;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/a$a;->b:Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Ls6/a;->a(ILcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method
