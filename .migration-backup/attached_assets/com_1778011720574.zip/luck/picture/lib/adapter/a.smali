.class public Lcom/luck/picture/lib/adapter/a;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/adapter/a$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Lcom/luck/picture/lib/adapter/a$b;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation
.end field

.field private b:Ls6/a;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/adapter/a;)Ls6/a;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s ~~ ~@bn  ~@oy@S~v~ @bM~~/4~ @ o~@@Kcoa1@s@  lf@@@~ ~@idtf@.~-~@~@~~o~m @t @ib/~o@~~u lo@~ ir"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/a;->b:Ls6/a;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public b(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/a;->a:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public c()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/a;->a:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public d(Lcom/luck/picture/lib/adapter/a$b;I)V
    .locals 13
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/a;->a:Ljava/util/List;

    const/4 v12, 0x7

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x2

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v12, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v2

    const/4 v12, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->e()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    iget-object v4, p1, Lcom/luck/picture/lib/adapter/a$b;->c:Landroid/widget/TextView;

    const/4 v12, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->n()Z

    move-result v5

    const/4 v12, 0x0

    const/4 v6, 0x0

    const/4 v12, 0x5

    if-eqz v5, :cond_0

    const/4 v12, 0x0

    move v5, v6

    move v5, v6

    const/4 v12, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v5, 0x4

    :goto_0
    const/4 v12, 0x2

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    const/4 v12, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v4

    const/4 v12, 0x2

    iget-object v5, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x7

    const/4 v7, 0x1

    const/4 v12, 0x2

    if-eqz v4, :cond_1

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v8

    const/4 v12, 0x4

    invoke-virtual {v4}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v10

    const/4 v12, 0x5

    cmp-long v4, v8, v10

    const/4 v12, 0x3

    if-nez v4, :cond_1

    const/4 v12, 0x2

    move v4, v7

    move v4, v7

    move v4, v7

    move v4, v7

    const/4 v12, 0x6

    goto :goto_1

    :cond_1
    move v4, v6

    move v4, v6

    move v4, v6

    move v4, v6

    :goto_1
    const/4 v12, 0x5

    invoke-virtual {v5, v4}, Landroid/view/View;->setSelected(Z)V

    const/4 v12, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x7

    invoke-static {v4}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v4

    const/4 v12, 0x0

    if-eqz v4, :cond_2

    const/4 v12, 0x4

    iget-object v3, p1, Lcom/luck/picture/lib/adapter/a$b;->a:Landroid/widget/ImageView;

    const/4 v12, 0x6

    sget v4, Lcom/luck/picture/lib/R$drawable;->ps_audio_placeholder:I

    const/4 v12, 0x4

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v12, 0x7

    goto :goto_2

    :cond_2
    const/4 v12, 0x6

    sget-object v4, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v12, 0x7

    if-eqz v4, :cond_3

    const/4 v12, 0x4

    iget-object v5, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v12, 0x2

    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/4 v12, 0x1

    iget-object v8, p1, Lcom/luck/picture/lib/adapter/a$b;->a:Landroid/widget/ImageView;

    const/4 v12, 0x6

    invoke-interface {v4, v5, v3, v8}, Lq6/d;->d(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    :cond_3
    :goto_2
    const/4 v12, 0x1

    iget-object v3, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v12, 0x7

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v12, 0x1

    iget-object v4, p1, Lcom/luck/picture/lib/adapter/a$b;->b:Landroid/widget/TextView;

    const/4 v12, 0x6

    sget v5, Lcom/luck/picture/lib/R$string;->ps_camera_roll_num:I

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v12, 0x2

    new-array v8, v8, [Ljava/lang/Object;

    const/4 v12, 0x1

    aput-object v1, v8, v6

    const/4 v12, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v12, 0x7

    aput-object v1, v8, v7

    const/4 v12, 0x1

    invoke-virtual {v3, v5, v8}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x0

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v12, 0x1

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v12, 0x4

    new-instance v1, Lcom/luck/picture/lib/adapter/a$a;

    const/4 v12, 0x0

    invoke-direct {v1, p0, p2, v0}, Lcom/luck/picture/lib/adapter/a$a;-><init>(Lcom/luck/picture/lib/adapter/a;ILcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v12, 0x2

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v12, 0x3

    return-void
.end method

.method public e(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/a$b;
    .locals 4
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p2, v0}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget p2, Lcom/luck/picture/lib/R$layout;->ps_album_folder_item:I

    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance p2, Lcom/luck/picture/lib/adapter/a$b;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-direct {p2, p1}, Lcom/luck/picture/lib/adapter/a$b;-><init>(Landroid/view/View;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p2
.end method

.method public f(Ls6/a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/a;->b:Ls6/a;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public getItemCount()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/a;->a:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    return v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    check-cast p1, Lcom/luck/picture/lib/adapter/a$b;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/a;->d(Lcom/luck/picture/lib/adapter/a$b;I)V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/a;->e(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/a$b;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-object p1
.end method
