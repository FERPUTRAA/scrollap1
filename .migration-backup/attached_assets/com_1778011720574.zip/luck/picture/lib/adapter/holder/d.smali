.class public Lcom/luck/picture/lib/adapter/holder/d;
.super Lcom/luck/picture/lib/adapter/holder/c;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/c;-><init>(Landroid/view/View;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->tvCamera:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v1

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->a()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->c()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v3, v2, v3, v3}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v2, v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ne v2, v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget v2, Lcom/luck/picture/lib/R$string;->ps_tape:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->g()I

    move-result p1

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    int-to-float p1, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->e()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method
