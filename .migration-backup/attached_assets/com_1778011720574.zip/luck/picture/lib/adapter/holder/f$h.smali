.class Lcom/luck/picture/lib/adapter/holder/f$h;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/f;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$h;->b:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/f$h;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~~.~ @S@/@@~~~K~~m @d bai@rof~o@i@  u/@ls~tc-@@  ~ ~Mb o@ ~@ ~~n4t@ bi~ol ~@~y~@ v@ @f@~o~o 1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$h;->b:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$h;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/adapter/holder/b$e;->a(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1
.end method
