.class public Lcom/luck/picture/lib/adapter/holder/h;
.super Lcom/luck/picture/lib/adapter/holder/b;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;-><init>(Landroid/view/View;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method
