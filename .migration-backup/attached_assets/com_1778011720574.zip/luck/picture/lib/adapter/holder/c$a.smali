.class Lcom/luck/picture/lib/adapter/holder/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$a;->a:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1os~m~@~tb c  lo@y@@~ta@dlb@  rs@ of~~i @@@o~~/no~   ~/~fK~~ @ u@  ~@~oi @@bi@4vM ~ S-~~@~~@~~@."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$a;->a:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->c:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
