.class Lcom/luck/picture/lib/adapter/holder/b$c;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/b;->g(Lcom/luck/picture/lib/entity/LocalMedia;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:Lcom/luck/picture/lib/adapter/holder/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/b;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b$c;->b:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/b$c;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i.som l@bt@ ~@@~~r @ ovK@l~ ~@@~ -@ o@@ty~@~b@~i~  ~~ ~o~ ~~1~M@fo@S 4/~~/c@buin~@@do@  af~ @s ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p1, Landroid/graphics/Bitmap;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b$c;->b(Landroid/graphics/Bitmap;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-void
.end method

.method public b(Landroid/graphics/Bitmap;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b$c;->b:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/b$c;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Lcom/luck/picture/lib/adapter/holder/b;->f(Lcom/luck/picture/lib/entity/LocalMedia;Landroid/graphics/Bitmap;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
