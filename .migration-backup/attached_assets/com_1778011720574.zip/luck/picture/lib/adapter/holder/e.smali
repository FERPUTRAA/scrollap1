.class public Lcom/luck/picture/lib/adapter/holder/e;
.super Lcom/luck/picture/lib/adapter/holder/c;


# instance fields
.field private final l:Landroid/widget/ImageView;

.field private final m:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/c;-><init>(Landroid/view/View;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget p2, Lcom/luck/picture/lib/R$id;->tv_media_tag:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast p2, Landroid/widget/TextView;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget p2, Lcom/luck/picture/lib/R$id;->ivEditor:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    check-cast p1, Landroid/widget/ImageView;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/e;->l:Landroid/widget/ImageView;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->r()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    and-int/2addr v7, v6

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->q()[I

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->a([I)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/16 v3, 0xc

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    instance-of v1, v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    move v7, v6

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    check-cast p1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p1, v3}, Landroid/widget/RelativeLayout$LayoutParams;->removeRule(I)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    array-length p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    move v1, v2

    move v1, v2

    const/4 v7, 0x3

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ge v1, p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    aget v4, v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v5, p0, Lcom/luck/picture/lib/adapter/holder/e;->l:Landroid/widget/ImageView;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast v5, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v5, v4}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->C()[I

    move-result-object p1

    const/4 v7, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->a([I)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    instance-of v0, v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    check-cast v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/16 v1, 0x15

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->removeRule(I)V

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    check-cast v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v3}, Landroid/widget/RelativeLayout$LayoutParams;->removeRule(I)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    array-length v0, p1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-ge v2, v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    aget v1, p1, v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    check-cast v3, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {v3, v1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_1

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->B()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_3

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->E()I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x0

    int-to-float p1, p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->D()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz p2, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_5
    const/4 v7, 0x1

    return-void
.end method


# virtual methods
.method public e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-~s@ @ 1 oo~~  n~ ~~@@@~tl dv @Sf.b @@@@ @@~b~~o~~~ c 4i~t @iKrfo @u~ ~ / ~@@~~alo@iM~o@@mb/y~s~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->M()Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/e;->l:Landroid/widget/ImageView;

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/e;->l:Landroid/widget/ImageView;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_0
    const/4 v3, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->e(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/c;->d:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_gif_tag:I

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->i(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p2, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/c;->d:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$string;->ps_webp_tag:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2, p1}, Lcom/luck/picture/lib/utils/i;->q(II)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/c;->d:Landroid/content/Context;

    const/4 v2, 0x6

    move v3, v2

    sget v0, Lcom/luck/picture/lib/R$string;->ps_long_chart:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x0

    goto :goto_1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/e;->m:Landroid/widget/TextView;

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method
