.class Lcom/luck/picture/lib/adapter/holder/f$i;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$i;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onCompletion(Landroid/media/MediaPlayer;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~s@.~~f@~ @  i@b~b~~a ~t4tv~~ @/@~o~dl@  s~@S~ l@@ @~Kf~~~-/r@~@oo~@Mi@m 1 ~@  o@c~yiuo   nb@@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$i;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->B(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$i;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->q(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$i;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/luck/picture/lib/adapter/holder/f;->r(Lcom/luck/picture/lib/adapter/holder/f;Z)V

    const/4 v2, 0x6

    return-void
.end method
