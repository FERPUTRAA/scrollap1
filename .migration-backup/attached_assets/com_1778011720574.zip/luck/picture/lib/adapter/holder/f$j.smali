.class Lcom/luck/picture/lib/adapter/holder/f$j;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$j;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public onError(Landroid/media/MediaPlayer;II)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sv  @o~/~@@  @~@ @~ ir@ t/b~d@m@Ky~o~~-i@~@tS ~~~f 1@ s .i ~@aoM ~cbo~@o  @~4@~ufn~@o~~l l@@b~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$j;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->q(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$j;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 p2, 0x7

    const/4 p2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/luck/picture/lib/adapter/holder/f;->r(Lcom/luck/picture/lib/adapter/holder/f;Z)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p1
.end method
