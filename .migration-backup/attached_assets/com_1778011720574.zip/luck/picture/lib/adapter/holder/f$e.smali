.class Lcom/luck/picture/lib/adapter/holder/f$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/f;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$e;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@4s@l1db~u-~@~o M ~f/~@~m so~@@@~ oc~~iS o~@/@  ~K@@if@l t r@@~~vo~ ~ ny@~@~  ~ ~at  b@.ib @@@o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p3, p0, Lcom/luck/picture/lib/adapter/holder/f$e;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p3, p2}, Lcom/luck/picture/lib/adapter/holder/f;->w(Lcom/luck/picture/lib/adapter/holder/f;I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/f$e;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p2}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/f$e;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-virtual {p2, p1}, Landroid/media/MediaPlayer;->seekTo(I)V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 2

    const/4 v1, 0x3

    return-void
.end method
