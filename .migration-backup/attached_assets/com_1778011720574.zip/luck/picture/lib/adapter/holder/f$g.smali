.class Lcom/luck/picture/lib/adapter/holder/f$g;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/f;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;Lcom/luck/picture/lib/entity/LocalMedia;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s ~~bKo.f @/ arf @~ @@~o@@@o ~~@ -l~~tmd~~ /@~ M@os~o~~@4~u~y @ @i@ bS~t~l@@ @ n@~~ @@bioiv c1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->w()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/adapter/holder/b$e;->d(Ljava/lang/String;)V

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->x(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->y(Lcom/luck/picture/lib/adapter/holder/f;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->z(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_2
    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->c:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$g;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/luck/picture/lib/adapter/holder/f;->A(Lcom/luck/picture/lib/adapter/holder/f;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
