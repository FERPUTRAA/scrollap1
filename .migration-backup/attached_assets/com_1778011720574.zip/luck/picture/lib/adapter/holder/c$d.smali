.class Lcom/luck/picture/lib/adapter/holder/c$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:I

.field final synthetic c:Lcom/luck/picture/lib/adapter/holder/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/c;Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p3, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->P()Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p1, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->g(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G:Z

    const/4 v4, 0x5

    if-nez p1, :cond_4

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    if-nez p1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x7

    const/4 v3, 0x4

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H:Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eq p1, v0, :cond_4

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-eqz p1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v1, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-ne p1, v0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x0

    :cond_4
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/c;->b:Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->b:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {p1, v0, v1, v2}, Lcom/luck/picture/lib/adapter/b$b;->c(Landroid/view/View;ILcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    goto :goto_1

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$d;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->c:Landroid/view/View;

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->performClick()Z

    :cond_6
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void
.end method
