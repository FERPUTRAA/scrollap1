.class Lcom/luck/picture/lib/adapter/holder/f$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/f;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$d;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "iis@@@4u@~     ./~  i~M~ ~v~ ~@~n@@~@@Ky ~t~l~~a soo@@f @t@~@ br d@~ 1@~~ofm@oo- o@~l~/@bc@ ~b~S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$d;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->v(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method
