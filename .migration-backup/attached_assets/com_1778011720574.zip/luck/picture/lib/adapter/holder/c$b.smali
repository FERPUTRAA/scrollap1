.class Lcom/luck/picture/lib/adapter/holder/c$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:I

.field final synthetic c:Lcom/luck/picture/lib/adapter/holder/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/c;Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v0, 0x0

    move v1, v0

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p3, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os ~t@~lo@Kv~@so~.i@d ~~/uf ~@~bl~i4/o~@@ f~~-n@ y~M~~@@@@~~ o~c~ ~b ~ 1 @S @b @ r@ ~miao@   @t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->P()Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/c;->b:Landroid/widget/TextView;

    const/4 v4, 0x4

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->b:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p1, v0, v1, v2}, Lcom/luck/picture/lib/adapter/b$b;->a(Landroid/view/View;ILcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ne p1, v0, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p1, Lcom/luck/picture/lib/adapter/holder/c;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W0:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/c;->a:Landroid/widget/ImageView;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/b;->b(Landroid/view/View;)V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->c:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/c$b;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/luck/picture/lib/adapter/holder/c;->c(Lcom/luck/picture/lib/adapter/holder/c;Lcom/luck/picture/lib/entity/LocalMedia;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/luck/picture/lib/adapter/holder/c;->d(Lcom/luck/picture/lib/adapter/holder/c;Z)V

    :cond_3
    :goto_0
    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
