.class Lcom/luck/picture/lib/adapter/holder/f$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@@s~@@ @~f@1~b s@c  ~~@~~/ i~o ab ~o~~r ~o@@@t~S~4@.~ @o~om@~~yb~/ioK  @if v@@@M n~ ud @ l@ -~t~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->getCurrentPosition()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    int-to-long v0, v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/d;->c(J)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v3, v3, Lcom/luck/picture/lib/adapter/holder/f;->o:Landroid/widget/TextView;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x1

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-nez v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v3, v3, Lcom/luck/picture/lib/adapter/holder/f;->o:Landroid/widget/TextView;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    int-to-long v2, v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    sub-long/2addr v2, v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-lez v2, :cond_0

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v2, v2, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x5

    long-to-int v3, v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v3, v2, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v2}, Lcom/luck/picture/lib/adapter/holder/f;->o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2}, Landroid/media/MediaPlayer;->getDuration()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {v3, v2}, Landroid/widget/ProgressBar;->setProgress(I)V

    :cond_1
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    rem-long/2addr v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    sub-long/2addr v4, v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$b;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/f;->p(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/os/Handler;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, p0, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method
