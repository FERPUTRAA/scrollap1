.class public Lcom/luck/picture/lib/adapter/holder/f;
.super Lcom/luck/picture/lib/adapter/holder/b;


# static fields
.field private static final A:J = 0x3e8L

.field private static final y:J = 0xbb8L

.field private static final z:J = 0x3e8L


# instance fields
.field private final k:Landroid/os/Handler;

.field public l:Landroid/widget/ImageView;

.field public m:Landroid/widget/TextView;

.field public n:Landroid/widget/TextView;

.field public o:Landroid/widget/TextView;

.field public p:Landroid/widget/SeekBar;

.field public q:Landroid/widget/ImageView;

.field public r:Landroid/widget/ImageView;

.field private s:Landroid/media/MediaPlayer;

.field private t:Z

.field public u:Ljava/lang/Runnable;

.field private final v:Landroid/media/MediaPlayer$OnCompletionListener;

.field private final w:Landroid/media/MediaPlayer$OnErrorListener;

.field private final x:Landroid/media/MediaPlayer$OnPreparedListener;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;-><init>(Landroid/view/View;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Landroid/media/MediaPlayer;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/f$b;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/adapter/holder/f$b;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->u:Ljava/lang/Runnable;

    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/f$i;

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/adapter/holder/f$i;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->v:Landroid/media/MediaPlayer$OnCompletionListener;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/f$j;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/adapter/holder/f$j;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->w:Landroid/media/MediaPlayer$OnErrorListener;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/f$a;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/adapter/holder/f$a;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->x:Landroid/media/MediaPlayer$OnPreparedListener;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget v0, Lcom/luck/picture/lib/R$id;->iv_play_video:I

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v0, Landroid/widget/ImageView;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->l:Landroid/widget/ImageView;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->tv_audio_name:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->m:Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->tv_current_time:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->o:Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->tv_total_duration:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->n:Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->music_seek_bar:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Landroid/widget/SeekBar;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->iv_play_back:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->q:Landroid/widget/ImageView;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->iv_play_fast:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    check-cast p1, Landroid/widget/ImageView;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->r:Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic A(Lcom/luck/picture/lib/adapter/holder/f;Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/ s  l~@-@oc@a~@@@@K@~b4@ls ni .~d@my@ ~@/@u~~M~@b ~ @~b ~~~i @~1ti@ @~rf f ~~S~t~@~oo o~~o@o   "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/f;->O(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic B(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->Q()V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private C()V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    int-to-long v0, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    const/4 v7, 0x2

    const-wide/16 v2, 0xbb8

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    cmp-long v0, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-lez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getMax()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    move v7, v6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    int-to-long v4, v1

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    add-long/2addr v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    long-to-int v1, v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->K(I)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method private D()V
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->pause()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x1

    shr-int/2addr v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->E(Z)V

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->Q()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method private E(Z)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->Q()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->o:Landroid/widget/TextView;

    const/4 v2, 0x3

    move v3, v2

    const-string v1, "0:sm0"

    const-string v1, "00s0:"

    const/4 v3, 0x3

    const-string v1, "0:00o"

    const-string v1, "00:00"

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->J(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->l:Landroid/widget/ImageView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$drawable;->ps_ic_audio_play:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v2, 0x0

    move v3, v2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Lcom/luck/picture/lib/adapter/holder/b$e;->d(Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method private F()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->P()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->J(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->l:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget v1, Lcom/luck/picture/lib/R$drawable;->ps_ic_audio_stop:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method private H()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->reset()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method private I()V
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->P()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->F()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private J(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->q:Landroid/widget/ImageView;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->r:Landroid/widget/ImageView;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->q:Landroid/widget/ImageView;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->r:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->q:Landroid/widget/ImageView;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/high16 v0, 0x3f000000    # 0.5f

    const/4 v1, 0x2

    and-int/2addr v2, v1

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->r:Landroid/widget/ImageView;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private K(I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    int-to-long v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/d;->c(J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->o:Landroid/widget/TextView;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private L()V
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->v:Landroid/media/MediaPlayer$OnCompletionListener;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->w:Landroid/media/MediaPlayer$OnErrorListener;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->x:Landroid/media/MediaPlayer$OnPreparedListener;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v3, 0x2

    return-void
.end method

.method private M()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private N()V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    cmp-long v0, v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-gez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    int-to-long v4, v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    sub-long/2addr v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    long-to-int v1, v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->K(I)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    return-void
.end method

.method private O(Ljava/lang/String;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v3, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/media/MediaPlayer;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->prepare()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->seekTo(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private P()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->u:Ljava/lang/Runnable;

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method private Q()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->u:Ljava/lang/Runnable;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic o(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/media/MediaPlayer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic p(Lcom/luck/picture/lib/adapter/holder/f;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic q(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->H()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic r(Lcom/luck/picture/lib/adapter/holder/f;Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/f;->E(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic s(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->P()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic t(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->F()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic u(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->N()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic v(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->C()V

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic w(Lcom/luck/picture/lib/adapter/holder/f;I)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/f;->K(I)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic x(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->D()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic y(Lcom/luck/picture/lib/adapter/holder/f;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-boolean p0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic z(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->I()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public G()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->u:Ljava/lang/Runnable;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->M()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->s:Landroid/media/MediaPlayer;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->u()J

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/d;->h(J)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->G()J

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v3, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v1, v2, v3}, Lcom/luck/picture/lib/utils/k;->i(JI)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->w()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const-string v3, "/n"

    const-string v3, "\n"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const-string v3, "  -"

    const-string v3, " - "

    const/4 v7, 0x7

    const-string v3, " - "

    const-string v3, " - "

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v4, Landroid/text/SpannableStringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v4, v5}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    const/4 v7, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    add-int/2addr v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v2, Landroid/text/style/AbsoluteSizeSpan;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/high16 v5, 0x41400000    # 12.0f

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3, v5}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v2, v3}, Landroid/text/style/AbsoluteSizeSpan;-><init>(I)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/16 v3, 0x11

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4, v2, v1, v0, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    new-instance v2, Landroid/text/style/ForegroundColorSpan;

    const/4 v7, 0x6

    const v5, -0x9a9a9b

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v2, v5}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4, v2, v1, v0, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->m:Landroid/widget/TextView;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->n:Landroid/widget/TextView;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->v()J

    move-result-wide v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v1, v2}, Lcom/luck/picture/lib/utils/d;->c(J)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x2

    move v7, v6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->v()J

    move-result-wide v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    long-to-int v1, v1

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setMax(I)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->J(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->q:Landroid/widget/ImageView;

    const/4 v7, 0x0

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/f$c;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/f$c;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->r:Landroid/widget/ImageView;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/f$d;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/f$d;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/f$e;

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/f$e;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x3

    const/4 v6, 0x2

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/f$f;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/f$f;-><init>(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->l:Landroid/widget/ImageView;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/f$g;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v1, p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/f$g;-><init>(Lcom/luck/picture/lib/adapter/holder/f;Lcom/luck/picture/lib/entity/LocalMedia;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/f$h;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/adapter/holder/f$h;-><init>(Lcom/luck/picture/lib/adapter/holder/f;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v7, 0x2

    invoke-virtual {p2, v0}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-void
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->L()V

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->E(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->t:Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f;->k:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/f;->u:Ljava/lang/Runnable;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->M()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/f;->H()V

    const/4 v0, 0x5

    move v3, v0

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/adapter/holder/f;->E(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method
