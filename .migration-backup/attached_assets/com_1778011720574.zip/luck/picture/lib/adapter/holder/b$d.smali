.class Lcom/luck/picture/lib/adapter/holder/b$d;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/b;->f(Lcom/luck/picture/lib/entity/LocalMedia;Landroid/graphics/Bitmap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/widget/ImageView$ScaleType;

.field final synthetic b:Lcom/luck/picture/lib/adapter/holder/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/b;Landroid/widget/ImageView$ScaleType;)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b$d;->b:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/b$d;->a:Landroid/widget/ImageView$ScaleType;

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p1, Ljava/lang/Boolean;

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b$d;->b(Ljava/lang/Boolean;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public b(Ljava/lang/Boolean;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b$d;->b:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    move v2, v1

    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b$d;->a:Landroid/widget/ImageView$ScaleType;

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
