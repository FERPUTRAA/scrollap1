.class Lcom/luck/picture/lib/adapter/holder/f$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/f;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$c;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@4sorb~~t @@~   ~ ~@~o@K@@fo / s.~bob~@~oa~M@~@~/l~ l~n @@~ ~ 1 y~i fSo@- ~@c  i~@i@@@~mu@ @~d~v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$c;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->u(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
