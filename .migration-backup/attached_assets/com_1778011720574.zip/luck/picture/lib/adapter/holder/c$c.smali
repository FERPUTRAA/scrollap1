.class Lcom/luck/picture/lib/adapter/holder/c$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/luck/picture/lib/adapter/holder/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/c;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/c$c;->b:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p2, p0, Lcom/luck/picture/lib/adapter/holder/c$c;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s @~ @M  imo@tS~@~b ~oa @~~v1~  / ~c~buo@@~  ol@si@~4ydi~@~~rt@~oKf  ~b-@~/.~@n@ f~ @~ ~~@@l@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/c$c;->b:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/c$c;->b:Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/c;->b(Lcom/luck/picture/lib/adapter/holder/c;)Lcom/luck/picture/lib/adapter/b$b;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/c$c;->a:I

    const/4 v2, 0x4

    move v3, v2

    invoke-interface {v0, p1, v1}, Lcom/luck/picture/lib/adapter/b$b;->d(Landroid/view/View;I)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return p1
.end method
