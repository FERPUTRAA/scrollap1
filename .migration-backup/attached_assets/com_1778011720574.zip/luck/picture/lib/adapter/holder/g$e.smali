.class Lcom/luck/picture/lib/adapter/holder/g$e;
.super Landroidx/recyclerview/widget/RecyclerView$g0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "e"
.end annotation


# instance fields
.field a:Landroid/widget/ImageView;

.field b:Landroid/widget/ImageView;

.field c:Landroid/widget/ImageView;

.field d:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$g0;-><init>(Landroid/view/View;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->ivImage:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v0, Landroid/widget/ImageView;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->a:Landroid/widget/ImageView;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->ivPlay:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v0, Landroid/widget/ImageView;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->b:Landroid/widget/ImageView;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->ivEditor:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->c:Landroid/widget/ImageView;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget v0, Lcom/luck/picture/lib/R$id;->viewBorder:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->d:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->r()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->c:Landroid/widget/ImageView;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->r()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->v()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g$e;->d:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->v()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->w()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, v0, v0}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method
