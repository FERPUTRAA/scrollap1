.class Lcom/luck/picture/lib/adapter/holder/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/g;->g(Lcom/luck/picture/lib/adapter/holder/g$e;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/g$e;

.field final synthetic b:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic c:Lcom/luck/picture/lib/adapter/holder/g;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/g;Lcom/luck/picture/lib/adapter/holder/g$e;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->c:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->a:Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->b:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s~f-u@@s b @t@~n@~@ @ v~r/~i@~oy @4l @~omt.@~c~ ioab~~o@S fi @~~ @ ~l~/@~@ o ~ 1@~ ~Kd@Mb ~@ ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->c:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/g;->a(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$c;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->c:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/g;->a(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$c;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->a:Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$g0;->getAbsoluteAdapterPosition()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/g$a;->b:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2, p1}, Lcom/luck/picture/lib/adapter/holder/g$c;->a(ILcom/luck/picture/lib/entity/LocalMedia;Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method
