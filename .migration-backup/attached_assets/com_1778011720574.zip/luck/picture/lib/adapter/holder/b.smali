.class public Lcom/luck/picture/lib/adapter/holder/b;
.super Landroidx/recyclerview/widget/RecyclerView$g0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/adapter/holder/b$e;
    }
.end annotation


# static fields
.field public static final h:I = 0x1

.field public static final i:I = 0x2

.field public static final j:I = 0x3


# instance fields
.field protected final a:I

.field protected final b:I

.field protected final c:I

.field protected d:Lcom/luck/picture/lib/entity/LocalMedia;

.field protected final e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field public f:Lcom/luck/picture/lib/photoview/PhotoView;

.field protected g:Lcom/luck/picture/lib/adapter/holder/b$e;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$g0;-><init>(Landroid/view/View;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->f(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->h(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    iput v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;->c(Landroid/view/View;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static d(Landroid/view/ViewGroup;II)Lcom/luck/picture/lib/adapter/holder/b;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ sM~@b@ o1~ sa@~@~~u l.f-lK ~ @oby~o /i@@~~@@ @bn ~iS~@~~ @ @m ~~4@@~~vd  t rio~  @@o~f@@~/t@c~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p2, p0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 p2, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x2

    if-ne p1, p2, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p1, Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p1, p0}, Lcom/luck/picture/lib/adapter/holder/i;-><init>(Landroid/view/View;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p2, 0x3

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne p1, p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p1, Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p1, p0}, Lcom/luck/picture/lib/adapter/holder/f;-><init>(Landroid/view/View;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p1, Lcom/luck/picture/lib/adapter/holder/h;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p1, p0}, Lcom/luck/picture/lib/adapter/holder/h;-><init>(Landroid/view/View;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p1
.end method


# virtual methods
.method public b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->d:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;->e(Lcom/luck/picture/lib/entity/LocalMedia;)[I

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    aget v1, p2, v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    aget p2, p2, v2

    const/4 v4, 0x3

    invoke-static {v1, p2}, Lcom/luck/picture/lib/utils/c;->b(II)[I

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    aget v0, p2, v0

    const/4 v4, 0x6

    aget p2, p2, v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, p1, v0, p2}, Lcom/luck/picture/lib/adapter/holder/b;->g(Lcom/luck/picture/lib/entity/LocalMedia;II)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;->n(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/adapter/holder/b;->k()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/adapter/holder/b;->l()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method protected c(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->preview_image:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p1, Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method protected e(Lcom/luck/picture/lib/entity/LocalMedia;)[I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-lez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-lez v0, :cond_0

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    filled-new-array {v0, p1}, [I

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    filled-new-array {v0, p1}, [I

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method

.method protected f(Lcom/luck/picture/lib/entity/LocalMedia;Landroid/graphics/Bitmap;)V
    .locals 7

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez p2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {p1}, Lcom/luck/picture/lib/adapter/holder/b$e;->b()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto/16 :goto_6

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->i(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->q(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->n(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->e(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, p2}, Lcom/luck/picture/lib/adapter/holder/b;->j(Landroid/graphics/Bitmap;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v1, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v6, 0x7

    const/4 v5, 0x0

    sget-object v2, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/photoview/PhotoView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v1, v2, v0, v3}, Lq6/d;->b(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    :cond_3
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-gtz v0, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->Y1(I)V

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-gtz v0, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->U1(I)V

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/i;->q(II)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v0, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget p2, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_5

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;->e(Lcom/luck/picture/lib/entity/LocalMedia;)[I

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lez v1, :cond_7

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-lez v1, :cond_7

    const/4 v5, 0x5

    move v6, v5

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_2

    :cond_7
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    move v1, v3

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    :goto_2
    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_3

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    aget v3, p1, v3

    :goto_3
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v1, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_4

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    aget p1, p1, v2

    :goto_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    move p2, v3

    move p2, v3

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v0, p1

    move v0, p1

    const/4 v6, 0x1

    move v0, p1

    move v0, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :goto_5
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v6, 0x7

    const/4 v5, 0x6

    new-instance v2, Lcom/luck/picture/lib/adapter/holder/b$d;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v2, p0, p1}, Lcom/luck/picture/lib/adapter/holder/b$d;-><init>(Lcom/luck/picture/lib/adapter/holder/b;Landroid/widget/ImageView$ScaleType;)V

    const/4 v6, 0x6

    invoke-interface {v1, p2, v0, v2}, Lcom/luck/picture/lib/adapter/holder/b$e;->c(IILs6/c;)V

    :goto_6
    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method protected g(Lcom/luck/picture/lib/entity/LocalMedia;II)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v5, Lcom/luck/picture/lib/adapter/holder/b$c;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v5, p0, p1}, Lcom/luck/picture/lib/adapter/holder/b$c;-><init>(Lcom/luck/picture/lib/adapter/holder/b;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    move v3, p2

    move v3, p2

    const/4 v7, 0x6

    move v3, p2

    move v3, p2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    move v4, p3

    move v4, p3

    const/4 v7, 0x4

    move v4, p3

    move v4, p3

    const/4 v7, 0x5

    invoke-interface/range {v0 .. v5}, Lq6/d;->f(Landroid/content/Context;Ljava/lang/String;IILs6/c;)V

    :cond_0
    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void
.end method

.method public h()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public i()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method protected j(Landroid/graphics/Bitmap;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/AppCompatImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method protected k()V
    .locals 4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v3, 0x4

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/b$a;-><init>(Lcom/luck/picture/lib/adapter/holder/b;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/photoview/PhotoView;->setOnViewTapListener(Lcom/luck/picture/lib/photoview/j;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method protected l()V
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/b$b;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/adapter/holder/b$b;-><init>(Lcom/luck/picture/lib/adapter/holder/b;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/photoview/PhotoView;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    return-void
.end method

.method public m(Lcom/luck/picture/lib/adapter/holder/b$e;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method protected n(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v3, 0x5

    if-ge v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-lez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-lez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    int-to-float v0, v0

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    int-to-float p1, p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    div-float/2addr v0, p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    int-to-float p1, p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    div-float/2addr p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    float-to-int p1, p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-le p1, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->c:I

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/16 p1, 0x11

    const/4 v3, 0x3

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
