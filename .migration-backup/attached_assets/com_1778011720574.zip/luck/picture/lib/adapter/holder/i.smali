.class public Lcom/luck/picture/lib/adapter/holder/i;
.super Lcom/luck/picture/lib/adapter/holder/b;


# instance fields
.field public k:Landroid/widget/ImageView;

.field public l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

.field public m:Landroid/widget/ProgressBar;

.field private final n:Lcom/google/android/exoplayer2/Player$Listener;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/b;-><init>(Landroid/view/View;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/i$c;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/adapter/holder/i$c;-><init>(Lcom/luck/picture/lib/adapter/holder/i;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->n:Lcom/google/android/exoplayer2/Player$Listener;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->iv_play_video:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->playerView:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->progress:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p1, Landroid/widget/ProgressBar;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->setUseController(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/16 v0, 0x8

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic o(Lcom/luck/picture/lib/adapter/holder/i;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  so~o@~~S @@@- @   bl~o lt@~1~@~ r~@@b@ ots@@  .~~@~ yKi@cin@~~i@f~4M @~o b~d@f @vuma/o~~~~/ @~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/i;->q()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic p(Lcom/luck/picture/lib/adapter/holder/i;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/i;->r()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method private q()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v2, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->setVisibility(I)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Lcom/luck/picture/lib/adapter/holder/b$e;->d(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method private r()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 v1, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->getVisibility()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ne v0, v1, :cond_3

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->setVisibility(I)V

    :cond_3
    const/4 v2, 0x0

    move v3, v2

    return-void
.end method


# virtual methods
.method public b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/b;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/adapter/holder/i;->n(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/i$a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/i$a;-><init>(Lcom/luck/picture/lib/adapter/holder/i;Lcom/luck/picture/lib/entity/LocalMedia;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p2, Lcom/luck/picture/lib/adapter/holder/i$b;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p2, p0}, Lcom/luck/picture/lib/adapter/holder/i$b;-><init>(Lcom/luck/picture/lib/adapter/holder/i;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public h()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/exoplayer2/ExoPlayer$Builder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/exoplayer2/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/ExoPlayer$Builder;->build()Lcom/google/android/exoplayer2/ExoPlayer;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->setPlayer(Lcom/google/android/exoplayer2/Player;)V

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i;->n:Lcom/google/android/exoplayer2/Player$Listener;

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lcom/google/android/exoplayer2/Player;->addListener(Lcom/google/android/exoplayer2/Player$Listener;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->getPlayer()Lcom/google/android/exoplayer2/Player;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i;->n:Lcom/google/android/exoplayer2/Player$Listener;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Lcom/google/android/exoplayer2/Player;->removeListener(Lcom/google/android/exoplayer2/Player$Listener;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/google/android/exoplayer2/Player;->release()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->setPlayer(Lcom/google/android/exoplayer2/Player;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/adapter/holder/i;->q()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method protected n(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ge v0, v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-le v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    int-to-float v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    int-to-float v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result p1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    int-to-float p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    div-float/2addr v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget p1, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    int-to-float p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    div-float/2addr p1, v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    float-to-int p1, p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x1

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    const/4 v4, 0x6

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-le p1, v1, :cond_1

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v1, p0, Lcom/luck/picture/lib/adapter/holder/b;->c:I

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 v1, 0x11

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/b;->f:Lcom/luck/picture/lib/photoview/PhotoView;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v2, p0, Lcom/luck/picture/lib/adapter/holder/b;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v2, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    iget v2, p0, Lcom/luck/picture/lib/adapter/holder/b;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-le p1, v2, :cond_2

    const/4 v3, 0x0

    move v4, v3

    iget v2, p0, Lcom/luck/picture/lib/adapter/holder/b;->c:I

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput v2, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method public s()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->getPlayer()Lcom/google/android/exoplayer2/Player;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i;->n:Lcom/google/android/exoplayer2/Player$Listener;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lcom/google/android/exoplayer2/Player;->removeListener(Lcom/google/android/exoplayer2/Player$Listener;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/google/android/exoplayer2/Player;->release()V

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    return-void
.end method
