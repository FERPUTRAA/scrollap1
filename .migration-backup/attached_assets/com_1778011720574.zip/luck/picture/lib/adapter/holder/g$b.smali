.class Lcom/luck/picture/lib/adapter/holder/g$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/g;->g(Lcom/luck/picture/lib/adapter/holder/g$e;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/g$e;

.field final synthetic b:Lcom/luck/picture/lib/adapter/holder/g;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/g;Lcom/luck/picture/lib/adapter/holder/g$e;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->b:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->a:Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->b:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/adapter/holder/g;->b(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$d;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->a:Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$g0;->getAbsoluteAdapterPosition()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->b:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/adapter/holder/g;->b(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$d;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/g$b;->a:Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-interface {v1, v2, v0, p1}, Lcom/luck/picture/lib/adapter/holder/g$d;->a(Landroidx/recyclerview/widget/RecyclerView$g0;ILandroid/view/View;)V

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    const/4 p1, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    return p1
.end method
