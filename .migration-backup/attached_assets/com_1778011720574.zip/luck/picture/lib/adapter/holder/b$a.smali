.class Lcom/luck/picture/lib/adapter/holder/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/photoview/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/b;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b$a;->a:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;FF)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os@~~ o~@~yb i@@@~itM~ ~@~ f4/l~b @f~ u  ~rSsto b@/od@.co 1~@mi@@~~vK~~~o @@ @l~ @-@@~~n @ ~@a "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/b$a;->a:Lcom/luck/picture/lib/adapter/holder/b;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    if-eqz p1, :cond_0

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-interface {p1}, Lcom/luck/picture/lib/adapter/holder/b$e;->onBackPressed()V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
