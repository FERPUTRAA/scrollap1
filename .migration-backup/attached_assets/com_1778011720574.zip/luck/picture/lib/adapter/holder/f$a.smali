.class Lcom/luck/picture/lib/adapter/holder/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/f;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onPrepared(Landroid/media/MediaPlayer;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@Ss @suf @ .ooi@o~~~@~~ ~M@1ybil@l~ r~d-o~~o @b~~~@~@@~inK f/m ~/b    @ ~o~@c@~ ~4@@ta~ t~ @@@v "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->isPlaying()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/f;->p:Landroid/widget/SeekBar;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->getDuration()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setMax(I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->s(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->t(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->B(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/f;->q(Lcom/luck/picture/lib/adapter/holder/f;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/f$a;->a:Lcom/luck/picture/lib/adapter/holder/f;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/luck/picture/lib/adapter/holder/f;->r(Lcom/luck/picture/lib/adapter/holder/f;Z)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method
