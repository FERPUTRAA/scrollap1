.class Lcom/luck/picture/lib/adapter/holder/i$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/adapter/holder/i;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/entity/LocalMedia;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/luck/picture/lib/adapter/holder/i;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/i;Lcom/luck/picture/lib/entity/LocalMedia;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->c:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  si4@1vi ~@S~n@u~l ~s ~    @@@ b@MK@@@~-t~~~ ~@@~@fto o@i~@~y~oomc~~o @lfb/@~~~ @@r~ob  @~. d~/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->c:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/i;->l:Lcom/google/android/exoplayer2/ui/StyledPlayerView;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/exoplayer2/ui/StyledPlayerView;->getPlayer()Lcom/google/android/exoplayer2/Player;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->c:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->c:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/i;->k:Landroid/widget/ImageView;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 v1, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->c:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/adapter/holder/b;->g:Lcom/luck/picture/lib/adapter/holder/b$e;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->a:Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->w()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lcom/luck/picture/lib/adapter/holder/b$e;->d(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/android/exoplayer2/MediaItem;->fromUri(Landroid/net/Uri;)Lcom/google/android/exoplayer2/MediaItem;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->f(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/android/exoplayer2/MediaItem;->fromUri(Ljava/lang/String;)Lcom/google/android/exoplayer2/MediaItem;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/i$a;->b:Ljava/lang/String;

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/android/exoplayer2/MediaItem;->fromUri(Landroid/net/Uri;)Lcom/google/android/exoplayer2/MediaItem;

    move-result-object v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lcom/google/android/exoplayer2/Player;->setMediaItem(Lcom/google/android/exoplayer2/MediaItem;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1}, Lcom/google/android/exoplayer2/Player;->prepare()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Lcom/google/android/exoplayer2/Player;->play()V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
