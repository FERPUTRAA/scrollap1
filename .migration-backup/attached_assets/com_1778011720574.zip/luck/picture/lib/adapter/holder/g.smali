.class public Lcom/luck/picture/lib/adapter/holder/g;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/adapter/holder/g$d;,
        Lcom/luck/picture/lib/adapter/holder/g$c;,
        Lcom/luck/picture/lib/adapter/holder/g$e;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Lcom/luck/picture/lib/adapter/holder/g$e;",
        ">;"
    }
.end annotation


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Z

.field private c:Lcom/luck/picture/lib/adapter/holder/g$c;

.field private d:Lcom/luck/picture/lib/adapter/holder/g$d;


# direct methods
.method public constructor <init>(ZLjava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/adapter/holder/g;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    move p2, p1

    move p2, p1

    const/4 v2, 0x6

    move p2, p1

    move p2, p1

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-ge p2, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->q0(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$c;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@st@~ @/@-@~~o~@s uto @lKf~~@~oS~ii~ ~l~~~vona/biy~d  ~ ~ ~  ~~~@o~ @@m  ~@rf@ b4 Mc o.@@@@b @1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/holder/g;->c:Lcom/luck/picture/lib/adapter/holder/g$c;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic b(Lcom/luck/picture/lib/adapter/holder/g;)Lcom/luck/picture/lib/adapter/holder/g$d;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/holder/g;->d:Lcom/luck/picture/lib/adapter/holder/g$d;

    const/4 v1, 0x2

    return-object p0
.end method

.method private d(Lcom/luck/picture/lib/entity/LocalMedia;)I
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v0, 0x0

    or-int/2addr v6, v0

    :goto_0
    const/4 v5, 0x1

    move v6, v5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-ge v0, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->x()J

    move-result-wide v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->x()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    cmp-long v1, v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x4

    move v6, v5

    return v0

    :cond_2
    const/4 v6, 0x0

    const/4 p1, -0x1

    const/4 v6, 0x6

    move v5, p1

    move v5, p1

    const/4 v6, 0x2

    return p1
.end method


# virtual methods
.method public c(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/adapter/holder/g;->e()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eq v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->b:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/g;->d(Lcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->q0(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    or-int/2addr v4, v3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    sub-int/2addr p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public e()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ge v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->H()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x2

    move v3, v2

    return v0
.end method

.method public f(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/adapter/holder/g;->e()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eq v0, v1, :cond_0

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/g;->d(Lcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eq p1, v1, :cond_1

    const/4 v4, 0x2

    or-int/2addr v5, v4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v5, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->V(Z)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    :cond_1
    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-void
.end method

.method public g(Lcom/luck/picture/lib/adapter/holder/g$e;I)V
    .locals 8
    .param p1    # Lcom/luck/picture/lib/adapter/holder/g$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    check-cast p2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->O()Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_half_white:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_transparent:I

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/r;->g(Landroid/content/Context;I)Landroid/graphics/ColorFilter;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->H()Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 v2, 0x8

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->O()Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v1, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->d:Landroid/view/View;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    goto :goto_2

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->d:Landroid/view/View;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->H()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v4, v3

    move v4, v3

    const/4 v7, 0x0

    move v4, v3

    move v4, v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    move v4, v2

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->M()Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    if-eqz v4, :cond_3

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v4, :cond_3

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v4, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->c:Landroid/widget/ImageView;

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v7, 0x0

    goto :goto_3

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v4, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->c:Landroid/widget/ImageView;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v4, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->a:Landroid/widget/ImageView;

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v7, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v0, :cond_4

    const/4 v7, 0x6

    iget-object v4, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v5, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->a:Landroid/widget/ImageView;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v0, v4, v1, v5}, Lq6/d;->e(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p1, Lcom/luck/picture/lib/adapter/holder/g$e;->b:Landroid/widget/ImageView;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v1, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :cond_5
    const/4 v6, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v1, Lcom/luck/picture/lib/adapter/holder/g$a;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v1, p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/g$a;-><init>(Lcom/luck/picture/lib/adapter/holder/g;Lcom/luck/picture/lib/adapter/holder/g$e;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object p2, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v7, 0x4

    new-instance v0, Lcom/luck/picture/lib/adapter/holder/g$b;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/adapter/holder/g$b;-><init>(Lcom/luck/picture/lib/adapter/holder/g;Lcom/luck/picture/lib/adapter/holder/g$e;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p2, v0}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void
.end method

.method public getData()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getItemCount()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method

.method public h(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/holder/g$e;
    .locals 4
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v0, 0x9

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    sget p2, Lcom/luck/picture/lib/R$layout;->ps_preview_gallery_item:I

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p2, Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p2, p1}, Lcom/luck/picture/lib/adapter/holder/g$e;-><init>(Landroid/view/View;)V

    const/4 v3, 0x5

    return-object p2
.end method

.method public i(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/adapter/holder/g;->d(Lcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eq p1, v0, :cond_1

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->b:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->q0(Z)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/holder/g;->a:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemRemoved(I)V

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public j(Lcom/luck/picture/lib/adapter/holder/g$c;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g;->c:Lcom/luck/picture/lib/adapter/holder/g$c;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public k(Lcom/luck/picture/lib/adapter/holder/g$d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/g;->d:Lcom/luck/picture/lib/adapter/holder/g$d;

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView$g0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    check-cast p1, Lcom/luck/picture/lib/adapter/holder/g$e;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/g;->g(Lcom/luck/picture/lib/adapter/holder/g$e;I)V

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/g;->h(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/holder/g$e;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method
