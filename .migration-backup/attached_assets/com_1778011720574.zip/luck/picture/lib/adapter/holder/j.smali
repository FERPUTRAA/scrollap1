.class public Lcom/luck/picture/lib/adapter/holder/j;
.super Lcom/luck/picture/lib/adapter/holder/c;


# instance fields
.field private final l:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/c;-><init>(Landroid/view/View;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget p2, Lcom/luck/picture/lib/R$id;->tv_duration:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p1, Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/j;->l:Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x7

    sget-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->i()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v2, v2, v2}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->o()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    int-to-float v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_1
    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->n()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->h()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v1, :cond_3

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/style/SelectMainStyle;->k()[I

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p2}, Lcom/luck/picture/lib/utils/r;->a([I)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    instance-of v0, v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    check-cast p1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/16 v0, 0xc

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p1, v0}, Landroid/widget/RelativeLayout$LayoutParams;->removeRule(I)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    array-length p1, p2

    :goto_0
    const/4 v3, 0x1

    const/4 v3, 0x1

    if-ge v2, p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    aget v0, p2, v2

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/holder/j;->l:Landroid/widget/TextView;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v4, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method public e(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s @~~r~@ ~s  @i~/d~ib@uftKf@ o@~~~~@o mo -o  @~ @o~ n@ @@@~4~b~@@yo~S.@Mtcv1~il @ bl@ ~~/ ~a@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/holder/j;->l:Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->v()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/d;->c(J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
