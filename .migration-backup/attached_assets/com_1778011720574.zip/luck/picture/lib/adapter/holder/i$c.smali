.class Lcom/luck/picture/lib/adapter/holder/i$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/exoplayer2/Player$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/holder/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/adapter/holder/i;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/adapter/holder/i;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$c;->a:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s bc/n @.@ r~t~ @~~@~~@~t  @f@@o-@  boo@  o ~i lb~~  ~o@~~~@@@ ~M@K@1@@d~mS~sv~4 ~faoiuly@@i/~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ne p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$c;->a:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/i;->p(Lcom/luck/picture/lib/adapter/holder/i;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-ne p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$c;->a:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/luck/picture/lib/adapter/holder/i;->m:Landroid/widget/ProgressBar;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v0, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x6

    if-ne p1, v0, :cond_2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$c;->a:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/i;->o(Lcom/luck/picture/lib/adapter/holder/i;)V

    :cond_2
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public b(Lcom/google/android/exoplayer2/PlaybackException;)V
    .locals 2
    .param p1    # Lcom/google/android/exoplayer2/PlaybackException;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/holder/i$c;->a:Lcom/luck/picture/lib/adapter/holder/i;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/adapter/holder/i;->o(Lcom/luck/picture/lib/adapter/holder/i;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
