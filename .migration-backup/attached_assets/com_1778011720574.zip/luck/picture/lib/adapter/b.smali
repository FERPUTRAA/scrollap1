.class public Lcom/luck/picture/lib/adapter/b;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/adapter/b$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Lcom/luck/picture/lib/adapter/holder/c;",
        ">;"
    }
.end annotation


# static fields
.field public static final f:I = 0x1

.field public static final g:I = 0x2

.field public static final h:I = 0x3

.field public static final i:I = 0x4


# instance fields
.field private a:Z

.field private b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final d:Landroid/content/Context;

.field private e:Lcom/luck/picture/lib/adapter/b$b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/adapter/b;->c:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/b;->d:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/adapter/b;)Lcom/luck/picture/lib/adapter/b$b;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@fsc@@~ Kb@ @~  ~@@o lu@/t r~v~1~~i@m~ ~~~@  M4@b~-o~ ~s@ y@o ~@~~d i~/ia ~ @~o.o@nto b~l@ @f@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/adapter/b;->e:Lcom/luck/picture/lib/adapter/b$b;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method private c(I)I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    if-eq p1, v0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eq p1, v1, :cond_3

    const/4 v3, 0x3

    if-eq p1, v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/b;->d:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1, v1}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_item_grid_image:I

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/b;->d:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :cond_2
    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_item_grid_audio:I

    :goto_1
    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/adapter/b;->d:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_2

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_item_grid_video:I

    :goto_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return p1

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_item_grid_camera:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p1
.end method


# virtual methods
.method public b()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public e()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/b;->a:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public f(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public g(Lcom/luck/picture/lib/adapter/holder/c;I)V
    .locals 4
    .param p1    # Lcom/luck/picture/lib/adapter/holder/c;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Lcom/luck/picture/lib/adapter/b;->getItemViewType(I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p2, Lcom/luck/picture/lib/adapter/b$a;

    const/4 v3, 0x7

    invoke-direct {p2, p0}, Lcom/luck/picture/lib/adapter/b$a;-><init>(Lcom/luck/picture/lib/adapter/b;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/b;->a:Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 p2, p2, -0x1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    invoke-virtual {p1, v0, p2}, Lcom/luck/picture/lib/adapter/holder/c;->e(Lcom/luck/picture/lib/entity/LocalMedia;I)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/adapter/b;->e:Lcom/luck/picture/lib/adapter/b$b;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/adapter/holder/c;->l(Lcom/luck/picture/lib/adapter/b$b;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public getItemCount()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/b;->a:Z

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getItemViewType(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/adapter/b;->a:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int/lit8 p1, p1, -0x1

    :cond_1
    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x6

    return p1

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p1, :cond_3

    const/4 v2, 0x4

    const/4 p1, 0x4

    const/4 v2, 0x4

    move v1, p1

    move v1, p1

    const/4 v2, 0x4

    return p1

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p1, 0x2

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    return p1
.end method

.method public h(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/holder/c;
    .locals 4
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0, p2}, Lcom/luck/picture/lib/adapter/b;->c(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/b;->c:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1, p2, v0, v1}, Lcom/luck/picture/lib/adapter/holder/c;->g(Landroid/view/ViewGroup;IILcom/luck/picture/lib/config/PictureSelectionConfig;)Lcom/luck/picture/lib/adapter/holder/c;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p1
.end method

.method public i(Ljava/util/ArrayList;)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/b;->b:Ljava/util/ArrayList;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyDataSetChanged()V

    :cond_0
    const/4 v1, 0x2

    return-void
.end method

.method public j(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/adapter/b;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public k(Lcom/luck/picture/lib/adapter/b$b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/adapter/b;->e:Lcom/luck/picture/lib/adapter/b$b;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 2
    .param p1    # Landroidx/recyclerview/widget/RecyclerView$g0;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p1, Lcom/luck/picture/lib/adapter/holder/c;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/b;->g(Lcom/luck/picture/lib/adapter/holder/c;I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/adapter/b;->h(Landroid/view/ViewGroup;I)Lcom/luck/picture/lib/adapter/holder/c;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method
