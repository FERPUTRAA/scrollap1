.class Lcom/luck/picture/lib/adapter/a$b;
.super Landroidx/recyclerview/widget/RecyclerView$g0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/adapter/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field a:Landroid/widget/ImageView;

.field b:Landroid/widget/TextView;

.field c:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$g0;-><init>(Landroid/view/View;)V

    const/4 v3, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->first_image:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/a$b;->a:Landroid/widget/ImageView;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->tv_folder_name:I

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/a$b;->b:Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->tv_select_tag:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/adapter/a$b;->c:Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->a()Lcom/luck/picture/lib/style/AlbumWindowStyle;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle;->a()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle;->c()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/a$b;->c:Landroid/widget/TextView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle;->d()I

    move-result p1

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/adapter/a$b;->b:Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/AlbumWindowStyle;->e()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-lez p1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/adapter/a$b;->b:Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x7

    int-to-float p1, p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method
