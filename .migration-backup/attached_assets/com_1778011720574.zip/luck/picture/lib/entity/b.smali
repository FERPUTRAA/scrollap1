.class public Lcom/luck/picture/lib/entity/b;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:I

.field private d:J

.field private e:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~@~i1@d a@~r @@o~ @ /f s~~ib~@~@f M@obKitS~u ~@o~vl@~  ~m@@y@@nt~~olo ~b/ @ @   o-~4@@~c~ ~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/luck/picture/lib/entity/b;->d:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-wide v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/entity/b;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/entity/b;->e:Ljava/lang/String;

    const/4 v1, 0x3

    return-object v0
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/entity/b;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lcom/luck/picture/lib/entity/b;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public f(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/luck/picture/lib/entity/b;->d:J

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public g(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/entity/b;->c:I

    const/4 v1, 0x7

    return-void
.end method

.method public h(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/entity/b;->e:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public i(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/entity/b;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public j(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/entity/b;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v1, "TxtmefInaalvanMi=/our{di/Eembihs"

    const-string v1, "dts/bn{henudraaxveamlIiMo=fiEi/T"

    const/4 v5, 0x3

    const-string/jumbo v1, "no{Eovfi=naab/lxiMidrTmdahIoe/eu"

    const-string v1, "MediaExtraInfo{videoThumbnail=\'"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/luck/picture/lib/entity/b;->a:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v1, 0x27

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "hwdi b,="

    const-string/jumbo v2, "ih=mw,d "

    const/4 v5, 0x1

    const-string v2, " i,h=duw"

    const-string v2, ", width="

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v2, p0, Lcom/luck/picture/lib/entity/b;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v2, "ith=,ehpg"

    const-string v2, ", height="

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v2, p0, Lcom/luck/picture/lib/entity/b;->c:I

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v2, "o oaunrdqt,"

    const-string v2, "ain,o tdour"

    const/4 v5, 0x4

    const-string v2, "ans,r=doit "

    const-string v2, ", duration="

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/luck/picture/lib/entity/b;->d:J

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "ntom/r=iibt,aen "

    const-string/jumbo v2, "orn/ob=iietn,a t"

    const/4 v5, 0x2

    const-string/jumbo v2, "iornoent=a//oi ,"

    const-string v2, ", orientation=\'"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/entity/b;->e:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v1, 0x7d

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object v0
.end method
