.class public Lcom/luck/picture/lib/entity/LocalMediaFolder;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:J

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:Z

.field private g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field private h:I

.field private i:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Lcom/luck/picture/lib/entity/LocalMediaFolder$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder$a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    sput-object v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v4, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-wide v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v4, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    iput v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-wide v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d:Ljava/lang/String;

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    iput v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x7

    move v1, v2

    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-boolean v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->f:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    sget-object v1, Lcom/luck/picture/lib/entity/LocalMedia;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput v1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    move v0, v2

    move v0, v2

    const/4 v4, 0x3

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method public a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@fs~fo~~1 K o@o~@n~b @s li@@t  @~.~@  -  m~~~~~@ca@@/@o4  @@~v~/  o@  @b~~itS~ ~~od@b~l@@r@Mu~iy"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-wide v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public d()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public describeContents()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->c:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "wkomunn"

    const-string/jumbo v0, "unknown"

    const/4 v2, 0x4

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->b:Ljava/lang/String;

    :goto_0
    return-object v0
.end method

.method public i()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->e:I

    return v0
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method

.method public n()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    return v0
.end method

.method public o(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public q(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v1, 0x5

    return-void
.end method

.method public r(Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public s(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->c:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public u(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d:Ljava/lang/String;

    const/4 v1, 0x6

    return-void
.end method

.method public v(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public w(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a:J

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->c:Ljava/lang/String;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d:Ljava/lang/String;

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->e:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    iget-boolean p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->f:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->g:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i:Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    int-to-byte p2, p2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public x(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public y(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/entity/LocalMediaFolder;->f:Z

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
