.class public final Lcom/luck/picture/lib/animators/e;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s~y b@@~u@  ~@~@voa~Klt@@~r c/obtin~~ ~@~~~s@biSl@@~o ~@ im o4@  ~@ ~ ~f   1/M@@~@-.~o@~d ~o ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x2

    shr-int/2addr v2, v0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationY(F)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationX(F)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setRotation(F)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setRotationY(F)V

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setRotationX(F)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    div-int/lit8 v0, v0, 0x2

    const/4 v3, 0x4

    int-to-float v0, v0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->setPivotY(F)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    div-int/lit8 v0, v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    int-to-float v0, v0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setPivotX(F)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->g(Landroid/view/View;)Landroidx/core/view/s1;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-virtual {p0, v0}, Landroidx/core/view/s1;->t(Landroid/view/animation/Interpolator;)Landroidx/core/view/s1;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Landroidx/core/view/s1;->w(J)Landroidx/core/view/s1;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
