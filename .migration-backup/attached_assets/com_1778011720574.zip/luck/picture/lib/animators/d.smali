.class public Lcom/luck/picture/lib/animators/d;
.super Lcom/luck/picture/lib/animators/c;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$h;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/animators/c;-><init>(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected a(Landroid/view/View;)[Landroid/animation/Animator;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ s~@o t@  u ~bo~4@vK@@ @f@~ ~a ocM t~~id@@b~ o~m@~1o@  /~~@yb@sl/~~~on@i @~~ Sl  ~@~@-@i~~~.r@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array v1, v0, [Landroid/animation/Animator;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x0

    new-array v2, v2, [F

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    int-to-float v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    aput v3, v2, v4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    aput v3, v2, v0

    const/4 v6, 0x2

    const-string v0, "aYsmsolrttai"

    const-string v0, "iYsatoalsnrt"

    const/4 v6, 0x5

    const-string/jumbo v0, "tsntoaYrioan"

    const-string/jumbo v0, "translationY"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1, v0, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    aput-object p1, v1, v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    return-object v1
.end method
