.class public Lcom/luck/picture/lib/animators/a;
.super Lcom/luck/picture/lib/animators/c;


# static fields
.field private static final g:F


# instance fields
.field private final f:F


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$h;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/animators/a;-><init>(Landroidx/recyclerview/widget/RecyclerView$h;F)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$h;F)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/animators/c;-><init>(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lcom/luck/picture/lib/animators/a;->f:F

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected a(Landroid/view/View;)[Landroid/animation/Animator;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @s~olnbtc~ ~@ s@fi@o@ - ~@o b @ ~/~~of@@ @.dy~i~~i@~r~~l1 ~bM~v@~@~ou ~~m @4a~  / o@K~S @ @@@@t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-array v1, v0, [Landroid/animation/Animator;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-array v2, v2, [F

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v3, p0, Lcom/luck/picture/lib/animators/a;->f:F

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    aput v3, v2, v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    aput v3, v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v0, "pasma"

    const-string/jumbo v0, "phsaa"

    const/4 v6, 0x4

    const-string/jumbo v0, "paaho"

    const-string v0, "alpha"

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p1, v0, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-object p1, v1, v4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v1
.end method
