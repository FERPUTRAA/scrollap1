.class public abstract Lcom/luck/picture/lib/animators/c;
.super Landroidx/recyclerview/widget/RecyclerView$h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$h<",
        "Landroidx/recyclerview/widget/RecyclerView$g0;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Landroidx/recyclerview/widget/RecyclerView$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/recyclerview/widget/RecyclerView$h<",
            "Landroidx/recyclerview/widget/RecyclerView$g0;",
            ">;"
        }
    .end annotation
.end field

.field private b:I

.field private c:Landroid/view/animation/Interpolator;

.field private d:I

.field private e:Z


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView$h;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/recyclerview/widget/RecyclerView$h<",
            "Landroidx/recyclerview/widget/RecyclerView$g0;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$h;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/16 v0, 0xfa

    const/4 v2, 0x2

    const/4 v1, 0x7

    iput v0, p0, Lcom/luck/picture/lib/animators/c;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Landroid/view/animation/LinearInterpolator;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/animators/c;->c:Landroid/view/animation/Interpolator;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput v0, p0, Lcom/luck/picture/lib/animators/c;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/animators/c;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method protected abstract a(Landroid/view/View;)[Landroid/animation/Animator;
.end method

.method public b()Landroidx/recyclerview/widget/RecyclerView$h;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/recyclerview/widget/RecyclerView$h<",
            "Landroidx/recyclerview/widget/RecyclerView$g0;",
            ">;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public c(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/animators/c;->e:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public d(Landroid/view/animation/Interpolator;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/animators/c;->c:Landroid/view/animation/Interpolator;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public e(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/animators/c;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public getItemCount()I
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemCount()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemId(I)J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getItemViewType(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemViewType(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1
.end method

.method public onAttachedToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onAttachedToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onAttachedToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$h;->onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$g0;I)V

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$g0;->getAdapterPosition()I

    move-result p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/animators/c;->e:Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v0, p0, Lcom/luck/picture/lib/animators/c;->d:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-le p2, v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/animators/e;->a(Landroid/view/View;)V

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p1, Landroidx/recyclerview/widget/RecyclerView$g0;->itemView:Landroid/view/View;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/animators/c;->a(Landroid/view/View;)[Landroid/animation/Animator;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    array-length v0, p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v1, 0x0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ge v1, v0, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    aget-object v2, p1, v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v3, p0, Lcom/luck/picture/lib/animators/c;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    int-to-long v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v3, v4}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v3}, Landroid/animation/Animator;->start()V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/luck/picture/lib/animators/c;->c:Landroid/view/animation/Interpolator;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput p2, p0, Lcom/luck/picture/lib/animators/c;->d:I

    :goto_2
    const/4 v6, 0x3

    return-void
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView$h;->onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$g0;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public onDetachedFromRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onDetachedFromRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onDetachedFromRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public onViewAttachedToWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewAttachedToWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewAttachedToWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v2, 0x7

    return-void
.end method

.method public onViewDetachedFromWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewDetachedFromWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewDetachedFromWindow(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public onViewRecycled(Landroidx/recyclerview/widget/RecyclerView$g0;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewRecycled(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->onViewRecycled(Landroidx/recyclerview/widget/RecyclerView$g0;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public registerAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->registerAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->registerAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public setDuration(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/animators/c;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public unregisterAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->unregisterAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/animators/c;->a:Landroidx/recyclerview/widget/RecyclerView$h;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->unregisterAdapterDataObserver(Landroidx/recyclerview/widget/RecyclerView$j;)V

    const/4 v2, 0x7

    return-void
.end method
