.class Lcom/luck/picture/lib/c$e;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/m;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->T()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/m<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/c$e;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~f u/y@@~ @~~@@c  t~~om4~~S~~fs@@n~ ~-r ~K   @vi1@.@ ~o~b @a@b@b o~@~@o~~@i@t i~Mo ldl@  ~@/ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/c$e;->b(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v1, 0x2

    return-void
.end method

.method public b(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$e;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/luck/picture/lib/c;->s1(Lcom/luck/picture/lib/c;Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
