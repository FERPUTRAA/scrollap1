.class Lcom/luck/picture/lib/c$k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->z(ZLcom/luck/picture/lib/entity/LocalMedia;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/c$k;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s u~@ofof @~o~ ~@@ib~@ @~ly.@ o~~@Mos~b@@~rn  ~~@@~ @ ~o@  t ~btim~a~/@~~@@/Kvcl4Sd~ i @  -~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/c$k;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/c;->W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyDataSetChanged()V

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method
