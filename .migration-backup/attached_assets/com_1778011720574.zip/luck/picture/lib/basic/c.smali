.class public interface abstract Lcom/luck/picture/lib/basic/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract B(Ljava/util/ArrayList;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation
.end method

.method public abstract C()V
.end method

.method public abstract D(Lcom/luck/picture/lib/entity/LocalMedia;)V
.end method

.method public abstract E(Lcom/luck/picture/lib/entity/LocalMedia;)V
.end method

.method public abstract G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I
.end method

.method public abstract H()V
.end method

.method public abstract I()V
.end method

.method public abstract J()V
.end method

.method public abstract K()V
.end method

.method public abstract M(ZLjava/lang/String;IJJ)Z
.end method

.method public abstract N()V
.end method

.method public abstract P(Lcom/luck/picture/lib/entity/LocalMedia;)V
.end method

.method public abstract Q(ZLcom/luck/picture/lib/entity/LocalMedia;)V
.end method

.method public abstract R(Z[Ljava/lang/String;)V
.end method

.method public abstract S()V
.end method

.method public abstract U()V
.end method

.method public abstract a()V
.end method

.method public abstract c([Ljava/lang/String;)V
.end method

.method public abstract e(Z)V
.end method

.method public abstract f()I
.end method

.method public abstract g()V
.end method

.method public abstract h()V
.end method

.method public abstract k(ZLjava/lang/String;Ljava/lang/String;JJ)Z
.end method

.method public abstract l(Landroid/content/Intent;)V
.end method

.method public abstract n(Landroid/os/Bundle;)V
.end method

.method public abstract o()V
.end method

.method public abstract q([Ljava/lang/String;)V
.end method

.method public abstract r(I)V
.end method

.method public abstract t()V
.end method

.method public abstract v()V
.end method

.method public abstract x(I[Ljava/lang/String;)V
.end method

.method public abstract y()V
.end method

.method public abstract z(ZLcom/luck/picture/lib/entity/LocalMedia;)V
.end method
