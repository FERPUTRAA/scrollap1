.class public interface abstract Lcom/luck/picture/lib/basic/d;
.super Ljava/lang/Object;


# virtual methods
.method public abstract O(J)V
.end method

.method public abstract T()V
.end method

.method public abstract i()V
.end method

.method public abstract u()V
.end method
