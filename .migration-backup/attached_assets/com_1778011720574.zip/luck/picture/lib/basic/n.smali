.class public final Lcom/luck/picture/lib/basic/n;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/fragment/app/Fragment;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/basic/n;-><init>(Landroid/app/Activity;Landroidx/fragment/app/Fragment;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>(Landroid/app/Activity;Landroidx/fragment/app/Fragment;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/basic/n;->a:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/basic/n;->b:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>(Landroidx/fragment/app/Fragment;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Lcom/luck/picture/lib/basic/n;-><init>(Landroid/app/Activity;Landroidx/fragment/app/Fragment;)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public static a(Landroid/app/Activity;)Lcom/luck/picture/lib/basic/n;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b4s@S@~u~i   oo~@t/o ~bf~v~~@r@~f@b~~@~o~ /1~@@~~.@l@l~Mo o~ta~ c@@~i ~  s~in@  ~ @d  -@y @@ m@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/basic/n;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/basic/n;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x7

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Lcom/luck/picture/lib/basic/n;
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    new-instance v0, Lcom/luck/picture/lib/basic/n;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p0, Landroid/app/Activity;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/basic/n;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public static c(Landroidx/fragment/app/Fragment;)Lcom/luck/picture/lib/basic/n;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Lcom/luck/picture/lib/basic/n;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/basic/n;-><init>(Landroidx/fragment/app/Fragment;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public static g(Landroid/content/Intent;)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            ")",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "asxmu_ralimeerdtes"

    const-string v0, "d_s_amaslterrxeeui"

    const/4 v2, 0x4

    const-string v0, "erdloa_xet_reautms"

    const-string v0, "extra_result_media"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static l(Ljava/util/ArrayList;)Landroid/content/Intent;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)",
            "Landroid/content/Intent;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "umxdibte_rtsreaml_"

    const-string v1, "i_rmrdeseul_attmax"

    const/4 v3, 0x2

    const-string v1, "emextsuutrd_laaier"

    const-string v1, "extra_result_media"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putParcelableArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    return-object p0
.end method


# virtual methods
.method public d(I)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/basic/l;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/basic/l;-><init>(Lcom/luck/picture/lib/basic/n;I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method e()Landroid/app/Activity;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/n;->a:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast v0, Landroid/app/Activity;

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-object v0
.end method

.method f()Landroidx/fragment/app/Fragment;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/n;->b:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, Landroidx/fragment/app/Fragment;

    const/4 v1, 0x3

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public h(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/basic/i;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/basic/i;-><init>(Lcom/luck/picture/lib/basic/n;I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public i(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/basic/j;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/basic/j;-><init>(Lcom/luck/picture/lib/basic/n;I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public j()Lcom/luck/picture/lib/basic/k;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    new-instance v0, Lcom/luck/picture/lib/basic/k;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/basic/k;-><init>(Lcom/luck/picture/lib/basic/n;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public k(I)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/luck/picture/lib/basic/m;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/basic/m;-><init>(Lcom/luck/picture/lib/basic/n;I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method
