.class Lcom/luck/picture/lib/basic/l$b$a;
.super Ls6/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/l$b;->a(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ls6/o<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/l$b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/l$b;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/basic/l$b$a;->a:Lcom/luck/picture/lib/basic/l$b;

    const/4 v1, 0x6

    invoke-direct {p0}, Ls6/o;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Ljava/util/ArrayList;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ sy~ /b/c~~o~o~il~ o  iouof@~@@~l@t m~~~~@@ ~@~@ d  ~~M bo@s  ~rvtS-.K@4 f1@a@@@n@@~~  @~@~@~b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/luck/picture/lib/basic/l$b$a;->a:Lcom/luck/picture/lib/basic/l$b;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p2, p2, Lcom/luck/picture/lib/basic/l$b;->b:Ls6/p;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-interface {p2, p1}, Ls6/p;->a(Ljava/util/List;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
