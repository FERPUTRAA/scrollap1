.class public final Lcom/luck/picture/lib/basic/k;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final b:Lcom/luck/picture/lib/basic/n;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/basic/n;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/basic/k;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    move v2, v1

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a(Z)Lcom/luck/picture/lib/basic/k;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ios@@@@ dn  ~i@l-y~f~~~~Ko@ @io r@b~@u~tvtbo~/ @  M~@o  . @~lcs1b/~ @~~m@fo@~~@~@~ ~   ~a @~~4S@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public b(Z)Lcom/luck/picture/lib/basic/k;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public c(Ls6/e;)Lcom/luck/picture/lib/basic/k;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g1:Ls6/e;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public d(Lq6/d;)Lcom/luck/picture/lib/basic/k;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public e(I)Lcom/luck/picture/lib/basic/k;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public f(Lcom/luck/picture/lib/style/a;)Lcom/luck/picture/lib/basic/k;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public g(IZLjava/util/ArrayList;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/k;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x7

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x7

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo p2, "nn,mii EIm eusgaeeamnmimilg en sgtlleeignnepePlE"

    const-string/jumbo p2, "imageEngine is null,Please implement ImageEngine"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p3, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x5

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x4

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p3}, Lcom/luck/picture/lib/manager/b;->e(Ljava/util/ArrayList;)V

    const/4 v3, 0x2

    move v4, v3

    const-string/jumbo p3, "ii_iotepelecklsrrc.b...etrulwevapumco"

    const-string p3, "_as.rkprieulmcenuorllv.tceiceibw.pte."

    const-string/jumbo p3, "xlewtb.leiciea.ct_nippomvlbcrkreure.u"

    const-string p3, "com.luck.picture.lib.external_preview"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo p3, "miwmp_..ckitutrl_einbereoouuccriptnpocvr.li.s"

    const/4 v4, 0x6

    const-string/jumbo p3, "ulci_rucpoct.lunrewiniireopucse.ktre.b.vi_top"

    const-string p3, "com.luck.picture.lib.current_preview_position"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo p1, "peasaecpr.oetrd..lbt_ylcvoiiplululeeiewn_r_ie.mkxdce"

    const-string p1, "ap.yolet_l_ce.icdxrnkleuteilode.epvrbs.iwai_leumertc"

    const/4 v4, 0x2

    const-string/jumbo p1, "kevciauuq.t.tlrienme.icpserp._oire_pladwelcbely_dlxe"

    const-string p1, "com.luck.picture.lib.external_preview_display_delete"

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/k;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/n;->f()Landroidx/fragment/app/Fragment;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget p1, p1, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget p2, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_2

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string p2, " p arb vulstnielaedw"

    const-string/jumbo p2, "l swiest davnu lperi"

    const-string/jumbo p2, "preview data is null"

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const-string/jumbo p2, "ntcmoAvbinnlittyucl u  "

    const-string p2, " nilbeuc ivuoActnynl tt"

    const/4 v4, 0x0

    const-string/jumbo p2, "ttluotnio eilvn abnyccA"

    const-string p2, "Activity cannot be null"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p1

    :cond_5
    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public h(IZLjava/util/ArrayList;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    if-nez v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/k;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/basic/k;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne v1, v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    or-int/2addr v5, v4

    const-string/jumbo p2, "limpPbeseeE ialmne nIi egnelgnemps umEatnialeg,i"

    const-string/jumbo p2, "slgteplpn,ePEaimuignlamnlnngese iee mE eiIeam ig"

    const/4 v5, 0x0

    const-string/jumbo p2, "nmep,eungeEiienmeee I nulnigsElaPg nliltm eaagmi"

    const-string/jumbo p2, "imageEngine is null,Please implement ImageEngine"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    throw p1

    :cond_1
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz p3, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    instance-of v1, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    check-cast v1, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    instance-of v1, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_3

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast v1, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object v2, Lcom/luck/picture/lib/d;->P:Ljava/lang/String;

    const/4 v5, 0x7

    invoke-static {v0, v2}, Lcom/luck/picture/lib/utils/a;->b(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/d;->R1()Lcom/luck/picture/lib/d;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v3, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v3, p3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result p3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, p1, p3, v3, p2}, Lcom/luck/picture/lib/d;->Y1(IILjava/util/ArrayList;Z)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v2, v0}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_2

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string p2, "e uoamnpnaneMrqal ennrgFbgttcl"

    const-string p2, " FMmetebq eugrangol nanatrlcnn"

    const/4 v5, 0x2

    const-string p2, "glrmFteaqlcanangtboaenrenM u  "

    const-string p2, "FragmentManager cannot be null"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw p1

    :cond_5
    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo p2, "v spta ilsin drswlae"

    const-string/jumbo p2, "vdslw ua tnesrl aipi"

    const/4 v5, 0x2

    const-string/jumbo p2, "preview data is null"

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p1

    :cond_6
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo p2, "yvtmic cAlauen binnmlto"

    const-string p2, "Avamnn iccbittneyoul tl"

    const/4 v5, 0x0

    const-string/jumbo p2, "nvloo yt i iuclcntAneab"

    const-string p2, "Activity cannot be null"

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    throw p1

    :cond_7
    :goto_2
    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method
