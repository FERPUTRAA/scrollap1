.class public final Lcom/luck/picture/lib/basic/f;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;
    .locals 2

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @st@@~v@n bo@~l~1-~~ b~~~iu@.~@@~4 y~b~f@ fo@m@l  / di@@  o@t@MSo~~@s@a   co~K~/@~@@~r~~ ~o  i "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public static b(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/OutputStream;
    .locals 2

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x1

    move v0, p0

    const/4 v1, 0x3

    return-object p0
.end method
