.class Lcom/luck/picture/lib/basic/e$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->R0(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$d;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ts ~cK~~1b~t~~@~i/@  n@ ~.@o @b~@or~S o~vf   @ M~u@b~s~@f/@~@@lyia@4~@- ~i@m ~@~@o @d~~ ~@oo   "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    const/4 p1, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-ne p2, p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p2, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-ne p1, p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$d;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p2

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x1

    return p1
.end method
