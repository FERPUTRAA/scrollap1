.class public Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;
.super Landroidx/appcompat/app/AppCompatActivity;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    const/4 v1, 0x4

    return-void
.end method

.method private t()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~vsl~~   @4~~ b~mo@~~~~~ nl o~~  @~@1fua@@~ S@f@/yo/b@~s@@@ii~@~ bc o@@@-~o.i tt@@ @ ~~ rK~oM@d "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->b0()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->G()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->f0()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p0, v1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0, v1, v2, v0}, Lr6/a;->a(Landroidx/appcompat/app/AppCompatActivity;IIZ)V

    const/4 v4, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method private u()V
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "RtlHardcoded"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v1, 0x33

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    and-int/2addr v3, v2

    const/4 v4, 0x7

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method private v()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const-string v1, "c_su.rumtoeuocmec.liikdee.tppcyl_.bor"

    const/4 v6, 0x1

    const-string v1, "com.luck.picture.lib.mode_type_source"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget-object v0, Lcom/luck/picture/lib/e;->p:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lcom/luck/picture/lib/e;->l1()Lcom/luck/picture/lib/e;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    sget-object v0, Lcom/luck/picture/lib/b;->l:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {}, Lcom/luck/picture/lib/b;->W0()Lcom/luck/picture/lib/b;

    move-result-object v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v0}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v4, v3}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3}, Landroidx/fragment/app/a0;->r()I

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v2, v0, v1}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void
.end method


# virtual methods
.method public finish()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_out:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1}, Landroidx/fragment/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;->t()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_empty:I

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->setContentView(I)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;->u()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;->v()V

    const/4 v1, 0x3

    return-void
.end method
