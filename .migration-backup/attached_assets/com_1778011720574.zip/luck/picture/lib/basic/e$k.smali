.class Lcom/luck/picture/lib/basic/e$k;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->x0(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic o:Landroid/content/Intent;

.field final synthetic p:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;Landroid/content/Intent;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/basic/e$k;->o:Landroid/content/Intent;

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~yb/  @ @~ o~~  ~i s@KM@@@lodi~@-@o~b@t.@~~o @bni~~~f @om ~@ t@@4 @~ @ auo/@ @S v~r~~~@~l~f1 "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e$k;->r()Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e$k;->s(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public r()Lcom/luck/picture/lib/entity/LocalMedia;
    .locals 4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e$k;->o:Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/basic/e;->C0(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, v1, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v0, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/basic/e;->c0(Lcom/luck/picture/lib/basic/e;)V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, v0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/basic/e;->f0(Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public s(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v1, 0x3

    move v2, v1

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/basic/e;->d0(Lcom/luck/picture/lib/basic/e;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$k;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/basic/e;->D(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
