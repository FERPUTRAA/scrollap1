.class Lcom/luck/picture/lib/basic/e$e;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->v()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$e;->a:Lcom/luck/picture/lib/basic/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v@s@i~ ~o@bo o@  4Mc@~s~of~@@-~y@~@~~@@~~S  ~nbi~~~f/1b@ @@K~l~md l~t oi@~~    o@@@@/r t  a~ .u@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x5

    if-eqz p2, :cond_2

    const/4 v1, 0x0

    const/4 v0, 0x3

    if-eq p2, p1, :cond_0

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    const/4 v1, 0x3

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d1:Ls6/d;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$e;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p2, 0x2

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/basic/e;->r(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    goto :goto_0

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$e;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->t()V

    const/4 v1, 0x6

    goto :goto_0

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x4

    sget-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d1:Ls6/d;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p2, :cond_3

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/luck/picture/lib/basic/e$e;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/basic/e;->r(I)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    goto :goto_0

    :cond_3
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$e;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->N()V

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method
