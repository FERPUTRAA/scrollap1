.class Lcom/luck/picture/lib/basic/e$i;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/u;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->x(I[Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$i;->b:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p2, p0, Lcom/luck/picture/lib/basic/e$i;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a([Ljava/lang/String;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s@ ud~~@b~b o@~@   ./vn ~@ @b~K oo~@l~~  @ ~ ~@i-m@ i~~@~M4@/ t1@~lS~s~aoc@~@~~f @@fy~tri o@@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    if-eqz p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x5

    iget p1, p0, Lcom/luck/picture/lib/basic/e$i;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    sget p2, Lcom/luck/picture/lib/config/d;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-ne p1, p2, :cond_0

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$i;->b:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->V0()V

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$i;->b:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->U0()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/basic/e$i;->b:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
