.class Lcom/luck/picture/lib/basic/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->z0()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Ljava/util/ArrayList<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$a;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sS@~t @o ~@~cdi@l~oy~@~  ~ . ~ob@~r@@~vf@/ ~@@K~ t@ @@~~o4 ~i~~ s~ -u@ @/fla~@~@~ io mbb@@ oM1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    check-cast p1, Ljava/util/ArrayList;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e$a;->b(Ljava/util/ArrayList;)V

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public b(Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$a;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/basic/e;->B(Ljava/util/ArrayList;)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method
