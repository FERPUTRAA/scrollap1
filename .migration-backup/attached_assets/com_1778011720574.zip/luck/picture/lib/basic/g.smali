.class public Lcom/luck/picture/lib/basic/g;
.super Landroid/content/ContextWrapper;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Landroid/content/ContextWrapper;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;I)Landroid/content/ContextWrapper;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ksl~~ ~ ~@i@f So1 @t~o~/ u@ ~@~@.fc~~~ 4@ob/@- @@@ ~oMbt~ i@~ob a @s @@i@~@~~ ~~l@n ~v o~y@m dr"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, -0x2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lt6/c;->d(Landroid/content/Context;I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Lcom/luck/picture/lib/basic/g;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p1, p0}, Lcom/luck/picture/lib/basic/g;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1
.end method


# virtual methods
.method public getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "oiamd"

    const-string/jumbo v0, "idsoa"

    const/4 v2, 0x3

    const-string/jumbo v0, "oduao"

    const-string v0, "audio"

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1
.end method
