.class Lcom/luck/picture/lib/basic/l$b;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/l;->j(Ls6/p;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/n<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/loader/a;

.field final synthetic b:Ls6/p;

.field final synthetic c:Lcom/luck/picture/lib/basic/l;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/l;Lcom/luck/picture/lib/loader/a;Ls6/p;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/basic/l$b;->c:Lcom/luck/picture/lib/basic/l;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/basic/l$b;->a:Lcom/luck/picture/lib/loader/a;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/luck/picture/lib/basic/l$b;->b:Ls6/p;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "i~s@~@@  o/ ~ @oy ~~o~~i  ~~~bf~ @~o@-/lt@~n~ a @  odt@uc~@~o@K @~@b@b s@~M@.v4 ~@1 ~fm~@ ril@@S"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-lez v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x1

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l$b;->c:Lcom/luck/picture/lib/basic/l;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/basic/l;->a(Lcom/luck/picture/lib/basic/l;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l$b;->a:Lcom/luck/picture/lib/loader/a;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/l$b;->c:Lcom/luck/picture/lib/basic/l;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/basic/l;->a(Lcom/luck/picture/lib/basic/l;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v3, Lcom/luck/picture/lib/basic/l$b$a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v3, p0}, Lcom/luck/picture/lib/basic/l$b$a;-><init>(Lcom/luck/picture/lib/basic/l$b;)V

    invoke-virtual {v0, v1, v2, p1, v3}, Lcom/luck/picture/lib/loader/a;->i(JILs6/o;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l$b;->b:Ls6/p;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v0, p1}, Ls6/p;->a(Ljava/util/List;)V

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-void
.end method
