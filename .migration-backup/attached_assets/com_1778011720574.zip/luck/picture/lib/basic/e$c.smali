.class Lcom/luck/picture/lib/basic/e$c;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/c<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$c;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f~s  ~ @~ n~@~ ~t@~ ~@b4 t~  l ~@s@y~o@v.-~c~S~@~~f~libr@/ i@d@@  b@oo~ ~a@@o ~@@imoMuo@@@1 ~K~/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e$c;->b(Ljava/lang/Boolean;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public b(Ljava/lang/Boolean;)V
    .locals 3

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e$c;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lu6/b;->a:[Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/basic/e;->c([Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object p1, Lu6/b;->a:[Ljava/lang/String;

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
