.class public Lcom/luck/picture/lib/basic/l;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final b:Lcom/luck/picture/lib/basic/n;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/basic/n;I)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/basic/l;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/basic/l;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s~t ~do@ra~ ~vS@o~~s@b@/ fmo@@~@@/~y-~~~M@ ~@ l.@t @~@u i~o1ci @i4@@ ~Kb @f  n  @~o@~~~ol@~ ~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public b()Lcom/luck/picture/lib/loader/a;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    new-instance v1, Lcom/luck/picture/lib/loader/d;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/d;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Lcom/luck/picture/lib/loader/b;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v1

    :cond_1
    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "anAmttscnlvun l teoycbi"

    const-string v1, "e scnvntutabcli loitAyn"

    const/4 v4, 0x7

    const-string v1, " Aauoloynvctl nicetni b"

    const-string v1, "Activity cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw v0
.end method

.method public c(Z)Lcom/luck/picture/lib/basic/l;
    .locals 3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public d(Z)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public e(Z)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v1, 0x6

    move v2, v1

    return-object p0
.end method

.method public f(ZI)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/16 p1, 0xa

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-ge p2, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/16 p2, 0x3c

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public g(ZIZ)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/16 p1, 0xa

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ge p2, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/16 p2, 0x3c

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    iput p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean p3, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public h(Z)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E:Z

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public i(Ls6/p;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/p<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    or-int/2addr v4, v3

    iget-object v1, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Lcom/luck/picture/lib/loader/d;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/d;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Lcom/luck/picture/lib/loader/b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Lcom/luck/picture/lib/basic/l$a;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/basic/l$a;-><init>(Lcom/luck/picture/lib/basic/l;Ls6/p;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/loader/a;->h(Ls6/n;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v0, "uSnntbr  smaoalbe iyOrunDncleoLracneeute"

    const-string v0, "aulmnnnorulDteet O Loaanseeiy urcrSbectn"

    const/4 v4, 0x1

    const-string v0, "aynsnbu lcr aneet oDotutueiuaLeOlcnQeSrr"

    const-string v0, "OnQueryDataSourceListener cannot be null"

    const/4 v3, 0x6

    and-int/2addr v4, v3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw p1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "cA icvbp ttnounleyltoni"

    const-string/jumbo v0, "vculotn  ieyttlnnboaAci"

    const/4 v4, 0x2

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw p1
.end method

.method public j(Ls6/p;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/p<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v1, Lcom/luck/picture/lib/loader/d;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/d;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Lcom/luck/picture/lib/loader/b;

    const/4 v4, 0x5

    const/4 v3, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1, v0, v2}, Lcom/luck/picture/lib/loader/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v0, Lcom/luck/picture/lib/basic/l$b;

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p0, v1, p1}, Lcom/luck/picture/lib/basic/l$b;-><init>(Lcom/luck/picture/lib/basic/l;Lcom/luck/picture/lib/loader/a;Ls6/p;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/loader/a;->h(Ls6/n;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v0, "aeuilbun SctreeryunQateobe cna slnLnoDOr"

    const/4 v4, 0x7

    const-string v0, "OnQueryDataSourceListener cannot be null"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    throw p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v0, "nonbuAytqtvlnia c ci et"

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    throw p1
.end method

.method public k(J)Lcom/luck/picture/lib/basic/l;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    cmp-long v0, p1, v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    mul-long/2addr p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p0
.end method

.method public l(J)Lcom/luck/picture/lib/basic/l;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x5

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    cmp-long v0, p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x0

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    mul-long/2addr p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p0
.end method

.method public m(I)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public n(I)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public o(Ljava/lang/String;)Lcom/luck/picture/lib/basic/l;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method
