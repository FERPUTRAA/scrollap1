.class Lcom/luck/picture/lib/basic/l$a;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/l;->i(Ls6/p;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/n<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Ls6/p;

.field final synthetic b:Lcom/luck/picture/lib/basic/l;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/l;Ls6/p;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/basic/l$a;->b:Lcom/luck/picture/lib/basic/l;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/basic/l$a;->a:Ls6/p;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/basic/l$a;->a:Ls6/p;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ls6/p;->a(Ljava/util/List;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
