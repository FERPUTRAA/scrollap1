.class public Lcom/luck/picture/lib/basic/h;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/MediaScannerConnection$MediaScannerConnectionClient;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/basic/h$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/media/MediaScannerConnection;

.field private final b:Ljava/lang/String;

.field private c:Lcom/luck/picture/lib/basic/h$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/basic/h;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    new-instance p2, Landroid/media/MediaScannerConnection;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p2, p1, p0}, Landroid/media/MediaScannerConnection;-><init>(Landroid/content/Context;Landroid/media/MediaScannerConnection$MediaScannerConnectionClient;)V

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/basic/h;->a:Landroid/media/MediaScannerConnection;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2}, Landroid/media/MediaScannerConnection;->connect()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Lcom/luck/picture/lib/basic/h$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/luck/picture/lib/basic/h;->c:Lcom/luck/picture/lib/basic/h$a;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/basic/h;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    new-instance p2, Landroid/media/MediaScannerConnection;

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p2, p1, p0}, Landroid/media/MediaScannerConnection;-><init>(Landroid/content/Context;Landroid/media/MediaScannerConnection$MediaScannerConnectionClient;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/luck/picture/lib/basic/h;->a:Landroid/media/MediaScannerConnection;

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p2}, Landroid/media/MediaScannerConnection;->connect()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onMediaScannerConnected()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " bs@i~@/f~@  t ~1 @u~~~M o@~o@oao@iv~@l /cr@@l  d@ -@~@ ~~Sb~~~4~ m@~sni@y @ ~o~~K.@o~b~  @t f@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/h;->b:Ljava/lang/String;

    const/4 v4, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/h;->a:Landroid/media/MediaScannerConnection;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/basic/h;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaScannerConnection;->scanFile(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public onScanCompleted(Ljava/lang/String;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/basic/h;->a:Landroid/media/MediaScannerConnection;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/media/MediaScannerConnection;->disconnect()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/basic/h;->c:Lcom/luck/picture/lib/basic/h$a;

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-interface {p1}, Lcom/luck/picture/lib/basic/h$a;->a()V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method
