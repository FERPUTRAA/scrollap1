.class public final Lcom/luck/picture/lib/basic/j;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final b:Lcom/luck/picture/lib/basic/n;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/basic/n;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v1, 0x1

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/j;->a0(I)Lcom/luck/picture/lib/basic/j;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public A(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " us @ @@i@@ @y ~~ ~m@i~ @@dto~  @ o~c ol~/@@f@l-~~4 io ~n~@S~ K~b1~ats~f@@v@b@~.r~o~M@/   b~~~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public A0(J)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    cmp-long v0, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    mul-long/2addr p1, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p0
.end method

.method public B(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H:Z

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public B0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public C(Z)Lcom/luck/picture/lib/basic/j;
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method

.method public C0(J)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    cmp-long v0, p1, v0

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x0

    mul-long/2addr p1, v1

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0
.end method

.method public D(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G0:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public D0(Ljava/util/List;)Lcom/luck/picture/lib/basic/j;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)",
            "Lcom/luck/picture/lib/basic/j;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x4

    if-ne v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->i()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->b(Ljava/util/ArrayList;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object p0
.end method

.method public E(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W0:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public E0(I)Lcom/luck/picture/lib/basic/j;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne p1, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p0
.end method

.method public F(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J0:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public F0(Lcom/luck/picture/lib/style/a;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public G(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public varargs G0([Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    array-length v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-lez v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public H(Z)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object p0
.end method

.method public H0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p:I

    const/4 v1, 0x1

    and-int/2addr v2, v1

    return-object p0
.end method

.method public I(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x2

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public J(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x6

    const/4 v1, 0x2

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public K(Ls6/d;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d1:Ls6/d;

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-object p0
.end method

.method public L(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method public M(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public N(Lq6/a;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public O(Lq6/b;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public P(Ls6/h;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h1:Ls6/h;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public Q(Lq6/c;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R0:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R0:Z

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public R(J)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    cmp-long v0, p1, v0

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-wide/16 v1, 0x400

    const/4 v4, 0x2

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v3, 0x0

    move v4, v3

    mul-long/2addr p1, v1

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p0
.end method

.method public S(J)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x5

    const/4 v3, 0x7

    cmp-long v0, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ltz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x7

    const/4 v3, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    mul-long/2addr p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p0
.end method

.method public T(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x4

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public U(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x4

    move v2, v1

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public V(Lq6/d;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public W(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->w:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public X(Ls6/f;)Lcom/luck/picture/lib/basic/j;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    or-int/2addr v3, v2

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->O0:Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j1:Ls6/f;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0
.end method

.method public Y(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public Z(I)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v2, 0x6

    move v4, v2

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    move p1, v2

    move p1, v2

    const/4 v4, 0x3

    move p1, v2

    move p1, v2

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v4, 0x2

    return-object p0
.end method

.method public a()Lcom/luck/picture/lib/c;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    instance-of v0, v0, Lcom/luck/picture/lib/basic/b;

    const/4 v4, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x0

    iput-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x6

    new-instance v0, Lcom/luck/picture/lib/c;

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/luck/picture/lib/c;-><init>()V

    const/4 v3, 0x7

    and-int/2addr v4, v3

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const-string/jumbo v2, "utrmnvPdesceogrmftibeinutrosoUemFet,e  ealm  bcpt eAtaiiytelg Sresllitcneye  inndrt rc  omnead"

    const-string/jumbo v2, "pes nivnFay mi mt leareau otlmU  rcnebeeditetrculfdctt nbognionmye ceseies,idr tStereroAe Ptlg"

    const/4 v4, 0x4

    const-string v2, "delooerircttanAPerdl mtonevtudm nyF pn f irybuentab  tneeSegFel tistgcoctl rem meo eieir,aecUs"

    const-string v2, "Use only build PictureSelectorFragment,Activity or Fragment interface needs to be implemented "

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v4, 0x0

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    and-int/2addr v4, v3

    throw v0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v1, "ta Anbcbemnvoiit ltnl y"

    const-string/jumbo v1, "itcmlcAn ynato lvnbeit "

    const/4 v4, 0x7

    const-string v1, "c euniuointAtal tcy nbv"

    const-string v1, "Activity cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    throw v0
.end method

.method public a0(I)Lcom/luck/picture/lib/basic/j;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/h;->d()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-ne v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 p1, 0x0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p0
.end method

.method public b(ILs6/v;)Lcom/luck/picture/lib/c;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)",
            "Lcom/luck/picture/lib/c;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p2, :cond_4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    move v4, v3

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    sput-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    instance-of p2, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    instance-of p2, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x0

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 p2, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz p2, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Lcom/luck/picture/lib/c;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0}, Lcom/luck/picture/lib/c;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/c;->B0()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, v1}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/c;->B0()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2, p1, v0, v1}, Landroidx/fragment/app/a0;->g(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/a0;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/c;->B0()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Landroidx/fragment/app/a0;->o(Ljava/lang/String;)Landroidx/fragment/app/a0;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroidx/fragment/app/a0;->r()I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v0

    :cond_3
    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string p2, "elaboe ocenannFtMargumta ngrln"

    const/4 v4, 0x5

    const-string/jumbo p2, "natFe lpagrlrana mnnegeuctnoMb"

    const-string p2, "FragmentManager cannot be null"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string p2, " bnO elrqttlualuLtesscnaneC aRobnicbelk"

    const-string p2, "esRatbC no nnkbteaescenctOL lllulbaniru"

    const/4 v4, 0x6

    const-string p2, "akseloulllebbsnaRntncltecCenri O  Laust"

    const-string p2, "OnResultCallbackListener cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw p1

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo p2, "tnlm v Altencuuiobcanyt"

    const-string p2, "etntltuAavinoc nu  cylb"

    const/4 v4, 0x6

    const-string/jumbo p2, "otltoln ncavuiAtcneyi b"

    const-string p2, "Activity cannot be null"

    const/4 v4, 0x6

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p1
.end method

.method public b0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public c(I)V
    .locals 5

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x0

    or-int/2addr v4, v2

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x6

    move v3, v2

    move v3, v2

    const/4 v4, 0x4

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne v1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v0, "Inmiibmslngsl  neEiEeuemggigmnlieeePtn,ppel aea "

    const-string/jumbo v0, "ltEssempiiE eunmennilimeigaPe ng elaImenglpn eg,"

    const/4 v4, 0x7

    const-string v0, "et,n gumlieeimien gmuenansaieglpE lei gPnsIelnmE"

    const-string/jumbo v0, "imageEngine is null,Please implement ImageEngine"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x6

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x7

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2}, Lcom/luck/picture/lib/basic/n;->f()Landroidx/fragment/app/Fragment;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2, v1, p1}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget p1, p1, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_2

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const-string/jumbo v0, "tveucn py nilAlcoibant "

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    move v4, v3

    throw p1

    :cond_4
    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public c0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public d(Landroidx/activity/result/h;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ne v1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v0, "emEngm gqneIseaPgnleilnlnamei  ,eEamiuse inilgte"

    const-string/jumbo v0, "imageEngine is null,Please implement ImageEngine"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x2

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v2, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, v1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget p1, p1, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v4, 0x6

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v4, 0x7

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v0, "utsn sanelnuotAilLyRqetcau tiherlbcvn"

    const-string v0, "cunnehL qlbRtitslncraleiutn Auovcaety"

    const/4 v4, 0x3

    const-string v0, "ActivityResultLauncher cannot be null"

    const/4 v4, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    throw p1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v0, "e vmitytalbitnucAn nso "

    const-string v0, "avst y lcnentubA ocntii"

    const-string v0, "alAnoecoiin ycutbv tl n"

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1

    :cond_4
    :goto_1
    const/4 v4, 0x3

    return-void
.end method

.method public d0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public e(Ls6/v;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x7

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget p1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x0

    move v4, v3

    const-string v0, "i gn bameen I ,unlmmPeiilaegeaeiseimtllEnpmnEngg"

    const-string/jumbo v0, "pimm tlnleeagm nela e,ig nPEmEinineIamigseleueng"

    const/4 v4, 0x0

    const-string/jumbo v0, "n,nenmugPtie EgenmiemnmeaigenpElll sgsaaeI iluei"

    const-string/jumbo v0, "imageEngine is null,Please implement ImageEngine"

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x4

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v3, 0x2

    move v4, v3

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget p1, p1, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v1}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v0, "rlllk spnc oeLRsatalunbbOentnaCecuneit "

    const-string v0, "OnResultCallbackListener cannot be null"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v0, "ba  nu lqoottcvienAclni"

    const-string/jumbo v0, "itAeo ln caiutbtn nvocl"

    const/4 v4, 0x2

    const-string v0, " bsuia ti toelclnAtnvcn"

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw p1

    :cond_4
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method public e0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K0:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public f(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F0:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public f0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public g(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->F:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public g0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public h(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i:Z

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public h0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public i(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public i0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public j(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H0:Z

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public j0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public k(Z)Lcom/luck/picture/lib/basic/j;
    .locals 6

    const/4 v4, 0x5

    move v5, v4

    const/4 v0, 0x0

    shr-int/2addr v5, v0

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x2

    const/4 v4, 0x5

    iput-boolean v0, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x6

    xor-int/2addr v4, v3

    const/4 v5, 0x4

    if-ne v2, v3, :cond_1

    const/4 v4, 0x3

    or-int/2addr v5, v4

    if-eqz p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    move v0, v3

    move v0, v3

    const/4 v5, 0x4

    move v0, v3

    move v0, v3

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-boolean v0, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object p0
.end method

.method public k0(Ls6/i;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x4

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n1:Ls6/i;

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-object p0
.end method

.method public l(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public l0(Ls6/j;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m1:Ls6/j;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public m(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    return-object p0
.end method

.method public m0(Ls6/k;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public n(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public n0(Ls6/l;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k1:Ls6/l;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public o(Z)Lcom/luck/picture/lib/basic/j;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public varargs o0([Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    array-length v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-lez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x7

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public p(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public p0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public q(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D0:Z

    const/4 v2, 0x1

    return-object p0
.end method

.method public q0(Ljava/lang/String;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method public r(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public r0(Ls6/q;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o1:Ls6/q;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public s(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public s0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->u:I

    const/4 v2, 0x7

    return-object p0
.end method

.method public t(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public t0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->v:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public u(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public u0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->E0:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public v(ZI)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 p1, 0xa

    if-ge p2, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/16 p2, 0x3c

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public v0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public w(ZIZ)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 p1, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-ge p2, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/16 p2, 0x3c

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p3, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v2, 0x6

    return-object p0
.end method

.method public w0(Lq6/f;)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public x(ZZ)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C0:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method public x0(Ls6/w;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l1:Ls6/w;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public y(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->I:Z

    const/4 v2, 0x2

    return-object p0
.end method

.method public y0(Ls6/x;)Lcom/luck/picture/lib/basic/j;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e1:Ls6/x;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method public z(Z)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public z0(I)Lcom/luck/picture/lib/basic/j;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/j;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    const/4 v2, 0x2

    return-object p0
.end method
