.class Lcom/luck/picture/lib/basic/e$f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/dialog/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->v()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$f;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(ZLandroid/content/DialogInterface;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@uso~~@@@@l~or@~1~ cm S~@@~o@ @~  .i 4-Koa~b~o  l~to@@~/ /f~ s@~M~byti~@ @~v~~@b~@@~i  ~ f n@d  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p2, p0, Lcom/luck/picture/lib/basic/e$f;->a:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p2, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/luck/picture/lib/basic/e;->S()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
