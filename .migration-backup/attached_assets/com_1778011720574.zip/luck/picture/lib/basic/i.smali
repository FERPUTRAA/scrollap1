.class public final Lcom/luck/picture/lib/basic/i;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final b:Lcom/luck/picture/lib/basic/n;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/basic/n;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U0:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v1, 0x7

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L:Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public A(Ls6/j;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "n4s ~ao@~/@~@o rb@o ~~@vs@~~o~f@ S/iM@b@.@ y~@~~~o ~lK @~ t d~b l@1~m@ ~-f@u~i@@ @~ c  ~ toi@~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m1:Ls6/j;

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-object p0
.end method

.method public B(Ls6/k;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method public C(Ls6/q;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->o1:Ls6/q;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public D(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->u:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public E(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->v:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public F(Lq6/f;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public G(Ls6/x;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e1:Ls6/x;

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-object p0
.end method

.method public H(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method public I(J)Lcom/luck/picture/lib/basic/i;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x4

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    cmp-long v0, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ltz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x4

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    mul-long/2addr p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object p0
.end method

.method public J(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public K(J)Lcom/luck/picture/lib/basic/i;
    .locals 5

    const/4 v4, 0x7

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x6

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    cmp-long v0, p1, v0

    const/4 v4, 0x4

    if-ltz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v4, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x4

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    mul-long/2addr p1, v1

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p0
.end method

.method public L(Ljava/util/List;)Lcom/luck/picture/lib/basic/i;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)",
            "Lcom/luck/picture/lib/basic/i;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v2, 0x1

    or-int/2addr v4, v2

    xor-int/2addr v3, v2

    const/4 v4, 0x7

    if-ne v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->i()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/manager/b;->b(Ljava/util/ArrayList;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0
.end method

.method public M(I)Lcom/luck/picture/lib/basic/i;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->p:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public a()Lcom/luck/picture/lib/b;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v3, 0x2

    instance-of v0, v0, Lcom/luck/picture/lib/basic/b;

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x3

    iput-boolean v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    sput-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lcom/luck/picture/lib/b;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/luck/picture/lib/b;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const-string/jumbo v2, "tnamceeisia,nFtustfdniob odiPOrFisytmlvmebCm rtm Aaagyt lnr une en Uraieer teogceyplemlrecnete  "

    const-string/jumbo v2, "oAs yds rUenuanla eennmcimselbcem cmro eyiPedaiielerF g tturnbtrtaittfCiay,e lFvnop ee Og tnrtme"

    const-string v2, "Ustro  beoOtbtrtegimin igpaesr Fv mnu eml,y treeendecineeoaeAta luP tldyeaa CntoiFrcdlmnnime ycr"

    const-string v2, "Use only build PictureOnlyCameraFragment,Activity or Fragment interface needs to be implemented "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v1, "b l nbcotlmtinivtAyeu c"

    const-string/jumbo v1, "ncAmnnovbiltticue  tl y"

    const/4 v4, 0x4

    const-string/jumbo v1, "tn v culanlAetinciyuob "

    const-string v1, "Activity cannot be null"

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw v0
.end method

.method public b(ILs6/v;)Lcom/luck/picture/lib/b;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)",
            "Lcom/luck/picture/lib/b;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p2, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x1

    and-int/2addr v3, v2

    const/4 v4, 0x0

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    sput-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x2

    const/4 v3, 0x2

    instance-of p2, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v3, 0x6

    and-int/2addr v4, v3

    if-eqz p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    instance-of p2, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v3, 0x7

    or-int/2addr v4, v3

    if-eqz p2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p2, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz p2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Lcom/luck/picture/lib/b;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/b;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/b;->B0()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p2, v1}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {v2, v1}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/b;->B0()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p2, p1, v0, v1}, Landroidx/fragment/app/a0;->g(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/a0;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/b;->B0()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroidx/fragment/app/a0;->o(Ljava/lang/String;)Landroidx/fragment/app/a0;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroidx/fragment/app/a0;->r()I

    const/4 v4, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_3
    const/4 v3, 0x7

    move v4, v3

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo p2, "nneleMlpta etnFagromr ngo ncub"

    const-string p2, "gnemottnFoacu  nb narealgnelrM"

    const/4 v4, 0x4

    const-string p2, " tnngarlqaemnFnogera  uMaeblnt"

    const-string p2, "FragmentManager cannot be null"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    throw p1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo p2, "ucsltenkoalbtnblset le laCcei OnLsurnaR"

    const-string p2, "Rsn ebtllei acurbetknCtla alnLnsenluocO"

    const/4 v4, 0x0

    const-string p2, "ce mOansucannLett klsobniln aleltluRrbe"

    const-string p2, "OnResultCallbackListener cannot be null"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw p1

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string p2, "coAlovntiuabe cnt ylntu"

    const-string/jumbo p2, "lyuAteunbia nvotctlc n "

    const/4 v4, 0x1

    const-string p2, "cn tobitnalecli ybtuAnv"

    const-string p2, "Activity cannot be null"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw p1
.end method

.method public c()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v0, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x1

    move v5, v2

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    instance-of v1, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    check-cast v1, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    instance-of v1, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v1, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    instance-of v0, v0, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v0, Lcom/luck/picture/lib/b;->l:Ljava/lang/String;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v1, v0}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v3, v2}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/b;->W0()Lcom/luck/picture/lib/b;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v1, v0, v2}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v2, "pngetmypCm nvi r rbmeree,l rinstytaeiAfeeod eeteecraiame ctctnm  sFnmpo odedaUoel no a "

    const/4 v5, 0x7

    const-string v2, "ani eeutp mn  mdo drr ersrecreemlpe ccadneoFUy iielnotfmatoAeg  beam,yeiaoetn msatnCte "

    const-string v2, "Use only camera openCamera mode,Activity or Fragment interface needs to be implemented "

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x2

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    throw v0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v1, "mbqrtFnpeorganeaul lgtMecn a a"

    const-string v1, "gn a a FqnMetlmguatrcoaerbennl"

    const/4 v5, 0x5

    const-string v1, "eenatgF qMmlrenctblann grao an"

    const-string v1, "FragmentManager cannot be null"

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    throw v0

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "otsbyanetvnni cllci ust"

    const-string/jumbo v1, "vtsiellob t cnycntnuai "

    const/4 v5, 0x2

    const-string/jumbo v1, "lunm tiecnattlyo cin bA"

    const-string v1, "Activity cannot be null"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    throw v0

    :cond_6
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public d(Ls6/v;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v0, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v2, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    instance-of p1, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    instance-of p1, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v0, Lcom/luck/picture/lib/b;->l:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {}, Lcom/luck/picture/lib/b;->W0()Lcom/luck/picture/lib/b;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1, v0, v1}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "nenmbnutnaaeaalon  ecgmgltrF M"

    const/4 v4, 0x3

    const-string v0, "ancroaMgnantae e g lnboFmntrul"

    const-string v0, "FragmentManager cannot be null"

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw p1

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v0, "coiltb loknCesa eel rlnsetOLbnutlaabcnR"

    const-string/jumbo v0, "n baoulciakCR O tenutacesbetllnsLlonlre"

    const/4 v4, 0x7

    const-string v0, "aelcknulCtnul leoRcaiLseasnrb bnntulte "

    const-string v0, "OnResultCallbackListener cannot be null"

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "co cnbAnyalbtuiit  veln"

    const/4 v4, 0x3

    const-string v0, " tbe yopAni nuvltticcan"

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw p1

    :cond_6
    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method public e(I)V
    .locals 6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x3

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v1, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v3}, Lcom/luck/picture/lib/basic/n;->f()Landroidx/fragment/app/Fragment;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v3, v1, p1}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, p1, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v0, "et  tcAnq ovbliailnucun"

    const-string v0, "cbuie uyltailAoncnnt v "

    const-string/jumbo v0, "vlse utbnln c nAtytaoci"

    const-string v0, "Activity cannot be null"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    move v5, v4

    throw p1

    :cond_2
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-void
.end method

.method public f(Landroidx/activity/result/h;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x6

    or-int/2addr v5, v4

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x2

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v3, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v1, v0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v4, 0x2

    move v5, v4

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, p1, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v4, 0x3

    and-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v0, "onpmc Rethyaecuteu ulii sbvatnAnnlctr"

    const-string/jumbo v0, "se rulapuvcnenielRAit nyablnttt ouhcc"

    const/4 v5, 0x4

    const-string v0, "Aveyo ec huteurtlnsRbltniaa icnltnocu"

    const-string v0, "ActivityResultLauncher cannot be null"

    const/4 v5, 0x4

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v0, "bcvycoueq tl inttAi nna"

    const/4 v5, 0x4

    const-string/jumbo v0, "yi Atbi voutbcaenclnn l"

    const-string v0, "Activity cannot be null"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw p1

    :cond_2
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void
.end method

.method public g(Ls6/v;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v3, 0x0

    move v4, v3

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v4, 0x6

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, "elalLnulceuealrO tictlCnebbtnskR onassu"

    const-string v0, "bnsebeniltonlls cCkea u LlctuOlestarRna"

    const/4 v4, 0x3

    const-string v0, "eLllilapnbb ntecu kRtauene tOcllnnaosCr"

    const-string v0, "OnResultCallbackListener cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    throw p1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v0, "vnlcitlyqtm i Anna tbue"

    const-string/jumbo v0, "t emntA ocilvynubali nt"

    const/4 v4, 0x3

    const-string/jumbo v0, "tosi tc  yAtnicenvuanbl"

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    throw p1

    :cond_2
    :goto_0
    const/4 v4, 0x3

    return-void
.end method

.method public h(Z)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public i(Z)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->M0:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public j(Z)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->H0:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public k(Z)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    move v2, v1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public l(Z)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->G0:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public m(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public n(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public o(Ls6/d;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d1:Ls6/d;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public p(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public q(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public r(Lq6/a;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public s(Lq6/b;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public t(I)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K0:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public u(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->W:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public v(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->U:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public w(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v2, 0x1

    return-object p0
.end method

.method public x(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public y(Ljava/lang/String;)Lcom/luck/picture/lib/basic/i;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/i;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x7

    and-int/2addr v2, v1

    iput-object p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public z(Ls6/i;)Lcom/luck/picture/lib/basic/i;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n1:Ls6/i;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method
