.class public final Lcom/luck/picture/lib/basic/m;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field private final b:Lcom/luck/picture/lib/basic/n;


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/basic/n;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~syi M@o1ft~n@@~u~c~@ i@-~@ ~iolo @@ S 4 @~ t @.~@@dv@~@bol ~~b~ @@/~~m ~~~~@b@fa@ ~os/ ~o~@ rK"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v0, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    instance-of v1, v0, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x2

    xor-int/2addr v4, v2

    const/4 v5, 0x3

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x3

    move v5, v4

    sput-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    instance-of v1, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    instance-of v1, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v0, Lcom/luck/picture/lib/e;->p:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v3, v1}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/e;->l1()Lcom/luck/picture/lib/e;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2, v0, v1}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    goto :goto_1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "aabmggMnlcont an leeteFnnrsamr"

    const-string v1, "cFsntgrg mroelnbnan altaMeea n"

    const/4 v5, 0x3

    const-string v1, "FragmentManager cannot be null"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    throw v0

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "fvteoysonoemRbteSg n arrtpleaomrdici l sfmteUdm rn ei esut ctyyAeetten  emes;no)(F,"

    const-string/jumbo v2, "trtmotoUA iomebmr ietmerd nis, de  eSln(aRlfnogi ttyeceupcr)nsf eemttas;e yyFvnese "

    const/4 v5, 0x2

    const-string v2, "dlegobs Sm;sb(ittea,toeeoFnsfei rnorie eteRsmtc vmetnl UyAdeerpl tyu y cm frnaine)t"

    const-string v2, "Use only forSystemResult();,Activity or Fragment interface needs to be implemented "

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x3

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const-class v2, Lcom/luck/picture/lib/basic/b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw v0

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "tiycnnuelovnAia ol t tu"

    const-string v1, " un oAelilvyttict aocnn"

    const/4 v5, 0x7

    const-string v1, "cinetl pytoltbnA v cinu"

    const-string v1, "Activity cannot be null"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    throw v0

    :cond_6
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public b(Ls6/v;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_5

    const/4 v3, 0x0

    move v4, v3

    if-eqz p1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v4, 0x5

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x7

    move v4, v3

    iput-boolean v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v4, v3

    iput-boolean v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    instance-of p1, v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v0, Landroidx/appcompat/app/AppCompatActivity;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    instance-of p1, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 p1, 0x5

    const/4 v4, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x3

    if-eqz p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/luck/picture/lib/e;->p:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2, v1}, Landroidx/fragment/app/a0;->B(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroidx/fragment/app/a0;->r()I

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {}, Lcom/luck/picture/lib/e;->l1()Lcom/luck/picture/lib/e;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p1, v0, v1}, Lcom/luck/picture/lib/basic/a;->b(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_1

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, "amlM lnFqeugbgoarbntnt anenae "

    const-string/jumbo v0, "nglenbue  ntaaMgrFoanternlmba "

    const/4 v4, 0x0

    const-string/jumbo v0, "naseunetlnemgraltnb FMcr aaogn"

    const-string v0, "FragmentManager cannot be null"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw p1

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v0, "nueml rOeelnLastnncleCostabRklb  utlaui"

    const-string v0, "a cRtCunLe slliskuno eelluntrclntbbaaOe"

    const/4 v4, 0x0

    const-string/jumbo v0, "ituroeRce lbsunOlatsanConcllknlne  aLbe"

    const-string v0, "OnResultCallbackListener cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    throw p1

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "nilolbbynv  iuetpaAnt t"

    const-string/jumbo v0, "nc n lApvbntoyueit tlai"

    const/4 v4, 0x2

    const-string/jumbo v0, "tlaoenutctyui cn bAlvn "

    const-string v0, "Activity cannot be null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw p1

    :cond_6
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method

.method public c(I)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v6, 0x4

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1, v0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v4, ".pt.lu.p_lccpmsqycketo_erb.cdueoeiumo"

    const-string/jumbo v4, "rrptmb.lq.yeue_..epoocustmlec_cuokcid"

    const/4 v6, 0x7

    const-string v4, "ce_skmccqluru..yoiiueoetretc.m.pplb_o"

    const-string v4, "com.luck.picture.lib.mode_type_source"

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/luck/picture/lib/basic/n;->f()Landroidx/fragment/app/Fragment;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v3, v1, p1}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, p1, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v0, "casnntilnuovcbe yilA  t"

    const-string v0, "Activity cannot be null"

    const/4 v6, 0x7

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    throw p1

    :cond_2
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void
.end method

.method public d(Landroidx/activity/result/h;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/activity/result/h<",
            "Landroid/content/Intent;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x2

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v6, 0x0

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v4, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v1, v0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v4, "scemopttieumde.uobr..s.rpmioe__lcckuy"

    const-string/jumbo v4, "kesyco_emus.e.tcu.iultc_irocodpmrbep."

    const/4 v6, 0x0

    const-string/jumbo v4, "lpriorloe.mckbsyidtucmee.__.eocput.uc"

    const-string v4, "com.luck.picture.lib.mode_type_source"

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, v1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, p1, v2}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v0, "ueneabelltltnio it uvbcsLyRmhncr ctan"

    const-string/jumbo v0, "vRymoiulcunltLn rtlbha tntee accAnies"

    const/4 v6, 0x4

    const-string v0, "ActivityResultLauncher cannot be null"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    throw p1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v0, " eionbuoyA t avcnitlnlc"

    const-string v0, "Aluio l tvecybocntnnai "

    const/4 v6, 0x1

    const-string/jumbo v0, "o ntil pctA tncnavleiby"

    const-string v0, "Activity cannot be null"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    throw p1

    :cond_2
    :goto_0
    const/4 v6, 0x6

    return-void
.end method

.method public e(Ls6/v;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/v<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/f;->a()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->b:Lcom/luck/picture/lib/basic/n;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/n;->e()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-boolean v2, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->N0:Z

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-boolean v3, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P0:Z

    const/4 v5, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f1:Ls6/v;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p1, Landroid/content/Intent;

    const/4 v5, 0x1

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x0

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const-class v1, Lcom/luck/picture/lib/basic/PictureSelectorTransparentActivity;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "rtcube_.qoecsd.rybmcc_.peuolmiko.lite"

    const-string v1, ".ceusbdouteoclieo_u..irbcc.ermlmpyt_k"

    const-string/jumbo v1, "m_sueetltppsoe_burcorkl.cymi.e.iccu.d"

    const-string v1, "com.luck.picture.lib.mode_type_source"

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget p1, Lcom/luck/picture/lib/R$anim;->ps_anim_fade_in:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p1, v3}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v0, "celmeancneatlsli  lenubuR CLknualnObots"

    const-string/jumbo v0, "lRsausuCe tnba lOlnc boikeeualLlrnecnnt"

    const/4 v5, 0x0

    const-string v0, "OnResultCallbackListener cannot be null"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    throw p1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v0, "uAleo nilcpncay btot in"

    const-string v0, " A utclpilebo tnynanvic"

    const/4 v5, 0x5

    const-string/jumbo v0, "u  cbbAcviynatto nlneli"

    const-string v0, "Activity cannot be null"

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw p1

    :cond_2
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method public f(Z)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-boolean p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public g(Lq6/a;)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Y0:Lq6/a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q0:Z

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public h(Lq6/b;)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z0:Lq6/b;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public i(Ls6/i;)Lcom/luck/picture/lib/basic/m;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->n1:Ls6/i;

    const/4 v1, 0x4

    const/4 v0, 0x0

    return-object p0
.end method

.method public j(Ls6/j;)Lcom/luck/picture/lib/basic/m;
    .locals 2

    const/4 v1, 0x0

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->m1:Ls6/j;

    const/4 v0, 0x5

    const/4 v0, 0x1

    return-object p0
.end method

.method public k(Ls6/k;)Lcom/luck/picture/lib/basic/m;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method public l(Lq6/f;)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x6

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S0:Z

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public m(Ls6/w;)Lcom/luck/picture/lib/basic/m;
    .locals 2

    const/4 v1, 0x3

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->l1:Ls6/w;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public n(Ls6/x;)Lcom/luck/picture/lib/basic/m;
    .locals 2

    const/4 v1, 0x2

    sput-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e1:Ls6/x;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public o(I)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->s:I

    const/4 v2, 0x3

    return-object p0
.end method

.method public p(J)Lcom/luck/picture/lib/basic/m;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    cmp-long v0, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x4

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    mul-long/2addr p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->z:J

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p0
.end method

.method public q(I)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->t:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method public r(J)Lcom/luck/picture/lib/basic/m;
    .locals 5

    const/4 v4, 0x2

    const-wide/32 v0, 0x100000

    const-wide/32 v0, 0x100000

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    cmp-long v0, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x4

    const-wide/16 v1, 0x400

    const-wide/16 v1, 0x400

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    mul-long/2addr p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-wide p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A:J

    :goto_0
    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0
.end method

.method public s(I)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    iput p1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v2, 0x1

    return-object p0
.end method

.method public varargs t([Ljava/lang/String;)Lcom/luck/picture/lib/basic/m;
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    array-length v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-lez v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/m;->a:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Q:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method
