.class Lcom/luck/picture/lib/basic/e$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e$b;->r()Ljava/util/ArrayList;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/b<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/basic/e$b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e$b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$b$a;->a:Lcom/luck/picture/lib/basic/e$b;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s@m~~y~M@lt~in@~@@  t@r~ob d~o@o~@  ~@  ~  isbf  ~@ ~~~@ .4uc S~ @K@@~-~ /~@ov1oif @b~/~@a@~~l"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/luck/picture/lib/basic/e$b$a;->b(Lcom/luck/picture/lib/entity/LocalMedia;I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public b(Lcom/luck/picture/lib/entity/LocalMedia;I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$b$a;->a:Lcom/luck/picture/lib/basic/e$b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/basic/e$b;->o:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->F()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p2, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->I0(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$b$a;->a:Lcom/luck/picture/lib/basic/e$b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/basic/e$b;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->A()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p2, v0}, Lcom/luck/picture/lib/entity/LocalMedia;->B0(Ljava/lang/String;)V

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->A()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    xor-int/lit8 p1, p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p2, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->z0(Z)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
