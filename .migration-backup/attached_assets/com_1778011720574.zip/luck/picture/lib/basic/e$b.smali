.class Lcom/luck/picture/lib/basic/e$b;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/basic/e;->j0(Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Ljava/util/ArrayList<",
        "Lcom/luck/picture/lib/entity/LocalMedia;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic o:Ljava/util/ArrayList;

.field final synthetic p:Lcom/luck/picture/lib/basic/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/basic/e;Ljava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/basic/e$b;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/basic/e$b;->o:Ljava/util/ArrayList;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ". s~ @@~ ot~a@@1 m~v st~o~c~@@onK r~i~@ @oo~ -i@o~~4~f M@ ~d/ /@yS @u@ b ~~ @~ bl~@b~@l@i~@f@@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e$b;->r()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    check-cast p1, Ljava/util/ArrayList;

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e$b;->s(Ljava/util/ArrayList;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public r()Ljava/util/ArrayList;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e$b;->o:Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ge v0, v1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e$b;->o:Ljava/util/ArrayList;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    check-cast v5, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v8, 0x5

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a1:Lq6/f;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e$b;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v3, p0, Lcom/luck/picture/lib/basic/e$b;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v3, v3, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-boolean v3, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v8, 0x3

    const/4 v7, 0x4

    new-instance v6, Lcom/luck/picture/lib/basic/e$b$a;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v6, p0}, Lcom/luck/picture/lib/basic/e$b$a;-><init>(Lcom/luck/picture/lib/basic/e$b;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    move v4, v0

    move v4, v0

    const/4 v8, 0x5

    move v4, v0

    move v4, v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface/range {v1 .. v6}, Lq6/f;->a(Landroid/content/Context;ZILcom/luck/picture/lib/entity/LocalMedia;Ls6/b;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$b;->o:Ljava/util/ArrayList;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-object v0
.end method

.method public s(Ljava/util/ArrayList;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e$b;->p:Lcom/luck/picture/lib/basic/e;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/luck/picture/lib/basic/e;->e0(Lcom/luck/picture/lib/basic/e;Ljava/util/ArrayList;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method
