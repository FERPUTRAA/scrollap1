.class public Lcom/luck/picture/lib/basic/e$l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/basic/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "l"
.end annotation


# instance fields
.field public a:I

.field public b:Landroid/content/Intent;


# direct methods
.method public constructor <init>(ILandroid/content/Intent;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/basic/e$l;->a:I

    const/4 v0, 0x4

    move v1, v0

    iput-object p2, p0, Lcom/luck/picture/lib/basic/e$l;->b:Landroid/content/Intent;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
