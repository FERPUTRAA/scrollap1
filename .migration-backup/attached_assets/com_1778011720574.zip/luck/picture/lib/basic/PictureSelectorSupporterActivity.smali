.class public Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;
.super Landroidx/appcompat/app/AppCompatActivity;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method private t()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@1s~~@i~ f~@~ M~ o ~i@o/f ~n   o   ~@@~ b@-~os @K~@o@y r@@/t@ducS@@.om t@@va~~~lb~ ~~~@4 lb@~~i~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->b0()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->G()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->f0()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x7

    if-nez v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v5, 0x5

    invoke-static {p0, v1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0, v1, v2, v0}, Lr6/a;->a(Landroidx/appcompat/app/AppCompatActivity;IIZ)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method private v()V
    .locals 8

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v1, "sw.mt.cpuclbeiceti.vn_.exrekiloaemrur"

    const-string v1, ".esi..iiputewncrrebelovckt.ue_lmrlacx"

    const/4 v7, 0x0

    const-string v1, ".a_uoxiltekbpwmeeconcti..er.rlcrvleip"

    const-string v1, "com.luck.picture.lib.external_preview"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string v1, ".ebctbtirrciockiwu__nuo.pmivs.eeriepl.orlutnc"

    const-string v1, "com.luck.picture.lib.current_preview_position"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {}, Lcom/luck/picture/lib/d;->R1()Lcom/luck/picture/lib/d;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->n()Ljava/util/ArrayList;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v4, Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v5, "rnemetmp_eceebwlctaeirue._l.tpioiirdllxk.u.edvl_yasp"

    const/4 v7, 0x3

    const-string v5, "evalauueciiwerytptcxul_melr.bco.eetpii.s.dd_lpreel_n"

    const-string v5, "com.luck.picture.lib.external_preview_display_delete"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v3, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v0, v3, v4, v2}, Lcom/luck/picture/lib/d;->Y1(IILjava/util/ArrayList;Z)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v0, Lcom/luck/picture/lib/d;->P:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/basic/a;->a(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object v0, Lcom/luck/picture/lib/c;->A:Ljava/lang/String;

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    invoke-static {}, Lcom/luck/picture/lib/c;->f2()Lcom/luck/picture/lib/c;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/basic/a;->a(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;Landroidx/fragment/app/Fragment;)V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void
.end method


# virtual methods
.method protected attachBaseContext(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/luck/picture/lib/basic/g;->a(Landroid/content/Context;I)Landroid/content/ContextWrapper;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->attachBaseContext(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public finish()V
    .locals 4

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v0, v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v1, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2
    .param p1    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;->u()V

    const/4 v1, 0x1

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroidx/fragment/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;->t()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_activity_container:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->setContentView(I)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/PictureSelectorSupporterActivity;->v()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public u()V
    .locals 5

    const/4 v3, 0x6

    move v4, v3

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, -0x2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eq v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p0, v1}, Lt6/c;->d(Landroid/content/Context;I)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method
