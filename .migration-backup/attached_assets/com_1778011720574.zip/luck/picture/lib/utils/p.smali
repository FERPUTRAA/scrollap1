.class public Lcom/luck/picture/lib/utils/p;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-void
.end method

.method public static synthetic a(Lcom/luck/picture/lib/entity/LocalMediaFolder;Lcom/luck/picture/lib/entity/LocalMediaFolder;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ils/ @@@@~@4r/bo@@ioS~t@ ~t@ci@.~  ~ 1~@~o-~ n ~ K@df ~Mb~ @~y@~ ~o a~~@ @   ~o~@@~s~u@bmf vo~l~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/p;->c(Lcom/luck/picture/lib/entity/LocalMediaFolder;Lcom/luck/picture/lib/entity/LocalMediaFolder;)I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method public static synthetic b(Lcom/luck/picture/lib/entity/LocalMedia;Lcom/luck/picture/lib/entity/LocalMedia;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/p;->d(Lcom/luck/picture/lib/entity/LocalMedia;Lcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    return p0
.end method

.method private static synthetic c(Lcom/luck/picture/lib/entity/LocalMediaFolder;Lcom/luck/picture/lib/entity/LocalMediaFolder;)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, p0}, Ljava/lang/Integer;->compare(II)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p0
.end method

.method private static synthetic d(Lcom/luck/picture/lib/entity/LocalMedia;Lcom/luck/picture/lib/entity/LocalMedia;)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/entity/LocalMedia;->u()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->u()J

    move-result-wide p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1}, Ljava/lang/Long;->compare(JJ)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return p0
.end method

.method public static e(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    new-instance v0, Lcom/luck/picture/lib/utils/o;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/luck/picture/lib/utils/o;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public static f(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/luck/picture/lib/utils/n;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/luck/picture/lib/utils/n;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
