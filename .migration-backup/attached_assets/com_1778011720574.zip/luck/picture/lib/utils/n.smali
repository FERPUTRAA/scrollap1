.class public final synthetic Lcom/luck/picture/lib/utils/n;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s @ o@d tn~r~~v@ M@~~i /y of@@ m S ~fbo4.l@b~K@ l @~u@ ~o~  ~~oi/i@b~ @1 ~@-~@~~@@~so@@a~~@~ct"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p2, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/p;->b(Lcom/luck/picture/lib/entity/LocalMedia;Lcom/luck/picture/lib/entity/LocalMedia;)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method
