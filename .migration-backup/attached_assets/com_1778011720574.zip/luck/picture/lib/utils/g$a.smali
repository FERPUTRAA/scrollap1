.class Lcom/luck/picture/lib/utils/g$a;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/utils/g;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ls6/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic o:Ljava/lang/String;

.field final synthetic p:Landroid/content/Context;

.field final synthetic q:Ljava/lang/String;

.field final synthetic r:Ls6/c;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Ls6/c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/luck/picture/lib/utils/g$a;->r:Ls6/c;

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " os~~~~@@vM@@~sm~ 1r ~K  @@4 il~@-bd~f@ @@~~.~n@i/ot/oy@ ~~ f lt  b~a @S@@c~~ io~obu@ ~o@@  ~~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/utils/g$a;->r()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/utils/g$a;->s(Ljava/lang/String;)V

    const/4 v1, 0x7

    return-void
.end method

.method public r()Ljava/lang/String;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v12, 0x1

    new-instance v0, Landroid/content/ContentValues;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v12, 0x1

    const/4 v11, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v2

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v3, "esamm"

    const-string/jumbo v3, "masie"

    const/4 v12, 0x4

    const-string/jumbo v3, "igmeo"

    const-string/jumbo v3, "image"

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string v4, "bimvo"

    const-string/jumbo v4, "viomd"

    const/4 v12, 0x4

    const-string v4, "eudov"

    const-string/jumbo v4, "video"

    const/4 v11, 0x4

    move v12, v11

    const-string v5, "aptta_rphieev"

    const-string/jumbo v5, "relative_path"

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string v6, "eakoentdq"

    const-string v6, "ataeodnek"

    const/4 v12, 0x7

    const-string v6, "adskatent"

    const-string v6, "datetaken"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v7, "adtm_"

    const-string v7, "_data"

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string/jumbo v8, "mtpboemyi"

    const-string/jumbo v8, "ipemybt_m"

    const/4 v12, 0x2

    const-string/jumbo v8, "immeyb_ep"

    const-string/jumbo v8, "mime_type"

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v9, "aumydaulisen_"

    const-string v9, "_ydlieusnma_a"

    const/4 v12, 0x2

    const-string/jumbo v9, "npdaimspy_al_"

    const-string v9, "_display_name"

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eqz v2, :cond_3

    const/4 v12, 0x4

    const-string v2, "_UAD"

    const-string v2, "AUD_"

    const/4 v12, 0x0

    const-string v2, "_ADU"

    const-string v2, "AUD_"

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v12, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v9, v10}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-object v9, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    if-nez v9, :cond_1

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v9, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v9, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-nez v4, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v4, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v4, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-eqz v3, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string/jumbo v3, "puie/apdqm"

    const-string v3, "admupi/peg"

    const/4 v12, 0x7

    const-string/jumbo v3, "p/sedgmoau"

    const-string v3, "audio/mpeg"

    :goto_1
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {v0, v8, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v3

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eqz v3, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v0, v6, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    sget-object v1, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v0, v5, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x1

    goto :goto_2

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    sget-object v1, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v11, 0x3

    move v12, v11

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    move v12, v11

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string/jumbo v1, "r.ma"

    const-string/jumbo v1, "m.ra"

    const/4 v12, 0x0

    const-string v1, ".rma"

    const-string v1, ".amr"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    or-int/2addr v12, v11

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x3

    move v12, v11

    invoke-virtual {v0, v7, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    sget-object v2, Landroid/provider/MediaStore$Audio$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    goto/16 :goto_9

    :cond_3
    const/4 v12, 0x3

    const/4 v11, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v11, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v2

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string/jumbo v10, "iuqma"

    const-string/jumbo v10, "iuaqo"

    const/4 v12, 0x5

    const-string/jumbo v10, "odauo"

    const-string v10, "audio"

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-eqz v2, :cond_7

    const/4 v11, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string v2, "V_DI"

    const-string v2, "I_VD"

    const/4 v12, 0x4

    const-string v2, "IV_D"

    const-string v2, "VID_"

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {v0, v9, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v4, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x3

    if-nez v4, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget-object v4, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v4, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    if-nez v4, :cond_5

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v4, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x5

    invoke-virtual {v4, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-eqz v3, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    goto :goto_3

    :cond_4
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    goto :goto_4

    :cond_5
    :goto_3
    const/4 v12, 0x6

    const-string/jumbo v3, "ip4vmbseo"

    const-string v3, "/mspoi4ve"

    const/4 v12, 0x4

    const-string/jumbo v3, "piodvmu4/"

    const-string/jumbo v3, "video/mp4"

    :goto_4
    invoke-virtual {v0, v8, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-eqz v3, :cond_6

    const/4 v12, 0x4

    invoke-virtual {v0, v6, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    sget-object v1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v0, v5, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    goto :goto_5

    :cond_6
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    sget-object v1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v11, 0x0

    shr-int/2addr v12, v11

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    const-string v1, ".m4p"

    const/4 v12, 0x2

    const-string v1, ".pm4"

    const-string v1, ".mp4"

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v0, v7, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :goto_5
    const/4 v11, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    sget-object v2, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x7

    goto/16 :goto_9

    :cond_7
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v2, "M_GI"

    const-string v2, "IMG_"

    const/4 v12, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v0, v9, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-nez v3, :cond_9

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v11, 0x6

    xor-int/2addr v12, v11

    invoke-virtual {v3, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-nez v3, :cond_9

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-eqz v3, :cond_8

    const/4 v12, 0x2

    const/4 v11, 0x7

    goto :goto_6

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto :goto_7

    :cond_9
    :goto_6
    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x4

    const-string v3, "gemeg/apmp"

    const-string/jumbo v3, "ip/mgameeg"

    const/4 v12, 0x5

    const-string/jumbo v3, "mjagie/eqg"

    const-string/jumbo v3, "image/jpeg"

    :goto_7
    const/4 v11, 0x3

    move v12, v11

    invoke-virtual {v0, v8, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    if-eqz v3, :cond_a

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v0, v6, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string v1, "CasemrMC/DI"

    const-string v1, "DCIM/Camera"

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {v0, v5, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    goto :goto_8

    :cond_a
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->o:Ljava/lang/String;

    const/4 v12, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->e(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-nez v1, :cond_b

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->n(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-eqz v1, :cond_c

    :cond_b
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    sget-object v1, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const-string v1, "f.gi"

    const-string v1, "gif."

    const/4 v12, 0x4

    const-string v1, "fg.i"

    const-string v1, ".gif"

    const/4 v12, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-virtual {v0, v7, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_c
    :goto_8
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    sget-object v2, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v0

    :goto_9
    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-eqz v0, :cond_f

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->f(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-eqz v1, :cond_d

    const/4 v12, 0x0

    new-instance v1, Ljava/net/URL;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-direct {v1, v2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {v1}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    goto :goto_a

    :cond_d
    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    if-eqz v1, :cond_e

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {v1, v2}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    goto :goto_a

    :cond_e
    const/4 v11, 0x0

    const/4 v12, 0x1

    new-instance v1, Ljava/io/FileInputStream;

    const/4 v11, 0x2

    shl-int/2addr v12, v11

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->q:Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-direct {v1, v2}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    :goto_a
    const/4 v12, 0x2

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v2, v0}, Lcom/luck/picture/lib/basic/f;->b(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v1, v2}, Lcom/luck/picture/lib/utils/k;->w(Ljava/io/InputStream;Ljava/io/OutputStream;)Z

    move-result v1

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-eqz v1, :cond_f

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/utils/g$a;->p:Landroid/content/Context;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v1, v0}, Lcom/luck/picture/lib/utils/k;->m(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    return-object v0

    :cond_f
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    const/4 v0, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    return-object v0
.end method

.method public s(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/utils/g$a;->r:Ls6/c;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method
