.class public Lcom/luck/picture/lib/utils/d;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/text/SimpleDateFormat;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SimpleDateFormat"
        }
    .end annotation
.end field

.field private static final b:Ljava/text/SimpleDateFormat;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SimpleDateFormat"
        }
    .end annotation
.end field

.field private static final c:Ljava/text/SimpleDateFormat;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SimpleDateFormat"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v2, 0x1

    move v3, v2

    const-string v1, "HMsHdmSySsySmysyd"

    const-string/jumbo v1, "yyyyMMddHHmmssSSS"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sput-object v0, Lcom/luck/picture/lib/utils/d;->a:Ljava/text/SimpleDateFormat;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, "-yymMsM"

    const-string v1, "M-sMyyy"

    const/4 v3, 0x3

    const-string/jumbo v1, "yyM-oyM"

    const-string/jumbo v1, "yyyy-MM"

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    sput-object v0, Lcom/luck/picture/lib/utils/d;->b:Ljava/text/SimpleDateFormat;

    const/4 v3, 0x2

    const/4 v2, 0x2

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "yd :-bmyHMHmsdys:-m"

    const-string v1, "-dsm::d sHyyy-MmHym"

    const/4 v3, 0x7

    const-string v1, "HmsMmsuy-dyyM:y:dH-"

    const-string/jumbo v1, "yyyy-MM-dd HH:mm:ss"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/luck/picture/lib/utils/d;->c:Ljava/text/SimpleDateFormat;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method

.method public static a(JJ)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~M@@~~p   @@4a n o@/fi d ~~  Ko@-b @v~i@b r~o~@u~ @yt~il@sm~@/c.b@~ o@~~@@ @~l  @@S~@~o~~~ot1~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sub-long/2addr p2, p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const-wide/16 p0, 0x3e8

    const-wide/16 p0, 0x3e8

    const-wide/16 p0, 0x3e8

    const-wide/16 p0, 0x3e8

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    cmp-long v0, p2, p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-lez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    div-long/2addr p2, p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p0, "o9q/u2"

    const-string p0, "/792ou"

    const/4 v2, 0x4

    const-string p0, "7us2d/"

    const-string/jumbo p0, "\u79d2"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p1, "2uum9/d7/6eb"

    const-string/jumbo p1, "u2d67b/ue9b/"

    const/4 v2, 0x7

    const-string p1, "96/eo2u7ub/b"

    const-string/jumbo p1, "\u6beb\u79d2"

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method public static b(J)I
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/luck/picture/lib/utils/d;->f()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    sub-long/2addr v0, p0

    const/4 v3, 0x6

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    long-to-int p0, p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    return p0

    :catch_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 p0, -0x1

    or-int/2addr v3, p0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return p0
.end method

.method public static c(J)Ljava/lang/String;
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v12, 0x4

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    cmp-long v0, p0, v0

    const/4 v12, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v12, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x5

    if-nez v0, :cond_0

    move-wide p0, v1

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    cmp-long v0, p0, v1

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    if-gez v0, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v0, "-"

    const-string v0, "-"

    const/4 v12, 0x7

    const-string v0, "-"

    const-string v0, "-"

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    goto :goto_0

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v12, 0x7

    const-string v0, ""

    const-string v0, ""

    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-static {p0, p1}, Ljava/lang/Math;->abs(J)J

    move-result-wide p0

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-wide/16 v3, 0x1f4

    const-wide/16 v3, 0x1f4

    const/4 v11, 0x2

    const/4 v12, 0x4

    add-long/2addr p0, v3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    const-wide/16 v3, 0x3e8

    const/4 v12, 0x0

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    div-long/2addr p0, v3

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    const-wide/16 v3, 0x3c

    const-wide/16 v3, 0x3c

    const/4 v11, 0x5

    shr-int/2addr v12, v11

    rem-long v5, p0, v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    div-long v7, p0, v3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    rem-long/2addr v7, v3

    const/4 v12, 0x1

    const-wide/16 v3, 0xe10

    const-wide/16 v3, 0xe10

    const/4 v12, 0x1

    const-wide/16 v3, 0xe10

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    div-long/2addr p0, v3

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    cmp-long v1, p0, v1

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v2, 0x2

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    const/4 v3, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    const/4 v4, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    const/4 v9, 0x3

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    if-lez v1, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    const/4 v10, 0x4

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-array v10, v10, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    aput-object v0, v10, v4

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    aput-object p0, v10, v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    aput-object p0, v10, v2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    aput-object p0, v10, v9

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string p0, "d:%d:sud2%%200"

    const/4 v12, 0x2

    const-string p0, "%s%d:%02d:%02d"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v1, p0, v10}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    goto :goto_1

    :cond_2
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    new-array p1, v9, [Ljava/lang/Object;

    const/4 v11, 0x1

    move v12, v11

    aput-object v0, p1, v4

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    aput-object v0, p1, v3

    const/4 v11, 0x0

    and-int/2addr v12, v11

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    aput-object v0, p1, v2

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-string v0, "0%%22b%p0d:"

    const-string v0, "%d2s2%0p:0%"

    const/4 v12, 0x4

    const-string v0, "2:2d%sud0%%"

    const-string v0, "%s%02d:%02d"

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-static {p0, v0, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    :goto_1
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    return-object p0
.end method

.method public static d()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v2, Lcom/luck/picture/lib/utils/d;->a:Ljava/text/SimpleDateFormat;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2, v0}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object p0, Lcom/luck/picture/lib/utils/d;->a:Ljava/text/SimpleDateFormat;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p0
.end method

.method public static f()J
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v2, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-le v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->j(Ljava/lang/Object;)J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-wide v0
.end method

.method public static g(Landroid/content/Context;J)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-le v0, v1, :cond_0

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x2

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    mul-long/2addr p1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/d;->j(J)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    sget p1, Lcom/luck/picture/lib/R$string;->ps_current_week:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/d;->i(J)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    sget p1, Lcom/luck/picture/lib/R$string;->ps_current_month:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    sget-object p0, Lcom/luck/picture/lib/utils/d;->b:Ljava/text/SimpleDateFormat;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public static h(J)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v1, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-le v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x5

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    mul-long/2addr p0, v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lcom/luck/picture/lib/utils/d;->c:Ljava/text/SimpleDateFormat;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0
.end method

.method public static i(J)Z
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    new-instance v0, Ljava/util/Date;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object p0, Lcom/luck/picture/lib/utils/d;->b:Ljava/text/SimpleDateFormat;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Ljava/util/Date;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p0
.end method

.method private static j(J)Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v3, Ljava/util/Date;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v3, p0, p1}, Ljava/util/Date;-><init>(J)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ne p0, v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 p0, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v5, 0x0

    return p0
.end method

.method public static k(J)J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1}, Ljava/lang/Math;->abs(J)J

    move-result-wide p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-long/2addr p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x7

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    div-long/2addr p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    mul-long/2addr p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide p0
.end method
