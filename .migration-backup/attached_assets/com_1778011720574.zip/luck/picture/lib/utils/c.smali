.class public Lcom/luck/picture/lib/utils/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = 0x4

.field private static final b:I = 0x6400000


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static a(II)I
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " @s/@@l@M@@br  ~~~bSs@~   @@f @n@i @b~~t.oi~a @i@d l~~~~fmK1@~o ~o~to/yc@@ o -4~~  ~@ @u~~~ ~@~o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    rem-int/lit8 v0, p0, 0x2

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    const/4 v1, 0x1

    move v7, v1

    const/4 v6, 0x4

    move v7, v6

    if-ne v0, v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/lit8 p0, p0, 0x1

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    rem-int/lit8 v0, p1, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x4

    if-ne v0, v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 p1, p1, 0x1

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p0, p1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    int-to-float p0, p0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    int-to-float p1, v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    div-float/2addr p0, p1

    const/4 v7, 0x1

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    cmpg-float p1, p0, p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/high16 v2, 0x3fe2000000000000L    # 0.5625

    const-wide/high16 v2, 0x3fe2000000000000L    # 0.5625

    const/4 v7, 0x6

    const-wide/high16 v2, 0x3fe2000000000000L    # 0.5625

    const-wide/high16 v2, 0x3fe2000000000000L    # 0.5625

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-gtz p1, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    float-to-double v4, p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    cmpl-double p1, v4, v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-lez p1, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/16 p0, 0x680

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ge v0, p0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    return v1

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/16 p0, 0x137e

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ge v0, p0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 p0, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    return p0

    :cond_3
    const/4 v7, 0x3

    if-le v0, p0, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/16 p0, 0x2800

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ge v0, p0, :cond_4

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    const/4 p0, 0x4

    shr-int/2addr v7, p0

    const/4 v6, 0x4

    move v7, v6

    return p0

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    div-int/lit16 v0, v0, 0x500

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    return v0

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    float-to-double p0, p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    cmpg-double v2, p0, v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-gtz v2, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const/4 v7, 0x0

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    cmpl-double v2, p0, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-lez v2, :cond_7

    const/4 v6, 0x1

    move v7, v6

    div-int/lit16 v0, v0, 0x500

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v0, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_0

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    move v1, v0

    move v1, v0

    const/4 v7, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    return v1

    :cond_7
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    int-to-double v0, v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-wide/high16 v2, 0x4094000000000000L    # 1280.0

    const-wide/high16 v2, 0x4094000000000000L    # 1280.0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    div-double/2addr v2, p0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    div-double/2addr v0, v2

    const/4 v7, 0x7

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    double-to-int p0, p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    return p0
.end method

.method public static b(II)[I
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v0, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez p0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez p1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    filled-new-array {v0, v0}, [I

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    return-object p0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/c;->a(II)I

    move-result v1

    const/4 v8, 0x5

    and-int/2addr v9, v8

    invoke-static {}, Lcom/luck/picture/lib/utils/c;->c()J

    move-result-wide v2

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    move v4, v1

    move v4, v1

    const/4 v9, 0x1

    move v4, v1

    move v4, v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-nez v5, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    div-int v0, p0, v4

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    div-int v1, p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    mul-int v6, v0, v1

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    mul-int/lit8 v6, v6, 0x4

    int-to-long v6, v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    cmp-long v6, v6, v2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-lez v6, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    mul-int/lit8 v4, v4, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    filled-new-array {v0, v1}, [I

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    return-object p0
.end method

.method public static c()J
    .locals 7

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Runtime;->totalMemory()J

    move-result-wide v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-wide/32 v2, 0x6400000

    const/4 v6, 0x4

    const-wide/32 v2, 0x6400000

    const-wide/32 v2, 0x6400000

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    cmp-long v4, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-lez v4, :cond_0

    move-wide v0, v2

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    return-wide v0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance p0, Landroidx/exifinterface/media/a;

    const/4 v4, 0x6

    invoke-direct {p0, v1}, Landroidx/exifinterface/media/a;-><init>(Ljava/io/InputStream;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance p0, Landroidx/exifinterface/media/a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Landroidx/exifinterface/media/a;-><init>(Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p1, "oatmOitiern"

    const-string p1, "Orientation"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, p1, v2}, Landroidx/exifinterface/media/a;->l(Ljava/lang/String;I)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p1, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x3

    if-eq p0, p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p1, 0x6

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq p0, p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 p1, 0x8

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eq p0, p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    return v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 p0, 0x10e

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    return p0

    :cond_2
    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/16 p0, 0x5a

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return p0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 p0, 0xb4

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    return v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    throw p0
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/c;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-lez v1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v2, Landroid/graphics/BitmapFactory$Options;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {v2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-boolean v3, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v3, :cond_0

    const/4 v7, 0x0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p0, v3}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v3, v0, v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p1, v2}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_0
    :try_start_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget v4, v2, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    iget v5, v2, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v4, v5}, Lcom/luck/picture/lib/utils/c;->a(II)I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    iput v4, v2, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput-boolean v4, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v4, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p0, v4}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v3, v0, v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p1, v2}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v2
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v2, :cond_3

    :try_start_4
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v2, v1}, Lcom/luck/picture/lib/utils/c;->f(Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;

    move-result-object v1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x6

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p0, p1}, Lcom/luck/picture/lib/basic/f;->b(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast p0, Ljava/io/FileOutputStream;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_2

    :cond_2
    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance p0, Ljava/io/FileOutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {p0, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    :goto_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v1, v0}, Lcom/luck/picture/lib/utils/c;->g(Landroid/graphics/Bitmap;Ljava/io/FileOutputStream;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_3

    :catchall_0
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_4

    :catch_0
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_5

    :catchall_1
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_4

    :catch_1
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_5

    :cond_3
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_3
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_6

    :catchall_2
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    :goto_4
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto/16 :goto_a

    :catch_2
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    :goto_5
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_8

    :cond_4
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    :goto_6
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v1, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez p0, :cond_5

    :goto_7
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_9

    :catchall_3
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_a

    :catch_3
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    :goto_8
    :try_start_6
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v1, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-nez p0, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_7

    :cond_5
    :goto_9
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void

    :catchall_4
    move-exception p0

    :goto_a
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x0

    move v7, v6

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v1, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez p1, :cond_6

    const/4 v7, 0x3

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    :cond_6
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    throw p0
.end method

.method public static f(Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance v5, Landroid/graphics/Matrix;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v5}, Landroid/graphics/Matrix;-><init>()V

    const/4 v8, 0x4

    int-to-float p1, p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v5, p1}, Landroid/graphics/Matrix;->postRotate(F)Z

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v6, 0x1

    shl-int/2addr v8, v6

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-static/range {v0 .. v6}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object p0
.end method

.method private static g(Landroid/graphics/Bitmap;Ljava/io/FileOutputStream;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v1, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v2, 0x3c

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v2, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, p0}, Ljava/io/FileOutputStream;->write([B)V

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_1

    :catchall_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    goto :goto_2

    :catch_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_2

    :catch_1
    move-exception p0

    :goto_0
    :try_start_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p0
.end method
