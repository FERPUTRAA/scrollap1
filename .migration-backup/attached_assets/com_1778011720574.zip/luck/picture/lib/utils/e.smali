.class public Lcom/luck/picture/lib/utils/e;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;F)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b si@ @by@    o- @m@@~~4@@~ ~ ~@~ /~n  d .otf@a~~~K@~~~ul~@lcir@~t  ~v~sS@@ @~o/i@oof~~1@@~o@Mb~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    mul-float/2addr p1, p0

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/high16 p0, 0x3f000000    # 0.5f

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    add-float/2addr p1, p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    float-to-int p0, p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;)I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x0

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v2, "esmmd"

    const-string/jumbo v2, "nmsed"

    const/4 v5, 0x7

    const-string/jumbo v2, "nedmo"

    const-string v2, "dimen"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v3, "idoanbd"

    const-string v3, "android"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, p1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-lez p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-lt p1, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    int-to-float v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    mul-float/2addr v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    div-float/2addr v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 p0, 0x0

    move v5, p0

    const/4 v4, 0x5

    move v5, v4

    cmpl-float p0, v0, p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/high16 p1, 0x3f000000    # 0.5f

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ltz p0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-float/2addr v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    sub-float/2addr v0, p1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    float-to-int p0, v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    return p0

    :catch_0
    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v0
.end method

.method public static c(Landroid/content/Context;)I
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-ne v0, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    move v2, v1

    move v2, v1

    const/4 v4, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->l(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v0, "rohieauvhmatt_nnibgai"

    const-string/jumbo v0, "toambhnthigingava_rei"

    const/4 v4, 0x3

    const-string v0, "eirhnhipo_bgta_vagani"

    const-string/jumbo v0, "navigation_bar_height"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, "ahiaoao_niit_lndrchntesepgabavg"

    const/4 v4, 0x1

    const-string/jumbo v0, "shhiinvrqlpaea_ggabia_dtnnate_o"

    const-string/jumbo v0, "navigation_bar_height_landscape"

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/e;->b(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return p0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1
.end method

.method public static d(Landroid/content/Context;)I
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->l(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "vanorbiahntid__iawbg"

    const-string/jumbo v0, "itsr_noi_adwtvbnhgia"

    const-string/jumbo v0, "navigation_bar_width"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/e;->b(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method public static e(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "wnimow"

    const-string/jumbo v0, "window"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p0, Landroid/view/WindowManager;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget p0, v0, Landroid/graphics/Point;->y:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p0
.end method

.method public static f(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x1

    const-string/jumbo v0, "oidwon"

    const-string/jumbo v0, "window"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Landroid/view/WindowManager;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget p0, v0, Landroid/graphics/Point;->x:I

    const/4 v2, 0x2

    return p0
.end method

.method private static g(Landroid/content/Context;I)Ljava/lang/String;
    .locals 2

    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0

    :catch_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method public static h(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->k(Landroid/content/Context;)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sub-int/2addr v0, p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method private static i(Landroid/app/Activity;)F
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Landroid/util/DisplayMetrics;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget p0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    int-to-float p0, p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v3, 0x4

    div-float/2addr p0, v1

    const/4 v3, 0x0

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    int-to-float v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    div-float/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, v0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p0
.end method

.method public static j(Landroid/content/Context;)I
    .locals 6

    const/4 v5, 0x1

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const-string v1, "bneum"

    const-string v1, "eunmd"

    const/4 v5, 0x3

    const-string/jumbo v1, "muend"

    const-string v1, "dimen"

    const/4 v5, 0x3

    const-string/jumbo v2, "pdpindo"

    const-string/jumbo v2, "pdnordi"

    const/4 v5, 0x2

    const-string/jumbo v2, "iqonadr"

    const-string v2, "android"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v3, "tgs_ishartqsauehb"

    const-string v3, "httiasugqeat_hbrs"

    const/4 v5, 0x1

    const-string v3, "biumhse_a_gathttr"

    const-string/jumbo v3, "status_bar_height"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-lez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/high16 v0, 0x41d00000    # 26.0f

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v0
.end method

.method private static k(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->l(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->c(Landroid/content/Context;)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    add-int/2addr v0, p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p0
.end method

.method public static l(Landroid/content/Context;)Z
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v9, 0x6

    const/4 v1, 0x0

    const/4 v9, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x7

    move v9, v8

    return v1

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast p0, Landroid/app/Activity;

    const/4 v8, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v9, 0x7

    move v3, v1

    move v3, v1

    const/4 v9, 0x2

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v4, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-ge v3, v2, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v5}, Landroid/view/View;->getId()I

    move-result v6

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v7, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eq v6, v7, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-static {p0, v6}, Lcom/luck/picture/lib/utils/e;->g(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string v7, "aokiontvaordBBgagarncui"

    const-string/jumbo v7, "navigationBarBackground"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v6, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez v5, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    move v2, v4

    move v2, v4

    const/4 v9, 0x1

    move v2, v4

    move v2, v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x5

    const/4 v9, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_2
    const/4 v9, 0x5

    move v2, v1

    move v2, v1

    const/4 v9, 0x1

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v2, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Lr6/c;->k()Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v2, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/16 v3, 0x1d

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ge v2, v3, :cond_4

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v2, "b_eabbdivgsei_nab_aatienrdahor"

    const-string v2, "_asv_igdha_ieelabaenodbrbatrni"

    const-string v2, "a_rvdaugabiabte_rane_dhebniiln"

    const-string/jumbo v2, "navigationbar_hide_bar_enabled"

    invoke-static {p0, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-nez p0, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    move v1, v4

    move v1, v4

    const/4 v9, 0x2

    move v1, v4

    move v1, v4

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    return v1

    :catch_0
    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getSystemUiVisibility()I

    move-result p0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    and-int/lit8 p0, p0, 0x2

    const/4 v8, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez p0, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    move v1, v4

    move v1, v4

    const/4 v9, 0x0

    move v1, v4

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    move v2, v1

    move v2, v1

    const/4 v9, 0x5

    move v2, v1

    move v2, v1

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    return v2
.end method

.method public static m(Landroid/app/Activity;)Z
    .locals 6

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-ne v0, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v5, 0x1

    move v0, v1

    move v0, v1

    const/4 v5, 0x3

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/luck/picture/lib/utils/e;->i(Landroid/app/Activity;)F

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/high16 v3, 0x44160000    # 600.0f

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    cmpl-float p0, p0, v3

    const/4 v5, 0x2

    if-gez p0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v1
.end method
