.class public Lcom/luck/picture/lib/utils/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@os@~olb~@f@r@n@@  o~o S@/ t~~~~mM~t @~ib @y @@ ~@o@v@i~ /~~u@4 icb1l~o@~d~  f@ sa~@ @ K-~~~. ~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast p0, Landroid/app/Activity;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    xor-int/2addr p0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v0, p0, Landroid/content/ContextWrapper;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    check-cast p0, Landroid/content/ContextWrapper;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    instance-of v0, v0, Landroid/app/Activity;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast p0, Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    xor-int/2addr p0, v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    return p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v1
.end method

.method public static b(Landroidx/fragment/app/FragmentActivity;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroidx/fragment/app/FragmentManager;->o0(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v1
.end method

.method public static c(Landroidx/fragment/app/FragmentActivity;)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentManager;->x0()I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-ne p0, v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    move v1, v0

    const/4 v3, 0x2

    move v1, v0

    move v1, v0

    :cond_1
    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1
.end method

.method public static d(Landroid/app/Activity;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x0

    move v2, v0

    move v2, v0

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    move v3, v0

    :cond_2
    :goto_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    return v0
.end method
