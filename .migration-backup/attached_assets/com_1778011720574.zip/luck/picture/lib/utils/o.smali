.class public final synthetic Lcom/luck/picture/lib/utils/o;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~sit@ @ol~~~ i@y1a o@ ~f@~@@-olt~@ o~~~~~@ov o@.@  i~b@@ dbs~~M~/ ~@ r @@c  ~ un S/K ~b~@@~~f4@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p2, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/p;->a(Lcom/luck/picture/lib/entity/LocalMediaFolder;Lcom/luck/picture/lib/entity/LocalMediaFolder;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method
