.class public Lcom/luck/picture/lib/utils/r;
.super Ljava/lang/Object;


# static fields
.field private static final a:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static a([I)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s@S~1 @ t@  ~~s@  da@@@u@M~~@yi  v n@i@~~@@o~o~@~~~@ im fc4/@~~~.l-l ~~r @  bbo@K~~~f ~/oto@bo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    array-length p0, p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-lez p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p0, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method public static b(I)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-lez p0, :cond_0

    const/4 v0, 0x3

    move v1, v0

    const/4 p0, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method

.method public static c(I)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x4

    return p0
.end method

.method public static d(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string v0, ")/(m)^*[s//"

    const-string v0, "(^s/[)*//)/"

    const/4 v2, 0x3

    const-string v0, ")//^o/[)]/*"

    const-string v0, "\\([^)]*\\)"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p0
.end method

.method public static e(Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v0, "/%m][bd^*"

    const-string v0, "[*%md%/^]"

    const/4 v4, 0x3

    const-string v0, "^/*%%]ud/"

    const-string v0, "%[^%]*\\d"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    move v1, v0

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p0, 0x2

    const/4 v4, 0x7

    if-lt v1, p0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x1

    move v4, v3

    return v0
.end method

.method public static f(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    xor-int/lit8 p0, p0, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method public static g(Landroid/content/Context;I)Landroid/graphics/ColorFilter;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    sget-object p1, Landroidx/core/graphics/g;->j:Landroidx/core/graphics/g;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0, p1}, Landroidx/core/graphics/f;->a(ILandroidx/core/graphics/g;)Landroid/graphics/ColorFilter;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method
