.class public Lcom/luck/picture/lib/utils/b;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0xfa


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/widget/ImageView;Z)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "brsS~@ @-~ @to@~mi~ ~vn@su@~ //@~bfbl~~ ~~~1  lo o~@~@.@ @~if@@4K~ c @ @~~@~o~@d o oMy@i@ta~~ @ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/high16 v1, 0x43340000    # 180.0f

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    move v3, v1

    move v3, v1

    const/4 v5, 0x6

    move v3, v1

    move v3, v1

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    move v1, v0

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    move v0, v3

    move v0, v3

    const/4 v5, 0x5

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 p1, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-array p1, p1, [F

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    aput v0, p1, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    aput v1, p1, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v0, "ootmiats"

    const-string v0, "ansoitto"

    const/4 v5, 0x4

    const-string/jumbo v0, "ooitontr"

    const-string/jumbo v0, "rotation"

    const/4 v4, 0x3

    const/4 v4, 0x7

    invoke-static {p0, v0, p1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance p1, Landroid/view/animation/LinearInterpolator;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p1}, Landroid/view/animation/LinearInterpolator;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method

.method public static b(Landroid/view/View;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Landroid/animation/AnimatorSet;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-array v2, v1, [F

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    fill-array-data v2, :array_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v3, "cmXseb"

    const-string v3, "eXcmsl"

    const/4 v5, 0x4

    const-string/jumbo v3, "uXaesc"

    const-string/jumbo v3, "scaleX"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0, v3, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-array v1, v1, [F

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    fill-array-data v1, :array_1

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, "Yplsae"

    const-string/jumbo v3, "saeYol"

    const/4 v5, 0x1

    const-string/jumbo v3, "sYqeac"

    const-string/jumbo v3, "scaleY"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p0, v3, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-array v1, v1, [Landroid/animation/Animator;

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    aput-object v2, v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    aput-object p0, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    const/4 v5, 0x4

    const-wide/16 v1, 0xfa

    const-wide/16 v1, 0xfa

    const/4 v5, 0x4

    const-wide/16 v1, 0xfa

    const-wide/16 v1, 0xfa

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p0, Landroid/view/animation/LinearInterpolator;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    return-void

    nop

    :array_0
    .array-data 4
        0x3f800000    # 1.0f
        0x3f8ccccd    # 1.1f
        0x3f800000    # 1.0f
    .end array-data

    :array_1
    .array-data 4
        0x3f800000    # 1.0f
        0x3f8ccccd    # 1.1f
        0x3f800000    # 1.0f
    .end array-data
.end method
