.class public Lcom/luck/picture/lib/utils/s;
.super Ljava/lang/Object;


# static fields
.field private static final a:J = 0x3e8L

.field private static b:J

.field private static c:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method static synthetic a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@sf~~1@4o~ s@Ko@~~@ vt/ @yo.~@~ ~@ ~r~@t do ~@ @@ @@~@fu@ - @i@@ba M~lS~i~ n l~~m i@~b~~~o  oc/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    sput-object p0, Lcom/luck/picture/lib/utils/s;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static b()Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget-wide v2, Lcom/luck/picture/lib/utils/s;->b:J

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    sub-long v2, v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x4

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x1

    const/4 v6, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-gez v2, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    return v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    sput-wide v0, Lcom/luck/picture/lib/utils/s;->b:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    return v0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/s;->b()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/luck/picture/lib/utils/s;->c:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    invoke-static {}, Lo6/b;->d()Lo6/b;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lo6/b;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {}, Lcom/luck/picture/lib/thread/a;->r0()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, p1, p0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object p1, Lcom/luck/picture/lib/utils/s;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Lcom/luck/picture/lib/utils/s$a;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/utils/s$a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->s0(Ljava/lang/Runnable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method
