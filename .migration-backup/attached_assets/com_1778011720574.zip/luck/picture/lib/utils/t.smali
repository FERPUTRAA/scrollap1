.class public Lcom/luck/picture/lib/utils/t;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    return-void
.end method

.method public static a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            "TT;)TT;"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~y@@t  ~@@~/ ~c/ f~~~@~@@   ~i~o@nS@Kt4 @ @ @Ma   ~~ib~dlsm@~~b~~~ouv~~o - rf.o@l@o~ @ o1@@@i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    if-nez p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public static b(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/t;->c(Ljava/lang/Object;Z)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p0
.end method

.method public static c(Ljava/lang/Object;Z)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p0

    :cond_0
    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "sfaml"

    const-string/jumbo v0, "saslf"

    const/4 v2, 0x1

    const-string v0, "elsfo"

    const-string v0, "false"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    xor-int/lit8 p1, p0, 0x1

    :catch_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1
.end method

.method public static d(Ljava/lang/Object;)D
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/t;->e(Ljava/lang/Object;I)D

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-wide v0
.end method

.method public static e(Ljava/lang/Object;I)D
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-nez p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    int-to-double p0, p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-wide p0

    :cond_0
    :try_start_0
    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :catch_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    int-to-double p0, p1

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    return-wide p0
.end method

.method public static f(Ljava/lang/Object;)F
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/utils/t;->g(Ljava/lang/Object;J)F

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return p0
.end method

.method public static g(Ljava/lang/Object;J)F
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    if-nez p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    long-to-float p0, p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p0

    :cond_0
    :try_start_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    goto :goto_0

    :catch_0
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    long-to-float p0, p1

    :goto_0
    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method public static h(Ljava/lang/Object;)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/t;->i(Ljava/lang/Object;I)I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0
.end method

.method public static i(Ljava/lang/Object;I)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x4

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p1

    :cond_0
    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    move p1, p0

    move p1, p0

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1
.end method

.method public static j(Ljava/lang/Object;)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/utils/t;->k(Ljava/lang/Object;J)J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static k(Ljava/lang/Object;J)J
    .locals 4

    const/4 v3, 0x2

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x3

    const-string v0, "."

    const-string v0, "."

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-wide p1

    :cond_0
    :try_start_0
    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    move-wide p1, p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    return-wide p1
.end method

.method public static l(Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    :try_start_0
    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    goto :goto_0

    :catch_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const-string p0, ""

    const/4 v1, 0x1

    const-string p0, ""

    const-string p0, ""

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method
