.class public Lcom/luck/picture/lib/utils/m;
.super Ljava/lang/Object;


# static fields
.field public static final a:I = 0x1e


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@siroK-~t~~ @@ @ ~ 1@f~@ @~~o@~@@  ~d l~ybo~@S~~l~4@ @ M@n~@~s  u/@ bcb~@av o@m oi~o ./@~f~t~~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v1, 0x18

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x1

    and-int/2addr v2, v0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0
.end method

.method public static b()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method public static c()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v1, 0x18

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return v0
.end method

.method public static d()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method public static e()Z
    .locals 4

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 v1, 0x1d

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public static f()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/16 v1, 0x1e

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0
.end method
