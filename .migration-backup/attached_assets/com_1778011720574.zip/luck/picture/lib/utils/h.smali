.class public Lcom/luck/picture/lib/utils/h;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentValues;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@@sf.~ @oy~~ b doi4 if t~lt@@~m1@ @ @@K n@~ vcs~@  b/~oSMbo@@@~ r@-~@~~  ~/ @uai~@o  ~l~~o~~~~@@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v1, Landroid/content/ContentValues;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v2, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1, v2}, Landroid/content/ContentValues;-><init>(I)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v3, "_MIG"

    const-string v3, "_MGI"

    const/4 v8, 0x1

    const-string v3, "M_IG"

    const-string v3, "IMG_"

    const/4 v8, 0x7

    const-string/jumbo v4, "nmpm_sida_yea"

    const-string/jumbo v4, "n_siapleadmy_"

    const/4 v8, 0x6

    const-string/jumbo v4, "lyanopmdi_se_"

    const-string v4, "_display_name"

    const/4 v8, 0x1

    const/4 v7, 0x3

    if-eqz v2, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v3}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string v2, "."

    const-string v2, "."

    const/4 v8, 0x4

    const-string v2, "."

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v6, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ne v5, v6, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v3}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x2

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x0

    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez p0, :cond_2

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    const-string p0, "bivom"

    const-string/jumbo p0, "iodmv"

    const/4 v8, 0x2

    const-string p0, "euoiv"

    const-string/jumbo p0, "video"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    if-eqz p0, :cond_3

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string p1, "eig/ojaegp"

    const/4 v8, 0x7

    const-string p1, "/ggjeiapem"

    const-string/jumbo p1, "image/jpeg"

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo p0, "ybt_ipemq"

    const-string/jumbo p0, "yimpeb_mt"

    const/4 v8, 0x5

    const-string/jumbo p0, "mime_type"

    const/4 v8, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1, p0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz p0, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string p0, "desuktnae"

    const-string/jumbo p0, "tdeenauka"

    const/4 v8, 0x0

    const-string/jumbo p0, "kttmanede"

    const-string p0, "datetaken"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v1, p0, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const-string p0, "aptporaveeitl"

    const-string p0, "aaetrl_ptiepv"

    const/4 v8, 0x6

    const-string p0, "arilabe_vptte"

    const-string/jumbo p0, "relative_path"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string p1, "CmCeMauDarI"

    const-string/jumbo p1, "maDrMCaIqeC"

    const/4 v8, 0x4

    const-string/jumbo p1, "merICMapDCa"

    const-string p1, "DCIM/Camera"

    const/4 v8, 0x4

    invoke-virtual {v1, p0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object v1
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentValues;
    .locals 9

    const/4 v7, 0x7

    move v8, v7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v1, Landroid/content/ContentValues;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v2, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {v1, v2}, Landroid/content/ContentValues;-><init>(I)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v3, "_VID"

    const-string v3, "VID_"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v4, "mlnaseypq_i_s"

    const-string v4, "a_s_paisnmely"

    const/4 v8, 0x7

    const-string/jumbo v4, "yasas_ilme_dp"

    const-string v4, "_display_name"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v3}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v2, "."

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v6, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-ne v5, v6, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v3}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    invoke-virtual {p0, v2}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, v4, p0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-nez p0, :cond_2

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string p0, "gaemm"

    const-string p0, "aeimg"

    const/4 v8, 0x2

    const-string p0, "geimo"

    const-string/jumbo p0, "image"

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz p0, :cond_3

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string/jumbo p1, "m4pdvbe/i"

    const-string/jumbo p1, "video/mp4"

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string/jumbo p0, "opmiyeum_"

    const-string p0, "epmioy_em"

    const-string/jumbo p0, "pmiy_mepe"

    const-string/jumbo p0, "mime_type"

    invoke-virtual {v1, p0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result p0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz p0, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string p0, "etentbkad"

    const/4 v8, 0x6

    const-string p0, "attakednq"

    const-string p0, "datetaken"

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, p0, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string/jumbo p0, "ttsupv_ihaele"

    const-string p0, "ailv_ruhtpeet"

    const-string p0, "alvmtehatrp_e"

    const-string/jumbo p0, "relative_path"

    const/4 v8, 0x1

    sget-object p1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1, p0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object v1
.end method

.method public static c(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)Landroid/net/Uri;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v1, "_"

    const-string v1, "_"

    const/4 v5, 0x1

    const-string v1, "_"

    const-string v1, "_"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->S:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->f:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0, v0, v1}, Lcom/luck/picture/lib/utils/h;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz p0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput-object v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    goto :goto_2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p0, v3, v0, v1, v2}, Lcom/luck/picture/lib/utils/k;->c(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/k;->v(Landroid/content/Context;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    :goto_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    return-object p0
.end method

.method public static d(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)Landroid/net/Uri;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-boolean v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b:Z

    const/4 v4, 0x4

    move v5, v4

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v2, "_"

    const-string v2, "_"

    const-string v2, "_"

    const-string v2, "_"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v5, 0x1

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g:Ljava/lang/String;

    const/4 v5, 0x7

    invoke-static {p0, v0, v2}, Lcom/luck/picture/lib/utils/h;->f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x7

    iget-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->e:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, v3, v0, v1, v2}, Lcom/luck/picture/lib/utils/k;->c(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-object v1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->Z:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lcom/luck/picture/lib/utils/k;->v(Landroid/content/Context;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p0
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-array v0, v0, [Landroid/net/Uri;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/h;->a(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentValues;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo p2, "ondmoup"

    const-string/jumbo p2, "pnudtom"

    const-string/jumbo p2, "mdentbu"

    const-string/jumbo p2, "mounted"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object p2, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p2, p1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object p0, v0, v2

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object p2, Landroid/provider/MediaStore$Images$Media;->INTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, p2, p1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    aput-object p0, v0, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    aget-object p0, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p0
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array v0, v0, [Landroid/net/Uri;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1, p2}, Lcom/luck/picture/lib/utils/h;->b(Ljava/lang/String;Ljava/lang/String;)Landroid/content/ContentValues;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p2, "qtduoeu"

    const-string p2, "eqodmtu"

    const/4 v4, 0x7

    const-string/jumbo p2, "pedmuto"

    const-string/jumbo p2, "mounted"

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object p2, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, p2, p1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    aput-object p0, v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p2, Landroid/provider/MediaStore$Video$Media;->INTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0, p2, p1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    aput-object p0, v0, v2

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    aget-object p0, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0
.end method
