.class public Lcom/luck/picture/lib/utils/k;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = 0x400

.field public static final b:Ljava/lang/String; = ".jpg"

.field public static final c:Ljava/lang/String; = ".mp4"

.field public static final d:Ljava/lang/String; = ".amr"

.field static final e:Ljava/lang/String; = "PictureFileUtils"

.field public static final f:I = 0x400

.field public static final g:I = 0x100000

.field public static final h:I = 0x40000000


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Ljava/io/Closeable;)V
    .locals 3
    .param p0    # Ljava/io/Closeable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "d s ~~S@@@f @o~@~~@o1@sat @@@o~@ ~ l @ @o@vbo~ ~Mi@~~  / @n~ u~@ .l~c~~-oy~K~~@t~i b@4b~~/  @imf"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    instance-of v0, p0, Ljava/io/Closeable;

    const/4 v2, 0x5

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v2, 0x1

    return-void
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 11
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v10, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-void

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v0, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    new-instance v1, Ljava/io/FileInputStream;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    new-instance v1, Ljava/io/FileOutputStream;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v1, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v1}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x4

    const-wide/16 v3, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p0}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v5

    move-object v2, p0

    move-object v2, p0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->transferTo(JJLjava/nio/channels/WritableByteChannel;)J
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_1

    :catchall_0
    move-exception p1

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object p0, v8

    move-object p0, v8

    move-object p0, v8

    move-object p0, v8

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_2

    :catch_0
    move-exception p1

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, p0

    move-object v0, p0

    move-object p0, v8

    move-object p0, v8

    move-object p0, v8

    move-object p0, v8

    const/4 v10, 0x2

    const/4 v9, 0x3

    goto :goto_0

    :catchall_1
    move-exception p1

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto :goto_2

    :catch_1
    move-exception p1

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    :try_start_2
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-void

    :catchall_2
    move-exception p1

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    throw p1
.end method

.method public static c(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/utils/k;->e(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-object p0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->o(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, "_VID"

    const-string v1, "_IDV"

    const/4 v3, 0x2

    const-string v1, "_DIV"

    const-string v1, "VID_"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p2, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v1, "DUA_"

    const-string v1, "_AUD"

    const/4 v3, 0x1

    const-string v1, "D_UA"

    const-string v1, "AUD_"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p2, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-eqz p2, :cond_6

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0

    :cond_7
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->l(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object p0, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v1, "MI_G"

    const-string v1, "IG_M"

    const/4 v3, 0x6

    const-string v1, "MI_G"

    const-string v1, "IMG_"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p2, :cond_9

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_8

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_8
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0

    :cond_9
    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-eqz p2, :cond_a

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    :cond_a
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method private static e(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/utils/k;->f(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-object p0
.end method

.method private static f(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const-string/jumbo p4, "notmsdu"

    const-string p4, "desoutn"

    const/4 v4, 0x0

    const-string/jumbo p4, "omdeout"

    const-string/jumbo p4, "mounted"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p4, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p4, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object p0, Landroid/os/Environment;->DIRECTORY_DCIM:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance p4, Ljava/io/File;

    const/4 v4, 0x2

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const-string/jumbo v2, "reamab"

    const-string/jumbo v2, "raamem"

    const/4 v4, 0x5

    const-string/jumbo v2, "ureCma"

    const-string v2, "Camera"

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p4, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/k;->n(Landroid/content/Context;I)Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance p4, Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v1, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p4, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    new-instance p0, Ljava/io/File;

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p4

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {p4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-virtual {p4}, Ljava/io/File;->exists()Z

    move-result p4

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez p4, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p4

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p4}, Ljava/io/File;->mkdirs()Z

    :cond_2
    move-object p4, p0

    move-object p4, p0

    move-object p4, p0

    move-object p4, p0

    :cond_3
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p4}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez p0, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {p4}, Ljava/io/File;->mkdirs()Z

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x2

    move v4, v0

    if-eq p1, v0, :cond_9

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eq p1, v0, :cond_7

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p1, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string p3, "gp.j"

    const-string p3, ".gjp"

    const/4 v4, 0x5

    const-string p3, ".gpj"

    const-string p3, ".jpg"

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p0, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string p1, "GM_I"

    const-string p1, "IG_M"

    const-string p1, "_IGM"

    const-string p1, "IMG_"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p0, Ljava/io/File;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0, p4, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p0

    :cond_7
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p0, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p1, "_UDA"

    const-string p1, "UAD_"

    const/4 v4, 0x7

    const-string p1, "UD_A"

    const-string p1, "AUD_"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo p1, "r.ma"

    const-string p1, ".mra"

    const/4 v4, 0x5

    const-string/jumbo p1, "r.am"

    const-string p1, ".amr"

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_8
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance p0, Ljava/io/File;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0, p4, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v3, 0x7

    move v4, v3

    return-object p0

    :cond_9
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p0, :cond_a

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    move v4, v3

    const-string p1, "_DVI"

    const-string p1, "DI_V"

    const/4 v4, 0x7

    const-string p1, "I_DV"

    const-string p1, "VID_"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p1, "p.4m"

    const-string p1, ".mp4"

    const/4 v4, 0x2

    const-string p1, ".mp4"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_a
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance p0, Ljava/io/File;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, p4, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0
.end method

.method public static g(Landroid/content/Context;)V
    .locals 8
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    sget-object v0, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    array-length v2, v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    const/4 v7, 0x4

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x6

    if-ge v3, v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    aget-object v4, v0, v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v6, 0x4

    move v7, v6

    array-length v2, v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    const/4 v7, 0x5

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-ge v3, v2, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    aget-object v4, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/io/File;->isFile()Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v5, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_1

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz p0, :cond_5

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {p0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz p0, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    array-length v0, p0

    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ge v1, v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    aget-object v2, p0, v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/io/File;->isFile()Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v3, :cond_4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_2

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x4

    return-void
.end method

.method public static h(Landroid/content/Context;I)V
    .locals 5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->c()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object p1, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    sget-object p1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length p1, p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ge v0, p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    aget-object v1, p0, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/io/File;->isFile()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method public static i(JI)Ljava/lang/String;
    .locals 8
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "DefaultLocale"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ltz p2, :cond_4

    const/4 v7, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ltz v0, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-wide/16 v0, 0x400

    const/4 v7, 0x2

    const-wide/16 v0, 0x400

    const-wide/16 v0, 0x400

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    cmp-long v0, p0, v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x2

    and-int/2addr v6, v2

    const/4 v7, 0x4

    const-string v3, "%."

    const-string v3, "%."

    const-string v3, "%."

    const-string v3, "%."

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-gez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const-string p2, "fB"

    const-string p2, "fB"

    const/4 v7, 0x7

    const-string p2, "fB"

    const-string p2, "fB"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    long-to-double p0, p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    aput-object p0, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-wide/32 v4, 0x100000

    const-wide/32 v4, 0x100000

    const/4 v7, 0x1

    const-wide/32 v4, 0x100000

    const-wide/32 v4, 0x100000

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    cmp-long v0, p0, v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-gez v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string p2, "KBf"

    const-string p2, "fKB"

    const/4 v7, 0x4

    const-string p2, "BKf"

    const-string p2, "fKB"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    long-to-double p0, p0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v7, 0x1

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    div-double/2addr p0, v2

    const/4 v6, 0x2

    move v7, v6

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    aput-object p0, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object p0

    :cond_1
    const/4 v7, 0x2

    const-wide/32 v4, 0x40000000

    const-wide/32 v4, 0x40000000

    const/4 v7, 0x3

    const-wide/32 v4, 0x40000000

    const-wide/32 v4, 0x40000000

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    cmp-long v0, p0, v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-gez v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string p2, "BMf"

    const-string p2, "BfM"

    const/4 v7, 0x4

    const-string p2, "fMB"

    const-string p2, "fMB"

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    long-to-double p0, p0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-wide/high16 v2, 0x4130000000000000L    # 1048576.0

    const-wide/high16 v2, 0x4130000000000000L    # 1048576.0

    const/4 v7, 0x2

    const-wide/high16 v2, 0x4130000000000000L    # 1048576.0

    const-wide/high16 v2, 0x4130000000000000L    # 1048576.0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    div-double/2addr p0, v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    aput-object p0, v0, v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-object p0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const-string p2, "fGB"

    const-string p2, "fBG"

    const/4 v7, 0x6

    const-string p2, "fGB"

    const-string p2, "fGB"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    and-int/2addr v7, v6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    long-to-double p0, p0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-wide/high16 v2, 0x41d0000000000000L    # 1.073741824E9

    const-wide/high16 v2, 0x41d0000000000000L    # 1.073741824E9

    const-wide/high16 v2, 0x41d0000000000000L    # 1.073741824E9

    const-wide/high16 v2, 0x41d0000000000000L    # 1.073741824E9

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    div-double/2addr p0, v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput-object p0, v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x6

    return-object p0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string p1, "dizloS eyusb le  szt!onehtt ens/abhr/e"

    const/4 v7, 0x6

    const-string/jumbo p1, "irsSnbopele  h/tsdz!a /lnbt euseyeohzt"

    const-string p1, "byteSize shouldn\'t be less than zero!"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    throw p0

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string p1, "eesopb/t!uirtbhzosolsanns/lnd e rih  c "

    const/4 v7, 0x0

    const-string p1, "c i nzesq!tolhhp l/ roueoriesa/nsesbd n"

    const-string/jumbo p1, "precision shouldn\'t be less than zero!"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw p0
.end method

.method public static j(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x5

    const-string p0, ""

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public static k(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v0, "_data"

    const/4 v9, 0x7

    const/4 v8, 0x4

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v7, 0x0

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v6, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v9, 0x7

    const/4 v8, 0x3

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v7, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {v7}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz p0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v7, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {v7, p0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {v7}, Landroid/database/Cursor;->close()V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-object p0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v7, :cond_1

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v7}, Landroid/database/Cursor;->close()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_2

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string p1, "eisetPUtiucllurs"

    const-string/jumbo p1, "tcsltiuluFUrePie"

    const/4 v9, 0x2

    const-string p1, "UlsmtliFerePuiic"

    const-string p1, "PictureFileUtils"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string p3, "a[D_ot laa utos-tn ]e%:Cmgp"

    const-string/jumbo p3, "od l_-[ps%nmu]g tCa:aetaD t"

    const/4 v9, 0x1

    const-string p3, "-a atbnd:gsC_l ataom%eDu[]t"

    const-string p3, "getDataColumn: _data - [%s]"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v0, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v9, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    aput-object p0, v0, v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p2, p3, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x7

    if-eqz v7, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    return-object p0

    :goto_2
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v7, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v7}, Landroid/database/Cursor;->close()V

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    throw p0
.end method

.method public static l(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method public static m(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;
    .locals 7
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-static {p0, p1}, Landroid/provider/DocumentsContract;->isDocumentUri(Landroid/content/Context;Landroid/net/Uri;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v0, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->r(Landroid/net/Uri;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v3, ":"

    const-string v3, ":"

    const-string v3, ":"

    const-string v3, ":"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1}, Landroid/provider/DocumentsContract;->getDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-object v0, p1, v2

    const/4 v6, 0x5

    const-string/jumbo v1, "yqarirp"

    const/4 v6, 0x3

    const-string/jumbo v1, "maripru"

    const-string/jumbo v1, "primary"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const-string v1, "/"

    const-string v1, "/"

    const/4 v6, 0x4

    const-string v1, "/"

    const-string v1, "/"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget-object v2, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v2}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    aget-object p0, p1, v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    aget-object p1, p1, v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-object p0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->q(Landroid/net/Uri;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p1}, Landroid/provider/DocumentsContract;->getDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v0, "nbodnalptlocid:cnt//de/dlsssnopooa_w"

    const-string/jumbo v0, "tnsb/ccs_nodlpaotaodo:od/sldi/wenlwn"

    const/4 v6, 0x2

    const-string/jumbo v0, "owooilt/qcnedndcpwasa/snod:l/ublo_tn"

    const-string v0, "content://downloads/public_downloads"

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->j(Ljava/lang/Object;)J

    move-result-wide v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v2, v3}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p0, p1, v1, v1}, Lcom/luck/picture/lib/utils/k;->k(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object p0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->u(Landroid/net/Uri;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Landroid/provider/DocumentsContract;->getDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    aget-object v0, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v2, "aegmm"

    const/4 v6, 0x5

    const-string v2, "gisae"

    const-string/jumbo v2, "image"

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v1, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_0

    :cond_3
    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v2, "oedio"

    const/4 v6, 0x2

    const-string/jumbo v2, "veimo"

    const-string/jumbo v2, "video"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v2, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object v1, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "boaui"

    const/4 v6, 0x3

    const-string v2, "audio"

    const/4 v6, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    sget-object v1, Landroid/provider/MediaStore$Audio$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    :cond_5
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    aget-object p1, p1, v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v0, "_d=?o"

    const-string v0, "_id=?"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p0, v1, v0, p1}, Lcom/luck/picture/lib/utils/k;->k(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object p0

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v2, "ttouebn"

    const-string/jumbo v2, "tnentou"

    const/4 v6, 0x0

    const-string/jumbo v2, "nntctou"

    const-string v2, "content"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_8

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->t(Landroid/net/Uri;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v0, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object p0

    :cond_7
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p0, p1, v1, v1}, Lcom/luck/picture/lib/utils/k;->k(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object p0

    :cond_8
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string p0, "eifl"

    const-string p0, "flei"

    const/4 v6, 0x2

    const-string p0, "elfi"

    const-string p0, "file"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz p0, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p0

    :cond_9
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x2

    return-object p0
.end method

.method private static n(Landroid/content/Context;I)Ljava/io/File;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x2

    move v2, v0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eq p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x4

    and-int/2addr v1, v0

    const/4 v2, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p1, Landroid/os/Environment;->DIRECTORY_PICTURES:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object p1, Landroid/os/Environment;->DIRECTORY_MUSIC:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object p1, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static o(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    sget-object v0, Landroid/os/Environment;->DIRECTORY_MOVIES:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public static p(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "piabehipduoTnl"

    const-string v1, "dlViaunphTibeo"

    const/4 v3, 0x7

    const-string v1, "VideoThumbnail"

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Ljava/io/File;->separator:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0
.end method

.method public static q(Landroid/net/Uri;)Z
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    const-string/jumbo v0, "oscprvlsqoid.eanrdnrcoodnt.iwmedm.os.ouad"

    const/4 v2, 0x4

    const-string v0, "aneodrpmq.vscmuicoddwoor.ss.eoodn.anilrdd"

    const-string v0, "com.android.providers.downloads.documents"

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return p0
.end method

.method public static r(Landroid/net/Uri;)Z
    .locals 3

    const/4 v2, 0x3

    const-string/jumbo v0, "nos..dxeedgeusdoatosrnrcmmnaostic.tel"

    const-string/jumbo v0, "ilsdtstaocducaeseordean.nemox.tn.romg"

    const/4 v2, 0x6

    const-string/jumbo v0, "it.mlu.edernasgamcdcoxtrmtardon.eeson"

    const-string v0, "com.android.externalstorage.documents"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0
.end method

.method public static s(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v1, 0x5

    new-instance v0, Ljava/io/File;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p0
.end method

.method public static t(Landroid/net/Uri;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "g.siopp.dlrn.ndoeec.ootatnommhgscaopo."

    const-string/jumbo v0, "oromlgpoaieton.nopmnddas.copgshc.eo.t."

    const/4 v2, 0x7

    const-string v0, "com.google.android.apps.photos.content"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p0
.end method

.method public static u(Landroid/net/Uri;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, "amecsbumn.ca..ooid.roovdsdmdrirpdenet"

    const-string v0, "com.android.providers.media.documents"

    invoke-virtual {p0}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method

.method public static v(Landroid/content/Context;Ljava/io/File;)Landroid/net/Uri;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const-string v1, "doreiruuPk.vc"

    const-string v1, "ekPuo.ldvicrr"

    const/4 v4, 0x3

    const-string/jumbo v1, "vedi.oPpukrrl"

    const-string v1, ".luckProvider"

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v2, 0x17

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-le v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p0, v0, p1}, Landroidx/core/content/FileProvider;->f(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p0
.end method

.method public static w(Ljava/io/InputStream;Ljava/io/OutputStream;)Z
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x0

    new-instance v2, Ljava/io/BufferedInputStream;

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v2, p0}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance p0, Ljava/io/BufferedOutputStream;

    const/4 v5, 0x2

    move v6, v5

    invoke-direct {p0, p1}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/16 v1, 0x400

    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-array v1, v1, [B

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v4, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eq v3, v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1, v1, v0, v3}, Ljava/io/OutputStream;->write([BII)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x6

    const/4 p0, 0x1

    const/4 v6, 0x6

    move v5, p0

    move v5, p0

    const/4 v6, 0x5

    return p0

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    goto :goto_2

    :catchall_1
    move-exception p1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_4

    :catch_1
    move-exception p1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_2
    move-object v1, v2

    move-object v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_3

    :catchall_2
    move-exception p1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_4

    :catch_2
    move-exception p1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_3
    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    return v0

    :catchall_3
    move-exception p1

    :goto_4
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    throw p1
.end method
