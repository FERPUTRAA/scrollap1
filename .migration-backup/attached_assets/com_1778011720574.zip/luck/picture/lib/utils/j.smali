.class public Lcom/luck/picture/lib/utils/j;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "EglUtils"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private static a()I
    .locals 13
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v11, " ssd@@  uob o 1@~~M@o @ ~@@ y b~r~~ooK@~ @4cfo~@i.@t~@fi@ ~S@m~ ~~~/b ~i~@@~t~l@~ av - n~~@l /@@"

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x1

    invoke-static {}, Ljavax/microedition/khronos/egl/EGLContext;->getEGL()Ljavax/microedition/khronos/egl/EGL;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    check-cast v0, Ljavax/microedition/khronos/egl/EGL10;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_DEFAULT_DISPLAY:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-interface {v0, v1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetDisplay(Ljava/lang/Object;)Ljavax/microedition/khronos/egl/EGLDisplay;

    move-result-object v7

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v1, 0x2

    move v12, v1

    const/4 v11, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    new-array v1, v1, [I

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {v0, v7, v1}, Ljavax/microedition/khronos/egl/EGL10;->eglInitialize(Ljavax/microedition/khronos/egl/EGLDisplay;[I)Z

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    const/4 v1, 0x7

    const/4 v12, 0x1

    new-array v3, v1, [I

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    fill-array-data v3, :array_0

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v8, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    new-array v9, v8, [Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    new-array v10, v8, [I

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v5, 0x0

    const/4 v5, 0x1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, v7

    move-object v2, v7

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v6, v10

    move-object v6, v10

    move-object v6, v10

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-interface/range {v1 .. v6}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/4 v1, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    aget v2, v10, v1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-nez v2, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    return v1

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    aget-object v2, v9, v1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/16 v3, 0x3057

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/16 v4, 0x3056

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/16 v5, 0x40

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/16 v6, 0x3038

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    filled-new-array {v3, v5, v4, v5, v6}, [I

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x4

    invoke-interface {v0, v7, v2, v3}, Ljavax/microedition/khronos/egl/EGL10;->eglCreatePbufferSurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;[I)Ljavax/microedition/khronos/egl/EGLSurface;

    move-result-object v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/16 v4, 0x3098

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    filled-new-array {v4, v8, v6}, [I

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    sget-object v5, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-interface {v0, v7, v2, v5, v4}, Ljavax/microedition/khronos/egl/EGL10;->eglCreateContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;Ljavax/microedition/khronos/egl/EGLContext;[I)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object v2

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-interface {v0, v7, v3, v3, v2}, Ljavax/microedition/khronos/egl/EGL10;->eglMakeCurrent(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLContext;)Z

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-array v4, v8, [I

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/16 v5, 0xd33

    const/4 v12, 0x7

    const/4 v11, 0x4

    invoke-static {v5, v4, v1}, Landroid/opengl/GLES10;->glGetIntegerv(I[II)V

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    sget-object v5, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v12, 0x5

    sget-object v6, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface {v0, v7, v5, v5, v6}, Ljavax/microedition/khronos/egl/EGL10;->eglMakeCurrent(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLContext;)Z

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-interface {v0, v7, v3}, Ljavax/microedition/khronos/egl/EGL10;->eglDestroySurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;)Z

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v0, v7, v2}, Ljavax/microedition/khronos/egl/EGL10;->eglDestroyContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLContext;)Z

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-interface {v0, v7}, Ljavax/microedition/khronos/egl/EGL10;->eglTerminate(Ljavax/microedition/khronos/egl/EGLDisplay;)Z

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    aget v0, v4, v1

    const/4 v12, 0x3

    return v0

    :array_0
    .array-data 4
        0x303f
        0x308e
        0x3029
        0x0
        0x3033
        0x1
        0x3038
    .end array-data
.end method

.method private static b()I
    .locals 15
    .annotation build Landroid/annotation/TargetApi;
        value = 0x11
    .end annotation

    const/4 v14, 0x3

    const/4 v0, 0x0

    const/4 v14, 0x6

    invoke-static {v0}, Landroid/opengl/EGL14;->eglGetDisplay(I)Landroid/opengl/EGLDisplay;

    move-result-object v9

    const/4 v14, 0x3

    const/4 v10, 0x2

    const/4 v14, 0x0

    new-array v1, v10, [I

    const/4 v14, 0x6

    const/4 v11, 0x1

    const/4 v14, 0x0

    invoke-static {v9, v1, v0, v1, v11}, Landroid/opengl/EGL14;->eglInitialize(Landroid/opengl/EGLDisplay;[II[II)Z

    const/4 v14, 0x2

    const/16 v1, 0x9

    const/4 v14, 0x7

    new-array v2, v1, [I

    const/4 v14, 0x4

    fill-array-data v2, :array_0

    new-array v12, v11, [Landroid/opengl/EGLConfig;

    const/4 v14, 0x6

    new-array v13, v11, [I

    const/4 v14, 0x5

    const/4 v3, 0x0

    const/4 v14, 0x5

    const/4 v5, 0x0

    const/4 v14, 0x0

    const/4 v6, 0x1

    const/4 v14, 0x1

    const/4 v8, 0x0

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v4, v12

    move-object v4, v12

    move-object v4, v12

    move-object v7, v13

    move-object v7, v13

    move-object v7, v13

    move-object v7, v13

    const/4 v14, 0x5

    invoke-static/range {v1 .. v8}, Landroid/opengl/EGL14;->eglChooseConfig(Landroid/opengl/EGLDisplay;[II[Landroid/opengl/EGLConfig;II[II)Z

    const/4 v14, 0x6

    aget v1, v13, v0

    const/4 v14, 0x4

    if-nez v1, :cond_0

    const/4 v14, 0x5

    return v0

    :cond_0
    const/4 v14, 0x4

    aget-object v1, v12, v0

    const/16 v2, 0x3057

    const/4 v14, 0x7

    const/16 v3, 0x3056

    const/4 v14, 0x6

    const/16 v4, 0x40

    const/4 v14, 0x0

    const/16 v5, 0x3038

    const/4 v14, 0x2

    filled-new-array {v2, v4, v3, v4, v5}, [I

    move-result-object v2

    const/4 v14, 0x5

    invoke-static {v9, v1, v2, v0}, Landroid/opengl/EGL14;->eglCreatePbufferSurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;[II)Landroid/opengl/EGLSurface;

    move-result-object v2

    const/4 v14, 0x1

    const/16 v3, 0x3098

    const/4 v14, 0x3

    filled-new-array {v3, v10, v5}, [I

    move-result-object v3

    const/4 v14, 0x5

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v14, 0x1

    invoke-static {v9, v1, v4, v3, v0}, Landroid/opengl/EGL14;->eglCreateContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Landroid/opengl/EGLContext;[II)Landroid/opengl/EGLContext;

    move-result-object v1

    const/4 v14, 0x3

    invoke-static {v9, v2, v2, v1}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    const/4 v14, 0x4

    new-array v3, v11, [I

    const/4 v14, 0x5

    const/16 v4, 0xd33

    const/4 v14, 0x7

    invoke-static {v4, v3, v0}, Landroid/opengl/GLES20;->glGetIntegerv(I[II)V

    sget-object v4, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v14, 0x2

    sget-object v5, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v14, 0x5

    invoke-static {v9, v4, v4, v5}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    const/4 v14, 0x1

    invoke-static {v9, v2}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    const/4 v14, 0x4

    invoke-static {v9, v1}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    const/4 v14, 0x1

    invoke-static {v9}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    const/4 v14, 0x2

    aget v0, v3, v0

    const/4 v14, 0x5

    return v0

    :array_0
    .array-data 4
        0x303f
        0x308e
        0x3029
        0x0
        0x3040
        0x4
        0x3033
        0x1
        0x3038
    .end array-data
.end method

.method public static c()I
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/j;->b()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v0

    :catch_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "giEmtlUs"

    const-string/jumbo v1, "lEsgtiUs"

    const/4 v4, 0x0

    const-string v1, "EglUtils"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v2, "xM mSatexeirteuzge:"

    const/4 v4, 0x7

    const-string/jumbo v2, "r:uMoexzxteeSTaigt "

    const-string v2, "getMaxTextureSize: "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    return v0
.end method
