.class public Lcom/luck/picture/lib/utils/f;
.super Ljava/lang/Object;


# static fields
.field private static final a:J = 0x258L

.field private static b:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Z
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "vasf~@f~b@ @~1@@.o ~ / ~@ bi~@ o~@@~ l~@@4oo  s  ~@o@~K@l i~ ~@ @~@ ~i/yb@r~~u@~n~ ~~mtSc- td~M@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-wide v2, Lcom/luck/picture/lib/utils/f;->b:J

    const/4 v7, 0x2

    sub-long v2, v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-wide/16 v4, 0x258

    const-wide/16 v4, 0x258

    const/4 v7, 0x3

    const-wide/16 v4, 0x258

    const-wide/16 v4, 0x258

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-gez v2, :cond_0

    const/4 v7, 0x0

    const/4 v0, 0x7

    const/4 v7, 0x4

    const/4 v0, 0x1

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    return v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    sput-wide v0, Lcom/luck/picture/lib/utils/f;->b:J

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    return v0
.end method
