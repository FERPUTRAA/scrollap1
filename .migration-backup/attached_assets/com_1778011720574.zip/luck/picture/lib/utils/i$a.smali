.class Lcom/luck/picture/lib/utils/i$a;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/utils/i;->f(Landroid/content/Context;Ljava/lang/String;Ls6/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Lcom/luck/picture/lib/entity/b;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic o:Landroid/content/Context;

.field final synthetic p:Ljava/lang/String;

.field final synthetic q:Ls6/c;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ls6/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/utils/i$a;->o:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/utils/i$a;->p:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    iput-object p3, p0, Lcom/luck/picture/lib/utils/i$a;->q:Ls6/c;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "i4s@l @bo~~@1~o/t~a. o@i@~@S/buK~~@-@@~Mf~ @y   rfo@o~ lm@ ~b@~dc   v i~~@~n~@ @ @@~~ ~@o~t@~ ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/utils/i$a;->r()Lcom/luck/picture/lib/entity/b;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    check-cast p1, Lcom/luck/picture/lib/entity/b;

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/utils/i$a;->s(Lcom/luck/picture/lib/entity/b;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public r()Lcom/luck/picture/lib/entity/b;
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/utils/i$a;->o:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/utils/i$a;->p:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/i;->p(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public s(Lcom/luck/picture/lib/entity/b;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/utils/i$a;->q:Ls6/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ls6/c;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
