.class public Lcom/luck/picture/lib/utils/i;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "android:query-arg-sql-limit"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Ljava/lang/String;[Ljava/lang/String;IILjava/lang/String;)Landroid/os/Bundle;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~sa~ @S1b~/ ~ i~~~b~- ~uno@    c  @@@os @b~@/i@~~ol@@ ~M@@@mo@ o~@~f~vr~@of~t @@ ~.t4l~diy~@@~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 v2, 0x1a

    const/4 v4, 0x0

    const/4 v3, 0x1

    if-lt v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "sqrmnnecodtoll-eue:asi-rdrgsi-a"

    const-string/jumbo v1, "srseo-le-uydio:-eqliatrngadrcsn"

    const/4 v4, 0x5

    const-string/jumbo v1, "uin-oes-r:aqsieorqltagdyreloc-d"

    const-string v1, "android:query-arg-sql-selection"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo p0, "rqd:sbolia--ym-deerri-troaesnqanugls"

    const-string p0, "crymr-steosoadne--ianguaiqq:slerrdl-"

    const/4 v4, 0x2

    const-string/jumbo p0, "oaosirue:uiqcss-l-dag-d-gylrqretearn"

    const-string p0, "android:query-arg-sql-selection-args"

    invoke-virtual {v0, p0, p1}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo p0, "orldronpydrrgoesi:qdqr-auetao---"

    const-string p0, "gru-osdeyrodtonea:r--qo-dlrqrira"

    const/4 v4, 0x3

    const-string/jumbo p0, "osrarruqq-d-dodirsgorye-lnreta:q"

    const-string p0, "android:query-arg-sql-sort-order"

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p0, p4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const-string p1, "best off"

    const-string p1, "efo  bft"

    const/4 v4, 0x7

    const-string/jumbo p1, "tfoms fe"

    const-string p1, " offset "

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const-string/jumbo p1, "rlq-odimerysnou-:dgtiarl-ui"

    const-string p1, "gldtqaumdliror-yui-es:-nqir"

    const/4 v4, 0x2

    const-string/jumbo p1, "siqidb-a-l-ltqrd:ernomgiray"

    const-string p1, "android:query-arg-sql-limit"

    invoke-virtual {v0, p1, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0, v0}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)J
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/i;->i(Landroid/content/Context;Ljava/lang/String;)J

    move-result-wide p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p2, :cond_1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    int-to-long p0, p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    goto :goto_0

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/i;->i(Landroid/content/Context;Ljava/lang/String;)J

    move-result-wide p0

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-wide p0
.end method

.method public static d(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Ljava/io/File;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const-string/jumbo p0, "urapae"

    const-string p0, "Cpreaa"

    const/4 v2, 0x6

    const-string p0, "Cpraae"

    const-string p0, "Camera"

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method public static e(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)J
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/i;->i(Landroid/content/Context;Ljava/lang/String;)J

    move-result-wide p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    int-to-long p0, p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    goto :goto_0

    :cond_1
    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/utils/i;->i(Landroid/content/Context;Ljava/lang/String;)J

    move-result-wide p0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-wide p0
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;Ls6/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ls6/c<",
            "Lcom/luck/picture/lib/entity/b;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    new-instance v0, Lcom/luck/picture/lib/utils/i$a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1, p2}, Lcom/luck/picture/lib/utils/i$a;-><init>(Landroid/content/Context;Ljava/lang/String;Ls6/c;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    return-void
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Lcom/luck/picture/lib/entity/b;

    const/4 v4, 0x4

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/b;-><init>()V

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Landroid/media/MediaMetadataRetriever;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1}, Landroid/media/MediaMetadataRetriever;-><init>()V

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, p0, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 p0, 0x9

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, p0}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/utils/t;->j(Ljava/lang/Object;)J

    move-result-wide p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, p0, p1}, Lcom/luck/picture/lib/entity/b;->f(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_2

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0

    :goto_2
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p0
.end method

.method public static h(Landroid/content/Context;Ljava/lang/String;)I
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string v0, "%"

    const-string v0, "%"

    const/4 v11, 0x6

    const-string v0, "%"

    const-string v0, "%"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v1, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v2, 0x0

    move v11, v2

    :try_start_0
    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v6, "_al? ie qakd"

    const-string/jumbo v6, "k ea _a?qldi"

    const/4 v11, 0x7

    const-string v6, "d siltk_e?aa"

    const-string v6, "_data like ?"

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v9, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-array v7, v9, [Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v0, 0x0

    const/4 v11, 0x1

    aput-object p1, v7, v0

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result p1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz p1, :cond_0

    const/4 v10, 0x1

    const-string p1, "DSdm_C E"

    const-string p1, "CEs_ DdS"

    const/4 v11, 0x4

    const-string p1, " ESioD_d"

    const-string p1, "_id DESC"

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {v6, v7, v9, v0, p1}, Lcom/luck/picture/lib/utils/i;->a(Ljava/lang/String;[Ljava/lang/String;IILjava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v0, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {p0, v0, v2, p1, v2}, Lcom/luck/picture/lib/loader/c;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Landroid/os/Bundle;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-string v8, "DfmltbiSos_e i   Cdt 01iE"

    const-string v8, "_id DESC limit 1 offset 0"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x7

    sget-object v4, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/4 v5, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual/range {v3 .. v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    :goto_0
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-eqz v2, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-interface {v2}, Landroid/database/Cursor;->getCount()I

    move-result p0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-lez p0, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz p0, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string p0, "_id"

    const-string p0, "_di"

    const/4 v11, 0x2

    const-string p0, "id_"

    const-string p0, "_id"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v2, p0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-interface {v2, p0}, Landroid/database/Cursor;->getInt(I)I

    move-result p0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string p1, "dedm_tdaed"

    const/4 v11, 0x6

    const-string p1, "ddteaeu_da"

    const-string p1, "date_added"

    const/4 v10, 0x3

    xor-int/2addr v11, v10

    invoke-interface {v2, p1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-interface {v2, p1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v3

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v3, v4}, Lcom/luck/picture/lib/utils/d;->b(J)I

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-gt p1, v9, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    move v1, p0

    move v1, p0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    const/4 v10, 0x3

    move v11, v10

    return v1

    :cond_2
    const/4 v10, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v2, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    return v1

    :catchall_0
    move-exception p0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    goto :goto_1

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v2, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    return v1

    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x6

    if-eqz v2, :cond_5

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_5
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    throw p0
.end method

.method public static i(Landroid/content/Context;Ljava/lang/String;)J
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v0, "%"

    const-string v0, "%"

    const/4 v9, 0x2

    const-string v0, "%"

    const-string v0, "%"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string v5, "ei ? koplaad"

    const-string v5, " ltaoke da?i"

    const/4 v9, 0x0

    const-string v5, "e_a  dtaq?lk"

    const-string v5, "_data like ?"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-array v6, v2, [Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    aput-object p1, v6, v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v3, "lesrnxta"

    const-string v3, "external"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz p1, :cond_0

    :try_start_1
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string p1, "Ed_S biC"

    const/4 v9, 0x1

    const-string p1, "dEDmi_ C"

    const-string p1, "_id DESC"

    const/4 v9, 0x1

    invoke-static {v5, v6, v2, v0, p1}, Lcom/luck/picture/lib/utils/i;->a(Ljava/lang/String;[Ljava/lang/String;IILjava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v3}, Landroid/provider/MediaStore$Files;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {p0, v0, v1, p1, v1}, Lcom/luck/picture/lib/loader/c;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Landroid/os/Bundle;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v7, "i1d_oiCltitme0u fofs SED "

    const-string/jumbo v7, "smittiu_f o1elDSif   0CdE"

    const/4 v9, 0x1

    const-string/jumbo v7, "iftStbm Ed s1 olfCiD  e_i"

    const-string v7, "_id DESC limit 1 offset 0"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v3}, Landroid/provider/MediaStore$Files;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual/range {v2 .. v7}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p0

    :goto_0
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result p0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-lez p0, :cond_1

    const/4 v9, 0x4

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz p0, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string p0, "icpkbtu_u"

    const-string/jumbo p0, "ktcibd_pu"

    const/4 v9, 0x5

    const-string/jumbo p0, "udtc_bipk"

    const-string p0, "bucket_id"

    const/4 v9, 0x5

    const/4 v8, 0x0

    invoke-interface {v1, p0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-interface {v1, p0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    return-wide p0

    :cond_1
    const/4 v9, 0x1

    if-eqz v1, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_2

    :catch_0
    move-exception p0

    :try_start_2
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v1, :cond_2

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_2
    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    const-wide/16 p0, -0x1

    const-wide/16 p0, -0x1

    const/4 v9, 0x1

    const-wide/16 p0, -0x1

    const-wide/16 p0, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    return-wide p0

    :goto_2
    const/4 v9, 0x6

    if-eqz v1, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x4

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    throw p0
.end method

.method public static j(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Lcom/luck/picture/lib/entity/b;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/b;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    xor-int/2addr v5, v1

    :try_start_0
    const/4 v4, 0x2

    const/4 v4, 0x6

    new-instance v2, Landroid/graphics/BitmapFactory$Options;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-boolean v3, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p0, p1}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p0, Ljava/io/FileInputStream;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :goto_0
    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p0, v1, v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget p1, v2, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/b;->j(I)V

    const/4 v5, 0x0

    iget p1, v2, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/b;->g(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_2

    :catchall_0
    move-exception p1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_3

    :catch_0
    move-exception p1

    move-object v1, p0

    move-object v1, p0

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_3

    :catch_1
    move-exception p0

    :goto_1
    :try_start_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    :goto_2
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object v0

    :goto_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    throw p0
.end method

.method public static k(Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;
    .locals 7
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v0, Lcom/luck/picture/lib/entity/b;

    const/4 v6, 0x5

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/b;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    new-instance v2, Landroid/graphics/BitmapFactory$Options;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v2}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-boolean v3, v2, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lo6/b;->d()Lo6/b;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3}, Lo6/b;->b()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3, p0}, Lcom/luck/picture/lib/basic/f;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    new-instance v3, Ljava/io/FileInputStream;

    const/4 v6, 0x2

    invoke-direct {v3, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object p0, v3

    move-object p0, v3

    :goto_0
    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p0, v1, v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v1, v2, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/b;->j(I)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget v1, v2, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/b;->g(I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_2

    :catchall_0
    move-exception v0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_3

    :catch_0
    move-exception v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object p0, v4

    move-object p0, v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_3

    :catch_1
    move-exception p0

    :goto_1
    :try_start_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object v0

    :goto_3
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    throw p0
.end method

.method private static l(Ljava/io/File;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Ljava/net/URLConnection;->getFileNameMap()Ljava/net/FileNameMap;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Ljava/net/FileNameMap;->getContentTypeFor(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public static m(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0}, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/i;->l(Ljava/io/File;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v0, "e/mjagipqg"

    const-string/jumbo v0, "mjpggi/eqa"

    const/4 v3, 0x2

    const-string v0, "gisajpge/e"

    const-string/jumbo v0, "image/jpeg"

    :cond_1
    const/4 v3, 0x3

    return-object v0
.end method

.method public static n(JLjava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->g(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    sget-object p2, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object p2, Landroid/provider/MediaStore$Video$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p2, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object p2, Landroid/provider/MediaStore$Audio$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p2, "esxmrnae"

    const-string p2, "ensearlx"

    const/4 v2, 0x5

    const-string/jumbo p2, "lnetorex"

    const-string p2, "external"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2}, Landroid/provider/MediaStore$Files;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p2, p0, p1}, Landroid/content/ContentUris;->withAppendedId(Landroid/net/Uri;J)Landroid/net/Uri;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static o(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x3

    new-instance v0, Lcom/luck/picture/lib/entity/b;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/b;-><init>()V

    const/4 v5, 0x3

    move v6, v5

    new-instance v1, Landroid/media/MediaMetadataRetriever;

    const/4 v6, 0x4

    invoke-direct {v1}, Landroid/media/MediaMetadataRetriever;-><init>()V

    :try_start_0
    const/4 v6, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, p0, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/16 p0, 0x18

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string p1, "09"

    const-string p1, "09"

    const/4 v6, 0x3

    const-string p1, "90"

    const-string p1, "90"

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/16 v2, 0x13

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/16 v3, 0x12

    const/4 v6, 0x1

    if-nez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string p1, "072"

    const-string p1, "027"

    const/4 v6, 0x7

    const-string p1, "702"

    const-string p1, "270"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p1, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz p1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/utils/t;->h(Ljava/lang/Object;)I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    move v4, v2

    move v4, v2

    const/4 v6, 0x4

    move v4, v2

    move v4, v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v2, p1

    move v2, p1

    const/4 v6, 0x6

    move v2, p1

    move v2, p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    move p1, v4

    move p1, v4

    const/4 v6, 0x7

    move p1, v4

    move p1, v4

    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/b;->j(I)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Lcom/luck/picture/lib/entity/b;->g(I)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, p0}, Lcom/luck/picture/lib/entity/b;->h(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/16 p0, 0x9

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Landroid/media/MediaMetadataRetriever;->extractMetadata(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/t;->j(Ljava/lang/Object;)J

    move-result-wide p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, p0, p1}, Lcom/luck/picture/lib/entity/b;->f(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_3

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_4

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v0

    :goto_4
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/media/MediaMetadataRetriever;->release()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    throw p0
.end method

.method public static p(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/b;
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x3

    new-instance v0, Lcom/luck/picture/lib/entity/b;

    const/4 v7, 0x3

    move v8, v7

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/b;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v1, 0x0

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v2, Landroid/media/MediaMetadataRetriever;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {v2}, Landroid/media/MediaMetadataRetriever;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/config/f;->c(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz v3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v2, p0, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Landroid/content/Context;Landroid/net/Uri;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v2, p1}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2}, Landroid/media/MediaMetadataRetriever;->getFrameAtTime()Landroid/graphics/Bitmap;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v8, 0x6

    const/4 v7, 0x7

    if-eqz p1, :cond_1

    :try_start_1
    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v2, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x5

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x5

    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v8, 0x3

    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/16 v4, 0x32

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p1, v3, v4, v2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->p(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance v3, Ljava/io/File;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const-string v5, "div_"

    const-string/jumbo v5, "vid_"

    const/4 v8, 0x7

    invoke-static {v5}, Lcom/luck/picture/lib/utils/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string v5, "ghjubb.p_m"

    const-string v5, "_thumb.jpg"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v3, p0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance p0, Ljava/io/FileOutputStream;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {p0, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0, v1}, Ljava/io/FileOutputStream;->write([B)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Ljava/io/OutputStream;->flush()V

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/b;->i(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/b;->j(I)V

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/b;->g(I)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move-object v1, v2

    move-object v1, v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto/16 :goto_4

    :catch_0
    move-exception v1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto/16 :goto_2

    :catchall_1
    move-exception p0

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto/16 :goto_4

    :catch_1
    move-exception p0

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object v2, p1

    move-object v2, p1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_4

    :catch_2
    move-exception p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_2

    :cond_1
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v7, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {p0}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz p1, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez p0, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_3

    :catchall_3
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_4

    :catch_3
    move-exception p0

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_2
    :try_start_4
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v2, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-nez p0, :cond_2

    const/4 v7, 0x4

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    :cond_2
    :goto_3
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object v0

    :catchall_4
    move-exception p0

    :goto_4
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/k;->a(Ljava/io/Closeable;)V

    const/4 v8, 0x4

    if-eqz v2, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-nez p1, :cond_3

    const/4 v8, 0x6

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    throw p0
.end method

.method public static q(II)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-lez p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-gtz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    mul-int/lit8 p0, p0, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-le p1, p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public static r(Landroid/content/Context;I)V
    .locals 7

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    sget-object v0, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v1, "?u_=m"

    const-string v1, "_?=mi"

    const/4 v6, 0x7

    const-string v1, "d=pi?"

    const-string v1, "_id=?"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x1

    shr-int/2addr v6, v2

    const/4 v5, 0x0

    move v6, v5

    new-array v2, v2, [Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    int-to-long v3, p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    aput-object p1, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0, v0, v1, v2}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method
