.class Lcom/luck/picture/lib/c$l;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->l2(Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/ArrayList;

.field final synthetic b:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/c$l;->b:Lcom/luck/picture/lib/c;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/luck/picture/lib/c$l;->a:Ljava/util/ArrayList;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s@~@ ~y  ~@f@l~of~ @@~ udo@4S@@t~ st~ a@~~i@~~@o.b@~Mi@-onco~~@ lb ~b@mK~ v@i~~   /@~o@/~ r 1~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/luck/picture/lib/c$l;->b:Lcom/luck/picture/lib/c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/c$l;->a:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/luck/picture/lib/c;->D1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method
