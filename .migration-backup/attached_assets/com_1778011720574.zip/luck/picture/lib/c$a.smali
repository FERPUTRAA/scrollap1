.class Lcom/luck/picture/lib/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->u()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ls6/n<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/c$a;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~~~n~os~M ~@d o ify@@r~ @@1@@K~ @/lu @S @~o@o.~ b aco@~fov ~ib~@ @~b/@-ti~@ ~@   ~@m@~lt4~@~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$a;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/luck/picture/lib/c;->q1(Lcom/luck/picture/lib/c;Ljava/util/List;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method
