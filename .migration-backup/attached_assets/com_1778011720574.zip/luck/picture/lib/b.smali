.class public Lcom/luck/picture/lib/b;
.super Lcom/luck/picture/lib/basic/e;


# static fields
.field public static final l:Ljava/lang/String; = "b"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/e;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-void
.end method

.method public static W0()Lcom/luck/picture/lib/b;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s/s@o@@y~@b~  i~4@f ti~~r l~@ ovoc~tK@ ~ 1 l~M-@o@ @ @~a~ i ~@~@@oS~ n~m b@~u @f~ .~b~o@/@d ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/luck/picture/lib/b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public B0()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/luck/picture/lib/b;->l:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method public D(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public c([Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p0, p1}, Ls6/k;->b(Landroidx/fragment/app/Fragment;[Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1}, Lu6/a;->c(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lu6/a;->f(Landroid/content/Context;)Z

    move-result p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    goto :goto_2

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1}, Lu6/a;->c(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_camera:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Lu6/a;->f(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p1, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$string;->ps_jurisdiction:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    :cond_4
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget v0, Lcom/luck/picture/lib/R$layout;->ps_empty:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/luck/picture/lib/basic/e;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v1, 0x6

    if-nez p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :cond_0
    const/4 v1, 0x6

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/basic/e;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lu6/a;->b()Lu6/a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p2, Lu6/b;->c:[Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/luck/picture/lib/b$a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/b$a;-><init>(Lcom/luck/picture/lib/b;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, p0, p2, v0}, Lu6/a;->j(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Lu6/c;)V

    :goto_0
    const/4 v2, 0x3

    return-void
.end method
