.class public final Lcom/luck/picture/lib/loader/d;
.super Lcom/luck/picture/lib/loader/a;


# static fields
.field private static final p:[Ljava/lang/String;

.field private static final q:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v0, "nyssskaeeapb__cmtld"

    const-string/jumbo v0, "y_seb_aunetpmslckad"

    const/4 v8, 0x0

    const-string v0, "eikmdtm_nlcey_pasua"

    const-string v0, "bucket_display_name"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const-string/jumbo v1, "mpiyot_mm"

    const-string v1, "e_mmtiymp"

    const-string/jumbo v1, "iet_mbmyp"

    const-string/jumbo v1, "mime_type"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v2, "id_"

    const-string v2, "d_i"

    const/4 v8, 0x1

    const-string v2, "_di"

    const-string v2, "_id"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string v3, "de_ukiubc"

    const-string v3, "bucket_id"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    sput-object v0, Lcom/luck/picture/lib/loader/d;->p:[Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v1, "d_i"

    const-string v1, "d_i"

    const-string v1, "_id"

    const-string v1, "_id"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v2, "tapad"

    const-string/jumbo v2, "tadao"

    const/4 v8, 0x2

    const-string v2, "da_qa"

    const-string v2, "_data"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string v3, "bdstbkuie"

    const-string/jumbo v3, "idek_butb"

    const-string/jumbo v3, "kcem_bdui"

    const-string v3, "bucket_id"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v4, "y_deoiupnb_kltacmeu"

    const-string/jumbo v4, "tcnlisubkupd_yeame_"

    const/4 v8, 0x3

    const-string v4, "asdyibk_pb_mucantee"

    const-string v4, "bucket_display_name"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string/jumbo v5, "ypempeuti"

    const-string/jumbo v5, "pmtieeypm"

    const/4 v8, 0x4

    const-string/jumbo v5, "memiy_tpp"

    const-string/jumbo v5, "mime_type"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v6, "Tu()NUScqO*  tnAC"

    const/4 v8, 0x6

    const-string/jumbo v6, "n Nu(O AqTctoUSC)"

    const-string v6, "COUNT(*) AS count"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    sput-object v0, Lcom/luck/picture/lib/loader/d;->q:[Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/a;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private A(J)[Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ so~ocdbt bf@~M~-@ @ @~~o~@~ 4/@ ~ i~@r@o~~m~.~/ obn~u  @ ~ @@ ifS@@~l@ ~y~ ~s@@ v@l~K ~o~a1@@t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v5, 0x4

    move v6, v5

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq v0, v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq v0, v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2, p1, p2}, Lcom/luck/picture/lib/loader/d;->K(IJ)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    return-object p1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v1, p1, p2}, Lcom/luck/picture/lib/loader/d;->K(IJ)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-object p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-static {v2, p1, p2}, Lcom/luck/picture/lib/loader/d;->K(IJ)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    return-object p1

    :cond_3
    const/4 v6, 0x7

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x5

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    cmp-long v0, p1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez v0, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x7

    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object p1

    :cond_4
    const/4 v6, 0x1

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    filled-new-array {v0, v1, p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object p1
.end method

.method private static B(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v1, "("

    const-string v1, "("

    const/4 v4, 0x3

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const-string v1, "diamsy_mtp"

    const-string v1, "_tspmdyiea"

    const-string v1, "edt_oemipy"

    const-string/jumbo v1, "media_type"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, "=?"

    const-string v2, "=?"

    const/4 v4, 0x5

    const-string v2, "?="

    const-string v2, "=?"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string p2, " RO "

    const/4 v4, 0x6

    const-string p2, " OR "

    const-string p2, " OR "

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    const-string p2, "NDAm= ?"

    const/4 v4, 0x0

    const-string p2, "D? = bN"

    const-string p2, "=? AND "

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p3, "u AD o"

    const-string p3, " ADNo "

    const/4 v4, 0x2

    const-string p3, " p)D N"

    const-string p3, ") AND "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    cmp-long p0, p0, v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo p0, "itdk_bebq"

    const-string p0, "ceki_bbdt"

    const/4 v4, 0x1

    const-string p0, "bucket_id"

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0
.end method

.method private static C(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x7

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const-string/jumbo v1, "pdsey_itau"

    const-string v1, "_tiepeuyad"

    const-string/jumbo v1, "yadmeip_te"

    const-string/jumbo v1, "media_type"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const-string v1, "?="

    const-string v1, "=?"

    const-string v1, "=?"

    const-string v1, "=?"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p2, "AN Do"

    const-string p2, "DNp A"

    const/4 v3, 0x1

    const-string p2, "bN  A"

    const-string p2, " AND "

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo p2, "uNDA  "

    const-string p2, "  qNAD"

    const/4 v3, 0x4

    const-string p2, "Np AD "

    const-string p2, ") AND "

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v3, 0x5

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v3, 0x5

    cmp-long p0, p0, p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x5

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const-string p0, "bsikcdutq"

    const-string p0, "edstbicuk"

    const/4 v3, 0x1

    const-string/jumbo p0, "t_seubidc"

    const-string p0, "bucket_id"

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const-string/jumbo p0, "m AmD ="

    const-string p0, "=A?m  D"

    const/4 v3, 0x2

    const-string p0, "?=NDo A"

    const-string p0, "=? AND "

    const/4 v2, 0x7

    or-int/2addr v3, v2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method private static D(JLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, "("

    const-string v1, "("

    const/4 v4, 0x0

    const-string v1, "("

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, "iadpmb_oet"

    const-string v1, "amd_opytie"

    const-string v1, "epmdetuai_"

    const-string/jumbo v1, "media_type"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const-string v1, "?="

    const-string v1, "?="

    const/4 v4, 0x3

    const-string v1, "=?"

    const-string v1, "=?"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    cmp-long p0, p0, v1

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string p1, " pNb) "

    const-string p1, ") ND b"

    const/4 v4, 0x4

    const-string p1, "D qN) "

    const-string p1, ") AND "

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p0, "dkstu_cbe"

    const-string/jumbo p0, "kbdetcuu_"

    const/4 v4, 0x5

    const-string p0, "ec_mduibt"

    const-string p0, "bucket_id"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo p0, "p?A=D  "

    const/4 v4, 0x3

    const-string p0, "A?D=oN "

    const-string p0, "=? AND "

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p0
.end method

.method private static E(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x0

    const-string v1, "("

    const-string v1, "("

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "_tpadbemiq"

    const-string v1, "aie_pmytqd"

    const/4 v3, 0x3

    const-string/jumbo v1, "typeimueda"

    const-string/jumbo v1, "media_type"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    const-string v1, "=?"

    const-string v1, "=?"

    const/4 v3, 0x6

    const-string v1, "=?"

    const-string v1, "=?"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string p2, "N p A"

    const-string p2, "NAs  "

    const/4 v3, 0x7

    const-string p2, " ADq "

    const-string p2, " AND "

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p2, " DsA)N"

    const-string p2, "D) mNA"

    const/4 v3, 0x7

    const-string p2, "D NmA)"

    const-string p2, ") AND "

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v3, 0x4

    const-wide/16 p2, -0x1

    const-wide/16 p2, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    cmp-long p0, p0, p2

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string/jumbo p0, "iu_oobeck"

    const-string p0, "_ictobeuk"

    const/4 v3, 0x7

    const-string/jumbo p0, "kictubebd"

    const-string p0, "bucket_id"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string p0, "Db=N ?u"

    const-string p0, " DN?=b "

    const/4 v3, 0x2

    const-string/jumbo p0, "pD?= AN"

    const-string p0, "=? AND "

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p0
.end method

.method private F()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    iget v3, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v3, :cond_3

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v3, v4, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v1, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eq v3, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eq v3, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x0

    return-object v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v2}, Lcom/luck/picture/lib/loader/d;->I(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object v0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v2}, Lcom/luck/picture/lib/loader/d;->L(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object v0

    :cond_2
    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/luck/picture/lib/loader/d;->J(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object v0

    :cond_3
    const/4 v6, 0x3

    invoke-static {v0, v1, v2}, Lcom/luck/picture/lib/loader/d;->H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object v0
.end method

.method private G()[Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq v0, v2, :cond_1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x2

    invoke-static {v2}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/luck/picture/lib/loader/a;->e()[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v0
.end method

.method private static H(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "("

    const-string v1, "("

    const/4 v4, 0x2

    const-string v1, "("

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "metd_puaey"

    const/4 v4, 0x3

    const-string/jumbo v1, "media_type"

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "?="

    const/4 v4, 0x7

    const-string v2, "?="

    const-string v2, "=?"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p2, " R O"

    const-string p2, " OR "

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p2, "?qNp=AD"

    const-string/jumbo p2, "pN=A ?D"

    const/4 v4, 0x0

    const-string p2, "A=sN ? "

    const-string p2, "=? AND "

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const-string p0, "AN)mqD"

    const-string p0, " Aq)DN"

    const/4 v4, 0x0

    const-string p0, "D NAo "

    const-string p0, ") AND "

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string p0, ")"

    const/4 v4, 0x1

    const-string p0, ")"

    const-string p0, ")"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string p0, "Bc_eib(PkdORsG ub tY"

    const-string p0, "dOsuBPR _keUti(G bYc"

    const/4 v4, 0x1

    const-string/jumbo p0, "u(diUYuPbtB_k  OGR e"

    const-string p0, " GROUP BY (bucket_id"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0
.end method

.method private static I(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v2, "?="

    const-string v2, "?="

    const/4 v5, 0x5

    const-string v2, "=?"

    const-string v2, "=?"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v3, "tdem_eaipm"

    const/4 v5, 0x1

    const-string v3, "eypdi_mpet"

    const-string/jumbo v3, "media_type"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string p1, " NDqo"

    const-string p1, "  NDo"

    const/4 v5, 0x4

    const-string p1, " DsAN"

    const-string p1, " AND "

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p0

    :cond_0
    const/4 v4, 0x4

    const/4 v4, 0x2

    const-string v1, "("

    const-string v1, "("

    const/4 v5, 0x1

    const-string v1, "("

    const-string v1, "("

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const-string p1, ") AND "

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string p0, ")"

    const-string p0, ")"

    const/4 v5, 0x1

    const-string p0, ")"

    const-string p0, ")"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string p0, "bY me(kRG ct_ OudUib"

    const-string p0, "dbORkbu G e_(iYct UB"

    const/4 v5, 0x3

    const-string p0, "bUG oBPuc Oeid(kR_tY"

    const-string p0, " GROUP BY (bucket_id"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0
.end method

.method private static J(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, "?="

    const-string v2, "?="

    const/4 v5, 0x1

    const-string v2, "=?"

    const-string v2, "=?"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v3, "eptdeb_yam"

    const-string v3, "etdpeyuma_"

    const/4 v5, 0x6

    const-string v3, "dyete_upia"

    const-string/jumbo v3, "media_type"

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p1, "Dpp N"

    const-string p1, " ApDN"

    const/4 v5, 0x5

    const-string p1, "D Nq "

    const-string p1, " AND "

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x0

    move v5, v4

    const-string v1, "("

    const-string v1, "("

    const/4 v5, 0x0

    const-string v1, "("

    const-string v1, "("

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo p1, "q sND)"

    const-string p1, "  qD)N"

    const/4 v5, 0x5

    const-string p1, ")N mDA"

    const-string p1, ") AND "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string p0, ")"

    const-string p0, ")"

    const/4 v5, 0x4

    const-string p0, ")"

    const-string p0, ")"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const-string/jumbo p0, "k sPoR_ dtbGiYO(ueU "

    const-string p0, "i_sb YeOkdU(ctGR u P"

    const/4 v5, 0x2

    const-string p0, " GROUP BY (bucket_id"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object p0
.end method

.method private static K(IJ)[Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    cmp-long v0, p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    filled-new-array {p0}, [Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    filled-new-array {p0, p1}, [Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method

.method private static L(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "=?"

    const/4 v5, 0x6

    const-string v2, "=?"

    const-string v2, "=?"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "pmm_ebaitd"

    const-string v3, "de_mmaitpy"

    const/4 v5, 0x4

    const-string/jumbo v3, "media_type"

    const/4 v4, 0x1

    move v5, v4

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const-string p1, "Du Ao"

    const-string p1, " NDAo"

    const/4 v5, 0x4

    const-string p1, " NpAD"

    const-string p1, " AND "

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "("

    const-string v1, "("

    const-string v1, "("

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const-string p1, "ADq )b"

    const-string p1, " D)ANb"

    const-string p1, "D)sN  "

    const-string p1, ") AND "

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p0, ")"

    const/4 v5, 0x0

    const-string p0, ")"

    const-string p0, ")"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string p0, "iUcm dGYPBueuOR_tb  "

    const-string p0, "UGckebuBY_tOR   Pdiu"

    const/4 v5, 0x0

    const-string p0, "Yb _okUeGiOtB Ru(dcP"

    const-string p0, " GROUP BY (bucket_id"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object p0
.end method

.method private M(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ge v0, v1, :cond_2

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v2, v3}, Lcom/luck/picture/lib/loader/d;->c(J)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz v3, :cond_1

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    return-void
.end method

.method static synthetic m(Lcom/luck/picture/lib/loader/d;J)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/loader/d;->z(J)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic n(Lcom/luck/picture/lib/loader/d;J)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/loader/d;->A(J)[Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic o()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/luck/picture/lib/loader/d;->p:[Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic p()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    sget-object v0, Lcom/luck/picture/lib/loader/d;->q:[Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic q(Lcom/luck/picture/lib/loader/d;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/d;->F()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic r(Lcom/luck/picture/lib/loader/d;)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/d;->G()[Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic s(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/loader/d;->x(Landroid/database/Cursor;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic t(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/luck/picture/lib/loader/d;->y(Landroid/database/Cursor;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic u(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/luck/picture/lib/loader/d;->w(Landroid/database/Cursor;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic v(Lcom/luck/picture/lib/loader/d;Ljava/util/List;)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/loader/d;->M(Ljava/util/List;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method private static w(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "pte_pbyem"

    const-string/jumbo v0, "mtpyme_pe"

    const/4 v2, 0x7

    const-string/jumbo v0, "iepe_mutm"

    const-string/jumbo v0, "mime_type"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method private static x(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v0, "id_"

    const-string v0, "i_d"

    const/4 v4, 0x6

    const-string v0, "_di"

    const-string v0, "_id"

    const/4 v4, 0x7

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v2, "emtmyqppe"

    const-string/jumbo v2, "mypetimeq"

    const/4 v4, 0x5

    const-string v2, "etiymmepq"

    const-string/jumbo v2, "mime_type"

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0, v1, p0}, Lcom/luck/picture/lib/utils/i;->n(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object p0
.end method

.method private static y(Landroid/database/Cursor;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, "aast_"

    const-string v0, "aast_"

    const/4 v2, 0x1

    const-string v0, "atdm_"

    const-string v0, "_data"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p0, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method private z(J)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget v3, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    or-int/2addr v6, v5

    if-eq v3, v4, :cond_2

    const/4 v6, 0x5

    const/4 v4, 0x2

    const/4 v6, 0x0

    move v5, v4

    move v5, v4

    const/4 v6, 0x5

    if-eq v3, v4, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v4, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v3, v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v5, 0x5

    move v6, v5

    invoke-static {p1, p2, v2, v0, v1}, Lcom/luck/picture/lib/loader/d;->C(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object p1

    :cond_1
    const/4 v5, 0x5

    invoke-static {p1, p2, v2, v0, v1}, Lcom/luck/picture/lib/loader/d;->E(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object p1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-static {p1, p2, v2, v1}, Lcom/luck/picture/lib/loader/d;->D(JLjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object p1

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p1, p2, v2, v0, v1}, Lcom/luck/picture/lib/loader/d;->B(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p1
.end method


# virtual methods
.method public c(J)Ljava/lang/String;
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    const/4 v2, 0x0

    :try_start_0
    invoke-static {}, Lcom/luck/picture/lib/utils/m;->f()Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v5, "aadto"

    const-string v5, "_data"

    const-string/jumbo v6, "mym_pbeie"

    const-string v6, "_eimymmpe"

    const-string v6, "e_yptiumm"

    const-string/jumbo v6, "mime_type"

    const-string v7, "_di"

    const-string v7, "d_i"

    const-string v7, "_id"

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v0, :cond_0

    :try_start_1
    invoke-direct/range {p0 .. p2}, Lcom/luck/picture/lib/loader/d;->z(J)Ljava/lang/String;

    move-result-object v0

    invoke-direct/range {p0 .. p2}, Lcom/luck/picture/lib/loader/d;->A(J)[Ljava/lang/String;

    move-result-object v10

    invoke-virtual/range {p0 .. p0}, Lcom/luck/picture/lib/loader/a;->g()Ljava/lang/String;

    move-result-object v11

    invoke-static {v0, v10, v9, v8, v11}, Lcom/luck/picture/lib/utils/i;->a(Ljava/lang/String;[Ljava/lang/String;IILjava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    iget-object v10, v1, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    invoke-virtual {v10}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    sget-object v11, Lcom/luck/picture/lib/loader/a;->d:Landroid/net/Uri;

    new-array v4, v4, [Ljava/lang/String;

    aput-object v7, v4, v8

    aput-object v6, v4, v9

    aput-object v5, v4, v3

    invoke-static {v10, v11, v4, v0, v2}, Lcom/luck/picture/lib/loader/c;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Landroid/os/Bundle;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object v0

    :goto_0
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Lcom/luck/picture/lib/loader/a;->g()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v10, "lm os tp t1efo0if"

    const-string/jumbo v10, "ls 1oit fti omef0"

    const-string/jumbo v10, "if s  0tqtif mle1"

    const-string v10, " limit 1 offset 0"

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    iget-object v0, v1, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v11

    sget-object v12, Lcom/luck/picture/lib/loader/a;->d:Landroid/net/Uri;

    new-array v13, v4, [Ljava/lang/String;

    aput-object v7, v13, v8

    aput-object v6, v13, v9

    aput-object v5, v13, v3

    invoke-direct/range {p0 .. p2}, Lcom/luck/picture/lib/loader/d;->z(J)Ljava/lang/String;

    move-result-object v14

    invoke-direct/range {p0 .. p2}, Lcom/luck/picture/lib/loader/d;->A(J)[Ljava/lang/String;

    move-result-object v15

    invoke-virtual/range {v11 .. v16}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_1
    if-eqz v3, :cond_5

    :try_start_2
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    move-result v0

    if-lez v0, :cond_5

    invoke-interface {v3}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {v3, v7}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v7

    invoke-interface {v3, v6}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v3, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-static {v7, v8, v0}, Lcom/luck/picture/lib/utils/i;->n(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    :cond_1
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I

    move-result v0

    invoke-interface {v3, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_2
    invoke-interface {v3}, Landroid/database/Cursor;->isClosed()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_2
    return-object v0

    :cond_3
    invoke-interface {v3}, Landroid/database/Cursor;->isClosed()Z

    move-result v0

    if-nez v0, :cond_4

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_4
    return-object v2

    :catch_0
    move-exception v0

    goto :goto_3

    :cond_5
    if-eqz v3, :cond_6

    invoke-interface {v3}, Landroid/database/Cursor;->isClosed()Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_4

    :catchall_0
    move-exception v0

    goto :goto_5

    :catch_1
    move-exception v0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_3
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v3, :cond_6

    invoke-interface {v3}, Landroid/database/Cursor;->isClosed()Z

    move-result v0

    if-nez v0, :cond_6

    :goto_4
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_6
    return-object v2

    :catchall_1
    move-exception v0

    move-object v2, v3

    move-object v2, v3

    :goto_5
    if-eqz v2, :cond_7

    invoke-interface {v2}, Landroid/database/Cursor;->isClosed()Z

    move-result v3

    if-nez v3, :cond_7

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_7
    throw v0
.end method

.method public h(Ls6/n;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/n<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/luck/picture/lib/loader/d$c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/loader/d$c;-><init>(Lcom/luck/picture/lib/loader/d;Ls6/n;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public i(JILs6/o;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JI",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v3, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    move v4, p3

    move v4, p3

    const/4 v8, 0x7

    move v4, p3

    move v4, p3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    move v5, p3

    move v5, p3

    const/4 v8, 0x6

    move v5, p3

    move v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual/range {v0 .. v6}, Lcom/luck/picture/lib/loader/d;->k(JIIILs6/o;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    return-void
.end method

.method public j(Ls6/m;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/m<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/luck/picture/lib/loader/d$b;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/loader/d$b;-><init>(Lcom/luck/picture/lib/loader/d;Ls6/m;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x3

    return-void
.end method

.method public k(JIIILs6/o;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JIII",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    new-instance v8, Lcom/luck/picture/lib/loader/d$a;

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v1, p0

    move-object v1, p0

    move-wide v2, p1

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    move v5, p3

    move v5, p3

    move v6, p5

    move v6, p5

    move v6, p5

    move v6, p5

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    invoke-direct/range {v0 .. v7}, Lcom/luck/picture/lib/loader/d$a;-><init>(Lcom/luck/picture/lib/loader/d;JIIILs6/o;)V

    invoke-static {v8}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    return-void
.end method

.method public l(JIILs6/o;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JII",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    move v3, p3

    move v3, p3

    const/4 v8, 0x3

    move v3, p3

    move v3, p3

    const/4 v8, 0x3

    move v4, p4

    move v4, p4

    const/4 v8, 0x7

    move v4, p4

    move v4, p4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    move v5, p4

    move v5, p4

    const/4 v8, 0x3

    move v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual/range {v0 .. v6}, Lcom/luck/picture/lib/loader/d;->k(JIIILs6/o;)V

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    return-void
.end method
