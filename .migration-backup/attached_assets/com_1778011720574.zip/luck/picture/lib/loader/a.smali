.class public Lcom/luck/picture/lib/loader/a;
.super Ljava/lang/Object;


# static fields
.field protected static final c:Ljava/lang/String; = "a"

.field protected static final d:Landroid/net/Uri;

.field protected static final e:Ljava/lang/String; = "date_modified DESC"

.field protected static final f:Ljava/lang/String; = "!=\'image/*\'"

.field protected static final g:Ljava/lang/String; = " AND (mime_type!=\'image/gif\' AND mime_type!=\'image/*\')"

.field protected static final h:Ljava/lang/String; = " GROUP BY (bucket_id"

.field protected static final i:Ljava/lang/String; = "count"

.field protected static final j:Ljava/lang/String; = "bucket_id"

.field protected static final k:Ljava/lang/String; = "duration"

.field protected static final l:Ljava/lang/String; = "bucket_display_name"

.field protected static final m:Ljava/lang/String; = "orientation"

.field protected static final n:I = 0x3c

.field protected static final o:[Ljava/lang/String;


# instance fields
.field protected a:Landroid/content/Context;

.field protected b:Lcom/luck/picture/lib/config/PictureSelectionConfig;


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x1

    const-string/jumbo v0, "xsstlrne"

    const-string/jumbo v0, "lesrtxne"

    const/4 v14, 0x0

    const-string v0, "external"

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-static {v0}, Landroid/provider/MediaStore$Files;->getContentUri(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x7

    sput-object v0, Lcom/luck/picture/lib/loader/a;->d:Landroid/net/Uri;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x0

    const-string v1, "di_"

    const-string v1, "_id"

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x4

    const-string/jumbo v2, "mdam_"

    const-string v2, "adam_"

    const/4 v14, 0x0

    const-string v2, "dta_o"

    const-string v2, "_data"

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x5

    const-string v3, "_emypbeio"

    const-string v3, "_itpoeyme"

    const/4 v14, 0x3

    const-string v3, "etemy_uip"

    const-string/jumbo v3, "mime_type"

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x0

    const-string/jumbo v4, "iwpbd"

    const-string v4, "bwitd"

    const/4 v14, 0x2

    const-string v4, "hwtqi"

    const-string/jumbo v4, "width"

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x1

    const-string v5, "htsuhi"

    const-string/jumbo v5, "uhihtg"

    const/4 v14, 0x6

    const-string v5, "height"

    const/4 v14, 0x7

    const-string/jumbo v6, "ipamutnd"

    const-string v6, "datunirp"

    const/4 v14, 0x5

    const-string/jumbo v6, "rdunoota"

    const-string v6, "duration"

    const-string v7, "bsq_e"

    const-string/jumbo v7, "iseq_"

    const/4 v14, 0x6

    const-string v7, "eusiz"

    const-string v7, "_size"

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x1

    const-string/jumbo v8, "snsapiytdblkeuac_m_"

    const/4 v14, 0x4

    const-string/jumbo v8, "suplt_epnyiaamebdkc"

    const-string v8, "bucket_display_name"

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x4

    const-string/jumbo v9, "isdmlnapq_aym"

    const-string/jumbo v9, "p_amsyialnd_m"

    const/4 v14, 0x2

    const-string v9, "epss_nm_aaidy"

    const-string v9, "_display_name"

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x2

    const-string/jumbo v10, "oetmbkcid"

    const-string v10, "dkiuocetb"

    const/4 v14, 0x6

    const-string v10, "bucket_id"

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x4

    const-string v11, "aea_oedbtd"

    const-string v11, "_deetbdada"

    const/4 v14, 0x1

    const-string v11, "adtdebda_e"

    const-string v11, "date_added"

    const/4 v14, 0x1

    const-string/jumbo v12, "ottaoeuiirn"

    const-string/jumbo v12, "orientation"

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x0

    filled-new-array/range {v1 .. v12}, [Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x3

    sput-object v0, Lcom/luck/picture/lib/loader/a;->o:[Ljava/lang/String;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method protected static e()[Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method protected static f(I)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    filled-new-array {p0}, [Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method protected a()Ljava/lang/String;
    .locals 11

    const/4 v9, 0x7

    move v10, v9

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x0

    const/4 v9, 0x5

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->q:I

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez v1, :cond_0

    const/4 v9, 0x4

    move v10, v9

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v10, 0x4

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    int-to-long v1, v1

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v3, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v4, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    int-to-long v5, v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x2

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x1

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v5, 0x0

    move v10, v5

    const/4 v9, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    aput-object v0, v4, v5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->r:I

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    int-to-long v5, v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v7, v8, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    cmp-long v0, v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez v0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, "="

    const-string v0, "="

    const/4 v10, 0x3

    const-string v0, "="

    const-string v0, "="

    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    const/4 v5, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    aput-object v0, v4, v5

    const/4 v9, 0x7

    move v10, v9

    const/4 v0, 0x2

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    aput-object v1, v4, v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v0, "=n daa p dtuoti% u<d %s<drnaiuo %r"

    const-string v0, "<oa <ru un aoddduadtii= % nrst%% n"

    const/4 v10, 0x4

    const-string/jumbo v0, "r<o ti= qudd<%rn%na t uno%d asadd "

    const-string v0, "%d <%s duration and duration <= %d"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v3, v0, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-object v0
.end method

.method protected b()Ljava/lang/String;
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-wide v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->x:J

    const/4 v10, 0x7

    const/4 v9, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x5

    cmp-long v5, v1, v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    if-nez v5, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v10, 0x4

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    sget-object v5, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    const/4 v9, 0x5

    move v10, v9

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-wide v7, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v3, v4, v7, v8}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    aput-object v0, v6, v7

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-wide v7, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->y:J

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v3, v4, v7, v8}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    cmp-long v0, v7, v3

    const/4 v10, 0x2

    const/4 v9, 0x7

    if-nez v0, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_0

    :cond_1
    const/4 v10, 0x6

    const-string v0, "="

    const-string v0, "="

    const/4 v10, 0x3

    const-string v0, "="

    const-string v0, "="

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v3, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-object v0, v6, v3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    const/4 v0, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    aput-object v1, v6, v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, "<zss nze=i%dse%is _   dp%_ <"

    const-string/jumbo v0, "z=es   pd isz%ied%% <__n<sd "

    const-string/jumbo v0, "nd m %se idz_a%e<i_  z%=s s<"

    const-string v0, "%d <%s _size and _size <= %d"

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-static {v5, v0, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    return-object v0
.end method

.method public c(J)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method protected d()Ljava/lang/String;
    .locals 12

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->P:Ljava/util/List;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v1, Ljava/util/HashSet;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v1, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v3, -0x1

    :cond_0
    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-eqz v4, :cond_6

    const/4 v11, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    check-cast v4, Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz v5, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto :goto_0

    :cond_1
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object v5, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    iget v5, v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/h;->d()I

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v7, "aiqdo"

    const-string/jumbo v7, "odaqi"

    const/4 v11, 0x4

    const-string v7, "bioud"

    const-string v7, "audio"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string/jumbo v8, "iumge"

    const-string v8, "emsgi"

    const/4 v11, 0x6

    const-string v8, "iapme"

    const-string/jumbo v8, "image"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-ne v5, v6, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-nez v5, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v4, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v5, :cond_4

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    goto :goto_0

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget-object v5, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget v5, v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->c()I

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x7

    const-string/jumbo v9, "ivoqm"

    const-string/jumbo v9, "voemi"

    const/4 v11, 0x0

    const-string/jumbo v9, "idsvo"

    const-string/jumbo v9, "video"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-ne v5, v6, :cond_3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v4, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-nez v5, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x1

    invoke-virtual {v4, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v5, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x4

    move v11, v10

    iget-object v5, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget v5, v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-ne v5, v6, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v4, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-nez v5, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v5, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-nez v3, :cond_5

    const/4 v11, 0x1

    const-string v5, "DA mN"

    const-string v5, " AND "

    const/4 v10, 0x2

    const/4 v11, 0x6

    goto :goto_1

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v5, " O R"

    const-string v5, "R  O"

    const/4 v11, 0x5

    const-string v5, " RO "

    const-string v5, " OR "

    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string/jumbo v5, "pmmtoie_e"

    const/4 v11, 0x5

    const-string/jumbo v5, "itypoemm_"

    const-string/jumbo v5, "mime_type"

    const/4 v10, 0x3

    or-int/2addr v11, v10

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-string v5, "=//"

    const-string v5, "/=/"

    const/4 v11, 0x1

    const-string v5, "=//"

    const-string v5, "=\'"

    const/4 v10, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string v4, "//"

    const-string v4, "//"

    const/4 v11, 0x5

    const-string v4, "//"

    const-string v4, "\'"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_6
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/h;->d()I

    move-result v3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eq v0, v3, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v11, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->D:Z

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-nez v0, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/f;->u()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-nez v0, :cond_7

    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string v0, "ee(/=bApe/ /m/i/DmA b/ y=/g_iygt)!eN!m/ia iepeDm/_*/mfNgta"

    const-string v0, "eg/( bitim///=)!m/ieNe=m f/peeD/ ai/Ny yA_gpA/itmmD_!g*ea/"

    const/4 v11, 0x1

    const-string v0, "*aa/ Au/tmitNm!mDp/eg=fAg=emmp(_eN/De /ii)iy_//y// e!/e im"

    const-string v0, " AND (mime_type!=\'image/gif\' AND mime_type!=\'image/*\')"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x6

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string v0, "eDuSidtp edafoi_Cd"

    const-string v0, " didCoufSd_eaDietE"

    const/4 v2, 0x5

    const-string/jumbo v0, "odCiei aqeDdEfm_dt"

    const-string v0, "date_modified DESC"

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k0:Ljava/lang/String;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public h(Ls6/n;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/n<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public i(JILs6/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JI",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public j(Ls6/m;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/m<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method public k(JIIILs6/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JIII",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public l(JIILs6/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JII",
            "Ls6/o<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method
