.class Lcom/luck/picture/lib/loader/d$b;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/loader/d;->j(Ls6/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic o:Ls6/m;

.field final synthetic p:Lcom/luck/picture/lib/loader/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/loader/d;Ls6/m;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/loader/d$b;->p:Lcom/luck/picture/lib/loader/d;

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/loader/d$b;->o:Ls6/m;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@osf @~u~tb.@ol @  @ o~1~d ~~~~M Koa  @l@@bo~~@ ~rbt~~/i@@@  ~/vnc@~@~@@mif @~~@@~~s i~o -S~y 4 "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/d$b;->r()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/loader/d$b;->s(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v1, 0x4

    return-void
.end method

.method public r()Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/loader/d$b;->p:Lcom/luck/picture/lib/loader/d;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, v0, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, v0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-static {v1, v0}, Lcom/luck/picture/lib/loader/e;->b(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public s(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 3

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/loader/d$b;->o:Ls6/m;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ls6/m;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
