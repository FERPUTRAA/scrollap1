.class Lcom/luck/picture/lib/loader/b$a;
.super Lcom/luck/picture/lib/thread/a$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/loader/b;->j(Ls6/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/luck/picture/lib/thread/a$e<",
        "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic o:Ls6/m;

.field final synthetic p:Lcom/luck/picture/lib/loader/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/loader/b;Ls6/m;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/loader/b$a;->p:Lcom/luck/picture/lib/loader/b;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/loader/b$a;->o:Ls6/m;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/thread/a$e;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cysr ~/@1 a/@ o ~ ~~os@l~v~ ~~ @@ i ~d~fto@S~ bm@@M~@ii-@@  ~nK .@o~@l@ub o~   @~bo@~@@f~~t~@~~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/b$a;->r()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic m(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v0, 0x3

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/loader/b$a;->s(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public r()Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/loader/b$a;->p:Lcom/luck/picture/lib/loader/b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, v0, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, v0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {v1, v0}, Lcom/luck/picture/lib/loader/e;->b(Landroid/content/Context;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public s(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/luck/picture/lib/thread/a;->d(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/loader/b$a;->o:Ls6/m;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ls6/m;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    return-void
.end method
