.class public final Lcom/luck/picture/lib/loader/b;
.super Lcom/luck/picture/lib/loader/a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/loader/a;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic m(Lcom/luck/picture/lib/loader/b;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s ~ S~i~@~4  @@Kd@nfr i~@u~~@~~@ @~@  ~s @~ oM@@ @o~-~@l~ @   b@~o @~y1ao. bco@v~olb/tf/i@~t@m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/b;->q()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic n(Lcom/luck/picture/lib/loader/b;)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/loader/b;->r()[Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic o(Lcom/luck/picture/lib/loader/b;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/luck/picture/lib/loader/b;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method private p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v2, p3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v1

    :cond_2
    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v0, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, p3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->v(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->s(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->u(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {p4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v0
.end method

.method private q()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/loader/a;->d()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v3, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v4, 0x1

    and-int/2addr v6, v4

    const/4 v5, 0x3

    move v6, v5

    if-eq v3, v4, :cond_2

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x4

    if-eq v3, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x3

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eq v3, v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object v0

    :cond_0
    const/4 v6, 0x5

    invoke-static {v0, v2}, Lcom/luck/picture/lib/loader/b;->t(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    return-object v0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lcom/luck/picture/lib/loader/b;->v(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object v0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/luck/picture/lib/loader/b;->u(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-object v0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v1, v2}, Lcom/luck/picture/lib/loader/b;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-object v0
.end method

.method private r()[Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/loader/a;->b:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v0, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v2}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/loader/a;->f(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {}, Lcom/luck/picture/lib/loader/a;->e()[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0
.end method

.method private static s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string/jumbo v1, "tsdmp=meae(_y"

    const-string v1, "eys=d_e(tmap?"

    const/4 v3, 0x7

    const-string v1, "(diyot?epea=_"

    const-string v1, "(media_type=?"

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string p2, "  OR"

    const-string p2, "  RO"

    const/4 v3, 0x6

    const-string p2, "R O "

    const-string p2, " OR "

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo p2, "tpydmbaei_"

    const-string p2, "_temipamyd"

    const/4 v3, 0x5

    const-string/jumbo p2, "tyi_emuead"

    const-string/jumbo p2, "media_type"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    const-string/jumbo p2, "poA = D"

    const-string p2, "=D? o A"

    const/4 v3, 0x1

    const-string p2, "?qD A= "

    const-string p2, "=? AND "

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p0, "  sbAN"

    const-string p0, " A DNb"

    const/4 v3, 0x2

    const-string p0, " )NmDA"

    const-string p0, ") AND "

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method private static t(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "ypueodmat=?e"

    const-string v1, "a=dmypue?e_t"

    const-string v1, "?mepaby=_dei"

    const-string/jumbo v1, "media_type=?"

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p1, "Du Np"

    const-string p1, " NpD "

    const/4 v3, 0x1

    const-string p1, " Ap D"

    const-string p1, " AND "

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p0
.end method

.method private static u(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "aym?d=_eqtpe"

    const/4 v3, 0x6

    const-string/jumbo v1, "mpai_ty=qeed"

    const-string/jumbo v1, "media_type=?"

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " As s"

    const-string p1, "A sN "

    const/4 v3, 0x1

    const-string p1, "D NmA"

    const-string p1, " AND "

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0
.end method

.method private static v(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "_p?eotame=iy"

    const-string/jumbo v1, "yepmm_t=i?ea"

    const/4 v3, 0x3

    const-string v1, "e=y?tbpae_mi"

    const-string/jumbo v1, "media_type=?"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string p1, " uo D"

    const-string p1, " N Do"

    const/4 v3, 0x0

    const-string p1, "DNpA "

    const-string p1, " AND "

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0
.end method


# virtual methods
.method public h(Ls6/n;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/n<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/loader/b$b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/loader/b$b;-><init>(Lcom/luck/picture/lib/loader/b;Ls6/n;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public j(Ls6/m;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ls6/m<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/luck/picture/lib/loader/b$a;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/luck/picture/lib/loader/b$a;-><init>(Lcom/luck/picture/lib/loader/b;Ls6/m;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/thread/a;->M(Lcom/luck/picture/lib/thread/a$g;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
