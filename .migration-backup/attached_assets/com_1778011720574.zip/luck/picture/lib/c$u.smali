.class Lcom/luck/picture/lib/c$u;
.super Ljava/lang/Object;

# interfaces
.implements Ls6/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->L1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(ILcom/luck/picture/lib/entity/LocalMediaFolder;)V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "4@s ~M~. b@~~c @ i/v~~1@@s~~a~~@ ub ~  y n ~@@@ol@~o -S@~@~@~  @t~ rt~@ ~/f @ l@o~dmK@@~~f@oiboi"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/c;->a1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->C:Z

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v1, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    cmp-long v0, v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-nez v0, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    move v0, v1

    move v0, v1

    const/4 v10, 0x2

    move v0, v1

    move v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    move v0, v2

    move v0, v2

    const/4 v10, 0x0

    move v0, v2

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lcom/luck/picture/lib/c;->Z0(Lcom/luck/picture/lib/c;Z)Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/c;->W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/c;->Y0(Lcom/luck/picture/lib/c;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/adapter/b;->j(Z)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    invoke-static {p1}, Lcom/luck/picture/lib/c;->I1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/TitleBar;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->k()Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v3

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/c;->b1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    cmp-long v0, v5, v3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v0, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/c;->W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/b;->b()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->r(Ljava/util/ArrayList;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/c;->c1(Lcom/luck/picture/lib/c;)I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->q(I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b()Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->x(Z)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-lez p1, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->k()Z

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    if-nez p1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x1

    const/4 v9, 0x4

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {p1, v0}, Lcom/luck/picture/lib/c;->d1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x6

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->c()I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {p1, v0}, Lcom/luck/picture/lib/c;->e1(Lcom/luck/picture/lib/c;I)I

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->k()Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setEnabledLoadMore(Z)V

    const/4 v10, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->smoothScrollToPosition(I)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {p1, v1}, Lcom/luck/picture/lib/c;->f1(Lcom/luck/picture/lib/c;I)I

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    sget-object v2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v9, 0x7

    move v10, v9

    if-eqz v2, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/c;->g1(Lcom/luck/picture/lib/c;)I

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/c;->h1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    iget v7, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    new-instance v8, Lcom/luck/picture/lib/c$u$a;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-direct {v8, p0}, Lcom/luck/picture/lib/c$u$a;-><init>(Lcom/luck/picture/lib/c$u;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-interface/range {v2 .. v8}, Lq6/c;->c(Landroid/content/Context;JIILs6/o;)V

    const/4 v9, 0x7

    move v10, v9

    goto :goto_1

    :cond_2
    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/c;->m1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/loader/a;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/c;->k1(Lcom/luck/picture/lib/c;)I

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/c;->l1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget v4, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-instance v5, Lcom/luck/picture/lib/c$u$b;

    const/4 v9, 0x4

    move v10, v9

    invoke-direct {v5, p0}, Lcom/luck/picture/lib/c$u$b;-><init>(Lcom/luck/picture/lib/c$u;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual/range {v0 .. v5}, Lcom/luck/picture/lib/loader/a;->l(JIILs6/o;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_1

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    cmp-long p1, v0, v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz p1, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->d()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {p1, v0}, Lcom/luck/picture/lib/c;->d1(Lcom/luck/picture/lib/c;Ljava/util/ArrayList;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v9, 0x0

    move v10, v9

    invoke-static {p1}, Lcom/luck/picture/lib/c;->F1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/RecyclerPreloadView;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->smoothScrollToPosition(I)V

    :cond_4
    :goto_1
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {p2}, Lcom/luck/picture/lib/manager/b;->q(Lcom/luck/picture/lib/entity/LocalMediaFolder;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/c;->G1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/dialog/a;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/dialog/a;->dismiss()V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/c;->n1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/a;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-eqz p1, :cond_5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/c;->o1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-boolean p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->V0:Z

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p1, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v9, 0x7

    or-int/2addr v10, v9

    invoke-static {p1}, Lcom/luck/picture/lib/c;->n1(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/widget/a;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/c$u;->a:Lcom/luck/picture/lib/c;

    const/4 v10, 0x2

    invoke-static {p2}, Lcom/luck/picture/lib/c;->W0(Lcom/luck/picture/lib/c;)Lcom/luck/picture/lib/adapter/b;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p2}, Lcom/luck/picture/lib/adapter/b;->e()Z

    move-result p2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/widget/a;->n(I)Lcom/luck/picture/lib/widget/a;

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-void
.end method
