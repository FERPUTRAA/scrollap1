.class Lcom/luck/picture/lib/d$i;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/d;->X1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/d;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/d$i;->a:Lcom/luck/picture/lib/d;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s/ b  ~~cv @ ~n mo~1d@~f@-~@s~@l~@@@~oSt@ @ir ~~~ ~i@M ~ ~o~u~~ bo@@@a/~4  .~@@tbKy @fo~l@i@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/d$i;->a:Lcom/luck/picture/lib/d;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-boolean v0, p1, Lcom/luck/picture/lib/d;->A:Z

    const/4 v2, 0x0

    return-void
.end method
