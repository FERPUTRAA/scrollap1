.class public final Lcom/luck/picture/lib/R$anim;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "anim"
.end annotation


# static fields
.field public static final abc_fade_in:I = 0x7f010000

.field public static final abc_fade_out:I = 0x7f010001

.field public static final abc_grow_fade_in_from_bottom:I = 0x7f010002

.field public static final abc_popup_enter:I = 0x7f010003

.field public static final abc_popup_exit:I = 0x7f010004

.field public static final abc_shrink_fade_out_from_bottom:I = 0x7f010005

.field public static final abc_slide_in_bottom:I = 0x7f010006

.field public static final abc_slide_in_top:I = 0x7f010007

.field public static final abc_slide_out_bottom:I = 0x7f010008

.field public static final abc_slide_out_top:I = 0x7f010009

.field public static final abc_tooltip_enter:I = 0x7f01000a

.field public static final abc_tooltip_exit:I = 0x7f01000b

.field public static final btn_checkbox_to_checked_box_inner_merged_animation:I = 0x7f010016

.field public static final btn_checkbox_to_checked_box_outer_merged_animation:I = 0x7f010017

.field public static final btn_checkbox_to_checked_icon_null_animation:I = 0x7f010018

.field public static final btn_checkbox_to_unchecked_box_inner_merged_animation:I = 0x7f010019

.field public static final btn_checkbox_to_unchecked_check_path_merged_animation:I = 0x7f01001a

.field public static final btn_checkbox_to_unchecked_icon_null_animation:I = 0x7f01001b

.field public static final btn_radio_to_off_mtrl_dot_group_animation:I = 0x7f01001c

.field public static final btn_radio_to_off_mtrl_ring_outer_animation:I = 0x7f01001d

.field public static final btn_radio_to_off_mtrl_ring_outer_path_animation:I = 0x7f01001e

.field public static final btn_radio_to_on_mtrl_dot_group_animation:I = 0x7f01001f

.field public static final btn_radio_to_on_mtrl_ring_outer_animation:I = 0x7f010020

.field public static final btn_radio_to_on_mtrl_ring_outer_path_animation:I = 0x7f010021

.field public static final fragment_fast_out_extra_slow_in:I = 0x7f010034

.field public static final ps_anim_album_dismiss:I = 0x7f010045

.field public static final ps_anim_album_show:I = 0x7f010046

.field public static final ps_anim_alpha_enter:I = 0x7f010047

.field public static final ps_anim_alpha_exit:I = 0x7f010048

.field public static final ps_anim_anticipate_interpolator:I = 0x7f010049

.field public static final ps_anim_down_out:I = 0x7f01004a

.field public static final ps_anim_enter:I = 0x7f01004b

.field public static final ps_anim_exit:I = 0x7f01004c

.field public static final ps_anim_fade_in:I = 0x7f01004d

.field public static final ps_anim_fade_out:I = 0x7f01004e

.field public static final ps_anim_fall_enter:I = 0x7f01004f

.field public static final ps_anim_layout_fall_enter:I = 0x7f010050

.field public static final ps_anim_modal_in:I = 0x7f010051

.field public static final ps_anim_modal_out:I = 0x7f010052

.field public static final ps_anim_overshoot_interpolator:I = 0x7f010053

.field public static final ps_anim_up_in:I = 0x7f010054


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
