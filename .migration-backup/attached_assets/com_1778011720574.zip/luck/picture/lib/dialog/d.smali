.class public Lcom/luck/picture/lib/dialog/d;
.super Landroid/app/Dialog;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget v0, Lcom/luck/picture/lib/R$style;->Picture_Theme_AlertDialog:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setCancelable(Z)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method private a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "4bst-~r@~ ~  ai~ /il M@c~@y ~o/~~~f~@bu @@~S@~l~@~ oo~@~b~  @K@@@~~~ 1  @ m@@~@osoo  . @@~vif@tn"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, -0x2

    const/4 v3, 0x0

    const/4 v3, 0x5

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 v1, 0x11

    const/4 v3, 0x1

    or-int/2addr v4, v3

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget v2, Lcom/luck/picture/lib/R$style;->PictureThemeDialogWindowStyle:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_alert_dialog:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/dialog/d;->a()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
