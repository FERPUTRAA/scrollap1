.class public Lcom/luck/picture/lib/dialog/a;
.super Landroid/widget/PopupWindow;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/dialog/a$d;
    }
.end annotation


# static fields
.field private static final h:I = 0x8


# instance fields
.field private final a:Landroid/content/Context;

.field private b:Landroid/view/View;

.field private c:Landroidx/recyclerview/widget/RecyclerView;

.field private d:Z

.field private e:I

.field private f:Lcom/luck/picture/lib/adapter/a;

.field private g:Lcom/luck/picture/lib/dialog/a$d;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x3

    invoke-direct {p0}, Landroid/widget/PopupWindow;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/dialog/a;->d:Z

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/a;->a:Landroid/content/Context;

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    sget v0, Lcom/luck/picture/lib/R$layout;->ps_window_folder:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setContentView(Landroid/view/View;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setWidth(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, -0x2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setHeight(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget p1, Lcom/luck/picture/lib/R$style;->PictureThemeWindowStyle:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setAnimationStyle(I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setFocusable(Z)V

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->update()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/dialog/a;->j()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/dialog/a;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "iosoo ~ ~@@va~~@m~ @~/t@@o@ ~ lb@ @~~u @@bt@~c~oK-@~~y M@ i. ~s @d@ir S @@@~~4~~1~~~ blf~/o @nf "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-super {p0}, Landroid/widget/PopupWindow;->dismiss()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic b(Lcom/luck/picture/lib/dialog/a;Z)Z
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/luck/picture/lib/dialog/a;->d:Z

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p1
.end method

.method public static d(Landroid/content/Context;)Lcom/luck/picture/lib/dialog/a;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/dialog/a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method private j()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->a:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/utils/e;->h(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    int-to-double v0, v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-wide v2, 0x3fe3333333333333L    # 0.6

    const-wide v2, 0x3fe3333333333333L    # 0.6

    const/4 v5, 0x3

    const-wide v2, 0x3fe3333333333333L    # 0.6

    const-wide v2, 0x3fe3333333333333L    # 0.6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    mul-double/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    double-to-int v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput v0, p0, Lcom/luck/picture/lib/dialog/a;->e:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget v1, Lcom/luck/picture/lib/R$id;->folder_list:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/dialog/a;->c:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget v1, Lcom/luck/picture/lib/R$id;->rootViewBg:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/dialog/a;->b:Landroid/view/View;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->c:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x0

    new-instance v1, Lcom/luck/picture/lib/decoration/WrapContentLinearLayoutManager;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/dialog/a;->a:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Lcom/luck/picture/lib/decoration/WrapContentLinearLayoutManager;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Lcom/luck/picture/lib/adapter/a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0}, Lcom/luck/picture/lib/adapter/a;-><init>()V

    const/4 v4, 0x1

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/dialog/a;->c:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->b:Landroid/view/View;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Lcom/luck/picture/lib/dialog/a$a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/dialog/a$a;-><init>(Lcom/luck/picture/lib/dialog/a;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/widget/PopupWindow;->getContentView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget v1, Lcom/luck/picture/lib/R$id;->rootView:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Lcom/luck/picture/lib/dialog/a$b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/dialog/a$b;-><init>(Lcom/luck/picture/lib/dialog/a;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x2

    and-int/2addr v5, v4

    return-void
.end method


# virtual methods
.method public c(Ljava/util/List;)V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/a;->b(Ljava/util/List;)V

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyDataSetChanged()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->c:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-le p1, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget p1, p0, Lcom/luck/picture/lib/dialog/a;->e:I

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, -0x2

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput p1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public dismiss()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/luck/picture/lib/dialog/a;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->b:Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->g:Lcom/luck/picture/lib/dialog/a$d;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0}, Lcom/luck/picture/lib/dialog/a$d;->b()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/luck/picture/lib/dialog/a;->d:Z

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->b:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x3

    new-instance v1, Lcom/luck/picture/lib/dialog/a$c;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/dialog/a$c;-><init>(Lcom/luck/picture/lib/dialog/a;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public e()V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    move v2, v1

    move v2, v1

    const/4 v10, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-ge v2, v3, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    check-cast v3, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    invoke-virtual {v3, v1}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->y(Z)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v4, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v9, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v4, v2}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    const/4 v10, 0x0

    move v4, v1

    move v4, v1

    const/4 v10, 0x2

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-ge v4, v5, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    check-cast v5, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->h()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v5}, Lcom/luck/picture/lib/entity/LocalMedia;->B()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v6, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-nez v5, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v3}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->a()J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const/4 v10, 0x2

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    cmp-long v5, v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-nez v5, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_2

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto :goto_1

    :cond_1
    :goto_2
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v4, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->y(Z)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v3, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v9, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    return-void
.end method

.method public f()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMediaFolder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public g()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/dialog/a;->i()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-lez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/luck/picture/lib/dialog/a;->h(I)Lcom/luck/picture/lib/entity/LocalMediaFolder;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMediaFolder;->i()I

    move-result v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v1
.end method

.method public h(I)Lcom/luck/picture/lib/entity/LocalMediaFolder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-lez v0, :cond_0

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-ge p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMediaFolder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x0

    move v2, p1

    :goto_0
    const/4 v1, 0x0

    move v2, v1

    return-object p1
.end method

.method public i()I
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/a;->c()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public k(Ls6/a;)V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/a;->f:Lcom/luck/picture/lib/adapter/a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/a;->f(Ls6/a;)V

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public l(Lcom/luck/picture/lib/dialog/a$d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/a;->g:Lcom/luck/picture/lib/dialog/a$d;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public showAsDropDown(Landroid/view/View;)V
    .locals 5

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/dialog/a;->f()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/dialog/a;->f()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->c()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-array v0, v0, [I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Landroid/view/View;->getLocationInWindow([I)V

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    aget v0, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    add-int/2addr v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v1, v1, v0}, Landroid/widget/PopupWindow;->showAtLocation(Landroid/view/View;III)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-super {p0, p1}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-boolean v1, p0, Lcom/luck/picture/lib/dialog/a;->d:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/dialog/a;->g:Lcom/luck/picture/lib/dialog/a$d;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p1}, Lcom/luck/picture/lib/dialog/a$d;->a()V

    :cond_2
    const/4 v3, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/dialog/a;->b:Landroid/view/View;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-wide/16 v0, 0xfa

    const-wide/16 v0, 0xfa

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setStartDelay(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/dialog/a;->e()V

    :cond_3
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method
