.class public Lcom/luck/picture/lib/dialog/c;
.super Landroid/app/Dialog;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/dialog/c$a;
    }
.end annotation


# instance fields
.field private a:Lcom/luck/picture/lib/dialog/c$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget v0, Lcom/luck/picture/lib/R$style;->Picture_Theme_Dialog:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget p1, Lcom/luck/picture/lib/R$layout;->ps_common_dialog:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget p1, Lcom/luck/picture/lib/R$id;->btn_cancel:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast p1, Landroid/widget/Button;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v0, Lcom/luck/picture/lib/R$id;->btn_commit:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v0, Landroid/widget/Button;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget v1, Lcom/luck/picture/lib/R$id;->tvTitle:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0, v1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast v1, Landroid/widget/TextView;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget v2, Lcom/luck/picture/lib/R$id;->tv_content:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v2}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v2, Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/dialog/c;->a()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method private a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "s.si@@K~~ o @b~@~@/m ~o~l  ~@1@rdo~@/~ ~~~l~f~ @@a@@@ 4  c~@@ tio ~uf@ vnb ~o Myt-@S@io~~~ @~b ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, -0x2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 v1, 0x11

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v2, Lcom/luck/picture/lib/R$style;->PictureThemeDialogWindowStyle:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/luck/picture/lib/dialog/c;
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Lcom/luck/picture/lib/dialog/c;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, p2}, Lcom/luck/picture/lib/dialog/c;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public b(Lcom/luck/picture/lib/dialog/c$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/c;->a:Lcom/luck/picture/lib/dialog/c$a;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->btn_cancel:I

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->btn_commit:I

    const/4 v2, 0x3

    if-ne p1, v0, :cond_1

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p0}, Landroid/app/Dialog;->dismiss()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/dialog/c;->a:Lcom/luck/picture/lib/dialog/c$a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/luck/picture/lib/dialog/c$a;->a()V

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method
