.class Lcom/luck/picture/lib/dialog/a$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/dialog/a;->j()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/dialog/a;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/dialog/a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/a$b;->a:Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "cms/sl~~iooi@.~/@~ ~ ~~ ~bu@K r b@@@~ @ @t~~o~b ~@~~ @-o @yd@@ @@ ~t ~@f ~ 1~ao 4@ln@@M @o~S~vi~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->b()Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/dialog/a$b;->a:Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/dialog/a;->dismiss()V

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method
