.class Lcom/luck/picture/lib/dialog/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/dialog/a;->j()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/dialog/a;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/dialog/a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/a$a;->a:Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s@.~~M~~ni~~~~@@t@fo~  @@~b~ ruyS ~i/lt c@@ @ f~v@a  4o~  o@@o~@d@/ ~@  blm~@- K~1s~~b@@@ i@~o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/luck/picture/lib/dialog/a$a;->a:Lcom/luck/picture/lib/dialog/a;

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/dialog/a;->dismiss()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
