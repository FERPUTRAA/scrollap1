.class public Lcom/luck/picture/lib/dialog/b;
.super Landroidx/fragment/app/c;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/dialog/b$a;
    }
.end annotation


# static fields
.field public static final d:I = 0x0

.field public static final e:I = 0x1


# instance fields
.field private a:Z

.field private b:Ls6/g;

.field private c:Lcom/luck/picture/lib/dialog/b$a;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/fragment/app/c;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/dialog/b;->a:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private e0()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "r s @~~@ @4~l -m@/ bK a@s  ob@~u~~~bo @ l@o@/~~~~~vo i~ @~o@.i dt@@ @~  ti@~~Sno@@~fcy~f ~@@~~@1"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/c;->getDialog()Landroid/app/Dialog;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/e;->f(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, -0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setLayout(II)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/16 v1, 0x50

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    sget v1, Lcom/luck/picture/lib/R$style;->PictureThemeDialogFragmentAnim:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public static f0()Lcom/luck/picture/lib/dialog/b;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lcom/luck/picture/lib/dialog/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/luck/picture/lib/dialog/b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public g0(Lcom/luck/picture/lib/dialog/b$a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/b;->c:Lcom/luck/picture/lib/dialog/b$a;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public h0(Ls6/g;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/dialog/b;->b:Ls6/g;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/dialog/b;->b:Ls6/g;

    const/4 v4, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget v2, Lcom/luck/picture/lib/R$id;->ps_tv_photo:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne v0, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v1, p1, v3}, Ls6/g;->a(Landroid/view/View;I)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-boolean v3, p0, Lcom/luck/picture/lib/dialog/b;->a:Z

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget v2, Lcom/luck/picture/lib/R$id;->ps_tv_video:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne v0, v2, :cond_1

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x7

    move v4, v0

    move v4, v0

    const/4 v5, 0x0

    invoke-interface {v1, p1, v0}, Ls6/g;->a(Landroid/view/View;I)V

    const/4 v4, 0x0

    const/4 v4, 0x1

    iput-boolean v3, p0, Lcom/luck/picture/lib/dialog/b;->a:Z

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/c;->dismissAllowingStateLoss()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 3
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/c;->getDialog()Landroid/app/Dialog;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p3, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/c;->getDialog()Landroid/app/Dialog;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p3, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/c;->getDialog()Landroid/app/Dialog;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p3}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p3, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/c;->getDialog()Landroid/app/Dialog;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p3}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const v0, 0x106000d

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p3, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget p3, Lcom/luck/picture/lib/R$layout;->ps_dialog_camera_selected:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1, p3, p2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 4
    .param p1    # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onDismiss(Landroid/content/DialogInterface;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/dialog/b;->c:Lcom/luck/picture/lib/dialog/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/luck/picture/lib/dialog/b;->a:Z

    const/4 v3, 0x2

    invoke-interface {v0, v1, p1}, Lcom/luck/picture/lib/dialog/b$a;->a(ZLandroid/content/DialogInterface;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public onStart()V
    .locals 2

    const/4 v1, 0x5

    invoke-super {p0}, Landroidx/fragment/app/c;->onStart()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/dialog/b;->e0()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget p2, Lcom/luck/picture/lib/R$id;->ps_tv_photo:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast p2, Landroid/widget/TextView;

    const/4 v3, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_video:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget v1, Lcom/luck/picture/lib/R$id;->ps_tv_cancel:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast p1, Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1, p0, p2}, Landroidx/fragment/app/a0;->k(Landroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/a0;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroidx/fragment/app/a0;->r()I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
