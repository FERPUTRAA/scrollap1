.class public Lcom/luck/picture/lib/d;
.super Lcom/luck/picture/lib/basic/e;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/d$v;
    }
.end annotation


# static fields
.field public static final P:Ljava/lang/String; = "d"


# instance fields
.field protected A:Z

.field protected B:I

.field protected C:I

.field protected D:I

.field protected E:J

.field protected F:Landroid/widget/TextView;

.field protected G:Landroid/widget/TextView;

.field protected H:Landroid/view/View;

.field protected I:Lcom/luck/picture/lib/widget/CompleteSelectView;

.field protected J:Z

.field protected K:Z

.field protected L:Landroidx/recyclerview/widget/RecyclerView;

.field protected M:Lcom/luck/picture/lib/adapter/holder/g;

.field protected N:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private final O:Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;

.field protected l:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;"
        }
    .end annotation
.end field

.field protected m:Lcom/luck/picture/lib/magical/MagicalView;

.field protected n:Landroidx/viewpager2/widget/ViewPager2;

.field protected o:Lcom/luck/picture/lib/adapter/c;

.field protected p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

.field protected q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

.field protected r:Z

.field protected s:I

.field protected t:Z

.field protected u:Z

.field protected v:Z

.field protected w:Ljava/lang/String;

.field protected x:Z

.field protected y:Z

.field protected z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/e;-><init>()V

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->r:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->J:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->K:Z

    new-instance v0, Lcom/luck/picture/lib/d$l;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/d$l;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/d;->O:Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method private A1()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s of@d~4  @~SoM @@yo~l-@~  b@i @.or1@o@K~ ~ @~cnvb~@a~is~  ~~bi~@tm @@~tl @~~/ o~~  @@f@~@~/~u"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/TitleBar;->getImageDelete()Landroid/widget/ImageView;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v2, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method private B1(Lcom/luck/picture/lib/entity/LocalMedia;)[I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/luck/picture/lib/utils/i;->q(II)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v0, p0, Lcom/luck/picture/lib/d;->C:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/luck/picture/lib/d;->D:I

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->b()I

    move-result v1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-lez v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-lez v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->k()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->i()I

    move-result v1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    filled-new-array {v0, v1}, [I

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object p1
.end method

.method private C1()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->F1()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->K0()V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private D1(Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean p1, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v3, 0x6

    const/4 v0, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    move p1, v0

    move p1, v0

    const/4 v3, 0x3

    move p1, v0

    move p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x3

    move v3, v2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ge v0, v1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->F0(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->M1(Ljava/util/ArrayList;)V

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private E1(Ljava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/luck/picture/lib/d;->r:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p2, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-lez p2, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v2, 0x5

    invoke-virtual {v0, p2, p1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemRangeChanged(II)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->Q1()V

    :cond_2
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private F1()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ge v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v1, Landroid/view/View;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Landroid/view/View;->setEnabled(Z)V

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;->getEditor()Landroid/widget/TextView;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method private G1()V
    .locals 5

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->N1()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/d;->a2()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->v:Z

    const/4 v3, 0x6

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundAlpha(F)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v0, 0x0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ge v0, v2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    instance-of v2, v2, Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast v2, Landroid/view/View;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Landroid/view/View;->setAlpha(F)V

    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundAlpha(F)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method private H1()V
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;->f()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->h()V

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v1, Lcom/luck/picture/lib/d$h;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$h;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/BottomNavBar;->setOnBottomNavBarListener(Lcom/luck/picture/lib/widget/BottomNavBar$b;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private I1()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->J()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->J()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->R()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->R()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->M()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->M()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->P()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->P()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    int-to-float v2, v2

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->O()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->O()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->L()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x2

    if-eqz v1, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->L()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_2

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    instance-of v1, v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x1

    if-eqz v1, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->L()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput v2, v1, Landroid/widget/RelativeLayout$LayoutParams;->rightMargin:I

    :cond_6
    :goto_2
    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/widget/CompleteSelectView;->c()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->d0()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v1, :cond_8

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget v2, Lcom/luck/picture/lib/R$id;->title_bar:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_8

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto :goto_3

    :cond_7
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    instance-of v1, v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_8

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v4, 0x2

    if-eqz v1, :cond_8

    const/4 v4, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v2}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v2, v1, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    :cond_8
    :goto_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->j0()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_9

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_b

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget v2, Lcom/luck/picture/lib/R$id;->bottom_nar_bar:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x4

    const/4 v3, 0x2

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->i:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x4

    const/4 v3, 0x1

    iput v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->l:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto/16 :goto_4

    :cond_9
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_b

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    instance-of v1, v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v1, :cond_a

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v2}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v2, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_4

    :cond_a
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    instance-of v1, v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v3, 0x5

    move v4, v3

    if-eqz v1, :cond_b

    const/4 v4, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v2}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v2, v1, Landroid/widget/RelativeLayout$LayoutParams;->topMargin:I

    :cond_b
    :goto_4
    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v2, Lcom/luck/picture/lib/d$t;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v2, p0, v0}, Lcom/luck/picture/lib/d$t;-><init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/style/SelectMainStyle;)V

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x4

    return-void
.end method

.method private L1()V
    .locals 5

    const/4 v4, 0x0

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->d()Lcom/luck/picture/lib/style/TitleBarStyle;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->A()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x1

    const/16 v1, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/PreviewTitleBar;->d()V

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Lcom/luck/picture/lib/d$u;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$u;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/TitleBar;->setOnTitleBarListener(Lcom/luck/picture/lib/widget/TitleBar$a;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v2, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, "/"

    const-string v2, "/"

    const/4 v4, 0x7

    const-string v2, "/"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    iget v2, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/TitleBar;->getImageDelete()Landroid/widget/ImageView;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Lcom/luck/picture/lib/d$a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$a;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    const/4 v4, 0x7

    new-instance v1, Lcom/luck/picture/lib/d$b;

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$b;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Lcom/luck/picture/lib/d$c;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$c;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method private M1(Ljava/util/ArrayList;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/d;->y1()Lcom/luck/picture/lib/adapter/c;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/c;->setData(Ljava/util/List;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v1, Lcom/luck/picture/lib/d$v;

    const/4 v2, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v1, p0, v2}, Lcom/luck/picture/lib/d$v;-><init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/d$k;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/c;->g(Lcom/luck/picture/lib/adapter/holder/b$e;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x2

    const/4 v1, 0x4

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->setOrientation(I)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v2, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Landroidx/viewpager2/widget/ViewPager2;->setCurrentItem(IZ)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->h()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-le v0, v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto/16 :goto_2

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v3}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v6, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    move v0, v4

    move v0, v4

    const/4 v6, 0x4

    move v0, v4

    move v0, v4

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v0}, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;->i(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {v3}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v5, 0x2

    invoke-virtual {v0, v4}, Lcom/luck/picture/lib/widget/CompleteSelectView;->setSelectedChange(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/d;->O:Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->registerOnPageChangeCallback(Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    new-instance v2, Landroidx/viewpager2/widget/MarginPageTransformer;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/high16 v4, 0x40400000    # 3.0f

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3, v4}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v2, v3}, Landroidx/viewpager2/widget/MarginPageTransformer;-><init>(I)V

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Landroidx/viewpager2/widget/ViewPager2;->setPageTransformer(Landroidx/viewpager2/widget/ViewPager2$PageTransformer;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Lcom/luck/picture/lib/d;->e(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/d;->U1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void

    :cond_3
    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/d;->S()V

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void
.end method

.method private N1()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method private P1(I)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz p1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v1, Lcom/luck/picture/lib/d$n;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$n;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {p1, v0, v1}, Lq6/c;->a(Landroid/content/Context;Ls6/m;)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v0, Lcom/luck/picture/lib/d$o;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/d$o;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/loader/a;->j(Ls6/m;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget-object v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v1, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-wide v3, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-instance v7, Lcom/luck/picture/lib/d$p;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {v7, p0}, Lcom/luck/picture/lib/d$p;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v6, p1

    move v6, p1

    const/4 v9, 0x1

    move v6, p1

    move v6, p1

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    invoke-interface/range {v1 .. v7}, Lq6/c;->c(Landroid/content/Context;JIILs6/o;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-wide v1, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance v3, Lcom/luck/picture/lib/d$q;

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {v3, p0}, Lcom/luck/picture/lib/d$q;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2, p1, v3}, Lcom/luck/picture/lib/loader/a;->i(JILs6/o;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    return-void
.end method

.method private Q1()V
    .locals 15

    const/4 v14, 0x1

    iget v0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x1

    add-int/lit8 v4, v0, 0x1

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x3

    iput v4, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v13, 0x2

    move v14, v13

    sget-object v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->b1:Lq6/c;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x3

    if-eqz v5, :cond_0

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v6

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x5

    iget-wide v7, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x1

    iget v9, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x2

    iget v11, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x7

    new-instance v12, Lcom/luck/picture/lib/d$r;

    const/4 v13, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-direct {v12, p0}, Lcom/luck/picture/lib/d$r;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    move v10, v11

    move v10, v11

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x5

    invoke-interface/range {v5 .. v12}, Lq6/c;->b(Landroid/content/Context;JIIILs6/o;)V

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x4

    goto :goto_0

    :cond_0
    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x3

    iget-wide v2, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x2

    iget v5, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->A0:I

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x3

    new-instance v6, Lcom/luck/picture/lib/d$s;

    const/4 v14, 0x3

    const/4 v13, 0x3

    invoke-direct {v6, p0}, Lcom/luck/picture/lib/d$s;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v14, 0x6

    const/4 v13, 0x3

    invoke-virtual/range {v1 .. v6}, Lcom/luck/picture/lib/loader/a;->l(JIILs6/o;)V

    :goto_0
    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x3

    return-void
.end method

.method public static R1()Lcom/luck/picture/lib/d;
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Lcom/luck/picture/lib/d;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/luck/picture/lib/d;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method

.method private S1(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->g0()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/adapter/holder/g;->f(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method private T1(ZLcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->g0()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    move v4, v3

    iget-object p1, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget p1, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x2

    if-ne p1, v0, :cond_1

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/adapter/holder/g;->clear()V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/adapter/holder/g;->c(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/luck/picture/lib/adapter/holder/g;->getItemCount()I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    sub-int/2addr p2, v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->smoothScrollToPosition(I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/luck/picture/lib/adapter/holder/g;->i(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_3
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method private V1(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g1:Ls6/e;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    const/4 v4, 0x4

    invoke-interface {v0, p1}, Ls6/e;->a(Lcom/luck/picture/lib/entity/LocalMedia;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->m(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->h(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->p(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$string;->ps_prompt_image_content:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_2

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget v0, Lcom/luck/picture/lib/R$string;->ps_prompt_video_content:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v0, Lcom/luck/picture/lib/R$string;->ps_prompt_audio_content:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v2, Lcom/luck/picture/lib/R$string;->ps_prompt:I

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1, v2, v0}, Lcom/luck/picture/lib/dialog/c;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/luck/picture/lib/dialog/c;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Lcom/luck/picture/lib/d$j;

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {v1, p0, p1}, Lcom/luck/picture/lib/d$j;-><init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/dialog/c;->b(Lcom/luck/picture/lib/dialog/c$a;)V

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method static synthetic W0(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private W1()V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/a;->d(Landroid/app/Activity;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->K0()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    move v2, v1

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/magical/MagicalView;->t()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    :cond_3
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic X0(Lcom/luck/picture/lib/d;Ljava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->D1(Ljava/util/ArrayList;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method private X1()V
    .locals 15

    const/4 v14, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->A:Z

    const/4 v14, 0x7

    if-eqz v0, :cond_0

    const/4 v14, 0x6

    return-void

    :cond_0
    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v14, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getTranslationY()F

    move-result v0

    const/4 v14, 0x5

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    const/4 v14, 0x2

    const/4 v2, 0x0

    const/4 v14, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v14, 0x6

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    const/4 v14, 0x1

    goto :goto_0

    :cond_1
    const/4 v14, 0x6

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v14, 0x0

    new-instance v4, Landroid/animation/AnimatorSet;

    const/4 v14, 0x0

    invoke-direct {v4}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v14, 0x7

    if-eqz v0, :cond_2

    const/4 v14, 0x4

    move v5, v1

    move v5, v1

    move v5, v1

    move v5, v1

    const/4 v14, 0x7

    goto :goto_1

    :cond_2
    const/4 v14, 0x5

    iget-object v5, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v14, 0x5

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v5

    const/4 v14, 0x6

    neg-int v5, v5

    const/4 v14, 0x1

    int-to-float v5, v5

    :goto_1
    const/4 v14, 0x2

    if-eqz v0, :cond_3

    const/4 v14, 0x4

    iget-object v6, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v14, 0x7

    invoke-virtual {v6}, Landroid/view/View;->getHeight()I

    move-result v6

    const/4 v14, 0x5

    neg-int v6, v6

    const/4 v14, 0x7

    int-to-float v6, v6

    const/4 v14, 0x4

    goto :goto_2

    :cond_3
    const/4 v14, 0x1

    move v6, v1

    move v6, v1

    move v6, v1

    move v6, v1

    :goto_2
    const/4 v14, 0x4

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v14, 0x3

    if-eqz v0, :cond_4

    const/4 v14, 0x7

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    const/4 v14, 0x6

    goto :goto_3

    :cond_4
    const/4 v14, 0x0

    move v8, v1

    move v8, v1

    move v8, v1

    move v8, v1

    :goto_3
    const/4 v14, 0x4

    if-eqz v0, :cond_5

    const/4 v14, 0x0

    goto :goto_4

    :cond_5
    const/4 v14, 0x0

    move v1, v7

    move v1, v7

    move v1, v7

    move v1, v7

    :goto_4
    move v7, v2

    move v7, v2

    move v7, v2

    move v7, v2

    :goto_5
    const/4 v14, 0x0

    iget-object v9, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v14, 0x7

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    const/4 v14, 0x2

    if-ge v7, v9, :cond_7

    iget-object v9, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    const/4 v14, 0x7

    check-cast v9, Landroid/view/View;

    const/4 v14, 0x2

    new-array v10, v3, [Landroid/animation/Animator;

    const/4 v14, 0x3

    const/4 v11, 0x2

    const/4 v14, 0x2

    new-array v12, v11, [F

    const/4 v14, 0x6

    aput v8, v12, v2

    const/4 v14, 0x3

    aput v1, v12, v3

    const/4 v14, 0x2

    const-string/jumbo v13, "lhamp"

    const-string/jumbo v13, "lhsap"

    const-string/jumbo v13, "palao"

    const-string v13, "alpha"

    const/4 v14, 0x2

    invoke-static {v9, v13, v12}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v12

    const/4 v14, 0x1

    aput-object v12, v10, v2

    const/4 v14, 0x7

    invoke-virtual {v4, v10}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    const/4 v14, 0x0

    instance-of v10, v9, Lcom/luck/picture/lib/widget/TitleBar;

    const/4 v14, 0x4

    if-eqz v10, :cond_6

    const/4 v14, 0x2

    new-array v10, v3, [Landroid/animation/Animator;

    const/4 v14, 0x3

    new-array v11, v11, [F

    const/4 v14, 0x4

    aput v5, v11, v2

    const/4 v14, 0x3

    aput v6, v11, v3

    const/4 v14, 0x5

    const-string/jumbo v12, "rsaambnYtton"

    const-string/jumbo v12, "snamiYnratto"

    const-string/jumbo v12, "lostnauYiran"

    const-string/jumbo v12, "translationY"

    const/4 v14, 0x1

    invoke-static {v9, v12, v11}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v9

    const/4 v14, 0x5

    aput-object v9, v10, v2

    const/4 v14, 0x1

    invoke-virtual {v4, v10}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    :cond_6
    const/4 v14, 0x5

    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_7
    const/4 v14, 0x0

    const-wide/16 v1, 0x15e

    const-wide/16 v1, 0x15e

    const-wide/16 v1, 0x15e

    const/4 v14, 0x4

    invoke-virtual {v4, v1, v2}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    const/4 v14, 0x7

    invoke-virtual {v4}, Landroid/animation/AnimatorSet;->start()V

    const/4 v14, 0x6

    iput-boolean v3, p0, Lcom/luck/picture/lib/d;->A:Z

    const/4 v14, 0x0

    new-instance v1, Lcom/luck/picture/lib/d$i;

    const/4 v14, 0x6

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$i;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v14, 0x0

    invoke-virtual {v4, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v14, 0x5

    if-eqz v0, :cond_8

    const/4 v14, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->d2()V

    const/4 v14, 0x2

    goto :goto_6

    :cond_8
    invoke-direct {p0}, Lcom/luck/picture/lib/d;->F1()V

    :goto_6
    const/4 v14, 0x1

    return-void
.end method

.method static synthetic Y0(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic Z0(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic a1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic b1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method private b2()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x1

    and-int/2addr v4, v3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->H()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->H()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundColor(I)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x5

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eq v0, v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-lez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->y()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/config/f;->d(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_black:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundColor(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_white:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setBackgroundColor(I)V

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method static synthetic c1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method private c2(III)V
    .locals 12

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2, v1}, Lcom/luck/picture/lib/magical/MagicalView;->A(IIZ)V

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->x:Z

    if-eqz v0, :cond_0

    add-int/lit8 p3, p3, 0x1

    :cond_0
    invoke-static {p3}, Lcom/luck/picture/lib/magical/a;->d(I)Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object p3

    if-eqz p3, :cond_2

    if-eqz p1, :cond_2

    if-nez p2, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    iget v1, p3, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    iget v2, p3, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    iget v3, p3, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    iget v4, p3, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    move v5, p1

    move v5, p1

    move v5, p1

    move v6, p2

    move v6, p2

    move v6, p2

    move v6, p2

    invoke-virtual/range {v0 .. v6}, Lcom/luck/picture/lib/magical/MagicalView;->F(IIIIII)V

    goto :goto_1

    :cond_2
    :goto_0
    iget-object v5, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move v10, p1

    move v10, p1

    move v10, p1

    move v10, p1

    move v11, p2

    move v11, p2

    move v11, p2

    move v11, p2

    invoke-virtual/range {v5 .. v11}, Lcom/luck/picture/lib/magical/MagicalView;->F(IIIIII)V

    :goto_1
    return-void
.end method

.method static synthetic d1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->X1()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method

.method private d2()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    const/4 v4, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-ge v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v2, Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v2, v0}, Landroid/view/View;->setEnabled(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;->getEditor()Landroid/widget/TextView;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v4, 0x3

    return-void
.end method

.method static synthetic e1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic f1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic g1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic h1(Lcom/luck/picture/lib/d;Ljava/util/List;Z)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/d;->E1(Ljava/util/List;Z)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic i1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->V1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic j1(Lcom/luck/picture/lib/d;)Z
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->N1()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    return p0
.end method

.method static synthetic k1(Lcom/luck/picture/lib/d;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->x1(I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic l1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic m1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v0, 0x6

    or-int/2addr v1, v0

    return-object p0
.end method

.method static synthetic n1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic o1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->Q1()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic p1(Lcom/luck/picture/lib/d;III)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/luck/picture/lib/d;->c2(III)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic q1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic r1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->C1()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic s1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic t1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->I0()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic u1(Lcom/luck/picture/lib/d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->z1()V

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic v1(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->S1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic w1(Lcom/luck/picture/lib/d;)Lcom/luck/picture/lib/config/PictureSelectionConfig;
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method private x1(I)V
    .locals 14

    const/4 v13, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x2

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v13, 0x5

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/d;->B1(Lcom/luck/picture/lib/entity/LocalMedia;)[I

    move-result-object v1

    const/4 v13, 0x3

    const/4 v2, 0x0

    const/4 v13, 0x5

    aget v3, v1, v2

    const/4 v13, 0x3

    const/4 v4, 0x1

    aget v5, v1, v4

    const/4 v13, 0x6

    invoke-static {v3, v5}, Lcom/luck/picture/lib/utils/c;->b(II)[I

    move-result-object v3

    const/4 v13, 0x0

    aget v5, v1, v2

    const/4 v13, 0x6

    if-lez v5, :cond_0

    const/4 v13, 0x0

    aget v6, v1, v4

    const/4 v13, 0x0

    if-lez v6, :cond_0

    const/4 v13, 0x3

    invoke-direct {p0, v5, v6, p1}, Lcom/luck/picture/lib/d;->c2(III)V

    const/4 v13, 0x4

    goto :goto_0

    :cond_0
    const/4 v13, 0x4

    sget-object v7, Lcom/luck/picture/lib/config/PictureSelectionConfig;->X0:Lq6/d;

    const/4 v13, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v8

    const/4 v13, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->c()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x1

    aget v10, v3, v2

    const/4 v13, 0x3

    aget v11, v3, v4

    const/4 v13, 0x0

    new-instance v12, Lcom/luck/picture/lib/d$m;

    const/4 v13, 0x3

    invoke-direct {v12, p0, v0, v1, p1}, Lcom/luck/picture/lib/d$m;-><init>(Lcom/luck/picture/lib/d;Lcom/luck/picture/lib/entity/LocalMedia;[II)V

    const/4 v13, 0x1

    invoke-interface/range {v7 .. v12}, Lq6/d;->f(Landroid/content/Context;Ljava/lang/String;IILs6/c;)V

    :goto_0
    const/4 v13, 0x3

    return-void
.end method

.method private z1()V
    .locals 9
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NotifyDataSetChanged"
        }
    .end annotation

    const/4 v8, 0x2

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    move v8, v7

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->g1:Ls6/e;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v0, :cond_2

    const/4 v7, 0x6

    move v8, v7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v0, v1}, Ls6/e;->b(I)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->C1()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    sget v2, Lcom/luck/picture/lib/R$string;->ps_preview_image_num:I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v3, 0x2

    and-int/2addr v8, v3

    const/4 v7, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget v4, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/2addr v4, v5

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    aput-object v4, v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v4, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    aput-object v4, v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0, v2, v3}, Landroidx/fragment/app/Fragment;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/widget/TitleBar;->setTitle(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    iput v1, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget v1, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v6}, Landroidx/viewpager2/widget/ViewPager2;->setCurrentItem(IZ)V

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void
.end method


# virtual methods
.method public B0()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/luck/picture/lib/d;->P:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public H()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->F1()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method protected J1()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->B0:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    new-instance v0, Lcom/luck/picture/lib/loader/d;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/loader/d;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Lcom/luck/picture/lib/loader/b;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lcom/luck/picture/lib/loader/b;-><init>(Landroid/content/Context;Lcom/luck/picture/lib/config/PictureSelectionConfig;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/basic/e;->d:Lcom/luck/picture/lib/loader/a;

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public K()V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->g()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method protected K1(Landroid/view/ViewGroup;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->g0()Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v1, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v1, v2}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->u()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->u()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v5, 0x4

    and-int/2addr v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget v1, Lcom/luck/picture/lib/R$drawable;->ps_preview_gallery_bg:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_0
    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    instance-of v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x3

    move v6, v5

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v0, -0x2

    const/4 v6, 0x6

    const/4 v5, 0x1

    iput v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget v0, Lcom/luck/picture/lib/R$id;->bottom_nar_bar:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput v0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->k:I

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->t:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    iput v1, p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;->v:I

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance p1, Lcom/luck/picture/lib/d$d;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-direct {p1, p0, v0}, Lcom/luck/picture/lib/d$d;-><init>(Lcom/luck/picture/lib/d;Landroid/content/Context;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getItemAnimator()Landroidx/recyclerview/widget/RecyclerView$m;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v0, Landroidx/recyclerview/widget/e0;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/e0;->Y(Z)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getItemDecorationCount()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Lp6/b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/high16 v4, 0x40c00000    # 6.0f

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v3, v4}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const v4, 0x7fffffff

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v2, v4, v3}, Lp6/b;-><init>(II)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$o;)V

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->setOrientation(I)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    if-lez p1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget v2, Lcom/luck/picture/lib/R$anim;->ps_anim_layout_fall_enter:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2}, Landroid/view/animation/AnimationUtils;->loadLayoutAnimation(Landroid/content/Context;I)Landroid/view/animation/LayoutAnimationController;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setLayoutAnimation(Landroid/view/animation/LayoutAnimationController;)V

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p1, Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p1, v0, v2}, Lcom/luck/picture/lib/adapter/holder/g;-><init>(ZLjava/util/List;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v5, 0x0

    move v6, v5

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->S1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v0, Lcom/luck/picture/lib/d$e;

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/d$e;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Lcom/luck/picture/lib/adapter/holder/g;->j(Lcom/luck/picture/lib/adapter/holder/g$c;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-lez p1, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_1

    :cond_5
    const/4 v6, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v0, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance p1, Landroidx/recyclerview/widget/o;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v0, Lcom/luck/picture/lib/d$f;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/d$f;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v6, 0x6

    invoke-direct {p1, v0}, Landroidx/recyclerview/widget/o;-><init>(Landroidx/recyclerview/widget/o$f;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->L:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/o;->b(Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->M:Lcom/luck/picture/lib/adapter/holder/g;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v1, Lcom/luck/picture/lib/d$g;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v1, p0, p1}, Lcom/luck/picture/lib/d$g;-><init>(Lcom/luck/picture/lib/d;Landroidx/recyclerview/widget/o;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/adapter/holder/g;->k(Lcom/luck/picture/lib/adapter/holder/g$d;)V

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void
.end method

.method protected O1(Lcom/luck/picture/lib/entity/LocalMedia;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1
.end method

.method public S()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->W1()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public U1(Lcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->i0()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/SelectMainStyle;->l0()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v1, ""

    const/4 v7, 0x1

    const-string v1, ""

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    and-int/2addr v7, v6

    const/4 v0, 0x0

    or-int/2addr v7, v0

    :goto_0
    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ge v0, v1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    check-cast v1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-nez v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->x()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->x()J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v2, :cond_1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->z()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->y0(I)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->D()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->F0(I)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/luck/picture/lib/entity/LocalMedia;->z()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    return-void
.end method

.method public Y1(IILjava/util/ArrayList;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;Z)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p2, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p4, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 p1, 0x1

    xor-int/2addr v1, p1

    const/4 v0, 0x2

    move v1, v0

    iput-boolean p1, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-boolean p2, p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->K:Z

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public Z1(ZLjava/lang/String;ZIIIJLjava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Ljava/lang/String;",
            "ZIIIJ",
            "Ljava/util/ArrayList<",
            "Lcom/luck/picture/lib/entity/LocalMedia;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p6, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-wide p7, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p9, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput p5, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p4, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/d;->w:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p3, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method protected a2()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v1, Lcom/luck/picture/lib/d$k;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/d$k;-><init>(Lcom/luck/picture/lib/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/magical/MagicalView;->setOnMojitoViewCallback(Lcom/luck/picture/lib/magical/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public e(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/SelectMainStyle;->i0()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/SelectMainStyle;->l0()Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v2, 0x0

    if-ge p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->y0(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public f()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/luck/picture/lib/config/c;->a(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget v0, Lcom/luck/picture/lib/R$layout;->ps_fragment_preview:I

    const/4 v3, 0x2

    return v0
.end method

.method public l(Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-le v0, v1, :cond_3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v0, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->b(Landroid/content/Intent;)Landroid/net/Uri;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x4

    const-string v1, ""

    const-string v1, ""

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->j0(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->h(Landroid/content/Intent;)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->b0(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->e(Landroid/content/Intent;)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->a0(I)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->f(Landroid/content/Intent;)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->c0(I)V

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->g(Landroid/content/Intent;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->d0(I)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->c(Landroid/content/Intent;)F

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->f0(F)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    xor-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->i0(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->d(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->g0(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->n0(Z)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/entity/LocalMedia;->I0(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->g()Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->j0(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->L()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->i0(Z)V

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->M()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->n0(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->g0(Ljava/lang/String;)V

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/entity/LocalMedia;->s()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->I0(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->h(Landroid/content/Intent;)I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->b0(I)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->e(Landroid/content/Intent;)I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->a0(I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->f(Landroid/content/Intent;)I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->c0(I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->g(Landroid/content/Intent;)I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->d0(I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/config/a;->c(Landroid/content/Intent;)F

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Lcom/luck/picture/lib/entity/LocalMedia;->f0(F)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/basic/e;->E(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0, v0, p1}, Lcom/luck/picture/lib/basic/e;->G(Lcom/luck/picture/lib/entity/LocalMedia;Z)I

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/RecyclerView$h;->notifyItemChanged(I)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/d;->S1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    :cond_3
    const/4 v4, 0x7

    return-void
.end method

.method public n(Landroid/os/Bundle;)V
    .locals 5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v0, "ilckru.pepmuoroe.e_pnrub.gcta.tci"

    const-string/jumbo v0, "obrkoprceuu.craeceigtlmup.t.n._ic"

    const/4 v4, 0x0

    const-string/jumbo v0, "relorertqk.utpil.nemipb.cc.guacc_"

    const-string v0, "com.luck.picture.lib.current_page"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v4, 0x6

    const-string/jumbo v0, "upsc.tntcbIctic.b_uobled.me.eurrlckir"

    const-string/jumbo v0, "u.tnrbcI.leitbcecmuoclrd_ubrkcp..iteu"

    const/4 v4, 0x2

    const-string v0, "Iibmilok.rlr.cpnu.ckuudeucrmtectceb.t"

    const-string v0, "com.luck.picture.lib.current_bucketId"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v0, "c.o.oini.rpmcevrollpiuuout_ctpcbetkn_irwrsie."

    const-string/jumbo v0, "iupcoeupukn.e_rtpertollucric.niiiwm.s.tcrbov_"

    const/4 v4, 0x7

    const-string v0, "etrwibioui_olcrnvkeccp..tpitueorim.lpc_sn.rub"

    const-string v0, "com.luck.picture.lib.current_preview_position"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v1, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, "icoyc.uasiultpmidcklbrl.ue_par.emp."

    const-string/jumbo v0, "is.mrdbplak..llepuuaiecctic._mopyra"

    const-string/jumbo v0, "lo.p.mupcycesriclkrtm.ceabda_p.alui"

    const-string v0, "com.luck.picture.lib.display_camera"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string/jumbo v0, "nkruocpqqac_mb.i..tubiuerucem_lt.lrotacl"

    const-string/jumbo v0, "iutcc_pnq_ob.lreareu..mtaiuttbcorculm.lk"

    const/4 v4, 0x5

    const-string/jumbo v0, "mls_ubclertortbcu._palcnitci.lk.mueo.uta"

    const-string v0, "com.luck.picture.lib.current_album_total"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput v0, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v0, "xpcm.lveu.ctepr.eiiueswr_bncktmlrae.i"

    const-string/jumbo v0, "iustr.tlwcxe.rr.epuecipm.kbcel_neivla"

    const/4 v4, 0x4

    const-string v0, ".bilou_ueeeteaorr.rceppcmlwlnitv.x.ik"

    const-string v0, "com.luck.picture.lib.external_preview"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v0, "_pmprbu.tmecewsnrioa.eutdetldllieleiiaxekvcrb_yelp.c"

    const-string/jumbo v0, "lllmdpl.akeuunperaxmipit.vyrr_t.ecebeoetiwc_.elsdiec"

    const/4 v4, 0x2

    const-string/jumbo v0, "rbi_odu..eke.tcelei.masll_lurnepeuwv_etrpidiaepctlxc"

    const-string v0, "com.luck.picture.lib.external_preview_display_delete"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v0, "pieciupp..tombwumt.toccervrlbloo.ie"

    const-string/jumbo v0, "moelow.pvctblibiuekumc.otter.orcp.i"

    const/4 v4, 0x7

    const-string v0, "i_e.rutrq.oie.tvtl.cepuboobpcilkmcw"

    const-string v0, "com.luck.picture.lib.bottom_preview"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, "aesilpkme.u.ac_t.cunbluernb.roi_mmctlru"

    const-string/jumbo v0, "rabk_buto.c.rmeneuc.mrmtbiaun_llpe.ulci"

    const/4 v4, 0x6

    const-string v0, "alcmul..n.b_urlrtaeiktmiupcro.mbmu_ccen"

    const-string v0, "com.luck.picture.lib.current_album_name"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x5

    const-string v1, ""

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/d;->w:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->n()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 12
    .param p1    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-super {p0, p1}, Lcom/luck/picture/lib/basic/e;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->N1()Z

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eqz p1, :cond_3

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-le p1, v0, :cond_3

    const/4 v10, 0x2

    or-int/2addr v11, v10

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    check-cast p1, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/d;->B1(Lcom/luck/picture/lib/entity/LocalMedia;)[I

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-boolean v0, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    const/4 v1, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz v0, :cond_0

    const/4 v10, 0x6

    shr-int/2addr v11, v10

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    add-int/2addr v0, v1

    const/4 v11, 0x3

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v0, p0, Lcom/luck/picture/lib/d;->s:I

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {v0}, Lcom/luck/picture/lib/magical/a;->d(I)Lcom/luck/picture/lib/magical/ViewParams;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v0, :cond_2

    aget v8, p1, v2

    const/4 v11, 0x4

    if-eqz v8, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    aget v9, p1, v1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-nez v9, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_1

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    iget-object v3, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x7

    iget v4, v0, Lcom/luck/picture/lib/magical/ViewParams;->a:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget v5, v0, Lcom/luck/picture/lib/magical/ViewParams;->b:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget v6, v0, Lcom/luck/picture/lib/magical/ViewParams;->c:I

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget v7, v0, Lcom/luck/picture/lib/magical/ViewParams;->d:I

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual/range {v3 .. v9}, Lcom/luck/picture/lib/magical/MagicalView;->F(IIIIII)V

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/magical/MagicalView;->B()V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v10, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v4, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/4 v5, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    aget v8, p1, v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    aget v9, p1, v1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual/range {v3 .. v9}, Lcom/luck/picture/lib/magical/MagicalView;->F(IIIIII)V

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    aget v3, p1, v2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    aget p1, p1, v1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v0, v3, p1, v2}, Lcom/luck/picture/lib/magical/MagicalView;->C(IIZ)V

    :cond_3
    :goto_2
    const/4 v11, 0x5

    return-void
.end method

.method public onCreateAnimation(IZI)Landroid/view/animation/Animation;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->N1()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 p1, 0x5

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->e()Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_3

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v1, v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget p3, v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->c:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget p3, v0, Lcom/luck/picture/lib/style/PictureWindowAnimationStyle;->d:I

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {p1, p3}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->o()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/d;->H()V

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-super {p0, p1, p2, p3}, Lcom/luck/picture/lib/basic/e;->onCreateAnimation(IZI)Landroid/view/animation/Animation;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1
.end method

.method public onDestroy()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/d;->o:Lcom/luck/picture/lib/adapter/c;

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/adapter/c;->a()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/d;->O:Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->unregisterOnPageChangeCallback(Landroidx/viewpager2/widget/ViewPager2$OnPageChangeCallback;)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-super {p0}, Lcom/luck/picture/lib/basic/e;->onDestroy()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 5
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-super {p0, p1}, Lcom/luck/picture/lib/basic/e;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v0, "cule_uugecr.ioplckecti.nam.tbrru."

    const/4 v4, 0x4

    const-string/jumbo v0, "rcmpoot.pk._ctucelceu.iugeinl.arr"

    const-string v0, "com.luck.picture.lib.current_page"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/luck/picture/lib/basic/e;->c:I

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const-string/jumbo v0, "tkebcb.icp.iumuc.r_rdeucttp.lobnIrulc"

    const-string v0, ".et.crcpu.cu.rilectdbIuptr_umkncboile"

    const/4 v4, 0x3

    const-string v0, "cuclp_udiceeotu.kur..bkei.ccrlnmItbur"

    const-string v0, "com.luck.picture.lib.current_bucketId"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/luck/picture/lib/d;->E:J

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v3, 0x7

    and-int/2addr v4, v3

    const-string/jumbo v0, "ionc.rcpeic_n.rot.c.lkqportevupsiueupmle_itrb"

    const-string v0, "_knipurtqlln.erupciic.uocmsbev.toeirectow.r_p"

    const/4 v4, 0x2

    const-string v0, "_tritropqpbc.ioeckiiuplenrwiec.c.u.ts_emuvnlo"

    const-string v0, "com.luck.picture.lib.current_preview_position"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v1, p0, Lcom/luck/picture/lib/d;->s:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v0, "l_st..pittacrc_eanblstcbmeuml.ciuurkuorl"

    const-string/jumbo v0, "ucsupobula.cabr_nlrtcreoit_.eicttkmu.llm"

    const/4 v4, 0x1

    const-string v0, ".ucmbueiitlb._tmrkouor.nematcc.cartl_ulp"

    const-string v0, "com.luck.picture.lib.current_album_total"

    const/4 v4, 0x1

    iget v1, p0, Lcom/luck/picture/lib/d;->B:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v0, "pllroeie_xteu.v.pmune.awlbmieor.cicct"

    const-string/jumbo v0, "metm.iw.v_pelbliarelkupe.iuectccorn.x"

    const/4 v4, 0x6

    const-string v0, "etxreb.bpl.iaeuwlicncr.opte.evru_mlci"

    const-string v0, "com.luck.picture.lib.external_preview"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "lrk_.uueaceetusltnleiepdi.exclmp_._paitcbeiyeovlrr.w"

    const-string v0, "baieorlc.pcr.elairetoe.uewup_meetvcne.xli_pld_siytlk"

    const/4 v4, 0x4

    const-string v0, "extielypnpbvlkcitd._.eeim.airreeealecs.uppcolrtu__lw"

    const-string v0, "com.luck.picture.lib.external_preview_display_delete"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->z:Z

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, "buaclr_mqlicdby.a.e.euociscrlkip.pm"

    const-string/jumbo v0, "om.lkburaecriiamlp.i_desyccb..tcplu"

    const/4 v4, 0x7

    const-string v0, "com.luck.picture.lib.display_camera"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->x:Z

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v0, "ums.lrecbcwtoilpu.ov.ur_t.petieoikb"

    const-string v0, "eowi.ou.o_.utcctrietipb.pkeurlblmcv"

    const/4 v4, 0x1

    const-string v0, ".utmptmwc_eiroe.or.tvccliolmbbeuipk"

    const-string v0, "com.luck.picture.lib.bottom_preview"

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/luck/picture/lib/d;->t:Z

    const/4 v3, 0x5

    and-int/2addr v4, v3

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "p.acoi_utic_bekeulluaotrcrmnrmulenm.p.b"

    const-string v0, "crccnbopkptluiea_ieu_nlum.ctml.baermur."

    const/4 v4, 0x2

    const-string v0, "com.luck.picture.lib.current_album_name"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/d;->w:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/luck/picture/lib/manager/b;->e(Ljava/util/ArrayList;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/basic/e;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Lcom/luck/picture/lib/d;->n(Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/luck/picture/lib/d;->v:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-static {p2}, Lcom/luck/picture/lib/utils/e;->f(Landroid/content/Context;)I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    iput p2, p0, Lcom/luck/picture/lib/d;->C:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/luck/picture/lib/utils/e;->h(Landroid/content/Context;)I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p2, p0, Lcom/luck/picture/lib/d;->D:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget p2, Lcom/luck/picture/lib/R$id;->title_bar:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p2, Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget p2, Lcom/luck/picture/lib/R$id;->ps_tv_selected:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p2, Landroid/widget/TextView;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget p2, Lcom/luck/picture/lib/R$id;->ps_tv_selected_word:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p2, Landroid/widget/TextView;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget p2, Lcom/luck/picture/lib/R$id;->select_click_area:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget p2, Lcom/luck/picture/lib/R$id;->ps_complete_select:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p2, Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v2, 0x5

    const/4 v1, 0x0

    sget p2, Lcom/luck/picture/lib/R$id;->magical:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p2, Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p2, Landroidx/viewpager2/widget/ViewPager2;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p2, v0}, Landroidx/viewpager2/widget/ViewPager2;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget p2, Lcom/luck/picture/lib/R$id;->bottom_nar_bar:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p2, Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p2, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/d;->m:Lcom/luck/picture/lib/magical/MagicalView;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/d;->n:Landroidx/viewpager2/widget/ViewPager2;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p2, v0}, Lcom/luck/picture/lib/magical/MagicalView;->setMagicalContent(Landroid/view/View;)V

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->b2()V

    const/4 v2, 0x1

    new-instance p2, Ljava/util/ArrayList;

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->q:Lcom/luck/picture/lib/widget/PreviewTitleBar;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d;->G:Landroid/widget/TextView;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/d;->H:Landroid/view/View;

    const/4 v1, 0x1

    move v2, v1

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/luck/picture/lib/d;->N:Ljava/util/List;

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->L1()V

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/luck/picture/lib/d;->l:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p2}, Lcom/luck/picture/lib/d;->M1(Ljava/util/ArrayList;)V

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->G1()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/d;->y:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    if-eqz p2, :cond_1

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->A1()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/d;->J1()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->H1()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/d;->K1(Landroid/view/ViewGroup;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/d;->I1()V

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method protected y1()Lcom/luck/picture/lib/adapter/c;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/adapter/c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/luck/picture/lib/adapter/c;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public z(ZLcom/luck/picture/lib/entity/LocalMedia;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/d;->F:Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/d;->p:Lcom/luck/picture/lib/widget/PreviewBottomNavBar;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/widget/BottomNavBar;->h()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/d;->I:Lcom/luck/picture/lib/widget/CompleteSelectView;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/widget/CompleteSelectView;->setSelectedChange(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/luck/picture/lib/d;->U1(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/d;->T1(ZLcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method
