.class public Lcom/luck/picture/lib/widget/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/luck/picture/lib/widget/a$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/widget/b$b;,
        Lcom/luck/picture/lib/widget/b$a;
    }
.end annotation


# instance fields
.field private final a:Lcom/luck/picture/lib/widget/b$a;

.field private b:Lcom/luck/picture/lib/widget/b$b;

.field private c:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/luck/picture/lib/widget/b$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/widget/b;->a:Lcom/luck/picture/lib/widget/b$a;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/widget/b;->b:Lcom/luck/picture/lib/widget/b$b;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method private d(IIZ)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "n s o 4 ~ @@tucd @ ~~KSb~tfo@@@~/ @@.s~v~blro @i~@ ~1@~~M~f@ -l@/ ooo@  @~~~@ iy~ma@ @~@@ b~~~~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/b;->a:Lcom/luck/picture/lib/widget/b$a;

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {v0, p1, p2, p3, v1}, Lcom/luck/picture/lib/widget/b$a;->a(IIZZ)V

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/b;->b:Lcom/luck/picture/lib/widget/b$b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/luck/picture/lib/widget/b$b;->a(I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public b(I)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/b;->a:Lcom/luck/picture/lib/widget/b$a;

    const/4 v5, 0x6

    invoke-interface {v0}, Lcom/luck/picture/lib/widget/b$a;->l()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v5, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/b;->a:Lcom/luck/picture/lib/widget/b$a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    xor-int/2addr v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v1, p1, p1, v2, v3}, Lcom/luck/picture/lib/widget/b$a;->a(IIZZ)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/widget/b;->b:Lcom/luck/picture/lib/widget/b$b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    invoke-interface {v1, p1, v0}, Lcom/luck/picture/lib/widget/b$b;->b(IZ)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    return-void
.end method

.method public c(IIZ)V
    .locals 4

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-gt p1, p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/b;->c:Ljava/util/HashSet;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eq p3, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_1
    const/4 v2, 0x0

    move v3, v2

    invoke-direct {p0, p1, p1, v0}, Lcom/luck/picture/lib/widget/b;->d(IIZ)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public e(Lcom/luck/picture/lib/widget/b$b;)Lcom/luck/picture/lib/widget/b;
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/widget/b;->b:Lcom/luck/picture/lib/widget/b$b;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method
