.class public Lcom/luck/picture/lib/widget/a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/recyclerview/widget/RecyclerView$t;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/widget/a$c;,
        Lcom/luck/picture/lib/widget/a$b;
    }
.end annotation


# instance fields
.field private a:Z

.field private b:I

.field private c:I

.field private d:Z

.field private e:Z

.field private f:I

.field private g:F

.field private h:F

.field private i:I

.field private j:I

.field private k:Lcom/luck/picture/lib/widget/a$c;

.field private l:Landroidx/recyclerview/widget/RecyclerView;

.field private m:Landroid/widget/OverScroller;

.field private final n:Ljava/lang/Runnable;

.field private o:I

.field private p:I

.field private q:I

.field private r:I

.field private s:I

.field private t:I

.field private u:I

.field private v:I

.field private w:Z

.field private x:Z

.field private y:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Lcom/luck/picture/lib/widget/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/widget/a$a;-><init>(Lcom/luck/picture/lib/widget/a;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/widget/a;->n:Ljava/lang/Runnable;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/16 v0, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v3, 0x1

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v3, 0x4

    const/high16 v1, 0x42600000    # 56.0f

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-float/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    float-to-int v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->t:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    or-int/2addr v3, v0

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->u:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->v:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->w:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->x:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/a;->k()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/widget/a;)Landroid/widget/OverScroller;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "u~s@~K@o~ft @  a .@~M bf~@t@~bo@~ly@ ni/~lo~@v~~~@rio~di@-~@@~@@s~S~    ~b~m@ o~@o ~  @c1 @@/  4"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic b(Lcom/luck/picture/lib/widget/a;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget p0, p0, Lcom/luck/picture/lib/widget/a;->f:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic c(Lcom/luck/picture/lib/widget/a;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/widget/a;->l(I)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic d(Lcom/luck/picture/lib/widget/a;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic e(Lcom/luck/picture/lib/widget/a;)Ljava/lang/Runnable;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/luck/picture/lib/widget/a;->n:Ljava/lang/Runnable;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method private f(Landroidx/recyclerview/widget/RecyclerView;FF)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView;->findChildViewUnder(FF)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p2, :cond_0

    const/4 v0, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->getChildAdapterPosition(Landroid/view/View;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p2, p0, Lcom/luck/picture/lib/widget/a;->y:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    sub-int/2addr p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p2, -0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-eq p1, p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget p2, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eq p2, p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/a;->i()V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method private g(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, v0, p2}, Lcom/luck/picture/lib/widget/a;->f(Landroidx/recyclerview/widget/RecyclerView;FF)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private h(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v2, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Landroid/widget/OverScroller;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Landroid/view/animation/LinearInterpolator;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v1}, Landroid/view/animation/LinearInterpolator;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, p1, v1}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private i()V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->b:I

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v1, -0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v0, v1, :cond_a

    const/4 v8, 0x3

    iget v2, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v8, 0x7

    if-ne v2, v1, :cond_1

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget v2, p0, Lcom/luck/picture/lib/widget/a;->b:I

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget v3, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    if-gez v0, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-void

    :cond_2
    const/4 v8, 0x7

    iget v3, p0, Lcom/luck/picture/lib/widget/a;->i:I

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v8, 0x3

    move v7, v4

    move v7, v4

    const/4 v8, 0x7

    if-eq v3, v1, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget v5, p0, Lcom/luck/picture/lib/widget/a;->j:I

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-ne v5, v1, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_1

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-le v0, v3, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v5, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x1

    const/4 v7, 0x3

    add-int/lit8 v6, v0, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {v5, v3, v6, v1}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_0

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-ge v0, v3, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v5, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v7, 0x1

    const/4 v7, 0x7

    sub-int/2addr v3, v4

    const/4 v8, 0x1

    invoke-interface {v5, v0, v3, v4}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    :cond_5
    :goto_0
    const/4 v8, 0x4

    iget v3, p0, Lcom/luck/picture/lib/widget/a;->j:I

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-le v2, v3, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/2addr v3, v4

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {v1, v3, v2, v4}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto :goto_2

    :cond_6
    const/4 v8, 0x5

    const/4 v7, 0x1

    if-ge v2, v3, :cond_9

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    add-int/lit8 v5, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v4, v5, v3, v1}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_2

    :cond_7
    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    sub-int v1, v2, v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-ne v1, v4, :cond_8

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x1

    invoke-interface {v1, v0, v0, v4}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    goto :goto_2

    :cond_8
    const/4 v8, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-interface {v1, v0, v2, v4}, Lcom/luck/picture/lib/widget/a$c;->c(IIZ)V

    :cond_9
    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->i:I

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    iput v2, p0, Lcom/luck/picture/lib/widget/a;->j:I

    :cond_a
    :goto_3
    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void
.end method

.method private j(Landroid/view/MotionEvent;)V
    .locals 7

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    float-to-int v0, v0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->o:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-lt v0, v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    iget v3, p0, Lcom/luck/picture/lib/widget/a;->p:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-gt v0, v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v5, 0x5

    move v6, v5

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v6, 0x5

    const/4 v5, 0x5

    iget p1, p0, Lcom/luck/picture/lib/widget/a;->p:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    int-to-float v1, p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    iget v3, p0, Lcom/luck/picture/lib/widget/a;->o:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    int-to-float v4, v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    sub-float/2addr v1, v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    int-to-float v0, v0

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    int-to-float v4, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    sub-float/2addr v0, v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    sub-float/2addr v1, v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    int-to-float p1, p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    int-to-float v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    sub-float/2addr p1, v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    div-float/2addr v1, p1

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget p1, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    int-to-float p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    mul-float/2addr p1, v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/high16 v0, -0x40800000    # -1.0f

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    mul-float/2addr p1, v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    float-to-int p1, p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->f:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez p1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-boolean v2, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->o()V

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-boolean v3, p0, Lcom/luck/picture/lib/widget/a;->w:Z

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ge v0, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget p1, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    mul-int/lit8 p1, p1, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->f:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez p1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput-boolean v2, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->o()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->q:I

    const/4 v6, 0x5

    if-lt v0, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->r:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gt v0, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v5, 0x4

    move v6, v5

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    int-to-float p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->q:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    int-to-float v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    sub-float/2addr p1, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->r:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    int-to-float v1, v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    int-to-float v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    sub-float/2addr v1, v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    div-float/2addr p1, v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    int-to-float v0, v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    mul-float/2addr v0, p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    float-to-int p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->f:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->e:Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    if-nez p1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-boolean v2, p0, Lcom/luck/picture/lib/widget/a;->e:Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->o()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-boolean v1, p0, Lcom/luck/picture/lib/widget/a;->x:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->r:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-le v0, v1, :cond_3

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget p1, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->f:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v5, 0x1

    move v6, v5

    if-nez p1, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput-boolean v2, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->o()V

    const/4 v6, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 p1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->e:Z

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 p1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->q()V

    :cond_4
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method private k()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/widget/a;->m(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    instance-of v2, v1, Lcom/luck/picture/lib/widget/a$b;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast v1, Lcom/luck/picture/lib/widget/a$b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v2, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Lcom/luck/picture/lib/widget/a$b;->a(I)V

    :cond_0
    const/4 v4, 0x0

    const/4 v1, -0x7

    const/4 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->j:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->e:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x6

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v4, 0x5

    iput v0, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/a;->q()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method private l(I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-lez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    neg-int v0, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p1}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget p1, p0, Lcom/luck/picture/lib/widget/a;->g:F

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    cmpl-float v1, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p0, Lcom/luck/picture/lib/widget/a;->h:F

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    cmpl-float v0, v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, v0, p1, v1}, Lcom/luck/picture/lib/widget/a;->f(Landroidx/recyclerview/widget/RecyclerView;FF)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public m(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public n(I)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->y:I

    const/4 v1, 0x1

    return-object p0
.end method

.method public o()V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-nez v0, :cond_0

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/widget/a;->h(Landroid/content/Context;)V

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v0, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->n:Ljava/lang/Runnable;

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x3

    invoke-virtual {v2}, Landroid/widget/OverScroller;->getCurrY()I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    const/16 v6, 0x1388

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    const v7, 0x186a0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual/range {v2 .. v7}, Landroid/widget/OverScroller;->startScroll(IIIII)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->n:Ljava/lang/Runnable;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v0, v1}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    return-void
.end method

.method public onInterceptTouchEvent(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)Z
    .locals 4
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->a:Z

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemCount()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p2, :cond_1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p2, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/a;->k()V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget p2, p0, Lcom/luck/picture/lib/widget/a;->u:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput p2, p0, Lcom/luck/picture/lib/widget/a;->o:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v0, p0, Lcom/luck/picture/lib/widget/a;->t:I

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/2addr p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput p2, p0, Lcom/luck/picture/lib/widget/a;->p:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget p2, p0, Lcom/luck/picture/lib/widget/a;->v:I

    const/4 v3, 0x4

    add-int v1, p1, p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    sub-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v1, p0, Lcom/luck/picture/lib/widget/a;->q:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/2addr p1, p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->r:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1

    :cond_2
    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p1
.end method

.method public onRequestDisallowInterceptTouchEvent(Z)V
    .locals 2

    const/4 v1, 0x7

    return-void
.end method

.method public onTouchEvent(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)V
    .locals 4
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->a:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/a;->k()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eq v0, v1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 p1, 0x3

    and-int/2addr v3, p1

    const/4 v2, 0x7

    move v3, v2

    if-eq v0, p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p1, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq v0, p1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->d:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/a;->e:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/widget/a;->g(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/MotionEvent;)V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p2}, Lcom/luck/picture/lib/widget/a;->j(Landroid/view/MotionEvent;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/a;->k()V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public p(I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/luck/picture/lib/widget/a;->m(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->i:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->j:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    instance-of v1, v0, Lcom/luck/picture/lib/widget/a$b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v0, Lcom/luck/picture/lib/widget/a$b;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lcom/luck/picture/lib/widget/a$b;->b(I)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public q()V
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/widget/OverScroller;->isFinished()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a;->n:Ljava/lang/Runnable;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a;->m:Landroid/widget/OverScroller;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public r(I)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->v:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public s(I)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x2

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->s:I

    const/4 v1, 0x6

    return-object p0
.end method

.method public t(Z)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->w:Z

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public u(Z)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/a;->x:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public v(Lcom/luck/picture/lib/widget/a$c;)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/luck/picture/lib/widget/a;->k:Lcom/luck/picture/lib/widget/a$c;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method public w(I)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->u:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public x(I)Lcom/luck/picture/lib/widget/a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/luck/picture/lib/widget/a;->t:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method
