.class public Lcom/luck/picture/lib/widget/TitleBar;
.super Landroid/widget/RelativeLayout;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/widget/TitleBar$a;
    }
.end annotation


# instance fields
.field protected a:Landroid/widget/RelativeLayout;

.field protected b:Landroid/widget/ImageView;

.field protected c:Landroid/widget/ImageView;

.field protected d:Landroid/widget/ImageView;

.field protected e:Lcom/luck/picture/lib/widget/MarqueeTextView;

.field protected f:Landroid/widget/TextView;

.field protected g:Landroid/view/View;

.field protected h:Landroid/view/View;

.field protected i:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field protected j:Landroid/view/View;

.field protected k:Landroid/widget/RelativeLayout;

.field protected l:Lcom/luck/picture/lib/widget/TitleBar$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-direct {p0, p1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/TitleBar;->c()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/TitleBar;->c()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/TitleBar;->c()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "lms-nc~Ma@ ot~ @bbo@~@~  ry o ~@o~~o@/ .@@~K~@@@@ ~@ ~f ~@@~Sl ov~i~@ i~@~ u1~~4 /@i f~@st d @b~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method

.method protected b()V
    .locals 4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget v1, Lcom/luck/picture/lib/R$layout;->ps_title_bar:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method protected c()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/TitleBar;->b()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->top_status_bar:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->j:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->rl_title_bar:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Landroid/widget/RelativeLayout;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->k:Landroid/widget/RelativeLayout;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget v0, Lcom/luck/picture/lib/R$id;->ps_iv_left_back:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Landroid/widget/ImageView;

    const/4 v2, 0x5

    move v3, v2

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->b:Landroid/widget/ImageView;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget v0, Lcom/luck/picture/lib/R$id;->ps_rl_album_bg:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Landroid/widget/RelativeLayout;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->ps_iv_delete:I

    const/4 v2, 0x7

    and-int/2addr v3, v2

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->d:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->ps_rl_album_click:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->h:Landroid/view/View;

    const/4 v3, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_title:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    sget v0, Lcom/luck/picture/lib/R$id;->ps_iv_arrow:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->c:Landroid/widget/ImageView;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_cancel:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->title_bar_line:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->b:Landroid/widget/ImageView;

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->k:Landroid/widget/RelativeLayout;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->h:Landroid/view/View;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->i:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/TitleBar;->a()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public d()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->i:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->J:Z

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->j:Landroid/view/View;

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/e;->j(Landroid/content/Context;)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->d()Lcom/luck/picture/lib/style/TitleBarStyle;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->h()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    move v6, v5

    iget-object v2, p0, Lcom/luck/picture/lib/widget/TitleBar;->k:Landroid/widget/RelativeLayout;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput v1, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->k:Landroid/widget/RelativeLayout;

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/high16 v3, 0x42400000    # 48.0f

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v2, v3}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x5

    move v5, v2

    move v5, v2

    const/4 v6, 0x6

    const/16 v3, 0x8

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->y()Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->i()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->i()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_3
    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->g()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v4, :cond_4

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->u()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v4, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->b:Landroid/widget/ImageView;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->r()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v4, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->w()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v4, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    int-to-float v1, v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_7
    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->v()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v4, :cond_8

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->i:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->L0:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v1, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->c:Landroid/widget/ImageView;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    sget v4, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_2

    :cond_9
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->s()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v4, :cond_a

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->c:Landroid/widget/ImageView;

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_a
    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->e()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v4, :cond_b

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v4, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v4, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_b
    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->z()Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_c

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto/16 :goto_3

    :cond_c
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v5, 0x7

    and-int/2addr v6, v5

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->k()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v2, :cond_d

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_d
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->n()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v2, :cond_e

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_e
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->o()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v2, :cond_f

    const/4 v5, 0x7

    move v6, v5

    iget-object v2, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_f
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->q()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v2, :cond_10

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v6, 0x0

    const/4 v5, 0x0

    int-to-float v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_10
    :goto_3
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->a()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    if-eqz v1, :cond_11

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->d:Landroid/widget/ImageView;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_4

    :cond_11
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->d:Landroid/widget/ImageView;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget v1, Lcom/luck/picture/lib/R$drawable;->ps_ic_delete:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_4
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void
.end method

.method public getImageArrow()Landroid/widget/ImageView;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->c:Landroid/widget/ImageView;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getImageDelete()Landroid/widget/ImageView;
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->d:Landroid/widget/ImageView;

    return-object v0
.end method

.method public getTitleBarLine()Landroid/view/View;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->g:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTitleCancelView()Landroid/widget/TextView;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v2, 0x0

    return-object v0
.end method

.method public getTitleText()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/widget/AppCompatTextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget v0, Lcom/luck/picture/lib/R$id;->ps_iv_left_back:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p1, v0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_cancel:I

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    goto :goto_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget v0, Lcom/luck/picture/lib/R$id;->ps_rl_album_bg:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p1, v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->ps_rl_album_click:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    if-ne p1, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget v0, Lcom/luck/picture/lib/R$id;->rl_title_bar:I

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-ne p1, v0, :cond_4

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/TitleBar;->l:Lcom/luck/picture/lib/widget/TitleBar$a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_4

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/widget/TitleBar$a;->c()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_2

    :cond_2
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/TitleBar;->l:Lcom/luck/picture/lib/widget/TitleBar$a;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1, p0}, Lcom/luck/picture/lib/widget/TitleBar$a;->b(Landroid/view/View;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/widget/TitleBar;->l:Lcom/luck/picture/lib/widget/TitleBar$a;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/widget/TitleBar$a;->a()V

    :cond_4
    :goto_2
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public setOnTitleBarListener(Lcom/luck/picture/lib/widget/TitleBar$a;)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/luck/picture/lib/widget/TitleBar;->l:Lcom/luck/picture/lib/widget/TitleBar$a;

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->e:Lcom/luck/picture/lib/widget/MarqueeTextView;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method
