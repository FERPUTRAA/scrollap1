.class public Lcom/luck/picture/lib/widget/CompleteSelectView;
.super Landroid/widget/LinearLayout;


# instance fields
.field private a:Landroid/widget/TextView;

.field private b:Landroid/widget/TextView;

.field private c:Landroid/view/animation/Animation;

.field private d:Lcom/luck/picture/lib/config/PictureSelectionConfig;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/CompleteSelectView;->b()V

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/CompleteSelectView;->b()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/CompleteSelectView;->b()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method private b()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/CompleteSelectView;->a()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_select_num:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_complete:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/16 v0, 0x10

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget v1, Lcom/luck/picture/lib/R$anim;->ps_anim_modal_in:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {v0, v1}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->c:Landroid/view/animation/Animation;

    const/4 v2, 0x6

    move v3, v2

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method protected a()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget v1, Lcom/luck/picture/lib/R$layout;->ps_complete_selected_layout:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public c()V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->T()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->T()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->U()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x2

    if-eqz v3, :cond_2

    const/4 v7, 0x5

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->e(Ljava/lang/String;)Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v3, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v4, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    aput-object v5, v4, v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v5, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget v5, v5, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v6, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    aput-object v5, v4, v6

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    :goto_0
    const/4 v8, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->W()I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v2}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v3, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v3, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    int-to-float v2, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->V()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v2, :cond_4

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->b()Lcom/luck/picture/lib/style/BottomNavBarStyle;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->z()Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v1, :cond_7

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->w()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v2, :cond_5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_5
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->y()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    if-eqz v2, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v8, 0x3

    int-to-float v1, v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_6
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->x()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v1, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_7
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-void
.end method

.method public setSelectedChange(Z)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->c()Lcom/luck/picture/lib/style/SelectMainStyle;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v3, 0x2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/16 v4, 0x8

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v5, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v6, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    if-lez v2, :cond_9

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p0, v6}, Landroid/view/View;->setEnabled(Z)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->S()I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v9, 0x2

    sget p1, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->Y()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v2, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->e(Ljava/lang/String;)Z

    move-result v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v7

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x0

    aput-object v7, v3, v5

    const/4 v9, 0x6

    iget-object v7, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget v7, v7, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v9, 0x4

    const/4 v8, 0x0

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    aput-object v7, v3, v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_1

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget v3, Lcom/luck/picture/lib/R$string;->ps_completed:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->a0()I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v2, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    int-to-float p1, p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->Z()I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v1, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto :goto_2

    :cond_4
    const/4 v8, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_fa632d:I

    invoke-static {v1, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->b()Lcom/luck/picture/lib/style/BottomNavBarStyle;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->z()Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz p1, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eq p1, v4, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v0, 0x4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-ne p1, v0, :cond_6

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz p1, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto/16 :goto_7

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/t;->l(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->c:Landroid/view/animation/Animation;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto/16 :goto_7

    :cond_8
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto/16 :goto_7

    :cond_9
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz p1, :cond_c

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->d0()Z

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    if-eqz p1, :cond_c

    const/4 v8, 0x2

    and-int/2addr v9, v8

    invoke-virtual {p0, v6}, Landroid/view/View;->setEnabled(Z)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->S()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v0, :cond_a

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_3

    :cond_a
    sget p1, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_3
    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->Z()I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v0, :cond_b

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto/16 :goto_5

    :cond_b
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_9b:I

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v0, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_5

    :cond_c
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p0, v5}, Landroid/view/View;->setEnabled(Z)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->T()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v0, :cond_d

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_4

    :cond_d
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    sget p1, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    :goto_4
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->V()I

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v0, :cond_e

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_5

    :cond_e
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    sget v2, Lcom/luck/picture/lib/R$color;->ps_color_9b:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v0, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_5
    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->a:Landroid/widget/TextView;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->U()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v0, :cond_10

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->e(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v0, :cond_f

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v8, 0x7

    and-int/2addr v9, v8

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    aput-object v3, v2, v5

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget v3, v3, Lcom/luck/picture/lib/config/PictureSelectionConfig;->k:I

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v9, 0x6

    aput-object v3, v2, v6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {p1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_6

    :cond_f
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto :goto_6

    :cond_10
    const/4 v8, 0x5

    const/4 v8, 0x4

    iget-object p1, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    sget v2, Lcom/luck/picture/lib/R$string;->ps_please_select:I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_6
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/luck/picture/lib/style/SelectMainStyle;->W()I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v0, :cond_11

    const/4 v9, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/CompleteSelectView;->b:Landroid/widget/TextView;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    int-to-float p1, p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_11
    :goto_7
    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    return-void
.end method
