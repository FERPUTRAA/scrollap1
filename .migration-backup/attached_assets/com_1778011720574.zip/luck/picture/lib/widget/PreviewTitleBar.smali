.class public Lcom/luck/picture/lib/widget/PreviewTitleBar;
.super Lcom/luck/picture/lib/widget/TitleBar;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/luck/picture/lib/widget/TitleBar;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/luck/picture/lib/widget/TitleBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0, p1, p2, p3}, Lcom/luck/picture/lib/widget/TitleBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public d()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~sd~ o t@ @/afnisbv.@~ /  l~ ~@@@~4u@o~@-~~@@~t~K~o~~ ~ m @@ @ 1i@  ~ @fo~Sobi~b~l@@Mo~~~@y@cr "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-super {p0}, Lcom/luck/picture/lib/widget/TitleBar;->d()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->d()Lcom/luck/picture/lib/style/TitleBarStyle;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->c()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->c()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->g()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->g()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->u()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->b:Landroid/widget/ImageView;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->u()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->d()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/widget/TitleBar;->b:Landroid/widget/ImageView;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/TitleBarStyle;->d()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_3
    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v1, 0x0

    move v3, v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->h:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v1, 0x11

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->removeRule(I)V

    const/4 v3, 0x3

    const/16 v1, 0xe

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget v1, Lcom/luck/picture/lib/R$drawable;->ps_ic_trans_1px:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->f:Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/16 v1, 0x8

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->c:Landroid/widget/ImageView;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/TitleBar;->h:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
