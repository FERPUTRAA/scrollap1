.class public Lcom/luck/picture/lib/widget/BottomNavBar;
.super Landroid/widget/RelativeLayout;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/luck/picture/lib/widget/BottomNavBar$b;
    }
.end annotation


# instance fields
.field protected a:Landroid/widget/TextView;

.field protected b:Landroid/widget/TextView;

.field private c:Landroid/widget/CheckBox;

.field protected d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

.field protected e:Lcom/luck/picture/lib/widget/BottomNavBar$b;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->e()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->e()V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->e()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic a(Lcom/luck/picture/lib/widget/BottomNavBar;)Landroid/widget/CheckBox;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@bsm~n@@a@@t d  ~~.~u4@lK @trfli@@ ~Mo~@ o  ~-y~ ~~@@@~@~~~fS@ v/@ ~o@~  ~c@i~@o  ~ ~/@o1bs ~bi~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method private b()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v0, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v0, 0x0

    move v9, v0

    const/4 v8, 0x0

    and-int/2addr v9, v8

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v9, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    move v3, v0

    move v3, v0

    move-wide v4, v1

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-ge v3, v6, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->o()Ljava/util/ArrayList;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    check-cast v6, Lcom/luck/picture/lib/entity/LocalMedia;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v6}, Lcom/luck/picture/lib/entity/LocalMedia;->G()J

    move-result-wide v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    add-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    cmp-long v1, v4, v1

    const/4 v9, 0x1

    if-lez v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v1, 0x2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v4, v5, v1}, Lcom/luck/picture/lib/utils/k;->i(JI)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    sget v4, Lcom/luck/picture/lib/R$string;->ps_original_image:I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v5, 0x1

    move v9, v5

    const/4 v8, 0x6

    shl-int/2addr v9, v8

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    aput-object v1, v5, v0

    const/4 v9, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    sget v2, Lcom/luck/picture/lib/R$string;->ps_default_original_image:I

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto :goto_1

    :cond_2
    const/4 v8, 0x7

    move v9, v8

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    sget v2, Lcom/luck/picture/lib/R$string;->ps_default_original_image:I

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void
.end method


# virtual methods
.method protected c()V
    .locals 2

    const/4 v1, 0x0

    return-void
.end method

.method protected d()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget v1, Lcom/luck/picture/lib/R$layout;->ps_bottom_nav_bar:I

    const/4 v3, 0x2

    invoke-static {v0, v1, p0}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method protected e()V
    .locals 4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->d()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/PictureSelectionConfig;->d()Lcom/luck/picture/lib/config/PictureSelectionConfig;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_preview:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_editor:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->b:Landroid/widget/TextView;

    const/4 v2, 0x6

    move v3, v2

    sget v0, Lcom/luck/picture/lib/R$id;->cb_original:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    check-cast v0, Landroid/widget/CheckBox;

    const/4 v3, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->b:Landroid/widget/TextView;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget v1, Lcom/luck/picture/lib/R$color;->ps_color_grey:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    new-instance v1, Lcom/luck/picture/lib/widget/BottomNavBar$a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/widget/BottomNavBar$a;-><init>(Lcom/luck/picture/lib/widget/BottomNavBar;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->c()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public f()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c:Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/16 v0, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->b()Lcom/luck/picture/lib/style/BottomNavBarStyle;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->T0:Z

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Landroid/widget/CompoundButton;->setButtonDrawable(I)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    int-to-float v1, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_3
    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_4

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->g()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v2, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput v1, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_5
    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/high16 v3, 0x42380000    # 46.0f

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v2, v3}, Lcom/luck/picture/lib/utils/e;->a(Landroid/content/Context;F)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->e()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v2, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_7
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->s()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v2, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v5, 0x2

    int-to-float v1, v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_8
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v2, :cond_9

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_9
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->a()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_a

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->b:Landroid/widget/TextView;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_a
    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->d()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_b

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->b:Landroid/widget/TextView;

    const/4 v4, 0x0

    and-int/2addr v5, v4

    int-to-float v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_b
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->c()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_c

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->b:Landroid/widget/TextView;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_c
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->h()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_d

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2, v1}, Landroid/widget/CompoundButton;->setButtonDrawable(I)V

    :cond_d
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->i()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v2, :cond_e

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_e
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->n()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->b(I)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_f

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x5

    int-to-float v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    :cond_f
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->k()I

    move-result v0

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_10

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_10
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->c:Landroid/widget/CheckBox;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-boolean v1, v1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public h()V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/widget/BottomNavBar;->b()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->c1:Lcom/luck/picture/lib/style/a;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/a;->b()Lcom/luck/picture/lib/style/BottomNavBarStyle;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-lez v1, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->v()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v4, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    sget v5, Lcom/luck/picture/lib/R$color;->ps_color_fa632d:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v4, v5}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->u()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v7, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    aput-object v4, v3, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto/16 :goto_2

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget v4, Lcom/luck/picture/lib/R$string;->ps_preview_num:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    aput-object v5, v3, v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v4, v3}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto/16 :goto_2

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->r()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v1}, Lcom/luck/picture/lib/utils/r;->c(I)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v2, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_1

    :cond_4
    const/4 v6, 0x2

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget v3, Lcom/luck/picture/lib/R$color;->ps_color_9b:I

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v2, v3}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/luck/picture/lib/style/BottomNavBarStyle;->q()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/utils/r;->f(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v1, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_2

    :cond_5
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->a:Landroid/widget/TextView;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget v2, Lcom/luck/picture/lib/R$string;->ps_preview:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->e:Lcom/luck/picture/lib/widget/BottomNavBar$b;

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    sget v0, Lcom/luck/picture/lib/R$id;->ps_tv_preview:I

    const/4 v2, 0x4

    if-ne p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->e:Lcom/luck/picture/lib/widget/BottomNavBar$b;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/luck/picture/lib/widget/BottomNavBar$b;->d()V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setOnBottomNavBarListener(Lcom/luck/picture/lib/widget/BottomNavBar$b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar;->e:Lcom/luck/picture/lib/widget/BottomNavBar$b;

    const/4 v1, 0x4

    return-void
.end method
