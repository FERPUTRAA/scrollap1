.class public Lcom/luck/picture/lib/widget/RecyclerPreloadView;
.super Landroidx/recyclerview/widget/RecyclerView;


# static fields
.field private static final i:Ljava/lang/String; = "RecyclerPreloadView"

.field private static final j:I = 0x1

.field public static final k:I = 0x2

.field private static final l:I = 0x96


# instance fields
.field private a:Z

.field private b:Z

.field private c:I

.field private d:I

.field private e:I

.field private f:Ls6/r;

.field private g:Ls6/t;

.field private h:Ls6/s;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->e:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroidx/recyclerview/widget/RecyclerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 p1, 0x6

    const/4 p1, 0x1

    const/4 v0, 0x0

    or-int/2addr v1, v0

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method private setLayoutManagerPosition(Landroidx/recyclerview/widget/RecyclerView$p;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "KSso~~@@~~ ~~oo/@ o~y l-@l @~b~ft @a  @@~~~@@@@~@i b@ ~md@~ r/vo tic~b4Mu.1~ofi @~ ~@s n~@ ~ ~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    instance-of v0, p1, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    check-cast p1, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->c:I

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    instance-of v0, p1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findFirstVisibleItemPosition()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->d:I

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public b()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public getFirstVisiblePosition()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public getLastVisiblePosition()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    return v0
.end method

.method public onScrollStateChanged(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->onScrollStateChanged(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-ne p1, v0, :cond_1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setLayoutManagerPosition(Landroidx/recyclerview/widget/RecyclerView$p;)V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->h:Ls6/s;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ls6/s;->a(I)V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->g:Ls6/t;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p1}, Ls6/t;->a()V

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public onScrolled(II)V
    .locals 7

    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->onScrolled(II)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->setLayoutManagerPosition(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->f:Ls6/r;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-boolean v1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v6, 0x0

    if-eqz v1, :cond_4

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    instance-of v2, v0, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v5, 0x2

    move v6, v5

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v0, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView$h;->getItemCount()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager;->getSpanCount()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    div-int/2addr v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->findLastVisibleItemPosition()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/GridLayoutManager;->getSpanCount()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    div-int/2addr v2, v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->e:I

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    sub-int/2addr v1, v0

    const/4 v6, 0x1

    if-lt v2, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    move v0, v3

    move v0, v3

    const/4 v6, 0x5

    move v0, v3

    move v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    move v0, v4

    move v0, v4

    const/4 v6, 0x3

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput-boolean v4, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-boolean v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->f:Ls6/r;

    const/4 v6, 0x7

    invoke-interface {v0}, Ls6/r;->A()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lez p2, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-boolean v3, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez p2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-boolean v4, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->a:Z

    const/4 v6, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string p2, "!ipmt,ca tsslAeedeklie ualnhcrsP"

    const-string p2, "elsleaaespd,h iAt iresun tlckc!P"

    const/4 v6, 0x7

    const-string p2, " ccnoh,lr eP eli le!euaskpatditA"

    const-string p2, "Adapter is null,Please check it!"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    throw p1

    :cond_4
    :goto_1
    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->h:Ls6/s;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v0, p1, p2}, Ls6/s;->b(II)V

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->g:Ls6/t;

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz p1, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/16 p2, 0x96

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-ge p1, p2, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->g:Ls6/t;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {p1}, Ls6/t;->a()V

    const/4 v6, 0x5

    goto :goto_2

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->g:Ls6/t;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-interface {p1}, Ls6/t;->b()V

    :cond_7
    :goto_2
    const/4 v6, 0x6

    return-void

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const-string p2, "a,uilbeaal yn  h asmcionlugPtL!ekesMre"

    const-string p2, "e gmlLa aaleMPseyikclcuahsuo nit,rn !e"

    const/4 v6, 0x6

    const-string p2, "er ,iyun l ehssntaocMeualL agac!uPtikl"

    const-string p2, "LayoutManager is null,Please check it!"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    throw p1
.end method

.method public setEnabledLoadMore(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->b:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public setLastVisiblePosition(I)V
    .locals 2

    const/4 v1, 0x7

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public setOnRecyclerViewPreloadListener(Ls6/r;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->f:Ls6/r;

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public setOnRecyclerViewScrollListener(Ls6/s;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->h:Ls6/s;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public setOnRecyclerViewScrollStateListener(Ls6/t;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->g:Ls6/t;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public setReachBottomRow(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ge p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    move p1, v0

    move p1, v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p1, p0, Lcom/luck/picture/lib/widget/RecyclerPreloadView;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method
