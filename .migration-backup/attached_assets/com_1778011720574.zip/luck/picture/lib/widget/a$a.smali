.class Lcom/luck/picture/lib/widget/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/luck/picture/lib/widget/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/widget/a;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/widget/a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@Mf~~/n@rS @~y@Ko@ot@m ~ ~~-@ ~ ~i f~@o   @c~ sd~b@@~~@ b~oab@/@~lo~~t.@~@o@~1 @@   u~i~4l @i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/luck/picture/lib/widget/a;->a(Lcom/luck/picture/lib/widget/a;)Landroid/widget/OverScroller;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/widget/a;->a(Lcom/luck/picture/lib/widget/a;)Landroid/widget/OverScroller;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/luck/picture/lib/widget/a;->b(Lcom/luck/picture/lib/widget/a;)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {v0, v1}, Lcom/luck/picture/lib/widget/a;->c(Lcom/luck/picture/lib/widget/a;I)V

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/luck/picture/lib/widget/a;->d(Lcom/luck/picture/lib/widget/a;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/luck/picture/lib/widget/a$a;->a:Lcom/luck/picture/lib/widget/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/luck/picture/lib/widget/a;->e(Lcom/luck/picture/lib/widget/a;)Ljava/lang/Runnable;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method
