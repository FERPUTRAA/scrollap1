.class Lcom/luck/picture/lib/widget/BottomNavBar$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/widget/BottomNavBar;->e()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/widget/BottomNavBar;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/widget/BottomNavBar;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar$a;->a:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~fs@~o@s~ l~~l~@~4/Ma~@@@ vc/m@~oKn @~Sy o~   @o.i@ ~o~ @di  b~u~f@@~1b@it@~-@ o~t~b   @~r~~ @ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar$a;->a:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p1, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x2

    iput-boolean p2, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/widget/BottomNavBar;->a(Lcom/luck/picture/lib/widget/BottomNavBar;)Landroid/widget/CheckBox;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/widget/BottomNavBar$a;->a:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, v0, Lcom/luck/picture/lib/widget/BottomNavBar;->d:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-boolean v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->R:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar$a;->a:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/luck/picture/lib/widget/BottomNavBar;->e:Lcom/luck/picture/lib/widget/BottomNavBar$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/luck/picture/lib/widget/BottomNavBar$b;->a()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/luck/picture/lib/manager/b;->m()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/luck/picture/lib/widget/BottomNavBar$a;->a:Lcom/luck/picture/lib/widget/BottomNavBar;

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object p1, p1, Lcom/luck/picture/lib/widget/BottomNavBar;->e:Lcom/luck/picture/lib/widget/BottomNavBar$b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/luck/picture/lib/widget/BottomNavBar$b;->c()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
