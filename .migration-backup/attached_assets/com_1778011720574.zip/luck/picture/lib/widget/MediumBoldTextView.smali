.class public Lcom/luck/picture/lib/widget/MediumBoldTextView;
.super Landroidx/appcompat/widget/AppCompatTextView;


# instance fields
.field private a:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/widget/MediumBoldTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, v0}, Lcom/luck/picture/lib/widget/MediumBoldTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const v0, 0x3f19999a    # 0.6f

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/luck/picture/lib/widget/MediumBoldTextView;->a:F

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/luck/picture/lib/R$styleable;->PictureMediumBoldTextView:[I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1, p2, v0, p3, v1}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    sget p2, Lcom/luck/picture/lib/R$styleable;->PictureMediumBoldTextView_stroke_Width:I

    const/4 v3, 0x5

    iget p3, p0, Lcom/luck/picture/lib/widget/MediumBoldTextView;->a:F

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p2, p0, Lcom/luck/picture/lib/widget/MediumBoldTextView;->a:F

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~us~/~~@@@d@1  ~o@ fi~n /~~ ~b@~t@@@S~- @ioc ~@ @  bsl K~4~ o@m.lfo~@@@ y~ir oov~  @b@a@~~~@~Mt~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v2, p0, Lcom/luck/picture/lib/widget/MediumBoldTextView;->a:F

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    cmpl-float v1, v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-super {p0, p1}, Landroid/widget/TextView;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method public setStrokeWidth(F)V
    .locals 2

    const/4 v1, 0x3

    iput p1, p0, Lcom/luck/picture/lib/widget/MediumBoldTextView;->a:F

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method
