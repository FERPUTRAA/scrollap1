.class public Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;
.super Landroid/widget/RelativeLayout;


# instance fields
.field private final a:Landroid/graphics/Path;

.field private final b:F

.field private final c:Z

.field private final d:Z

.field private final e:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 4

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Landroid/graphics/RectF;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->e:Landroid/graphics/RectF;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/luck/picture/lib/R$styleable;->PictureRoundCornerRelativeLayout:[I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, p2, v0, p3, v1}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget p2, Lcom/luck/picture/lib/R$styleable;->PictureRoundCornerRelativeLayout_corners:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 p3, 0x4

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->b:F

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget p2, Lcom/luck/picture/lib/R$styleable;->PictureRoundCornerRelativeLayout_topNormal:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-boolean p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->c:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget p2, Lcom/luck/picture/lib/R$styleable;->PictureRoundCornerRelativeLayout_bottomNormal:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, p2, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->d:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance p1, Landroid/graphics/Path;

    const/4 v3, 0x6

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ".~ss4lb@/~@@@~~~no@ o  vt@b i@@ ~M-t~ @l~@@i @~o1@~ ~~~o K~fcmyf@~@u@@ @~@odr  o  ~~ Sb~~~~ai@/ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroid/widget/RelativeLayout;->dispatchDraw(Landroid/graphics/Canvas;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 11

    const/4 v10, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/RelativeLayout;->onSizeChanged(IIII)V

    const/4 v10, 0x3

    iget-object p3, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    const/4 v10, 0x2

    invoke-virtual {p3}, Landroid/graphics/Path;->reset()V

    iget-object p3, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->e:Landroid/graphics/RectF;

    const/4 v10, 0x6

    int-to-float p1, p1

    const/4 v10, 0x7

    iput p1, p3, Landroid/graphics/RectF;->right:F

    const/4 v10, 0x0

    int-to-float p1, p2

    const/4 v10, 0x1

    iput p1, p3, Landroid/graphics/RectF;->bottom:F

    const/4 v10, 0x6

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->c:Z

    const/4 v10, 0x5

    if-nez p1, :cond_0

    const/4 v10, 0x6

    iget-boolean p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->d:Z

    if-nez p2, :cond_0

    const/4 v10, 0x6

    iget-object p1, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    const/4 v10, 0x5

    iget p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->b:F

    const/4 v10, 0x7

    sget-object p4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v10, 0x5

    invoke-virtual {p1, p3, p2, p2, p4}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 p2, 0x7

    const/4 v10, 0x7

    const/4 p4, 0x6

    const/4 v10, 0x5

    const/4 v0, 0x5

    const/4 v10, 0x4

    const/4 v1, 0x4

    const/4 v10, 0x5

    const/4 v2, 0x3

    const/4 v10, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    or-int/2addr v10, v4

    const/4 v5, 0x0

    shr-int/2addr v10, v5

    const/16 v6, 0x8

    const/4 v10, 0x2

    const/4 v7, 0x0

    const/4 v10, 0x2

    if-eqz p1, :cond_1

    const/4 v10, 0x3

    new-array p1, v6, [F

    const/4 v10, 0x2

    aput v7, p1, v5

    const/4 v10, 0x0

    aput v7, p1, v4

    const/4 v10, 0x0

    aput v7, p1, v3

    aput v7, p1, v2

    const/4 v10, 0x7

    iget v8, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->b:F

    const/4 v10, 0x0

    aput v8, p1, v1

    const/4 v10, 0x5

    aput v8, p1, v0

    aput v8, p1, p4

    const/4 v10, 0x5

    aput v8, p1, p2

    const/4 v10, 0x7

    iget-object v8, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    sget-object v9, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v10, 0x7

    invoke-virtual {v8, p3, p1, v9}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    :cond_1
    const/4 v10, 0x6

    iget-boolean p1, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->d:Z

    if-eqz p1, :cond_2

    const/4 v10, 0x7

    new-array p1, v6, [F

    const/4 v10, 0x0

    iget p3, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->b:F

    const/4 v10, 0x2

    aput p3, p1, v5

    const/4 v10, 0x3

    aput p3, p1, v4

    const/4 v10, 0x5

    aput p3, p1, v3

    const/4 v10, 0x4

    aput p3, p1, v2

    const/4 v10, 0x1

    aput v7, p1, v1

    const/4 v10, 0x1

    aput v7, p1, v0

    const/4 v10, 0x3

    aput v7, p1, p4

    aput v7, p1, p2

    iget-object p2, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->a:Landroid/graphics/Path;

    const/4 v10, 0x0

    iget-object p3, p0, Lcom/luck/picture/lib/widget/RoundCornerRelativeLayout;->e:Landroid/graphics/RectF;

    const/4 v10, 0x2

    sget-object p4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v10, 0x1

    invoke-virtual {p2, p3, p1, p4}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    :cond_2
    :goto_0
    const/4 v10, 0x6

    return-void
.end method
