.class Lcom/luck/picture/lib/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lu6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/b;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/b;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/luck/picture/lib/b$a;->a:Lcom/luck/picture/lib/b;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onDenied()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/b$a;->a:Lcom/luck/picture/lib/b;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v1, Lu6/b;->c:[Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V

    return-void
.end method

.method public onGranted()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/b$a;->a:Lcom/luck/picture/lib/b;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {v0}, Lcom/luck/picture/lib/basic/e;->I()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
