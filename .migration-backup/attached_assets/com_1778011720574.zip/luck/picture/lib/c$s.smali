.class Lcom/luck/picture/lib/c$s;
.super Ljava/lang/Object;

# interfaces
.implements Lu6/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/c;->k2()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/c;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/luck/picture/lib/c$s;->a:Lcom/luck/picture/lib/c;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onDenied()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s~f@~t@i~@  @od ~  i@m@b~@ 4@~~a@.@~ ~c1 @sno@@@oou~/~ bf~-@o~lS ~i~v@@~~M~b~/ ~r@K@ty  @~ ol "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/c$s;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    sget-object v1, Lu6/b;->b:[Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/luck/picture/lib/basic/e;->q([Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public onGranted()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/c$s;->a:Lcom/luck/picture/lib/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/luck/picture/lib/c;->K1(Lcom/luck/picture/lib/c;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
