.class public Lcom/luck/picture/lib/e;
.super Lcom/luck/picture/lib/basic/e;


# static fields
.field public static final p:Ljava/lang/String; = "e"


# instance fields
.field private l:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private m:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private n:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private o:Landroidx/activity/result/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/h<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/basic/e;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic W0(Lcom/luck/picture/lib/e;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ysob~ @~S~i/ ~d  u@ @@~@b@foM~.~~fo / -cvr@a~4~in ~~o~@@~il~~ @lo1~m~@ @@s@ K @~ @t@@~ ~~@t@ b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->m1()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic X0(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e;->f0(Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-object p0
.end method

.method static synthetic Y0(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic Z0(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e;->f0(Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic a1(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic b1(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e;->f0(Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic c1(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic d1(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/basic/e;->f0(Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic e1(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->z0()V

    const/4 v1, 0x3

    return-void
.end method

.method private f1()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lcom/luck/picture/lib/e$j;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$j;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lcom/luck/picture/lib/e$a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/e$a;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/e;->o:Landroidx/activity/result/h;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method private g1()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lcom/luck/picture/lib/e$h;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$h;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v1, Lcom/luck/picture/lib/e$i;

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/e$i;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/luck/picture/lib/e;->n:Landroidx/activity/result/h;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private h1()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/luck/picture/lib/e$d;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$d;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v1, Lcom/luck/picture/lib/e$e;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/e$e;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/luck/picture/lib/e;->l:Landroidx/activity/result/h;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private i1()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lcom/luck/picture/lib/e$f;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$f;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v1, Lcom/luck/picture/lib/e$g;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/luck/picture/lib/e$g;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Ld/a;Landroidx/activity/result/a;)Landroidx/activity/result/h;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/luck/picture/lib/e;->m:Landroidx/activity/result/h;

    const/4 v3, 0x4

    return-void
.end method

.method private j1()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ne v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->i1()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->f1()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne v0, v1, :cond_2

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->h1()V

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->g1()V

    :goto_0
    const/4 v4, 0x7

    return-void
.end method

.method private k1()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/h;->d()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v0, "s/dmeov"

    const-string v0, "d*sv/eo"

    const/4 v3, 0x0

    const-string/jumbo v0, "io/*odv"

    const-string/jumbo v0, "video/*"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/luck/picture/lib/config/h;->b()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "mdauibo"

    const-string v0, "do/muia"

    const/4 v3, 0x0

    const-string v0, "a/iduou"

    const-string v0, "audio/*"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v0, "pa*og/i"

    const-string v0, "gi*eo/a"

    const/4 v3, 0x4

    const-string v0, "gq*me/a"

    const-string/jumbo v0, "image/*"

    const/4 v3, 0x4

    return-object v0
.end method

.method public static l1()Lcom/luck/picture/lib/e;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    new-instance v0, Lcom/luck/picture/lib/e;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/luck/picture/lib/e;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method private m1()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/luck/picture/lib/basic/e;->e:Lcom/luck/picture/lib/config/PictureSelectionConfig;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v1, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->j:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v3, "a,so*ib/iedv*g/"

    const-string/jumbo v3, "o*v*gbi/id/,ame"

    const-string v3, ",aomeiegd*m*/iv"

    const-string/jumbo v3, "image/*,video/*"

    const/4 v5, 0x2

    if-ne v1, v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ne v0, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/e;->m:Landroidx/activity/result/h;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v3}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v4, 0x6

    move v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    iget-object v0, p0, Lcom/luck/picture/lib/e;->o:Landroidx/activity/result/h;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->k1()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v0, v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Lcom/luck/picture/lib/config/h;->a()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ne v0, v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/luck/picture/lib/e;->l:Landroidx/activity/result/h;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/luck/picture/lib/e;->n:Landroidx/activity/result/h;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->k1()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method public B0()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/luck/picture/lib/e;->p:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public c([Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, p0, p1}, Ls6/k;->b(Landroidx/fragment/app/Fragment;[Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1}, Lu6/a;->d(Landroid/content/Context;)Z

    move-result p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->m1()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget v0, Lcom/luck/picture/lib/R$string;->ps_jurisdiction:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/luck/picture/lib/utils/s;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_1
    return-void
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget v0, Lcom/luck/picture/lib/R$layout;->ps_empty:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3}, Lcom/luck/picture/lib/basic/e;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-nez p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/luck/picture/lib/basic/e;->S()V

    :cond_0
    const/4 v1, 0x2

    return-void
.end method

.method public onDestroy()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/luck/picture/lib/basic/e;->onDestroy()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/e;->l:Landroidx/activity/result/h;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/activity/result/h;->d()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/luck/picture/lib/e;->m:Landroidx/activity/result/h;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/activity/result/h;->d()V

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/luck/picture/lib/e;->n:Landroidx/activity/result/h;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/activity/result/h;->d()V

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/luck/picture/lib/e;->o:Landroidx/activity/result/h;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/activity/result/h;->d()V

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-super {p0, p1, p2}, Lcom/luck/picture/lib/basic/e;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->j1()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1}, Lu6/a;->d(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p0}, Lcom/luck/picture/lib/e;->m1()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object p1, Lu6/b;->b:[Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p2, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p2, p1}, Lcom/luck/picture/lib/basic/e;->R(Z[Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object p2, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p2, -0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p2, p1}, Lcom/luck/picture/lib/e;->x(I[Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lu6/a;->b()Lu6/a;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lcom/luck/picture/lib/e$b;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$b;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p2, p0, p1, v0}, Lu6/a;->j(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Lu6/c;)V

    :goto_0
    const/4 v2, 0x5

    return-void
.end method

.method public x(I[Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p2, -0x2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ne p1, p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p1, Lcom/luck/picture/lib/config/PictureSelectionConfig;->i1:Ls6/k;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object p2, Lu6/b;->b:[Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/luck/picture/lib/e$c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/luck/picture/lib/e$c;-><init>(Lcom/luck/picture/lib/e;)V

    const/4 v2, 0x2

    invoke-interface {p1, p0, p2, v0}, Ls6/k;->a(Landroidx/fragment/app/Fragment;[Ljava/lang/String;Ls6/u;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
