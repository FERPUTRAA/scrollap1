.class Lcom/luck/picture/lib/e$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/luck/picture/lib/e;->h1()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/activity/result/a<",
        "Ljava/util/List<",
        "Landroid/net/Uri;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/luck/picture/lib/e;


# direct methods
.method constructor <init>(Lcom/luck/picture/lib/e;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/luck/picture/lib/e$e;->a:Lcom/luck/picture/lib/e;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "a@sc@ @m b @   @o ~- @@l@y ~ s/M@t~@@~@n~i@~ i1~~roo@ ~d~~ f~f~ @o@oo@/4 ~t@~SK~@ ~~.~bl~~v~ @ui"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    check-cast p1, Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/luck/picture/lib/e$e;->b(Ljava/util/List;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public b(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/net/Uri;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_2

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-ge v0, v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/luck/picture/lib/e$e;->a:Lcom/luck/picture/lib/e;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v2, Landroid/net/Uri;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, v2}, Lcom/luck/picture/lib/e;->X0(Lcom/luck/picture/lib/e;Ljava/lang/String;)Lcom/luck/picture/lib/entity/LocalMedia;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {}, Lcom/luck/picture/lib/utils/m;->e()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->C()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/luck/picture/lib/entity/LocalMedia;->E()Ljava/lang/String;

    move-result-object v2

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Lcom/luck/picture/lib/entity/LocalMedia;->E0(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/luck/picture/lib/manager/b;->d(Lcom/luck/picture/lib/entity/LocalMedia;)V

    const/4 v3, 0x0

    move v4, v3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v4, 0x3

    iget-object p1, p0, Lcom/luck/picture/lib/e$e;->a:Lcom/luck/picture/lib/e;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/luck/picture/lib/e;->Y0(Lcom/luck/picture/lib/e;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_3

    :cond_3
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/luck/picture/lib/e$e;->a:Lcom/luck/picture/lib/e;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/luck/picture/lib/basic/e;->S()V

    :goto_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method
