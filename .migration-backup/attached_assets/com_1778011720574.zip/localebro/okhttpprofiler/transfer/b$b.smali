.class Lcom/localebro/okhttpprofiler/transfer/b$b;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/localebro/okhttpprofiler/transfer/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# direct methods
.method private constructor <init>(Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Looper;Lcom/localebro/okhttpprofiler/transfer/b$a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/localebro/okhttpprofiler/transfer/b$b;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ks@/~@~o~mr~S /lb@@ ~n@ o~~t~ ~b a@t ~~b@ @  1 dov@o @~@~oy@i @@i@.sf~@~@li ~~ ~-f~4@  ~@ou@Mc "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const-string v0, "CTNmURSTPO_"

    const-string v0, "_OsRCTNTPSU"

    const/4 v3, 0x1

    const-string v0, "TTOCo_RNSUA"

    const-string v0, "PARTS_COUNT"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0x14

    const/4 v3, 0x3

    if-le v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    const/4 v3, 0x2

    const-wide/16 v0, 0x5

    const-wide/16 v0, 0x5

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "LUAmE"

    const-string v0, "VALUE"

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "GAT"

    const-string v1, "TAG"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method
