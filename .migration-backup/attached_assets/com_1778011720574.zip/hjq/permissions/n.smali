.class public final synthetic Lcom/hjq/permissions/n;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/Context;Ljava/util/Collection;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~~r  ~@@oMb@f@~uiS -~@@oy~~@i~o@ bo@  n@~ ol ~v@~~ d~@~~f@ / s i~b@ o~@c.@@  K~@~l@tt @a~m1 4"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Landroid/content/Context;->revokeSelfPermissionsOnKill(Ljava/util/Collection;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
