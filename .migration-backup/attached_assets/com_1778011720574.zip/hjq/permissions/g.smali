.class public final synthetic Lcom/hjq/permissions/g;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/AlarmManager;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " vs @~M ~@ Kb stc ~~~@4o~o  b ba@~@ ~oo~ry@/~@~t~ m@@@duiS~/~@~@l~~~~i  o-ln.@@ @ i~~@@f@of ~@ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/app/AlarmManager;->canScheduleExactAlarms()Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method
