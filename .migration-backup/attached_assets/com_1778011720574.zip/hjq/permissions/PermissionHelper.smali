.class final Lcom/hjq/permissions/PermissionHelper;
.super Ljava/lang/Object;


# static fields
.field private static final PERMISSION_VERSION_MAP:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final SPECIAL_PERMISSION_LIST:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final VIRTUAL_PERMISSION_LIST:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    sput-object v0, Lcom/hjq/permissions/PermissionHelper;->SPECIAL_PERMISSION_LIST:Ljava/util/List;

    new-instance v1, Ljava/util/HashMap;

    const/16 v2, 0x35

    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    sput-object v1, Lcom/hjq/permissions/PermissionHelper;->PERMISSION_VERSION_MAP:Ljava/util/Map;

    new-instance v2, Ljava/util/ArrayList;

    const/4 v3, 0x4

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    sput-object v2, Lcom/hjq/permissions/PermissionHelper;->VIRTUAL_PERMISSION_LIST:Ljava/util/List;

    const-string/jumbo v3, "rLsd.iosaidEDCUTEne._RnL_pmoMXHiEAsAsAC"

    const-string v3, "_osHLACmsiCrrRATnEDEUnAdas_EeoMX.ipd.Li"

    const-string/jumbo v3, "neMmE_ioAR.CdEsUEsHnDLAC.pXaLTSr_Aiiorm"

    const-string v3, "android.permission.SCHEDULE_EXACT_ALARM"

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v4, "TAssoEArGEiriRdE.d.GSOAmMTopnALiNN_me_oaER"

    const-string/jumbo v4, "idnmrNrTGGapRAeM_isiOosAEANTEd.LoRm.ES_nEA"

    const-string/jumbo v4, "nsOXEbSrA.GNonAATpms_roRGdeEd_LMNTEEi.ARii"

    const-string v4, "android.permission.MANAGE_EXTERNAL_STORAGE"

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v5, "EdQo_duSEKURo.AansrLpineSTGN_oESILCisTAAri."

    const-string v5, "QAn_odCAmSe_nGErSiINsKEoiULEipLsoTSARrad..T"

    const-string v5, "IsoRLAdpiEAiQS_CedASSaEniTKEmG.rpN.noLr_UPs"

    const-string v5, "android.permission.REQUEST_INSTALL_PACKAGES"

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v6, "dbIsrCinqsoPEC_UITNrTp.iRnIR.iUPdEaom"

    const-string v6, "IdianbPNimU.srETPCo.Epnis_ToRdrICUIR_"

    const-string/jumbo v6, "m.spUIierEaUCsRTnoENRod.ri_CIPnsdPIT_"

    const-string v6, "android.permission.PICTURE_IN_PICTURE"

    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v7, "uSEmar_iiWn.pIsMA.si_dTDTndoRWLNrmEYSe"

    const-string v7, "._YEiduparTsEeRmMrdTNionDSOWiWL_nSsAI."

    const-string v7, "MD_.osTSi_mEsEoISrOnLWWiTYdnro.ipdReaN"

    const-string v7, "android.permission.SYSTEM_ALERT_WINDOW"

    invoke-interface {v0, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v8, "p_RrIbsnndaNpWiTiiGsEeES.oT.SroIm"

    const-string/jumbo v8, "sSRnoEepoTdsmSaE.pWNnIiT.IGirr_id"

    const-string/jumbo v8, "rdnoiiuTnWe_TRomaiErS.ssIET.NISpG"

    const-string v8, "android.permission.WRITE_SETTINGS"

    invoke-interface {v0, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v9, "sAm_OropTsCiE_oNpaYITL.IC.SdPnAOiFIenIdCCiNrq"

    const-string/jumbo v9, "oEPa.pF.qAIdYeOri_AnInTCdN_iismSOTNCrILIoCsCO"

    const-string/jumbo v9, "opONiLmFqACiAI._i.s_dEaCTdrYISPTCrnInOCNOseoI"

    const-string v9, "android.permission.ACCESS_NOTIFICATION_POLICY"

    invoke-interface {v0, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v10, "OssTEIEQRpTnN.oPs_IT_USR.iAEdiErrnAYsaTMoIidOmGeBRI_ZNO"

    const-string/jumbo v10, "rIsEasORNeIPniN_MIQSEEoOBZRpAniiOYrR.TmdSAEosId_TTT.U_G"

    const-string v10, "T.omYRIQInsoBeEMO.TrdGPETSind_TIINNamiSR_AOZRTpUA_ErEsi"

    const-string v10, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    invoke-interface {v0, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v11, "daAmAAio_PsnrGEpUs.iEnTTAoKCSGmr.ieSSd"

    const-string/jumbo v11, "nC_dooSeiK..dUSAsGSApEnAarPrTGoEsiA_mT"

    const-string v11, "android.permission.PACKAGE_USAGE_STATS"

    invoke-interface {v0, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v12, "FsInobasrEIoIpENrORAIT_nTdCmC.NSO.oiVid"

    const-string v12, "TsomodSinpO.IioFdI_NrCInIisrVOETE.aCANR"

    const-string/jumbo v12, "psImFouAOEs_ndTCd.iiNIOIr.EIaerCnRSViTo"

    const-string v12, "android.permission.NOTIFICATION_SERVICE"

    invoke-interface {v0, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v13, "NSs_ObAIsE_BLronEOICeRFIiEndTSINrdio_CN..mDVINETRpiTa"

    const-string v13, "LsTI.REp_edRNrEnONs_DEINCpdamN_FIIiS.SIiriooIBTATCOEV"

    const-string v13, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    invoke-interface {v0, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v14, "r.BEanrVqNIidmDsENoCesVudpiRi_PIon_"

    const-string v14, "idCI_pue_in.NPEVEoiVDm.anBsoIrNRdsr"

    const-string v14, "CosmNer.dS_V.sprIdsniaiP_iDENoIEVnR"

    const-string v14, "android.permission.BIND_VPN_SERVICE"

    invoke-interface {v0, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v0, 0x1f

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v1, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v3, 0x1e

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v3, 0x1a

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v5, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v1, v6, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v4, 0x17

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v1, v7, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v1, v8, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v1, v9, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v1, v10, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0x15

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v11, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0x13

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v12, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0x12

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v13, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0xe

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v1, v14, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0x22

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v7, "EAUmArrSEeSDs_pEL.dLdTD_ainIDSRMEiVmnsI_UEEiopoCR."

    const-string v7, "RUSmEAnpoU_DEiTrioSpEned.EI.L_sMaRAVSCiADIDEdrLs_E"

    const-string v7, "_rLeoUI..oEsoS_DEnsrSAdaELiiMDRmUEViI_nCARETD_dASE"

    const-string v7, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v5, 0x21

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v7, "OCsTobdoaiqrpTNOnIsmTiFISe_O.i.dNSnAP"

    const-string v7, "IFsPaTSNq.i.dAodOmOn_iiSrpoOsTeTnCINI"

    const-string v7, "CAaPsOuNporTNdI.IndOSrSTTimOes_oIini."

    const-string v7, "android.permission.POST_NOTIFICATIONS"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v7, "no_WiInpVdSpeiodCiE..NrsYRFBDA_IassrEE"

    const-string v7, "._snVaEsWS.oBYI_rDopNdFrdiRCmsniEIAEei"

    const-string v7, "I_.rriSIqsomndEAIadWo.eECFsYEDiR_VNBnp"

    const-string v7, "android.permission.NEARBY_WIFI_DEVICES"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, "d.sSnRpoBmdiSYeKRNrA_sNriBSDmUoOGi_sD.aOnC"

    const-string v7, "RSOmYNnndSGiCUiER.a.Sr_oeOsdmoDKpABBr_DNsi"

    const-string v7, "NRomiSsRd.GDis_rnEB_oBDKNOAenCS.OYSpdamirU"

    const-string v7, "android.permission.BODY_SENSORS_BACKGROUND"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, ".pDnoesAoEnirR_GAMadiioMd_DrAIE.ESIs"

    const-string v7, "android.permission.READ_MEDIA_IMAGES"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, "iDiorboMrsse.IEEOI_om.VnpREdAn_daDA"

    const-string v7, "IEiMoroIs.R.anno_D_AsidDeAmdpErOVDE"

    const-string v7, "idDIanu..snODordRsiEiMD_r_oEAIEmAeV"

    const-string v7, "android.permission.READ_MEDIA_VIDEO"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, "Dni.DiApnrdiosIbUApOsoaME_d_AD.meIR"

    const-string v7, "DpaAibADM_AImo.rInUsEnddOsR.iirDo_e"

    const-string v7, "DDAOe__dqEMiR.IpAsoanos.EUdimrnirAI"

    const-string v7, "android.permission.READ_MEDIA_AUDIO"

    invoke-interface {v1, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "Nmsn.O_iUpSouBseOasHAiCdnTrdE.roL"

    const-string/jumbo v5, "mpBaTsuio.L_SreoTEsrnOCnUiHN.OAdd"

    const-string v5, "N.BmsU.OrsCLpSiOdrTiEdneinmTo_aHA"

    const-string v5, "android.permission.BLUETOOTH_SCAN"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v5, "sEsCoomnn.TiBLddOorTNeOC_rHpUaTpiNE."

    const-string/jumbo v5, "saNHnOCp_TLpmdiE.d.oiOrECUrieTsnoTBN"

    const-string v5, "_d.THbNoLUC.miOeOsiBErdTnarCnpiENTOs"

    const-string v5, "android.permission.BLUETOOTH_CONNECT"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v5, "q.LHT.usinIierEOmBDVRSsOponEUTradE_TAo"

    const-string v5, "iHETe_RpqnOO.AdiaErLBVTTEnoSrUDso.mIsi"

    const-string v5, "AE_roiIpsTBiEHULeETiDnOonOmd.s.TVpRrad"

    const-string v5, "android.permission.BLUETOOTH_ADVERTISE"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v0, 0x1d

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const-string/jumbo v5, "smNorB_KqL_snrCoGT.CiAiOEUCR.DOIeAdSpOiSNAnas"

    const-string v5, "IOseoAK_BNrnos.SECGCN_siUiAOnSRTCAOaCpdD.Lirm"

    const-string v5, "AAsSNBGSo_rCsKCim.LOoreAdOCaUIspiOCnNndTR_.ED"

    const-string v5, "android.permission.ACCESS_BACKGROUND_LOCATION"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v5, "rITmCmTAaRmedrNopOn_.iIsIVIoYndCO.iGsTN"

    const-string v5, "_ICmOoNGrTdYeAITinInd.ssaETpV.NmRCrIiOo"

    const-string v5, "android.permission.ACTIVITY_RECOGNITION"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "MinsoAAC_CIseOdNir.DaIrmSoo.iLO_CTnEopAd"

    const-string/jumbo v5, "rACaopS.ro.iniLmend_EsCNIsCTMDAIoOdAE_iO"

    const-string v5, "ENOarboCC_iMA.IdmoiC.seinASOpd_ILTSrEDAs"

    const-string v5, "android.permission.ACCESS_MEDIA_LOCATION"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v0, 0x1c

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const-string/jumbo v5, "nodprPuaeACoC_HVT.ERmsdiisAOiENnD."

    const-string/jumbo v5, "nDTEpbiaAOC.NAddirsooCnsi.PHVRe_Em"

    const-string v5, "a.psNrmpnsnOEA.iHCPAodoTiVeCRd_rDi"

    const-string v5, "android.permission.ACCEPT_HANDOVER"

    invoke-interface {v1, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "nesCsidEqoSSr.iHWO_NNLArApiad_EnPmo.R"

    const-string v0, "android.permission.ANSWER_PHONE_CALLS"

    invoke-interface {v1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "Nisn_a.sHPrrER.DE_MnsSEReimopBiAOduoU"

    const-string/jumbo v0, "osiirSupmeMBno.EAaENiP_RH_dN.rnRUDsEO"

    const-string v0, "UM.mdsrHiRDsA._iBprmRPEdEone_NNoiOaES"

    const-string v0, "android.permission.READ_PHONE_NUMBERS"

    invoke-interface {v1, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "iESPoD.a_AAmcTedpPNSpsoroindsGoTnmL_i.IE."

    const-string v0, ".sSrIi.pAnEoDi_cimELesAPddTmaTronoNSGp.P_"

    const-string v0, "GETLsb...deSmIPaiAPEmSrcrTiNodDps_oi_oLAn"

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "p_._STuAeEoqEAaAELdRXRrGrinnmsOTs.diNRoE"

    const-string v0, "EE.RrRpiqTSodArXnsadAs_mL_GiAeRnDENEoTO."

    const-string v0, "GDArAoOpTsNE__EERrioiXa.Annpm.idTdRsLEeS"

    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "WirnaipdqSROnsdAR.sTN_srLEm.AETie_ERooTEG"

    const-string v0, "ETsWsepaoRRid_.RoiAmnsOEENTGiT.dr_ALrXESn"

    const-string v0, "iLsOEWNiATEsRIRreR_dima_E.EspAX.odTnoTnrS"

    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "iosmadrAiMCnm.nopdsRmEei."

    const-string/jumbo v0, "modmrAie.isEMr.dCiposnaRn"

    const-string v0, "Cdr.oRpAnooisrMdnA.Eaieis"

    const-string v0, "android.permission.CAMERA"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "iRRCUbaorripdsoiDI..OmnoEesDd_O"

    const-string v0, "UIRioDsra_dApO.odminisrROoD.eEC"

    const-string v0, "OOrr..upiUdeRdnasmioCADnDi_soIE"

    const-string v0, "android.permission.RECORD_AUDIO"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "_be.aIspSCFiNnoTCdNS.pOrdoIAEOC_AiErLim"

    const-string v0, "SneiCbnE_OFdANdLiIr.sami_CNSoOorpA.ECIT"

    const-string/jumbo v0, "nsTA_NEoqdnodE.O.eiOCs_IAiCFrpSIiaCrNLS"

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "AeapARuA_LSssOnEnNOOS_ETS.orCIdio.CCdimiC"

    const-string/jumbo v0, "rIsaOoLROA_s.dmdACriOCCeAiSSnNEip.Tn_CosE"

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, ".NimSAiidERaCTprCoTmprnsAnds_oO."

    const-string v0, "TO._Tr.pNoidEnRnSdmoisAACrsipCDa"

    const-string/jumbo v0, "oTido_C.AnoRseCnAsdaiOrSiNT.rDEp"

    const-string v0, "android.permission.READ_CONTACTS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "Siisab_RN.nrEs.nOIdTepTCorAiqdWTo"

    const-string v0, "dOn._TiEqoerriTINpsnTsiAm.RoCaSdW"

    const-string v0, "SioICiudRneEsWaAprTiONo.Cs_TTnd.m"

    const-string v0, "android.permission.WRITE_CONTACTS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "nrodETrpO_niamAGsdii.TsCSps.eNU"

    const-string v0, ".AsTEC.iNmOiaUisTdeGprs_oSnrdno"

    const-string/jumbo v0, "sUaATSooqNprOeGiidmTsCd.r.CnEni"

    const-string v0, "android.permission.GET_ACCOUNTS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "ErsnEd_sm.CAianmA.rDioNsdLpieDoR"

    const-string v0, "AmamRdiDN.iEDrssndrnA.ioCApoeL_E"

    const-string/jumbo v0, "is.mArRnCnd.E_LseopdaDAmRDoiNirE"

    const-string v0, "android.permission.READ_CALENDAR"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "NnRCodEoEmn..RTADIrd_aWiAipesoLis"

    const-string v0, "android.permission.WRITE_CALENDAR"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "eTrioa_OnEDnPHEAspTir.mbE.oAdR_SdNs"

    const-string/jumbo v0, "ndsA.bpem_H.oi_EEsRiOrEPDrTSidANanT"

    const-string v0, "AiHTnbeOEsnr_R.riTN.AmpEaPdoESdiDs_"

    const-string v0, "android.permission.READ_PHONE_STATE"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "NsOsiuuL.imior_oLCAHEnedn.adP"

    const-string v0, "aCH_iNuoemdsEnr.OLnsrAoi.LdiP"

    const-string v0, "iN.mnCEpsineOraPdHrs_Ao.dopLi"

    const-string v0, "android.permission.CALL_PHONE"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "p.imLoLeqRAr_rnLadspo_iGOnidDs.C"

    const-string/jumbo v0, "sinorLpprAdE.Cs_iOLa._LmnGodDiRe"

    const-string v0, "EAsArDnsidLC.Ganpii.oLsLOmd_R_ro"

    const-string v0, "android.permission.READ_CALL_LOG"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "si.mms.LGndLrTniWiLRAI_CpqOdroaeo"

    const-string v0, "dG_sedLAq.roO_IorLCspiLanTnm.RiWi"

    const-string/jumbo v0, "npsWon.LdiT_r.sLiGORAoodaiEer_mLC"

    const-string v0, "android.permission.WRITE_CALL_LOG"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "DiooIbdl_eeciispLaiisVEI.mcrrdnao.nmoCOA..ADMm"

    const-string/jumbo v0, "iosi_oDpomIcEaeoc.DLrisI.nmiArOCvdeAn.M.mValid"

    const-string v0, "I.mC_pu..cdeaEsrManVoAcIoLovidnDseio.ArDliimmO"

    const-string v0, "com.android.voicemail.permission.ADD_VOICEMAIL"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "nd.siI_pmPsiodSpieEUomrn.S"

    const-string/jumbo v0, "nmSmePp.ssdooiI_SnUEdra.ii"

    const-string v0, "i.imSISEqon_enUPssi.rapddr"

    const-string v0, "android.permission.USE_SIP"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "oRsiiOACrUGdIdsNEOCLrO.ooSin_SemPSsn_aLT."

    const-string v0, "d_idossSSSPIerLUO_AioTRLiGnNCOC.n.amporOE"

    const-string v0, "eCmmNniGo.OAsRidrLaU_EnSsdO.IiCoSLpS_OTPG"

    const-string v0, "android.permission.PROCESS_OUTGOING_CALLS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "r_NOopiDmoiYBsoners.SSOadS.nEbd"

    const-string v0, "SidSnb.SpiiseY_ONEoO.BDrrmdnosa"

    const-string v0, "android.permission.BODY_SENSORS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "supdSbr.oennmdaro_SiEsiMiDN"

    const-string v0, "EssadSu.Mmn.poreNd_iirionSD"

    const-string/jumbo v0, "ido.pmuneiNr.Ersso_SdSiaSMD"

    const-string v0, "android.permission.SEND_SMS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "s.opaMiprdES_IRCsei.rEnidnVmSE"

    const-string v0, "android.permission.RECEIVE_SMS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "MrisnESpqoi.AoSnmapDsedRr_."

    const-string/jumbo v0, "imensSaAqrEndo.DSor_pi.RMsd"

    const-string/jumbo v0, "monrEsS.qMoe_psd.DSdiRnrAia"

    const-string v0, "android.permission.READ_SMS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "mUsCEpiAaHP.oPi_ro.ndeVEnEdRss_WsIS"

    const-string/jumbo v0, "imssrdARPVoEn.aPneds_HEWpEr.CiSoI_U"

    const-string v0, "PrimUsREe_sVHIEnSmonaoPi.d.iCApdEr_"

    const-string v0, "android.permission.RECEIVE_WAP_PUSH"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v0, "r.VeoMIiio_oEdinanpsREMm.mdsCr"

    const-string/jumbo v0, "snRmi_n.piiEE.VeMMrrCamdoIdEso"

    const-string/jumbo v0, "naMsmbEedrIoi_RMEV.rSCnioEidps"

    const-string v0, "android.permission.RECEIVE_MMS"

    invoke-interface {v1, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v2, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v2, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v2, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v2, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static findAndroidVersionByPermission(Ljava/lang/String;)I
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oo @o@ur4~f~@@i ~~  tbb~lo~m@v~n ~S ~ ~i@~ @~/~yl~t~o~d /a~@  ~-@oc@@@@@~i~@@@K@  @  b@ u .M~1sf"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/hjq/permissions/PermissionHelper;->PERMISSION_VERSION_MAP:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p0
.end method

.method static isSpecialPermission(Ljava/lang/String;)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/hjq/permissions/PermissionHelper;->SPECIAL_PERMISSION_LIST:Ljava/util/List;

    invoke-static {v0, p0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0
.end method

.method static isVirtualPermission(Ljava/lang/String;)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/hjq/permissions/PermissionHelper;->VIRTUAL_PERMISSION_LIST:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p0
.end method
