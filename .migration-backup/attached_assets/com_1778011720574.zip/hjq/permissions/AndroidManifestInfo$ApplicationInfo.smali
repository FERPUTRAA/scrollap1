.class final Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/permissions/AndroidManifestInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "ApplicationInfo"
.end annotation


# instance fields
.field name:Ljava/lang/String;

.field requestLegacyExternalStorage:Z


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method
