.class public final Lcom/hjq/permissions/PermissionFragment;
.super Landroid/app/Fragment;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static final REQUEST_CODE:Ljava/lang/String; = "request_code"

.field private static final REQUEST_CODE_ARRAY:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final REQUEST_PERMISSIONS:Ljava/lang/String; = "request_permissions"


# instance fields
.field private mCallBack:Lcom/hjq/permissions/OnPermissionCallback;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private mDangerousRequest:Z

.field private mInterceptor:Lcom/hjq/permissions/OnPermissionInterceptor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private mRequestFlag:Z

.field private mScreenOrientation:I

.field private mSpecialRequest:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    sput-object v0, Lcom/hjq/permissions/PermissionFragment;->REQUEST_CODE_ARRAY:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/app/Fragment;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public static launch(Landroid/app/Activity;Ljava/util/List;Lcom/hjq/permissions/OnPermissionInterceptor;Lcom/hjq/permissions/OnPermissionCallback;)V
    .locals 8
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/permissions/OnPermissionInterceptor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/hjq/permissions/OnPermissionCallback;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/OnPermissionInterceptor;",
            "Lcom/hjq/permissions/OnPermissionCallback;",
            ")V"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "o s l1i~~bul~no@f @ s @ ~~o~/4c@im  -~f~@@~ K@v./@@~~@~@@  otbi~a~@~ @~@dS@@~~~ b ~o r~M y@~@t@o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    new-instance v0, Lcom/hjq/permissions/PermissionFragment;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v0}, Lcom/hjq/permissions/PermissionFragment;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v1, Ljava/util/Random;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v7, 0x7

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v7, 0x4

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    double-to-int v2, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v3, Lcom/hjq/permissions/PermissionFragment;->REQUEST_CODE_ARRAY:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-interface {v3, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    if-nez v4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {v3, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v1, Landroid/os/Bundle;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v3, "oremssd_utee"

    const-string v3, "eosdetuqr_se"

    const/4 v7, 0x0

    const-string/jumbo v3, "sredoute_eqc"

    const-string/jumbo v3, "request_code"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    instance-of v2, p1, Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v3, "sruiibmsqntsrpeeo_s"

    const-string/jumbo v3, "request_permissions"

    const/4 v7, 0x4

    if-eqz v2, :cond_1

    const/4 v7, 0x4

    check-cast p1, Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1, v3, p1}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v2, Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 p1, 0x1

    const/4 p1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Landroid/app/Fragment;->setRetainInstance(Z)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Lcom/hjq/permissions/PermissionFragment;->setRequestFlag(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, p3}, Lcom/hjq/permissions/PermissionFragment;->setOnPermissionCallback(Lcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v0, p2}, Lcom/hjq/permissions/PermissionFragment;->setOnPermissionInterceptor(Lcom/hjq/permissions/OnPermissionInterceptor;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, p0}, Lcom/hjq/permissions/PermissionFragment;->attachByActivity(Landroid/app/Activity;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void
.end method


# virtual methods
.method public attachByActivity(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1, p0, v0}, Landroid/app/FragmentTransaction;->add(Landroid/app/Fragment;Ljava/lang/String;)Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/app/FragmentTransaction;->commitAllowingStateLoss()I

    const/4 v2, 0x5

    return-void
.end method

.method public detachByActivity(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x0

    const/4 v0, 0x5

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void

    :cond_0
    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p0}, Landroid/app/FragmentTransaction;->remove(Landroid/app/Fragment;)Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Landroid/app/FragmentTransaction;->commitAllowingStateLoss()I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 2
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p3

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p2, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-eqz p3, :cond_2

    const/4 v1, 0x6

    const/4 v0, 0x5

    iget-boolean p2, p0, Lcom/hjq/permissions/PermissionFragment;->mDangerousRequest:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p2, :cond_2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    const-string p2, "_rmoequdetsu"

    const-string p2, "eormdset_qcu"

    const/4 v1, 0x5

    const-string/jumbo p2, "udcoeeepr_sq"

    const-string/jumbo p2, "request_code"

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p3, p2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-eq p1, p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string/jumbo p1, "p_srsursqismqteneio"

    const-string/jumbo p1, "moeponsseustsir_irq"

    const/4 v1, 0x2

    const-string/jumbo p1, "iisroseqtrp_esssneu"

    const-string/jumbo p1, "request_permissions"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-eqz p1, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-eqz p2, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p2, p0, Lcom/hjq/permissions/PermissionFragment;->mDangerousRequest:Z

    invoke-static {p1, p0}, Lcom/hjq/permissions/PermissionUtils;->postActivityResult(Ljava/util/List;Ljava/lang/Runnable;)V

    :cond_2
    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public onAttach(Landroid/content/Context;)V
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SourceLockedOrientationActivity"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroid/app/Fragment;->onAttach(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/app/Activity;->getRequestedOrientation()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput v0, p0, Lcom/hjq/permissions/PermissionFragment;->mScreenOrientation:I

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/hjq/permissions/PermissionUtils;->lockActivityOrientation(Landroid/app/Activity;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public onDestroy()V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-super {p0}, Landroid/app/Fragment;->onDestroy()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/hjq/permissions/PermissionFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionCallback;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public onDetach()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-super {p0}, Landroid/app/Fragment;->onDetach()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v1, p0, Lcom/hjq/permissions/PermissionFragment;->mScreenOrientation:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, -0x1

    const/4 v4, 0x2

    if-ne v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/app/Activity;->getRequestedOrientation()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Landroid/app/Activity;->setRequestedOrientation(I)V

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 12

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v7

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v7, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v0, :cond_7

    const/4 v11, 0x2

    iget-object v1, p0, Lcom/hjq/permissions/PermissionFragment;->mInterceptor:Lcom/hjq/permissions/OnPermissionInterceptor;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-eqz v1, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v1, "uetme_rqedco"

    const-string v1, "d_rucbqetoee"

    const-string/jumbo v1, "request_code"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eq p1, v0, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    goto/16 :goto_3

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/hjq/permissions/PermissionFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionCallback;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v1, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    iput-object v1, p0, Lcom/hjq/permissions/PermissionFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionCallback;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v8, p0, Lcom/hjq/permissions/PermissionFragment;->mInterceptor:Lcom/hjq/permissions/OnPermissionInterceptor;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput-object v1, p0, Lcom/hjq/permissions/PermissionFragment;->mInterceptor:Lcom/hjq/permissions/OnPermissionInterceptor;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget-object v1, Lcom/hjq/permissions/PermissionFragment;->REQUEST_CODE_ARRAY:Ljava/util/List;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-interface {v1, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v10, 0x3

    move v11, v10

    if-eqz p2, :cond_7

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    array-length p1, p2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz p1, :cond_7

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-eqz p3, :cond_7

    const/4 v11, 0x7

    array-length p1, p3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez p1, :cond_1

    goto/16 :goto_3

    :cond_1
    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 p1, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    move v1, p1

    move v1, p1

    const/4 v11, 0x1

    move v1, p1

    move v1, p1

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    array-length v2, p2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ge v1, v2, :cond_4

    const/4 v10, 0x4

    or-int/2addr v11, v10

    aget-object v2, p2, v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    aget v3, p3, v1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-nez v3, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v3, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    goto :goto_1

    :cond_2
    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    move v3, p1

    move v3, p1

    const/4 v11, 0x2

    move v3, p1

    move v3, p1

    :goto_1
    const/4 v10, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v7, v2, v3}, Lcom/hjq/permissions/PermissionApi;->recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x0

    if-eqz v2, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x5

    move v2, p1

    move v2, p1

    const/4 v11, 0x5

    move v2, p1

    move v2, p1

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto :goto_2

    :cond_3
    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v2, -0x1

    :goto_2
    const/4 v10, 0x3

    const/4 v11, 0x0

    aput v2, p3, v1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    goto :goto_0

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {p2}, Lcom/hjq/permissions/PermissionUtils;->asArrayList([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p0, v7}, Lcom/hjq/permissions/PermissionFragment;->detachByActivity(Landroid/app/Activity;)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {p2, p3}, Lcom/hjq/permissions/PermissionApi;->getGrantedPermissions(Ljava/util/List;[I)Ljava/util/List;

    move-result-object v9

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-ne v1, v2, :cond_5

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    const/4 v5, 0x6

    const/4 v5, 0x1

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v6, v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-interface/range {v1 .. v6}, Lcom/hjq/permissions/OnPermissionInterceptor;->grantedPermissionRequest(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;ZLcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-interface {v8, v7, p2, p1, v0}, Lcom/hjq/permissions/OnPermissionInterceptor;->finishPermissionRequest(Landroid/app/Activity;Ljava/util/List;ZLcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    return-void

    :cond_5
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {p2, p3}, Lcom/hjq/permissions/PermissionApi;->getDeniedPermissions(Ljava/util/List;[I)Ljava/util/List;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {v7, v4}, Lcom/hjq/permissions/PermissionApi;->isDoNotAskAgainPermissions(Landroid/app/Activity;Ljava/util/List;)Z

    move-result v5

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v3, p2

    move-object v3, p2

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-interface/range {v1 .. v6}, Lcom/hjq/permissions/OnPermissionInterceptor;->deniedPermissionRequest(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;ZLcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result p3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-nez p3, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v5, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-interface/range {v1 .. v6}, Lcom/hjq/permissions/OnPermissionInterceptor;->grantedPermissionRequest(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;ZLcom/hjq/permissions/OnPermissionCallback;)V

    :cond_6
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-interface {v8, v7, p2, p1, v0}, Lcom/hjq/permissions/OnPermissionInterceptor;->finishPermissionRequest(Landroid/app/Activity;Ljava/util/List;ZLcom/hjq/permissions/OnPermissionCallback;)V

    :cond_7
    :goto_3
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    return-void
.end method

.method public onResume()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Landroid/app/Fragment;->onResume()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/hjq/permissions/PermissionFragment;->mRequestFlag:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/hjq/permissions/PermissionFragment;->detachByActivity(Landroid/app/Activity;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/hjq/permissions/PermissionFragment;->mSpecialRequest:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/hjq/permissions/PermissionFragment;->mSpecialRequest:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/hjq/permissions/PermissionFragment;->requestSpecialPermission()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public requestDangerousPermission()V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-eqz v0, :cond_8

    const/4 v8, 0x7

    xor-int/2addr v9, v8

    if-nez v1, :cond_0

    const/4 v8, 0x6

    move v9, v8

    goto/16 :goto_2

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v2, "esedo_tuourc"

    const-string/jumbo v2, "s_utdcueeroq"

    const/4 v9, 0x5

    const-string/jumbo v2, "ue_eobtrcqds"

    const-string/jumbo v2, "request_code"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string v3, "errqieuppn_esusoism"

    const-string/jumbo v3, "s_imsssppueroeirnqe"

    const/4 v9, 0x6

    const-string v3, "_iusomnpseeeqtprssi"

    const-string/jumbo v3, "request_permissions"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v1, v3}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v1, :cond_8

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v3, :cond_1

    const/4 v9, 0x2

    goto/16 :goto_2

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-nez v3, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-array v4, v3, [I

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v5, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x6

    move v6, v5

    move v6, v5

    const/4 v9, 0x2

    move v6, v5

    move v6, v5

    :goto_0
    const/4 v8, 0x5

    move v9, v8

    if-ge v6, v3, :cond_3

    const/4 v8, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    check-cast v7, Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v0, v7}, Lcom/hjq/permissions/PermissionApi;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v7, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    move v7, v5

    move v7, v5

    const/4 v9, 0x1

    move v7, v5

    move v7, v5

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_1

    :cond_2
    const/4 v9, 0x5

    const/4 v7, -0x1

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    aput v7, v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    add-int/lit8 v6, v6, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-array v0, v5, [Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    check-cast v0, [Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0, v2, v0, v4}, Lcom/hjq/permissions/PermissionFragment;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    return-void

    :cond_4
    const/4 v9, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-eqz v3, :cond_5

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-lt v3, v4, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v3, "RBpS_iaEqoAGSnCO.OSDsdUedRoNmrBi_KY.DNnirs"

    const-string v3, "android.permission.BODY_SENSORS_BACKGROUND"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {v1, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x3

    if-eqz v5, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x5

    new-instance v4, Ljava/util/ArrayList;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {v4, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p0, v0, v1, v4, v2}, Lcom/hjq/permissions/PermissionFragment;->splitTwiceRequestPermission(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;I)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-void

    :cond_5
    const/4 v8, 0x5

    move v9, v8

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x3

    if-eqz v3, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-lt v3, v4, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v3, "Assi.asIiGOoSNDeoCnrSApdKErA_.CUTNOdOBCR_inmL"

    const-string v3, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v8, 0x5

    move v9, v8

    invoke-static {v1, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-eqz v4, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    new-instance v4, Ljava/util/ArrayList;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v4, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p0, v0, v1, v4, v2}, Lcom/hjq/permissions/PermissionFragment;->splitTwiceRequestPermission(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;I)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-void

    :cond_6
    const/4 v9, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v3, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v3, "OoAmdDnOESSnNaTIpmi_rA_.doCeECisAiCIrML."

    const-string v3, "aODn_iONqSmToLSiInEddAIprMAEC_iCs.reAC.o"

    const/4 v9, 0x6

    const-string/jumbo v3, "rIoNoaTnpnESeO_SirsDACi.ILACd_MOCmE.dAso"

    const-string v3, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v1, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v4, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v4, "aAsosb_ERsre.NdLAdSmOTRrpDGi.EonERXi_inA"

    const-string v4, "LAsiAEdiEDoerREdAR.._pXRGnESsarnT_sNoiOm"

    const-string v4, "Drs_aGuXSeERsNiEAnRmErnd_diiRE..ALoToAOp"

    const-string v4, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v1, v4}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v4, :cond_7

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    new-instance v4, Ljava/util/ArrayList;

    const/4 v9, 0x6

    invoke-direct {v4, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p0, v0, v1, v4, v2}, Lcom/hjq/permissions/PermissionFragment;->splitTwiceRequestPermission(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;I)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-void

    :cond_7
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-array v0, v0, [Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    check-cast v0, [Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p0, v0, v2}, Landroid/app/Fragment;->requestPermissions([Ljava/lang/String;I)V

    :cond_8
    :goto_2
    const/4 v8, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-void
.end method

.method public requestSpecialPermission()V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v0, :cond_7

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-nez v1, :cond_0

    const/4 v7, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto/16 :goto_2

    :cond_0
    const/4 v8, 0x1

    const-string/jumbo v2, "sismesrp_otnpumrsei"

    const-string/jumbo v2, "nu_mqstrimsposeersi"

    const/4 v8, 0x5

    const-string/jumbo v2, "sses_pteqrouenmisri"

    const-string/jumbo v2, "request_permissions"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v0, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    sub-int/2addr v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v4, 0x0

    :goto_0
    const/4 v7, 0x1

    const/4 v8, 0x2

    if-ltz v2, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-static {v5}, Lcom/hjq/permissions/PermissionApi;->isSpecialPermission(Ljava/lang/String;)Z

    move-result v6

    const/4 v8, 0x2

    if-nez v6, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto :goto_1

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v1, v5}, Lcom/hjq/permissions/PermissionApi;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v6, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_1

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez v6, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v6, ".msGnLiReNTNOs_X_rsERdoaEArSpEoodniAT.iAGM"

    const-string v6, "ETRXoGm_RTndidEGsOMNoa_roE.AeNASiE.nsiLprA"

    const/4 v8, 0x4

    const-string v6, "AaNmiorARmd_ssiAEEMOATS_rEeio.GNnRGnX.LdTE"

    const-string v6, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v5, v6}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v6

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v6, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_1

    :cond_4
    const/4 v7, 0x6

    const/4 v8, 0x5

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v4}, Lcom/hjq/permissions/PermissionUtils;->asArrayList([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v1, v4}, Lcom/hjq/permissions/PermissionApi;->getSmartPermissionIntent(Landroid/content/Context;Ljava/util/List;)Landroid/content/Intent;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v6, "_coeosebrequ"

    const-string/jumbo v6, "oueq_bscedre"

    const/4 v8, 0x4

    const-string/jumbo v6, "seretb_duoeq"

    const-string/jumbo v6, "request_code"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v5, v6}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p0, v4, v5}, Lcom/hjq/permissions/StartActivityManager;->startActivityForResult(Landroid/app/Fragment;Landroid/content/Intent;I)Z

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v2, v2, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto/16 :goto_0

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v4, :cond_6

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void

    :cond_6
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/hjq/permissions/PermissionFragment;->requestDangerousPermission()V

    :cond_7
    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-void
.end method

.method public run()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->isAdded()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/hjq/permissions/PermissionFragment;->requestDangerousPermission()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setOnPermissionCallback(Lcom/hjq/permissions/OnPermissionCallback;)V
    .locals 2
    .param p1    # Lcom/hjq/permissions/OnPermissionCallback;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/hjq/permissions/PermissionFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionCallback;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public setOnPermissionInterceptor(Lcom/hjq/permissions/OnPermissionInterceptor;)V
    .locals 2
    .param p1    # Lcom/hjq/permissions/OnPermissionInterceptor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/hjq/permissions/PermissionFragment;->mInterceptor:Lcom/hjq/permissions/OnPermissionInterceptor;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public setRequestFlag(Z)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    iput-boolean p1, p0, Lcom/hjq/permissions/PermissionFragment;->mRequestFlag:Z

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public splitTwiceRequestPermission(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;I)V
    .locals 10
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;I)V"
        }
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    new-instance v3, Ljava/util/ArrayList;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-direct {v3, p2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance v6, Lcom/hjq/permissions/PermissionFragment$1;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-direct {v6, p0}, Lcom/hjq/permissions/PermissionFragment$1;-><init>(Lcom/hjq/permissions/PermissionFragment;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-instance v7, Lcom/hjq/permissions/PermissionFragment$2;

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    move v5, p4

    const/4 v9, 0x1

    move v5, p4

    move v5, p4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct/range {v0 .. v5}, Lcom/hjq/permissions/PermissionFragment$2;-><init>(Lcom/hjq/permissions/PermissionFragment;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1, p3, v6, v7}, Lcom/hjq/permissions/PermissionFragment;->launch(Landroid/app/Activity;Ljava/util/List;Lcom/hjq/permissions/OnPermissionInterceptor;Lcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-void
.end method
