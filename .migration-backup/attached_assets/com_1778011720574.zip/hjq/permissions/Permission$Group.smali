.class public final Lcom/hjq/permissions/Permission$Group;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/permissions/Permission;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Group"
.end annotation


# static fields
.field public static final BLUETOOTH:[Ljava/lang/String;

.field public static final CALENDAR:[Ljava/lang/String;

.field public static final CONTACTS:[Ljava/lang/String;

.field public static final STORAGE:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v0, ".LsssmArTXDoEs_ENEnEoR_GiAidideaROSrA.nT"

    const-string v0, "REs.nT.SoORneTXAr_sdidiLDaimrNAEAEoGERs_"

    const/4 v4, 0x1

    const-string v0, "ALdm_TpDTOiR.XEoE.AssSrdR_iRainEEmArNnGe"

    const-string v0, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v4, 0x7

    const-string v1, "EdNoomG.riRSsTERnnIeEiomLrAaX_WET.dsiRTOA"

    const-string v1, "XpImrdReE.aiRdiiATmG_TrsnnWETSAosR.NoLEEO"

    const/4 v4, 0x7

    const-string v1, "dAsLTbnEiEiEnWsRIRSropEd.T.GXaAmToi_Rr_eO"

    const-string v1, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v0, Lcom/hjq/permissions/Permission$Group;->STORAGE:[Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v0, "AE.eCmurdop_droAsnsARoanE.DiNiDL"

    const-string/jumbo v0, "oriLosD.nDeApR.CRanE_idAoEmrsdAN"

    const/4 v4, 0x5

    const-string v0, "ND_naRCpRodnmAp..direiDArssioEAL"

    const-string v0, "android.permission.READ_CALENDAR"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, ".iIRiNW.qr_oCdTasRpdEonDsbrmneEAL"

    const-string v1, ".pmrebCEd.srnsiATRRADiWENod_anLoI"

    const/4 v4, 0x7

    const-string/jumbo v1, "mRsAR.psWNrrdTACLida.nIEnseD_iEoo"

    const-string v1, "android.permission.WRITE_CALENDAR"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    sput-object v0, Lcom/hjq/permissions/Permission$Group;->CALENDAR:[Ljava/lang/String;

    const/4 v4, 0x4

    const-string/jumbo v0, "neimTNdrSCsm.dICrRO_TsTW.iAaipono"

    const-string v0, "android.permission.WRITE_CONTACTS"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, ".dpSoUsenT_rsEo.iCNTridnmioAOCG"

    const-string v1, "android.permission.GET_ACCOUNTS"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v2, "uAEO_bToi.AnDrerdidpsn.sRmCNSCao"

    const-string v2, "aiiRSCuorOnTmneANEToAsD.._dCsrpd"

    const/4 v4, 0x5

    const-string/jumbo v2, "nnmEiSuNTsCooadArAsD_CreT..RpiOd"

    const-string v2, "android.permission.READ_CONTACTS"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    sput-object v0, Lcom/hjq/permissions/Permission$Group;->CONTACTS:[Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v0, "easii_TpLNNO.dOsinTUrmrpCnEp.OEdoHCB"

    const-string v0, "BOrsNEnpTiCnsaiUeC.NimOOLodp.EdroH_T"

    const/4 v4, 0x1

    const-string v0, "BTHTOUE.qdieC_CLNnsiaEdromOpirTNOso."

    const-string v0, "android.permission.BLUETOOTH_CONNECT"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const-string v1, "Ensp.siirTsViSmdTaenROdUOrLDoA_q.HoEIE"

    const-string v1, "DTmIELeSqaiOiiUEs.dRps.nroTdTHrAoVn_OE"

    const/4 v4, 0x1

    const-string v1, "ES.mO._diaITOiodmrEEpHVLeBsDRrAsUTTnin"

    const-string v1, "android.permission.BLUETOOTH_ADVERTISE"

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "_sLio.EaOoBiensOHiUrdTnATCr.mNopd"

    const-string v2, "O.srniSTreBNapdsin_EmOoTUdAH.iLCo"

    const/4 v4, 0x2

    const-string v2, "Adim.b_TCosOBidNnEa.eULHsOTniSrop"

    const-string v2, "android.permission.BLUETOOTH_SCAN"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    sput-object v0, Lcom/hjq/permissions/Permission$Group;->BLUETOOTH:[Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method
