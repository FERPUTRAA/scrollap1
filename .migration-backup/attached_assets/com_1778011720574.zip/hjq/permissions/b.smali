.class public final synthetic Lcom/hjq/permissions/b;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/hjq/permissions/OnPermissionCallback;Ljava/util/List;Z)V
    .locals 2
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "i~s S@ o@~@~/n lKoMi~@~  o ~~b-tv~@@yd~@@ @ta4~f ~@~.~@s ~ ~@@o~@l @@ ~m r f c1 ~bi@@o@@o ~~~b~u"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-void
.end method
