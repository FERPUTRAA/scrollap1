.class public final synthetic Lcom/hjq/permissions/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/permissions/PermissionFragment$2;

.field public final synthetic b:Landroid/app/Activity;

.field public final synthetic c:Ljava/util/ArrayList;

.field public final synthetic d:Ljava/util/List;

.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/permissions/PermissionFragment$2;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/hjq/permissions/h;->a:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/hjq/permissions/h;->b:Landroid/app/Activity;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/hjq/permissions/h;->c:Ljava/util/ArrayList;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/hjq/permissions/h;->d:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput p5, p0, Lcom/hjq/permissions/h;->e:I

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~~scSb@@oa@~i~~mu ~fbl~/l@ @~~~t@o@ oK@@@d~ @~~@~~tr -i~  ~ ~ @ f/ ~ .@~@  v @ ~4@i1@s@~@noMboy "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/hjq/permissions/h;->a:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/hjq/permissions/h;->b:Landroid/app/Activity;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/hjq/permissions/h;->c:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/hjq/permissions/h;->d:Ljava/util/List;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v4, p0, Lcom/hjq/permissions/h;->e:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v0, v1, v2, v3, v4}, Lcom/hjq/permissions/PermissionFragment$2;->a(Lcom/hjq/permissions/PermissionFragment$2;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    return-void
.end method
