.class final Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/permissions/AndroidManifestInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "PermissionInfo"
.end annotation


# static fields
.field private static final REQUESTED_PERMISSION_NEVER_FOR_LOCATION:I


# instance fields
.field maxSdkVersion:I

.field name:Ljava/lang/String;

.field usesPermissionFlags:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/high16 v1, 0x10000

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    sput v1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->REQUESTED_PERMISSION_NEVER_FOR_LOCATION:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    sput v1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->REQUESTED_PERMISSION_NEVER_FOR_LOCATION:I

    :goto_0
    const/4 v3, 0x4

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method neverForLocation()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s@ l~~ ~ nM~@~ o@  @a~@~~it/u c@i~bb4 s~ K@@m@@  / ~l1@@o~-.it@@~~@oo~ @o @dy~~f v~~@So r@ f~b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->usesPermissionFlags:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget v1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->REQUESTED_PERMISSION_NEVER_FOR_LOCATION:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method
