.class final Lcom/hjq/permissions/AndroidManifestParser;
.super Ljava/lang/Object;


# static fields
.field private static final ANDROID_MANIFEST_FILE_NAME:Ljava/lang/String; = "AndroidManifest.xml"

.field private static final ANDROID_NAMESPACE_URI:Ljava/lang/String; = "http://schemas.android.com/apk/res/android"

.field private static final ATTR_MAX_SDK_VERSION:Ljava/lang/String; = "maxSdkVersion"

.field private static final ATTR_MIN_SDK_VERSION:Ljava/lang/String; = "minSdkVersion"

.field private static final ATTR_NAME:Ljava/lang/String; = "name"

.field private static final ATTR_PACKAGE:Ljava/lang/String; = "package"

.field private static final ATTR_PERMISSION:Ljava/lang/String; = "permission"

.field private static final ATTR_REQUEST_LEGACY_EXTERNAL_STORAGE:Ljava/lang/String; = "requestLegacyExternalStorage"

.field private static final ATTR_SUPPORTS_PICTURE_IN_PICTURE:Ljava/lang/String; = "supportsPictureInPicture"

.field private static final ATTR_USES_PERMISSION_FLAGS:Ljava/lang/String; = "usesPermissionFlags"

.field private static final TAG_ACTIVITY:Ljava/lang/String; = "activity"

.field private static final TAG_ACTIVITY_ALIAS:Ljava/lang/String; = "activity-alias"

.field private static final TAG_APPLICATION:Ljava/lang/String; = "application"

.field private static final TAG_MANIFEST:Ljava/lang/String; = "manifest"

.field private static final TAG_SERVICE:Ljava/lang/String; = "service"

.field private static final TAG_USES_PERMISSION:Ljava/lang/String; = "uses-permission"

.field private static final TAG_USES_PERMISSION_SDK_23:Ljava/lang/String; = "uses-permission-sdk-23"

.field private static final TAG_USES_PERMISSION_SDK_M:Ljava/lang/String; = "uses-permission-sdk-m"

.field private static final TAG_USES_SDK:Ljava/lang/String; = "uses-sdk"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private static parseActivityFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;
    .locals 6
    .param p0    # Landroid/content/res/XmlResourceParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " os@@ @~~/~ob~~ ~@@f@c4~~@~@fri.@  @~@@o ~~u~vyol  M b@o~ ttadK o@~@~m@i@s ~@ @- 1iS@l~~b  /~ n~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v1, "aenm"

    const-string v1, "amne"

    const/4 v5, 0x2

    const-string v1, "eanm"

    const-string/jumbo v1, "name"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "//rm.nead/chtdopm:sh/s/ioceaoatriakdnpmdrs"

    const-string v2, "http://schemas.android.com/apk/res/android"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;->name:Ljava/lang/String;

    const/4 v4, 0x2

    and-int/2addr v5, v4

    const-string/jumbo v1, "sPeroipIrecPrtutpnisstuo"

    const-string v1, "etsprrsiPiutscoInrPtecup"

    const/4 v5, 0x2

    const-string/jumbo v1, "supportsPictureInPicture"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {p0, v2, v1, v3}, Landroid/util/AttributeSet;->getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-boolean p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;->supportsPictureInPicture:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v0
.end method

.method static parseAndroidManifest(Landroid/content/Context;I)Lcom/hjq/permissions/AndroidManifestInfo;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "lAiMtbarexdn.ndfmom"

    const-string v1, "dlfmexiAodMinra.tnm"

    const/4 v4, 0x2

    const-string v1, "AixonnutsdlifarMedm"

    const-string v1, "AndroidManifest.xml"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, p1, v1}, Landroid/content/res/AssetManager;->openXmlResourceParser(ILjava/lang/String;)Landroid/content/res/XmlResourceParser;

    move-result-object p0

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq p1, v1, :cond_1

    const/4 v4, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x6

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const-string/jumbo v1, "oestnfip"

    const-string/jumbo v1, "snefoati"

    const/4 v4, 0x7

    const-string/jumbo v1, "qesfaimn"

    const-string/jumbo v1, "manifest"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const-string v1, "beskpaa"

    const-string/jumbo v1, "paeckba"

    const/4 v4, 0x3

    const-string v1, "ekampag"

    const-string/jumbo v1, "package"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->packageName:Ljava/lang/String;

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "-ksdouse"

    const-string v1, "dessksu-"

    const/4 v4, 0x6

    const-string/jumbo v1, "k-sdubse"

    const-string/jumbo v1, "uses-sdk"

    const/4 v4, 0x3

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/AndroidManifestParser;->parseUsesSdkFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->usesSdkInfo:Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "ppie-uursisnosm"

    const-string/jumbo v1, "mip-euopsnsrise"

    const/4 v4, 0x7

    const-string/jumbo v1, "isno-eipeurssms"

    const-string/jumbo v1, "uses-permission"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v1, "r-eskueiqi2-oq-sdss3mp"

    const-string v1, "dsesk--2qserismsu3ip-o"

    const/4 v4, 0x1

    const-string/jumbo v1, "sesd-okesus--rni2pss3m"

    const-string/jumbo v1, "uses-permission-sdk-23"

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "miem-s-s-imnsoeskrsdp"

    const-string v1, "dps-ossk-sensmeii-rms"

    const/4 v4, 0x1

    const-string/jumbo v1, "sme-omnksi-pse-rssdiu"

    const-string/jumbo v1, "uses-permission-sdk-m"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_5

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->permissionInfoList:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/AndroidManifestParser;->parsePermissionFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v3, 0x4

    move v4, v3

    const-string/jumbo v1, "ptmlcbiiopa"

    const-string/jumbo v1, "olpmipactni"

    const/4 v4, 0x6

    const-string v1, "aciaolupnit"

    const-string v1, "application"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/AndroidManifestParser;->parseApplicationFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->applicationInfo:Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "tovitcyp"

    const-string v1, "ctyiovat"

    const/4 v4, 0x2

    const-string v1, "activity"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v1, :cond_7

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "iibyaastqticl-"

    const-string v1, "atiyibcslaait-"

    const/4 v4, 0x5

    const-string/jumbo v1, "tistaiailv-yac"

    const-string v1, "activity-alias"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_8

    :cond_7
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->activityInfoList:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/AndroidManifestParser;->parseActivityFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "eeimsuc"

    const-string/jumbo v1, "resiecu"

    const/4 v4, 0x0

    const-string/jumbo v1, "vceiors"

    const-string/jumbo v1, "service"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p1, :cond_9

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, v0, Lcom/hjq/permissions/AndroidManifestInfo;->serviceInfoList:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/AndroidManifestParser;->parseServerFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_9
    :goto_0
    const/4 v3, 0x4

    move v4, v3

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ne p1, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p0}, Landroid/content/res/XmlResourceParser;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    return-object v0

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p0, :cond_a

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p0}, Landroid/content/res/XmlResourceParser;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :catchall_2
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_a
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw v0
.end method

.method private static parseApplicationFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;
    .locals 6
    .param p0    # Landroid/content/res/XmlResourceParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v1, "amne"

    const-string v1, "aenm"

    const/4 v5, 0x3

    const-string/jumbo v1, "mnea"

    const-string/jumbo v1, "name"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v2, "tacasbso/de:sctkh/rpn.d.i/amdame/rooi/rpdn"

    const-string/jumbo v2, "k/pnpispdomtn.da.cd/:oaercaomsiedrsr/h/t/a"

    const/4 v5, 0x5

    const-string/jumbo v2, "rn/mp/uarar.topi/co:dthdead.osdma//cheksin"

    const-string v2, "http://schemas.android.com/apk/res/android"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;->name:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "EeqtreLptyaecrgeeaalrsqgotxS"

    const-string/jumbo v1, "toqangxEqetaaerrLcyeesrglteS"

    const/4 v5, 0x1

    const-string/jumbo v1, "ucterStnqarEqxesayeegoergatL"

    const-string/jumbo v1, "requestLegacyExternalStorage"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p0, v2, v1, v3}, Landroid/util/AttributeSet;->getAttributeBooleanValue(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-boolean p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;->requestLegacyExternalStorage:Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object v0
.end method

.method private static parsePermissionFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;
    .locals 6
    .param p0    # Landroid/content/res/XmlResourceParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v1, "mane"

    const-string v1, "aenm"

    const/4 v5, 0x6

    const-string/jumbo v1, "name"

    const-string/jumbo v1, "name"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v2, "adst./o/tesnr.rpdaincach:emodsasrsidmkho//"

    const-string v2, "eisotis.csdham.knpd/narr:ad/trme//dpsoohca"

    const/4 v5, 0x0

    const-string/jumbo v2, "ocmmsro/a//tiim/dc.kd/sed.ahapordrnh:senta"

    const-string v2, "http://schemas.android.com/apk/res/android"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v1, "mixooVdrsmena"

    const-string/jumbo v1, "rnxmdmVskaoei"

    const/4 v5, 0x5

    const-string/jumbo v1, "xsVodbkSneima"

    const-string/jumbo v1, "maxSdkVersion"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const v3, 0x7fffffff

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-interface {p0, v2, v1, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->maxSdkVersion:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "nmroseueaisusgoFlPi"

    const-string v1, "aosgomesPnrieFiussl"

    const/4 v5, 0x5

    const-string/jumbo v1, "uinsgilpaesrmssPeso"

    const-string/jumbo v1, "usesPermissionFlags"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {p0, v2, v1, v3}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->usesPermissionFlags:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object v0
.end method

.method private static parseServerFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;
    .locals 5
    .param p0    # Landroid/content/res/XmlResourceParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "mena"

    const-string/jumbo v1, "mnae"

    const/4 v4, 0x1

    const-string/jumbo v1, "mane"

    const-string/jumbo v1, "name"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v2, ":dori//nqdmhsot/.epdpac/btsi/karsaerm.doca"

    const-string v2, ".nrmpb.sitd:/ima/rhsodeooac/kr/aadnep/sdtc"

    const/4 v4, 0x5

    const-string/jumbo v2, "rpsi//comddithserkdr:eonhaa.a/pcn.dat/oss/"

    const-string v2, "http://schemas.android.com/apk/res/android"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;->name:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v1, "surmeisiop"

    const-string/jumbo v1, "opssieurni"

    const/4 v4, 0x1

    const-string/jumbo v1, "ipmnoisors"

    const-string/jumbo v1, "permission"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p0, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;->permission:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method

.method private static parseUsesSdkFromXml(Landroid/content/res/XmlResourceParser;)Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;
    .locals 6
    .param p0    # Landroid/content/res/XmlResourceParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v0, Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0}, Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const-string v1, "SinspbdinmkVe"

    const-string v1, "iVndirmpksnSe"

    const-string/jumbo v1, "inSVdiusmoekn"

    const-string/jumbo v1, "minSdkVersion"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v3, "nmdcia/pp.ehd:tpehs/osm.rn/csd/oataikrd/ao"

    const-string v3, "http://schemas.android.com/apk/res/android"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p0, v3, v1, v2}, Landroid/util/AttributeSet;->getAttributeIntValue(Ljava/lang/String;Ljava/lang/String;I)I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;->minSdkVersion:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v0
.end method
