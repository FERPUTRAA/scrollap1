.class Lcom/hjq/permissions/PermissionDelegateImplV18;
.super Lcom/hjq/permissions/PermissionDelegateImplBase;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@bsm@  ~b/~~@  @@~~4a~~ @   @ t~~uv@d~@o@~oo~o ~ ~o@f/inrl~M~~@@ i@~@ l1it-@ @of b. K@~ ~~S~c@@y"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string v0, "CNnmE.Ir_TIEeRiFIBsiILI.roopTDESNmAVsiOSCITRaNs_EnOdd"

    const-string v0, ".NsDAEdIsdinNICTEFOS.mVrisNT_SIOIB_CEipnroLaoNReITRIE"

    const/4 v2, 0x0

    const-string v0, "aoSOoE.ISIR.TrCLpImDNsdNTIAEEiIdCnoInTOiVE_erN__RisNF"

    const-string v0, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    const/4 v2, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/NotificationListenerPermissionCompat;->getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "CBVnSbimpEsELraTNoTDiI_sReR.dEINOFIo.mCIrS_iE_nNIAdNI"

    const-string v0, "drrmsiCTE_I_dEinIRNI._NTiAEFaSmRIIDoBNSeoOnVTNICL.spE"

    const/4 v2, 0x2

    const-string v0, "SNarnEusIIpNATBECieCOREOoIrsTL._NRImIInoV_T._FSNdEdiD"

    const-string v0, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplBase;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const-string v0, "i_.SmsIpd_EBod_TNoNCoNiLONOAaEEiDsIeCTISrnIERRIpTrVnI"

    const-string v0, "NiimoIIeVNRENoIFInrISCEBOp_TIDEA.isoS_rLddTRsENCnTaO_"

    const/4 v2, 0x6

    const-string v0, "dNVrNInEqNARRnIe_iIEoCiTOa.SpFLDsTOErE_BIiNIsm._dCIST"

    const-string v0, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/hjq/permissions/NotificationListenerPermissionCompat;->isGrantedPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplBase;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p1
.end method
