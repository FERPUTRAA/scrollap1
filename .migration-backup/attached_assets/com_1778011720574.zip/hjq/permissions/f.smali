.class public final synthetic Lcom/hjq/permissions/f;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t1s@n@ @~@o~o   @~  /   -bfo~~l~@@~@c@~d. ~si~@@~~4~Kvt@~~  y r~~@o/@~ bbl~f@~  @@u~i~iSo@@ma oM"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-static {}, Landroid/os/Environment;->isExternalStorageManager()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
