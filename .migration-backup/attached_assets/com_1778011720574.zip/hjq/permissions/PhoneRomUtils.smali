.class final Lcom/hjq/permissions/PhoneRomUtils;
.super Ljava/lang/Object;


# static fields
.field private static final ROM_360:[Ljava/lang/String;

.field private static final ROM_HONOR:[Ljava/lang/String;

.field private static final ROM_HUAWEI:[Ljava/lang/String;

.field private static final ROM_LEECO:[Ljava/lang/String;

.field private static final ROM_NAME_MIUI:Ljava/lang/String; = "ro.miui.ui.version.name"

.field private static final ROM_NUBIA:[Ljava/lang/String;

.field private static final ROM_ONEPLUS:[Ljava/lang/String;

.field private static final ROM_OPPO:[Ljava/lang/String;

.field private static final ROM_SAMSUNG:[Ljava/lang/String;

.field private static final ROM_VIVO:[Ljava/lang/String;

.field private static final ROM_XIAOMI:[Ljava/lang/String;

.field private static final ROM_ZTE:[Ljava/lang/String;

.field private static final VERSION_PROPERTY_360:Ljava/lang/String; = "ro.build.uiversion"

.field private static final VERSION_PROPERTY_HUAWEI:Ljava/lang/String; = "ro.build.version.emui"

.field private static final VERSION_PROPERTY_LEECO:Ljava/lang/String; = "ro.letv.release.version"

.field private static final VERSION_PROPERTY_MAGIC:[Ljava/lang/String;

.field private static final VERSION_PROPERTY_NUBIA:Ljava/lang/String; = "ro.build.rom.id"

.field private static final VERSION_PROPERTY_ONEPLUS:Ljava/lang/String; = "ro.rom.version"

.field private static final VERSION_PROPERTY_OPPO:[Ljava/lang/String;

.field private static final VERSION_PROPERTY_VIVO:Ljava/lang/String; = "ro.vivo.os.build.display.id"

.field private static final VERSION_PROPERTY_XIAOMI:Ljava/lang/String; = "ro.build.version.incremental"

.field private static final VERSION_PROPERTY_ZTE:Ljava/lang/String; = "ro.build.MiFavor_version"


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "wissha"

    const-string/jumbo v0, "iwshea"

    const/4 v3, 0x3

    const-string/jumbo v0, "ueimah"

    const-string v0, "huawei"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_HUAWEI:[Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "vvio"

    const-string/jumbo v0, "oivv"

    const/4 v3, 0x6

    const-string/jumbo v0, "viov"

    const-string/jumbo v0, "vivo"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_VIVO:[Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "imoioa"

    const-string/jumbo v0, "miomai"

    const/4 v3, 0x3

    const-string/jumbo v0, "xiimob"

    const-string/jumbo v0, "xiaomi"

    const/4 v3, 0x3

    const/4 v2, 0x1

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_XIAOMI:[Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "poop"

    const-string/jumbo v0, "oopp"

    const/4 v3, 0x5

    const-string/jumbo v0, "oppo"

    const-string/jumbo v0, "oppo"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_OPPO:[Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v0, "eueoc"

    const-string/jumbo v0, "leceo"

    const/4 v3, 0x5

    const-string/jumbo v0, "leeco"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "letv"

    const-string/jumbo v1, "letv"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_LEECO:[Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "360"

    const-string v0, "360"

    const/4 v3, 0x3

    const-string v0, "036"

    const-string v0, "360"

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "uikq"

    const-string/jumbo v1, "iuqk"

    const/4 v3, 0x1

    const-string/jumbo v1, "qkui"

    const-string/jumbo v1, "qiku"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_360:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v0, "zet"

    const-string/jumbo v0, "zte"

    const/4 v3, 0x1

    const-string/jumbo v0, "zte"

    const-string/jumbo v0, "zte"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_ZTE:[Ljava/lang/String;

    const/4 v2, 0x1

    move v3, v2

    const-string/jumbo v0, "psnpboe"

    const-string/jumbo v0, "lnsoebp"

    const/4 v3, 0x0

    const-string v0, "equlosn"

    const-string/jumbo v0, "oneplus"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_ONEPLUS:[Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "ubsau"

    const-string/jumbo v0, "uuanb"

    const/4 v3, 0x4

    const-string v0, "bunma"

    const-string/jumbo v0, "nubia"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_NUBIA:[Ljava/lang/String;

    const/4 v3, 0x3

    const-string v0, "amsgoup"

    const-string/jumbo v0, "pgmssua"

    const/4 v3, 0x5

    const-string/jumbo v0, "sunasbg"

    const-string/jumbo v0, "samsung"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_SAMSUNG:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "ouonh"

    const-string v0, "hooqn"

    const/4 v3, 0x3

    const-string/jumbo v0, "nhpor"

    const-string v0, "honor"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->ROM_HONOR:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "or.ios.rqdmpplbeuroiosv."

    const-string/jumbo v0, "ilsepo..oordbi.rvruoposm"

    const/4 v3, 0x4

    const-string/jumbo v0, "lnsbipooro...rsorevpudmo"

    const-string/jumbo v0, "ro.build.version.opporom"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "s.dm.rl.iuiuovraolbiplpsrommes.yn"

    const-string/jumbo v1, "obrmd.aon.ol.ieuioppll.irsmusvysr"

    const/4 v3, 0x4

    const-string v1, ".u.lonpuloiyr.eoopbilsd.sovrmsrdi"

    const-string/jumbo v1, "ro.build.version.oplusrom.display"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->VERSION_PROPERTY_OPPO:[Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v0, "os.nosmfc.o.avciginicemr"

    const/4 v3, 0x0

    const-string/jumbo v0, "ngmsobcivs.ifc.ingec.rao"

    const-string/jumbo v0, "msc.config.magic.version"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const-string/jumbo v1, "rc.o.iub.roiuvndgbsiml"

    const-string v1, "i.uvibma.cooild.rnrsgb"

    const/4 v3, 0x7

    const-string/jumbo v1, "lge.aucprvoism.io.rind"

    const-string/jumbo v1, "ro.build.version.magic"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-object v0, Lcom/hjq/permissions/PhoneRomUtils;->VERSION_PROPERTY_MAGIC:[Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method private static getBrand()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "vo~@~~~@q~ 1u ~ @~@@ f ~@old@~4r ~s i~cM-o@ @y@o ~t~m~ft/a@@o~b@@~@i~/ @@   .~~ @~obS  lin@bK~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method private static getManufacturer()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method private static getPropertyName(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/PhoneRomUtils;->getSystemProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method static getRomVersionName()Ljava/lang/String;
    .locals 8
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getBrand()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getManufacturer()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_HUAWEI:[Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x3

    const-string v3, ""

    const/4 v7, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v0, "ousde.mbv.iinoleu.urs"

    const-string/jumbo v0, "oeuoudu.vblinm.rr.eis"

    const-string/jumbo v0, "ro.build.version.emui"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v1, "_"

    const-string v1, "_"

    const/4 v7, 0x3

    const-string v1, "_"

    const-string v1, "_"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    array-length v2, v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-le v2, v4, :cond_0

    const/4 v6, 0x5

    const/4 v7, 0x1

    aget-object v0, v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-object v0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v1, "mtoUoIEpi"

    const/4 v7, 0x1

    const-string/jumbo v1, "oIUmmEont"

    const-string v1, "EmotionUI"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string v1, "IEnqots*/Uimo"

    const-string/jumbo v1, "itoIoEUsq/n*m"

    const/4 v7, 0x3

    const-string/jumbo v1, "mnUsob*tEoi/I"

    const-string v1, "EmotionUI\\s*"

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-object v0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_VIVO:[Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v0, ".rsposi.siol..dadlviu.iyvdo"

    const-string v0, ".olddouiuii.bo.ivlsdpy.ra.s"

    const-string/jumbo v0, "ro.vivo.os.build.display.id"

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_XIAOMI:[Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v2, :cond_4

    const/4 v7, 0x3

    const-string v0, "eelsn.dpmriioonutrabimlnec.."

    const-string/jumbo v0, "ntbmno.ielusoei.rmricnde.alr"

    const/4 v7, 0x5

    const-string/jumbo v0, "ldtebnu.qloa.rseroni.virnmce"

    const-string/jumbo v0, "ro.build.version.incremental"

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object v0

    :cond_4
    const/4 v6, 0x2

    move v7, v6

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_OPPO:[Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v2, :cond_7

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    sget-object v0, Lcom/hjq/permissions/PhoneRomUtils;->VERSION_PROPERTY_OPPO:[Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    array-length v1, v0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ge v4, v1, :cond_6

    const/4 v7, 0x6

    aget-object v2, v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v2, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x2

    move v7, v6

    goto :goto_0

    :cond_5
    const/4 v7, 0x5

    return-object v5

    :cond_6
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-object v3

    :cond_7
    const/4 v7, 0x7

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_LEECO:[Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v2, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v0, "trsns.vrrilse.ea.eeelvo"

    const-string/jumbo v0, "r.eeonrs.soeveariv.letl"

    const/4 v7, 0x2

    const-string v0, "earmrs.se.ol.evetrovlei"

    const-string/jumbo v0, "ro.letv.release.version"

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-object v0

    :cond_8
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_360:[Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v2, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string/jumbo v0, "onruobiroud.ebivil"

    const-string/jumbo v0, "sovoeburdlibiiur.n"

    const/4 v7, 0x0

    const-string v0, ".bdosbnerl.rivuuoi"

    const-string/jumbo v0, "ro.build.uiversion"

    const/4 v6, 0x4

    move v7, v6

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object v0

    :cond_9
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_ZTE:[Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v2, :cond_a

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo v0, "iiorreurslvoaFvM.diun.bo"

    const-string/jumbo v0, "rvMFvlunarroo.d.eb_iosii"

    const-string/jumbo v0, "ureb.vFpirvsnodio.o_rMil"

    const-string/jumbo v0, "ro.build.MiFavor_version"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object v0

    :cond_a
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_ONEPLUS:[Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_b

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v0, ".msnroorqpei.r"

    const-string/jumbo v0, "mnoerrop.v.ris"

    const/4 v7, 0x6

    const-string v0, ".rsroovnmis.er"

    const-string/jumbo v0, "ro.rom.version"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object v0

    :cond_b
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_NUBIA:[Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v2, :cond_c

    const/4 v7, 0x1

    const-string v0, "blrmdoiqd.im.uo"

    const-string v0, ".lobmrodquidi.r"

    const/4 v7, 0x4

    const-string/jumbo v0, "rd.ood.omiriubl"

    const-string/jumbo v0, "ro.build.rom.id"

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v0

    :cond_c
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_HONOR:[Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v0, :cond_f

    const/4 v7, 0x0

    const/4 v6, 0x0

    sget-object v0, Lcom/hjq/permissions/PhoneRomUtils;->VERSION_PROPERTY_MAGIC:[Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    array-length v1, v0

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-ge v4, v1, :cond_e

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    aget-object v2, v0, v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x7

    xor-int/2addr v7, v6

    if-eqz v2, :cond_d

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x5

    and-int/2addr v7, v6

    goto :goto_1

    :cond_d
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-object v5

    :cond_e
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-object v3

    :cond_f
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v3}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-object v0
.end method

.method private static getSystemProperty(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PhoneRomUtils;->getSystemPropertyByShell(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/PhoneRomUtils;->getSystemPropertyByStream(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/16 v2, 0x1c

    const/4 v3, 0x5

    move v4, v3

    if-ge v1, v2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/PhoneRomUtils;->getSystemPropertyByReflect(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p0

    :cond_2
    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method

.method private static getSystemPropertyByReflect(Ljava/lang/String;)Ljava/lang/String;
    .locals 10
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x5

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v9, 0x3

    const-string v1, ""

    const-string v1, ""

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string v2, "StpPabnrsmeir.yeserdt.siodo"

    const-string v2, "android.os.SystemProperties"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x0

    const-string v3, "egt"

    const-string v3, "etg"

    const/4 v9, 0x4

    const-string v3, "get"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v4, 0x2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    aput-object v0, v5, v6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    aput-object v0, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x6

    aput-object p0, v3, v6

    const/4 v9, 0x7

    aput-object v1, v3, v7

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-object p0

    :catch_0
    move-exception p0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto :goto_0

    :catch_1
    move-exception p0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    goto :goto_0

    :catch_2
    move-exception p0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_0

    :catch_3
    move-exception p0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    return-object v1
.end method

.method private static getSystemPropertyByShell(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v3, "prst oup"

    const-string/jumbo v3, "tesoprp "

    const/4 v5, 0x2

    const-string/jumbo v3, "rptp gop"

    const-string v3, "getprop "

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v1, Ljava/io/BufferedReader;

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v2, Ljava/io/InputStreamReader;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v2, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/16 p0, 0x400

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v1, v2, p0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz p0, :cond_0

    :try_start_2
    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v5, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object p0

    :cond_0
    :try_start_3
    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    goto :goto_2

    :catchall_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_3

    :catch_1
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_3

    :catch_2
    move-exception p0

    :goto_1
    :try_start_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    :try_start_5
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_2

    :catch_3
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x7

    return-object p0

    :goto_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_2

    :try_start_6
    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_4

    const/4 v5, 0x4

    goto :goto_4

    :catch_4
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_4
    const/4 v5, 0x1

    throw p0
.end method

.method private static getSystemPropertyByStream(Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v1, Ljava/util/Properties;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/util/Properties;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    new-instance v2, Ljava/io/FileInputStream;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v3, Ljava/io/File;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {}, Landroid/os/Environment;->getRootDirectory()Ljava/io/File;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v5, "pblmopirq."

    const-string/jumbo v5, "rplmdpboi."

    const/4 v7, 0x0

    const-string v5, "build.prop"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v3, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v2, v3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/util/Properties;->load(Ljava/io/InputStream;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1, p0, v0}, Ljava/util/Properties;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-object p0

    :catch_0
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :catch_1
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object v0
.end method

.method static isColorOs()Z
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    sget-object v0, Lcom/hjq/permissions/PhoneRomUtils;->VERSION_PROPERTY_OPPO:[Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    array-length v1, v0

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x7

    xor-int/2addr v5, v2

    const/4 v6, 0x6

    move v3, v2

    move v3, v2

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v3, v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    aget-object v4, v0, v3

    const/4 v5, 0x0

    and-int/2addr v6, v5

    invoke-static {v4}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v2
.end method

.method static isEmui()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo v0, "slsrio...beoduerovini"

    const-string v0, ".dnoo.r.oeimuvelsbrii"

    const/4 v2, 0x5

    const-string v0, "dlim..eom.beuusrvrioi"

    const-string/jumbo v0, "ro.build.version.emui"

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method static isHarmonyOs()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v1

    :cond_0
    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v0, "docioe..a.hEstuxbmsByielw"

    const-string v0, ".ismobyxte.Euledcia.Bhsmw"

    const/4 v5, 0x0

    const-string/jumbo v0, "milsebucwmud.hBitysa.eoEx"

    const-string v0, "com.huawei.system.BuildEx"

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string v2, "Baudgturen"

    const-string v2, "engdaBuOrt"

    const/4 v5, 0x0

    const-string/jumbo v2, "rdBnsetpOa"

    const-string v2, "getOsBrand"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-array v3, v1, [Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v2, "rqmHpay"

    const-string/jumbo v2, "pHrmnya"

    const/4 v5, 0x0

    const-string/jumbo v2, "oysmnaH"

    const-string v2, "Harmony"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v0

    :catchall_0
    move-exception v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v1
.end method

.method static isMagicOs()Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getBrand()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getManufacturer()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_HONOR:[Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0
.end method

.method static isMiui()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "emimiinn.r..ovuqiaesm.o"

    const-string v0, "eiu...rnqiaoiesmormvni."

    const-string/jumbo v0, "oriroou..eiaeunnvm.smii"

    const-string/jumbo v0, "ro.miui.ui.version.name"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method static isMiuiOptimization()Z
    .locals 10
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x1

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v1, 0x2

    const/4 v1, 0x1

    :try_start_0
    const/4 v9, 0x1

    const-string/jumbo v2, "poerabeorsnr.yseSmsoitdPi.d"

    const-string v2, "android.os.SystemProperties"

    const/4 v8, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v3, "teg"

    const-string/jumbo v3, "teg"

    const/4 v9, 0x6

    const-string v3, "gte"

    const-string v3, "get"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v4, 0x2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    aput-object v0, v5, v6

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    aput-object v0, v5, v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v7, "mi.t.ruuoss"

    const-string/jumbo v7, "otsrmi.iu.s"

    const/4 v9, 0x7

    const-string/jumbo v7, "uis.cmtpro."

    const-string/jumbo v7, "ro.miui.cts"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    aput-object v7, v5, v6

    const/4 v9, 0x0

    const-string v7, ""

    const-string v7, ""

    const/4 v9, 0x4

    const-string v7, ""

    const-string v7, ""

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    aput-object v7, v5, v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v3, v2, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo v5, "teoaogemqB"

    const-string/jumbo v5, "leomatBoeg"

    const/4 v9, 0x5

    const-string/jumbo v5, "oesltoeBag"

    const-string v5, "getBoolean"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-array v7, v4, [Ljava/lang/Class;

    const/4 v8, 0x4

    move v9, v8

    aput-object v0, v7, v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    sget-object v0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    aput-object v0, v7, v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v2, v5, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v5, "is.ms_ri.utyptoainomiomtiepsi"

    const-string/jumbo v5, "posmosyrtieptt.iuami.sinoi_si"

    const/4 v9, 0x7

    const-string/jumbo v5, "rzpioop.sti.sonesmmiistitia_u"

    const-string/jumbo v5, "persist.sys.miui_optimization"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    aput-object v5, v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    const-string v5, "1"

    const-string v5, "1"

    const/4 v9, 0x4

    const-string v5, "1"

    const-string v5, "1"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    if-nez v3, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    move v6, v1

    move v6, v1

    const/4 v9, 0x6

    move v6, v1

    move v6, v1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    aput-object v3, v4, v1

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    return v0

    :catch_0
    move-exception v0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto :goto_0

    :catch_1
    move-exception v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_0

    :catch_2
    move-exception v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_0

    :catch_3
    move-exception v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    return v1
.end method

.method static isOneUi()Z
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getBrand()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getManufacturer()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v2, Lcom/hjq/permissions/PhoneRomUtils;->ROM_SAMSUNG:[Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PhoneRomUtils;->isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0
.end method

.method static isOriginOs()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "d..pibvviboa.slsbr..odyidol"

    const-string v0, ".pdldbrdvsl.o.iyuioo.s.ibva"

    const/4 v2, 0x1

    const-string/jumbo v0, "su.db.u.ioio.adiydpvro.sllv"

    const-string/jumbo v0, "ro.vivo.os.build.display.id"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/hjq/permissions/PhoneRomUtils;->getPropertyName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x2

    move v2, v1

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method private static varargs isRightRom(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    array-length v0, p2

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x0

    move v6, v1

    const/4 v5, 0x3

    move v6, v5

    move v2, v1

    move v2, v1

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ge v2, v0, :cond_2

    const/4 v5, 0x6

    or-int/2addr v6, v5

    aget-object v3, p2, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 p0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    return p0

    :cond_2
    const/4 v5, 0x0

    const/4 v6, 0x0

    return v1
.end method
