.class public final synthetic Lcom/hjq/permissions/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/PermissionInfo;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " is yl@vd-S  ~ @~@@.m @a/os  l~o b~b~~  on~ o~@~~ o@~K@4~@o1i@~@/~@t~c M@~ ~~fu@r@  ft@i@~@~~~@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/pm/PermissionInfo;->getProtection()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    return p0
.end method
