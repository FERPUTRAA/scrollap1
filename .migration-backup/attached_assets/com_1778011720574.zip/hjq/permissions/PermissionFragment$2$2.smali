.class Lcom/hjq/permissions/PermissionFragment$2$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/hjq/permissions/OnPermissionCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hjq/permissions/PermissionFragment$2;->lambda$onGranted$0(Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/hjq/permissions/PermissionFragment$2;

.field final synthetic val$allPermissions:Ljava/util/List;

.field final synthetic val$requestCode:I

.field final synthetic val$secondPermissions:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lcom/hjq/permissions/PermissionFragment$2;Ljava/util/List;ILjava/util/ArrayList;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->this$1:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p3, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$requestCode:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$secondPermissions:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onDenied(Ljava/util/List;Z)V
    .locals 5
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->this$1:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/app/Fragment;->isAdded()Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    new-array p1, p1, [I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 p2, 0x0

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    move v0, p2

    move v0, p2

    const/4 v4, 0x7

    move v0, p2

    move v0, p2

    :goto_0
    const/4 v3, 0x2

    move v4, v3

    iget-object v1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-ge v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$secondPermissions:Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :cond_1
    const/4 v4, 0x4

    move v1, p2

    move v1, p2

    const/4 v4, 0x4

    move v1, p2

    move v1, p2

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput v1, p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->this$1:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, v0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$requestCode:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-array p2, p2, [Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v2, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast p2, [Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p2, p1}, Lcom/hjq/permissions/PermissionFragment;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/4 v4, 0x7

    return-void
.end method

.method public onGranted(Ljava/util/List;Z)V
    .locals 5
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p2, :cond_1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->this$1:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p1, p1, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/app/Fragment;->isAdded()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-array p1, p1, [I

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    const/4 p2, 0x0

    move v4, p2

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1, p2}, Ljava/util/Arrays;->fill([II)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->this$1:Lcom/hjq/permissions/PermissionFragment$2;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, v0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v1, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$requestCode:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/hjq/permissions/PermissionFragment$2$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x5

    new-array p2, p2, [Ljava/lang/String;

    const/4 v4, 0x7

    invoke-interface {v2, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p2, [Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p2, p1}, Lcom/hjq/permissions/PermissionFragment;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method
