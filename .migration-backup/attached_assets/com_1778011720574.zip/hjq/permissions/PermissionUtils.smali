.class final Lcom/hjq/permissions/PermissionUtils;
.super Ljava/lang/Object;


# static fields
.field private static final HANDLER:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object v0, Lcom/hjq/permissions/PermissionUtils;->HANDLER:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method static areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-wide/32 v0, 0x10000

    const-wide/32 v0, 0x10000

    const/4 v3, 0x1

    const-wide/32 v0, 0x10000

    const-wide/32 v0, 0x10000

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lo0/a;->a(J)Landroid/content/pm/PackageManager$ResolveInfoFlags;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0, p1, v0}, Lcom/hjq/permissions/k;->a(Landroid/content/pm/PackageManager;Landroid/content/Intent;Landroid/content/pm/PackageManager$ResolveInfoFlags;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    xor-int/lit8 p0, p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/high16 v0, 0x10000

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    xor-int/lit8 p0, p0, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p0
.end method

.method static varargs asArrayList([Ljava/lang/Object;)Ljava/util/ArrayList;
    .locals 6
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v0, 0x0

    shl-int/2addr v5, v0

    const/4 v4, 0x7

    move v5, v4

    if-eqz p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    array-length v1, p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v2, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz p0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    array-length v1, p0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    array-length v1, p0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    if-ge v0, v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    aget-object v3, p0, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v2
.end method

.method static varargs asArrayLists([[Ljava/lang/Object;)Ljava/util/ArrayList;
    .locals 6
    .param p0    # [[Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([[TT;)",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    .annotation runtime Ljava/lang/SafeVarargs;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    array-length v1, p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    move v5, v4

    array-length v1, p0

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ge v2, v1, :cond_1

    const/4 v5, 0x6

    aget-object v3, p0, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v3}, Lcom/hjq/permissions/PermissionUtils;->asArrayList([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v0
.end method

.method static checkOpNoThrow(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v3, 0x3

    const-string/jumbo v0, "ppsosa"

    const-string/jumbo v0, "saspop"

    const-string/jumbo v0, "popmpa"

    const-string v0, "appops"

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Landroid/app/AppOpsManager;

    const/4 v3, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, p1, v1, p0}, Lcom/hjq/permissions/j;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1, v1, p0}, Landroid/app/AppOpsManager;->checkOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez p0, :cond_1

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_1

    :cond_1
    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p0, 0x0

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p0
.end method

.method static checkOpNoThrow(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 11
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string/jumbo v0, "pmppoa"

    const-string/jumbo v0, "papmop"

    const/4 v10, 0x2

    const-string v0, "apspob"

    const-string v0, "appops"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    check-cast v0, Landroid/app/AppOpsManager;

    const/4 v10, 0x7

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v2, 0x1

    :try_start_0
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-class v3, Landroid/app/AppOpsManager;

    const-class v3, Landroid/app/AppOpsManager;

    const/4 v10, 0x4

    const-class v3, Landroid/app/AppOpsManager;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-class v4, Ljava/lang/Integer;

    const/4 v10, 0x7

    const-class v4, Ljava/lang/Integer;

    const-class v4, Ljava/lang/Integer;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p2
    :try_end_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v10, 0x7

    const-string/jumbo p1, "wNoepcuhkTocOr"

    const-string p1, "TcOkoehrwphNoc"

    const/4 v10, 0x0

    const-string/jumbo p1, "kwhopOrpoNTceh"

    const-string p1, "checkOpNoThrow"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v4, 0x3

    const/4 v9, 0x2

    const/4 v9, 0x3

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x6

    const/4 v7, 0x0

    const/4 v10, 0x3

    move v9, v7

    move v9, v7

    const/4 v10, 0x6

    aput-object v6, v5, v7

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    aput-object v6, v5, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v10, 0x6

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v8, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    aput-object v6, v5, v8

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v3, p1, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v10, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    aput-object p2, v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-object p2, v3, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    aput-object p0, v3, v8

    const/4 v10, 0x0

    const/4 v9, 0x0

    invoke-virtual {p1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    check-cast p0, Ljava/lang/Integer;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_2
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-nez p0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_1

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    move v2, v7

    move v2, v7

    const/4 v10, 0x5

    move v2, v7

    move v2, v7

    :catch_1
    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    return v2
.end method

.method static checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 p0, 0x1

    shr-int/2addr v1, p0

    const/4 v0, 0x2

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method static containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z
    .locals 4
    .param p0    # Ljava/util/Collection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")Z"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    return v1

    :cond_0
    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x4

    return p0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return v1
.end method

.method static containsPermission([Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p0
.end method

.method static equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 7
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eq v0, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    return v2

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    sub-int/2addr v0, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ltz v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    if-eq v3, v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x6

    return v2

    :cond_1
    const/4 v6, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    return v1
.end method

.method static findActivity(Landroid/content/Context;)Landroid/app/Activity;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast p0, Landroid/app/Activity;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v0, p0, Landroid/content/ContextWrapper;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p0, Landroid/content/ContextWrapper;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p0, :cond_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v1
.end method

.method static findApkPathCookie(Landroid/content/Context;Ljava/lang/String;)I
    .locals 11
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v2
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/16 v3, 0x1c

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v10, 0x6

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-lt v2, v3, :cond_0

    :try_start_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->getAndroidVersionCode()I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-lt v2, v3, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->getAndroidVersionCode()I

    move-result v2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v3, 0x1e

    const/4 v10, 0x2

    if-ge v2, v3, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-class v2, Ljava/lang/Class;

    const-class v2, Ljava/lang/Class;

    const/4 v10, 0x5

    const-class v2, Ljava/lang/Class;

    const-class v2, Ljava/lang/Class;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const-string v3, "MectDgblqaterdhee"

    const-string v3, "DaedhbeetlgtdecMr"

    const/4 v10, 0x4

    const-string/jumbo v3, "otstMledghcereDea"

    const-string v3, "getDeclaredMethod"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v6, 0x2

    const/4 v10, 0x5

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v9, 0x2

    move v10, v9

    aput-object v4, v7, v1

    const/4 v10, 0x3

    const-class v8, [Ljava/lang/Class;

    const-class v8, [Ljava/lang/Class;

    const/4 v10, 0x5

    const-class v8, [Ljava/lang/Class;

    const-class v8, [Ljava/lang/Class;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    aput-object v8, v7, v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v2, v3, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v9, 0x6

    move v10, v9

    const-class v3, Landroid/content/res/AssetManager;

    const-class v3, Landroid/content/res/AssetManager;

    const/4 v10, 0x2

    const-class v3, Landroid/content/res/AssetManager;

    const-class v3, Landroid/content/res/AssetManager;

    const/4 v10, 0x7

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string/jumbo v7, "nPemoafuihdFotkoi"

    const-string v7, "iPokdfuthCooeFina"

    const/4 v10, 0x3

    const-string/jumbo v7, "tdnfoCkaiPoFehoro"

    const-string v7, "findCookieForPath"

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    aput-object v7, v6, v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    new-array v7, v5, [Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    aput-object v4, v7, v1

    const/4 v10, 0x2

    aput-object v7, v6, v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v2, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    check-cast v2, Ljava/lang/reflect/Method;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eqz v2, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x1

    invoke-virtual {v2, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v9, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-array v3, v5, [Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-object p1, v3, v1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v2, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    check-cast p0, Ljava/lang/Integer;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz p0, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    return p0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo v2, "tdthsadpaPsA"

    const/4 v10, 0x0

    const-string v2, "adetdbtAhssP"

    const-string v2, "addAssetPath"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-array v3, v5, [Ljava/lang/Class;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    aput-object v4, v3, v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p0, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-array v2, v5, [Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    aput-object p1, v2, v1

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {p0, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    check-cast p0, Ljava/lang/Integer;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz p0, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    return p0

    :catch_0
    move-exception p0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_0

    :catch_1
    move-exception p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_0

    :catch_2
    move-exception p0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    return v1
.end method

.method static getAndroidManifestInfo(Landroid/content/Context;)Lcom/hjq/permissions/AndroidManifestInfo;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->findApkPathCookie(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v1

    :cond_0
    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/AndroidManifestParser;->parseAndroidManifest(Landroid/content/Context;I)Lcom/hjq/permissions/AndroidManifestInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v2, v0, Lcom/hjq/permissions/AndroidManifestInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-static {p0, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez p0, :cond_1

    const/4 v4, 0x0

    return-object v1

    :catch_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :catch_1
    move-exception p0

    :goto_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_1

    :catch_2
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :catch_3
    move-exception p0

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v0
.end method

.method static getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "a:epqaug"

    const-string/jumbo v1, "qagacp:e"

    const-string v1, "gkaacpep"

    const-string/jumbo v1, "package:"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0
.end method

.method static isActivityReverse(Landroid/app/Activity;)Z
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/i;->a(Landroid/app/Activity;)Landroid/view/Display;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/Display;->getRotation()I

    move-result p0

    const/4 v2, 0x3

    move v3, v2

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eq p0, v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eq p0, v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x0

    return p0
.end method

.method static isDebugMode(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v0, 0x7

    move v1, v0

    and-int/lit8 p0, p0, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p0, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p0
.end method

.method static isScopedStorage(Landroid/content/Context;)Z
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v0, "eesapSocdgtSr"

    const-string/jumbo v0, "oSaeeptgqcord"

    const-string v0, "ScopedStorage"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/16 v2, 0x80

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return p0

    :catch_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return p0
.end method

.method static lockActivityOrientation(Landroid/app/Activity;)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SwitchIntDef"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq v0, v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->isActivityReverse(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/16 v0, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    const/4 v2, 0x4

    and-int/2addr v3, v2

    goto :goto_1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->isActivityReverse(Landroid/app/Activity;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/16 v1, 0x9

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_1

    :catch_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method static postActivityResult(Ljava/util/List;Ljava/lang/Runnable;)V
    .locals 7
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/Runnable;",
            ")V"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-wide/16 v1, 0x12c

    const-wide/16 v1, 0x12c

    const/4 v6, 0x5

    const-wide/16 v1, 0x12c

    const-wide/16 v1, 0x12c

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v6, 0x2

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v5, 0x1

    move v6, v5

    goto :goto_0

    :cond_0
    move-wide v3, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isEmui()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-nez v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isHarmonyOs()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiui()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v0, "smsEPOrTIEABaQrdNRdo_MnOesTi.STGSEUOZIm._TIIopRTAiEYinN"

    const-string/jumbo v0, "oNIm.EnSQGA_ZmOiAPR.EddsTTIRarsTTniIipEYeBONRISEMT_OUro"

    const-string v0, "STTmZNMIA_.nGdOda_PmiE_BTIiTEYIERTrnoIUSNRiQOeRsEsrA.pO"

    const-string v0, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz p0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v6, 0x1

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_2

    :cond_2
    move-wide v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-eqz p0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_2

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v6, 0x5

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, v1, v2}, Lcom/hjq/permissions/PermissionUtils;->postDelayed(Ljava/lang/Runnable;J)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void
.end method

.method static postDelayed(Ljava/lang/Runnable;J)V
    .locals 3
    .param p0    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    sget-object v0, Lcom/hjq/permissions/PermissionUtils;->HANDLER:Landroid/os/Handler;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method static shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 9
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        api = 0x17
    .end annotation

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->getAndroidVersionCode()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/16 v1, 0x1f

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ne v0, v1, :cond_0

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-class v1, Landroid/content/pm/PackageManager;

    const-class v1, Landroid/content/pm/PackageManager;

    const/4 v8, 0x3

    const-class v1, Landroid/content/pm/PackageManager;

    const-class v1, Landroid/content/pm/PackageManager;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v2, "ntPoohuamoisRehRaquoelostwdnsliresei"

    const-string v2, "htlmowsdtRihoosuinsouSeeaerlqRsPnaie"

    const/4 v8, 0x2

    const-string/jumbo v2, "seiaebRhhudnsleqSeoanPotitruoiwmslos"

    const-string/jumbo v2, "shouldShowRequestPermissionRationale"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x7

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    aput-object v5, v4, v6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    aput-object p1, v2, v6

    const/4 v8, 0x7

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast v0, Ljava/lang/Boolean;

    const/4 v8, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    return p0

    :catch_0
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_0

    :catch_1
    move-exception v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_0

    :catch_2
    move-exception v0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Landroid/app/Activity;->shouldShowRequestPermissionRationale(Ljava/lang/String;)Z

    move-result p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    return p0
.end method
