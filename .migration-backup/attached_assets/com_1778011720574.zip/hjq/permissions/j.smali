.class public final synthetic Lcom/hjq/permissions/j;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "m~s~~i ~.b~ ~l~@M -u/@i ~lb~ff1@@ /~yb@so@~n @@~to~ o@4o @~v@@@@c  S~@~@~o t~@ a@ ~r~i~K   @o@ d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1, p2, p3}, Landroid/app/AppOpsManager;->unsafeCheckOpNoThrow(Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method
