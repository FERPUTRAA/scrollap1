.class Lcom/hjq/permissions/PermissionDelegateImplV23;
.super Lcom/hjq/permissions/PermissionDelegateImplV21;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV21;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-void
.end method

.method private static getIgnoreBatteryPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~~tb@oSm ~.@ib@1~~ @ ~@o ~u @~@~@ltd/ @~-@~~on~ 4 ~~~o ob~@ o@@f~@is@@ ~~cfv  KMly@@/ ~ i@a r"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, "ATTmN.oSRsgEsQRt_BIYeSPOIMnErOnUiIAIaT_TiEdRdONtG._ZE"

    const-string v1, "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "ITa.oPBGNsdSiZETsOdetosEIIMAE.Nngi_RYTtNOrRTGTOSI__IA"

    const-string/jumbo v1, "tOstPRSnOYTIiIN_AOGIg.B__MNrodEA.NsTITeaGRTTEEiZsdSTI"

    const/4 v3, 0x6

    const-string v1, "ItATGbEOnGOBsT_Ird.IoITSRITPNaNeEMNRAisgTST.Yi__EtZOn"

    const-string v1, "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method private static getNotDisturbPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, ".CeNnCuNirAaSCOgoSYSnTsLITt__EmOEdFIAGITPCsItTSNdO_i"

    const-string v1, "YGSmNnddITT_ESTro.OtsNOCCCAsI_iaFPgNeIIL_OSitC.AnTES"

    const/4 v4, 0x4

    const-string v1, "android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS"

    const/4 v3, 0x4

    or-int/2addr v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v2, "Tod_AoIp_STCIdOInE_NisIOSAIT.OtPeiN.tTLrNaSEsEYICDFCC_GAgnL"

    const-string v2, "CFT_oTdYTOiCEoCsLCI_NSIItPrOLNNaSAEItTs_G.dOInAg_n.ESITeDAi"

    const/4 v4, 0x0

    const-string v2, "dGOIETiOqnOAITISDTn_rCsit_EsA.SP_NALaIdeSITCC_CENINgtFYS.oL"

    const-string v2, "android.settings.NOTIFICATION_POLICY_ACCESS_DETAIL_SETTINGS"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isHarmonyOs()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMagicOs()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_2

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v1, :cond_3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0
.end method

.method private static getSettingPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "sMs_GsSIdonEgAr.R.N_ticSnWINbTinoE.TaeEGtaATi"

    const-string/jumbo v1, "sE_iobs_ac.TAEadWIgdiM.neITnTEtRtnrSiN.SGGoAN"

    const/4 v3, 0x7

    const-string v1, "TNtmsn.edTi.g.rnAEiSNdEcioEIRoSGtaTIs_AanGWM_"

    const-string v1, "android.settings.action.MANAGE_WRITE_SETTINGS"

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method

.method private static isGrantedIgnoreBatteryPermission(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-class v0, Landroid/os/PowerManager;

    const-class v0, Landroid/os/PowerManager;

    const/4 v2, 0x4

    const-class v0, Landroid/os/PowerManager;

    const-class v0, Landroid/os/PowerManager;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast v0, Landroid/os/PowerManager;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Landroid/os/PowerManager;->isIgnoringBatteryOptimizations(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x6

    return p0
.end method

.method private static isGrantedNotDisturbPermission(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-class v0, Landroid/app/NotificationManager;

    const-class v0, Landroid/app/NotificationManager;

    const/4 v2, 0x6

    const-class v0, Landroid/app/NotificationManager;

    const-class v0, Landroid/app/NotificationManager;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/app/NotificationManager;->isNotificationPolicyAccessGranted()Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method private static isGrantedSettingPermission(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Landroid/provider/Settings$System;->canWrite(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "rdinoiTNmSodL_PrEAsSuaADGIe.TLscn_pmPE.oi"

    const-string v0, "_cEPGEudSimriTSDn.TLLdosaIAos.Pe.nAri_mpN"

    const/4 v2, 0x1

    const-string v0, "SriErbs_STie.iEnpPdm..IAmLLsoTDdGa_oNnocP"

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const-string/jumbo v0, "niASpiuLYdWRriISNrTmOspoMTn_W_.aEDeEo."

    const-string v0, "SN_SrWdpmis_YTL.pn.DraREisneiWoOoMETIA"

    const/4 v2, 0x5

    const-string v0, "MLT_Y.Wprp_.NWiEEismaiSrSRnIosonDdOeAT"

    const-string v0, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/hjq/permissions/WindowPermissionCompat;->getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string v0, ".rinopiNqiTSWeEER_Gmarsd.IIdnSToT"

    const-string v0, "android.permission.WRITE_SETTINGS"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p2, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :cond_2
    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->getSettingPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string v0, "OTsrE_aisIOpNFISrCPCS_.oOnnIACdIme.iqCsNYLidT"

    const-string v0, "iS_AFTYTqCCn._eNdmrOdaCPiIoE.NsCnIsiOSLIrIOAp"

    const/4 v2, 0x5

    const-string v0, "InLmd.TAiCIpSCiO.ssdomCrNnEe_aNOPoriY_FIIOAST"

    const-string v0, "android.permission.ACCESS_NOTIFICATION_POLICY"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    if-eqz v0, :cond_5

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez p2, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-object p1

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->getNotDisturbPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1

    :cond_5
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "RBsssUTnT.TEI.NI_SdYRoTEOmQrZRPEMOdErOIIiaGT_iSAiNApon_"

    const/4 v2, 0x4

    const-string/jumbo v0, "oReroGNaT_EniTTIYBEipPQSITAAsOTEnOUNosir.dREd_IS_.IMRZm"

    const-string v0, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_7

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez p2, :cond_6

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1

    :cond_6
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->getIgnoreBatteryPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    return-object p1

    :cond_7
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV21;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 7
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p2}, Lcom/hjq/permissions/PermissionHelper;->isSpecialPermission(Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_3

    const/4 v6, 0x4

    const-string v0, "IcE.pbmi_oidLPTAmrr.o_Lm.neNsEDPAsGoanTSS"

    const-string v0, "LDnm.oPTi.AdN.LdmGsseS_pnTEEAamrcrooSi_IP"

    const-string v0, "d._desuG.smTLnSPoArEa.Tn_oDNmpAPcIirioiSL"

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isDoNotAskAgainPermission(Landroid/app/Activity;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    return p1

    :cond_0
    const/4 v6, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v6, 0x4

    return v1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez p1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x1

    :cond_2
    return v1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v0, "YnOAT.epEICnSioNNpSrmFAaOCIToCC_dr_IidsiO.osL"

    const-string v0, "eNCLoOiInFAAIECrO_dpdY.TSNaCIiCsnsoOrmSo_i.PT"

    const/4 v6, 0x1

    const-string/jumbo v0, "oE.oNCrsqiOIidTCFSpnLYA.ONS_nCaIATOmIdPesI_iC"

    const-string v0, "android.permission.ACCESS_NOTIFICATION_POLICY"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v2, "OSsrNQUsE_mIRRIRTBreTIo_EPESdAsi._iabnIN.TAdOZOEYpTGMio"

    const-string v2, "dTZARbEI.TnrIpiOsTRRYaEoio_QrOU.APIinmESOG_BTNedEMSINs_"

    const/4 v6, 0x3

    const-string/jumbo v2, "siUmIRArGTPp__SnArTaiY_MNS.RsEOeoiZONTmEBIRQdIO.dIToTnE"

    const-string v2, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v3, "rWsEoodiLr_ui.YT_SdoIENDnMT.OpmRaAWiSe"

    const-string v3, "eWrnNYuATinTiEMWOIidaos.rSR_p_oLEmDS.d"

    const/4 v6, 0x2

    const-string v3, "M_AW_bOn.ipELIsSSnaNTWiRYDTdodmo.rseri"

    const-string v3, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v6, 0x4

    const-string/jumbo v4, "nTedNEuIRoGsdm.Tp_.iEInrSsSWrToia"

    const-string v4, ".aiSeiWpnsrE_GT.domNIsEdprTTSRnoI"

    const/4 v6, 0x6

    const-string v4, "_oiSIndprsETiInpaWsTeNm..EGorRidT"

    const-string v4, "android.permission.WRITE_SETTINGS"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    filled-new-array {v3, v4, v0, v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    return v1

    :cond_4
    const/4 v6, 0x3

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV21;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2}, Lcom/hjq/permissions/PermissionHelper;->isSpecialPermission(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v0, "PdAniSiqqeS.Tm.L_cr.mEdsALoaGnNsoPDoI_pri"

    const-string v0, "SDLiiAA_qipcEELPssamrnooGI_PTo.dS.Nnrem.d"

    const/4 v3, 0x2

    const-string v0, "adssdDp_iP_eELLNoPsrm.irSoAnAc.nITi.moGST"

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isGrantedPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v1

    :cond_1
    const/4 v3, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "nETmRdsdLorETrnONSiYp_eIi.ssDoWA_mMSW."

    const-string/jumbo v0, "oEsMYsoe_rEnWnADmNdLTpTiOdiSSr.iIR_.Ws"

    const/4 v3, 0x1

    const-string v0, "L_rEodeosDpNiInsiTTWRAmWrOoSd._SY.MEin"

    const-string v0, "android.permission.SYSTEM_ALERT_WINDOW"

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/hjq/permissions/WindowPermissionCompat;->isGrantedPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p1

    :cond_3
    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "eErTrbIiWITTosspai_mniRmS.EGNodSn"

    const-string v0, "ImimTSiWdEeaonETn_irsdoR.rSNspTIG"

    const/4 v3, 0x3

    const-string/jumbo v0, "niTSm.uI_rErEoS.dWTsRnepINsoiaGdT"

    const-string v0, "android.permission.WRITE_SETTINGS"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez p2, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x7

    return v1

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isGrantedSettingPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p1

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v0, "CioOIiPpeAa.NCiIsp_dFITCTC_AOdnEmoSrnNrSYo.LO"

    const-string v0, "FSd.oOirISOIiTCLY._pnCNOosnrodeCA_NaTCsmPIAEi"

    const/4 v3, 0x5

    const-string v0, "E_dNCiCYqICIooSC_pIIemsraNOiSAdnTOsr.PAFO.Lin"

    const-string v0, "android.permission.ACCESS_NOTIFICATION_POLICY"

    const/4 v3, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_7

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez p2, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v1

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isGrantedNotDisturbPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    return p1

    :cond_7
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v0, "TmsdoOSTdIPIIIsRRENsbNET___ApnraiOTT.GESEeYBROAro.UiQMn"

    const-string v0, "EsI.UbedRrTAnESsIQiOnNaMPTrBGo_AEYNOiiOSdRTRIoEIpmT.T__"

    const/4 v3, 0x0

    const-string v0, "TISmRYBN__GQ_ESOZIUrIOEoir.nidieTnmAoTEOMTRp.asEsPRNATd"

    const-string v0, "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_9

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez p2, :cond_8

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_8
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isGrantedIgnoreBatteryPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p1

    :cond_9
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV21;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1
.end method

.method public recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "EDrdoGiETPmpsILmscPSiA.rAin_o_edLNouo..na"

    const-string v0, "_ic.pmue_ssrnP.oAiLPSmSioonErdaTDLdANEIG."

    const/4 v2, 0x4

    const-string v0, "Gi.rIbPoncL_.SNmaDm.sedoiAPTALTiSE_sodErn"

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/hjq/permissions/PermissionDelegateImplBase;->recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method
