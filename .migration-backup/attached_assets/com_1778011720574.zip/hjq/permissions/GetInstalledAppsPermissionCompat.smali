.class final Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;
.super Ljava/lang/Object;


# static fields
.field private static final MIUI_OP_GET_INSTALLED_APPS_DEFAULT_VALUE:I = 0x2726

.field private static final MIUI_OP_GET_INSTALLED_APPS_FIELD_NAME:Ljava/lang/String; = "OP_GET_INSTALLED_APPS"


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bosfri~4~ d~~@~ ~n Sfuo~@@Kt @~ @~ob-~l~@@ @v@~1l ~. @iso/ b ym@@ ~@/ i@@@~ ~~~o o  cM@~@@t@a~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiui()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiuiOptimization()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getMiuiPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-static {v0, p0}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method static isDoNotAskAgainPermission(Landroid/app/Activity;)Z
    .locals 6
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid4_4()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isSupportGetInstalledAppsPermission(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v0, "PEomGiIs_sNe.pdSidAP.r._LrnsaAmicoSLDmETo"

    const-string/jumbo v0, "pNserio.sS.aTEP_oGLISEr.AciomnsDnd_LdimPA"

    const/4 v5, 0x6

    const-string/jumbo v0, "in.Po_d_LmpTrcimEsTsdniaIAe.SADNPSoELorG."

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v3, :cond_1

    const/4 v5, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    const/4 v5, 0x1

    move v1, v2

    move v1, v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiui()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isMiuiSupportGetInstalledAppsPermission()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v5, 0x5

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiuiOptimization()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isGrantedPermission(Landroid/content/Context;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    xor-int/2addr p0, v2

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    return p0

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v1
.end method

.method static isGrantedPermission(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    move v3, v2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid4_4()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x5

    and-int/2addr v3, v2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isSupportGetInstalledAppsPermission(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const-string v0, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiui()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v2, 0x3

    or-int/2addr v3, v2

    invoke-static {}, Lcom/hjq/permissions/GetInstalledAppsPermissionCompat;->isMiuiSupportGetInstalledAppsPermission()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    move v3, v2

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isMiuiOptimization()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_2

    const/4 v3, 0x0

    return v1

    :cond_2
    const/4 v3, 0x4

    const-string v0, "ANE_IbE_T_PLOTSGmAPPD"

    const-string v0, "PO_mLTGTADEE_SISP_ANP"

    const/4 v3, 0x5

    const-string v0, "OP_GET_INSTALLED_APPS"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v1, 0x2726

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lcom/hjq/permissions/PermissionUtils;->checkOpNoThrow(Landroid/content/Context;Ljava/lang/String;I)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return p0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v1
.end method

.method private static isMiuiSupportGetInstalledAppsPermission()Z
    .locals 5

    const/4 v4, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid4_4()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1

    :cond_0
    :try_start_0
    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v4, 0x3

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v2, "ALP_SAuG_EP_TNESTOLPD"

    const-string v2, "OP_GET_INSTALLED_APPS"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1

    :catch_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :catch_1
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    or-int/2addr v4, v3

    return v0
.end method

.method private static isSupportGetInstalledAppsPermission(Landroid/content/Context;)Z
    .locals 6
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x2

    or-int/2addr v4, v1

    :try_start_0
    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v3, "e_dLs.opT.N.APoGisTo_nEpmDSinEiLArSacIPdm"

    const-string v3, "LTsPoNTnnP_ddirSom._iDosSiIAGa.E.LcpEmAeo"

    const/4 v5, 0x1

    const-string/jumbo v3, "paTcSn.iqNDeLErsrE.Iim_PiLAAPo.d_TdmnoosS"

    const-string v3, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v3, v0}, Landroid/content/pm/PackageManager;->getPermissionInfo(Ljava/lang/String;I)Landroid/content/pm/PermissionInfo;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid9()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/hjq/permissions/a;->a(Landroid/content/pm/PermissionInfo;)I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne p0, v1, :cond_0

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    :cond_0
    const/4 v4, 0x5

    const/4 v5, 0x6

    return v0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    iget p0, v2, Landroid/content/pm/PermissionInfo;->protectionLevel:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    and-int/lit8 p0, p0, 0xf

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-ne p0, v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    return v0

    :catch_0
    move-exception v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3
    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v2, "peslaboro_ateenn_rsebm_p_pisnsielaismn_eitdu"

    const-string/jumbo v2, "priuabsrln_pi_seosiemnam_penmlao_teenteibd_s"

    const/4 v5, 0x4

    const-string/jumbo v2, "rlmm_nimpssmpseeolanit_sreplna__dab_itnuieee"

    const-string/jumbo v2, "oem_installed_apps_runtime_permission_enable"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0, v2}, Landroid/provider/Settings$Secure;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result p0
    :try_end_1
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v4, 0x2

    const/4 v4, 0x2

    if-ne p0, v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v0

    :catch_1
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0
.end method
