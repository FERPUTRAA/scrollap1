.class final Lcom/hjq/permissions/PermissionIntentManager;
.super Ljava/lang/Object;


# static fields
.field private static final COLOR_OS_SAFE_CENTER_APP_PACKAGE_NAME_1:Ljava/lang/String; = "com.oppo.safe"

.field private static final COLOR_OS_SAFE_CENTER_APP_PACKAGE_NAME_2:Ljava/lang/String; = "com.color.safecenter"

.field private static final COLOR_OS_SAFE_CENTER_APP_PACKAGE_NAME_3:Ljava/lang/String; = "com.oplus.safecenter"

.field private static final EMUI_MOBILE_MANAGER_APP_PACKAGE_NAME:Ljava/lang/String; = "com.huawei.systemmanager"

.field private static final MIUI_MOBILE_MANAGER_APP_PACKAGE_NAME:Ljava/lang/String; = "com.miui.securitycenter"

.field private static final ORIGIN_OS_MOBILE_MANAGER_APP_PACKAGE_NAME:Ljava/lang/String; = "com.iqoo.secure"


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static getAndroidSettingAppIntent()Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "stsTNSGe.nSgtodiasiTdI.rs"

    const-string v1, "ISsdTrdTG.otEnNieiS.satgs"

    const/4 v3, 0x7

    const-string/jumbo v1, "tNamsToiIsnErGSSgTdntd..i"

    const-string v1, "android.settings.SETTINGS"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method static getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionIntentManager;->getApplicationDetailsIntent(Landroid/content/Context;Ljava/util/List;)Landroid/content/Intent;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method static getApplicationDetailsIntent(Landroid/content/Context;Ljava/util/List;)Landroid/content/Intent;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Landroid/content/Intent;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "tITmo_IEt.AAePTsEIONTTsADdnILPog.CnNLdriSGa_S"

    const-string v1, "ToAmdTOCSast.ELrEgNTIPGdS_.IiTsetnIDLSInNPAA_"

    const/4 v4, 0x6

    const-string v1, "ASiCnbIeSEN.I_dStAinaT_gGToLIOLIDrAsNEtTs.TPP"

    const-string v1, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->isColorOs()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Landroid/os/Bundle;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    instance-of v2, p1, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    check-cast p1, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v2, Ljava/util/ArrayList;

    const/4 v4, 0x6

    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v2, "oossmnueiispir"

    const-string/jumbo v2, "orieonpsimsiLs"

    const/4 v4, 0x3

    const-string/jumbo v2, "nissetmpLoiipr"

    const-string/jumbo v2, "permissionList"

    const/4 v4, 0x1

    invoke-virtual {v1, v2, p1}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v4, 0x1

    const-string p1, "bPsnsietqsoeiGi"

    const-string/jumbo p1, "omsGsbePiitnsie"

    const/4 v4, 0x0

    const-string/jumbo p1, "oissisGiPemnest"

    const-string/jumbo p1, "isGetPermission"

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x7

    or-int/2addr v3, v1

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "_d.msnaTSgOTLusPSe.CGnAEtTNAIIdPNiiIo"

    const-string v0, "PsAT.suad_gtGConISTIELOnTiiteNSNA.PId"

    const/4 v4, 0x1

    const-string v0, "dT_EonnLSrPadiNAItsTNTOeICiGPotgS.sIA"

    const-string v0, "android.settings.APPLICATION_SETTINGS"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    move v4, v3

    invoke-static {p0, p1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    and-int/2addr v4, v3

    return-object p1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, "NPPIdbgN_Nno.CsTATAEMS.OSEndaGSrpLA_tAGeIsitI"

    const-string v0, "TETnPaop_IAg..NICierLNGnNsTAEO_SSGSdPtAsdtIAM"

    const/4 v4, 0x1

    const-string v0, "GeN.d_u_rTgCiSGstToAMnstATI.NAISadNOLSniEEIAP"

    const-string v0, "android.settings.MANAGE_APPLICATIONS_SETTINGS"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {}, Lcom/hjq/permissions/PermissionIntentManager;->getAndroidSettingAppIntent()Landroid/content/Intent;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0
.end method

.method static getColorOsWindowPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "smAmioepntoeipf.rnaiis.pp.ioTssioocseq.mPovtrc"

    const-string/jumbo v1, "snipse.vqPm..mToosorsippiseo.ipiaAnmteocrifotc"

    const/4 v4, 0x4

    const-string/jumbo v1, "oeipAnmrqscytprieiasvi.ooompctefp..sissTonm.Po"

    const-string v1, "com.oppo.safe.permission.PermissionTopActivity"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getOppoSafeCenterAppIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method static getEmuiWindowPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 7
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v1, "vtsywndamovnmdenAyaraotstiwmdgeieiiwacmeoi.d.tcMtrVeoo.iis.Arh"

    const-string/jumbo v1, "wrsoi.ynmyemrcnaaAiiiewidotaVocawot.m..gnetoivhissAtvMedetdmrd"

    const/4 v6, 0x1

    const-string/jumbo v1, "tAwmwrenrcgo.ymd.emanVisoiyraonm.htaiiei.coveiaumeidsvdMottAtd"

    const-string v1, "com.huawei.systemmanager.addviewmonitor.AddViewMonitorActivity"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "com.huawei.systemmanager"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v3, "ieiioaotyammt.t.gnitoafoacnnicuninotnifaMwah.vcmmAeaiutic.gteoN"

    const-string v3, "ianmy.c.uaiaiuonoeeinNgtgaiiitoaMwtiftmtveimnamcnhaioc.cfA.tnot"

    const/4 v6, 0x3

    const-string v3, "cn.omb.gtiyicttmaivtttNetMnAiino.efaiaiurnucogaiaohnoiiaafmcnew"

    const-string v3, "com.huawei.notificationmanager.ui.NotificationManagmentActivity"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getHuaWeiMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {}, Lcom/hjq/permissions/PhoneRomUtils;->getRomVersionName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x2

    const-string v3, ""

    const-string v3, ""

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v4, "0.3"

    const-string v4, ".30"

    const/4 v6, 0x0

    const-string v4, "03."

    const-string v4, "3.0"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x6

    move v5, v4

    move v5, v4

    const/4 v6, 0x2

    if-eqz v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v3, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v0}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_2

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_2

    :cond_4
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :cond_5
    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p0, v2}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p0, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v1, v2}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v1

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-object v1
.end method

.method static getHuaWeiMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "sohmiyuasercmaeumn.teg.a"

    const-string v1, "com.huawei.systemmanager"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0
.end method

.method static getMiuiPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "PAPRn.npeaRoiuit_mitc.o_.PTDMinEIO"

    const-string v1, "DntcoAOR_Pi.tatR.n_ii.mToiPnIMePEu"

    const/4 v4, 0x4

    const-string v1, "IEn..OtcqmDTPnMiAnti__.tuiPiaPoRRE"

    const-string/jumbo v1, "miui.intent.action.APP_PERM_EDITOR"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const-string v2, "egp_ebxknmara"

    const/4 v4, 0x5

    const-string v2, "eksgtern_mxap"

    const-string v2, "extra_pkgname"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getXiaoMiMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/hjq/permissions/StartActivityManager;->addSubIntentToMainIntent(Landroid/content/Intent;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method

.method static getMiuiWindowPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getMiuiPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method static getOneUiPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x5

    const-string v1, ".gomtnodi.ecmatniusr"

    const-string/jumbo v1, "m.rdaiu.iscnonsoettg"

    const-string v1, ".grootsicnm.estdoaid"

    const-string v1, "com.android.settings"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v2, "dssnpbapAtntalsrg.ieitpdeSinvOy..gDc$motsstiicteipo"

    const-string v2, "g.n.ns$pinytattiieddaipcsSpgtottlO.ArvssDpsicAieemo"

    const/4 v5, 0x2

    const-string v2, "etOiAcu.ittpn.sgalSdppyeastiieDsdiArncmtvntgsso$.ot"

    const-string v2, "com.android.settings.Settings$AppOpsDetailsActivity"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v3, "pqeapkg"

    const-string v3, "eqpkaga"

    const/4 v5, 0x6

    const-string v3, "gqkaeca"

    const-string/jumbo v3, "package"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v2, "a_ses:s:ttrgsoeaswhsgmtrni_g"

    const-string v2, "_hsr:tst_gietowseafn:gssagmr"

    const/4 v5, 0x4

    const-string/jumbo v2, "ratm:rsse_ewmgitft:annhossg_"

    const-string v2, ":settings:show_fragment_args"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 p0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p0
.end method

.method static getOneUiWindowPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getOneUiPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static getOppoSafeCenterAppIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "a.oposo.ecfmm"

    const-string v1, "coemo.psmpfa."

    const/4 v3, 0x3

    const-string v1, "e.a.sbpmopoco"

    const-string v1, "com.oppo.safe"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "cfmt.euoooe.rclosnca"

    const-string v1, "eceaom.oort.socnelfc"

    const-string/jumbo v1, "lmefeecpsoocrna.tcr."

    const-string v1, "com.color.safecenter"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v1, ".olpcbarqe.eesncfotu"

    const-string v1, "eorscb.ufes.pctanleo"

    const/4 v3, 0x2

    const-string/jumbo v1, "pfsce.rel.namsteusco"

    const-string v1, "com.oplus.safecenter"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_2

    const/4 v2, 0x0

    const/4 v2, 0x0

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 p0, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0
.end method

.method static getOriginOsPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "osimpueai.n.efiinttnsPtt.sisromnntseimolDiera"

    const-string v1, ".nnor.uatPioeiomisiienstpletf.nsrsenttmiDsaoi"

    const/4 v4, 0x5

    const-string/jumbo v1, "ni.roniPetoaiismcisemsrspie.tDoninsnola.fettt"

    const-string/jumbo v1, "permission.intent.action.softPermissionDetail"

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v2, "mekacbppnea"

    const-string v2, "aemakacpenp"

    const/4 v4, 0x5

    const-string/jumbo v2, "pkgeecuaana"

    const-string/jumbo v2, "packagename"

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz p0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p0
.end method

.method static getOriginOsWindowPermissionPageIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getVivoMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method static getVivoMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, "ecemrocpu.i.oqq"

    const-string v1, "eoscqimcq..erou"

    const/4 v3, 0x7

    const-string v1, ".meoqcrcqouesoi"

    const-string v1, "com.iqoo.secure"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0
.end method

.method static getXiaoMiMobileManagerAppIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "umsrcsieencut.o.sremcyi"

    const-string/jumbo v1, "uiseecoimriunc.setrc.my"

    const/4 v3, 0x3

    const-string/jumbo v1, "ye.mcoimtrcreeniiuc.sum"

    const-string v1, "com.miui.securitycenter"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method
