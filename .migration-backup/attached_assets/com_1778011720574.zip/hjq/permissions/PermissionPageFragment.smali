.class public final Lcom/hjq/permissions/PermissionPageFragment;
.super Landroid/app/Fragment;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static final REQUEST_PERMISSIONS:Ljava/lang/String; = "request_permissions"


# instance fields
.field private mCallBack:Lcom/hjq/permissions/OnPermissionPageCallback;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private mRequestFlag:Z

.field private mStartActivityFlag:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/app/Fragment;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static launch(Landroid/app/Activity;Ljava/util/List;Lcom/hjq/permissions/OnPermissionPageCallback;)V
    .locals 6
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/permissions/OnPermissionPageCallback;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/OnPermissionPageCallback;",
            ")V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@soSr@l~ 4~mi@ ~o~@   v@~ ~/o ~f~@@  -f~@@~1~Kio@~b~~ @@~~i~d~  ~ ocy@@@s@ b~nl @/t btuM@@a~o.@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    new-instance v0, Lcom/hjq/permissions/PermissionPageFragment;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v0}, Lcom/hjq/permissions/PermissionPageFragment;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x2

    instance-of v2, p1, Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v3, "irssqspmtree_noesis"

    const/4 v5, 0x1

    const-string/jumbo v3, "ossmn_iieurqprmsees"

    const-string/jumbo v3, "request_permissions"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast p1, Ljava/util/ArrayList;

    const/4 v5, 0x3

    invoke-virtual {v1, v3, p1}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v2, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-direct {v2, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v3, v2}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Landroid/app/Fragment;->setRetainInstance(Z)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/hjq/permissions/PermissionPageFragment;->setRequestFlag(Z)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, p2}, Lcom/hjq/permissions/PermissionPageFragment;->setOnPermissionPageCallback(Lcom/hjq/permissions/OnPermissionPageCallback;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Lcom/hjq/permissions/PermissionPageFragment;->attachByActivity(Landroid/app/Activity;)V

    const/4 v5, 0x2

    return-void
.end method


# virtual methods
.method public attachByActivity(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, p0, v0}, Landroid/app/FragmentTransaction;->add(Landroid/app/Fragment;Ljava/lang/String;)Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/app/FragmentTransaction;->commitAllowingStateLoss()I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public detachByActivity(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1, p0}, Landroid/app/FragmentTransaction;->remove(Landroid/app/Fragment;)Landroid/app/FragmentTransaction;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/app/FragmentTransaction;->commitAllowingStateLoss()I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 2
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/16 p2, 0x401

    const/4 v1, 0x1

    const/4 v0, 0x4

    if-eq p1, p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-eqz p1, :cond_3

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    if-nez p2, :cond_1

    const/4 v1, 0x2

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    move v1, v0

    const-string p1, "enqsotsuemiprsse_mo"

    const-string p1, "_iemspusosqremtnies"

    const/4 v1, 0x5

    const-string p1, "eus_sbispiereomnrtq"

    const-string/jumbo p1, "request_permissions"

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-eqz p1, :cond_3

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-eqz p2, :cond_2

    const/4 v1, 0x6

    goto :goto_0

    :cond_2
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1, p0}, Lcom/hjq/permissions/PermissionUtils;->postActivityResult(Ljava/util/List;Ljava/lang/Runnable;)V

    :cond_3
    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public onResume()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/app/Fragment;->onResume()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/hjq/permissions/PermissionPageFragment;->mRequestFlag:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/hjq/permissions/PermissionPageFragment;->detachByActivity(Landroid/app/Activity;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/hjq/permissions/PermissionPageFragment;->mStartActivityFlag:Z

    const/4 v2, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    move v3, v2

    return-void

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/hjq/permissions/PermissionPageFragment;->mStartActivityFlag:Z

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "epsriiuostrsmesqueo"

    const-string/jumbo v1, "tipeososruerme_siqs"

    const/4 v3, 0x4

    const-string/jumbo v1, "moseisspnursitepeqr"

    const-string/jumbo v1, "request_permissions"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/hjq/permissions/PermissionApi;->getSmartPermissionIntent(Landroid/content/Context;Ljava/util/List;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/16 v1, 0x401

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lcom/hjq/permissions/StartActivityManager;->startActivityForResult(Landroid/app/Fragment;Landroid/content/Intent;I)Z

    :cond_3
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public run()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/app/Fragment;->isAdded()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x1

    return-void

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/hjq/permissions/PermissionPageFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionPageCallback;

    const/4 v4, 0x0

    const/4 v2, 0x0

    shl-int/2addr v5, v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/hjq/permissions/PermissionPageFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionPageCallback;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Lcom/hjq/permissions/PermissionPageFragment;->detachByActivity(Landroid/app/Activity;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const-string/jumbo v3, "rstmsqoeqrsiin_speu"

    const-string/jumbo v3, "request_permissions"

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    if-eqz v2, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2}, Lcom/hjq/permissions/PermissionApi;->getGrantedPermissions(Landroid/content/Context;Ljava/util/List;)Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ne v3, v2, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Lcom/hjq/permissions/OnPermissionPageCallback;->onGranted()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v1}, Lcom/hjq/permissions/OnPermissionPageCallback;->onDenied()V

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Lcom/hjq/permissions/PermissionPageFragment;->detachByActivity(Landroid/app/Activity;)V

    :cond_5
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method

.method public setOnPermissionPageCallback(Lcom/hjq/permissions/OnPermissionPageCallback;)V
    .locals 2
    .param p1    # Lcom/hjq/permissions/OnPermissionPageCallback;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/hjq/permissions/PermissionPageFragment;->mCallBack:Lcom/hjq/permissions/OnPermissionPageCallback;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public setRequestFlag(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    iput-boolean p1, p0, Lcom/hjq/permissions/PermissionPageFragment;->mRequestFlag:Z

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
