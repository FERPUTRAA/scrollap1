.class final Lcom/hjq/permissions/PermissionChecker;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method static checkActivityStatus(Landroid/app/Activity;Z)Z
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l~s@~  r~~i~iy od@@a~v~  ~@/~ ~sm@@4~S@@fo@@b~~o@K-@  o@/u  @@ 1.~ ~~ t @~o~bol ftni @c@b@ ~~M@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string p1, "   mentoethcbyios steoaejfac utnaiettxentcTnstm  i cv "

    const-string/jumbo p1, "vysn inantscuicTbct tjfmc ehe  thti etootaoa s eetnex "

    const/4 v3, 0x3

    const-string p1, "The instance of the context must be an activity object"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw p0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string p1, "Ti mle,hapetue iceyt ttehtehlmb ianufae n gvsiir astycdmnth s ieeiet atfnvos i ahalns"

    const/4 v3, 0x4

    const-string/jumbo p1, "nieioiit ualsmri ttee nhsThyn u fasit alaneaisft  tbevyen,tgvhemdtelopcya  ace ste hi"

    const-string p1, "The activity has been finishing, please manually determine the status of the activity"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw p0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid4_2()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v1, :cond_5

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez p1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo p1, "leyeebrsihltnnni msh ieua rphe ctt  a my tstiletsasvad,vTfd  tyaoocbadiehutet e eayee"

    const-string p1, "The activity has been destroyed, please manually determine the status of the activity"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    throw p0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return p0
.end method

.method static checkBodySensorsPermission(Ljava/util/List;)V
    .locals 4
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const-string v0, "idEoB.uBssRpS_ennRKOrr_.YdioNUGCaOmNADDoiS"

    const-string v0, "BesSoOiri.OarGDpOiKEB.d_YmoonndNR_RSACsDUN"

    const/4 v3, 0x6

    const-string v0, "Booi_.NpUOOSiDe_mndpDAaKRrsNGBYndSECsi.OSr"

    const-string v0, "android.permission.BODY_SENSORS_BACKGROUND"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v0, "dSDeNrO_qndbEis.ipiBarmSRSnY.oo"

    const-string v0, ".DnBmboO_aipiESR.erOdSNYirSsodn"

    const-string v0, "OnsY.iOmesaoSdsEdrnRop.iSi_NSBr"

    const-string v0, "android.permission.BODY_SENSORS"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "rcnm a_mpnmOdps.o nnoDriaOco oyuE  ktSuoBoiisepSdsrRnroimgrs.bgena AudseitsSNsnnp irlis"

    const-string v0, "bnY eiusi.Snmnr tdOioSiypOoBASd senm._ Nsaorrrssgks oupncdDriEm tuongno iRsaarscoeppnil"

    const/4 v3, 0x0

    const-string v0, "esbnoln O pisosrtunEtoidodopcYne roSarNDmSriocnsi .ngsprk OapurA.o ssi_mfdiinayRegmn BS"

    const-string v0, "Applying for background sensor permissions must contain android.permission.BODY_SENSORS"

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0

    :cond_2
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v1, "iK.DoOTp_IiCedpnCnRsmsBA.SGLSrCoOAEaAdiUO_NNC"

    const-string v1, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v1, "S_IiibCOqn_sEmoTirndCA.CoSDeLsrpdNIEAAO."

    const-string v1, "OE_siIneqAo_AConCD.ICdipLiSOAMdErmNr.sST"

    const/4 v3, 0x6

    const-string v1, "IsdniausCAm.dIpADOEASo.NEiMSeriCLOr_C_nT"

    const-string v1, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_1

    :cond_3
    const/4 v2, 0x2

    move v3, v2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v0, "oAt sripauat intogim.BpOEiodnsdDdaOnCIdSm_ RmTUofO_NLsAridDs.  trpesS DAeism  ephinAYits py Ssnps_MrK.oRaS_mSnrnoplprnOCNeeidiaoGoCB.rAsEOe EiNCI "

    const-string/jumbo v0, "tpssNeC GdEOMisid nIoe .opSdBp pmdSeir OyiCfe  Snisp mTaidB.RAmgrrit_otaAeOCYmssa CuSr_noaeKlNSpo_nsnrOpis_IoAnrsi reas.ihmNtDnnUDLEDtRAE.i dA Ooo"

    const/4 v3, 0x2

    const-string/jumbo v0, "rCo_AS DqpCtm mNmitdEIeKsNsdmonimACir.ShiYeieapaO .eapAfrsysdni lt oMsperieod_O.TispIE_Sd oG_dooR tsRaOSnSpingBanspCrsNEAnLBo OsuD.Dt OiAe Unr ni "

    const-string v0, "Applying for permissions android.permission.BODY_SENSORS_BACKGROUND and android.permission.ACCESS_MEDIA_LOCATION at the same time is not supported"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "yisRSooidCptsrsOA  epleniiArtesdda__om  CmetrnIfDoOap.R_KordrimoA N.OOsApeBs sSp. nnisBGCEDogUs s.nRniSNOisTOmL a tGmC YKUehep anSDrA_SdaiBnNNdtrimCopE"

    const-string/jumbo v0, "rSAmeoKOLpn OtSpnaoiiOlUCmortArOiCmdT_iNm sD.i_ n_e AOeKiNpdDSD h.Ssred_RtiRetARsGoaBr mCnapBnm En op.i sniOedirs SsiUIYfsArNosd  CyoeGpsotEaaCpdgsN.nB"

    const/4 v3, 0x0

    const-string v0, "a Omm TtsmAo.Cgi UCoIippeOi.n SEeSoOasasNrerOGrisso nSpGOylC_NOo sEndKpRoiaipeiRd refCnnK e Bu.AeNrdoDAaspDRdst_SniB m nrmi_DtitUBs.pdAhnNoYs ALrSimCd_"

    const-string v0, "Applying for permissions android.permission.BODY_SENSORS_BACKGROUND and android.permission.ACCESS_BACKGROUND_LOCATION at the same time is not supported"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    throw p0

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method static checkLocationPermission(Ljava/util/List;)V
    .locals 7
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v0, ".nrioeSCAosL.DOiGmd_BACCdoKinRTINO_ANrOsUaSpC"

    const-string v0, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, "EEiiAbmTndoCpraN_O_OLSCn.dIrSoCeAos.ORSCA"

    const-string v1, ".poOoS_Cns.IrOdCrEATiSCSiEoA_iNReCLOAmnda"

    const/4 v6, 0x7

    const-string v1, "iOToiiuCr.OA_ndAsroesCCpIACSmE.LSRNSnOdaE"

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const-string v3, "dCrNSAmpFS.iCsONn.sdonioperiILIE_CEaT_A"

    const-string v3, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    move v6, v5

    invoke-static {p0, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v0, " ragOb nqiyStInsfonrAibF_ Sn a  IdiEpnriiCLgNosksslAdiA.drOoecpupiloCT ruNsonde_Ciinuiooscpmntge.Emm"

    const-string/jumbo v0, "psisubmids iNgICStoyifOeoCdC cnpaIiu mNdp_A nogTrso.E ko inliSsruersieg_npacrOdrbFnlAm.tA oonnsLinEi"

    const/4 v6, 0x3

    const-string v0, "Applying for background positioning permissions must include android.permission.ACCESS_FINE_LOCATION"

    const/4 v6, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    throw p0

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    filled-new-array {v3, v1, v0}, [Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v4, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const-string v0, "aeseldonopbunld icciitry   Bicd trcoio l neuksdmelinaupp  mnitu s raitee stfscotrg,ssea oponouonlaornsa"

    const-string v0, "g bopau  aoo  uedseauirtrtinnslcalus snmpuf tcip  otei sedlenysscnc rda iimtci oieknooloonandreoltrsp,B"

    const/4 v6, 0x4

    const-string v0, "arlmmlugdcpyi ,ctsnoitbtedoraesiteoo seosiilpnpBoesfucuknanim aednap or   rc st saoecdnti r so oonunll "

    const-string v0, "Because it includes background location permissions, do not apply for permissions unrelated to location"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw p0

    :cond_4
    const/4 v5, 0x3

    const/4 v6, 0x0

    return-void
.end method

.method static checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V
    .locals 3
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const v0, 0x7fffffff

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method static checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V
    .locals 5
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;",
            ">;",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x5

    if-eqz v0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget p0, v0, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->maxSdkVersion:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ge p0, p2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, "dffsopmsor:ide/n<miuiixhln-ddatnTsro imeri n sM /enloaspe=eea"

    const-string v2, "Msardnmp ndured/ei=ssofsn leaishn peifa-don/mmoe :<riiTtiel.x"

    const-string v2, "<rndebsmrdm uh-xe/ on=:eonfAiofsTrdsinde.npeli/iaaelimasits  "

    const-string v2, "The AndroidManifest.xml file <uses-permission android:name=\""

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p1, "ikn/nous/d e=oad/mq/d:axVir"

    const-string p1, "adxirdi/qd/msr=kVoa ne://no"

    const/4 v4, 0x3

    const-string p1, "edkx:o/paSV//di=m/ nnrdsrio"

    const-string p1, "\" android:maxSdkVersion=\""

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    const-string p1, "\" /> does not meet the requirements, "

    const-string p1, "\" /> does not meet the requirements, "

    const/4 v4, 0x1

    const-string p1, "\" /> does not meet the requirements, "

    const-string p1, "\" /> does not meet the requirements, "

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    const p1, 0x7fffffff

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eq p2, p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo p1, "xe emfnnqeod urmVst qeiontikia rseirSmmu  hri"

    const-string/jumbo p1, "the minimum requirement for maxSdkVersion is "

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const-string p2, "e sStisalr r:kedeVeethdladxns mondsp/o=/ea"

    const-string/jumbo p2, "lmspeVdkr/eSeden nlediost=exaah/es td:aor "

    const/4 v4, 0x3

    const-string p2, "ep:mn/tdeekterheelxd dS= Vonldaier mia/osa"

    const-string/jumbo p2, "please delete the android:maxSdkVersion=\""

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string p0, "btauom/i/r t"

    const-string p0, "ebum/a /ritt"

    const/4 v4, 0x7

    const-string/jumbo p0, "tb /ubritet/"

    const-string p0, "\" attribute"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    throw v0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v0, "dsripmutunasreiMt sifoie<siregenaoe m aeleiesnois al/f=-sdsnlomnepx irmsni roP:sd.reAdhne/t "

    const-string v0, "eit<otre snMe/m  idgoresPnma-lresioe:fdnesmpeeetplndi =osAoshas x/ir eisirnal ansd umrsiinf."

    const/4 v4, 0x5

    const-string v0, "-dtesMdpsioesrsn til prl eiepiussnfdmeaeriPsfinerr: ree siAainm .g /<lnhenesntdmmsoa i=xo/ao"

    const-string v0, "Please register permissions in the AndroidManifest.xml file <uses-permission android:name=\""

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string p1, ">//q/"

    const-string p1, "\" />"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw p0
.end method

.method static checkManifestPermissions(Landroid/content/Context;Ljava/util/List;Lcom/hjq/permissions/AndroidManifestInfo;)V
    .locals 9
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/permissions/AndroidManifestInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/AndroidManifestInfo;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-nez p2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-void

    :cond_0
    const/4 v8, 0x2

    iget-object v0, p2, Lcom/hjq/permissions/AndroidManifestInfo;->permissionInfoList:Ljava/util/List;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez v1, :cond_11

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid7()Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {p2}, Lcom/google/firebase/i;->a(Landroid/content/pm/ApplicationInfo;)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object p2, p2, Lcom/hjq/permissions/AndroidManifestInfo;->usesSdkInfo:Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz p2, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget p2, p2, Lcom/hjq/permissions/AndroidManifestInfo$UsesSdkInfo;->minSdkVersion:I

    const/4 v8, 0x7

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/16 p2, 0xe

    :goto_0
    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_3
    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v1, :cond_10

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v1}, Lcom/hjq/permissions/PermissionHelper;->isVirtualPermission(Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v2, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v2, "ONsnSbnNmSDpir_ReU.drGoBiOCAEiRDo._sSdBaOK"

    const-string/jumbo v2, "p_oSDbBCdB.irSEUNS._dORmrDiOaKGAnONRnYoies"

    const/4 v8, 0x2

    const-string/jumbo v2, "pODmOnESSed_dYi.oBKOsa.UDoAnBrN_RNSiCiGmsr"

    const-string v2, "android.permission.BODY_SENSORS_BACKGROUND"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x5

    if-eqz v2, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v1, "SiiOoNeY_nBsE..dOaiSSudrsopDomr"

    const-string/jumbo v1, "mSnEYruD.sNspddaROOir_o.ieoiSBS"

    const/4 v8, 0x3

    const-string v1, "Odo._bEisdasOrieSBSiRpnYrn.DmNS"

    const-string v1, "android.permission.BODY_SENSORS"

    const/4 v7, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v2, "iN_ICRu.NdrKLTos.OUAdCnrESspCop_AGSOeAiiOmDan"

    const-string v2, "dLACC.EpTS.AdDspeooAR_OCCNiKOmirOsUnInSN_iGar"

    const/4 v8, 0x0

    const-string v2, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v3, "aqsS.LOp.OnmrnNFCSsiId_oAi_piICCdTrANEE"

    const-string v3, "O_CLiNTpq_nsodSOdFAIEImESirAsai.NCC.ren"

    const/4 v8, 0x2

    const-string/jumbo v3, "sr.FiEA.qd_Oooi_ApamIdCSinSrEsLINTeOCNn"

    const-string v3, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v8, 0x7

    const/16 v4, 0x1e

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v2, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/16 v2, 0x1f

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-lt v1, v2, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v0, v3, v4}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v1, "OCsIpS.NA.SCmnRdrs_AoC_sderaOnoCEOAEiSiLi"

    const/4 v8, 0x1

    const-string v1, "EOspSn_ArOCsnITsNaAdOCdRL.mi.oSiroSECAie_"

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto/16 :goto_1

    :cond_6
    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v0, v3}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    goto/16 :goto_1

    :cond_7
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v2, "LApmm.rDns.oocE.IEPTiGSmPrnd_e_SiTsdimNoA"

    const-string v2, "ArTmpaoL_mPndiGedrS.EsmDIsScNoiPnAEoi_..T"

    const/4 v8, 0x0

    const-string v2, "GD_soA.SdTronNTcidIioLsiPEmeESpPomL..rAna"

    const-string v2, "com.android.permission.GET_INSTALLED_APPS"

    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v2, :cond_8

    const/4 v8, 0x2

    const/4 v7, 0x5

    const-string v1, "SQnPCbodnisGaKroeEApRiU.A_LmLsAiYodrE"

    const-string v1, "URYoo_dLEGK.nePdaQop_EAsrsiLACArnmSii"

    const/4 v8, 0x2

    const-string v1, "EoAYeAuiKCUERd_LoLamr_AsP.dsniGSiQ.nr"

    const-string v1, "android.permission.QUERY_ALL_PACKAGES"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto/16 :goto_1

    :cond_8
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v1}, Lcom/hjq/permissions/PermissionHelper;->findAndroidVersionByPermission(Ljava/lang/String;)I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-lt p2, v2, :cond_9

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void

    :cond_9
    const/4 v8, 0x4

    const-string v2, "Drs.RrApiidbnoasin_E_EomeIO.dVMEpID"

    const-string v2, "EMEdDbsDE..dAIIier_mAriVpsinOn_oaoR"

    const/4 v8, 0x0

    const-string v2, "E.DVoadiqEnED.ermOA_DornIiMpsIRAsdi"

    const-string v2, "android.permission.READ_MEDIA_VIDEO"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v5, "IAsrdDndUApu.D_MsiiOneRoErs._EAaIoD"

    const-string/jumbo v5, "r..Es_uUeDndEIprioiaAn_AMIdORDDisAo"

    const/4 v8, 0x2

    const-string/jumbo v5, "srpmi.dR.ArndAioaAMmeEU_IoDnsD_IDOE"

    const-string v5, "android.permission.READ_MEDIA_AUDIO"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v6, ".d.GoMAossEIAEnmSeiErpnDaoiIMRiADrd_"

    const-string v6, "android.permission.READ_MEDIA_IMAGES"

    const/4 v8, 0x7

    const/4 v7, 0x5

    filled-new-array {v6, v2, v5}, [Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v2, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/16 v5, 0x20

    const/4 v7, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string v6, "TT_REb.irROLDonaAndNimprEEGsipEAs_A.dXSe"

    const-string v6, "ATEAE.ep.s_aEnLGirrmn_oTXEDRSNpoOAsdiidR"

    const/4 v8, 0x3

    const-string v6, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v2, :cond_a

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-static {v0, v6, v5}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    goto/16 :goto_1

    :cond_a
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v2, "I_iIeouCrdAr.ns_dIinRpqVEiNFsYBSEEoaWD"

    const-string/jumbo v2, "pDIVBCWdqEAiRmrioINoEasinY.nIsEd_Fr_Se"

    const/4 v8, 0x4

    const-string v2, ".pREoWdpisYS_EFDrroaid_EesnnVBACIINmiI"

    const-string v2, "android.permission.NEARBY_WIFI_DEVICES"

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-eqz v2, :cond_b

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v0, v3, v5}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v7, 0x1

    or-int/2addr v8, v7

    goto/16 :goto_1

    :cond_b
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v2, "iBsOTiTeqHmCUnrso.dEpLa.nodr_SiAs"

    const-string v2, "Hrsp_nenaismOEosB..TiSLUOdrACdoiT"

    const/4 v8, 0x5

    const-string v2, "CNspiSBrUoOTinsod.m_LOrainAEdeHT."

    const-string v2, "android.permission.BLUETOOTH_SCAN"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v5, "oDmmTiLi.MIsTNBsHOAnaUm_rnOipeEd.o"

    const-string v5, "HiImnUddnOMANDiLm._sEToiasopreOT.B"

    const/4 v8, 0x3

    const-string/jumbo v5, "rH.aodssMoiDeoTO_TnNIBEirLUnipdOmA"

    const-string v5, "android.permission.BLUETOOTH_ADMIN"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v2, :cond_c

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v0, v5, v4}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v0, v3, v4}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto/16 :goto_1

    :cond_c
    const/4 v8, 0x2

    const-string/jumbo v2, "oni.obmEOEdsTsiiLNHrCoNTr_pTOn.BUdeC"

    const-string v2, "..EmosaoiCLndONoTNTsHnBOdUpeT_EirCir"

    const/4 v8, 0x2

    const-string/jumbo v2, "imTpnHurnodO_.NOECLoasi.NirUOdCBTTes"

    const-string v2, "android.permission.BLUETOOTH_CONNECT"

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v2, :cond_d

    const/4 v8, 0x5

    const/4 v7, 0x7

    const-string v1, "aUO.dLepnbinTiTdoBOr.riompEs"

    const-string v1, "OnipibmeaTB.siooLOTsEnU.rddr"

    const/4 v8, 0x3

    const-string v1, "dmnTsaHoqen..siTUrBrpEdOOLio"

    const-string v1, "android.permission.BLUETOOTH"

    const/4 v7, 0x2

    move v8, v7

    invoke-static {v0, v1, v4}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto/16 :goto_1

    :cond_d
    const/4 v8, 0x3

    const/4 v7, 0x5

    const-string v2, "BnsdEiVrLdDorssET.iao.OmeOTTRuHEiU_ASp"

    const-string/jumbo v2, "mDsTidudIn_HEEABreEoO.rLRopVTSiiUsT.Oa"

    const/4 v8, 0x0

    const-string v2, "iInmEUdisrLsO_HnDoOroTA..BVeSdTaEEpRmT"

    const-string v2, "android.permission.BLUETOOTH_ADVERTISE"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v2, :cond_e

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v0, v5, v4}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto/16 :goto_1

    :cond_e
    const/4 v8, 0x4

    const-string v2, "i_oGosdrErLOXMApTedNAiEGRnoR.pmSNAa_TEsEA."

    const-string v2, "aAiOrLdppSEAmeA.dN_sER_MrRXEsTGGAoTNn.niEo"

    const-string v2, "MsR_AbdeirTX.NGAmTrdEAi_SnoOGEsEpAnEaLRiNo"

    const-string v2, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v2, :cond_f

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/16 v1, 0x1d

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v0, v6, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string v2, "SqRRdEu_TW_pEea.iriInAoiTsEdmoTsOrGLEAXnN"

    const-string/jumbo v2, "na_dWrRGqnRARE.TiELsTedo_oEiOsrXpTmiNAIES"

    const-string v2, "emTAopnpGiATiErnNddas.RRWEosLS.iTEO_E_XRI"

    const-string v2, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v8, 0x1

    invoke-static {v0, v2, v1}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto/16 :goto_1

    :cond_f
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v2, "dHoM.iUmqSoiir_peOsEDs_dABNPn.sRREEar"

    const-string v2, "NAsHERmBn_irSaON_iDpUoMr.oedRE.PssdiE"

    const/4 v8, 0x7

    const-string v2, "_isdnoUAPiiSmRr.spR.osDEHndNOEMBNr_ea"

    const-string v2, "android.permission.READ_PHONE_NUMBERS"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {v1, v2}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v1, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v1, "NmsmdPnae..irRnsDoiAipEH_TAmTE_dEOr"

    const-string/jumbo v1, "s_Oma.sirenE_nidNpATProH.dDEmERTiAS"

    const/4 v8, 0x6

    const-string v1, "Eea_o_iSnAr.OdimTsRErEHoPDNpoT.siAn"

    const-string v1, "android.permission.READ_PHONE_STATE"

    const/4 v7, 0x0

    move v8, v7

    const/16 v2, 0x19

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v0, v1, v2}, Lcom/hjq/permissions/PermissionChecker;->checkManifestPermission(Ljava/util/List;Ljava/lang/String;I)V

    const/4 v8, 0x0

    goto/16 :goto_1

    :cond_10
    const/4 v8, 0x7

    const/4 v7, 0x7

    return-void

    :cond_11
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo p1, "r. ribneloiMademelfsistdip  t  soAhdoo Nair sgsnfreieerixeenm"

    const-string/jumbo p1, "oasNo mirlmaMi g dieirst oerAfhi x.tndrfene oenpsliseensr eid"

    const/4 v8, 0x2

    const-string p1, "M lsetuedraos en.drp fsmamixn tlni stereniodeigeirNso Aieifrh"

    const-string p1, "No permissions are registered in the AndroidManifest.xml file"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    throw p0
.end method

.method static checkMediaLocationPermission(Landroid/content/Context;Ljava/util/List;)V
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string v0, "OTiI.iApNnrdSsLDMonCAaCm_p_eISEbos.iAOEd"

    const-string v0, "dn.mCbOAOTDoCisSeSM_idairnAEo_NL.prIAIsE"

    const/4 v9, 0x0

    const-string v0, "LEICsOSdqOaCsrST_.piDIoidNriEAAm.nC_MeAn"

    const-string v0, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-nez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    if-eqz v1, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string/jumbo v2, "oNsCuIoA.CmnsAIDsrOMSeE_aA.pCEiiSOLTnrid"

    const-string/jumbo v2, "pmOsCiudNDAanA_EoCn.IirOdIirTLES.SoAMesC"

    const/4 v9, 0x5

    const-string/jumbo v2, "ordm_OndTaIiSAAnrmICCiAsCMESesEDpL.i_ONo"

    const-string v2, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo v3, "rnAEooEApsn.DS_dERM.IGAidDiMoa_rpiIs"

    const-string v3, "iA.niGDpdmD_p_RSMoAonAaiIsEsEd.IrrME"

    const/4 v9, 0x1

    const-string v3, "android.permission.READ_MEDIA_IMAGES"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const-string v4, "RInEebq_ArnIisoEirDAoEMmDdV_Da.s.id"

    const-string v4, "MDieEd_EqdipaInEA.s.rDVorAmRD_sinIo"

    const/4 v9, 0x1

    const-string/jumbo v4, "rAsiEiupdIr.Eo.O_VIRsminnMeDDaEA_do"

    const-string v4, "android.permission.READ_MEDIA_VIDEO"

    const/4 v9, 0x0

    const-string v5, "EirRGiApnssAeS_osaREd_XERi.rLnDAp.oNETmO"

    const-string v5, "XisLEadioRpESNsAiADr_AT.GEnRnRs_oT.EermO"

    const/4 v9, 0x3

    const-string v5, "GisoOdLnqNaAEAEiSXrTniRdTE_D.AsrE_.oRRem"

    const-string v5, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string v6, "eIs_.AniEONiGsEAdsm.opW_XEdTnTorESRramLiR"

    const-string v6, "iE_mLR.TWOosIrApnioARi.GTRNaEsmESdnErd_Xe"

    const/4 v9, 0x1

    const-string v6, "SprmEniiWsGXsdE_oNiTm.EeL.dArTInAERa_oOTR"

    const-string v6, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string v7, "SpXeoNR..miOEsaoEnirTondGEoAdAM_GsAELRANri"

    const-string v7, "GOp_omdSeLA_sEiE.NX.RNnAooiAdsRMGniTrrEAEa"

    const-string/jumbo v7, "nsiEEbTAOpMm_.a.oo_rXsEirANASdGRNGnARediTL"

    const-string v7, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v2, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v1, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string/jumbo p1, "itc onuubtreeps  mrscop  ne iosati ins fneaoatidoa idy nlcadi mcslBiee sieontiplmutrrnacodsueoss cempdseao o la ,elcac"

    const-string p1, " ea Bbani nsitscoyidnno eetmipto soa ocis roaesetplc auee defllmtiocs,cr anmcmse  pdio nce li splsdaeuuooirirtaa dnssc"

    const/4 v9, 0x5

    const-string p1, "csrmin p sesdpnpctndpdsl eicaeoniyieo eBscstaea tmoiutalais aes smleaeoeulio ncmuicrca i ossor ,fld nscottpre d  ooin "

    const-string p1, "Because it includes access media location permissions, do not apply for permissions unrelated to access media location"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    throw p0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result p0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/16 v0, 0x21

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v1, "omiRAndGqMdsTNsXEOroAEST.Gpei_L_.ENEurAAnR"

    const-string/jumbo v1, "nEGRdmuN.MidGTseOLNAR._Tp_AsroEoiSAnXrAEEi"

    const/4 v9, 0x2

    const-string/jumbo v1, "oMsAGa.dTEn__sdpAEnRm.NASLroAiiRsirEXTENGO"

    const-string v1, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-lt p0, v0, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo p0, "miRmo..dsEnpr_pMnrDEIGAdESA_iiaIoDeA"

    const-string/jumbo p0, "oAsErDAped_nSdipsMI.rA_iEGEa.mDoniRI"

    const/4 v9, 0x4

    const-string p0, "GiSdodADiDiR_EAreI_.pmnEMIoAa.ossEnM"

    const-string p0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v9, 0x2

    invoke-static {p1, p0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-nez p0, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string/jumbo p0, "naqOIb_nDedDVrmiMI.Di_EAsEosAo.rdEp"

    const-string p0, "DEmoIoAVq.iaepnDd_EMrirn.IsiA_EODds"

    const/4 v9, 0x0

    const-string/jumbo p0, "no_.DOu.noprRsEsri_IAiDVamDdEIAdMEi"

    const-string p0, "android.permission.READ_MEDIA_VIDEO"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p1, p0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-nez p0, :cond_6

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {p1, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz p0, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_1

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x7

    const-string p1, "NphsCIopEoETrtm iMdAsm AaSsXTDDdEo. rECapgiE o_ iupnEns sp_m.od.dldndGMoGAiRirDonDoEtEERgipMNs CsoAArrdmeRyAeoELAV.h IEea_.O Ts.ridsO_DAaiMiYnp.iomdtII I aOs r_eai_ArnIOrrordo_i.MDNr nfLnSuAGsS_AiRisrAS"

    const-string p1, "fdshNMDADrs rMimd.do o_IDEVEnrgNmAIEpes dCT Ooiep iG_iRtGdRR.DsrCmEuM_OL MdaAegtaO i.._DtyoIDnG _Ed_AAinssdiSAda n.IE.EppmrsdlT oAiESpos T_uaiissamitoNrCL opYSnEX_..rso AinrEAahrAoAIsniIonAOerrEiMRrSoro"

    const/4 v9, 0x0

    const-string/jumbo p1, "tSS CiaTqVanoGsom GoX_AErrIrlpT.__iDDeN_noAoEdEda.hs. rSdoIA AALieRIpoAdiigsCirpDdE oiERoopMEr_nuLD gEmAEseuAio_sTpiEDM_IohR.nsAtdEdMar rrrOesAGrmm DnSO.  mdtIiiEMfiNn AsO .nsIRYdsp_ianE.irMdaOysC.t orN"

    const-string p1, "You must add android.permission.READ_MEDIA_IMAGES or android.permission.READ_MEDIA_VIDEO or android.permission.MANAGE_EXTERNAL_STORAGE rights to apply for android.permission.ACCESS_MEDIA_LOCATION rights"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v8, 0x7

    throw p0

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string p0, "EEimrpTsamArs_iASRLEdXn..TReNRAGodoODiEn"

    const/4 v9, 0x7

    const-string p0, "RDsRdsoe_TrdErXT..panGnNALEimsiAEoAiSORE"

    const-string p0, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {p1, p0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez p0, :cond_6

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {p1, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz p0, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_1

    :cond_5
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x0

    const-string p1, "OiimSoXLaRCsRTpAE f YopOhayupiasXA_L..AiAnorDaNp_EEirnsidEr oodsiAd Eg_oNorroiN tMridneEGlAodRs  __sadgOTGOmNAsEMn.Ar.sCn pT.E dCGtu_ SAAimoERmrSertt.LIDnTmEI sdRihoST"

    const-string p1, "REeGoEo_ T mlEL_sAdisOrSfosCdrdrde.hsoOiC.osA_AAatORpEDGisEaTmaAhoopmNtnrEd_r_LNd mtgLini .RrgAEspS TX AsXaRM.Ciri o_tATnNEiEAiIorn N.rpRyAnrSGuYTMEd. ooOuaDidp Sni sI"

    const/4 v9, 0x5

    const-string p1, "_Gooooyr_GdsiRSTniaSA aXiTodtoRsTONLuirdiTOA_EeoEpteoiOdgRrYrD.iiOr XIdEE mDSrt.nniiNrTpA_dMfsonAAR_rrNE ahoEptrCds.RapiCA .p.sAssEumsahAnLEoNmne  d.G_AAClSmgsLMI EE  "

    const-string p1, "You must add android.permission.READ_EXTERNAL_STORAGE or android.permission.MANAGE_EXTERNAL_STORAGE rights to apply for android.permission.ACCESS_MEDIA_LOCATION rights"

    const/4 v8, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    throw p0

    :cond_6
    :goto_1
    const/4 v8, 0x7

    const/4 v9, 0x0

    return-void
.end method

.method static checkNearbyDevicesPermission(Ljava/util/List;Lcom/hjq/permissions/AndroidManifestInfo;)V
    .locals 7
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/hjq/permissions/AndroidManifestInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/AndroidManifestInfo;",
            ")V"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v0, "OnEsSbTdorTin.roLHAiNa.pBms_dibUO"

    const-string/jumbo v0, "pTNsSboAdHOEm.T_iBrnLnOos.iraiCUd"

    const/4 v6, 0x3

    const-string v0, "UoH.AEuLdieBiaO_poTrS.nmNdinCsrTs"

    const-string v0, "android.permission.BLUETOOTH_SCAN"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v2, "nepouoEpB.riEsdIIVaCI.niNiYWREdm_rAFSs"

    const-string v2, ".riYIsueIRA_VNd.EoS_dEiBWpmCnrEioFsaIn"

    const/4 v6, 0x0

    const-string v2, "iICaiIAVqNsY.nrIrnoSEe_pB_DdiodWF.sRmE"

    const-string v2, "android.permission.NEARBY_WIFI_DEVICES"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-nez v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p0, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v1, "ipsNTCadIiO_LeAEFAm_n.sSndIrNSrO.oCCEis"

    const-string v1, "CsSIiioprr_nSNEA.d_OpANseCnFTiELdO.IaCm"

    const/4 v6, 0x5

    const-string/jumbo v1, "soEmIC_.o_Cneip.dANrFnCOSOTEisIiSaAmrNd"

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez p1, :cond_2

    const/4 v6, 0x2

    return-void

    :cond_2
    const/4 v6, 0x1

    iget-object p0, p1, Lcom/hjq/permissions/AndroidManifestInfo;->permissionInfoList:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_3
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz p1, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget-object v4, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v3, v4}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v3, :cond_4

    const/4 v5, 0x5

    and-int/2addr v6, v5

    goto :goto_0

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->neverForLocation()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v3, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget p0, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->maxSdkVersion:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const v0, 0x7fffffff

    const/4 v5, 0x6

    move v6, v5

    const-string v2, "/ /"

    const-string v2, "// "

    const/4 v6, 0x0

    const-string v2, "// "

    const-string v2, "\" "

    const/4 v5, 0x2

    xor-int/2addr v6, v5

    if-eq p0, v0, :cond_5

    const/4 v5, 0x7

    or-int/2addr v6, v5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v0, "=so:oe/Vadd/dSknnoqaiimx"

    const-string/jumbo v0, "md/nsiSxq=:ariknaVoeo/dd"

    const/4 v6, 0x3

    const-string v0, "earkVbrads/dmdoSino=:/xi"

    const-string v0, "android:maxSdkVersion=\""

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget v0, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->maxSdkVersion:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v6, 0x4

    const-string p0, ""

    const-string p0, ""

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v4, "uuIeysupfs/  aodenr p s /"

    const-string v4, " ss ropnpI fd  sueayeut//"

    const/4 v6, 0x2

    const-string/jumbo v4, "n esIutpae o/  r sdy/fpuo"

    const-string v4, "If your app doesn\'t use "

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v4, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v4, " nls aeaqi- nmtd/hei igrsep ahmg is,ee=ua to/ersnmdaol:ceeilspsn ht ccpooytao"

    const-string v4, "etemasae/ ,r ns p- eccesasodttc  oaaonei:dn ithnpsrelimi=m/loai gsno yluhpheg"

    const/4 v6, 0x5

    const-string v4, "  s,optaee< eg n dsosnhatmhsl/np reocaelhi lu pe:n tnas=ct/oramiigi-eeciosdsa"

    const-string v4, " to get physical location, please change the <uses-permission android:name=\""

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v4, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v2, "oiemisanrsisiud o: e/r/aodeilf-e mnn<se>eptdo /n=mest m hni tano"

    const-string/jumbo v2, "posfotdienud iethnln/=m:ena ie>ssrmt  -a noorso eaedini</ /esmi "

    const-string v2, "/m ao rrdaif:spsand-nif<toeos ns=eotm   ne/eo/eh iumineiilns dt>"

    const-string v2, "/> node in the manifest file to <uses-permission android:name=\""

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v2, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v2, "enntFbdeLs/Fso aadiorirl/P/boi/nensrrc=gosvue//os ia"

    const-string v2, "Pd/nib rsiieov/s/o:// sedsarLnuaaioc/leeon=FsgFrnort"

    const/4 v6, 0x3

    const-string v2, "gFr/:rut/ns/lmo=evaedrdiuinir/soacsai noF/eP/ onsseo"

    const-string v2, "\" android:usesPermissionFlags=\"neverForLocation\" "

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string p0, "apu  oypued f edn senoiu r,> /"

    const-string/jumbo p0, "pn uf uie n as/eeddu>ro  oy e,"

    const/4 v6, 0x2

    const-string/jumbo p0, "y p  neoqi pe,nre/udsuaofe d >"

    const-string p0, "/> node, if your app need use "

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object p0, p1, Lcom/hjq/permissions/AndroidManifestInfo$PermissionInfo;->name:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string p0, "  sisao, oldpdpl encoct inseagy oolheat tad "

    const-string p0, "a a  otpollgcope yhsa,ce tnltt ddandoos  eii"

    const/4 v6, 0x0

    const-string/jumbo p0, "tcom ,sdotei daasic elge loo hontdatn al  p "

    const-string p0, " to get physical location, also need to add "

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo p0, "msiqonsri se"

    const-string p0, "emin rosqsis"

    const/4 v6, 0x6

    const-string/jumbo p0, "s sribposmne"

    const-string p0, " permissions"

    const/4 v6, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    throw v0

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void
.end method

.method static checkNotificationListenerPermission(Ljava/util/List;Lcom/hjq/permissions/AndroidManifestInfo;)V
    .locals 4
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/hjq/permissions/AndroidManifestInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/AndroidManifestInfo;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "EONTEduOE_BrTIRnSC_srLIINapEdAoimiNsNIIRnsC.SoeViTF_D"

    const-string v0, "IIs_nLTaVeEANErOInsNmdDSoEENo_FOTRSii_CpITIrsCR.BiIdN"

    const/4 v3, 0x5

    const-string v0, "NDmaTsVpRdT.rdTNA__CFIOBNRiIIIE.ILSeoEEiSnsNICpr_nEOo"

    const-string v0, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p0, p1, Lcom/hjq/permissions/AndroidManifestInfo;->serviceInfoList:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ge p1, v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    check-cast v1, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, v1, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;->permission:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_2

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const-string p1, " oOgfimmqni:risee>rasNvttxspNrNrraanLni Nii_dE Isrne/mlu/reEtpidtesEdeeonee_I_eBcTeCEeoInA. ls RSMi ti,a   epdIome=gn<oT.rmiai IIFiVdcsSv/srdTsOAstsrrRCiripeN. D/erbosiid"

    const-string/jumbo p1, "irsm,oiT I p a<RrMsn iridpdrioeiise.rOIieetBlisRcgruv.reemo=TNeoirEnF:in bIsImSeetselnOtdNscf p_taIxENmd aieCiNi.nrIrDiint r/ //VaotT dsA>r_apg mEdeL/eAosedEvsereCS_sNosn"

    const/4 v3, 0x6

    const-string p1, "gesSeeg I s/,d_iCoenENIR rrmOi/ir_/Leime_=iosT nsrfDVdrpredoerrnEt.i eNdnNapiepanid nspvt<FAnir reeuiamNsTsCS/ila.IxnI >vcitoseE:tAbsismdotdB .erRriseeNsoaitl  iMsOoIIEcT"

    const-string p1, "No service registered permission attribute, please register <service android:permission=\"android.permission.BIND_NOTIFICATION_LISTENER_SERVICE\" > in AndroidManifest.xml"

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method static checkPermissionArgument(Ljava/util/List;Z)Z
    .locals 9
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)Z"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz p0, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto/16 :goto_3

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->getAndroidVersionCode()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/16 v2, 0x21

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x2

    move v8, v7

    if-le v1, v2, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    return v3

    :cond_1
    const/4 v8, 0x5

    if-eqz p1, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-class v1, Lcom/hjq/permissions/Permission;

    const-class v1, Lcom/hjq/permissions/Permission;

    const/4 v8, 0x7

    const-class v1, Lcom/hjq/permissions/Permission;

    const-class v1, Lcom/hjq/permissions/Permission;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    array-length v2, v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-nez v2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    return v3

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    array-length v2, v1

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-ge v0, v2, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    aget-object v4, v1, v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v8, 0x2

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-nez v5, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_1

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v5, 0x0

    :try_start_0
    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    check-cast v4, Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {p1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x1

    goto :goto_1

    :catch_0
    move-exception v4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v4}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    goto :goto_0

    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v0, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v1, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_2

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v1, "T eh"

    const-string v1, "eTh "

    const/4 v8, 0x5

    const-string v1, " The"

    const-string v1, "The "

    const/4 v7, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const-string v0, " opmraspa es smri rq sntrll cngeoo seeonidius noaye ade ssapocl,tup ma liremti nonydiei"

    const-string v0, " is not a dangerous permission or special permission, please do not request dynamically"

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    throw p0

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    return v3

    :cond_7
    :goto_3
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-nez p1, :cond_8

    const/4 v8, 0x6

    const/4 v7, 0x2

    return v0

    :cond_8
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x5

    const-string/jumbo p1, "mu noT peqdpsi he yaetneems beeoosriortn"

    const-string/jumbo p1, "tynToedemssi seaeerropiobhp n et tnmuqe "

    const/4 v8, 0x1

    const-string p1, " h isbotepnaeye opntub eenscsti rqedmrmT"

    const-string p1, "The requested permission cannot be empty"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    throw p0
.end method

.method static checkPictureInPicturePermission(Landroid/app/Activity;Ljava/util/List;Lcom/hjq/permissions/AndroidManifestInfo;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/permissions/AndroidManifestInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/AndroidManifestInfo;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "nRE_Uiundbid.PUopTePNsCCIiTmsIorRrIa_"

    const-string v0, "CnIU_bainEPii_drsEsdIr.TPoRmINUoCeTRp"

    const/4 v2, 0x7

    const-string v0, "TIUiCRopEs.IUsidTnIpEPe.oCdanrR__PNrm"

    const-string v0, "android.permission.PICTURE_IN_PICTURE"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void

    :cond_1
    const/4 v2, 0x3

    iget-object p1, p2, Lcom/hjq/permissions/AndroidManifestInfo;->activityInfoList:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ge p2, v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast v0, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-boolean v0, v0, Lcom/hjq/permissions/AndroidManifestInfo$ActivityInfo;->supportsPictureInPicture:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p2, ""

    const/4 v2, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p1, p0, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "nptteasgqPrte=,duroot caNnaeeiatP ie tact/tvuiierenauuicp<niisysicvit seros etbelpr  t/yr/t:igrIurdmer"

    const-string v0, "gt /eautiiglitnase=Ncucyraeer,o s o rivvt/ tnPpn peeduIPuo< eatctai c/enubipsrrrreraiyserdt:ieiisttttm"

    const/4 v2, 0x7

    const-string v0, "eostrciyIiureae it=nug attdvaPreeg,irpNyerct uitutapcPr/teoneo btindma :enitesvr</siir/ieslas tdsc rt "

    const-string v0, "No activity registered supportsPictureInPicture attribute, please register \n<activity android:name=\""

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo p0, "su/mtioeiAneruIsd d.a=e >ldtoiit:///M/crr tatunrnrncfierodpnPpus m/Px"

    const-string p0, "\" android:supportsPictureInPicture=\"true\" > in AndroidManifest.xml"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    throw p1
.end method

.method static checkReadMediaVisualUserSelectedPermission(Ljava/util/List;)V
    .locals 3
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "EERTodSd..EooiUSL_MeS__r_DUIDamRnIppADEVnAsCrLiAEi"

    const-string v0, "E_InDdDpMLAsV.aAEiSE.TAonR_doC_SiURLsDrmpES_eEUIir"

    const/4 v2, 0x2

    const-string v0, "iESUIbAESLiSroERismMDon_n__RsaE_UdTVdLE.IpEerDA.CA"

    const-string v0, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "AMmDniuD_rn.Rsid.EAMaooeAiGSsrEI_IpE"

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "ArsImnEps_Irq.iM.ndiEdiD_DRDaopAeOV"

    const-string/jumbo v0, "sAEaDonIqiI_Amdie.DioV.rD_dsORpnMrE"

    const-string v0, "DDOmrIosqnR_IaddEiVD_spoMn..iEAEriA"

    const-string v0, "android.permission.READ_MEDIA_VIDEO"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    move v2, v1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "IAsit L.uO maAtMncMrioremtsdeSsdrusRRo_ELAIEDnDstrEA_oe irD _sionipdEt.spAn rEmyARUEani oimeDs SomooiSUIA_sihe.rEoCVboiVnEdsoGM Drl espipuao._rd.p E.eInMDAnaR rDhhsir_. eEd anadnYnIe rES_DtdaI,m_oibiseoeEq Te "

    const-string v0, "You cannot request the android.permission.READ_MEDIA_VISUAL_USER_SELECTED permission alone. must add either android.permission.READ_MEDIA_IMAGES or android.permission.READ_MEDIA_VIDEO permission, or maybe both"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    throw p0

    :cond_2
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method static checkStoragePermission(Landroid/content/Context;Ljava/util/List;Lcom/hjq/permissions/AndroidManifestInfo;)V
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/permissions/AndroidManifestInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/hjq/permissions/AndroidManifestInfo;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v0, "mIs.A.opiEMiErAdS_nArsDeMaRGIndmsD_E"

    const-string v0, "RrDmDEnI.S.AMsEdEmieAdIpAi_GarosMni_"

    const/4 v9, 0x4

    const-string/jumbo v0, "sGDmSIspnio._EiRMAAnrIDiaoEre_AdEM.d"

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-string v2, "AOmpond_dXiTnoAETRsEo.rSEoILisiaRTWE_.eNG"

    const-string v2, "ILRooiRsEdNGTEWiReOsSiXornTAEE.p__TA.adnm"

    const-string v2, "EdESab_EAi_AdrTWTeoI.GEORnn.RpiRmoiTNrsLs"

    const-string v2, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo v3, "odpEmOur__AD.seiAIaDnsREoriIdnDM.bU"

    const-string v3, "DiiRIbaAnr.MApIsD_rAE.EdOson_odDemU"

    const/4 v9, 0x0

    const-string v3, "android.permission.READ_MEDIA_AUDIO"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo v4, "oDEminupRi_OEsiId.MsrEneV_IaAoAr.pD"

    const-string v4, "EArIsEuaRDoOrnps..neimMI__VdADiDEoi"

    const/4 v9, 0x4

    const-string/jumbo v4, "insnD.OEqooRidEd_Ap.IaDsIMmV_DiArre"

    const-string v4, "android.permission.READ_MEDIA_VIDEO"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string v5, "LAsESnDiAsXpaOnEoRdreGRmEi.pirAEdsTR_oT."

    const-string/jumbo v5, "rnEORsrpo_aiT.n.dXEAEomiSiERNsdeAAGTpDLR"

    const/4 v9, 0x1

    const-string v5, "Es.miSsNOERrdid_AopE_DiaoXRAGmnTrR.EeALn"

    const-string v5, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    const-string/jumbo v6, "pnisMNXrqsmnAr._.LdGiOToAoR_RESGAATeEaidNE"

    const/4 v9, 0x1

    const-string v6, "NoEio.rAns_TE_AEMENspAAGioS.eTaXdGOrdRiLnR"

    const-string v6, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-nez v1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-nez v1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-nez v1, :cond_0

    const/4 v8, 0x5

    move v9, v8

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez v1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {p1, v5}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v1, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez v1, :cond_0

    const/4 v8, 0x3

    move v9, v8

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/16 v7, 0x21

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-lt v1, v7, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1, v5}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo p1, "nD>deb EM.dAEnR_iosTEha3_AkoApIo dsssmiDA_iper.na nhdEoriredmtmAiTGe,arDruEiriis_dRDNRRdLeoOD,s_rgsEIW OEhaotI.nIaSAA _sRaDEro_li.AhDSdo XI,saeiet_Mp3onsSEV ..iG.nipMt EnIeO=DAsondRrDAEmrUdrVu iEsMr  .An"

    const-string/jumbo p1, "n_sl.gAioaIan.hdrA_ =OirAM e.RsEAGrkGisEmmruTMe.deEaoVetErnD,.soIE asadSV_DirTRpAn,i_NEnrD o Ae_AoRen_oIieDdmoWnaOXtMDRppneD,.O.iirmDidEIIis srdRdtiEisE ntaiM _ 3e AE3ohpd>ArsdSsh ErIDALSrsho.AoDndEuRU_s"

    const/4 v9, 0x1

    const-string p1, "IDirMsu>RtT VRiEsEaX R spmrTs_Ar nunsids,Iii_dIEs,ASrn,.MSmgWilosps Rr_3DDADnm.ds_heot=nAAoEredEdA3Dnio.otADha eEE AaEDOVadIohuOpUAeidrIpddEnO.rrRe.hra.oA.M ne_DGERGk_ioieEDiANesEL.r_anmioeMnr_idn ta Io "

    const-string p1, "When targetSdkVersion >= 33 should use android.permission.READ_MEDIA_IMAGES, android.permission.READ_MEDIA_VIDEO, android.permission.READ_MEDIA_AUDIO, rather than android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    throw p0

    :cond_2
    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v0, :cond_d

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v0, :cond_d

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v0, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto/16 :goto_4

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eqz v0, :cond_5

    const/4 v9, 0x0

    invoke-static {p1, v5}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez v0, :cond_4

    const/4 v8, 0x3

    move v9, v8

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez v0, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_1

    :cond_4
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string p1, "RiraoXepGpLmTnEI pan G_a EtORLRrG nuXhW  NNospAh iAymOA_IRyavfserM isSRENoE__roReAeRESsAdTNm  SdGeTET stEEAoOAli pRXLEEpfEpTdnA_sDT,oT _fAil E"

    const-string p1, "_nAmpaOWmT iRiRNvoroAGXOEsdTppThLX NNnilLENLyedaEf XTE EOrGfE_Ao AfARSn_esisGE SySasns_AAlTpTE I RpaRisIMoD rR_ t dou,G Ermp_ tREAe EhoRoEAeeT"

    const/4 v9, 0x0

    const-string/jumbo p1, "ioRXD prqARhRlf RnOEeN io NAEEip nT stEsAaXrRo E,lWTpLaydEEASh_EEGIiradeo eAeO_yNEfEp EAAusoRsS  _pTAaSdo_T_sR ieO noGsTvIfLr_mTmpGAtGLR MnNTX"

    const-string p1, "If you have applied for MANAGE_EXTERNAL_STORAGE permissions, do not apply for the READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE permissions"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    throw p0

    :cond_5
    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v0, ".Eso.AECOCinSOrMpDi_AsCNTsmeLodSid_aoInA"

    const-string/jumbo v0, "pis_oioeaLCImSAdrM.nEnOADTNCiEoSdsO_r.CA"

    const/4 v9, 0x5

    const-string v0, "_iNmACsDECAEreLOionATdpd.SsC.omrOanMI_iI"

    const-string v0, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v0, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x1

    return-void

    :cond_6
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez p2, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void

    :cond_7
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object p2, p2, Lcom/hjq/permissions/AndroidManifestInfo;->applicationInfo:Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;

    const/4 v9, 0x1

    const/4 v8, 0x4

    if-nez p2, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    return-void

    :cond_8
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->isScopedStorage(Landroid/content/Context;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-boolean p2, p2, Lcom/hjq/permissions/AndroidManifestInfo$ApplicationInfo;->requestLegacyExternalStorage:Z

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/16 v1, 0x1d

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-lt p0, v1, :cond_a

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez p2, :cond_a

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez p2, :cond_9

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v0, :cond_9

    const/4 v8, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_2

    :cond_9
    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string p1, "Please register the android:requestLegacyExternalStorage=\"true\" attribute in the AndroidManifest.xml file, otherwise it will cause incompatibility with the old version"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    throw p0

    :cond_a
    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/16 p2, 0x1e

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-lt p0, p2, :cond_c

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez p0, :cond_c

    const/4 v9, 0x3

    if-eqz v0, :cond_b

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_3

    :cond_b
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string p1, "AetpoA neegaod/e.esyhraaLp/na saarlsoa h RgGerEte b arpe /thouaS- Me prlpes di,a/fnsetdIvtrot urtatcToe.a itmin miireoAoi iafbmhncadoaMrsOotiut ore.TpoA sgdh.s NlnRtaiIptdgerrrt /e  poXliiop pi mNaecacbetyeeTar_pfor=efo=t/sr_ttupdndei/  tseso ole dmlin /sd< ntserddEe/xghap:ia foGaito:ai,i>iEnens uve  r sela  d nm speEn sSemSiaaos.nlAa"

    const-string/jumbo p1, "tmvetbainesaoropaldtars oii  roa esterieoadeex dTean /tpd/o s omtLramhc/sSn reirIpgddEaoplhgi=crleiTnataRianma  eyte nfabi dohy urtnipopmovsa_ieOces_etaoAlil.sG prp Gta..Xrp As,afMi =ueuorsst,/trsh iut  SpretMf seed sn> .dnblhoN/ie  n/ertnt/I: edn aE-ireeaos Tpfs/ep  esAttgiEl/rpnl<shRta ocd:of ra adnme egeiAoi dEoNeptmau .Aeieaa goSa"

    const/4 v9, 0x5

    const-string p1, "The storage permission application is abnormal. If you have adapted the scope storage, please register the <meta-data android:name=\"ScopedStorage\" android:value=\"true\" /> attribute in the AndroidManifest.xml file. If there is no adaptation scope storage, please use android.permission.MANAGE_EXTERNAL_STORAGE to apply for permission"

    const/4 v9, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    throw p0

    :cond_c
    :goto_3
    const/4 v9, 0x1

    const/4 v8, 0x7

    return-void

    :cond_d
    :goto_4
    const/4 v9, 0x1

    invoke-static {p1, v5}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-nez p0, :cond_f

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-nez p0, :cond_e

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    return-void

    :cond_e
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string p1, "ereyMbEepec n vernuroemT lilrayfmAeogsenw iR asiidNh  ppaiieeXar ,ne AN EG snsda faL,i EE l_ros deiado.a tgdceRhaeo itdaiS  iothot Betums ueATyns t_sndOip aA sirmlG "

    const-string p1, "R ion uEoa rfesdATnomeegs iMed ,sm i ni AatwnLcpGupg eiaNs,esAtioisne  _sefT trpdr Bp elaa.ishlei yaS ar ya OoNXnudmtta mnEireiEyl todoieaa_ sGdl ih n eevcEeA Rehrdr"

    const/4 v9, 0x4

    const-string/jumbo p1, "tolep us uci  Tde AXr y ssra nEBAeal r  NNgliypsteoita.i rmfwy neo ro maasEMrem_RiotoeaA,hst iaepht nduTo e,c  sAeisGini ie Sd_sgdhiedf ieaOGrLaddman vpERielrne Enne"

    const-string p1, "Because the MANAGE_EXTERNAL_STORAGE permission range is very large, you can read media files with it, and there is no need to apply for additional media permissions."

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    throw p0

    :cond_f
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "iT L aep_hRn sGorAn  WsAdTXeEoop dr opiirS,EinlDmELOpEX_oanE OsdhiRefpte_ioIl e pAGdE RR  m_AvSyA EI NfsRTTsmufprNyeatopsERT"

    const-string p1, "RA_orAapiip eipAplEEfpLDsdaReRTth n fT mrAs s_SOn o_oiS rmreIdGE edEneyuvTTmlTNo nXoyE,ai   soEppo tEa ALsdEWf_RheIisRNOX GR"

    const/4 v9, 0x1

    const-string p1, "GhulRe_rqsoeETXET,pmXansfo NWean  ypfEsroEnihAA mROirpSaitoIpEta  Is REdODAomo_e TRdLoA sndEG diLR y p_TTESaNipvAR ei  le_sf"

    const-string p1, "If you have applied for media permissions, do not apply for the READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE permissions"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    throw p0
.end method

.method static checkTargetSdkVersion(Landroid/content/Context;Ljava/util/List;)V
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x3

    const-string/jumbo v1, "srsDADsE_qRVLamSIEinAredpARTi.onIiUSdEC_o_MELSD_EU"

    const-string v1, "TDponRIeqsE_rAAAnLi_U.mMEEEaLUdIR_SsEiE_DVrdSSCDoi"

    const/4 v5, 0x7

    const-string/jumbo v1, "sarmiEDEVS.RRmnDT_DCEsdSioSEELAoLiM_r_n_dAUIApUEI."

    const-string v1, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/16 v1, 0x21

    const/4 v4, 0x6

    move v5, v4

    goto :goto_1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v1, "iLdCoEseOCNTBinErnHTisd_rNOao.p.somT"

    const-string v1, "LisNsUCNToaCrdrEd_mH.ipiTETBnOOnso.e"

    const/4 v5, 0x5

    const-string/jumbo v1, "s_CrmbnoBsEipNU.NOTdioTTreiCOHnda.OE"

    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo v2, "riBi_pusoHLVnOETOImaTEonrDiRUAs.TddES."

    const-string/jumbo v2, "nEsmdVOrEo.OHAi_TETsmBpiT.DSRLnrUIadoi"

    const/4 v5, 0x5

    const-string/jumbo v2, "ndVod_ppEiHirTDsBSLTEEOrmAoaTRUI..insO"

    const-string v2, "android.permission.BLUETOOTH_ADVERTISE"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v3, "nEUSH.doqiOmLnTN.rsiCArd_oapiTesO"

    const-string v3, "android.permission.BLUETOOTH_SCAN"

    filled-new-array {v3, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/16 v1, 0x17

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/hjq/permissions/PermissionHelper;->findAndroidVersionByPermission(Ljava/lang/String;)I

    move-result v1

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-lt v2, v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v2, "Rost ese"

    const-string v2, " tsuoRee"

    const/4 v5, 0x5

    const-string v2, "Request "

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v0, " eim  doKepsntTuSm, rSisbkDaeVms  eroshbtti nr"

    const-string v0, " Susebk,erVirKrobnSt pagssTtom  ehDdintm e s i"

    const/4 v5, 0x4

    const-string v0, " thiokDSermosne tSK stsrpud,ne Vebr smae iioT "

    const-string v0, " permission, The targetSdkVersion SDK must be "

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v0, "feeoobpdepp Sn u t t ndwVaanoom iisiaoosmtrsytrigk,teheti d up est r uoalorewl g ,  ohlnypdrer"

    const-string/jumbo v0, "mw  oyuuadieer ln eiriotds smp n owenga dopsi t,th ao  ttnayeilrlfoshuVkerSetaop   toeop,rdpgr"

    const/4 v5, 0x7

    const-string/jumbo v0, "oydtihu nno eapr o  emoys  l,oewio p rdn e imtsaptggSpdesiw,Vlaotlueo f rra tt a hnueerpitkdso"

    const-string v0, " or more, if you do not want to upgrade targetSdkVersion, please apply with the old permission"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    throw p0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method static optimizeDeprecatedPermission(Ljava/util/List;)V
    .locals 6
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v1, "ETiARaApGD.OSrsTo_pd.ieEXpEAsLoRnRrEndi_"

    const-string/jumbo v1, "oOmREospSedTX_LiEEEa.rAr.i_pRTGAnAinsRdD"

    const/4 v5, 0x5

    const-string/jumbo v1, "rnE_TATdqaiOn.RosmLiE_DEEXSsrei.ANdRRGoA"

    const-string v1, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, "NAssCdrIOFeoOrqIspSoiiaCnE_Ci.LTmNA_ES."

    const-string v2, "NiICrSsNqnoIAanr.EL_EOpTisAde_FSimCO.Co"

    const/4 v5, 0x3

    const-string v2, "dnCmia.OCApNTAroNCISoEsiSIi.rme_F_OEdsn"

    const-string v2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v0, "eIiTosoTnPO.sFSNipnOTdNA_mdrIaosOirCI"

    const-string v0, "iIspNSaPFn_TdTsCoiOnOSsiArmeOrNT.oIId"

    const/4 v5, 0x7

    const-string/jumbo v0, "psPOSbIIANiIsS_o.dTmiOTCTneF.oraNindO"

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v0, ".rTimousCmFedIorTIiIpIECinOANVNOdasE_S."

    const-string v0, ".prmEo_AeINVCoFaRSiTdrnIIOCiOiImTE.sdsN"

    const/4 v5, 0x3

    const-string v0, "_rdnOESp.doR.VpIAFTrsOeIsoNiTiNEIiaInCm"

    const-string v0, "android.permission.NOTIFICATION_SERVICE"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const-string/jumbo v0, "sa.SiY.RqsFVi_oIdWrICNrIEnEnE_moABoeDp"

    const-string v0, "iRIWonse_dFdoB_.aEiISnVYm.CpArIErENoDs"

    const-string v0, "aEsSBAViIpN_sCoWnDFsednEriIiYEr._Ido.m"

    const-string v0, "android.permission.NEARBY_WIFI_DEVICES"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {p0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v0, "A_smEEi.DaSMR_nGrIdpDrdoEbs.inIAMmAe"

    const-string/jumbo v0, "sDaSibi_MdMd.nepEAAIEsmRiD_ArGEnoIr."

    const/4 v5, 0x5

    const-string v0, "EAonoiidA.MGsn_DeRsapA.Dr_SEIiodrMIE"

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v0, "EdiErbsndo.nruA._s_RiDDoViApOMmEeDI"

    const-string/jumbo v0, "siVEdDuIOrro_MiARn.eDpAmidnE.Ios_DE"

    const/4 v5, 0x2

    const-string v0, "dRDi_DurnoAaVmiEEsOpDesMrnd.i._oEAI"

    const-string v0, "android.permission.READ_MEDIA_VIDEO"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v0, "irOsDoEpA.podMIEIpAe_nsmDRDn_da.rAi"

    const-string v0, "E.MI.oDprdOr_UdEssneARp_ImAaDDoAiin"

    const/4 v5, 0x1

    const-string v0, "_.DsnrEiqiIOAm.sMnraDpoAURiIEedAdDo"

    const-string v0, "android.permission.READ_MEDIA_AUDIO"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {p0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v0, "TnsLr..rUABdOipCodiSmOTsseaNniEH_"

    const-string v0, "android.permission.BLUETOOTH_SCAN"

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p0, v2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-interface {p0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v0, "AaAmEsGEErNoOioSdiXeGimAT.rMTqsd_ANE.npLR_"

    const-string/jumbo v0, "nTiiGMo_qpas_OdNAriEro.GEAERXeNAmdsES.ALRT"

    const/4 v5, 0x6

    const-string v0, "T.A_oNGaAMeEAAOdoniENrsprGinioX_LdRsTER.SE"

    const-string v0, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v0, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v0, "a.ss.biRdE_ORmIrsiSEELANTodoenWTAniEXG_pR"

    const-string v0, "ATsisLrRSTodEIpXnsr_OEG.nE_eA.RWNmiodEiaR"

    const/4 v5, 0x1

    const-string v0, "RorimTuiEdiaonLsEsRndrW_eER.AAE_S.TGIOXTN"

    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v1, :cond_6

    const/4 v5, 0x1

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    const/4 v5, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-nez v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v0, "IsOedpNpoAiNnCmI.diVYi_nrrOE.oImTGaTsIC"

    const-string v0, "TCsmAIomTIdNsOInrneaYId.pOroNTVEiC.G_ii"

    const/4 v5, 0x0

    const-string v0, ".TRINeTCqaidIOpI.OroVGo_dsiIinNTAYmnrsE"

    const-string v0, "android.permission.ACTIVITY_RECOGNITION"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_7

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v0, "DesdoSip.BarOoSiRYsrNEdOSm_nnso"

    const-string/jumbo v0, "insNodSaYeDEr.riBSsiOndRoSmO_op"

    const/4 v5, 0x0

    const-string/jumbo v0, "pSomOeRrDriimSYSONBon_Edni..sds"

    const-string v0, "android.permission.BODY_SENSORS"

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_8

    const-string/jumbo v0, "irRboSs._HiEEsnOA.EPiDoRm_aMUBdpnrodN"

    const-string/jumbo v0, "snSorbsP.DoERN.EpOBUEa_RAMi_mNnddirHi"

    const/4 v5, 0x6

    const-string v0, "iNdsOb_HUaPdsDRmEr_niEAorR.n.piBoEeMS"

    const-string v0, "android.permission.READ_PHONE_NUMBERS"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v0, "SsEo.EuENd_TrOn_PTidAism.eaAipruRDn"

    const-string v0, ".A.HiRusT_nSTdADes_idmnNaPrEopEEiOr"

    const/4 v5, 0x0

    const-string v0, ".AHDSippaOooi_PEEANr.r_sEiTensddnmT"

    const-string v0, "android.permission.READ_PHONE_STATE"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->containsPermission(Ljava/util/Collection;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v1, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_8
    const/4 v5, 0x3

    const/4 v4, 0x6

    return-void
.end method
