.class final Lcom/hjq/permissions/NotificationListenerPermissionCompat;
.super Ljava/lang/Object;


# static fields
.field private static final SETTING_ENABLED_NOTIFICATION_LISTENERS:Ljava/lang/String; = "enabled_notification_listeners"


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    return-void
.end method

.method static getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 8
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " @s~@~v@@~~@b ~ r~adbloKs @o f ~ i~~ @-/@~. o@@~~~no c~ mi  @1l4@@yo@i@~f~~u t@~ @S ~@b@o M/t~~~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v0, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getAndroidManifestInfo(Landroid/content/Context;)Lcom/hjq/permissions/AndroidManifestInfo;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v0, v0, Lcom/hjq/permissions/AndroidManifestInfo;->serviceInfoList:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    if-eqz v3, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v3, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;

    const/4 v7, 0x5

    const/4 v6, 0x4

    iget-object v4, v3, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;->permission:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v5, "dTsnISCOrCsEeTsmIR_TNrooFiB.pNnIEIRai_iIOED_.LENdNISA"

    const/4 v7, 0x3

    const-string v5, "SOEmmIInnD__RdsBNCsoaAOLIripISNIei.VCIo_TRTENi.TNEEdF"

    const-string v5, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v4, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    move-object v2, v3

    move-object v2, v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    :goto_1
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v2, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const-string v3, "CTLmo.ILdI.IASetOTs_tGEN_FoOsrniNSNESITIITaTRDEiAdTnEN"

    const-string v3, "SOEmadDnttA_RLT.TSIiIdETIOGN_TINFsIN.ErE_TLNCAeIosTiSn"

    const/4 v7, 0x4

    const-string v3, "GSiNObENT_tTT..snrEgOIFaLItLIAD_CETdoRSAnII_EeTsNiITdN"

    const-string v3, "android.settings.NOTIFICATION_LISTENER_DETAIL_SETTINGS"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v3, Landroid/content/ComponentName;

    const/4 v7, 0x4

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/hjq/permissions/AndroidManifestInfo$ServiceInfo;->name:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v3, p0, v2}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x0

    invoke-virtual {v3}, Landroid/content/ComponentName;->flattenToString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v3, "aFSveNuTrEo_OEOai...dEonMOOA_pxINLANrTPCRrdN_CIioMrNtTEdeNI"

    const-string/jumbo v3, "oroiodeiOrI.CeOaFNIArP_LNS_NvtN.rIEndEITEaR.NOTCpNEMxMO_AdT"

    const/4 v7, 0x6

    const-string/jumbo v3, "rTOEOTIpdIOErCipSLAEMN_NxvnNt.C._FerAeRIOMT.aNNToor_EdINiPd"

    const-string v3, "android.provider.extra.NOTIFICATION_LISTENER_COMPONENT_NAME"

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v2, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_2

    :cond_4
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :cond_5
    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez v1, :cond_7

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid5_1()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v1, "SSCnEOIIqTENdTIsasAEGAoL_SieNOi_FTr.ItTNRtNTNCgII_dn.O"

    const-string v1, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v0, :cond_6

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_3

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :goto_3
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p0, v1}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-nez v0, :cond_8

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/PermissionIntentManager;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v1

    :cond_8
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object v1
.end method

.method static isGrantedPermission(Landroid/content/Context;)Z
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid4_3()Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    return v1

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v2, "__srotobsdsetcnflniibianielnae"

    const-string v2, "eatlfbnacr_dsiooit_siltenneinb"

    const/4 v9, 0x6

    const-string/jumbo v2, "sinmotloa_dencnitlbrintifeease"

    const-string v2, "enabled_notification_listeners"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v0, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    return v3

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const-string v2, ":"

    const-string v2, ":"

    const/4 v9, 0x5

    const-string v2, ":"

    const-string v2, ":"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    array-length v2, v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    move v4, v3

    move v4, v3

    const/4 v9, 0x6

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-ge v4, v2, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    aget-object v5, v0, v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v5}, Landroid/content/ComponentName;->unflattenFromString(Ljava/lang/String;)Landroid/content/ComponentName;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-nez v5, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_1

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v5}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-nez v6, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto :goto_1

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v5}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v5

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x5

    return v1

    :catch_0
    move-exception v5

    const/4 v9, 0x0

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_0

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    return v3
.end method
