.class Lcom/hjq/permissions/StartActivityManager$StartActivityDelegateActivityImpl;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/hjq/permissions/StartActivityManager$StartActivityDelegate;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/permissions/StartActivityManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "StartActivityDelegateActivityImpl"
.end annotation


# instance fields
.field private final mActivity:Landroid/app/Activity;


# direct methods
.method private constructor <init>(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/hjq/permissions/StartActivityManager$StartActivityDelegateActivityImpl;->mActivity:Landroid/app/Activity;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Landroid/app/Activity;Lcom/hjq/permissions/StartActivityManager$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/hjq/permissions/StartActivityManager$StartActivityDelegateActivityImpl;-><init>(Landroid/app/Activity;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public startActivity(Landroid/content/Intent;)V
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@@  @i@@@~~~f~1b@@@mb o-@~@uv~  ot~~~~~iM@nayl oo~o @~ Kcrl~~@@~/d.~ ~ s o/~ b~ i4t f~ @@@S@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/permissions/StartActivityManager$StartActivityDelegateActivityImpl;->mActivity:Landroid/app/Activity;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public startActivityForResult(Landroid/content/Intent;I)V
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/permissions/StartActivityManager$StartActivityDelegateActivityImpl;->mActivity:Landroid/app/Activity;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {v0, p1, p2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method
