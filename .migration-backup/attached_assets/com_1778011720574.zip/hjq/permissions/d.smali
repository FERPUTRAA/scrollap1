.class public final synthetic Lcom/hjq/permissions/d;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/hjq/permissions/OnPermissionPageCallback;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s@ @~@~4@ ~~~bo~ui~~~bM ~f a~fsmon  o~~-l @v~Kt@o @~~ S~~~. tl@ @d~1@i@o@b@   @~~ir/@c/ @@ yo "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method
