.class Lcom/hjq/permissions/PermissionFragment$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/hjq/permissions/OnPermissionCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hjq/permissions/PermissionFragment;->splitTwiceRequestPermission(Landroid/app/Activity;Ljava/util/List;Ljava/util/List;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/hjq/permissions/PermissionFragment;

.field final synthetic val$activity:Landroid/app/Activity;

.field final synthetic val$allPermissions:Ljava/util/List;

.field final synthetic val$requestCode:I

.field final synthetic val$secondPermissions:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lcom/hjq/permissions/PermissionFragment;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$activity:Landroid/app/Activity;

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput-object p3, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$secondPermissions:Ljava/util/ArrayList;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$allPermissions:Ljava/util/List;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p5, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$requestCode:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic a(Lcom/hjq/permissions/PermissionFragment$2;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ss~ ~@ 1@@oc@@ v@~~o @ff i@~~~@~~~o nb o@ i4-. o@ S@y~ ~M~@/ @l@~~@ @@/~~~@ b~  lu K~mt~brtai@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/hjq/permissions/PermissionFragment$2;->lambda$onGranted$0(Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method private synthetic lambda$onGranted$0(Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Lcom/hjq/permissions/PermissionFragment$2$1;

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/hjq/permissions/PermissionFragment$2$1;-><init>(Lcom/hjq/permissions/PermissionFragment$2;)V

    const/4 v3, 0x3

    new-instance v1, Lcom/hjq/permissions/PermissionFragment$2$2;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, p0, p3, p4, p2}, Lcom/hjq/permissions/PermissionFragment$2$2;-><init>(Lcom/hjq/permissions/PermissionFragment$2;Ljava/util/List;ILjava/util/ArrayList;)V

    const/4 v3, 0x3

    invoke-static {p1, p2, v0, v1}, Lcom/hjq/permissions/PermissionFragment;->launch(Landroid/app/Activity;Ljava/util/List;Lcom/hjq/permissions/OnPermissionInterceptor;Lcom/hjq/permissions/OnPermissionCallback;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public onDenied(Ljava/util/List;Z)V
    .locals 5
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/app/Fragment;->isAdded()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-array p1, p1, [I

    const/4 v4, 0x7

    const/4 p2, -0x1

    const/4 v4, 0x5

    move v3, p2

    move v3, p2

    const/4 v4, 0x7

    invoke-static {p1, p2}, Ljava/util/Arrays;->fill([II)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v0, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$requestCode:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$allPermissions:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array v2, v2, [Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1, v2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v1, [Ljava/lang/String;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p2, v0, v1, p1}, Lcom/hjq/permissions/PermissionFragment;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public onGranted(Ljava/util/List;Z)V
    .locals 9
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz p2, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/hjq/permissions/PermissionFragment$2;->this$0:Lcom/hjq/permissions/PermissionFragment;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/app/Fragment;->isAdded()Z

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    if-nez p1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz p1, :cond_1

    const/4 v8, 0x2

    const-wide/16 p1, 0x96

    const-wide/16 p1, 0x96

    const/4 v8, 0x2

    const-wide/16 p1, 0x96

    const-wide/16 p1, 0x96

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-wide/16 p1, 0x0

    const/4 v8, 0x3

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$activity:Landroid/app/Activity;

    const/4 v8, 0x0

    iget-object v3, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$secondPermissions:Ljava/util/ArrayList;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v4, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$allPermissions:Ljava/util/List;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget v5, p0, Lcom/hjq/permissions/PermissionFragment$2;->val$requestCode:I

    const/4 v8, 0x6

    new-instance v6, Lcom/hjq/permissions/h;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/hjq/permissions/h;-><init>(Lcom/hjq/permissions/PermissionFragment$2;Landroid/app/Activity;Ljava/util/ArrayList;Ljava/util/List;I)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v6, p1, p2}, Lcom/hjq/permissions/PermissionUtils;->postDelayed(Ljava/lang/Runnable;J)V

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void
.end method
