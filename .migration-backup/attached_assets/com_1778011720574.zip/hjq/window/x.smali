.class final Lcom/hjq/window/x;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field private final a:Lcom/hjq/window/j;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation
.end field

.field private final b:Lcom/hjq/window/q;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/hjq/window/j;Lcom/hjq/window/q;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/q;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Lcom/hjq/window/q;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/hjq/window/x;->a:Lcom/hjq/window/j;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/hjq/window/x;->b:Lcom/hjq/window/q;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~4so@ Mn@~i@ b~Sr@@.c@sbf@~~ ~o @@   ~@@@ ou@m/dyi~  K~@@ @~l  ~o@l ~~bo ~~1t~vo-i@~ ~~~~@ft~ @/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/hjq/window/x;->b:Lcom/hjq/window/q;

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/hjq/window/x;->a:Lcom/hjq/window/j;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0, v1, p1}, Lcom/hjq/window/q;->a(Lcom/hjq/window/j;Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return p1
.end method
