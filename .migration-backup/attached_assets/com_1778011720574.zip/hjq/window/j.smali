.class public Lcom/hjq/window/j;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/hjq/window/u$a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<X:",
        "Lcom/hjq/window/j<",
        "*>;>",
        "Ljava/lang/Object;",
        "Lcom/hjq/window/u$a;"
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/ref/Reference;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;"
        }
    .end annotation
.end field

.field private b:Landroid/content/Context;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c:Landroid/view/ViewGroup;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Landroid/view/WindowManager;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private e:Landroid/view/WindowManager$LayoutParams;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private f:Z

.field private g:I

.field private h:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Lcom/hjq/window/a0;

.field private j:Lcom/hjq/window/draggable/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private k:Lcom/hjq/window/n;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private l:Lcom/hjq/window/u;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final m:Ljava/lang/Object;

.field private final n:Ljava/lang/Runnable;

.field private final o:Ljava/lang/Runnable;

.field private final p:Ljava/lang/Runnable;

.field private final q:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/accessibilityservice/AccessibilityService;)V
    .locals 3
    .param p1    # Landroid/accessibilityservice/AccessibilityService;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x5

    or-int/2addr v2, v1

    iput-object v0, p0, Lcom/hjq/window/j;->a:Ljava/lang/ref/Reference;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lcom/hjq/window/f;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/hjq/window/f;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/hjq/window/j;->n:Ljava/lang/Runnable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/hjq/window/g;

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/hjq/window/g;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/hjq/window/j;->o:Ljava/lang/Runnable;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lcom/hjq/window/h;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/hjq/window/h;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/hjq/window/j;->p:Ljava/lang/Runnable;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/hjq/window/i;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/hjq/window/i;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/hjq/window/j;->q:Ljava/lang/Runnable;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->A(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/16 p1, 0x7f0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->R0(I)Lcom/hjq/window/j;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 7
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/hjq/window/j;->a:Ljava/lang/ref/Reference;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v1, Lcom/hjq/window/f;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1, p0}, Lcom/hjq/window/f;-><init>(Lcom/hjq/window/j;)V

    const/4 v6, 0x4

    iput-object v1, p0, Lcom/hjq/window/j;->n:Ljava/lang/Runnable;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Lcom/hjq/window/g;

    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-direct {v1, p0}, Lcom/hjq/window/g;-><init>(Lcom/hjq/window/j;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v1, p0, Lcom/hjq/window/j;->o:Ljava/lang/Runnable;

    const/4 v6, 0x3

    const/4 v5, 0x7

    new-instance v1, Lcom/hjq/window/h;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v1, p0}, Lcom/hjq/window/h;-><init>(Lcom/hjq/window/j;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/hjq/window/j;->p:Ljava/lang/Runnable;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v1, Lcom/hjq/window/i;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {v1, p0}, Lcom/hjq/window/i;-><init>(Lcom/hjq/window/j;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object v1, p0, Lcom/hjq/window/j;->q:Ljava/lang/Runnable;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->A(Landroid/content/Context;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v3, v2, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v5, 0x3

    move v6, v5

    const/16 v4, 0x400

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    and-int/2addr v3, v4

    const/4 v6, 0x5

    if-nez v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    and-int/lit8 v3, v3, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v3, :cond_1

    :cond_0
    const/4 v6, 0x7

    invoke-virtual {p0, v4}, Lcom/hjq/window/j;->c(I)Lcom/hjq/window/j;

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/16 v4, 0x1c

    const/4 v6, 0x7

    const/4 v5, 0x4

    if-lt v3, v4, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/hjq/window/d;->a(Landroid/view/WindowManager$LayoutParams;)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Lcom/hjq/window/j;->X(I)Lcom/hjq/window/j;

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v2, v2, Landroid/view/WindowManager$LayoutParams;->systemUiVisibility:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v2}, Lcom/hjq/window/j;->s0(I)Lcom/hjq/window/j;

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    if-eqz v2, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/view/View;->getSystemUiVisibility()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x4

    new-instance v1, Lcom/hjq/window/a0;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1, v0, p1}, Lcom/hjq/window/a0;-><init>(Ljava/lang/ref/Reference;Landroid/app/Activity;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object v1, p0, Lcom/hjq/window/j;->i:Lcom/hjq/window/a0;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/hjq/window/a0;->a()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/app/Application;)V
    .locals 3
    .param p1    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/hjq/window/j;->a:Ljava/lang/ref/Reference;

    const/4 v2, 0x4

    const/4 v1, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Lcom/hjq/window/f;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/hjq/window/f;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/hjq/window/j;->n:Ljava/lang/Runnable;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/hjq/window/g;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/hjq/window/g;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/hjq/window/j;->o:Ljava/lang/Runnable;

    const/4 v2, 0x1

    new-instance v0, Lcom/hjq/window/h;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/hjq/window/h;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/hjq/window/j;->p:Ljava/lang/Runnable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/hjq/window/i;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/hjq/window/i;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/hjq/window/j;->q:Ljava/lang/Runnable;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->A(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/16 v0, 0x1a

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-lt p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/16 p1, 0x7f6

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->R0(I)Lcom/hjq/window/j;

    const/4 v2, 0x7

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/16 p1, 0x7d3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->R0(I)Lcom/hjq/window/j;

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method private synthetic C()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~ ~@@~@~~ @of@4-~oSrKl~~@M~ v@/~@ @ @@  /~ o~t@~sa1 mn~o i@c~~b @bobl@ud.@ot ~y~  @i@~~i~ ~ f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/hjq/window/draggable/h;->M()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private a0(Landroid/view/View;Lcom/hjq/window/o;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/o;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lcom/hjq/window/o<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v1, 0x3

    move v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/16 v0, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, Lcom/hjq/window/v;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0, p0, p2}, Lcom/hjq/window/v;-><init>(Lcom/hjq/window/j;Lcom/hjq/window/o;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public static a1(Landroid/accessibilityservice/AccessibilityService;)Lcom/hjq/window/j;
    .locals 3
    .param p0    # Landroid/accessibilityservice/AccessibilityService;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/hjq/window/j;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/hjq/window/j;-><init>(Landroid/accessibilityservice/AccessibilityService;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static synthetic b(Lcom/hjq/window/j;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/hjq/window/j;->C()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static b1(Landroid/app/Activity;)Lcom/hjq/window/j;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    new-instance v0, Lcom/hjq/window/j;

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/hjq/window/j;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static c1(Landroid/app/Application;)Lcom/hjq/window/j;
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/hjq/window/j;

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/hjq/window/j;-><init>(Landroid/app/Application;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method private d0(Landroid/view/View;Lcom/hjq/window/p;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/p;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lcom/hjq/window/p<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/16 v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/hjq/window/w;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p0, p2}, Lcom/hjq/window/w;-><init>(Lcom/hjq/window/j;Lcom/hjq/window/p;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method private g0(Landroid/view/View;Lcom/hjq/window/q;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/q;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lcom/hjq/window/q<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez p2, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p2, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/16 v0, 0x10

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    new-instance v0, Lcom/hjq/window/x;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p0, p2}, Lcom/hjq/window/x;-><init>(Lcom/hjq/window/j;Lcom/hjq/window/q;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method private j0(Landroid/view/View;Lcom/hjq/window/s;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/s;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lcom/hjq/window/s<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/16 v0, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->setEnabled(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lcom/hjq/window/y;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0, p2}, Lcom/hjq/window/y;-><init>(Lcom/hjq/window/j;Lcom/hjq/window/s;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method


# virtual methods
.method protected A(Landroid/content/Context;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lcom/hjq/window/WindowRootLayout;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, p1}, Lcom/hjq/window/WindowRootLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const-string/jumbo v0, "wosniw"

    const/4 v3, 0x2

    const-string/jumbo v0, "iwnmwo"

    const-string/jumbo v0, "window"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Landroid/view/WindowManager;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v1, -0x2

    and-int/2addr v3, v1

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v2, 0x0

    move v3, v2

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v1, -0x3

    move v3, v1

    const/4 v2, 0x1

    const/4 v2, 0x6

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->format:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const v1, 0x1030004

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p1, v0, Landroid/view/WindowManager$LayoutParams;->packageName:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v0, 0x28

    const/4 v3, 0x4

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/hjq/window/j;->a:Ljava/lang/ref/Reference;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/hjq/window/k;->a(Ljava/lang/ref/Reference;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public A0(II)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public B()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public B0(F)Lcom/hjq/window/j;
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->alpha:F

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public C0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    return-object p0
.end method

.method public D()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->e()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/j;->d()V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v2}, Lcom/hjq/window/u;->b(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    :cond_1
    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v3, 0x4

    move v4, v3

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0, p0}, Lcom/hjq/window/n;->e(Lcom/hjq/window/j;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    :cond_2
    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Lcom/hjq/window/j;->i:Lcom/hjq/window/a0;

    const/4 v3, 0x0

    move v4, v3

    if-eqz v0, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/hjq/window/a0;->b()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/hjq/window/j;->i:Lcom/hjq/window/a0;

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_4

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-virtual {v0}, Lcom/hjq/window/draggable/h;->L()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->a:Ljava/lang/ref/Reference;

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/hjq/window/k;->n(Ljava/lang/ref/Reference;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public D0(Lcom/hjq/window/draggable/h;)Lcom/hjq/window/j;
    .locals 4
    .param p1    # Lcom/hjq/window/draggable/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/draggable/h;",
            ")TX;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v0, 0x6

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    move v3, v2

    if-nez p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/hjq/window/draggable/h;->L()V

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    iget-object v1, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Lcom/hjq/window/u;->b(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v1, 0x10

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/16 v1, 0x200

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->Z0()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, p0}, Lcom/hjq/window/draggable/h;->R(Lcom/hjq/window/j;)V

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_4
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p1, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    :cond_5
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_7

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance p1, Lcom/hjq/window/u;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Lcom/hjq/window/u;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/hjq/window/j;->l:Lcom/hjq/window/u;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v0, p0}, Lcom/hjq/window/u;->a(Landroid/content/Context;Lcom/hjq/window/u$a;)V

    :cond_7
    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0
.end method

.method public E(I)Lcom/hjq/window/j;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    not-int p1, p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    and-int/2addr p1, v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public E0(I)Lcom/hjq/window/j;
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x0

    iput p1, p0, Lcom/hjq/window/j;->g:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget p1, p0, Lcom/hjq/window/j;->g:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    int-to-long v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->h(J)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0
.end method

.method public F(Ljava/lang/Runnable;)V
    .locals 5
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, v0, v1, v2}, Lcom/hjq/window/b0;->d(Ljava/lang/Runnable;Ljava/lang/Object;J)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public F0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public G(Ljava/lang/Runnable;J)V
    .locals 3
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0, p2, p3}, Lcom/hjq/window/b0;->d(Ljava/lang/Runnable;Ljava/lang/Object;J)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public G0(II)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0x33

    const/4 v2, 0x4

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->H0(III)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1
.end method

.method public H(F)Lcom/hjq/window/j;
    .locals 4
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    move v3, v2

    cmpg-float v1, p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ltz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    cmpl-float v1, p1, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-gtz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput p1, v1, Landroid/view/WindowManager$LayoutParams;->dimAmount:F

    const/4 v3, 0x6

    cmpl-float p1, p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->c(I)Lcom/hjq/window/j;

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    and-int/2addr v3, v2

    const-string v0, "atmnote eautne wv le udn   mom aseba1b"

    const-string v0, "basm  vbmweemet  d n ael 1uetutanoa0 n"

    const/4 v3, 0x6

    const-string/jumbo v0, "lan0tbm  b ntuubdmaoee  tua even w ase"

    const-string v0, "amount must be a value between 0 and 1"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p1
.end method

.method public H0(III)Lcom/hjq/window/j;
    .locals 3
    .param p2    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(III)TX;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x3

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p3, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Lcom/hjq/window/e;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, p0}, Lcom/hjq/window/e;-><init>(Lcom/hjq/window/j;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->F(Ljava/lang/Runnable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public I(II)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/j;->J(ILandroid/graphics/drawable/Drawable;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1
.end method

.method public I0(FF)Lcom/hjq/window/j;
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/u0;
        .end annotation

        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/u0;
        .end annotation

        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FF)TX;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0x33

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->J0(IFF)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method

.method public J(ILandroid/graphics/drawable/Drawable;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/graphics/drawable/Drawable;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v1, 0x3

    return-object p0
.end method

.method public J0(IFF)Lcom/hjq/window/j;
    .locals 4
    .param p2    # F
        .annotation build Landroidx/annotation/u0;
        .end annotation

        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p3    # F
        .annotation build Landroidx/annotation/u0;
        .end annotation

        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IFF)TX;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p2, v0}, Ljava/lang/Math;->max(FF)F

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p2, v1}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p3, v0}, Ljava/lang/Math;->max(FF)F

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p3, v1}, Ljava/lang/Math;->min(FF)F

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v1, Landroid/util/DisplayMetrics;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v1}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v3, 0x3

    iget v0, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-float v0, v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    mul-float/2addr v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    float-to-int p2, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v0, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v2, 0x7

    move v3, v2

    int-to-float v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    mul-float/2addr v0, p3

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    float-to-int p3, v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/hjq/window/j;->H0(III)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p1
.end method

.method public K(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->format:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public K0(Landroid/view/WindowManager;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # Landroid/view/WindowManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/WindowManager;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public L(I)Lcom/hjq/window/j;
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x1f

    const/4 v3, 0x7

    if-lt v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lcom/hjq/window/a;->a(Landroid/view/WindowManager$LayoutParams;I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p1, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->z(I)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->c(I)Lcom/hjq/window/j;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public L0(Landroid/view/WindowManager$LayoutParams;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # Landroid/view/WindowManager$LayoutParams;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/WindowManager$LayoutParams;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public M(F)Lcom/hjq/window/j;
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = -1.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->buttonBrightness:F

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public M0(II)Lcom/hjq/window/j;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    if-lez v0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_4

    const/4 v5, 0x6

    iget v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v2, p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget v3, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eq v3, p2, :cond_4

    :cond_1
    const/4 v5, 0x0

    if-eq v2, p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput p1, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget p1, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq p1, p2, :cond_3

    const/4 v5, 0x5

    iput p2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p0
.end method

.method public N(I)Lcom/hjq/window/j;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p1}, Lcom/hjq/window/b;->a(Landroid/view/WindowManager$LayoutParams;I)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0
.end method

.method public N0(FF)Lcom/hjq/window/j;
    .locals 4
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FF)TX;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, v0}, Ljava/lang/Math;->max(FF)F

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1, v1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p2, v0}, Ljava/lang/Math;->max(FF)F

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p2, v1}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, -0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p1}, Lcom/hjq/window/j;->M0(II)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1

    :cond_0
    const/4 v3, 0x4

    new-instance v1, Landroid/util/DisplayMetrics;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v1}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    int-to-float v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    mul-float/2addr v0, p1

    const/4 v2, 0x4

    move v3, v2

    float-to-int p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    iget v0, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-float v0, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    mul-float/2addr v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    float-to-int p2, v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/j;->M0(II)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p1
.end method

.method public O(I)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/hjq/window/j;->P(ILcom/hjq/window/l;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public O0(Ljava/lang/String;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/hjq/window/j;->h:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public P(ILcom/hjq/window/l;)Lcom/hjq/window/j;
    .locals 5
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/l;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/hjq/window/l;",
            ")TX;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x4

    move v3, v2

    move v3, v2

    invoke-virtual {v0, p1, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p2, :cond_1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {p2, p0, v0, p1, v1}, Lcom/hjq/window/l;->a(Lcom/hjq/window/j;Landroid/view/View;ILandroid/view/ViewGroup;)V

    :cond_1
    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->Q(Landroid/view/View;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    return-object p1

    :cond_2
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    return-object p0
.end method

.method public P0(Ljava/lang/CharSequence;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")TX;"
        }
    .end annotation

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x1

    const-string p1, ""

    const-string p1, ""

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/view/WindowManager$LayoutParams;->setTitle(Ljava/lang/CharSequence;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public Q(Landroid/view/View;)Lcom/hjq/window/j;
    .locals 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")TX;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x2

    return-object p0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-lez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    instance-of v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x3

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v5, 0x7

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput v1, v0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    :cond_2
    const/4 v5, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v5, 0x7

    if-nez v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    instance-of v1, p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v1, v1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    if-eq v1, v2, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    instance-of v1, p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_4

    move-object v1, p1

    move-object v1, p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v1, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq v1, v2, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    :cond_4
    :goto_0
    const/4 v4, 0x5

    move v5, v4

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/16 v1, 0x11

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p1, :cond_7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, -0x2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ne v1, v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v3, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne v3, v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_1

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v1, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput v0, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    :cond_7
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object p0
.end method

.method public Q0(Landroid/os/IBinder;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/IBinder;",
            ")TX;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public R(II)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/j;->S(ILjava/lang/CharSequence;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public R0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x2

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return-object p0
.end method

.method public S(ILjava/lang/CharSequence;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/CharSequence;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-nez p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x1

    const-string p2, ""

    const-string p2, ""

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p1, Landroid/widget/TextView;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public S0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ne v0, p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-interface {v0, p0, p1}, Lcom/hjq/window/n;->a(Lcom/hjq/window/j;I)V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public T(II)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p1, Landroid/widget/TextView;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setHintTextColor(I)V

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public T0()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_8

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->Z0()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    instance-of v1, v0, Landroid/app/Activity;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast v0, Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_3

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_3
    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x3

    or-int/2addr v4, v3

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v0, p0, Lcom/hjq/window/j;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    int-to-long v0, v0

    const/4 v4, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->h(J)V

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Lcom/hjq/window/draggable/h;->R(Lcom/hjq/window/j;)V

    :cond_6
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    if-eqz v0, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0, p0}, Lcom/hjq/window/n;->d(Lcom/hjq/window/j;)V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/view/WindowManager$BadTokenException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :catch_1
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :catch_2
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :catch_3
    move-exception v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_7
    :goto_1
    const/4 v3, 0x2

    move v4, v3

    return-void

    :cond_8
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v1, "m doeruaaWn  o otwnPewaestpyimcavdbin"

    const-string/jumbo v1, "vrniotntipoa a mesbdmwPw onWeaa ce dy"

    const/4 v4, 0x1

    const-string/jumbo v1, "nayiamvp aWodmenit e srac pntewnwPbo "

    const-string v1, "WindowParams and view cannot be empty"

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    or-int/2addr v4, v3

    throw v0
.end method

.method public U(F)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->horizontalMargin:F

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public U0(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/16 v0, 0x50

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/hjq/window/j;->V0(Landroid/view/View;I)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public V(II)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/j;->W(ILandroid/graphics/drawable/Drawable;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1
.end method

.method public V0(Landroid/view/View;I)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2, v0, v0}, Lcom/hjq/window/j;->W0(Landroid/view/View;III)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public W(ILandroid/graphics/drawable/Drawable;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/graphics/drawable/Drawable;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p1, Landroid/widget/ImageView;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method public W0(Landroid/view/View;III)V
    .locals 8
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v0, :cond_9

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p2, v0}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result p2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v0, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-array v0, v0, [I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v1, Landroid/graphics/Rect;

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, v1}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const v3, 0x800033

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput v3, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget v4, v0, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget v5, v1, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    sub-int/2addr v4, v5

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/2addr v4, p3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v7, 0x3

    const/4 p3, 0x1

    const/4 v7, 0x4

    aget p3, v0, p3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v0, v1, Landroid/graphics/Rect;->top:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    sub-int/2addr p3, v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    add-int/2addr p3, p4

    const/4 v7, 0x6

    const/4 v6, 0x5

    iput p3, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    and-int/lit8 p3, p2, 0x3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 p4, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ne p3, p4, :cond_3

    const/4 v6, 0x6

    move v7, v6

    iget-object p3, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x1

    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    move-result p3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez p3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object p3, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p3}, Landroid/view/View;->getMeasuredWidth()I

    move-result p3

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-nez p3, :cond_2

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p3, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x1

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p3, p4, v0}, Landroid/view/View;->measure(II)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object p3, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p3}, Landroid/view/View;->getMeasuredWidth()I

    move-result p3

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object p4, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v0, p4, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    sub-int/2addr v0, p3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v0, p4, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    and-int/lit8 p3, p2, 0x5

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 p4, 0x5

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ne p3, p4, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    add-int/2addr v4, p3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    :cond_4
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    and-int/lit8 p3, p2, 0x30

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/16 p4, 0x30

    const/4 v7, 0x0

    if-ne p3, p4, :cond_7

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    if-nez p1, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-nez p1, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/view/View;->measure(II)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    :cond_6
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object p2, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget p3, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    sub-int/2addr p3, p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput p3, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :cond_7
    const/4 v6, 0x6

    const/4 v7, 0x6

    const/16 p3, 0x50

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    and-int/2addr p2, p3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-ne p2, p3, :cond_8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object p2, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v7, 0x2

    const/4 v6, 0x2

    iget p3, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    add-int/2addr p3, p1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput p3, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    :cond_8
    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->T0()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_9
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string p2, "deioWwecqmnnvnt bay n bmi Pos taraaep"

    const-string p2, " eaaibrnwo otpPnaanyi sbWcm wdeme tnv"

    const/4 v7, 0x6

    const-string/jumbo p2, "nnsa osPdeamowrwa bWi pd ye canmtneti"

    const-string p2, "WindowParams and view cannot be empty"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    throw p1
.end method

.method public X(I)Lcom/hjq/window/j;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x7

    or-int/2addr v3, v2

    const/16 v1, 0x1c

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/hjq/window/c;->a(Landroid/view/WindowManager$LayoutParams;I)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0
.end method

.method public X0(Landroid/content/Intent;)V
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    instance-of v0, v0, Landroid/app/Activity;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/high16 v0, 0x10000000

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_2
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public Y(Lcom/hjq/window/o;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Lcom/hjq/window/o;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/o<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1}, Lcom/hjq/window/j;->a0(Landroid/view/View;Lcom/hjq/window/o;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method public Y0(Ljava/lang/Class;)V
    .locals 4
    .param p1    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Landroid/app/Activity;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->X0(Landroid/content/Intent;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public Z(ILcom/hjq/window/o;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/o;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/hjq/window/o<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/hjq/window/j;->a0(Landroid/view/View;Lcom/hjq/window/o;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public Z0()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x4

    move v4, v3

    iget-object v0, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lcom/hjq/window/n;->c(Lcom/hjq/window/j;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v1, 0x0

    const/4 v0, 0x3

    if-nez p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/hjq/window/draggable/h;->J()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public b0(Lcom/hjq/window/p;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Lcom/hjq/window/p;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/p<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Lcom/hjq/window/j;->d0(Landroid/view/View;Lcom/hjq/window/p;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public c(I)Lcom/hjq/window/j;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    or-int/2addr p1, v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public c0(ILcom/hjq/window/p;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/p;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/hjq/window/p<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/hjq/window/j;->d0(Landroid/view/View;Lcom/hjq/window/p;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public d()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v3, 0x1

    and-int/2addr v4, v3

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v1, p0}, Lcom/hjq/window/n;->b(Lcom/hjq/window/j;)V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_2

    :catch_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :catch_1
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :catch_2
    move-exception v1

    :goto_0
    :try_start_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_1
    :goto_1
    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void

    :goto_2
    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/hjq/window/j;->f:Z

    const/4 v4, 0x4

    throw v1
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->m:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/hjq/window/b0;->a(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public e0(Lcom/hjq/window/q;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Lcom/hjq/window/q;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/q<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, v0, p1}, Lcom/hjq/window/j;->g0(Landroid/view/View;Lcom/hjq/window/q;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1
.end method

.method public f(Ljava/lang/Runnable;)V
    .locals 2
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/hjq/window/b0;->b(Ljava/lang/Runnable;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public f0(ILcom/hjq/window/q;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/q;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/hjq/window/q<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/hjq/window/j;->g0(Landroid/view/View;Lcom/hjq/window/q;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public g()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->h(J)V

    const/4 v3, 0x7

    return-void
.end method

.method public h(J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->o:Ljava/lang/Runnable;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->f(Ljava/lang/Runnable;)V

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->o:Ljava/lang/Runnable;

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->G(Ljava/lang/Runnable;J)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public h0(Lcom/hjq/window/s;)Lcom/hjq/window/j;
    .locals 3
    .param p1    # Lcom/hjq/window/s;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/s<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Lcom/hjq/window/j;->j0(Landroid/view/View;Lcom/hjq/window/s;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->j(J)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public i0(ILcom/hjq/window/s;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/s;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/hjq/window/s<",
            "+",
            "Landroid/view/View;",
            ">;)TX;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lcom/hjq/window/j;->j0(Landroid/view/View;Lcom/hjq/window/s;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public j(J)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->q:Ljava/lang/Runnable;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->f(Ljava/lang/Runnable;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->q:Ljava/lang/Runnable;

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->G(Ljava/lang/Runnable;J)V

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public k()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->l(J)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public k0(Lcom/hjq/window/n;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # Lcom/hjq/window/n;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/n;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/hjq/window/j;->k:Lcom/hjq/window/n;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public l(J)V
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->n:Ljava/lang/Runnable;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->f(Ljava/lang/Runnable;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->n:Ljava/lang/Runnable;

    const/4 v2, 0x1

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->G(Ljava/lang/Runnable;J)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public l0(Z)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)TX;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0x28

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->c(I)Lcom/hjq/window/j;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public m()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/hjq/window/j;->n(J)V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    return-void
.end method

.method public m0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->preferredDisplayModeId:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public n(J)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->p:Ljava/lang/Runnable;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/hjq/window/j;->f(Ljava/lang/Runnable;)V

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->p:Ljava/lang/Runnable;

    const/4 v2, 0x0

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/j;->G(Ljava/lang/Runnable;J)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public n0(F)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->preferredRefreshRate:F

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public o(I)Landroid/view/View;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Landroid/view/View;",
            ">(I)TV;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method

.method public o0(Landroid/view/ViewGroup;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/ViewGroup;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method public p()Landroid/view/View;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public p0(F)Lcom/hjq/window/j;
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = -1.0
            to = 1.0
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->screenBrightness:F

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public q()Landroid/content/Context;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public q0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->screenOrientation:I

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public r()Landroid/view/ViewGroup;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public r0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/16 p1, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->E(I)Lcom/hjq/window/j;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public s()Lcom/hjq/window/draggable/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->j:Lcom/hjq/window/draggable/h;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public s0(I)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TX;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->systemUiVisibility:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public t()Landroid/view/WindowManager;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/j;->d:Landroid/view/WindowManager;

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public t0(II)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->b:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/j;->u0(ILjava/lang/CharSequence;)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public u()Landroid/view/WindowManager$LayoutParams;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public u0(ILjava/lang/CharSequence;)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/CharSequence;",
            ")TX;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    if-nez p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x5

    const-string p2, ""

    const-string p2, ""

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p1, Landroid/widget/TextView;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v0, 0x0

    move v1, v0

    return-object p0
.end method

.method public v()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/hjq/window/j;->h:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public v0(II)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TX;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p1, Landroid/widget/TextView;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public w()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/j;->r()Landroid/view/ViewGroup;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public w0(IF)Lcom/hjq/window/j;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IF)TX;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0, p2}, Lcom/hjq/window/j;->x0(IIF)Lcom/hjq/window/j;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method

.method public x()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/hjq/window/j;->c:Landroid/view/ViewGroup;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 v0, 0x8

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public x0(IIF)Lcom/hjq/window/j;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IIF)TX;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/hjq/window/j;->o(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Landroid/widget/TextView;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/widget/TextView;->setTextSize(IF)V

    :cond_0
    const/4 v1, 0x2

    return-object p0
.end method

.method public y()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->r()Landroid/view/ViewGroup;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public y0(F)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v1, 0x7

    move v2, v1

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->verticalMargin:F

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public z(I)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    and-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method public z0(F)Lcom/hjq/window/j;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)TX;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/hjq/window/j;->e:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->verticalWeight:F

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/j;->m()V

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method
