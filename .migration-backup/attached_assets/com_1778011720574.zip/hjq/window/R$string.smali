.class public final Lcom/hjq/window/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/window/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f11040c

.field public static final abc_action_bar_up_description:I = 0x7f11040d

.field public static final abc_action_menu_overflow_description:I = 0x7f11040e

.field public static final abc_action_mode_done:I = 0x7f11040f

.field public static final abc_activity_chooser_view_see_all:I = 0x7f110410

.field public static final abc_activitychooserview_choose_application:I = 0x7f110411

.field public static final abc_capital_off:I = 0x7f110412

.field public static final abc_capital_on:I = 0x7f110413

.field public static final abc_search_hint:I = 0x7f11041e

.field public static final abc_searchview_description_clear:I = 0x7f11041f

.field public static final abc_searchview_description_query:I = 0x7f110420

.field public static final abc_searchview_description_search:I = 0x7f110421

.field public static final abc_searchview_description_submit:I = 0x7f110422

.field public static final abc_searchview_description_voice:I = 0x7f110423

.field public static final abc_shareactionprovider_share_with:I = 0x7f110424

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f110425

.field public static final abc_toolbar_collapse_description:I = 0x7f110426

.field public static final appbar_scrolling_view_behavior:I = 0x7f110458

.field public static final bottom_sheet_behavior:I = 0x7f110495

.field public static final character_counter_pattern:I = 0x7f1104bd

.field public static final password_toggle_content_description:I = 0x7f1108a5

.field public static final path_password_eye:I = 0x7f1108a6

.field public static final path_password_eye_mask_strike_through:I = 0x7f1108a7

.field public static final path_password_eye_mask_visible:I = 0x7f1108a8

.field public static final path_password_strike_through:I = 0x7f1108a9

.field public static final search_menu_title:I = 0x7f1109e8

.field public static final status_bar_notification_info_overflow:I = 0x7f110a56


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
