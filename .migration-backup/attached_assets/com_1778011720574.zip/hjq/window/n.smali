.class public interface abstract Lcom/hjq/window/n;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/hjq/window/j;I)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;I)V"
        }
    .end annotation
.end method

.method public abstract b(Lcom/hjq/window/j;)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;)V"
        }
    .end annotation
.end method

.method public abstract c(Lcom/hjq/window/j;)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;)V"
        }
    .end annotation
.end method

.method public abstract d(Lcom/hjq/window/j;)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;)V"
        }
    .end annotation
.end method

.method public abstract e(Lcom/hjq/window/j;)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;)V"
        }
    .end annotation
.end method
