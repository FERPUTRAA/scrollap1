.class public final synthetic Lcom/hjq/window/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/WindowManager$LayoutParams;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ys  oiv@~~ @@o/@~@~~~ u4i~ @c-@~f~~ ~@f    a @~@bdmt@@n ~o@~b.l@@irot sS~@~@ 1o ~o@M/lK~~b @@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/view/WindowManager$LayoutParams;->setColorMode(I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
