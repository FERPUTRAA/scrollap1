.class final Lcom/hjq/window/u;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ComponentCallbacks;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/hjq/window/u$a;
    }
.end annotation


# instance fields
.field private a:I

.field private b:Ljava/lang/ref/Reference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/u$a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/hjq/window/u;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method a(Landroid/content/Context;Lcom/hjq/window/u$a;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/u$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s S l~ @Mo@ ~@~@/f@~l  o~ @t~i/ ~ ~4ooos~n@-~~  dboa@@ b@tKm~ f~r~~~@.@@i@ ubiy@@~c~@~ @v  1@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/u;->b(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p1, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1, p0}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    :cond_2
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/hjq/window/u;->b:Ljava/lang/ref/Reference;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method b(Landroid/content/Context;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p0}, Landroid/content/Context;->unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    :cond_1
    const/4 v1, 0x2

    iget-object p1, p0, Lcom/hjq/window/u;->b:Ljava/lang/ref/Reference;

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p1, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->clear()V

    :cond_2
    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x4

    move v0, p1

    move v0, p1

    iput-object p1, p0, Lcom/hjq/window/u;->b:Ljava/lang/ref/Reference;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 3
    .param p1    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/hjq/window/u;->a:I

    const/4 v2, 0x5

    iget p1, p1, Landroid/content/res/Configuration;->orientation:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-ne v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lcom/hjq/window/u;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/hjq/window/u;->b:Ljava/lang/ref/Reference;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Lcom/hjq/window/u$a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez p1, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/hjq/window/u;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p1, v0}, Lcom/hjq/window/u$a;->a(I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onLowMemory()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method
