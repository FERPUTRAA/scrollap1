.class public final synthetic Lcom/hjq/window/draggable/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/DisplayCutout;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~sl~~co@~ b ovo~~~@@~-4 @~~@ f@ b/ @u1~sd~~~ l@ot@o@oit @ @nM~a  /i  ~@@b@~~@@~~~S~ K yf  @.r@m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/DisplayCutout;->getSafeInsetRight()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p0
.end method
