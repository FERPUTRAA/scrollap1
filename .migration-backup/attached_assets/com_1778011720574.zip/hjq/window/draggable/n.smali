.class public final synthetic Lcom/hjq/window/draggable/n;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/hjq/window/draggable/m$b;Lcom/hjq/window/j;Landroid/animation/Animator;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/animation/Animator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sr~u blo/@ bv4~m~  o@~~  -bni /~@~@~~@@c    M @o~So~@@t~@ ~~@ad~@l.~@~ @o@s@ff~~ o~~@ Ky1i@ti@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public static b(Lcom/hjq/window/draggable/m$b;Lcom/hjq/window/j;Landroid/animation/Animator;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/animation/Animator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method
