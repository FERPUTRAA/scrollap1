.class public abstract Lcom/hjq/window/draggable/h;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/hjq/window/draggable/h$b;
    }
.end annotation


# instance fields
.field private a:Lcom/hjq/window/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation
.end field

.field private b:Landroid/view/ViewGroup;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c:Z

.field private d:Lcom/hjq/window/draggable/h$b;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final e:Landroid/graphics/Rect;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:D

.field private m:Landroid/view/View;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/hjq/window/draggable/h;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/hjq/window/draggable/h;->e:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private synthetic F()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->O()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->N()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->M()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private synthetic G()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->O()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->N()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->M()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic a(Lcom/hjq/window/draggable/h;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/hjq/window/draggable/h;->G()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic b(Lcom/hjq/window/draggable/h;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/hjq/window/draggable/h;->F()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic c(Lcom/hjq/window/draggable/h;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p0, p0, Lcom/hjq/window/draggable/h;->f:I

    const/4 v0, 0x2

    move v1, v0

    return p0
.end method

.method static synthetic d(Lcom/hjq/window/draggable/h;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget p0, p0, Lcom/hjq/window/draggable/h;->g:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method public static q(Landroid/view/Window;)Landroid/graphics/Rect;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v1, 0x1c

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ge v0, v1, :cond_0

    const/4 v4, 0x5

    move v5, v4

    return-object v2

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p0}, Landroidx/core/view/l3;->a(Landroid/view/WindowInsets;)Landroid/view/DisplayCutout;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_2

    :cond_3
    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p0, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/hjq/window/draggable/a;->a(Landroid/view/DisplayCutout;)I

    move-result v0

    const/4 v4, 0x4

    move v5, v4

    invoke-static {p0}, Lcom/amar/library/ui/b;->a(Landroid/view/DisplayCutout;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/hjq/window/draggable/b;->a(Landroid/view/DisplayCutout;)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/hjq/window/draggable/c;->a(Landroid/view/DisplayCutout;)I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    new-instance v3, Landroid/graphics/Rect;

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v3, v0, v1, v2, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object v3

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    return-object v2
.end method


# virtual methods
.method protected A(FFFF)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->m()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    sub-float/2addr p1, p2

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    cmpl-float p1, p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-gez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    sub-float/2addr p3, p4

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    cmpl-float p1, p1, v0

    const/4 v1, 0x1

    move v2, v1

    if-ltz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x1

    move v2, p1

    :goto_1
    const/4 v1, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method public B()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method protected C()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/16 v1, 0x200

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/hjq/window/j;->z(I)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method public abstract D()Z
.end method

.method protected E(Landroid/view/View;)Z
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->isScrollContainer()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/draggable/h;->f(Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of v0, p1, Landroid/webkit/WebView;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_5

    const/4 v3, 0x1

    instance-of v0, p1, Landroid/widget/ScrollView;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    if-nez v0, :cond_5

    const/4 v2, 0x4

    move v3, v2

    instance-of v0, p1, Landroid/widget/ListView;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_5

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v0, p1, Landroid/widget/SeekBar;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v0, p1, Landroidx/core/view/t0;

    const/4 v2, 0x4

    move v3, v2

    if-nez v0, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of v0, p1, Landroidx/core/view/x0;

    const/4 v3, 0x7

    if-nez v0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v0, p1, Landroidx/viewpager/widget/ViewPager;

    const/4 v3, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v1, "w.siretepeowwgrPdavagra2xidgV.i2neeid"

    const-string v1, "androidx.viewpager2.widget.ViewPager2"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/hjq/window/draggable/h;->f(Landroid/view/View;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p1

    :catch_0
    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p1

    :cond_4
    :goto_0
    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/hjq/window/draggable/h;->f(Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p1

    :cond_5
    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/hjq/window/draggable/h;->f(Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return p1
.end method

.method public H(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getScrollX()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getScrollY()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    sub-int/2addr p1, p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    int-to-float p2, v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    int-to-float p1, p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p3, p2, p1}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public abstract I(Lcom/hjq/window/j;Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Landroid/view/ViewGroup;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation
.end method

.method public J()V
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->o()Landroid/view/ViewGroup;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    if-nez v0, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    return-void

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->B()Z

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    if-nez v1, :cond_2

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->l()Lcom/hjq/window/j;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-eqz v0, :cond_1

    const/4 v11, 0x1

    and-int/2addr v12, v11

    new-instance v1, Lcom/hjq/window/draggable/e;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-direct {v1, p0}, Lcom/hjq/window/draggable/e;-><init>(Lcom/hjq/window/draggable/h;)V

    const/4 v12, 0x5

    const/4 v11, 0x1

    const-wide/16 v2, 0x64

    const-wide/16 v2, 0x64

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lcom/hjq/window/j;->G(Ljava/lang/Runnable;J)V

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    return-void

    :cond_2
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget v2, p0, Lcom/hjq/window/draggable/h;->h:I

    iget v3, p0, Lcom/hjq/window/draggable/h;->j:I

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    sub-int/2addr v2, v3

    const/4 v12, 0x7

    iget v3, p0, Lcom/hjq/window/draggable/h;->i:I

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget v4, p0, Lcom/hjq/window/draggable/h;->k:I

    const/4 v11, 0x3

    move v12, v11

    sub-int/2addr v3, v4

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->m()F

    move-result v4

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    int-to-float v5, v2

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    cmpg-float v6, v5, v4

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/high16 v9, 0x40000000    # 2.0f

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    if-gtz v6, :cond_3

    const/4 v11, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    move v6, v10

    move v6, v10

    const/4 v12, 0x7

    move v6, v10

    move v6, v10

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    goto :goto_0

    :cond_3
    const/4 v12, 0x5

    const/4 v11, 0x4

    iget v6, p0, Lcom/hjq/window/draggable/h;->f:I

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    add-int/2addr v2, v7

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    sub-int/2addr v6, v2

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v2

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-float v2, v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    cmpg-float v2, v2, v4

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-gez v2, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    move v6, v8

    move v6, v8

    const/4 v12, 0x7

    move v6, v8

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    goto :goto_0

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    int-to-float v2, v7

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    div-float/2addr v2, v9

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    add-float/2addr v5, v2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v2, p0, Lcom/hjq/window/draggable/h;->f:I

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    int-to-float v2, v2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    div-float/2addr v5, v2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    move v6, v5

    move v6, v5

    const/4 v12, 0x5

    move v6, v5

    move v6, v5

    :goto_0
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-float v2, v3

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    cmpg-float v5, v2, v4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-gtz v5, :cond_5

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    move v8, v10

    move v8, v10

    const/4 v12, 0x6

    move v8, v10

    move v8, v10

    const/4 v11, 0x3

    or-int/2addr v12, v11

    goto :goto_1

    :cond_5
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget v5, p0, Lcom/hjq/window/draggable/h;->g:I

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    add-int/2addr v3, v1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    sub-int/2addr v5, v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    int-to-float v3, v3

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    cmpg-float v3, v3, v4

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-gez v3, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x3

    goto :goto_1

    :cond_6
    const/4 v12, 0x0

    int-to-float v1, v1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    div-float/2addr v1, v9

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    add-float/2addr v2, v1

    const/4 v12, 0x2

    const/4 v11, 0x1

    iget v1, p0, Lcom/hjq/window/draggable/h;->g:I

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-float v1, v1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    div-float/2addr v2, v1

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    move v8, v2

    move v8, v2

    const/4 v12, 0x2

    move v8, v2

    move v8, v2

    :goto_1
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    new-instance v1, Lcom/hjq/window/draggable/h$a;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-wide/16 v9, 0x64

    const-wide/16 v9, 0x64

    const/4 v12, 0x2

    const-wide/16 v9, 0x64

    const-wide/16 v9, 0x64

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct/range {v4 .. v10}, Lcom/hjq/window/draggable/h$a;-><init>(Lcom/hjq/window/draggable/h;FIFJ)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    const/4 v12, 0x2

    const/4 v11, 0x7

    return-void
.end method

.method protected K()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->O()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->N()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->M()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public L()V
    .locals 4

    const/4 v3, 0x3

    const/4 v0, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    iput-object v0, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public M()V
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->o()Landroid/view/ViewGroup;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-array v1, v1, [I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v3, 0x3

    const/4 v0, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    aget v0, v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/hjq/window/draggable/h;->h:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    aget v0, v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v0, p0, Lcom/hjq/window/draggable/h;->i:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public N()V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v8, 0x2

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/hjq/window/j;->t()Landroid/view/WindowManager;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-nez v0, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-void

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v1, Landroid/util/DisplayMetrics;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v1}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v7, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance v2, Landroid/graphics/Point;

    const/4 v7, 0x1

    move v8, v7

    invoke-direct {v2}, Landroid/graphics/Point;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v2}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget v0, v2, Landroid/graphics/Point;->x:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    int-to-float v0, v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget v3, v1, Landroid/util/DisplayMetrics;->xdpi:F

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    div-float/2addr v0, v3

    const/4 v8, 0x3

    iget v2, v2, Landroid/graphics/Point;->y:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    int-to-float v2, v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget v1, v1, Landroid/util/DisplayMetrics;->ydpi:F

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    div-float/2addr v2, v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    float-to-double v0, v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    const/4 v8, 0x3

    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    const-wide/high16 v3, 0x4000000000000000L    # 2.0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v0, v1, v3, v4}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    float-to-double v5, v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    add-double/2addr v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v0, v1}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput-wide v0, p0, Lcom/hjq/window/draggable/h;->l:D

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-void
.end method

.method public O()V
    .locals 5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/hjq/window/j;->q()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->o()Landroid/view/ViewGroup;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    instance-of v2, v0, Landroid/app/Activity;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast v0, Landroid/app/Activity;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->e:Landroid/graphics/Rect;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->e:Landroid/graphics/Rect;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v1, v0, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v2, v0, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    sub-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    iput v1, p0, Lcom/hjq/window/draggable/h;->f:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v1, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v0, v0, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x0

    sub-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v3, 0x2

    iput v1, p0, Lcom/hjq/window/draggable/h;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput v1, p0, Lcom/hjq/window/draggable/h;->j:I

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->e:Landroid/graphics/Rect;

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v1, v1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    iput v0, p0, Lcom/hjq/window/draggable/h;->k:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public P(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/hjq/window/draggable/h;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public Q(Lcom/hjq/window/draggable/h$b;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/hjq/window/draggable/h;->d:Lcom/hjq/window/draggable/h$b;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public R(Lcom/hjq/window/j;)V
    .locals 3
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/hjq/window/j;->r()Landroid/view/ViewGroup;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/hjq/window/draggable/d;

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/hjq/window/draggable/d;-><init>(Lcom/hjq/window/draggable/h;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public S(FF)V
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->z()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lcom/hjq/window/draggable/h;->T(FFZ)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public T(FFZ)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    float-to-int p1, p1

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    float-to-int p2, p2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lcom/hjq/window/draggable/h;->U(IIZ)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public U(IIZ)V
    .locals 8

    const/4 v6, 0x4

    move v7, v6

    if-eqz p3, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->V(II)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    return-void

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->p()Landroid/graphics/Rect;

    move-result-object p3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez p3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->V(II)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-void

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget v0, p3, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-lez v0, :cond_2

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    iget v0, p3, Landroid/graphics/Rect;->right:I

    const/4 v7, 0x2

    if-lez v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget v0, p3, Landroid/graphics/Rect;->top:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-lez v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget v0, p3, Landroid/graphics/Rect;->bottom:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lez v0, :cond_2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->V(II)V

    const/4 v6, 0x5

    const/4 v6, 0x4

    return-void

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->x()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->w()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->y()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->t()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget v4, p3, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->v()I

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    sub-int/2addr v4, v5

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ge p1, v4, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget p1, p3, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->v()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    sub-int/2addr p1, v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget v4, p3, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x0

    const/4 v6, 0x0

    sub-int v5, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    sub-int/2addr v5, v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    if-le p1, v5, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    sub-int/2addr v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    sub-int p1, v2, v0

    :cond_4
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget v0, p3, Landroid/graphics/Rect;->top:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->u()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    sub-int/2addr v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ge p2, v0, :cond_5

    const/4 v6, 0x4

    move v7, v6

    iget p2, p3, Landroid/graphics/Rect;->top:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->u()I

    move-result p3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    sub-int/2addr p2, p3

    const/4 v7, 0x6

    goto :goto_1

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget p3, p3, Landroid/graphics/Rect;->bottom:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    sub-int v0, v3, p3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    sub-int/2addr v0, v1

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-le p2, v0, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    sub-int/2addr v3, p3

    const/4 v6, 0x3

    move v7, v6

    sub-int p2, v3, v1

    :cond_6
    :goto_1
    const/4 v7, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->V(II)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method public V(II)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/hjq/window/j;->u()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/16 v2, 0x33

    if-ne v1, v2, :cond_1

    const/4 v4, 0x1

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne v1, p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ne v1, p2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/hjq/window/j;->Z0()V

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->M()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method protected e(Landroidx/recyclerview/widget/RecyclerView;)Z
    .locals 4
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$p;->canScrollVertically()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView$p;->canScrollHorizontally()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0
.end method

.method protected f(Landroid/view/View;)Z
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    instance-of v0, p1, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/hjq/window/draggable/h;->e(Landroidx/recyclerview/widget/RecyclerView;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/View;->isEnabled()Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method protected g()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->d:Lcom/hjq/window/draggable/h$b;

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v2, 0x3

    or-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v1, v0}, Lcom/hjq/window/draggable/h$b;->b(Lcom/hjq/window/j;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method protected h()V
    .locals 4

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->d:Lcom/hjq/window/draggable/h$b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x0

    invoke-interface {v1, v0}, Lcom/hjq/window/draggable/h$b;->c(Lcom/hjq/window/j;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method protected i()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->d:Lcom/hjq/window/draggable/h$b;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v1, v0}, Lcom/hjq/window/draggable/h$b;->a(Lcom/hjq/window/j;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public j(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/hjq/window/draggable/h;->H(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p2, p3}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method protected k(Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Landroid/view/View;
    .locals 12
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v1, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-ge v2, v0, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v4, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    new-array v4, v4, [I

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-virtual {v3, v4}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    aget v5, v4, v1

    const/4 v10, 0x3

    move v11, v10

    const/4 v6, 0x1

    xor-int/2addr v11, v6

    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    aget v4, v4, v6

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v6

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    add-int/2addr v6, v5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v7

    const/4 v11, 0x7

    const/4 v10, 0x1

    add-int/2addr v7, v4

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v8

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v9

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    int-to-float v5, v5

    const/4 v10, 0x1

    const/4 v10, 0x6

    cmpl-float v5, v8, v5

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-ltz v5, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    int-to-float v5, v6

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    cmpg-float v5, v8, v5

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-gtz v5, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    int-to-float v4, v4

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    cmpl-float v4, v9, v4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-ltz v4, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    int-to-float v4, v7

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    cmpg-float v4, v9, v4

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-gtz v4, :cond_1

    const/4 v11, 0x2

    invoke-virtual {p0, v3}, Lcom/hjq/window/draggable/h;->E(Landroid/view/View;)Z

    move-result v4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v4, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    return-object v3

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    instance-of v4, v3, Landroid/view/ViewGroup;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eqz v4, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    check-cast v3, Landroid/view/ViewGroup;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p0, v3, p2}, Lcom/hjq/window/draggable/h;->k(Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Landroid/view/View;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x7

    return-object p1

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 p1, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    return-object p1
.end method

.method public l()Lcom/hjq/window/j;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method protected m()F
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->n()D

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    cmpl-double v2, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-lez v2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-wide/high16 v4, 0x402e000000000000L    # 15.0

    const-wide/high16 v4, 0x402e000000000000L    # 15.0

    const/4 v7, 0x1

    const-wide/high16 v4, 0x402e000000000000L    # 15.0

    const-wide/high16 v4, 0x402e000000000000L    # 15.0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    div-double/2addr v0, v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    double-to-int v0, v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v0, v3

    move v0, v3

    const/4 v7, 0x3

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    int-to-float v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v3, v0, v1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    return v0
.end method

.method protected n()D
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-wide v0, p0, Lcom/hjq/window/draggable/h;->l:D

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-wide v0
.end method

.method public o()Landroid/view/ViewGroup;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_5

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    and-int/2addr v2, v1

    const/4 v3, 0x2

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p1, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eq p1, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/draggable/h;->j(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p1

    :cond_2
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0, p1, p2}, Lcom/hjq/window/draggable/h;->j(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->O()V

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->N()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->M()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->k(Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v1, p1, p2}, Lcom/hjq/window/draggable/h;->j(Landroid/view/View;Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v1, :cond_4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/hjq/window/draggable/h;->m:Landroid/view/View;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, p1, v0, p2}, Lcom/hjq/window/draggable/h;->I(Lcom/hjq/window/j;Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return p1

    :cond_5
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1
.end method

.method public p()Landroid/graphics/Rect;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    return-object v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/hjq/window/j;->q()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    instance-of v2, v0, Landroid/app/Activity;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v1

    :cond_1
    const/4 v4, 0x3

    check-cast v0, Landroid/app/Activity;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    return-object v1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/hjq/window/draggable/h;->q(Landroid/view/Window;)Landroid/graphics/Rect;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object v0
.end method

.method public r()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/hjq/window/draggable/h;->h:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public s()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/hjq/window/draggable/h;->i:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public t()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/hjq/window/draggable/h;->g:I

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public u()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/hjq/window/draggable/h;->k:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    return v0
.end method

.method public v()I
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/hjq/window/draggable/h;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public w()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/hjq/window/j;->w()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public x()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/draggable/h;->a:Lcom/hjq/window/j;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/hjq/window/j;->y()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public y()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/hjq/window/draggable/h;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public z()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/hjq/window/draggable/h;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method
