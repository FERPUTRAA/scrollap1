.class public final synthetic Lcom/hjq/window/draggable/g;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/draggable/h$a;

.field public final synthetic b:F

.field public final synthetic c:I

.field public final synthetic d:F

.field public final synthetic e:Landroid/view/View;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/draggable/h$a;FIFLandroid/view/View;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/hjq/window/draggable/g;->a:Lcom/hjq/window/draggable/h$a;

    const/4 v1, 0x4

    iput p2, p0, Lcom/hjq/window/draggable/g;->b:F

    iput p3, p0, Lcom/hjq/window/draggable/g;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p4, p0, Lcom/hjq/window/draggable/g;->d:F

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/hjq/window/draggable/g;->e:Landroid/view/View;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@4s ~ K@~/ @@b@- o~c ~y~@f@ @~r~l~t~~@@ S  f ~@. ol@~@ot@o@~b@~~~ ~ @i uim1 @M~ooa~~@v @ni~s~/ b"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/hjq/window/draggable/g;->a:Lcom/hjq/window/draggable/h$a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v1, p0, Lcom/hjq/window/draggable/g;->b:F

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v2, p0, Lcom/hjq/window/draggable/g;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v3, p0, Lcom/hjq/window/draggable/g;->d:F

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v4, p0, Lcom/hjq/window/draggable/g;->e:Landroid/view/View;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v1, v2, v3, v4}, Lcom/hjq/window/draggable/h$a;->a(Lcom/hjq/window/draggable/h$a;FIFLandroid/view/View;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method
