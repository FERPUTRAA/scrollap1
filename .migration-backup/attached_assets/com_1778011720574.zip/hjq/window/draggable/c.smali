.class public final synthetic Lcom/hjq/window/draggable/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/DisplayCutout;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s@is  o~  @l@ b~/@~itK@ ~~~oi~ ~@~v@ ~~ ~nr@@~-f1 m@@@@b~~ @~b@ac ~~ o~d~u@@ @f 4t/ M~yo~l@@.S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/DisplayCutout;->getSafeInsetBottom()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method
