.class Lcom/hjq/window/draggable/m$a;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hjq/window/draggable/m;->h0(FFJLandroid/animation/ValueAnimator$AnimatorUpdateListener;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/hjq/window/draggable/m;


# direct methods
.method constructor <init>(Lcom/hjq/window/draggable/m;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/hjq/window/draggable/m$a;->a:Lcom/hjq/window/draggable/m;

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ".~s~~~~~@@@ m~@@~l1~ir/tob bi@o S@@~K~~sd~ c@@ @Mt~  @@o4@@b ~@ ~~o@ ~@oul/~ ~ a@o@- f~f~  ni  v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/hjq/window/draggable/m$a;->a:Lcom/hjq/window/draggable/m;

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {v0, p1}, Lcom/hjq/window/draggable/m;->Z(Landroid/animation/Animator;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/draggable/m$a;->a:Lcom/hjq/window/draggable/m;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/hjq/window/draggable/m;->a0(Landroid/animation/Animator;)V

    const/4 v1, 0x6

    move v2, v1

    return-void
.end method
