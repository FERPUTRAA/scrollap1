.class public final synthetic Lcom/hjq/window/draggable/i;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/hjq/window/draggable/h$b;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i@sbi~o@s~@@y~ @ ~Ka~m~c~ @@ o b@@~@tfu~ v S~/@~ bo t~o/@i@~l@. r~~ @ol~d~~ @~~M  1o@n@@-  ~4~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method

.method public static b(Lcom/hjq/window/draggable/h$b;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static c(Lcom/hjq/window/draggable/h$b;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
