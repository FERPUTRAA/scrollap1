.class Lcom/hjq/window/draggable/h$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/hjq/window/draggable/h;->J()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:F

.field final synthetic b:I

.field final synthetic c:F

.field final synthetic d:J

.field final synthetic e:Lcom/hjq/window/draggable/h;


# direct methods
.method constructor <init>(Lcom/hjq/window/draggable/h;FIFJ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput p2, p0, Lcom/hjq/window/draggable/h$a;->a:F

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p3, p0, Lcom/hjq/window/draggable/h$a;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p4, p0, Lcom/hjq/window/draggable/h$a;->c:F

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-wide p5, p0, Lcom/hjq/window/draggable/h$a;->d:J

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic a(Lcom/hjq/window/draggable/h$a;FIFLandroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s@~4to@~~@u@ ~f oS~~ ~i @~@o m~ ~.@o t~ns @o ~@ lb i @1~d@b r @~l @~~Kiva@c@@o/-~My~~/  @@@b~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/hjq/window/draggable/h$a;->d(FIFLandroid/view/View;)V

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    return-void
.end method

.method public static synthetic b(Lcom/hjq/window/draggable/h$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/hjq/window/draggable/h$a;->c()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private synthetic c()V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/hjq/window/draggable/h;->K()V

    const/4 v2, 0x4

    return-void
.end method

.method private synthetic d(FIFLandroid/view/View;)V
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/hjq/window/draggable/h;->O()V

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/hjq/window/draggable/h;->N()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/hjq/window/draggable/h;->c(Lcom/hjq/window/draggable/h;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    int-to-float v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    mul-float/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    int-to-float p1, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/high16 p2, 0x40000000    # 2.0f

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    div-float/2addr p1, p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    sub-float/2addr v0, p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    float-to-int p2, v0

    const/4 v2, 0x2

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x6

    move v3, v2

    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/hjq/window/draggable/h;->d(Lcom/hjq/window/draggable/h;)I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    int-to-float v1, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    mul-float/2addr v1, p3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    sub-float/2addr v1, p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    float-to-int p1, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p3, p0, Lcom/hjq/window/draggable/h$a;->e:Lcom/hjq/window/draggable/h;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    int-to-float p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    int-to-float p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p3, p2, p1}, Lcom/hjq/window/draggable/h;->S(FF)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Lcom/hjq/window/draggable/f;

    const/4 v3, 0x3

    invoke-direct {p1, p0}, Lcom/hjq/window/draggable/f;-><init>(Lcom/hjq/window/draggable/h$a;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p4, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p4, p0, Lcom/hjq/window/draggable/h$a;->a:F

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p5, p0, Lcom/hjq/window/draggable/h$a;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget p6, p0, Lcom/hjq/window/draggable/h$a;->c:F

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    new-instance p8, Lcom/hjq/window/draggable/g;

    move-object p2, p8

    move-object p2, p8

    move-object p2, p8

    move-object p3, p0

    move-object p3, p0

    move-object p3, p0

    move-object p3, p0

    move-object p7, p1

    move-object p7, p1

    move-object p7, p1

    move-object p7, p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct/range {p2 .. p7}, Lcom/hjq/window/draggable/g;-><init>(Lcom/hjq/window/draggable/h$a;FIFLandroid/view/View;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-wide p2, p0, Lcom/hjq/window/draggable/h$a;->d:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1, p8, p2, p3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method
