.class public final synthetic Lcom/hjq/window/draggable/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/DisplayCutout;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s~ . m@ ~@oc@~id~~ubo@l@r ni1io~/~/ @~@f @~ K@a~ o@fols@4@~@@t~tv~@~~ ~b~ ~@ o  ~~bM @ ~-Sy@ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/DisplayCutout;->getSafeInsetLeft()I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0
.end method
