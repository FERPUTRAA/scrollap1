.class public final synthetic Lcom/hjq/window/draggable/f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/draggable/h$a;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/draggable/h$a;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    iput-object p1, p0, Lcom/hjq/window/draggable/f;->a:Lcom/hjq/window/draggable/h$a;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " /sbb @aof @~.~~~ @l@ of~~it~@~@~@~@@  -@yr~~@~~bo~ ~  u@to@@~o ms@ @ ~i@l@ov ~@/cn~~ 4~1 K@MdS "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/draggable/f;->a:Lcom/hjq/window/draggable/h$a;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/hjq/window/draggable/h$a;->b(Lcom/hjq/window/draggable/h$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method
