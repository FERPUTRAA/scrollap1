.class public final synthetic Lcom/hjq/window/draggable/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:Lcom/hjq/window/draggable/m;

.field public final synthetic b:F


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/draggable/m;F)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/hjq/window/draggable/k;->a:Lcom/hjq/window/draggable/m;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p2, p0, Lcom/hjq/window/draggable/k;->b:F

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@sbsi~uma@lK@@o bf~i~@@b  ~ -  @@ d@~ ~.  ~f@tl o~@r@~@  ~o~@i~/@~4@~~~t~oo1 vo@@~  @~~/c~MnS ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/hjq/window/draggable/k;->a:Lcom/hjq/window/draggable/m;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/hjq/window/draggable/k;->b:F

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-static {v0, v1, p1}, Lcom/hjq/window/draggable/m;->X(Lcom/hjq/window/draggable/m;FLandroid/animation/ValueAnimator;)V

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    return-void
.end method
