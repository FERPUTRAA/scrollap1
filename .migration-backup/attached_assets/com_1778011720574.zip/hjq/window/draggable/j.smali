.class public Lcom/hjq/window/draggable/j;
.super Lcom/hjq/window/draggable/h;


# instance fields
.field private n:F

.field private o:F

.field private p:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/hjq/window/draggable/h;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public D()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t@su ~@i~@~ @@~@~ s~  v~oba~o@@ S~ M l /~~@fct~ ~@  -fb~@@ omd  no.@~~i@@ /~~~@@Kl@~~@iry~o1 4o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public I(Lcom/hjq/window/j;Landroid/view/ViewGroup;Landroid/view/MotionEvent;)Z
    .locals 4
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Landroid/view/ViewGroup;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p2, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_5

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq p1, v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eq p1, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-eq p1, p3, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->v()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    int-to-float p2, p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    sub-float/2addr p1, p2

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getRawY()F

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->u()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    int-to-float v1, v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    sub-float/2addr p2, v1

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lcom/hjq/window/draggable/j;->n:F

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    sub-float/2addr p1, v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, p0, Lcom/hjq/window/draggable/j;->o:F

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    sub-float/2addr p2, v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->C()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p2, v1}, Ljava/lang/Math;->max(FF)F

    move-result p2

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/hjq/window/draggable/h;->S(FF)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-boolean p1, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->g()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget p1, p0, Lcom/hjq/window/draggable/j;->n:F

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v1, p0, Lcom/hjq/window/draggable/j;->o:F

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2, v1, p3}, Lcom/hjq/window/draggable/h;->A(FFFF)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p1, :cond_6

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->h()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-boolean p1, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/hjq/window/draggable/h;->i()V

    :cond_4
    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    iget-boolean p1, p0, Lcom/hjq/window/draggable/j;->p:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-boolean p2, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean p2, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw p1

    :cond_5
    const/4 v3, 0x1

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput p1, p0, Lcom/hjq/window/draggable/j;->n:F

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    iput p1, p0, Lcom/hjq/window/draggable/j;->o:F

    iput-boolean p2, p0, Lcom/hjq/window/draggable/j;->p:Z

    :cond_6
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-boolean p1, p0, Lcom/hjq/window/draggable/j;->p:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return p1
.end method
