.class public final synthetic Lcom/hjq/window/draggable/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/draggable/h;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/draggable/h;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/hjq/window/draggable/e;->a:Lcom/hjq/window/draggable/h;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bts@M~@~o-io~//~~~~b ~~@ i@  @o~@@dr@@ ~v~~ @l@1.iob mc~o @ n~ @@~Kf~@tf  @~o@S~~@  s4 ya @~@~u "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/draggable/e;->a:Lcom/hjq/window/draggable/h;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/hjq/window/draggable/h;->b(Lcom/hjq/window/draggable/h;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
