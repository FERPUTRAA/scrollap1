.class public final synthetic Lcom/hjq/window/draggable/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/draggable/h;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/draggable/h;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/hjq/window/draggable/d;->a:Lcom/hjq/window/draggable/h;

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@Ks  @~ ool~~f ~@@~@b~@o@/~b ya@b@@iotf~  @~~dv. io@@ c~ io~M@/ ~~s   1~~4- ~~l@Sn @r@~u~@@m~t~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/hjq/window/draggable/d;->a:Lcom/hjq/window/draggable/h;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {v0}, Lcom/hjq/window/draggable/h;->a(Lcom/hjq/window/draggable/h;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method
