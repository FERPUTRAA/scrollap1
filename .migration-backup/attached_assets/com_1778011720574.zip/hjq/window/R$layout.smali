.class public final Lcom/hjq/window/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/window/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final abc_action_bar_title_item:I = 0x7f0c0000

.field public static final abc_action_bar_up_container:I = 0x7f0c0001

.field public static final abc_action_menu_item_layout:I = 0x7f0c0002

.field public static final abc_action_menu_layout:I = 0x7f0c0003

.field public static final abc_action_mode_bar:I = 0x7f0c0004

.field public static final abc_action_mode_close_item_material:I = 0x7f0c0005

.field public static final abc_activity_chooser_view:I = 0x7f0c0006

.field public static final abc_activity_chooser_view_list_item:I = 0x7f0c0007

.field public static final abc_alert_dialog_button_bar_material:I = 0x7f0c0008

.field public static final abc_alert_dialog_material:I = 0x7f0c0009

.field public static final abc_alert_dialog_title_material:I = 0x7f0c000a

.field public static final abc_dialog_title_material:I = 0x7f0c000c

.field public static final abc_expanded_menu_layout:I = 0x7f0c000d

.field public static final abc_list_menu_item_checkbox:I = 0x7f0c000e

.field public static final abc_list_menu_item_icon:I = 0x7f0c000f

.field public static final abc_list_menu_item_layout:I = 0x7f0c0010

.field public static final abc_list_menu_item_radio:I = 0x7f0c0011

.field public static final abc_popup_menu_header_item_layout:I = 0x7f0c0012

.field public static final abc_popup_menu_item_layout:I = 0x7f0c0013

.field public static final abc_screen_content_include:I = 0x7f0c0014

.field public static final abc_screen_simple:I = 0x7f0c0015

.field public static final abc_screen_simple_overlay_action_mode:I = 0x7f0c0016

.field public static final abc_screen_toolbar:I = 0x7f0c0017

.field public static final abc_search_dropdown_item_icons_2line:I = 0x7f0c0018

.field public static final abc_search_view:I = 0x7f0c0019

.field public static final abc_select_dialog_material:I = 0x7f0c001a

.field public static final design_bottom_navigation_item:I = 0x7f0c008a

.field public static final design_bottom_sheet_dialog:I = 0x7f0c008b

.field public static final design_layout_snackbar:I = 0x7f0c008c

.field public static final design_layout_snackbar_include:I = 0x7f0c008d

.field public static final design_layout_tab_icon:I = 0x7f0c008e

.field public static final design_layout_tab_text:I = 0x7f0c008f

.field public static final design_menu_item_action_area:I = 0x7f0c0090

.field public static final design_navigation_item:I = 0x7f0c0091

.field public static final design_navigation_item_header:I = 0x7f0c0092

.field public static final design_navigation_item_separator:I = 0x7f0c0093

.field public static final design_navigation_item_subheader:I = 0x7f0c0094

.field public static final design_navigation_menu:I = 0x7f0c0095

.field public static final design_navigation_menu_item:I = 0x7f0c0096

.field public static final notification_action:I = 0x7f0c0215

.field public static final notification_action_tombstone:I = 0x7f0c0216

.field public static final notification_media_action:I = 0x7f0c0217

.field public static final notification_media_cancel_action:I = 0x7f0c0218

.field public static final notification_template_big_media:I = 0x7f0c0219

.field public static final notification_template_big_media_custom:I = 0x7f0c021a

.field public static final notification_template_big_media_narrow:I = 0x7f0c021b

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0c021c

.field public static final notification_template_custom_big:I = 0x7f0c021d

.field public static final notification_template_icon_group:I = 0x7f0c021e

.field public static final notification_template_lines_media:I = 0x7f0c021f

.field public static final notification_template_media:I = 0x7f0c0220

.field public static final notification_template_media_custom:I = 0x7f0c0221

.field public static final notification_template_part_chronometer:I = 0x7f0c0222

.field public static final notification_template_part_time:I = 0x7f0c0223

.field public static final select_dialog_item_material:I = 0x7f0c0259

.field public static final select_dialog_multichoice_material:I = 0x7f0c025a

.field public static final select_dialog_singlechoice_material:I = 0x7f0c025b

.field public static final support_simple_spinner_dropdown_item:I = 0x7f0c0260


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
