.class public final Lcom/hjq/window/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/hjq/window/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action0:I = 0x7f090043

.field public static final action_bar:I = 0x7f09004b

.field public static final action_bar_activity_content:I = 0x7f09004c

.field public static final action_bar_container:I = 0x7f09004d

.field public static final action_bar_root:I = 0x7f09004e

.field public static final action_bar_spinner:I = 0x7f09004f

.field public static final action_bar_subtitle:I = 0x7f090050

.field public static final action_bar_title:I = 0x7f090051

.field public static final action_container:I = 0x7f090052

.field public static final action_context_bar:I = 0x7f090053

.field public static final action_divider:I = 0x7f090054

.field public static final action_image:I = 0x7f090055

.field public static final action_menu_divider:I = 0x7f090056

.field public static final action_menu_presenter:I = 0x7f090057

.field public static final action_mode_bar:I = 0x7f090058

.field public static final action_mode_bar_stub:I = 0x7f090059

.field public static final action_mode_close_button:I = 0x7f09005a

.field public static final action_text:I = 0x7f09005b

.field public static final actions:I = 0x7f09005d

.field public static final activity_chooser_view_content:I = 0x7f09005f

.field public static final add:I = 0x7f090061

.field public static final alertTitle:I = 0x7f090071

.field public static final async:I = 0x7f090082

.field public static final auto:I = 0x7f090083

.field public static final blocking:I = 0x7f0900b8

.field public static final bottom:I = 0x7f0900bb

.field public static final buttonPanel:I = 0x7f090133

.field public static final cancel_action:I = 0x7f09013a

.field public static final center:I = 0x7f090143

.field public static final checkbox:I = 0x7f090155

.field public static final chronometer:I = 0x7f090161

.field public static final container:I = 0x7f0901b3

.field public static final contentPanel:I = 0x7f0901b7

.field public static final coordinator:I = 0x7f0901be

.field public static final custom:I = 0x7f0901de

.field public static final customPanel:I = 0x7f0901df

.field public static final decor_content_parent:I = 0x7f0901f9

.field public static final default_activity_button:I = 0x7f0901fb

.field public static final design_bottom_sheet:I = 0x7f090201

.field public static final design_menu_item_action_area:I = 0x7f090202

.field public static final design_menu_item_action_area_stub:I = 0x7f090203

.field public static final design_menu_item_text:I = 0x7f090204

.field public static final design_navigation_view:I = 0x7f090205

.field public static final edit_query:I = 0x7f090247

.field public static final end:I = 0x7f09025f

.field public static final end_padder:I = 0x7f090261

.field public static final expand_activities_button:I = 0x7f090280

.field public static final expanded_menu:I = 0x7f090281

.field public static final fill:I = 0x7f090286

.field public static final fixed:I = 0x7f090291

.field public static final forever:I = 0x7f0902a7

.field public static final ghost_view:I = 0x7f0902c6

.field public static final home:I = 0x7f090307

.field public static final icon:I = 0x7f090318

.field public static final icon_group:I = 0x7f09031a

.field public static final image:I = 0x7f09031f

.field public static final info:I = 0x7f090385

.field public static final italic:I = 0x7f090391

.field public static final item_touch_helper_previous_elevation:I = 0x7f09039e

.field public static final left:I = 0x7f0904db

.field public static final line1:I = 0x7f0904ef

.field public static final line3:I = 0x7f0904f1

.field public static final listMode:I = 0x7f0904fb

.field public static final list_item:I = 0x7f0904fd

.field public static final masked:I = 0x7f090594

.field public static final media_actions:I = 0x7f0905ab

.field public static final message:I = 0x7f0905b3

.field public static final mini:I = 0x7f0905bc

.field public static final multiply:I = 0x7f0905e3

.field public static final navigation_header_container:I = 0x7f0905ee

.field public static final none:I = 0x7f0905fe

.field public static final normal:I = 0x7f0905ff

.field public static final notification_background:I = 0x7f090602

.field public static final notification_main_column:I = 0x7f090603

.field public static final notification_main_column_container:I = 0x7f090604

.field public static final parallax:I = 0x7f090644

.field public static final parentPanel:I = 0x7f090646

.field public static final parent_matrix:I = 0x7f090648

.field public static final pin:I = 0x7f090664

.field public static final progress_circular:I = 0x7f090687

.field public static final progress_horizontal:I = 0x7f090688

.field public static final radio:I = 0x7f0906aa

.field public static final right:I = 0x7f0906c8

.field public static final right_icon:I = 0x7f0906ca

.field public static final right_side:I = 0x7f0906cb

.field public static final save_non_transition_alpha:I = 0x7f090702

.field public static final screen:I = 0x7f090709

.field public static final scrollIndicatorDown:I = 0x7f09070b

.field public static final scrollIndicatorUp:I = 0x7f09070c

.field public static final scrollView:I = 0x7f09070d

.field public static final scrollable:I = 0x7f090710

.field public static final search_badge:I = 0x7f090713

.field public static final search_bar:I = 0x7f090714

.field public static final search_button:I = 0x7f090715

.field public static final search_close_btn:I = 0x7f090716

.field public static final search_edit_frame:I = 0x7f090718

.field public static final search_go_btn:I = 0x7f090719

.field public static final search_mag_icon:I = 0x7f09071a

.field public static final search_plate:I = 0x7f09071b

.field public static final search_src_text:I = 0x7f09071c

.field public static final search_voice_btn:I = 0x7f09071d

.field public static final select_dialog_listview:I = 0x7f090727

.field public static final shortcut:I = 0x7f090737

.field public static final snackbar_action:I = 0x7f090744

.field public static final snackbar_text:I = 0x7f090745

.field public static final spacer:I = 0x7f090752

.field public static final split_action_bar:I = 0x7f090756

.field public static final src_atop:I = 0x7f09075b

.field public static final src_in:I = 0x7f09075c

.field public static final src_over:I = 0x7f09075d

.field public static final start:I = 0x7f090768

.field public static final status_bar_latest_event_content:I = 0x7f090775

.field public static final submenuarrow:I = 0x7f090778

.field public static final submit_area:I = 0x7f09077b

.field public static final tabMode:I = 0x7f09079c

.field public static final text:I = 0x7f0907b7

.field public static final text2:I = 0x7f0907ba

.field public static final textSpacerNoButtons:I = 0x7f0907c0

.field public static final textSpacerNoTitle:I = 0x7f0907c1

.field public static final textinput_counter:I = 0x7f090825

.field public static final textinput_error:I = 0x7f090826

.field public static final time:I = 0x7f09082f

.field public static final title:I = 0x7f090834

.field public static final titleDividerNoCustom:I = 0x7f090836

.field public static final title_template:I = 0x7f09083d

.field public static final top:I = 0x7f090845

.field public static final topPanel:I = 0x7f090846

.field public static final touch_outside:I = 0x7f090852

.field public static final transition_current_scene:I = 0x7f090859

.field public static final transition_layout_save:I = 0x7f09085a

.field public static final transition_position:I = 0x7f09085b

.field public static final transition_scene_layoutid_cache:I = 0x7f09085c

.field public static final transition_transform:I = 0x7f09085d

.field public static final uniform:I = 0x7f090a89

.field public static final up:I = 0x7f090a8c

.field public static final view_offset_helper:I = 0x7f090abc

.field public static final visible:I = 0x7f090ac6

.field public static final wrap_content:I = 0x7f090aed


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
