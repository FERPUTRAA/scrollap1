.class public final synthetic Lcom/hjq/window/f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/j;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/j;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/hjq/window/f;->a:Lcom/hjq/window/j;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osl  ~io@/@ Ss@M@ ~ o~i@urd~ @ob~-@~ @~. /@o~@f @ct@ai@b~b~nl ~~K~~~@@  ~~ ~v@4~ @of~ m1 @@@yt "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/f;->a:Lcom/hjq/window/j;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/hjq/window/j;->T0()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
