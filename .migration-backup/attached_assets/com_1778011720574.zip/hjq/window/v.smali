.class final Lcom/hjq/window/v;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final a:Lcom/hjq/window/j;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation
.end field

.field private final b:Lcom/hjq/window/o;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/hjq/window/j;Lcom/hjq/window/o;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Lcom/hjq/window/o;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/hjq/window/v;->a:Lcom/hjq/window/j;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/hjq/window/v;->b:Lcom/hjq/window/o;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bis~~f1~@ @~@S@b/Ko~~/a ou M~@l @-~o~@ ~@ i ~ ~ @t ~ol@cy ~@@o@@4@ f@@i~m@ @ d t~n~r~~ ~o@b.v~s~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/hjq/window/v;->b:Lcom/hjq/window/o;

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/hjq/window/v;->a:Lcom/hjq/window/j;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, v1, p1}, Lcom/hjq/window/o;->a(Lcom/hjq/window/j;Landroid/view/View;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method
