.class public final synthetic Lcom/hjq/window/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/WindowManager$LayoutParams;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Ssl f@ @  / K@~@ y~i~l~v~~~/t @@@@bbn@ r~d~1- Mm o~ @@@  .~~oo@iou~fo~4c@@~~~t@i@a ~s~~~@o@  b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroid/view/WindowManager$LayoutParams;->setBlurBehindRadius(I)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method
