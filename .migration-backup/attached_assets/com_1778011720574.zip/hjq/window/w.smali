.class final Lcom/hjq/window/w;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnKeyListener;


# instance fields
.field private final a:Lcom/hjq/window/j;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation
.end field

.field private final b:Lcom/hjq/window/p;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/hjq/window/j;Lcom/hjq/window/p;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/hjq/window/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Lcom/hjq/window/p;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/hjq/window/w;->a:Lcom/hjq/window/j;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/hjq/window/w;->b:Lcom/hjq/window/p;

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~o l. Mitv~~ 1m @@lr @@~t @y f~~bs~/~@n~d b~o a 4  u@~o@o@o-@@~~@c~S@ ~~io @ ~@bif@@@~/~@~  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/hjq/window/w;->b:Lcom/hjq/window/p;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/hjq/window/w;->a:Lcom/hjq/window/j;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0, v1, p1, p3, p2}, Lcom/hjq/window/p;->a(Lcom/hjq/window/j;Landroid/view/View;Landroid/view/KeyEvent;I)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    return p1
.end method
