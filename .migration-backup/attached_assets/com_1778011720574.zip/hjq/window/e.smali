.class public final synthetic Lcom/hjq/window/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/j;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/j;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/hjq/window/e;->a:Lcom/hjq/window/j;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os~v~ n~@bt~ /@buo@ c~~~@~ @ ~do@~@m@.fiSo@~/ 4@~@~Ka@~  ~lt ~@l @1r@ - i@f~  ~b@y~~i@@oos~  M@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/hjq/window/e;->a:Lcom/hjq/window/j;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/hjq/window/j;->b(Lcom/hjq/window/j;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
