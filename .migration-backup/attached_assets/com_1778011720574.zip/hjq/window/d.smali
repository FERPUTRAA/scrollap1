.class public final synthetic Lcom/hjq/window/d;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/WindowManager$LayoutParams;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s ~@~~@~@1 @t  uto@~/b~~odriom~~i ~-f  ~~~@@@ @lsnabSl @~.@~ @~~@@of ~@~@@~Myo /~@c@oKv@bi   ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget p0, p0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method
