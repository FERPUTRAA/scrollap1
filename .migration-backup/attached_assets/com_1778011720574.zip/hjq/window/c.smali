.class public final synthetic Lcom/hjq/window/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/WindowManager$LayoutParams;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " Ss@i  @t~t @@ob@@M.v  ~  lic ~~bis@~@~ol~@d@r~u~ ~a@~@ ~fy@~~~o@ @@~ /4  -~1o~ mK~ n@/~~@@@o~fb"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput p1, p0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
