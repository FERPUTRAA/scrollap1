.class public final Lcom/hjq/window/k;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/List;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object v0, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static declared-synchronized a(Ljava/lang/ref/Reference;)V
    .locals 4
    .param p0    # Ljava/lang/ref/Reference;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s~c@oo~f.@~~@@ ~a  M~o~4 K~~ / @~@ t ~/bb~ r ~@ S@@@isf 1n~d@ @@~o @~ i~~ubmtl~i-@@~@vy @~l~oo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v3, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v1, Lcom/hjq/window/j;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method public static declared-synchronized b()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x7

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Lcom/hjq/window/j;

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v2}, Lcom/hjq/window/j;->d()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    move v4, v3

    monitor-exit v0

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw v1
.end method

.method public static declared-synchronized c(Ljava/lang/Class;)V
    .locals 6
    .param p0    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Lcom/hjq/window/j<",
            "*>;>;)V"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    monitor-enter v0

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    if-nez p0, :cond_0

    const/4 v4, 0x0

    move v5, v4

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x1

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v2, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast v2, Lcom/hjq/window/j;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v3, :cond_3

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/hjq/window/j;->d()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    goto :goto_0

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p0
.end method

.method public static declared-synchronized d(Ljava/lang/String;)V
    .locals 6
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x6

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x6

    move v5, v4

    monitor-enter v0

    if-nez p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v2, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast v2, Lcom/hjq/window/j;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/hjq/window/j;->v()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v3, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/hjq/window/j;->d()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    throw p0
.end method

.method public static declared-synchronized e()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v2, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v2, Lcom/hjq/window/j;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2}, Lcom/hjq/window/j;->B()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x5

    return v0

    :cond_3
    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x7

    throw v1
.end method

.method public static declared-synchronized f(Ljava/lang/Class;)Z
    .locals 7
    .param p0    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Lcom/hjq/window/j<",
            "*>;>;)Z"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x6

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x3

    const/4 v5, 0x4

    monitor-enter v0

    const/4 v6, 0x4

    const/4 v1, 0x5

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v1

    :cond_0
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object v2, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x0

    move v6, v5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v3, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/ref/Reference;

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-nez v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast v3, Lcom/hjq/window/j;

    const/4 v6, 0x4

    if-nez v3, :cond_3

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v4, :cond_4

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/hjq/window/j;->B()Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 p0, 0x1

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    return p0

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x5

    return v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p0
.end method

.method public static declared-synchronized g(Ljava/lang/String;)Z
    .locals 7
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x1

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-enter v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez p0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x1

    return v1

    :cond_0
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v2, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x4

    and-int/2addr v6, v5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v3, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/ref/Reference;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    check-cast v3, Lcom/hjq/window/j;

    const/4 v5, 0x1

    shr-int/2addr v6, v5

    if-nez v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/hjq/window/j;->v()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v4, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_0

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/hjq/window/j;->B()Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 p0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    return p0

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    return v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    throw p0
.end method

.method public static declared-synchronized h(Ljava/lang/Class;)Lcom/hjq/window/j;
    .locals 7
    .param p0    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<X:",
            "Lcom/hjq/window/j<",
            "*>;>(",
            "Ljava/lang/Class<",
            "TX;>;)TX;"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    monitor-enter v0

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez p0, :cond_0

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v1

    :cond_0
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    sget-object v2, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v3, Ljava/lang/ref/Reference;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v3, Lcom/hjq/window/j;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v4, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object v3

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x0

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    throw p0
.end method

.method public static declared-synchronized i(Ljava/lang/String;)Lcom/hjq/window/j;
    .locals 7
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/hjq/window/j<",
            "*>;"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x1

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-enter v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    if-nez p0, :cond_0

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    return-object v1

    :cond_0
    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    sget-object v2, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v3, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    check-cast v3, Ljava/lang/ref/Reference;

    const/4 v6, 0x7

    if-nez v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v3, Lcom/hjq/window/j;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v3}, Lcom/hjq/window/j;->v()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v4, :cond_3

    const/4 v6, 0x4

    goto :goto_0

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x4

    return-object v3

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    throw p0
.end method

.method public static declared-synchronized j()Ljava/util/List;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/hjq/window/j<",
            "*>;>;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x0

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    sget-object v2, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v3, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v3, Ljava/lang/ref/Reference;

    const/4 v5, 0x5

    const/4 v4, 0x1

    if-nez v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v3, Lcom/hjq/window/j;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v3, :cond_1

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    throw v1
.end method

.method public static declared-synchronized k()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v2, Lcom/hjq/window/j;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v4, 0x0

    invoke-virtual {v2}, Lcom/hjq/window/j;->D()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw v1
.end method

.method public static declared-synchronized l(Ljava/lang/Class;)V
    .locals 6
    .param p0    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Lcom/hjq/window/j<",
            "*>;>;)V"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x4

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-enter v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v4, 0x0

    move v5, v4

    if-nez v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v2, Lcom/hjq/window/j;

    const/4 v5, 0x0

    if-nez v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-nez v3, :cond_3

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/hjq/window/j;->D()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    throw p0
.end method

.method public static declared-synchronized m(Ljava/lang/String;)V
    .locals 6
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x5

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    monitor-enter v0

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    if-nez p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v2, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v4, 0x3

    move v5, v4

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast v2, Lcom/hjq/window/j;

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    if-nez v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/hjq/window/j;->v()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v2}, Lcom/hjq/window/j;->D()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_4
    const/4 v4, 0x4

    move v5, v4

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw p0
.end method

.method static declared-synchronized n(Ljava/lang/ref/Reference;)V
    .locals 4
    .param p0    # Ljava/lang/ref/Reference;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v3, 0x7

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v3, 0x7

    const/4 v2, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->clear()V

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v1, p0}, Ljava/util/List;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw p0
.end method

.method public static declared-synchronized o()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x6

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast v2, Lcom/hjq/window/j;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v2, :cond_1

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/hjq/window/j;->T0()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    throw v1
.end method

.method public static declared-synchronized p(Ljava/lang/Class;)V
    .locals 6
    .param p0    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Lcom/hjq/window/j<",
            "*>;>;)V"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-class v0, Lcom/hjq/window/k;

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x4

    const-class v0, Lcom/hjq/window/k;

    const/4 v4, 0x1

    move v5, v4

    monitor-enter v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v2, :cond_1

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast v2, Lcom/hjq/window/j;

    const/4 v5, 0x1

    if-nez v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v3, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/hjq/window/j;->T0()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw p0
.end method

.method public static declared-synchronized q(Ljava/lang/String;)V
    .locals 6
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-class v0, Lcom/hjq/window/k;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    monitor-enter v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v1, Lcom/hjq/window/k;->a:Ljava/util/List;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v2, :cond_4

    const/4 v4, 0x0

    move v5, v4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    check-cast v2, Ljava/lang/ref/Reference;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v2, :cond_1

    const/4 v4, 0x6

    and-int/2addr v5, v4

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    check-cast v2, Lcom/hjq/window/j;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v2, :cond_2

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/hjq/window/j;->v()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-nez v3, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v2}, Lcom/hjq/window/j;->T0()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    throw p0
.end method
