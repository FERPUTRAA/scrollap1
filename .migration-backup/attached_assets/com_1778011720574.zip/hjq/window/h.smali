.class public final synthetic Lcom/hjq/window/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hjq/window/j;


# direct methods
.method public synthetic constructor <init>(Lcom/hjq/window/j;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/hjq/window/h;->a:Lcom/hjq/window/j;

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ns @M@   t@~K~~v@i1@So~~t~ d ~@@~~~~l b@mof~sc/~  @o/~l ~@4~o@o@@ioy~b@iu  @~ ~ . @a~@~ @~ fr-@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/h;->a:Lcom/hjq/window/j;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/hjq/window/j;->Z0()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method
