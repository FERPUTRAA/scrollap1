.class public final Lcom/hjq/window/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/hjq/window/R$anim;,
        Lcom/hjq/window/R$animator;,
        Lcom/hjq/window/R$attr;,
        Lcom/hjq/window/R$bool;,
        Lcom/hjq/window/R$color;,
        Lcom/hjq/window/R$dimen;,
        Lcom/hjq/window/R$drawable;,
        Lcom/hjq/window/R$id;,
        Lcom/hjq/window/R$integer;,
        Lcom/hjq/window/R$layout;,
        Lcom/hjq/window/R$string;,
        Lcom/hjq/window/R$style;,
        Lcom/hjq/window/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
