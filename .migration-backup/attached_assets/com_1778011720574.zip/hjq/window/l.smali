.class public interface abstract Lcom/hjq/window/l;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lcom/hjq/window/j;Landroid/view/View;ILandroid/view/ViewGroup;)V
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param
    .param p4    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/hjq/window/j<",
            "*>;",
            "Landroid/view/View;",
            "I",
            "Landroid/view/ViewGroup;",
            ")V"
        }
    .end annotation
.end method
