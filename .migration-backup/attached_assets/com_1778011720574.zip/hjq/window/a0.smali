.class final Lcom/hjq/window/a0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# instance fields
.field private a:Landroid/app/Activity;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private b:Ljava/lang/ref/Reference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/ref/Reference;Landroid/app/Activity;)V
    .locals 2
    .param p1    # Ljava/lang/ref/Reference;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/ref/Reference<",
            "Lcom/hjq/window/j<",
            "*>;>;",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/hjq/window/a0;->b:Ljava/lang/ref/Reference;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s~ o t. ~v~tK~ @o4~cy@@s~l@oo@ i@~@b~~~ @ib ~n~/~@o~um~@~@df@@@@  -~ @@ ~Mi  /@fbao ~ 1@l S~~r"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/16 v2, 0x1d

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-lt v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0, p0}, Landroidx/lifecycle/a1;->a(Landroid/app/Activity;Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method b()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/16 v2, 0x1d

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-lt v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0, p0}, Lcom/hjq/window/z;->a(Landroid/app/Activity;Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v3, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :goto_0
    const/4 v4, 0x6

    return-void
.end method

.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v1, 0x1

    move v2, v1

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/hjq/window/a0;->b:Ljava/lang/ref/Reference;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast v0, Lcom/hjq/window/j;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_2

    const/4 v2, 0x7

    return-void

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/hjq/window/j;->D()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/hjq/window/a0;->b:Ljava/lang/ref/Reference;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/hjq/window/a0;->a:Landroid/app/Activity;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-ne v0, p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/hjq/window/a0;->b:Ljava/lang/ref/Reference;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p1, :cond_1

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p1, Lcom/hjq/window/j;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez p1, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :cond_2
    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/hjq/window/j;->B()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/hjq/window/j;->d()V

    :cond_4
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
