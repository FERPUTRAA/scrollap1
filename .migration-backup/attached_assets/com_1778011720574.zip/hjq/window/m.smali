.class public final synthetic Lcom/hjq/window/m;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/hjq/window/n;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ son~~ 4/~ @ ~~c~~i~o@@mof@@ @t S o do@-iK~~@  t@us ~@@l@ ~lb.~bbv@@@ @ir@f@~~~1~/ ~~@M ~ao@ y "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    return-void
.end method

.method public static b(Lcom/hjq/window/n;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static c(Lcom/hjq/window/n;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static d(Lcom/hjq/window/n;Lcom/hjq/window/j;)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public static e(Lcom/hjq/window/n;Lcom/hjq/window/j;I)V
    .locals 2
    .param p1    # Lcom/hjq/window/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method
