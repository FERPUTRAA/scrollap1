.class Lcom/ntjbase/NTThreadUtils$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ntjbase/NTThreadUtils;->invokeUninterruptibly(Landroid/os/Handler;Ljava/util/concurrent/Callable;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$barrier:Ljava/util/concurrent/CountDownLatch;

.field private final synthetic val$callable:Ljava/util/concurrent/Callable;

.field private final synthetic val$result:Lcom/ntjbase/NTThreadUtils$1Result;


# direct methods
.method constructor <init>(Lcom/ntjbase/NTThreadUtils$1Result;Ljava/util/concurrent/Callable;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/ntjbase/NTThreadUtils$3;->val$result:Lcom/ntjbase/NTThreadUtils$1Result;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/ntjbase/NTThreadUtils$3;->val$callable:Ljava/util/concurrent/Callable;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/ntjbase/NTThreadUtils$3;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  s @@a@~ov@ ~b@ . ~~~  @@@fi~o~u r@co@lo~s oSM/ @ i@ity K~@-~1n@@b~~ b~@4~ ~@~~/~@~~f@om~l @ ~t"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/ntjbase/NTThreadUtils$3;->val$result:Lcom/ntjbase/NTThreadUtils$1Result;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/ntjbase/NTThreadUtils$3;->val$callable:Ljava/util/concurrent/Callable;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    iput-object v1, v0, Lcom/ntjbase/NTThreadUtils$1Result;->value:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/ntjbase/NTThreadUtils$3;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v3, "xeeml i wtp:ohancll eesbrt"

    const-string v3, " ls e nte:aeewohlxprCblict"

    const-string v3, "htrnobClele:  oaepxclwt ae"

    const-string v3, "Callable threw exception: "

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    throw v1
.end method
