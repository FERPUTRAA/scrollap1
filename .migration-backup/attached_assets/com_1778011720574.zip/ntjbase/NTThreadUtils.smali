.class public Lcom/ntjbase/NTThreadUtils;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ntjbase/NTThreadUtils$BlockingOperation;,
        Lcom/ntjbase/NTThreadUtils$ThreadChecker;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s@  @@loi @~  @bo ~~/~.b~t@~ @@@lu v o ~Sm @yM@~1K/@ r ~@~~o@~ioos~~~@@b~~ fn~ 4 dta~~~f@c-i@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Lcom/ntjbase/NTThreadUtils$2;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/ntjbase/NTThreadUtils$2;-><init>(Ljava/util/concurrent/CountDownLatch;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-static {v0}, Lcom/ntjbase/NTThreadUtils;->executeUninterruptibly(Lcom/ntjbase/NTThreadUtils$BlockingOperation;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public static awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 v2, 0x0

    move-wide v3, p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    move v5, v2

    move v5, v2

    const/4 v8, 0x1

    move v5, v2

    move v5, v2

    :goto_0
    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    sget-object v6, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0, v3, v4, v6}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    move-result v2
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_1

    :catch_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    sub-long/2addr v3, v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    sub-long v3, p1, v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    cmp-long v5, v3, v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v6, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-gtz v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    move v5, v6

    move v5, v6

    const/4 v8, 0x4

    move v5, v6

    move v5, v6

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v5, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/Thread;->interrupt()V

    :cond_0
    const/4 v7, 0x1

    return v2

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v5, v6

    move v5, v6

    const/4 v8, 0x4

    move v5, v6

    move v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0
.end method

.method public static executeUninterruptibly(Lcom/ntjbase/NTThreadUtils$BlockingOperation;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x0

    :goto_0
    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p0}, Lcom/ntjbase/NTThreadUtils$BlockingOperation;->run()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Thread;->interrupt()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :catch_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0
.end method

.method public static invokeUninterruptibly(Landroid/os/Handler;Ljava/util/concurrent/Callable;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/os/Handler;",
            "Ljava/util/concurrent/Callable<",
            "TV;>;)TV;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lcom/ntjbase/NTThreadUtils$1Result;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/ntjbase/NTThreadUtils$1Result;-><init>()V

    const/4 v4, 0x4

    new-instance v1, Ljava/util/concurrent/CountDownLatch;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v2, Lcom/ntjbase/NTThreadUtils$3;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v2, v0, p1, v1}, Lcom/ntjbase/NTThreadUtils$3;-><init>(Lcom/ntjbase/NTThreadUtils$1Result;Ljava/util/concurrent/Callable;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/ntjbase/NTThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p0, v0, Lcom/ntjbase/NTThreadUtils$1Result;->value:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p0
.end method

.method public static invokeUninterruptibly(Landroid/os/Handler;Ljava/lang/Runnable;)V
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    new-instance v1, Lcom/ntjbase/NTThreadUtils$4;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v1, p1, v0}, Lcom/ntjbase/NTThreadUtils$4;-><init>(Ljava/lang/Runnable;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/ntjbase/NTThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public static joinUninterruptibly(Ljava/lang/Thread;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lcom/ntjbase/NTThreadUtils$1;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0, p0}, Lcom/ntjbase/NTThreadUtils$1;-><init>(Ljava/lang/Thread;)V

    invoke-static {v0}, Lcom/ntjbase/NTThreadUtils;->executeUninterruptibly(Lcom/ntjbase/NTThreadUtils$BlockingOperation;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public static joinUninterruptibly(Ljava/lang/Thread;J)Z
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v2, 0x0

    move-wide v3, p1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x7

    cmp-long v5, v3, v5

    const/4 v7, 0x4

    move v8, v7

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-gtz v5, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0, v3, v4}, Ljava/lang/Thread;->join(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    :cond_1
    const/4 v7, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/Thread;->isAlive()Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    xor-int/2addr p0, v6

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    return p0

    :catch_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    sub-long/2addr v2, v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    sub-long v3, p1, v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    move v2, v6

    move v2, v6

    const/4 v8, 0x5

    move v2, v6

    move v2, v6

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_0
.end method
