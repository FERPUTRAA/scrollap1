.class public final Lcom/ntjbase/NTAppInfo;
.super Ljava/lang/Object;


# static fields
.field private static TAG:Ljava/lang/String; = "NTJE.AIF"


# instance fields
.field private final context:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/ntjbase/NTAppInfo;->context:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object p1, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const-string/jumbo v0, "unsltilc s "

    const/4 v2, 0x3

    const-string/jumbo v0, "uis lx ncsl"

    const-string v0, "ctx is null"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public AI()Landroid/content/pm/ApplicationInfo;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/ntjbase/NTAppInfo;->PKM()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    move v6, v5

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v5, 0x7

    move v6, v5

    const-string v2, " smmillnumk"

    const-string v2, " npmlskuilm"

    const/4 v6, 0x3

    const-string/jumbo v2, "nmi ou pskl"

    const-string/jumbo v2, "pkm is null"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-object v1

    :cond_0
    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p0}, Lcom/ntjbase/NTAppInfo;->PKN()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, " knnlbpluio"

    const-string/jumbo v2, "nipson ullk"

    const/4 v6, 0x7

    const-string/jumbo v2, "pksiu unlln"

    const-string/jumbo v2, "pkn is null"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-object v1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    if-ge v3, v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v5, 0x7

    move v6, v5

    const-string/jumbo v2, "yse pm ppbik"

    const-string/jumbo v2, "te pibpysmk "

    const/4 v6, 0x4

    const-string/jumbo v2, "yt epispqkm "

    const-string/jumbo v2, "pkn is empty"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    return-object v1

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v3, 0x0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v1, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "ios nuulnsi "

    const-string/jumbo v2, "nnsiiluo u l"

    const/4 v6, 0x0

    const-string/jumbo v2, "ifsm ulli nn"

    const-string/jumbo v2, "info is null"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-object v1
.end method

.method public AL()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/ntjbase/NTAppInfo;->PKM()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-string/jumbo v2, "kmpiopnls l"

    const-string v2, " pulmilpsnk"

    const/4 v4, 0x0

    const-string/jumbo v2, "msi  bnulpl"

    const-string/jumbo v2, "pkm is null"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/ntjbase/NTAppInfo;->AI()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v2, :cond_1

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v4, 0x2

    const-string/jumbo v2, "squlniu il"

    const-string/jumbo v2, "lian uisql"

    const/4 v4, 0x4

    const-string v2, " a siilpnl"

    const-string v2, "ai is null"

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    return-object v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0
.end method

.method public PKM()Landroid/content/pm/PackageManager;
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/ntjbase/NTAppInfo;->context:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "uilssxnlq t"

    const-string/jumbo v1, "tusi  sllnx"

    const/4 v3, 0x6

    const-string v1, "cnsultsl ix"

    const-string v1, "ctx is null"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method

.method public PKN()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/ntjbase/NTAppInfo;->context:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/ntjbase/NTAppInfo;->TAG:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "tlumlxcnmi "

    const-string/jumbo v1, "xi mcln tlu"

    const/4 v3, 0x1

    const-string/jumbo v1, "uinxo cltl "

    const-string v1, "ctx is null"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method
