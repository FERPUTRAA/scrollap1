.class Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/viewpager/widget/ViewPager$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;


# direct methods
.method constructor <init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public onPageScrollStateChanged(I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method

.method public onPageScrolled(IFI)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public onPageSelected(I)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;I)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    move v1, v0

    move v1, v0

    const/4 v5, 0x5

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v2}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroid/widget/LinearLayout;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ge v1, v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    rem-int v2, p1, v2

    const/4 v5, 0x7

    if-ne v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroid/widget/LinearLayout;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v2, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x1

    and-int/2addr v5, v3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;->setState(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v2}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroid/widget/LinearLayout;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    check-cast v2, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;->setState(Z)V

    :goto_1
    const/4 v4, 0x3

    move v5, v4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method
