.class public Lcom/ocnyang/pagetransformerhelp/b;
.super Ljava/lang/Object;


# instance fields
.field a:Ljava/lang/Object;

.field b:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/b;->a:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/b;->a:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/ocnyang/pagetransformerhelp/b;->b:Ljava/lang/String;

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s@@Mo~@@ ~~~@@o@~ t@ ui @ v ~f@  onSfa ~4~r/o-~i ~do /.~~ ~~@~oK~t~~b@@1 @~@ cib@ ~ ~m@bll@y@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/b;->a:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public b()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/b;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public c(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/b;->a:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public d(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/b;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
