.class public Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
.super Landroid/widget/FrameLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;
    }
.end annotation


# static fields
.field private static final n:I


# instance fields
.field private a:I

.field private b:Landroidx/viewpager/widget/ViewPager;

.field private c:Landroidx/viewpager/widget/ViewPager$k;

.field private d:Lcom/ocnyang/pagetransformerhelp/a;

.field private e:I

.field private f:Landroid/widget/LinearLayout;

.field private g:Landroid/widget/TextView;

.field private h:Z

.field private i:Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;

.field private j:Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

.field private k:Lcom/ocnyang/pagetransformerhelp/d;

.field private l:Z

.field private m:Landroid/os/Handler;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "HandlerLeak"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    new-instance p1, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p1, p0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;-><init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->m:Landroid/os/Handler;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->j()V

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic b(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o1s 4@/f-@n~@@i ~v@c.@@ ~d u@~~o@/o~t@~@~~~ ~~@s b  i~m @o@  yt~ ~~~@  ~ i~bb@M@Sr~~ o@ K@lfalo@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->h:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic c(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroidx/viewpager/widget/ViewPager;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic d(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->a:I

    return p0
.end method

.method static synthetic e(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setTitleSlogan(I)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic f(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroid/widget/LinearLayout;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic g(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget p0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method public static i(Landroid/content/Context;IZ)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    int-to-float p0, p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/high16 p1, 0x44870000    # 1080.0f

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    div-float/2addr p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    int-to-float p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    mul-float/2addr p0, p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    float-to-int p0, p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    int-to-float p1, p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/high16 p2, 0x44f00000    # 1920.0f

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    div-float/2addr p1, p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    int-to-float p0, p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    mul-float/2addr p1, p0

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    float-to-int p0, p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0
.end method

.method private j()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x2

    iput-boolean v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->l:Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-boolean v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->h:Z

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    iput v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v0, 0x1388

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->a:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->l()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->k()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->m:Landroid/os/Handler;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    int-to-long v1, v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v1, v2}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method private k()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v1, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;

    invoke-direct {v1, p0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$b;-><init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroidx/viewpager/widget/ViewPager;->addOnPageChangeListener(Landroidx/viewpager/widget/ViewPager$j;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private l()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget v1, Lcom/ocnyang/pagetransformerhelp/R$layout;->layout_bannerviewpager:I

    const/4 v3, 0x2

    invoke-static {v0, v1, p0}, Landroid/view/View;->inflate(Landroid/content/Context;ILandroid/view/ViewGroup;)Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget v0, Lcom/ocnyang/pagetransformerhelp/R$id;->viewPager:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Landroidx/viewpager/widget/ViewPager;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget v0, Lcom/ocnyang/pagetransformerhelp/R$id;->bannerIndicators:I

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Landroid/widget/LinearLayout;

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget v0, Lcom/ocnyang/pagetransformerhelp/R$id;->bannerTitle:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method private s(Lcom/ocnyang/pagetransformerhelp/BaseIndicator;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->j:Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string/jumbo v0, "ooo"

    const-string/jumbo v0, "ooo"

    const/4 v2, 0x7

    const-string/jumbo v0, "ooo"

    const-string/jumbo v0, "ooo"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    mul-int/lit16 v0, v0, 0x3e8

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setIndicators(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setTitleSlogan(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method private setIndicators(I)V
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    move v1, v0

    move v1, v0

    const/4 v9, 0x4

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x7

    const-string/jumbo v3, "iii"

    const-string/jumbo v3, "iii"

    const/4 v9, 0x7

    const-string/jumbo v3, "iii"

    const-string/jumbo v3, "iii"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v4, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-ge v1, p1, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x7

    iget-object v5, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->j:Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez v5, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance v2, Lcom/ocnyang/pagetransformerhelp/Indicator;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct {v2, v3}, Lcom/ocnyang/pagetransformerhelp/Indicator;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/16 v6, 0x14

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v5, v6, v0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i(Landroid/content/Context;IZ)I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-static {v7, v6, v0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i(Landroid/content/Context;IZ)I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/16 v6, 0xa

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v5, v6, v4}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i(Landroid/content/Context;IZ)I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v7, v6, v4}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i(Landroid/content/Context;IZ)I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v3, v5, v0, v4, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    iget-object v3, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string/jumbo v5, "oucms"

    const-string/jumbo v5, "ousnc"

    const/4 v9, 0x0

    const-string/jumbo v5, "ocuto"

    const-string v5, "count"

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->j:Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v5, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x1

    check-cast v5, Landroid/view/ViewGroup;

    const/4 v9, 0x6

    const/4 v8, 0x3

    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v5, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x6

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->f:Landroid/widget/LinearLayout;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    check-cast p1, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v9, 0x2

    invoke-virtual {p1, v4}, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;->setState(Z)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-void
.end method

.method private setTitleSlogan(I)V
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->l:Z

    const/4 v2, 0x7

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->d:Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/ocnyang/pagetransformerhelp/a;->b()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    rem-int/2addr p1, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast p1, Lcom/ocnyang/pagetransformerhelp/b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/ocnyang/pagetransformerhelp/b;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->g:Landroid/widget/TextView;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method protected a(Landroid/view/View;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i:Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    rem-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, p1, v1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;->a(Landroid/view/View;I)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method protected getIndicatorView()Lcom/ocnyang/pagetransformerhelp/BaseIndicator;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->j:Lcom/ocnyang/pagetransformerhelp/BaseIndicator;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public h(Landroid/content/Context;Landroid/widget/ImageView;Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->k:Lcom/ocnyang/pagetransformerhelp/d;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1, p3, p2}, Lcom/ocnyang/pagetransformerhelp/d;->a(Landroid/content/Context;Ljava/lang/Object;Landroid/widget/ImageView;)V

    const/4 v1, 0x4

    return-void
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->h:Z

    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public n()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->l:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public o(Z)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->h:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public p(Ljava/util/List;Lcom/ocnyang/pagetransformerhelp/d;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ocnyang/pagetransformerhelp/b;",
            ">;",
            "Lcom/ocnyang/pagetransformerhelp/d;",
            ")",
            "Lcom/ocnyang/pagetransformerhelp/BannerViewPager;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->k:Lcom/ocnyang/pagetransformerhelp/d;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance p2, Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p2, p0}, Lcom/ocnyang/pagetransformerhelp/a;-><init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->d:Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Lcom/ocnyang/pagetransformerhelp/a;->d(Ljava/util/List;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->d:Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p2, v0}, Landroidx/viewpager/widget/ViewPager;->setAdapter(Landroidx/viewpager/widget/a;)V

    const/4 v2, 0x4

    iget-object p2, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    mul-int/lit16 v0, v0, 0x3e8

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setIndicators(I)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setTitleSlogan(I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public q(I)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public r(Z)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->l:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    invoke-virtual {p1}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->setTitleSlogan(I)V

    const/4 v1, 0x4

    return-object p0
.end method

.method public t(Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->i:Lcom/ocnyang/pagetransformerhelp/BannerViewPager$c;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public u(Landroidx/viewpager/widget/ViewPager$k;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->c:Landroidx/viewpager/widget/ViewPager$k;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b:Landroidx/viewpager/widget/ViewPager;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v0, v1, p1}, Landroidx/viewpager/widget/ViewPager;->setPageTransformer(ZLandroidx/viewpager/widget/ViewPager$k;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0
.end method
