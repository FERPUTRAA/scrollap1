.class Lcom/ocnyang/pagetransformerhelp/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/ocnyang/pagetransformerhelp/a;->instantiateItem(Landroid/view/ViewGroup;I)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/ocnyang/pagetransformerhelp/a;


# direct methods
.method constructor <init>(Lcom/ocnyang/pagetransformerhelp/a;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/a$a;->a:Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@lm/@f~~ i~o4~osb~t @n@~.c~ou@@~@ i ~M @oo a@ / ~ @f@r@1@ ~Sdb~ ~-~K @ ~~@o@t~~ly ~v@@b ~ i @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/a$a;->a:Lcom/ocnyang/pagetransformerhelp/a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/ocnyang/pagetransformerhelp/a;->a(Lcom/ocnyang/pagetransformerhelp/a;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->a(Landroid/view/View;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
