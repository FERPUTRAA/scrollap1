.class public final Lcom/ocnyang/pagetransformerhelp/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ocnyang/pagetransformerhelp/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final abc_background_cache_hint_selector_material_dark:I = 0x7f060000

.field public static final abc_background_cache_hint_selector_material_light:I = 0x7f060001

.field public static final abc_btn_colored_borderless_text_material:I = 0x7f060002

.field public static final abc_btn_colored_text_material:I = 0x7f060003

.field public static final abc_color_highlight_material:I = 0x7f060004

.field public static final abc_hint_foreground_material_dark:I = 0x7f060007

.field public static final abc_hint_foreground_material_light:I = 0x7f060008

.field public static final abc_primary_text_disable_only_material_dark:I = 0x7f060009

.field public static final abc_primary_text_disable_only_material_light:I = 0x7f06000a

.field public static final abc_primary_text_material_dark:I = 0x7f06000b

.field public static final abc_primary_text_material_light:I = 0x7f06000c

.field public static final abc_search_url_text:I = 0x7f06000d

.field public static final abc_search_url_text_normal:I = 0x7f06000e

.field public static final abc_search_url_text_pressed:I = 0x7f06000f

.field public static final abc_search_url_text_selected:I = 0x7f060010

.field public static final abc_secondary_text_material_dark:I = 0x7f060011

.field public static final abc_secondary_text_material_light:I = 0x7f060012

.field public static final abc_tint_btn_checkable:I = 0x7f060013

.field public static final abc_tint_default:I = 0x7f060014

.field public static final abc_tint_edittext:I = 0x7f060015

.field public static final abc_tint_seek_thumb:I = 0x7f060016

.field public static final abc_tint_spinner:I = 0x7f060017

.field public static final abc_tint_switch_track:I = 0x7f060018

.field public static final accent_material_dark:I = 0x7f06001c

.field public static final accent_material_light:I = 0x7f06001d

.field public static final background_floating_material_dark:I = 0x7f060024

.field public static final background_floating_material_light:I = 0x7f060025

.field public static final background_material_dark:I = 0x7f060026

.field public static final background_material_light:I = 0x7f060027

.field public static final bright_foreground_disabled_material_dark:I = 0x7f060029

.field public static final bright_foreground_disabled_material_light:I = 0x7f06002a

.field public static final bright_foreground_inverse_material_dark:I = 0x7f06002b

.field public static final bright_foreground_inverse_material_light:I = 0x7f06002c

.field public static final bright_foreground_material_dark:I = 0x7f06002d

.field public static final bright_foreground_material_light:I = 0x7f06002e

.field public static final button_material_dark:I = 0x7f060034

.field public static final button_material_light:I = 0x7f060035

.field public static final dim_foreground_disabled_material_dark:I = 0x7f060092

.field public static final dim_foreground_disabled_material_light:I = 0x7f060093

.field public static final dim_foreground_material_dark:I = 0x7f060094

.field public static final dim_foreground_material_light:I = 0x7f060095

.field public static final error_color_material_dark:I = 0x7f06009a

.field public static final error_color_material_light:I = 0x7f06009b

.field public static final foreground_material_dark:I = 0x7f06009c

.field public static final foreground_material_light:I = 0x7f06009d

.field public static final highlighted_text_material_dark:I = 0x7f06009f

.field public static final highlighted_text_material_light:I = 0x7f0600a0

.field public static final material_blue_grey_800:I = 0x7f0601e7

.field public static final material_blue_grey_900:I = 0x7f0601e8

.field public static final material_blue_grey_950:I = 0x7f0601e9

.field public static final material_deep_teal_200:I = 0x7f0601eb

.field public static final material_deep_teal_500:I = 0x7f0601ec

.field public static final material_grey_100:I = 0x7f06022f

.field public static final material_grey_300:I = 0x7f060230

.field public static final material_grey_50:I = 0x7f060231

.field public static final material_grey_600:I = 0x7f060232

.field public static final material_grey_800:I = 0x7f060233

.field public static final material_grey_850:I = 0x7f060234

.field public static final material_grey_900:I = 0x7f060235

.field public static final notification_action_color_filter:I = 0x7f060283

.field public static final notification_icon_bg_color:I = 0x7f060284

.field public static final primary_dark_material_dark:I = 0x7f060295

.field public static final primary_dark_material_light:I = 0x7f060296

.field public static final primary_material_dark:I = 0x7f060297

.field public static final primary_material_light:I = 0x7f060298

.field public static final primary_text_default_material_dark:I = 0x7f060299

.field public static final primary_text_default_material_light:I = 0x7f06029a

.field public static final primary_text_disabled_material_dark:I = 0x7f06029b

.field public static final primary_text_disabled_material_light:I = 0x7f06029c

.field public static final ripple_material_dark:I = 0x7f0602cd

.field public static final ripple_material_light:I = 0x7f0602ce

.field public static final secondary_text_default_material_dark:I = 0x7f0602d1

.field public static final secondary_text_default_material_light:I = 0x7f0602d2

.field public static final secondary_text_disabled_material_dark:I = 0x7f0602d3

.field public static final secondary_text_disabled_material_light:I = 0x7f0602d4

.field public static final switch_thumb_disabled_material_dark:I = 0x7f0602dd

.field public static final switch_thumb_disabled_material_light:I = 0x7f0602de

.field public static final switch_thumb_material_dark:I = 0x7f0602df

.field public static final switch_thumb_material_light:I = 0x7f0602e0

.field public static final switch_thumb_normal_material_dark:I = 0x7f0602e1

.field public static final switch_thumb_normal_material_light:I = 0x7f0602e2

.field public static final tooltip_background_dark:I = 0x7f0602f9

.field public static final tooltip_background_light:I = 0x7f0602fa


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method
