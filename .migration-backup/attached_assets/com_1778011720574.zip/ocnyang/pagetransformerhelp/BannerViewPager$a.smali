.class Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;


# direct methods
.method constructor <init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " oso M~@ ~~~mrlo~ @~.@@@ lo~@~S~ ~fvt bt ~o@~@b@@ ~i~1o ~ @d~b@~Ki@/@  /-s@ ~a@f4 ~i@ @~@@nc~ y~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->b(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->c(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroidx/viewpager/widget/ViewPager;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-static {v0}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->c(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)Landroidx/viewpager/widget/ViewPager;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/viewpager/widget/ViewPager;->getCurrentItem()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroidx/viewpager/widget/ViewPager;->setCurrentItem(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/BannerViewPager$a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->d(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    int-to-long v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, p1, v0, v1}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    :cond_0
    const/4 v3, 0x3

    return-void
.end method
