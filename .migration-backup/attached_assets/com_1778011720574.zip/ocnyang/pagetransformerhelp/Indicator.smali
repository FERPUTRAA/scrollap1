.class public Lcom/ocnyang/pagetransformerhelp/Indicator;
.super Lcom/ocnyang/pagetransformerhelp/BaseIndicator;


# instance fields
.field private a:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/ocnyang/pagetransformerhelp/BaseIndicator;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/ocnyang/pagetransformerhelp/Indicator;->a()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method private a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o s~@c@~  y@o@~~M- ~/mfv@t~@~@~@~b~S ~@o @l~  ~~@~i  ~ bu~rd~fKt@ i .@@ o@oo~a l~@4s @1~@ @ib/~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Landroid/graphics/Paint;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/ocnyang/pagetransformerhelp/Indicator;->a:Landroid/graphics/Paint;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lcom/ocnyang/pagetransformerhelp/Indicator;->setState(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v4, "gesmht"

    const-string/jumbo v4, "tesigh"

    const/4 v6, 0x5

    const-string v4, "htehog"

    const-string v4, "heigth"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v3, "bhwdi"

    const-string/jumbo v3, "wdimh"

    const-string/jumbo v3, "width"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    int-to-float v1, v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/high16 v2, 0x3f000000    # 0.5f

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    mul-float/2addr v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    int-to-float v0, v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    mul-float/2addr v0, v2

    const/4 v6, 0x6

    invoke-virtual {p1, v1, v0}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/ocnyang/pagetransformerhelp/Indicator;->a:Landroid/graphics/Paint;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, v0, v0, v1, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void
.end method

.method public setState(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/Indicator;->a:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/Indicator;->a:Landroid/graphics/Paint;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const v0, -0x77000001

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x7

    return-void
.end method
