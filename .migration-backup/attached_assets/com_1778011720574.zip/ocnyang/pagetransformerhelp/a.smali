.class public Lcom/ocnyang/pagetransformerhelp/a;
.super Landroidx/viewpager/widget/a;


# instance fields
.field private a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

.field private b:I

.field private c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/ocnyang/pagetransformerhelp/b;",
            ">;"
        }
    .end annotation
.end field

.field private d:Landroid/widget/ImageView$ScaleType;


# direct methods
.method public constructor <init>(Lcom/ocnyang/pagetransformerhelp/BannerViewPager;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Landroidx/viewpager/widget/a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput v0, p0, Lcom/ocnyang/pagetransformerhelp/a;->b:I

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic a(Lcom/ocnyang/pagetransformerhelp/a;)Lcom/ocnyang/pagetransformerhelp/BannerViewPager;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o-s~@@cl~@@~ @@ @@b  M~rt@ sy4f~f~~in~@1~@.~ o@@ oSo/~@ vi@m~/d @t@@  u~~ ~ o bl~~~a~@~b Ki ~@ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/ocnyang/pagetransformerhelp/a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method private c()Landroid/widget/ImageView$ScaleType;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/a;->d:Landroid/widget/ImageView$ScaleType;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public b()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/ocnyang/pagetransformerhelp/b;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/a;->c:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public d(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/ocnyang/pagetransformerhelp/b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/a;->c:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/ocnyang/pagetransformerhelp/a;->c:Ljava/util/List;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lcom/ocnyang/pagetransformerhelp/a;->b:I

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public destroyItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    check-cast p3, Landroid/widget/ImageView;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1, p3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public e(Landroid/widget/ImageView$ScaleType;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/ocnyang/pagetransformerhelp/a;->d:Landroid/widget/ImageView$ScaleType;

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public getCount()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/ocnyang/pagetransformerhelp/a;->c:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const v0, 0x7fffffff

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public instantiateItem(Landroid/view/ViewGroup;I)Ljava/lang/Object;
    .locals 7

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v0, Landroid/widget/ImageView;

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/ocnyang/pagetransformerhelp/a;->c()Landroid/widget/ImageView$ScaleType;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/ocnyang/pagetransformerhelp/a;->a:Lcom/ocnyang/pagetransformerhelp/BannerViewPager;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/ocnyang/pagetransformerhelp/a;->c:Ljava/util/List;

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget v4, p0, Lcom/ocnyang/pagetransformerhelp/a;->b:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    rem-int/2addr p2, v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v3, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    check-cast p2, Lcom/ocnyang/pagetransformerhelp/b;

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/ocnyang/pagetransformerhelp/b;->a()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v0, p2}, Lcom/ocnyang/pagetransformerhelp/BannerViewPager;->h(Landroid/content/Context;Landroid/widget/ImageView;Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance p2, Lcom/ocnyang/pagetransformerhelp/a$a;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {p2, p0}, Lcom/ocnyang/pagetransformerhelp/a$a;-><init>(Lcom/ocnyang/pagetransformerhelp/a;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v6, 0x2

    return-object v0
.end method

.method public isViewFromObject(Landroid/view/View;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-ne p1, p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 p1, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return p1
.end method
