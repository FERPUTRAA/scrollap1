.class public final Lcom/ocnyang/pagetransformerhelp/c;
.super Ljava/lang/Object;


# static fields
.field public static final a:Z = false

.field public static final b:Ljava/lang/String; = "com.ocnyang.pagetransformerhelp"

.field public static final c:Ljava/lang/String; = "release"

.field public static final d:Ljava/lang/String; = ""

.field public static final e:I = 0x2

.field public static final f:Ljava/lang/String; = "1.0.1"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
