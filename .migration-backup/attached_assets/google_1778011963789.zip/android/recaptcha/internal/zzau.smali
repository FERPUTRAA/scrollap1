.class final Lcom/google/android/recaptcha/internal/zzau;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/p;


# instance fields
.field final synthetic zza:Lcom/google/android/recaptcha/internal/zzba;

.field final synthetic zzb:Ljava/lang/String;

.field final synthetic zzc:I


# direct methods
.method constructor <init>(Lcom/google/android/recaptcha/internal/zzba;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzau;->zza:Lcom/google/android/recaptcha/internal/zzba;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/recaptcha/internal/zzau;->zzb:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/recaptcha/internal/zzau;->zzc:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@-s ~M~ @~@ l@~@@o ~b~o@ir@~~cm~4@vSK~ ~  .@@@ ~@~u /o/n ~~~@d~@@~a~ bs@t~ f@tily~f@1oi @~o   ob"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    check-cast p1, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast p2, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzau;->zza:Lcom/google/android/recaptcha/internal/zzba;

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    iget-object v1, p0, Lcom/google/android/recaptcha/internal/zzau;->zzb:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0, v1, p2}, Lcom/google/android/recaptcha/internal/zzba;->zzg(Lcom/google/android/recaptcha/internal/zzba;Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget p2, p0, Lcom/google/android/recaptcha/internal/zzau;->zzc:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eq p2, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzau;->zza:Lcom/google/android/recaptcha/internal/zzba;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzba;->zzb()Lcom/google/android/recaptcha/internal/zzbn;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzbn;->zzb()Lcom/google/android/recaptcha/internal/zzbm;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p2, p1}, Lcom/google/android/recaptcha/internal/zzbm;->zzf(ILjava/lang/Object;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method
