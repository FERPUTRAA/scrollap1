.class public final Lcom/google/android/recaptcha/internal/zzlp;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzlp;


# instance fields
.field private zzd:Lcom/google/android/recaptcha/internal/zzgv;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzlp;-><init>()V

    const/4 v2, 0x6

    move v3, v2

    sput-object v0, Lcom/google/android/recaptcha/internal/zzlp;->zzb:Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/recaptcha/internal/zzlp;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/recaptcha/internal/zzlp;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzgo;->zzw()Lcom/google/android/recaptcha/internal/zzgv;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlp;->zzd:Lcom/google/android/recaptcha/internal/zzgv;

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzlp;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~  @@@u~i @ot@~-o4~l ~oS@  n f@K1l@M ay/~~ f @~~~~@@ i~d@@b o ~b@~~@so@t.@~@@@ ~/ mv ~~ ~bcoi"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlp;->zzb:Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zzg()Lcom/google/android/recaptcha/internal/zzlp;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlp;->zzb:Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p1, :cond_4

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p3, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eq p1, p3, :cond_3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p2, 0x3

    const/4 v1, 0x5

    if-eq p1, p2, :cond_2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p2, 0x4

    const/4 v0, 0x7

    move v1, v0

    const/4 p3, 0x0

    shr-int/2addr v1, p3

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-eq p1, p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p2, 0x5

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eq p1, p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-object p3

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-object p1, Lcom/google/android/recaptcha/internal/zzlp;->zzb:Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1

    :cond_1
    new-instance p1, Lcom/google/android/recaptcha/internal/zzlo;

    const/4 v1, 0x2

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzlo;-><init>(Lcom/google/android/recaptcha/internal/zzln;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1

    :cond_2
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzlp;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1

    :cond_3
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    const-string p3, "dzz"

    const-string p3, "dzz"

    const-string/jumbo p3, "zdz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    aput-object p3, p1, p2

    const/4 v1, 0x1

    const/4 v0, 0x2

    sget-object p2, Lcom/google/android/recaptcha/internal/zzlp;->zzb:Lcom/google/android/recaptcha/internal/zzlp;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    const-string p3, "00/m00/u00/s/100/0u0u2/0//uu0u0000u10/00u/u0000u10000/000a10010010u001/0"

    const-string p3, "00s00u/2uua0000001000000001000001/10/////0/110u/u//100u0000uu0uu00/000u0"

    const/4 v1, 0x1

    const-string p3, "00u0o000/0//000a01/uu0/2uu00/0100000/0000101/000u0u0/0/u00u/u01u/01u0010"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u021a"

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1

    :cond_4
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public final zzi()Ljava/util/List;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzlp;->zzd:Lcom/google/android/recaptcha/internal/zzgv;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method
