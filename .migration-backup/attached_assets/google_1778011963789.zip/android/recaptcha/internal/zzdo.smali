.class public final Lcom/google/android/recaptcha/internal/zzdo;
.super Lcom/google/android/recaptcha/internal/zzds;

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field final zza:I

.field private final zzb:Ljava/util/Queue;


# direct methods
.method private constructor <init>(I)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzds;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ltz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Ljava/util/ArrayDeque;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Ljava/util/ArrayDeque;-><init>(I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v3, 0x6

    move v4, v3

    iput p1, p0, Lcom/google/android/recaptcha/internal/zzdo;->zza:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    aput-object p1, v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string p1, "0 s> (=x%m si sSm)euta"

    const/4 v4, 0x6

    const-string p1, "S ssu mt%0xzm )i=e>a(s"

    const-string/jumbo p1, "maxSize (%s) must >= 0"

    invoke-static {p1, v1}, Lcom/google/android/recaptcha/internal/zzdl;->zza(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw v0
.end method

.method public static zza(I)Lcom/google/android/recaptcha/internal/zzdo;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@o~m@~@~@d@~ v~isln~o f oo@ f~~@a oM~c~b~l-@ /~~~ui~Km@ 4@~  @b1~  @@~o@. b~ t @@S/@t @@y~ i~~r@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/recaptcha/internal/zzdo;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/android/recaptcha/internal/zzdo;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zza:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzdq;->size()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/android/recaptcha/internal/zzdo;->zza:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne v0, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Queue;->remove()Ljava/lang/Object;

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    return v1
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/recaptcha/internal/zzdo;->zza:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-lt v0, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzdq;->clear()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/recaptcha/internal/zzdo;->zza:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x2

    move v4, v3

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "nnseoibtoebn ekoruam   tpcin etmv"

    const-string/jumbo v2, "nepmtnbbeise go  ovtncrkaent uim "

    const/4 v4, 0x5

    const-string/jumbo v2, "teo vb btekn nio  agretisnpaencbm"

    const-string/jumbo v2, "number to skip cannot be negative"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lcom/google/android/recaptcha/internal/zzdi;->zzb(ZLjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Lcom/google/android/recaptcha/internal/zzdu;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v1, p1, v0}, Lcom/google/android/recaptcha/internal/zzdu;-><init>(Ljava/lang/Iterable;I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lcom/google/android/recaptcha/internal/zzdv;->zza(Ljava/util/Collection;Ljava/util/Iterator;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return p1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, p1}, Lcom/google/android/recaptcha/internal/zzdv;->zza(Ljava/util/Collection;Ljava/util/Iterator;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return p1
.end method

.method public final offer(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/recaptcha/internal/zzdq;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x3

    const/4 p1, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method protected final synthetic zzb()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final synthetic zzc()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected final zzd()Ljava/util/Queue;
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzdo;->zzb:Ljava/util/Queue;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method
