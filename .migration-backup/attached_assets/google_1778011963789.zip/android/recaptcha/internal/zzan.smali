.class final Lcom/google/android/recaptcha/internal/zzan;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# instance fields
.field final synthetic zza:Lcom/google/android/recaptcha/internal/zzkx;

.field final synthetic zzb:Lcom/google/android/recaptcha/internal/zzao;


# direct methods
.method constructor <init>(Lcom/google/android/recaptcha/internal/zzkx;Lcom/google/android/recaptcha/internal/zzao;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzan;->zza:Lcom/google/android/recaptcha/internal/zzkx;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/recaptcha/internal/zzan;->zzb:Lcom/google/android/recaptcha/internal/zzao;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ syub@t/@ ~i~.b ~~@~~i~a@~~~n@   @ b @@f~o~@ o4r   v@sdli  1@o~@ Ko@@@@~m~@@~M-~t@~c~ol@ofS~~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzan;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzan;->zza:Lcom/google/android/recaptcha/internal/zzkx;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/recaptcha/internal/zzan;->zzb:Lcom/google/android/recaptcha/internal/zzao;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p1, v0, v1, p2}, Lcom/google/android/recaptcha/internal/zzan;-><init>(Lcom/google/android/recaptcha/internal/zzkx;Lcom/google/android/recaptcha/internal/zzao;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1
.end method

.method public final bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/android/recaptcha/internal/zzan;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    check-cast p1, Lcom/google/android/recaptcha/internal/zzan;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/recaptcha/internal/zzan;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x0

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zzan;->zza:Lcom/google/android/recaptcha/internal/zzkx;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzan;->zzb:Lcom/google/android/recaptcha/internal/zzao;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-class v1, Lcom/google/android/recaptcha/internal/zzaj;

    const-class v1, Lcom/google/android/recaptcha/internal/zzaj;

    const/4 v8, 0x4

    const-class v1, Lcom/google/android/recaptcha/internal/zzaj;

    const-class v1, Lcom/google/android/recaptcha/internal/zzaj;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    monitor-enter v1

    :try_start_0
    const/4 v8, 0x5

    new-instance v2, Lcom/google/android/recaptcha/internal/zzae;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/google/android/recaptcha/internal/zzei;->zzd()[B

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzeb;->zzg()Lcom/google/android/recaptcha/internal/zzeb;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    array-length v4, p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v3, p1, v5, v4}, Lcom/google/android/recaptcha/internal/zzeb;->zzi([BII)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {v2, p1, v3, v4, v5}, Lcom/google/android/recaptcha/internal/zzae;-><init>(Ljava/lang/String;JI)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zza(Lcom/google/android/recaptcha/internal/zzao;)Lcom/google/android/recaptcha/internal/zzad;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance v3, Landroid/content/ContentValues;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v4, "ss"

    const-string/jumbo v4, "ss"

    const/4 v8, 0x6

    const-string/jumbo v4, "ss"

    const-string/jumbo v4, "ss"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v2}, Lcom/google/android/recaptcha/internal/zzae;->zzc()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, v4, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const-string/jumbo v4, "st"

    const-string/jumbo v4, "ts"

    const/4 v8, 0x1

    const-string/jumbo v4, "st"

    const-string/jumbo v4, "ts"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v2}, Lcom/google/android/recaptcha/internal/zzae;->zzb()J

    move-result-wide v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v3, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v2, "ce"

    const-string v2, "ce"

    const/4 v8, 0x5

    const-string v2, "ce"

    const-string v2, "ce"

    const/4 v8, 0x1

    const/4 v4, 0x3

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p1, v2, v4, v3}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zza(Lcom/google/android/recaptcha/internal/zzao;)Lcom/google/android/recaptcha/internal/zzad;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/recaptcha/internal/zzad;->zzb()I

    move-result p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    add-int/lit16 p1, p1, -0x1f4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-lez p1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zza(Lcom/google/android/recaptcha/internal/zzao;)Lcom/google/android/recaptcha/internal/zzad;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v2}, Lcom/google/android/recaptcha/internal/zzad;->zzd()Ljava/util/List;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v2, p1}, Lkotlin/collections/u;->G5(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zza(Lcom/google/android/recaptcha/internal/zzao;)Lcom/google/android/recaptcha/internal/zzad;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2, p1}, Lcom/google/android/recaptcha/internal/zzad;->zza(Ljava/util/List;)I

    :cond_0
    const/4 v8, 0x3

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zza(Lcom/google/android/recaptcha/internal/zzao;)Lcom/google/android/recaptcha/internal/zzad;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/google/android/recaptcha/internal/zzad;->zzb()I

    move-result p1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v2, 0x14

    const/4 v7, 0x6

    move v8, v7

    if-lt p1, v2, :cond_1

    const/4 v8, 0x4

    invoke-static {v0}, Lcom/google/android/recaptcha/internal/zzao;->zzd(Lcom/google/android/recaptcha/internal/zzao;)V

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    monitor-exit v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    monitor-exit v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    throw p1
.end method
