.class public final Lcom/google/android/recaptcha/internal/zzma;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzmb;->zzg()Lcom/google/android/recaptcha/internal/zzmb;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzlv;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzmb;->zzg()Lcom/google/android/recaptcha/internal/zzmb;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final zzd(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzma;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s n @c@M@ri@~vo ~i abf~@ -/~~@ o~~~o ~~ oSs~d @ .@1tlm K~/~f~@@@~~b @  u@@~@ il4~t@~@~boo @@y~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/recaptcha/internal/zzmb;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzmb;->zzj(Lcom/google/android/recaptcha/internal/zzmb;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public final zze(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzma;
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/recaptcha/internal/zzmb;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzmb;->zzi(Lcom/google/android/recaptcha/internal/zzmb;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-object p0
.end method
