.class public final Lcom/google/android/recaptcha/internal/zzkf;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzkg;->zzg()Lcom/google/android/recaptcha/internal/zzkg;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzke;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzkg;->zzg()Lcom/google/android/recaptcha/internal/zzkg;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zzd(Lcom/google/android/recaptcha/internal/zzfw;)Lcom/google/android/recaptcha/internal/zzkf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ys@@@so~~o/mbo ~~@@@.~   o~@~ @ro~~  ~n~v~K@ t~~@ od  i~S@~l@c @-@b  ~1bM@@@~~~~/l@f@ui4~itaf  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzkg;->zzi(Lcom/google/android/recaptcha/internal/zzkg;Lcom/google/android/recaptcha/internal/zzfw;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public final zze(I)Lcom/google/android/recaptcha/internal/zzkf;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzkg;->zzj(Lcom/google/android/recaptcha/internal/zzkg;I)V

    const/4 v1, 0x6

    or-int/2addr v2, v1

    return-object p0
.end method
