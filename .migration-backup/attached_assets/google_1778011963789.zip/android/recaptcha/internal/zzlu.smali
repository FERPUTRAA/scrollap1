.class public final Lcom/google/android/recaptcha/internal/zzlu;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzlu;


# instance fields
.field private zzd:I

.field private zze:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzlu;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/recaptcha/internal/zzlu;->zzb:Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/recaptcha/internal/zzlu;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/recaptcha/internal/zzlu;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/recaptcha/internal/zzlu;->zzd:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzlu;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/s~@@b@tt~os@-~~@a @~ ~yr~~~oiM@~ c~o  ~~ u @@o f~~o SK/v~@@ lb@@o@ @b f.i@~d~m ~ @1@4@ l~in~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlu;->zzb:Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p1, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p3, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p1, p3, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p2, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p1, p2, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p2, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p1, p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p2, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eq p1, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p3

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/recaptcha/internal/zzlu;->zzb:Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlt;

    const/4 v2, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzlt;-><init>(Lcom/google/android/recaptcha/internal/zzls;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzlu;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1

    :cond_3
    const/4 v2, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p3, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "zze"

    const-string/jumbo v0, "zez"

    const/4 v2, 0x7

    const-string/jumbo v0, "zze"

    const-string/jumbo v0, "zze"

    const/4 v1, 0x5

    move v2, v1

    aput-object v0, p1, p3

    const/4 v2, 0x4

    const-string p3, "dzz"

    const-string p3, "dzz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x5

    aput-object p3, p1, p2

    const/4 v2, 0x2

    sget-object p2, Lcom/google/android/recaptcha/internal/zzlu;->zzb:Lcom/google/android/recaptcha/internal/zzlu;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const-string p3, "0/um00u/6/0uu0/uu0n00/40?0100/tu00u00/uu//?u0u/u0u0800?/?01///000u/0u00/0004uu0u04/0?00000u00000/?1/0?u00u0/0e1000/0u?0/0f010100004u200u0b00/00/0000/u0000u0u000//511/0?01?0c00//04001/0/00uu300uu000/0u0u00?00//0?u00u000/001u//0000/00?00u0r000000000uu0??0us000?00?//00u0u000?1000300u?//7/u0u///00000?000002u0/0"

    const-string p3, "0es000u00n00u0100/02/0u2000000/t00/u000/u//0u0/00000/0000000uu0/u100/100uu?500010u/04000800/43/000uuu0100000100/00u/uu1u/u/0/u00u0u?00u0c30u?4000r0u400/0?/u0u0/1u00/uu000?0/0u1u?/u0/?07/?0?u/0000?00uu/0?//06u00/0000u000??/uu000?f0/0?1/000/u?00004//0u01/u0//000000b00/0/0u0//0/0?/0?0u00/10000000u000?00?/00000"

    const/4 v2, 0x4

    const-string p3, "??/uo00000u/00u000uu/00e0/00?/01000u0/1f//0007200//?/06u//00?00//0?0u00/10/0/u?/40000uuu0?//0u0000u000tu/u00u0u0u00000003000u0//0/004/u0000000uu/c0ru/01241u0?000u0000?0nu00000u1?/?/0u00u1/uu000000u0u00/b0000u00000/u?000?u1/10?00110000u000?5/0?u?/000/00u/0uu0u01400//u////008/403?00/u00/0000/00?0000000//u0000"

    const-string p3, "\u0000\u0014\u0001\u0000\u0001\u0014\u0014\u0000\u0000\u0000\u0001?\u0000\u0002?\u0000\u0003?\u0000\u0004?\u0000\u0005?\u0000\u0006?\u0000\u0007?\u0000\u0008?\u0000\t?\u0000\n?\u0000\u000b?\u0000\u000c?\u0000\r?\u0000\u000e?\u0000\u000f?\u0000\u0010?\u0000\u0011?\u0000\u0012?\u0000\u0013?\u0000\u0014?\u0000"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method
