.class public final Lcom/google/android/recaptcha/internal/zzkj;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzgu;

.field private static final zzd:Lcom/google/android/recaptcha/internal/zzkj;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;

.field private zzh:Ljava/lang/String;

.field private zzi:Ljava/lang/String;

.field private zzj:Ljava/lang/String;

.field private zzk:Lcom/google/android/recaptcha/internal/zzgt;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/recaptcha/internal/zzkh;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzkh;-><init>()V

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/recaptcha/internal/zzkj;->zzb:Lcom/google/android/recaptcha/internal/zzgu;

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzkj;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/recaptcha/internal/zzkj;->zzd:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzkj;

    const-class v1, Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzf:Ljava/lang/String;

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzg:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzh:Ljava/lang/String;

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzi:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzj:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzgo;->zzv()Lcom/google/android/recaptcha/internal/zzgt;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzk:Lcom/google/android/recaptcha/internal/zzgt;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic zzG(Lcom/google/android/recaptcha/internal/zzkj;Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "bfs~ -t~@/uf ~o~ l.~4@~@n~l @ @ ~~ @ya~t ~ ib@ o~~o  @@s~rMm~1 i~i~Kd@~o/@o~~ @c~v@ ~ b S@o@@@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzf:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-void
.end method

.method static synthetic zzH(Lcom/google/android/recaptcha/internal/zzkj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const-string p1, ".2s.81"

    const/4 v1, 0x6

    const-string p1, ".8.m12"

    const-string p1, "18.1.2"

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzg:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzI(Lcom/google/android/recaptcha/internal/zzkj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzh:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static zzf()Lcom/google/android/recaptcha/internal/zzki;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    sget-object v0, Lcom/google/android/recaptcha/internal/zzkj;->zzd:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzp()Lcom/google/android/recaptcha/internal/zzgi;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/recaptcha/internal/zzki;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzg()Lcom/google/android/recaptcha/internal/zzkj;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/recaptcha/internal/zzkj;->zzd:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzi(Lcom/google/android/recaptcha/internal/zzkj;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zze:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzj(Lcom/google/android/recaptcha/internal/zzkj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzi:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/recaptcha/internal/zzkj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkj;->zzj:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 p2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    move v6, v5

    const/4 p3, 0x5

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v0, 0x4

    const/4 v5, 0x0

    move v6, v5

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq p1, v2, :cond_3

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eq p1, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 p2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eq p1, v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eq p1, p3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object p2

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object p1, Lcom/google/android/recaptcha/internal/zzkj;->zzd:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzki;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p1, p2}, Lcom/google/android/recaptcha/internal/zzki;-><init>(Lcom/google/android/recaptcha/internal/zzkh;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-object p1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzkj;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-object p1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 p1, 0x7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v4, "zez"

    const-string/jumbo v4, "zze"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    aput-object v4, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v3, "fzz"

    const-string v3, "fzz"

    const/4 v6, 0x5

    const-string/jumbo v3, "zzf"

    const-string/jumbo v3, "zzf"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    aput-object v3, p1, p2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    aput-object p2, p1, v2

    const/4 v5, 0x6

    and-int/2addr v6, v5

    const-string p2, "hzz"

    const-string/jumbo p2, "zhz"

    const/4 v6, 0x4

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    aput-object p2, p1, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo p2, "zzi"

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    aput-object p2, p1, v0

    const/4 v6, 0x5

    const-string/jumbo p2, "zzj"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    aput-object p2, p1, p3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 p2, 0x6

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo p3, "kzz"

    const-string/jumbo p3, "zkz"

    const/4 v6, 0x7

    const-string/jumbo p3, "kzz"

    const-string/jumbo p3, "zzk"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    aput-object p3, p1, p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object p2, Lcom/google/android/recaptcha/internal/zzkj;->zzd:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string p3, "0/4m00/0/00u8uu6u00//0//10u5000u0u00//0u0/200u03uuu104/0702000u008/0000u0000/uu2/20//00/000u00180/0u00080u00000u/000uu020/7,u00/07200/000/8"

    const/4 v6, 0x5

    const-string p3, "05/0o7//000u0uu8002u0/0u0u0/400uu8000u0,000100u/uu00802/20001u00080//00000u040600//00/0u0u/00/2//370/u000u80/000/u7uu00/20/00u1200/0/000u00"

    const-string p3, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0001\u0000\u0001\u0004\u0002\u0208\u0003\u0208\u0004\u0208\u0005\u0208\u0006\u0208\u0007,"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-object p1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object p1
.end method
