.class public final Lcom/google/android/recaptcha/internal/zzfo;
.super Lcom/google/android/recaptcha/internal/zzgk;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzd:Lcom/google/android/recaptcha/internal/zzfo;


# instance fields
.field private zze:I

.field private zzf:Z

.field private zzg:Lcom/google/android/recaptcha/internal/zzgv;

.field private zzh:B


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzfo;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/recaptcha/internal/zzfo;->zzd:Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzfo;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzfo;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgk;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-byte v0, p0, Lcom/google/android/recaptcha/internal/zzfo;->zzh:B

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzii;->zze()Lcom/google/android/recaptcha/internal/zzii;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzfo;->zzg:Lcom/google/android/recaptcha/internal/zzgv;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzfo;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " csi  ~ a4t~ ~~~r~oto~o ~ ~@ @@@o~Kb S@b~@/~@ ~i/~@ol@~~@ d@M y~ ~~if ~ @s @1f@@mnblu@o- v@@.@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/recaptcha/internal/zzfo;->zzd:Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zzg()Lcom/google/android/recaptcha/internal/zzfo;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/recaptcha/internal/zzfo;->zzd:Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p1, :cond_5

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    const/4 p3, 0x1

    move v5, p3

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eq p1, v3, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eq p1, v2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq p1, v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, 0x5

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eq p1, v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez p2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    move p3, v0

    move p3, v0

    const/4 v5, 0x1

    move p3, v0

    move p3, v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-byte p3, p0, Lcom/google/android/recaptcha/internal/zzfo;->zzh:B

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object p1, Lcom/google/android/recaptcha/internal/zzfo;->zzd:Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object p1

    :cond_2
    new-instance p1, Lcom/google/android/recaptcha/internal/zzfn;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p1, v2}, Lcom/google/android/recaptcha/internal/zzfn;-><init>(Lcom/google/android/recaptcha/internal/zzfm;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object p1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzfo;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-array p1, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo p2, "zze"

    const-string p2, "ezz"

    const/4 v5, 0x3

    const-string/jumbo p2, "zze"

    const-string/jumbo p2, "zze"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    aput-object p2, p1, v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zfz"

    const/4 v5, 0x6

    const-string/jumbo p2, "zzf"

    const/4 v5, 0x5

    const/4 v4, 0x5

    aput-object p2, p1, p3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string p2, "gzz"

    const-string/jumbo p2, "zgz"

    const/4 v5, 0x5

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x3

    const/4 v4, 0x2

    aput-object p2, p1, v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-class p2, Lcom/google/android/recaptcha/internal/zzfs;

    const-class p2, Lcom/google/android/recaptcha/internal/zzfs;

    const/4 v5, 0x1

    const-class p2, Lcom/google/android/recaptcha/internal/zzfs;

    const-class p2, Lcom/google/android/recaptcha/internal/zzfs;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput-object p2, p1, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object p2, Lcom/google/android/recaptcha/internal/zzfo;->zzd:Lcom/google/android/recaptcha/internal/zzfo;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance p3, Lcom/google/android/recaptcha/internal/zzij;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v0, "00um004b10u/0u0u/00000/10100u1u000/1001307//12///20//u3//0s0000uu0u00/70u70/0ue0000u01uu00"

    const-string v0, "00s/00u00uu10u00eu//u000001/0u00u010/1702/300/4/0000b000u0010uu/u7/010/03u/1070//e2u/u1000"

    const/4 v5, 0x0

    const-string v0, "\u0001\u0002\u0000\u0001\u0001\u03e7\u0002\u0000\u0001\u0001\u0001\u1007\u0000\u03e7\u041b"

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p3, p2, v0, p1}, Lcom/google/android/recaptcha/internal/zzij;-><init>(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p3

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x5

    iget-byte p1, p0, Lcom/google/android/recaptcha/internal/zzfo;->zzh:B

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p1
.end method
