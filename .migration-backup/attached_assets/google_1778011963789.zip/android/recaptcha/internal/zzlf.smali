.class public final Lcom/google/android/recaptcha/internal/zzlf;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlg;->zzg()Lcom/google/android/recaptcha/internal/zzlg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzle;)V
    .locals 2

    const/4 v1, 0x3

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlg;->zzg()Lcom/google/android/recaptcha/internal/zzlg;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zzd(Lcom/google/android/recaptcha/internal/zzjd;)Lcom/google/android/recaptcha/internal/zzlf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s ~~~ n @f ~~l@  @@y~1@bbr~bi~ot~@@ ~a~@ /v~  /@ o4oi~f~S-@o ~l~~  M@.Ku~@@@@m@ ~~o@i~d@@oc st"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlg;->zzj(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzjd;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public final zze(Lcom/google/android/recaptcha/internal/zzfw;)Lcom/google/android/recaptcha/internal/zzlf;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlg;->zzG(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzfw;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public final zzp(Lcom/google/android/recaptcha/internal/zzjd;)Lcom/google/android/recaptcha/internal/zzlf;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlg;->zzk(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzjd;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public final zzq(Lcom/google/android/recaptcha/internal/zzfw;)Lcom/google/android/recaptcha/internal/zzlf;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v1, 0x4

    move v2, v1

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlg;->zzi(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzfw;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method
