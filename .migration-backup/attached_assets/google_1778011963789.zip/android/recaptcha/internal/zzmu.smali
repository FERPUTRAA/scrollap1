.class public final Lcom/google/android/recaptcha/internal/zzmu;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzmu;


# instance fields
.field private zzd:I

.field private zze:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzmu;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/recaptcha/internal/zzmu;->zzb:Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/recaptcha/internal/zzmu;

    const-class v1, Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/recaptcha/internal/zzmu;

    const-class v1, Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic zzI()Lcom/google/android/recaptcha/internal/zzmu;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/recaptcha/internal/zzmu;->zzb:Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public final zzG()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v1, 0x8

    const/4 v2, 0x6

    move v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/Long;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-wide v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method

.method public final zzH()Lcom/google/android/recaptcha/internal/zzez;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/recaptcha/internal/zzez;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lcom/google/android/recaptcha/internal/zzez;->zzb:Lcom/google/android/recaptcha/internal/zzez;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public final zzJ()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public final zzK()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v1, 0xc

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public final zzL()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    return v0
.end method

.method public final zzM()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0
.end method

.method public final zzN()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    packed-switch v0, :pswitch_data_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0

    :pswitch_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/16 v0, 0xf

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0

    :pswitch_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/16 v0, 0xe

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0

    :pswitch_2
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/16 v0, 0xd

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0

    :pswitch_3
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/16 v0, 0xc

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0

    :pswitch_4
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v0, 0xb

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0

    :pswitch_5
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v0, 0xa

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0

    :pswitch_6
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/16 v0, 0x9

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0

    :pswitch_7
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0x8

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0

    :pswitch_8
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0

    :pswitch_9
    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0

    :pswitch_a
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :pswitch_b
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return v0

    :pswitch_c
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0

    :pswitch_d
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0

    :pswitch_e
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0

    :pswitch_f
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0x10

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final zzf()D
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 v1, 0xb

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/Double;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-wide v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-wide v0
.end method

.method public final zzg()F
    .locals 4

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 v1, 0xa

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/Float;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0
.end method

.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 p3, 0x1

    const/4 v2, 0x4

    const/4 p3, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq p1, p3, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eq p1, p2, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p1, p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p2, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq p1, p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p3

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    sget-object p1, Lcom/google/android/recaptcha/internal/zzmu;->zzb:Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/recaptcha/internal/zzmt;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzmt;-><init>(Lcom/google/android/recaptcha/internal/zzlv;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzmu;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "ezz"

    const-string/jumbo v0, "zze"

    const/4 v2, 0x3

    const-string/jumbo v0, "zze"

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    aput-object v0, p1, p3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string p3, "dzz"

    const-string/jumbo p3, "zdz"

    const/4 v2, 0x3

    const-string p3, "dzz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x2

    const/4 v1, 0x1

    aput-object p3, p1, p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p2, Lcom/google/android/recaptcha/internal/zzmu;->zzb:Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p3, "/fs0008>00uuu/0fuur/0u0c0Cuu0uu00/0=00000u000/0/0u0/0/0/0B0/0u000u/0100030010u0u000/0000/00/b>u00/u0u00//00u?/0t000000f0/00Bu0u04//501uu//u0u00?0000003u000/00u0:0/u000/:0/2/n000//u02b000uu0/f//000200/003/e00/00u0/00u000760/u/000000u0600u30/u40/0b000/u00"

    const/4 v2, 0x0

    const-string p3, "0/s00/07u00u020/00000/u000/t/03/40000360/u0>10/0u00010///0u00n/00060B/2b0/uB000ubu/0/00?fu0r000u00002u0uu00/u>0/00u1u0=000?0u04/0/00/0c000030u50/:/000//0u000u000e/00u000u0//0fu000u0//C000000u/0/f0uu003000u0000//000/000/uuu0/u/00008uu00/uf/0u/:00000u0ub0"

    const-string p3, "\u0000\u000f\u0001\u0000\u0001\u000f\u000f\u0000\u0000\u0000\u0001>\u0000\u0002:\u0000\u0003=\u0000\u0004\u023b\u0000\u0005B\u0000\u0006B\u0000\u0007>\u0000\u0008C\u0000\t6\u0000\n4\u0000\u000b3\u0000\u000c\u023b\u0000\r:\u0000\u000e?\u0000\u000f?\u0000"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1

    :cond_4
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method public final zzi()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method public final zzj()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public final zzk()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zzd:I

    const/4 v3, 0x0

    const/4 v1, 0x6

    const/4 v3, 0x7

    move v2, v1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmu;->zze:Ljava/lang/Object;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0
.end method
