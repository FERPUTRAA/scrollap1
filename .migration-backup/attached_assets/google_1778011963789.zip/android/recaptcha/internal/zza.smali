.class final Lcom/google/android/recaptcha/internal/zza;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# instance fields
.field final synthetic zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field final synthetic zzb:Lkotlinx/coroutines/c1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/tasks/TaskCompletionSource;Lkotlinx/coroutines/c1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zza;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/recaptcha/internal/zza;->zzb:Lkotlinx/coroutines/c1;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public final bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@is-  @ lio b@@~@ o@~ @~nv~ ~/i~~/~@~@@dy~o@K~~s@@S~~  a@b@@4M ~ro ~tob~m@ .foc~ f~@    ~~ul@@t~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zza;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x4

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/Exception;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setException(Ljava/lang/Exception;)V

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zza;->zzb:Lkotlinx/coroutines/c1;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p1}, Lkotlinx/coroutines/c1;->getCompletionExceptionOrNull()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zza;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zza;->zzb:Lkotlinx/coroutines/c1;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/c1;->getCompleted()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zza;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, p1, Ljava/lang/Exception;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v1, Ljava/lang/Exception;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lcom/google/android/gms/tasks/RuntimeExecutionException;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1, p1}, Lcom/google/android/gms/tasks/RuntimeExecutionException;-><init>(Ljava/lang/Throwable;)V

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setException(Ljava/lang/Exception;)V

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1
.end method
