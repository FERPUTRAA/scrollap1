.class final Lcom/google/android/recaptcha/internal/zzet;
.super Lcom/google/android/recaptcha/internal/zzew;


# instance fields
.field private final zzc:I


# direct methods
.method constructor <init>([BII)V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzew;-><init>([B)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    array-length p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzez;->zzk(III)I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p3, p0, Lcom/google/android/recaptcha/internal/zzet;->zzc:I

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final zza(I)B
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "rms@o~  @~/~~~bf~@~~~@ @u~  o/@t~il@i~ @o ~d t@ .~~ ~@ySo@~@~nl oi@@  ~-1s@  @b@MK@a~c~ov~@@ bf "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzet;->zzc:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-int/lit8 v1, p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    sub-int v1, v0, v1

    const/4 v5, 0x6

    or-int/2addr v1, p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-gez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-gez p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "xn ms < d0:"

    const-string v2, " <sdne x0: "

    const/4 v5, 0x5

    const-string v2, "<en:o  I0x "

    const-string v2, "Index < 0: "

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    move v5, v4

    throw v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v3, ":h>m tnxdnlI g e"

    const/4 v5, 0x3

    const-string v3, ">h n:btlxe en dg"

    const-string v3, "Index > length: "

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string p1, ", "

    const-string p1, ", "

    const/4 v5, 0x5

    const-string p1, ", "

    const-string p1, ", "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-direct {v1, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzew;->zza:[B

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    aget-byte p1, v0, p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    return p1
.end method

.method final zzb(I)B
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzew;->zza:[B

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    aget-byte p1, v0, p1

    const/4 v1, 0x4

    move v2, v1

    return p1
.end method

.method protected final zzc()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final zzd()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzet;->zzc:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method protected final zze([BIII)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/recaptcha/internal/zzew;->zza:[B

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p3, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p2, p3, p1, p3, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
