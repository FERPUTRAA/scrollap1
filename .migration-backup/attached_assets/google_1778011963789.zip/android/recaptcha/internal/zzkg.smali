.class public final Lcom/google/android/recaptcha/internal/zzkg;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzkg;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/recaptcha/internal/zzfw;

.field private zzf:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzkg;-><init>()V

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/recaptcha/internal/zzkg;->zzb:Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v2, 0x3

    move v3, v2

    const-class v1, Lcom/google/android/recaptcha/internal/zzkg;

    const-class v1, Lcom/google/android/recaptcha/internal/zzkg;

    const-class v1, Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public static zzf()Lcom/google/android/recaptcha/internal/zzkf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@fno@b~@ @bd@~s~f-S~iyaK~~.~~u ~t 4~@ @@b~ /@ @~@~ io~ot ~@@o~~ / o ~vc@@@  M~o ~l@~i1l ~ m@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/recaptcha/internal/zzkg;->zzb:Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzp()Lcom/google/android/recaptcha/internal/zzgi;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/recaptcha/internal/zzkf;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzg()Lcom/google/android/recaptcha/internal/zzkg;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/recaptcha/internal/zzkg;->zzb:Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzi(Lcom/google/android/recaptcha/internal/zzkg;Lcom/google/android/recaptcha/internal/zzfw;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzkg;->zze:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget p1, p0, Lcom/google/android/recaptcha/internal/zzkg;->zzd:I

    const/4 v0, 0x2

    move v1, v0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/recaptcha/internal/zzkg;->zzd:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzj(Lcom/google/android/recaptcha/internal/zzkg;I)V
    .locals 2

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/recaptcha/internal/zzkg;->zzf:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p3, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eq p1, v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq p1, p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p2, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p3, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq p1, p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p2, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq p1, p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p3

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object p1, Lcom/google/android/recaptcha/internal/zzkg;->zzb:Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v3, 0x1

    return-object p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p1, Lcom/google/android/recaptcha/internal/zzkf;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzkf;-><init>(Lcom/google/android/recaptcha/internal/zzke;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_2
    new-instance p1, Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzkg;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "zzd"

    const-string v1, "dzz"

    const/4 v3, 0x0

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    aput-object v1, p1, p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const/4 v3, 0x2

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x5

    aput-object p3, p1, p2

    const/4 v2, 0x3

    or-int/2addr v3, v2

    const-string p2, "fzz"

    const-string p2, "fzz"

    const/4 v3, 0x4

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p2, p1, v0

    const/4 v2, 0x6

    move v3, v2

    sget-object p2, Lcom/google/android/recaptcha/internal/zzkg;->zzb:Lcom/google/android/recaptcha/internal/zzkg;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p3, "uu0m/00000200uu012u///000000u00000u2000u//0/u00/41u00000010u000/00/0/00u000uu/0/0u21/0s000"

    const-string p3, "/0s/00/010000u00/0000u/000020u00/020000000100u00200/uu1/001/0u0u//u2/u0000u0uu9000/u0/u040"

    const/4 v3, 0x7

    const-string/jumbo p3, "u000o2u10u0u0u0000u0000020/00//01u00000//2000200//000u/04010/0/00/0u0uu000/u0u0u0100090u//"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u0004"

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p1
.end method
