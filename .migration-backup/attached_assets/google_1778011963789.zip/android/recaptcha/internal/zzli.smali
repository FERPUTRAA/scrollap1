.class public final Lcom/google/android/recaptcha/internal/zzli;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlj;->zzg()Lcom/google/android/recaptcha/internal/zzlj;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzlh;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlj;->zzg()Lcom/google/android/recaptcha/internal/zzlj;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zzd(Lcom/google/android/recaptcha/internal/zzkj;)Lcom/google/android/recaptcha/internal/zzli;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~tsbl~1@nm~ i~~~ i@ ~@ t~S@@ @/s@o~@o  u@  ~@~~@~@.o@M~~d@ ~ vyo4@c @~@forb l~bKfo-~a~  /i@ ~@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlj;->zzG(Lcom/google/android/recaptcha/internal/zzlj;Lcom/google/android/recaptcha/internal/zzkj;)V

    const/4 v2, 0x6

    return-object p0
.end method

.method public final zze(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzli;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlj;->zzk(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public final zzp(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzli;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlj;->zzj(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public final zzq(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzli;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzlj;->zzi(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method
