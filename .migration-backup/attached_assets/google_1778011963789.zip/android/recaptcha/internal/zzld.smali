.class public final Lcom/google/android/recaptcha/internal/zzld;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzld;


# instance fields
.field private zzd:I

.field private zze:Ljava/lang/Object;

.field private zzf:Lcom/google/android/recaptcha/internal/zzlg;

.field private zzg:I

.field private zzh:Lcom/google/android/recaptcha/internal/zzkm;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/recaptcha/internal/zzld;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzld;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/recaptcha/internal/zzld;->zzb:Lcom/google/android/recaptcha/internal/zzld;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/recaptcha/internal/zzld;

    const-class v1, Lcom/google/android/recaptcha/internal/zzld;

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/recaptcha/internal/zzld;

    const-class v1, Lcom/google/android/recaptcha/internal/zzld;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/recaptcha/internal/zzld;->zzd:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzld;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4lsb c@@~@~/~iv@@@S~ /@d@~~f~ia~~ @o~uo@ ~ n~@  t@rbo~y @.K ~ ts @ -@ ~@mb@1 ~l M~o i~@~@~o~~ @f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/recaptcha/internal/zzld;->zzb:Lcom/google/android/recaptcha/internal/zzld;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p2, 0x1

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 p3, 0x2

    const/4 p3, 0x5

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v0, 0x4

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq p1, v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eq p1, v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 p2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq p1, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eq p1, p3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object p2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    sget-object p1, Lcom/google/android/recaptcha/internal/zzld;->zzb:Lcom/google/android/recaptcha/internal/zzld;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object p1

    :cond_1
    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlc;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p1, p2}, Lcom/google/android/recaptcha/internal/zzlc;-><init>(Lcom/google/android/recaptcha/internal/zzlb;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object p1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/recaptcha/internal/zzld;

    const/4 v4, 0x5

    const/4 v4, 0x4

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzld;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object p1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 p3, 0x0

    const/4 v5, 0x1

    move v4, p3

    const/4 v5, 0x2

    const-string/jumbo v3, "zez"

    const-string/jumbo v3, "zze"

    const/4 v5, 0x7

    const-string/jumbo v3, "zze"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    aput-object v3, p1, p3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo p3, "zdz"

    const/4 v5, 0x3

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zzd"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object p3, p1, p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zfz"

    const/4 v5, 0x4

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    aput-object p2, p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    aput-object p2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo p2, "zhz"

    const-string p2, "hzz"

    const/4 v5, 0x5

    const-string/jumbo p2, "zzh"

    const-string/jumbo p2, "zzh"

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object p2, p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    sget-object p2, Lcom/google/android/recaptcha/internal/zzld;->zzb:Lcom/google/android/recaptcha/internal/zzld;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string p3, "0us000u0u00u000/u00?/0uu0/0u1u0/0?10?u0/60040?1000/001/00/000u00/u1//7/u/t?000000///0u0010/c0u00u/000u50uu000/0/tu00/0230fu0/?u00000uu00u/402000ue0007/u00u0/0/u0u?00/080u/?00001/0000uu0u/?1n050006u000//0??//00u/0/01u0010r0?001u0//0u0cu00/?000u/u/10b7//000000u00/0u0?0/u000?0/1u0?ut?0u0//?0000/00/1/0/00000u000017?0u00/0000//0u/0000300?0"

    const/4 v5, 0x0

    const-string/jumbo p3, "u0um?000//00u00?/c/uu100uu/7000600016u00ur0000000ub0u0/u0/?0/?00ut/00/u0/0uu00///0u/700100u01u/0000/0t14/00u?0000u0050/01004u001000002/00?e?/00?/////30/021000500/?000??/uu0u0000u?00?7/u0u0c000/0u/0700u0?u3000u000u1f0010/00/u70u000t0/0000/000?0u000u0?u00/10u///100u00//100/00000u/0/0/080000//u0u0//0/00/u/0uu/0000?00uu0u0/0?0000nu10u/?1?"

    const-string p3, "\u0000\u0017\u0001\u0000\u0001\u0017\u0017\u0000\u0000\u0000\u0001\t\u0002\u000c\u0003\t\u0004?\u0000\u0005?\u0000\u0006?\u0000\u0007?\u0000\u0008?\u0000\t?\u0000\n?\u0000\u000b?\u0000\u000c?\u0000\r?\u0000\u000e?\u0000\u000f?\u0000\u0010?\u0000\u0011?\u0000\u0012?\u0000\u0013?\u0000\u0014?\u0000\u0015?\u0000\u0016?\u0000\u0017?\u0000"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p1

    :cond_4
    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p1
.end method
