.class final Lcom/google/android/recaptcha/internal/zzcw;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# instance fields
.field zza:Ljava/lang/Object;

.field zzb:Ljava/lang/Object;

.field zzc:Ljava/lang/Object;

.field zzd:I

.field final synthetic zze:Lcom/google/android/recaptcha/RecaptchaAction;

.field final synthetic zzf:Lcom/google/android/recaptcha/internal/zzda;

.field final synthetic zzg:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/google/android/recaptcha/RecaptchaAction;Lcom/google/android/recaptcha/internal/zzda;Ljava/lang/String;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zze:Lcom/google/android/recaptcha/RecaptchaAction;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzf:Lcom/google/android/recaptcha/internal/zzda;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzg:Ljava/lang/String;

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "K~s ~~  @i@i@oy~~@4~@~@  M ~@~~@~@@o~Smo @~l~- @/1/cbt f.r   ~l~u n@sa@i@t~@b~@bo~~~@v@d   @o fo"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance p1, Lcom/google/android/recaptcha/internal/zzcw;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzcw;->zze:Lcom/google/android/recaptcha/RecaptchaAction;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzf:Lcom/google/android/recaptcha/internal/zzda;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzg:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p1, v0, v1, v2, p2}, Lcom/google/android/recaptcha/internal/zzcw;-><init>(Lcom/google/android/recaptcha/RecaptchaAction;Lcom/google/android/recaptcha/internal/zzda;Ljava/lang/String;Lkotlin/coroutines/d;)V

    const/4 v3, 0x1

    move v4, v3

    return-object p1
.end method

.method public final bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/recaptcha/internal/zzcw;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/recaptcha/internal/zzcw;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Lcom/google/android/recaptcha/internal/zzcw;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget v1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzd:I

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz v1, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x6

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzf:Lcom/google/android/recaptcha/internal/zzda;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v5, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzg:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zze:Lcom/google/android/recaptcha/RecaptchaAction;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zza:Ljava/lang/Object;

    const/4 v11, 0x5

    iput-object v5, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzb:Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    iput-object v1, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzc:Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v2, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    iput v2, p0, Lcom/google/android/recaptcha/internal/zzcw;->zzd:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v7, Lkotlinx/coroutines/r;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {p0}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v7, v3, v2}, Lkotlinx/coroutines/r;-><init>(Lkotlin/coroutines/d;I)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v7}, Lkotlinx/coroutines/r;->R()V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzda;->zzl(Lcom/google/android/recaptcha/internal/zzda;)Ljava/util/Map;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-interface {v2, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzmb;->zzf()Lcom/google/android/recaptcha/internal/zzma;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2, v5}, Lcom/google/android/recaptcha/internal/zzma;->zze(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzma;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1}, Lcom/google/android/recaptcha/RecaptchaAction;->getAction()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v2, v1}, Lcom/google/android/recaptcha/internal/zzma;->zzd(Ljava/lang/String;)Lcom/google/android/recaptcha/internal/zzma;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v2}, Lcom/google/android/recaptcha/internal/zzgi;->zzh()Lcom/google/android/recaptcha/internal/zzgo;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    check-cast v1, Lcom/google/android/recaptcha/internal/zzmb;

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v1}, Lcom/google/android/recaptcha/internal/zzei;->zzd()[B

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzeb;->zzh()Lcom/google/android/recaptcha/internal/zzeb;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    array-length v3, v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    const/4 v4, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v2, v1, v4, v3}, Lcom/google/android/recaptcha/internal/zzeb;->zzi([BII)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v1, Lcom/google/android/recaptcha/internal/zzai;->zza:Lcom/google/android/recaptcha/internal/zzai;

    const/4 v11, 0x2

    const/4 v10, 0x2

    new-instance v9, Lcom/google/android/recaptcha/internal/zzaf;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    sget-object v2, Lcom/google/android/recaptcha/internal/zzkw;->zzf:Lcom/google/android/recaptcha/internal/zzkw;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzda;->zzh(Lcom/google/android/recaptcha/internal/zzda;)Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzda;->zzi(Lcom/google/android/recaptcha/internal/zzda;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v6, 0x0

    move-object v1, v9

    move-object v1, v9

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct/range {v1 .. v6}, Lcom/google/android/recaptcha/internal/zzaf;-><init>(Lcom/google/android/recaptcha/internal/zzkw;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzda;->zza(Lcom/google/android/recaptcha/internal/zzda;)Landroid/content/Context;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzda;->zzc(Lcom/google/android/recaptcha/internal/zzda;)Lcom/google/android/recaptcha/internal/zzr;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v9, v1, v2}, Lcom/google/android/recaptcha/internal/zzai;->zzc(Lcom/google/android/recaptcha/internal/zzaf;Landroid/content/Context;Lcom/google/android/recaptcha/internal/zzr;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {p1}, Lcom/google/android/recaptcha/internal/zzda;->zzb()Landroid/webkit/WebView;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-string v2, "atsMctcepaier./mn(x.ecah.ue"

    const/4 v11, 0x3

    const-string/jumbo v2, "recaptcha.m.Main.execute(\""

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v2, ")//"

    const-string v2, ")//"

    const/4 v11, 0x7

    const-string v2, "//)"

    const-string v2, "\")"

    const/4 v11, 0x7

    const/4 v10, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v2, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-virtual {v7}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x5

    if-ne p1, v1, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {p0}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_1
    const/4 v11, 0x0

    if-ne p1, v0, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    return-object v0

    :cond_2
    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    return-object p1
.end method
