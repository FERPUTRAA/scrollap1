.class public final Lcom/google/android/recaptcha/internal/zzlo;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlp;->zzf()Lcom/google/android/recaptcha/internal/zzlp;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzln;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzlp;->zzf()Lcom/google/android/recaptcha/internal/zzlp;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
