.class public final Lcom/google/android/recaptcha/internal/zzmh;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzmh;


# instance fields
.field private zzd:Lcom/google/android/recaptcha/internal/zzgv;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzmh;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/recaptcha/internal/zzmh;->zzb:Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/recaptcha/internal/zzmh;

    const-class v1, Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/recaptcha/internal/zzmh;

    const-class v1, Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzgo;->zzw()Lcom/google/android/recaptcha/internal/zzgv;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzmh;->zzd:Lcom/google/android/recaptcha/internal/zzgv;

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzmh;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c~s@ o4 a@~~~bis~/@b @o~ d@lo lm~@  u. i~  S ~o 1~@@@~n@@Mi~~ov@t~f~ Ky  ~@-t@br~@~fo @@~~/ @@~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/recaptcha/internal/zzmh;->zzb:Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object v0
.end method

.method public static zzg([B)Lcom/google/android/recaptcha/internal/zzmh;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/recaptcha/internal/zzgy;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/recaptcha/internal/zzmh;->zzb:Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/android/recaptcha/internal/zzgo;->zzu(Lcom/google/android/recaptcha/internal/zzgo;[B)Lcom/google/android/recaptcha/internal/zzgo;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p0, Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p2, 0x1

    const/4 v1, 0x1

    move v2, v1

    if-eqz p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p3, 0x2

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    if-eq p1, p3, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq p1, p2, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p2, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 p3, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq p1, p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p2, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eq p1, p2, :cond_0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p3

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object p1, Lcom/google/android/recaptcha/internal/zzmh;->zzb:Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    return-object p1

    :cond_1
    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p1, Lcom/google/android/recaptcha/internal/zzmg;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzmg;-><init>(Lcom/google/android/recaptcha/internal/zzlv;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x0

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzmh;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zdz"

    const/4 v2, 0x1

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    aput-object v0, p1, p3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-class p3, Lcom/google/android/recaptcha/internal/zzmv;

    const/4 v2, 0x5

    const-class p3, Lcom/google/android/recaptcha/internal/zzmv;

    const-class p3, Lcom/google/android/recaptcha/internal/zzmv;

    const/4 v2, 0x7

    aput-object p3, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object p2, Lcom/google/android/recaptcha/internal/zzmh;->zzb:Lcom/google/android/recaptcha/internal/zzmh;

    const/4 v2, 0x4

    const-string p3, "/00m/000/1u000/0u10000010u/0100/0uu0u00s0/0/00u0b11u0/0u00//1/0000000uu0"

    const-string p3, "00s00000/1/0b000/u0u0000/0uu/u1011/1100/0000u0uu//0000000/u0u0/00u10u00/"

    const-string p3, "/100o/00001/u/0u0001u00/0000uu/10/010b0u0/0u000/0u0u0u000/0u00//1u010000"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1

    :cond_4
    const/4 v2, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1
.end method

.method public final zzi()Ljava/util/List;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzmh;->zzd:Lcom/google/android/recaptcha/internal/zzgv;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method
