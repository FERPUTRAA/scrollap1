.class public final Lcom/google/android/recaptcha/internal/zzmi;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzmj;->zzg()Lcom/google/android/recaptcha/internal/zzmj;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzlv;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzmj;->zzg()Lcom/google/android/recaptcha/internal/zzmj;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zzd(I)Lcom/google/android/recaptcha/internal/zzmi;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bbs@o-@ @n @~@~@@rtlM@@@.o @~ @@/~bKo ~~i~ lS vy 1 ~o@ ~c~@~@fotmsf @~~/a ~ ~i ~i @@4o~@~d ~~~u~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x6

    const/4 v1, 0x6

    check-cast v0, Lcom/google/android/recaptcha/internal/zzmj;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzmj;->zzi(Lcom/google/android/recaptcha/internal/zzmj;I)V

    const/4 v1, 0x0

    move v2, v1

    return-object p0
.end method

.method public final zze(I)Lcom/google/android/recaptcha/internal/zzmi;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/recaptcha/internal/zzmj;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzmj;->zzH(Lcom/google/android/recaptcha/internal/zzmj;I)V

    return-object p0
.end method

.method public final zzp(I)Lcom/google/android/recaptcha/internal/zzmi;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzm()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/recaptcha/internal/zzmj;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzmj;->zzG(Lcom/google/android/recaptcha/internal/zzmj;I)V

    const/4 v2, 0x4

    return-object p0
.end method
