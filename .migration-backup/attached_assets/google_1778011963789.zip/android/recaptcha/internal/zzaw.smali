.class final Lcom/google/android/recaptcha/internal/zzaw;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# instance fields
.field final synthetic zza:Lcom/google/android/recaptcha/internal/zzba;


# direct methods
.method constructor <init>(Lcom/google/android/recaptcha/internal/zzba;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzaw;->zza:Lcom/google/android/recaptcha/internal/zzba;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ simo~~ yo bMbt@@ @Kn@~  ob~v@~@ 1l@~d ~@  @o@@~ ~4 ~.f-@c@ it~ o~r@@~~if~ ~~S @@~l//~u~s @~@~a"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/recaptcha/internal/zzmu;

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-object p1
.end method
