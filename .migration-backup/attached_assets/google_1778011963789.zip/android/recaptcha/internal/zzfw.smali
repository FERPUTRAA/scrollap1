.class public final Lcom/google/android/recaptcha/internal/zzfw;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzfw;


# instance fields
.field private zzd:J

.field private zze:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzfw;-><init>()V

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/recaptcha/internal/zzfw;->zzb:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/recaptcha/internal/zzfw;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/recaptcha/internal/zzfw;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static zzi()Lcom/google/android/recaptcha/internal/zzfv;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sbo~ @@iiy~ mr4~@lu1-bo@~@MKb.o~~ @S l@o~@@ t @ct~n@  @ i~@ ~@fsd~~~@~~@ v~ ~o@ ~ ~@o~a/ /f@@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/recaptcha/internal/zzfw;->zzb:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzp()Lcom/google/android/recaptcha/internal/zzgi;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/recaptcha/internal/zzfv;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzj()Lcom/google/android/recaptcha/internal/zzfw;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    sget-object v0, Lcom/google/android/recaptcha/internal/zzfw;->zzb:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzk(Lcom/google/android/recaptcha/internal/zzfw;J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/google/android/recaptcha/internal/zzfw;->zzd:J

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic zzl(Lcom/google/android/recaptcha/internal/zzfw;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/recaptcha/internal/zzfw;->zze:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final zzf()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/recaptcha/internal/zzfw;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public final zzg()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/google/android/recaptcha/internal/zzfw;->zzd:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-wide v0
.end method

.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 p2, 0x3

    const/4 v2, 0x2

    const/4 p2, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p3, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p1, p3, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p2, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eq p1, p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x1

    const/4 p3, 0x3

    const/4 v2, 0x0

    const/4 p3, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eq p1, p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p2, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eq p1, p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p3

    :cond_0
    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object p1, Lcom/google/android/recaptcha/internal/zzfw;->zzb:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/recaptcha/internal/zzfv;

    const/4 v2, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzfv;-><init>(Lcom/google/android/recaptcha/internal/zzfu;)V

    const/4 v1, 0x0

    move v2, v1

    return-object p1

    :cond_2
    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzfw;-><init>()V

    const/4 v2, 0x5

    return-object p1

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    aput-object v0, p1, p3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string p3, "ezz"

    const-string p3, "ezz"

    const/4 v2, 0x0

    const-string/jumbo p3, "zze"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    aput-object p3, p1, p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p2, Lcom/google/android/recaptcha/internal/zzfw;->zzb:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p3, Lcom/google/android/recaptcha/internal/zzij;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "0/0m01us/0uu0020/u0/u/u000u000/0u00u0u0000/20//00u004u020000/0u/02001000002//0/0000u"

    const-string v0, "00s00uu00/20u2u001000u//0//10/uu00000u00/0/u000000000//00u/0u2/uu0/02u0000/000200400"

    const/4 v2, 0x2

    const-string v0, "2000o00u0u001/0104u000/0/0uu0000u/00u/20/000u/0002000/000000/2000u//u2u/0/u0/00000u0"

    const-string v0, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0004"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p3, p2, v0, p1}, Lcom/google/android/recaptcha/internal/zzij;-><init>(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x3

    return-object p3

    :cond_4
    const/4 v2, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method
