.class public final Lcom/google/android/recaptcha/internal/zzkp;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzkp;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Ljava/lang/String;

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;

.field private zzh:Ljava/lang/String;

.field private zzi:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzkp;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/recaptcha/internal/zzkp;->zzb:Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/recaptcha/internal/zzkp;

    const-class v1, Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zzd:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zze:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zzf:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zzg:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zzh:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzkp;->zzi:Ljava/lang/String;

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzkp;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t~s@~u @~@b@  @@l~o  ~.o@~ir fm ~i1oS~c~i o@~M@ a~o ~@@o~~ - ~ @@~@~~n~@f~b~//@4y v@@b K@sdt~  l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/recaptcha/internal/zzkp;->zzb:Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 p2, 0x1

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 p3, 0x5

    const/4 v5, 0x2

    move v6, v5

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v6, 0x6

    const/4 v1, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eq p1, v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq p1, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 p2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eq p1, v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eq p1, p3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-object p2

    :cond_0
    const/4 v5, 0x7

    const/4 v6, 0x1

    sget-object p1, Lcom/google/android/recaptcha/internal/zzkp;->zzb:Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-object p1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance p1, Lcom/google/android/recaptcha/internal/zzko;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/recaptcha/internal/zzko;-><init>(Lcom/google/android/recaptcha/internal/zzkn;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object p1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance p1, Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzkp;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object p1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 p1, 0x6

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v4, "zzd"

    const-string/jumbo v4, "zzd"

    const/4 v6, 0x3

    const-string/jumbo v4, "zzd"

    const-string/jumbo v4, "zzd"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    aput-object v4, p1, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v3, "zze"

    const-string v3, "ezz"

    const/4 v6, 0x6

    const-string v3, "ezz"

    const-string/jumbo v3, "zze"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    aput-object v3, p1, p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zfz"

    const/4 v6, 0x2

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v6, 0x3

    aput-object p2, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo p2, "zzg"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    aput-object p2, p1, v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x7

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    aput-object p2, p1, v0

    const/4 v6, 0x2

    const-string/jumbo p2, "izz"

    const-string/jumbo p2, "ziz"

    const/4 v6, 0x5

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    aput-object p2, p1, p3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object p2, Lcom/google/android/recaptcha/internal/zzkp;->zzb:Lcom/google/android/recaptcha/internal/zzkp;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const-string/jumbo p3, "u02m0s008uu02u000604/00020u008/801/u6/u00//002u/0uu25000/u08uu030000/u8000uu/060u8//0/1000/0uu00000/0/0/000/6000u000/0//0000u200/00u"

    const-string p3, "/0s0/8868u0000///54200/0u/200u0600000u00/u00u/000u/00u8/0/u0u002/0/00u0280u0/00000006u008000/uuu12u/002//0030uu000u1/0060u00/00/200u"

    const-string p3, "6081ou0000u/00u0uu/00//00/u/00/8u2u/86u00088/00022000000u0/0/022//00004uu0/000/00000200uu0uu030u0005u000060uu/00//000///0u800126/u00"

    const-string p3, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0208\u0002\u0208\u0003\u0208\u0004\u0208\u0005\u0208\u0006\u0208"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    return-object p1

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-object p1
.end method
