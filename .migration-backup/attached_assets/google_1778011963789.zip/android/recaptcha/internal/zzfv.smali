.class public final Lcom/google/android/recaptcha/internal/zzfv;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzfw;->zzj()Lcom/google/android/recaptcha/internal/zzfw;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzfu;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzfw;->zzj()Lcom/google/android/recaptcha/internal/zzfw;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zzd(I)Lcom/google/android/recaptcha/internal/zzfv;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sy@@obKr@t@~ .~  ~~/tu @@-~~1l@Msc  @ o ob  ~@m o~~~@~~f@~~io@d@  @4v~~ a f@~So~@i@~~@i@@b/ nl"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzF()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzn()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/android/recaptcha/internal/zzfw;->zzl(Lcom/google/android/recaptcha/internal/zzfw;I)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public final zze(J)Lcom/google/android/recaptcha/internal/zzfv;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzF()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/recaptcha/internal/zzgi;->zzn()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzgi;->zza:Lcom/google/android/recaptcha/internal/zzgo;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1, p2}, Lcom/google/android/recaptcha/internal/zzfw;->zzk(Lcom/google/android/recaptcha/internal/zzfw;J)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method
