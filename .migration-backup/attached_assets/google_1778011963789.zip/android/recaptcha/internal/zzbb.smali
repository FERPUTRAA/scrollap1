.class final Lcom/google/android/recaptcha/internal/zzbb;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# instance fields
.field final synthetic zza:[Ljava/lang/String;

.field final synthetic zzb:Lcom/google/android/recaptcha/internal/zzbc;

.field final synthetic zzc:Ljava/lang/String;


# direct methods
.method constructor <init>([Ljava/lang/String;Lcom/google/android/recaptcha/internal/zzbc;Ljava/lang/String;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzbb;->zza:[Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzb:Lcom/google/android/recaptcha/internal/zzbc;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzc:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  s@S@b~~~@~@l@~~of@~ i1K ~@~~@@l@uom~@bo~  ~   io4~~~ oi  cM~a- @~~y@@ d@~~~vbr @  ostf@@n/t/.@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance p1, Lcom/google/android/recaptcha/internal/zzbb;

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/recaptcha/internal/zzbb;->zza:[Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzb:Lcom/google/android/recaptcha/internal/zzbc;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzc:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p1, v0, v1, v2, p2}, Lcom/google/android/recaptcha/internal/zzbb;-><init>([Ljava/lang/String;Lcom/google/android/recaptcha/internal/zzbc;Ljava/lang/String;Lkotlin/coroutines/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p1
.end method

.method public final bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v0, 0x3

    move v1, v0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/recaptcha/internal/zzbb;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p1, Lcom/google/android/recaptcha/internal/zzbb;

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/recaptcha/internal/zzbb;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zzbb;->zza:[Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    array-length v1, p1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-ge v2, v1, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    aget-object v3, p1, v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string v5, "//"

    const-string v5, "//"

    const/4 v11, 0x7

    const-string v5, "//"

    const-string v5, "\""

    const/4 v11, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    invoke-interface {v0, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    goto :goto_0

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzb:Lcom/google/android/recaptcha/internal/zzbc;

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-static {p1}, Lcom/google/android/recaptcha/internal/zzbc;->zza(Lcom/google/android/recaptcha/internal/zzbc;)Landroid/webkit/WebView;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v9, p0, Lcom/google/android/recaptcha/internal/zzbb;->zzc:Ljava/lang/String;

    const/4 v11, 0x2

    const-string v1, ","

    const-string v1, ","

    const/4 v11, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v2, 0x0

    shr-int/2addr v11, v2

    const/4 v10, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v3, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v5, 0x0

    const/4 v11, 0x5

    const/4 v6, 0x0

    const/4 v11, 0x5

    const/4 v6, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/16 v7, 0x3e

    const/4 v10, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v8, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static/range {v0 .. v8}, Lkotlin/collections/u;->j3(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Li8/l;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string v2, "("

    const-string v2, "("

    const/4 v11, 0x5

    const-string v2, "("

    const-string v2, "("

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const-string v0, ")"

    const-string v0, ")"

    const/4 v11, 0x3

    const-string v0, ")"

    const-string v0, ")"

    const/4 v11, 0x4

    const/4 v10, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v1, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    return-object p1
.end method
