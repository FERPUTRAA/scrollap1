.class public final Lcom/google/android/recaptcha/internal/zzlx;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzlx;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Ljava/lang/String;

.field private zzf:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzlx;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/recaptcha/internal/zzlx;->zzb:Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/recaptcha/internal/zzlx;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlx;->zzd:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlx;->zze:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlx;->zzf:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzlx;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sl~f~@@rio~ o~@~d~@@@~f~/@@ @1~a  4Svt  M ~t/ @@ @@@i.~~~~Kois-@o~@ b~~bolcy@o nb m u~@ ~ ~ @ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlx;->zzb:Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x0

    const/4 p2, 0x0

    const/4 p2, 0x1

    move v3, p2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x5

    and-int/2addr v3, v2

    const/4 p3, 0x2

    const/4 p3, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq p1, v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eq p1, p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p2, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq p1, p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p2, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eq p1, p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p3

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object p1, Lcom/google/android/recaptcha/internal/zzlx;->zzb:Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p1

    :cond_1
    const/4 v3, 0x1

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlw;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzlw;-><init>(Lcom/google/android/recaptcha/internal/zzlv;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzlx;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p3, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zdz"

    const/4 v3, 0x0

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    aput-object p3, p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v3, 0x4

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    aput-object p2, p1, v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object p2, Lcom/google/android/recaptcha/internal/zzlx;->zzb:Lcom/google/android/recaptcha/internal/zzlx;

    const/4 v3, 0x6

    const-string p3, "0//mu00u0003/00000300u020002u/0/000/030008u/000/uu110u2u/uu/0/800080000000/000u00s/uu0/u30u0//00"

    const-string p3, "0us0u0803/0000//100/u80000/u/u20/u00u30u20003800000000u0210u0//300u/u0000000u2u0//0000////00uu00"

    const/4 v3, 0x1

    const-string p3, "2300o0030/00/0880u/03210u/0/02u/u/u00000u1uu00008/0u00u00/000/0/0200u0//300000u000uu0u0000u//000"

    const-string p3, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0208\u0002\u0208\u0003\u0208"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1
.end method
