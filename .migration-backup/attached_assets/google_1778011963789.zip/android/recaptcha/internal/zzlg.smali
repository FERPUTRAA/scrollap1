.class public final Lcom/google/android/recaptcha/internal/zzlg;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzlg;


# instance fields
.field private zzd:Lcom/google/android/recaptcha/internal/zzfw;

.field private zze:Lcom/google/android/recaptcha/internal/zzjd;

.field private zzf:Lcom/google/android/recaptcha/internal/zzfw;

.field private zzg:Lcom/google/android/recaptcha/internal/zzjd;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzlg;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/recaptcha/internal/zzlg;->zzb:Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/recaptcha/internal/zzlg;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlg;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlg;

    const-class v1, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzG(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzfw;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " 4s fo r~@sb@~~  l~/@tf~c~~u~@d/~@i @ ~o i ~b .~b@ oK@o~o~~~ @n@M@ m@1@o vy~ ~@@l~~a@t ~-S @@@@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlg;->zzf:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    return-void
.end method

.method public static zzf()Lcom/google/android/recaptcha/internal/zzlf;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlg;->zzb:Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzp()Lcom/google/android/recaptcha/internal/zzgi;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/recaptcha/internal/zzlf;

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-object v0
.end method

.method static synthetic zzg()Lcom/google/android/recaptcha/internal/zzlg;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlg;->zzb:Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzi(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzfw;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlg;->zzd:Lcom/google/android/recaptcha/internal/zzfw;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic zzj(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzjd;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlg;->zzg:Lcom/google/android/recaptcha/internal/zzjd;

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/recaptcha/internal/zzlg;Lcom/google/android/recaptcha/internal/zzjd;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlg;->zze:Lcom/google/android/recaptcha/internal/zzjd;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p3, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p1, v1, :cond_3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq p1, p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p3, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eq p1, p3, :cond_0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    return-object p2

    :cond_0
    const/4 v4, 0x2

    sget-object p1, Lcom/google/android/recaptcha/internal/zzlg;->zzb:Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p1

    :cond_1
    const/4 v3, 0x0

    move v4, v3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlf;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Lcom/google/android/recaptcha/internal/zzlf;-><init>(Lcom/google/android/recaptcha/internal/zzle;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzlg;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p3, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v2, "dzz"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x1

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object v2, p1, p3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const/4 v4, 0x5

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    aput-object p3, p1, p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v4, 0x0

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    aput-object p2, p1, v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x5

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput-object p2, p1, v0

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object p2, Lcom/google/android/recaptcha/internal/zzlg;->zzb:Lcom/google/android/recaptcha/internal/zzlg;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p3, "/0/m000/0/00/00100000u00/0uuu/000000t000000u0/4utt/0/0/s20/000/004/3uu/00/4uuu0t4/00u1u/0u00"

    const-string p3, "00s//u0/u/000t000/0000t0//00000u0u4/040uu0/0/0/00/0u/00100030/00uu00ut01u0/4004/0t00u0uu0/2/"

    const/4 v4, 0x6

    const-string/jumbo p3, "u/40o000t/1u0uu00t0tu00u0t01u02uuu/0//000040/u00/000//u400/00/0//00/0/0000/3u/00040u0/000000"

    const-string p3, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\t\u0002\t\u0003\t\u0004\t"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object p1
.end method
