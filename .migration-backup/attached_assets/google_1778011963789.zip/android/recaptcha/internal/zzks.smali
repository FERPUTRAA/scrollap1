.class public final Lcom/google/android/recaptcha/internal/zzks;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzks;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/recaptcha/internal/zzks;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzks;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/recaptcha/internal/zzks;->zzb:Lcom/google/android/recaptcha/internal/zzks;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/recaptcha/internal/zzks;

    const-class v1, Lcom/google/android/recaptcha/internal/zzks;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/recaptcha/internal/zzks;

    const-class v1, Lcom/google/android/recaptcha/internal/zzks;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzks;->zzd:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzks;->zze:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzks;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~K@~di/@ t~   ~ov@oy~ @@lfo~@a~M~l~ @u bi~~o~@m~~ @@S s~@~io4c~~. ~-r@f@@ @t~@ b~@b o n  ~ /@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/recaptcha/internal/zzks;->zzb:Lcom/google/android/recaptcha/internal/zzks;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 p2, 0x1

    move v2, p2

    const/4 v1, 0x6

    move v2, v1

    if-eqz p1, :cond_4

    const/4 v1, 0x6

    move v2, v1

    const/4 p3, 0x2

    const/4 p3, 0x2

    const/4 v2, 0x3

    if-eq p1, p3, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq p1, p2, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p2, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eq p1, p2, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p2, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x4

    if-eq p1, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p3

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/recaptcha/internal/zzks;->zzb:Lcom/google/android/recaptcha/internal/zzks;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzkr;

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p1, p3}, Lcom/google/android/recaptcha/internal/zzkr;-><init>(Lcom/google/android/recaptcha/internal/zzkq;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p1, Lcom/google/android/recaptcha/internal/zzks;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzks;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    aput-object v0, p1, p3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo p3, "zez"

    const-string p3, "ezz"

    const/4 v2, 0x3

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v1, 0x0

    const/4 v1, 0x1

    aput-object p3, p1, p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object p2, Lcom/google/android/recaptcha/internal/zzks;->zzb:Lcom/google/android/recaptcha/internal/zzks;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string p3, "/00m0u08u02000uu12s0/20///0/u/u00u2010/00uu/0000000000u00/0000u00/u/0800/u0/00000200"

    const-string p3, "00s0/0000200/2u00000000///u00uu002u0000/1100/0000/00/u000000//u0u20/20u2uu8/008uu00/"

    const/4 v2, 0x1

    const-string p3, "020/o20u00000201/0/0u/00/0u2u0u/20800uu/000u20/000/00uu0000u008000/000000//u010u0u//"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0208\u0002\u0208"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1
.end method
