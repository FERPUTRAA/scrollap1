.class public final Lcom/google/android/recaptcha/internal/zzfr;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzfr;


# instance fields
.field private zzd:I

.field private zze:Ljava/lang/String;

.field private zzf:Z

.field private zzg:B


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzfr;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/recaptcha/internal/zzfr;->zzb:Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/recaptcha/internal/zzfr;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzfr;

    const-class v1, Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-byte v0, p0, Lcom/google/android/recaptcha/internal/zzfr;->zzg:B

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v1, 0x0

    or-int/2addr v2, v1

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzfr;->zze:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic zzf()Lcom/google/android/recaptcha/internal/zzfr;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/recaptcha/internal/zzfr;->zzb:Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p1, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 p3, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eq p1, v2, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eq p1, v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eq p1, v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eq p1, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    move p3, v0

    move p3, v0

    const/4 v4, 0x6

    move p3, v0

    move p3, v0

    :cond_0
    const/4 v4, 0x3

    iput-byte p3, p0, Lcom/google/android/recaptcha/internal/zzfr;->zzg:B

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v2

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/recaptcha/internal/zzfr;->zzb:Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object p1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/recaptcha/internal/zzfq;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-direct {p1, v2}, Lcom/google/android/recaptcha/internal/zzfq;-><init>(Lcom/google/android/recaptcha/internal/zzfm;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzfr;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p1

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-array p1, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo p2, "zdz"

    const-string p2, "dzz"

    const/4 v4, 0x3

    const-string/jumbo p2, "zzd"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object p2, p1, v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo p2, "zze"

    const-string/jumbo p2, "zez"

    const/4 v4, 0x1

    const-string/jumbo p2, "zze"

    const-string/jumbo p2, "zze"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    aput-object p2, p1, p3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v4, 0x6

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x7

    aput-object p2, p1, v2

    const/4 v3, 0x5

    sget-object p2, Lcom/google/android/recaptcha/internal/zzfr;->zzb:Lcom/google/android/recaptcha/internal/zzfr;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p3, Lcom/google/android/recaptcha/internal/zzij;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v0, "00s00000uuu0200000uu/00/1001002001/00u/0s05070/0u00u/u0001u2u0u//u0012//u00/10105/u/00/u02//0000"

    const-string/jumbo v0, "u/su000u/00000/0u/0/u002/u0uu1/0015000u/0/0001//00u0/000/500u0010000u7u/2020u100100/0022u00u00/1"

    const/4 v4, 0x3

    const-string/jumbo v0, "u0umu20u0/0/uu201000u0/0000002080u//00u000//1//0u/u010/1u00/0/1u005000u00050u02u072/01000/010/00"

    const-string v0, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0002\u0001\u1508\u0000\u0002\u1507\u0001"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p3, p2, v0, p1}, Lcom/google/android/recaptcha/internal/zzij;-><init>(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p3

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-byte p1, p0, Lcom/google/android/recaptcha/internal/zzfr;->zzg:B

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p1
.end method
