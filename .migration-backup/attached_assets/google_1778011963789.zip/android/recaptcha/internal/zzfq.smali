.class public final Lcom/google/android/recaptcha/internal/zzfq;
.super Lcom/google/android/recaptcha/internal/zzgi;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzfr;->zzf()Lcom/google/android/recaptcha/internal/zzfr;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/recaptcha/internal/zzfm;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/android/recaptcha/internal/zzfr;->zzf()Lcom/google/android/recaptcha/internal/zzfr;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/recaptcha/internal/zzgi;-><init>(Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method
