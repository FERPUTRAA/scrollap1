.class public final Lcom/google/android/recaptcha/internal/zzlj;
.super Lcom/google/android/recaptcha/internal/zzgo;

# interfaces
.implements Lcom/google/android/recaptcha/internal/zzhz;


# static fields
.field private static final zzb:Lcom/google/android/recaptcha/internal/zzlj;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Lcom/google/android/recaptcha/internal/zzkp;

.field private zzf:Lcom/google/android/recaptcha/internal/zzkj;

.field private zzg:Lcom/google/android/recaptcha/internal/zzks;

.field private zzh:Ljava/lang/String;

.field private zzi:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/recaptcha/internal/zzlj;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/recaptcha/internal/zzlj;->zzb:Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/recaptcha/internal/zzlj;

    invoke-static {v1, v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzC(Ljava/lang/Class;Lcom/google/android/recaptcha/internal/zzgo;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/recaptcha/internal/zzgo;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzd:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzh:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzi:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic zzG(Lcom/google/android/recaptcha/internal/zzlj;Lcom/google/android/recaptcha/internal/zzkj;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "y@s@~4~@ b@nf@@~-t~.o/~l mf@c r@ oi~v~S~~t/~@ bs~ u a~@~~~d ~@~ @1io@~@o b @@~i~@M~~@   l o  @Ko"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzf:Lcom/google/android/recaptcha/internal/zzkj;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static zzf()Lcom/google/android/recaptcha/internal/zzli;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlj;->zzb:Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/recaptcha/internal/zzgo;->zzp()Lcom/google/android/recaptcha/internal/zzgi;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/recaptcha/internal/zzli;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzg()Lcom/google/android/recaptcha/internal/zzlj;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/recaptcha/internal/zzlj;->zzb:Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzi(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzd:Ljava/lang/String;

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method static synthetic zzj(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzh:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/recaptcha/internal/zzlj;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/recaptcha/internal/zzlj;->zzi:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method protected final zzh(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 p2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz p1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 p3, 0x5

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x2

    move v6, v2

    if-eq p1, v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eq p1, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 p2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x1

    if-eq p1, v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eq p1, p3, :cond_0

    const/4 v6, 0x7

    return-object p2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    sget-object p1, Lcom/google/android/recaptcha/internal/zzlj;->zzb:Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object p1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance p1, Lcom/google/android/recaptcha/internal/zzli;

    const/4 v6, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/recaptcha/internal/zzli;-><init>(Lcom/google/android/recaptcha/internal/zzlh;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object p1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance p1, Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p1}, Lcom/google/android/recaptcha/internal/zzlj;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-object p1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 p1, 0x6

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v4, "zdz"

    const-string/jumbo v4, "zzd"

    const-string/jumbo v4, "zdz"

    const-string/jumbo v4, "zzd"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    aput-object v4, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "zze"

    const-string/jumbo v3, "zze"

    const/4 v6, 0x0

    const-string/jumbo v3, "zez"

    const-string/jumbo v3, "zze"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    aput-object v3, p1, p2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v6, 0x3

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    aput-object p2, p1, v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v6, 0x4

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    aput-object p2, p1, v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string p2, "hzz"

    const-string p2, "hzz"

    const/4 v6, 0x4

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    aput-object p2, p1, v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x5

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    aput-object p2, p1, p3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    sget-object p2, Lcom/google/android/recaptcha/internal/zzlj;->zzb:Lcom/google/android/recaptcha/internal/zzlj;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string p3, "0u0m000/4//600//0/030/60u05000///2/00/00u/0u/u108/u0/000u000uu06/00t00000s1/0002u/t6008t0/u0u2uu00000u0uu0u/2/0000u08000"

    const-string p3, "0/s0001u/0u000uut0uu/2000000u000/000/0620/0u002000/8///06000000200uu0u0//t0006/u08000u0u00u00/50/086t0///03/0u4u//u00/1u"

    const/4 v6, 0x5

    const-string p3, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0208\u0002\t\u0003\t\u0004\t\u0005\u0208\u0006\u0208"

    const/4 v5, 0x0

    move v6, v5

    invoke-static {p2, p3, p1}, Lcom/google/android/recaptcha/internal/zzgo;->zzz(Lcom/google/android/recaptcha/internal/zzhy;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p1

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object p1
.end method
