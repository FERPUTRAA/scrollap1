.class public Lcom/google/android/material/transformation/FabTransformationSheetBehavior;
.super Lcom/google/android/material/transformation/FabTransformationBehavior;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field private l:Ljava/util/Map;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/transformation/FabTransformationBehavior;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/transformation/FabTransformationBehavior;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method private D(Landroid/view/View;Z)V
    .locals 9
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@ s~ @i/ o/~~  o ~@sd~by~rt@@S4@f@ @@i~@o~~~ofuM~o~ ~@ @l~loim@  .~~b1v@ @@@ ~-@b@t~@~  cKna~~~ "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    instance-of v1, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x0

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz p2, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v2, Ljava/util/HashMap;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v2, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v8, 0x7

    iput-object v2, p0, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->l:Ljava/util/Map;

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ge v3, v1, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    instance-of v5, v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v5, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v5, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    instance-of v5, v5, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v5, :cond_2

    const/4 v8, 0x4

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v5, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_1

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x0

    move v5, v2

    move v5, v2

    const/4 v8, 0x0

    move v5, v2

    move v5, v2

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eq v4, p1, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eqz v5, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    goto :goto_2

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-nez p2, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x0

    iget-object v5, p0, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->l:Ljava/util/Map;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-eqz v5, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v5, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    if-eqz v5, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object v5, p0, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->l:Ljava/util/Map;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v5, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    check-cast v5, Ljava/lang/Integer;

    const/4 v8, 0x5

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v4, v5}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_2

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v5, p0, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->l:Ljava/util/Map;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v4}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {v5, v4, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v5, 0x4

    const/4 v8, 0x6

    xor-int/2addr v7, v5

    const/4 v8, 0x5

    invoke-static {v4, v5}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    :cond_5
    :goto_2
    const/4 v8, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-nez p2, :cond_7

    const/4 v7, 0x1

    move v8, v7

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->l:Ljava/util/Map;

    :cond_7
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method protected B(Landroid/content/Context;Z)Lcom/google/android/material/transformation/FabTransformationBehavior$e;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget p2, Lcom/google/android/material/R$animator;->mtrl_fab_transformation_sheet_expand_spec:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    sget p2, Lcom/google/android/material/R$animator;->mtrl_fab_transformation_sheet_collapse_spec:I

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/material/transformation/FabTransformationBehavior$e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/material/transformation/FabTransformationBehavior$e;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, p2}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, v0, Lcom/google/android/material/transformation/FabTransformationBehavior$e;->a:Lcom/google/android/material/animation/h;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p1, Lcom/google/android/material/animation/j;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 p2, 0x11

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p1, p2, v1, v1}, Lcom/google/android/material/animation/j;-><init>(IFF)V

    const/4 v2, 0x1

    const/4 v2, 0x5

    iput-object p1, v0, Lcom/google/android/material/transformation/FabTransformationBehavior$e;->b:Lcom/google/android/material/animation/j;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method protected e(Landroid/view/View;Landroid/view/View;ZZ)Z
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/transformation/FabTransformationSheetBehavior;->D(Landroid/view/View;Z)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/android/material/transformation/ExpandableTransformationBehavior;->e(Landroid/view/View;Landroid/view/View;ZZ)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method
