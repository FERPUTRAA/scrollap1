.class public Lcom/google/android/material/transformation/FabTransformationScrimBehavior;
.super Lcom/google/android/material/transformation/ExpandableTransformationBehavior;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final h:J = 0x4bL

.field public static final i:J = 0x96L

.field public static final j:J = 0x0L

.field public static final k:J = 0x96L


# instance fields
.field private final f:Lcom/google/android/material/animation/i;

.field private final g:Lcom/google/android/material/animation/i;


# direct methods
.method public constructor <init>()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/google/android/material/transformation/ExpandableTransformationBehavior;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Lcom/google/android/material/animation/i;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const-wide/16 v1, 0x4b

    const-wide/16 v1, 0x4b

    const/4 v6, 0x2

    const-wide/16 v1, 0x4b

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-wide/16 v3, 0x96

    const-wide/16 v3, 0x96

    const/4 v6, 0x0

    const-wide/16 v3, 0x96

    const-wide/16 v3, 0x96

    const/4 v5, 0x6

    and-int/2addr v6, v5

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/android/material/animation/i;-><init>(JJ)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->f:Lcom/google/android/material/animation/i;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Lcom/google/android/material/animation/i;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/android/material/animation/i;-><init>(JJ)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->g:Lcom/google/android/material/animation/i;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/transformation/ExpandableTransformationBehavior;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance p1, Lcom/google/android/material/animation/i;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-wide/16 v0, 0x4b

    const-wide/16 v0, 0x4b

    const/4 v5, 0x5

    const-wide/16 v0, 0x4b

    const-wide/16 v0, 0x4b

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v2, 0x96

    const-wide/16 v2, 0x96

    const/4 v5, 0x3

    const-wide/16 v2, 0x96

    const-wide/16 v2, 0x96

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/material/animation/i;-><init>(JJ)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->f:Lcom/google/android/material/animation/i;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p1, Lcom/google/android/material/animation/i;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/material/animation/i;-><init>(JJ)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->g:Lcom/google/android/material/animation/i;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void
.end method

.method private h(Landroid/view/View;ZZLjava/util/List;Ljava/util/List;)V
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "ZZ",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;",
            "Ljava/util/List<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~.s ~S~/~~ @@boton @m@-~ty@@~a@ @@~~o@f~ Msv~@@@u iK  ~l@@@~o@r~1i~ i~4~~@~/ l ~fb o b~@c  @ d~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    if-eqz p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object p5, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->f:Lcom/google/android/material/animation/i;

    const/4 v3, 0x2

    move v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    iget-object p5, p0, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->g:Lcom/google/android/material/animation/i;

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p3, :cond_1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p2, Landroid/view/View;->ALPHA:Landroid/util/Property;

    const/4 v4, 0x1

    const/4 v3, 0x7

    new-array p3, v2, [F

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v4, 0x6

    aput v0, p3, v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1, p2, p3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v3, 0x2

    move v4, v3

    sget-object p2, Landroid/view/View;->ALPHA:Landroid/util/Property;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-array p3, v2, [F

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput v0, p3, v1

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1, p2, p3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p5, p1}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p4, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method protected g(Landroid/view/View;Landroid/view/View;ZZ)Landroid/animation/AnimatorSet;
    .locals 8
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v5, Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    move v2, p3

    move v2, p3

    const/4 v7, 0x5

    move v2, p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    move v3, p4

    move v3, p4

    const/4 v7, 0x0

    move v3, p4

    move v3, p4

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/transformation/FabTransformationScrimBehavior;->h(Landroid/view/View;ZZLjava/util/List;Ljava/util/List;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance p4, Landroid/animation/AnimatorSet;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p4}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p4, p1}, Lcom/google/android/material/animation/b;->a(Landroid/animation/AnimatorSet;Ljava/util/List;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance p1, Lcom/google/android/material/transformation/FabTransformationScrimBehavior$a;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {p1, p0, p3, p2}, Lcom/google/android/material/transformation/FabTransformationScrimBehavior$a;-><init>(Lcom/google/android/material/transformation/FabTransformationScrimBehavior;ZLandroid/view/View;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p4, p1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object p4
.end method

.method public layoutDependsOn(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    instance-of p1, p3, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x2

    return p1
.end method

.method public onTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method
