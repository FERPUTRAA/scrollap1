.class public final Lcom/google/android/material/transition/m;
.super Lcom/google/android/material/transition/q;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/transition/q<",
        "Lcom/google/android/material/transition/r;",
        ">;"
    }
.end annotation


# static fields
.field private static final G0:F = 0.85f


# instance fields
.field private final F0:Z


# direct methods
.method public constructor <init>(Z)V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/material/transition/m;->V0(Z)Lcom/google/android/material/transition/r;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/material/transition/m;->W0()Lcom/google/android/material/transition/v;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0, v0, v1}, Lcom/google/android/material/transition/q;-><init>(Lcom/google/android/material/transition/v;Lcom/google/android/material/transition/v;)V

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/transition/m;->F0:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private static V0(Z)Lcom/google/android/material/transition/r;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os.v@ o @y@t~bmonfM @@~~r ii @ lSs~ t~i~b@K @oc@~do/~~ b~~f ~@/  @~@@@ -a~~ @@~ ~@1@ ~~~4~o@ l@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/transition/r;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/material/transition/r;-><init>(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const p0, 0x3f59999a    # 0.85f

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Lcom/google/android/material/transition/r;->m(F)V

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {v0, p0}, Lcom/google/android/material/transition/r;->l(F)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method private static W0()Lcom/google/android/material/transition/v;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/transition/d;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/material/transition/d;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public bridge synthetic E0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/android/material/transition/q;->E0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic G0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/android/material/transition/q;->G0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-object p1
.end method

.method public bridge synthetic J0(Lcom/google/android/material/transition/v;)V
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->J0(Lcom/google/android/material/transition/v;)V

    const/4 v1, 0x6

    return-void
.end method

.method public bridge synthetic L0()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-super {p0}, Lcom/google/android/material/transition/q;->L0()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic Q0()Lcom/google/android/material/transition/v;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/android/material/transition/q;->Q0()Lcom/google/android/material/transition/v;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic R0()Lcom/google/android/material/transition/v;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/android/material/transition/q;->R0()Lcom/google/android/material/transition/v;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic T0(Lcom/google/android/material/transition/v;)Z
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->T0(Lcom/google/android/material/transition/v;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic U0(Lcom/google/android/material/transition/v;)V
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->U0(Lcom/google/android/material/transition/v;)V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public X0()Z
    .locals 3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/transition/m;->F0:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method
