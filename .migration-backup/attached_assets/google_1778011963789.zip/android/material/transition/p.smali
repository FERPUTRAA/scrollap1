.class public final Lcom/google/android/material/transition/p;
.super Lcom/google/android/material/transition/q;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/transition/p$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/transition/q<",
        "Lcom/google/android/material/transition/v;",
        ">;"
    }
.end annotation


# static fields
.field public static final H0:I = 0x0

.field public static final I0:I = 0x1

.field public static final J0:I = 0x2

.field private static final K0:I
    .annotation build Landroidx/annotation/f;
    .end annotation
.end field

.field private static final L0:I
    .annotation build Landroidx/annotation/f;
    .end annotation
.end field


# instance fields
.field private final F0:I

.field private final G0:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget v0, Lcom/google/android/material/R$attr;->motionDurationLong1:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput v0, Lcom/google/android/material/transition/p;->K0:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget v0, Lcom/google/android/material/R$attr;->motionEasingStandard:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput v0, Lcom/google/android/material/transition/p;->L0:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(IZ)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lcom/google/android/material/transition/p;->V0(IZ)Lcom/google/android/material/transition/v;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/material/transition/p;->W0()Lcom/google/android/material/transition/v;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lcom/google/android/material/transition/q;-><init>(Lcom/google/android/material/transition/v;Lcom/google/android/material/transition/v;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/android/material/transition/p;->F0:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-boolean p2, p0, Lcom/google/android/material/transition/p;->G0:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private static V0(IZ)Lcom/google/android/material/transition/v;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s i~~  ~@l~@@4os  ~@@~vn@o~/i~@ub~~ dt@fi @m~~by@~~~f@@c~o  S~r~ ~MK o~t@o  @@./@ o@~b@@a@ -l~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    if-eqz p0, :cond_3

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eq p0, v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne p0, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance p0, Lcom/google/android/material/transition/r;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/transition/r;-><init>(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "iIam:vsi axld "

    const-string v1, "Invalid axis: "

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    new-instance p0, Lcom/google/android/material/transition/s;

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/16 p1, 0x50

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/16 p1, 0x30

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/transition/s;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object p0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p0, Lcom/google/android/material/transition/s;

    const/4 v3, 0x7

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const p1, 0x800005

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_1

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const p1, 0x800003

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/transition/s;-><init>(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method

.method private static W0()Lcom/google/android/material/transition/v;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/transition/e;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/material/transition/e;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public bridge synthetic E0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/android/material/transition/q;->E0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic G0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Lcom/google/android/material/transition/q;->G0(Landroid/view/ViewGroup;Landroid/view/View;Landroidx/transition/r0;Landroidx/transition/r0;)Landroid/animation/Animator;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-object p1
.end method

.method public bridge synthetic J0(Lcom/google/android/material/transition/v;)V
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->J0(Lcom/google/android/material/transition/v;)V

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic L0()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-super {p0}, Lcom/google/android/material/transition/q;->L0()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method O0(Z)I
    .locals 2
    .annotation build Landroidx/annotation/f;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    sget p1, Lcom/google/android/material/transition/p;->K0:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p1
.end method

.method P0(Z)I
    .locals 2
    .annotation build Landroidx/annotation/f;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    sget p1, Lcom/google/android/material/transition/p;->L0:I

    const/4 v1, 0x5

    return p1
.end method

.method public bridge synthetic Q0()Lcom/google/android/material/transition/v;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/android/material/transition/q;->Q0()Lcom/google/android/material/transition/v;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic R0()Lcom/google/android/material/transition/v;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/android/material/transition/q;->R0()Lcom/google/android/material/transition/v;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic T0(Lcom/google/android/material/transition/v;)Z
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->T0(Lcom/google/android/material/transition/v;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p1
.end method

.method public bridge synthetic U0(Lcom/google/android/material/transition/v;)V
    .locals 2
    .param p1    # Lcom/google/android/material/transition/v;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/transition/q;->U0(Lcom/google/android/material/transition/v;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public X0()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/transition/p;->F0:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public Y0()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/transition/p;->G0:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method
