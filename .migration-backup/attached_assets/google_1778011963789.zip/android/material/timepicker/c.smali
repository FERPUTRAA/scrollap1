.class public final Lcom/google/android/material/timepicker/c;
.super Landroidx/fragment/app/c;

# interfaces
.implements Lcom/google/android/material/timepicker/TimePickerView$e;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/timepicker/c$d;
    }
.end annotation


# static fields
.field static final A:Ljava/lang/String; = "TIME_PICKER_TITLE_RES"

.field static final B:Ljava/lang/String; = "TIME_PICKER_TITLE_TEXT"

.field static final C:Ljava/lang/String; = "TIME_PICKER_POSITIVE_BUTTON_TEXT_RES"

.field static final D:Ljava/lang/String; = "TIME_PICKER_POSITIVE_BUTTON_TEXT"

.field static final E:Ljava/lang/String; = "TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES"

.field static final F:Ljava/lang/String; = "TIME_PICKER_NEGATIVE_BUTTON_TEXT"

.field static final G:Ljava/lang/String; = "TIME_PICKER_OVERRIDE_THEME_RES_ID"

.field public static final w:I = 0x0

.field public static final x:I = 0x1

.field static final y:Ljava/lang/String; = "TIME_PICKER_TIME_MODEL"

.field static final z:Ljava/lang/String; = "TIME_PICKER_INPUT_MODE"


# instance fields
.field private final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Landroid/view/View$OnClickListener;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Landroid/view/View$OnClickListener;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Landroid/content/DialogInterface$OnCancelListener;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Landroid/content/DialogInterface$OnDismissListener;",
            ">;"
        }
    .end annotation
.end field

.field private e:Lcom/google/android/material/timepicker/TimePickerView;

.field private f:Landroid/view/ViewStub;

.field private g:Lcom/google/android/material/timepicker/g;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private h:Lcom/google/android/material/timepicker/k;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Lcom/google/android/material/timepicker/i;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/v;
    .end annotation
.end field

.field private k:I
    .annotation build Landroidx/annotation/v;
    .end annotation
.end field

.field private l:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private m:Ljava/lang/CharSequence;

.field private n:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private o:Ljava/lang/CharSequence;

.field private p:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private q:Ljava/lang/CharSequence;

.field private r:Lcom/google/android/material/button/MaterialButton;

.field private s:Landroid/widget/Button;

.field private t:I

.field private u:Lcom/google/android/material/timepicker/TimeModel;

.field private v:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Landroidx/fragment/app/c;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->a:Ljava/util/Set;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->b:Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->c:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->d:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/material/timepicker/c;->l:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/material/timepicker/c;->n:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput v0, p0, Lcom/google/android/material/timepicker/c;->p:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/timepicker/c;->v:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method private A0(I)Landroid/util/Pair;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Landroid/util/Pair<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "rts  i~c @~~ mio~by/ -@o@~14~~~~@Ssl  f@~~tM  @ ~o@@.@vb @a/@Ki~@ @~~ ~~@u@~~ nd@@ l bo~o @~@f~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-ne p1, v0, :cond_0

    const/4 v4, 0x4

    new-instance p1, Landroid/util/Pair;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/android/material/timepicker/c;->k:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget v1, Lcom/google/android/material/R$string;->material_timepicker_clock_mode_description:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v2, " i meofmo:oodnrns "

    const-string/jumbo v2, "oos: n eoiordm f n"

    const/4 v4, 0x7

    const-string/jumbo v2, "oo: oc n nmeo irdf"

    const-string/jumbo v2, "no icon for mode: "

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p1, Landroid/util/Pair;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/material/timepicker/c;->j:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget v1, Lcom/google/android/material/R$string;->material_timepicker_text_input_mode_description:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p1
.end method

.method private E0()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/timepicker/c;->v:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget v1, Lcom/google/android/material/R$attr;->materialTimePickerTheme:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object v0

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v0, v0, Landroid/util/TypedValue;->data:I

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0
.end method

.method private G0(ILcom/google/android/material/timepicker/TimePickerView;Landroid/view/ViewStub;)Lcom/google/android/material/timepicker/i;
    .locals 2
    .param p2    # Lcom/google/android/material/timepicker/TimePickerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/ViewStub;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-nez p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x1

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->g:Lcom/google/android/material/timepicker/g;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    new-instance p1, Lcom/google/android/material/timepicker/g;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p1, p2, p3}, Lcom/google/android/material/timepicker/g;-><init>(Lcom/google/android/material/timepicker/TimePickerView;Lcom/google/android/material/timepicker/TimeModel;)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/timepicker/c;->g:Lcom/google/android/material/timepicker/g;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1

    :cond_1
    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-nez p1, :cond_2

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p3}, Landroid/view/ViewStub;->inflate()Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    check-cast p1, Landroid/widget/LinearLayout;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    new-instance p2, Lcom/google/android/material/timepicker/k;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p2, p1, p3}, Lcom/google/android/material/timepicker/k;-><init>(Landroid/widget/LinearLayout;Lcom/google/android/material/timepicker/TimeModel;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    iput-object p2, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/timepicker/k;->e()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method private static H0(Lcom/google/android/material/timepicker/c$d;)Lcom/google/android/material/timepicker/c;
    .locals 6
    .param p0    # Lcom/google/android/material/timepicker/c$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/material/timepicker/c;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v0}, Lcom/google/android/material/timepicker/c;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "IL_DEbIKEPMMTOECI_ERT_"

    const-string v2, "TIME_PICKER_TIME_MODEL"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->a(Lcom/google/android/material/timepicker/c$d;)Lcom/google/android/material/timepicker/TimeModel;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v2, "IEMDEOuIKR_NM_C_EUTPPI"

    const-string v2, "DN_mRTKUIMPI_C_IEPEOEM"

    const/4 v5, 0x3

    const-string v2, "_TOU_PKpCEIMIIPN_EDERM"

    const-string v2, "TIME_PICKER_INPUT_MODE"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->b(Lcom/google/android/material/timepicker/c$d;)I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v2, "TI_IETTLqRSMKE_IRCEP_"

    const-string v2, "TPMRo_S__TEIRECTIEILK"

    const-string v2, "RKs_E_PMSEEEICITTRL_I"

    const-string v2, "TIME_PICKER_TITLE_RES"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->c(Lcom/google/android/material/timepicker/c$d;)I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->d(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v2, "LIEmTE_IPT_bEXTERTC_TI"

    const-string v2, "IPCLRb_ITM_EXETTIT_TEE"

    const/4 v5, 0x0

    const-string v2, "TIME_PICKER_TITLE_TEXT"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->d(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string v2, "CIE_ouIEE_ST_ERTOPUTTTKPIIO_NTREBV_X"

    const-string v2, "_I_PTEuXRTTUNEIOS__PRBKTEICO_STTVEEI"

    const/4 v5, 0x4

    const-string v2, "E___EbIKOXPBCPRISTTTVTENIEOE_T_SMIRT"

    const-string v2, "TIME_PICKER_POSITIVE_BUTTON_TEXT_RES"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->e(Lcom/google/android/material/timepicker/c$d;)I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->f(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v2, "II_ETRuCUTIPTMTEBVX_pOETKES_TPOI"

    const-string v2, "__XTEEIpEUTOKTIR_TOBPTIIVTPS_ECM"

    const/4 v5, 0x6

    const-string v2, "RIEUCTOpPPMTTE_ITI_NBKOTVSIEETX_"

    const-string v2, "TIME_PICKER_POSITIVE_BUTTON_TEXT"

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->f(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v2, "TKVI_EERqEG_PTASMTTENTI_NOBE__RTXUCI"

    const-string v2, "TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES"

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->g(Lcom/google/android/material/timepicker/c$d;)I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->h(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, "_EsTBECKEET_UGTTATTPqI_NR_IVMNOI"

    const-string v2, "_EGCTPKMqI_IBTETNOT_ERUE_TAIETNV"

    const/4 v5, 0x2

    const-string v2, "NATmTIRNME_EKBITEGTEI_EUV_OTTC_P"

    const-string v2, "TIME_PICKER_NEGATIVE_BUTTON_TEXT"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->h(Lcom/google/android/material/timepicker/c$d;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, "PMEOo_RRESRMER_HDIIIEE__EEVCTKT_D"

    const-string v2, "TIME_PICKER_OVERRIDE_THEME_RES_ID"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/material/timepicker/c$d;->i(Lcom/google/android/material/timepicker/c$d;)I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object v0
.end method

.method private M0(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "IMs_TMEITRK_IEDLMEOCPE"

    const/4 v3, 0x5

    const-string v0, "IMOMEbPLE_EDCR_MTEII_T"

    const-string v0, "TIME_PICKER_TIME_MODEL"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/material/timepicker/TimeModel;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/material/timepicker/TimeModel;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/material/timepicker/TimeModel;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "DMECORuIP_PTM__mEEUINK"

    const-string v0, "KCUmIEND_IPM_REEP_IOMT"

    const/4 v3, 0x6

    const-string v0, "TIME_PICKER_INPUT_MODE"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v0, "RMETECTpIK_SERIITo__E"

    const-string v0, "_REToKTSCI__PEEREIMIT"

    const/4 v3, 0x0

    const-string v0, "M_TLIERTq_IPTESECIE_K"

    const-string v0, "TIME_PICKER_TITLE_RES"

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/android/material/timepicker/c;->l:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "TMsbLT_IR_TECITPEXITEE"

    const-string v0, "T_CEMbETIP_ITTIEXEKLRT"

    const/4 v3, 0x2

    const-string v0, "TCEmTEEIT_XLT__MPTIRKI"

    const-string v0, "TIME_PICKER_TITLE_TEXT"

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->m:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "TIKToSTX__PSTI_EPRNERVOIT_EM_ECEOBUT"

    const-string v0, "TIME_PICKER_POSITIVE_BUTTON_TEXT_RES"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/android/material/timepicker/c;->n:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "PROEEbTTO_ETPTISEIIB_XIMTNuUCK_V"

    const-string v0, "MIPIBIuTECPO_UK_VT_TETSNORXI_ETE"

    const/4 v3, 0x1

    const-string v0, "EIKOXTuOUMCIRTT__NPVI_EIEBEPS_TT"

    const-string v0, "TIME_PICKER_POSITIVE_BUTTON_TEXT"

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->o:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v0, "TESEPBEpO__TTC_pXVKEARE_G_UNRIEITMTT"

    const-string v0, "REKAIN_p_OBNR_STGT_I_MTEPTVUEEETCETX"

    const/4 v3, 0x6

    const-string v0, "XNPOT_ITqKRT_STIEAEVN_GEEMBUEIECT__R"

    const-string v0, "TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/android/material/timepicker/c;->p:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "MKsTEENUTIECTGT_VOEIq_E_XTIAPTNR"

    const-string v0, "MEOEVEPTqIXENTIENKRI_TTT_TGCU__A"

    const/4 v3, 0x2

    const-string v0, "E__mTT_GVIUEAETOETCNK_ETNRIXTPIB"

    const-string v0, "TIME_PICKER_NEGATIVE_BUTTON_TEXT"

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->q:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "EEsHP_EKIOEIEC_MVTT_MSRIIR_DDE_RE"

    const/4 v3, 0x6

    const-string v0, "EIEIoERDEHETEIC_S_R_KVD_PREMMR_OI"

    const-string v0, "TIME_PICKER_OVERRIDE_THEME_RES_ID"

    const/4 v2, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput p1, p0, Lcom/google/android/material/timepicker/c;->v:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private Q0()V
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->s:Landroid/widget/Button;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/c;->isCancelable()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v1, 0x8

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method private R0(Lcom/google/android/material/button/MaterialButton;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->e:Lcom/google/android/material/timepicker/TimePickerView;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->f:Landroid/view/ViewStub;

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {v0}, Lcom/google/android/material/timepicker/i;->hide()V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->e:Lcom/google/android/material/timepicker/TimePickerView;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/material/timepicker/c;->f:Landroid/view/ViewStub;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, v0, v1, v2}, Lcom/google/android/material/timepicker/c;->G0(ILcom/google/android/material/timepicker/TimePickerView;Landroid/view/ViewStub;)Lcom/google/android/material/timepicker/i;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    invoke-interface {v0}, Lcom/google/android/material/timepicker/i;->a()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/android/material/timepicker/i;->invalidate()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-direct {p0, v0}, Lcom/google/android/material/timepicker/c;->A0(I)Landroid/util/Pair;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    const/4 v3, 0x6

    move v4, v3

    check-cast v1, Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1, v1}, Lcom/google/android/material/button/MaterialButton;->setIconResource(I)V

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, v0, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v4, 0x5

    const/4 v0, 0x4

    const/4 v4, 0x6

    move v3, v0

    move v3, v0

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->sendAccessibilityEvent(I)V

    :cond_2
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method static synthetic e0(Lcom/google/android/material/timepicker/c;)Ljava/util/Set;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/timepicker/c;->b:Ljava/util/Set;

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-object p0
.end method

.method static synthetic f0(Lcom/google/android/material/timepicker/c;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget p0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic g0(Lcom/google/android/material/timepicker/c;I)I
    .locals 2

    const/4 v0, 0x1

    iput p1, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic h0(Lcom/google/android/material/timepicker/c;)Lcom/google/android/material/button/MaterialButton;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/timepicker/c;->r:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic i0(Lcom/google/android/material/timepicker/c;Lcom/google/android/material/button/MaterialButton;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/timepicker/c;->R0(Lcom/google/android/material/button/MaterialButton;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic j0(Lcom/google/android/material/timepicker/c$d;)Lcom/google/android/material/timepicker/c;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/android/material/timepicker/c;->H0(Lcom/google/android/material/timepicker/c$d;)Lcom/google/android/material/timepicker/c;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic l0(Lcom/google/android/material/timepicker/c;)Ljava/util/Set;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/material/timepicker/c;->a:Ljava/util/Set;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public B0()I
    .locals 3
    .annotation build Landroidx/annotation/g0;
        from = 0x0L
        to = 0x17L
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, v0, Lcom/google/android/material/timepicker/TimeModel;->d:I

    const/4 v1, 0x6

    move v2, v1

    rem-int/lit8 v0, v0, 0x18

    const/4 v2, 0x3

    return v0
.end method

.method public C0()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public D0()I
    .locals 3
    .annotation build Landroidx/annotation/g0;
        from = 0x0L
        to = 0x3bL
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, v0, Lcom/google/android/material/timepicker/TimeModel;->e:I

    const/4 v1, 0x6

    move v2, v1

    return v0
.end method

.method F0()Lcom/google/android/material/timepicker/g;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->g:Lcom/google/android/material/timepicker/g;

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-object v0
.end method

.method public I0(Landroid/content/DialogInterface$OnCancelListener;)Z
    .locals 3
    .param p1    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->c:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method public J0(Landroid/content/DialogInterface$OnDismissListener;)Z
    .locals 3
    .param p1    # Landroid/content/DialogInterface$OnDismissListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->d:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return p1
.end method

.method public K0(Landroid/view/View$OnClickListener;)Z
    .locals 3
    .param p1    # Landroid/view/View$OnClickListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->b:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1
.end method

.method public L0(Landroid/view/View$OnClickListener;)Z
    .locals 3
    .param p1    # Landroid/view/View$OnClickListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->a:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p1
.end method

.method N0(Lcom/google/android/material/timepicker/i;)V
    .locals 2
    .param p1    # Lcom/google/android/material/timepicker/i;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    return-void
.end method

.method public O0(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
            to = 0x17L
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/timepicker/TimeModel;->i(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p1}, Lcom/google/android/material/timepicker/i;->invalidate()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public P0(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
            to = 0x3bL
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/timepicker/TimeModel;->n(I)V

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    invoke-interface {p1}, Lcom/google/android/material/timepicker/i;->invalidate()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public m()V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->r:Lcom/google/android/material/button/MaterialButton;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/timepicker/c;->R0(Lcom/google/android/material/button/MaterialButton;)V

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/timepicker/k;->g()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public n0(Landroid/content/DialogInterface$OnCancelListener;)Z
    .locals 3
    .param p1    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->c:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p1
.end method

.method public o0(Landroid/content/DialogInterface$OnDismissListener;)Z
    .locals 3
    .param p1    # Landroid/content/DialogInterface$OnDismissListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->d:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p1
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .locals 4
    .param p1    # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->c:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v1, Landroid/content/DialogInterface$OnCancelListener;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnCancelListener;->onCancel(Landroid/content/DialogInterface;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onCancel(Landroid/content/DialogInterface;)V

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/timepicker/c;->M0(Landroid/os/Bundle;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public final onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
    .locals 9
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance p1, Landroid/app/Dialog;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0}, Lcom/google/android/material/timepicker/c;->E0()I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {p1, v0, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget v1, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v8, 0x3

    const-class v2, Lcom/google/android/material/timepicker/c;

    const-class v2, Lcom/google/android/material/timepicker/c;

    const/4 v8, 0x2

    const-class v2, Lcom/google/android/material/timepicker/c;

    const-class v2, Lcom/google/android/material/timepicker/c;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, v1, v2}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance v2, Lcom/google/android/material/shape/j;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget v3, Lcom/google/android/material/R$attr;->materialTimePickerStyle:I

    const/4 v7, 0x7

    or-int/2addr v8, v7

    sget v4, Lcom/google/android/material/R$style;->Widget_MaterialComponents_TimePicker:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-direct {v2, v0, v5, v3, v4}, Lcom/google/android/material/shape/j;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    sget-object v6, Lcom/google/android/material/R$styleable;->MaterialTimePicker:[I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v0, v5, v6, v3, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    sget v4, Lcom/google/android/material/R$styleable;->MaterialTimePicker_clockIcon:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v3, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput v4, p0, Lcom/google/android/material/timepicker/c;->k:I

    const/4 v8, 0x7

    sget v4, Lcom/google/android/material/R$styleable;->MaterialTimePicker_keyboardIcon:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v3, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    iput v4, p0, Lcom/google/android/material/timepicker/c;->j:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x7

    invoke-virtual {v2, v0}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v2, v0}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Landroid/view/Window;->requestFeature(I)Z

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v1, -0x2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v0}, Landroidx/core/view/k1;->R(Landroid/view/View;)F

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v2, v0}, Lcom/google/android/material/shape/j;->n0(F)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object p1
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 2
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    sget p3, Lcom/google/android/material/R$layout;->material_timepicker_dialog:I

    const/4 v1, 0x5

    invoke-virtual {p1, p3, p2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    sget p2, Lcom/google/android/material/R$id;->material_timepicker_view:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p2, Lcom/google/android/material/timepicker/TimePickerView;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/material/timepicker/c;->e:Lcom/google/android/material/timepicker/TimePickerView;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p2, p0}, Lcom/google/android/material/timepicker/TimePickerView;->u(Lcom/google/android/material/timepicker/TimePickerView$e;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget p2, Lcom/google/android/material/R$id;->material_textinput_timepicker:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    check-cast p2, Landroid/view/ViewStub;

    const/4 v0, 0x4

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/google/android/material/timepicker/c;->f:Landroid/view/ViewStub;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget p2, Lcom/google/android/material/R$id;->material_timepicker_mode_button:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    check-cast p2, Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/material/timepicker/c;->r:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x7

    const/4 v0, 0x6

    sget p2, Lcom/google/android/material/R$id;->header_title:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    check-cast p2, Landroid/widget/TextView;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p3, p0, Lcom/google/android/material/timepicker/c;->l:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->m:Ljava/lang/CharSequence;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-nez p3, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->m:Ljava/lang/CharSequence;

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/material/timepicker/c;->r:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x7

    invoke-direct {p0, p2}, Lcom/google/android/material/timepicker/c;->R0(Lcom/google/android/material/button/MaterialButton;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    sget p2, Lcom/google/android/material/R$id;->material_timepicker_ok_button:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p2, Landroid/widget/Button;

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p3, Lcom/google/android/material/timepicker/c$a;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p3, p0}, Lcom/google/android/material/timepicker/c$a;-><init>(Lcom/google/android/material/timepicker/c;)V

    const/4 v1, 0x1

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p3, p0, Lcom/google/android/material/timepicker/c;->n:I

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eqz p3, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    goto :goto_1

    :cond_2
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->o:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-nez p3, :cond_3

    const/4 v0, 0x2

    move v1, v0

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->o:Ljava/lang/CharSequence;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    :goto_1
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    sget p2, Lcom/google/android/material/R$id;->material_timepicker_cancel_button:I

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p2, Landroid/widget/Button;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/timepicker/c;->s:Landroid/widget/Button;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    new-instance p3, Lcom/google/android/material/timepicker/c$b;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p3, p0}, Lcom/google/android/material/timepicker/c$b;-><init>(Lcom/google/android/material/timepicker/c;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p2, p0, Lcom/google/android/material/timepicker/c;->p:I

    const/4 v1, 0x3

    if-eqz p2, :cond_4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->s:Landroid/widget/Button;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(I)V

    const/4 v0, 0x1

    const/4 v0, 0x6

    goto :goto_2

    :cond_4
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/timepicker/c;->q:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p2, :cond_5

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/material/timepicker/c;->s:Landroid/widget/Button;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p3, p0, Lcom/google/android/material/timepicker/c;->q:Ljava/lang/CharSequence;

    const/4 v1, 0x1

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_5
    :goto_2
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/timepicker/c;->Q0()V

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/material/timepicker/c;->r:Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x0

    new-instance p3, Lcom/google/android/material/timepicker/c$c;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p3, p0}, Lcom/google/android/material/timepicker/c$c;-><init>(Lcom/google/android/material/timepicker/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public onDestroyView()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-super {p0}, Landroidx/fragment/app/c;->onDestroyView()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->i:Lcom/google/android/material/timepicker/i;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->g:Lcom/google/android/material/timepicker/g;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->h:Lcom/google/android/material/timepicker/k;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->e:Lcom/google/android/material/timepicker/TimePickerView;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Lcom/google/android/material/timepicker/TimePickerView;->u(Lcom/google/android/material/timepicker/TimePickerView$e;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/android/material/timepicker/c;->e:Lcom/google/android/material/timepicker/TimePickerView;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 4
    .param p1    # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->d:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v1, Landroid/content/DialogInterface$OnDismissListener;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnDismissListener;->onDismiss(Landroid/content/DialogInterface;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onDismiss(Landroid/content/DialogInterface;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v3, 0x2

    const-string v0, "_E_TTb_EmORILKPIDEMMCM"

    const-string v0, "MI_mIECLME_EDIOTT_RKPM"

    const-string v0, "RLMKIMuCEO_E_P_TITEEDI"

    const-string v0, "TIME_PICKER_TIME_MODEL"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->u:Lcom/google/android/material/timepicker/TimeModel;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, "EINEIIPp_EPTR_UDMKMC_O"

    const-string v0, "TP_IoDEKR_IEPE_NMIMOUC"

    const/4 v3, 0x7

    const-string v0, "E_O_IMCRqEIPDIU_KPTNET"

    const-string v0, "TIME_PICKER_INPUT_MODE"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/timepicker/c;->t:I

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const-string v0, "EKsR_ETSb_IPTCLIIMTER"

    const-string v0, "TEEPRbIREKTISCE__ITLM"

    const/4 v3, 0x4

    const-string v0, "TISmLCE_EKEIRTIP__MRT"

    const-string v0, "TIME_PICKER_TITLE_RES"

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/timepicker/c;->l:I

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "PI_IoETTECIXKTMERu_T_L"

    const-string v0, "ET_ETXu_TET_KRECIMIPLI"

    const/4 v3, 0x4

    const-string v0, "TIIKIbCPET_RMT_TELTXE_"

    const-string v0, "TIME_PICKER_TITLE_TEXT"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->m:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "pT_IKMu_CTPE_RTOBEIS_PVTTEIST_UEOIRE"

    const-string v0, "IT_BIUIp_XVIET_OTTE__EPTMTREOKCSEPRS"

    const/4 v3, 0x4

    const-string v0, "KOETXEIpIEIBRTSTSM_INT_C_UEPOTE_TR_V"

    const-string v0, "TIME_PICKER_POSITIVE_BUTTON_TEXT_RES"

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/android/material/timepicker/c;->n:I

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "KI_POPMBqEI_IVIRTE_OETE_TXNTSTCT"

    const/4 v3, 0x1

    const-string v0, "EPTXVIEOqTIRT_T_NUK__PBSICETTEMI"

    const-string v0, "TIME_PICKER_POSITIVE_BUTTON_TEXT"

    const/4 v3, 0x3

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->o:Ljava/lang/CharSequence;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v0, "MIsNTTE_TTSREPANT_IBUROEKEsITVEE_GC_"

    const-string v0, "IMsTNGARTBE_TSO_PTEXCTIEEV_RENITUEK_"

    const-string v0, "TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES"

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/timepicker/c;->p:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "PTEmEINTTTMIIAE__OTBX_mRG_VUTECN"

    const-string v0, "_AImETEUBTNT__MTN_GTXEIPEOCRITVE"

    const/4 v3, 0x4

    const-string v0, "KIEToENPTRBEMTTII_XGTO_VCU_EN_AT"

    const-string v0, "TIME_PICKER_NEGATIVE_BUTTON_TEXT"

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/timepicker/c;->q:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v0, "IORVCboERHIEEESE_IRMRKI_T_TMDE_D_"

    const-string v0, "I_EOoEPEEVHETRRKRDCRMEMIS_D_TI__I"

    const/4 v3, 0x5

    const-string v0, "_EVI_IuRKTHTEOPERID_EMSERDE_MIREC"

    const-string v0, "TIME_PICKER_OVERRIDE_THEME_RES_ID"

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/timepicker/c;->v:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public q0(Landroid/view/View$OnClickListener;)Z
    .locals 3
    .param p1    # Landroid/view/View$OnClickListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->b:Ljava/util/Set;

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1
.end method

.method public r0(Landroid/view/View$OnClickListener;)Z
    .locals 3
    .param p1    # Landroid/view/View$OnClickListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->a:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1
.end method

.method public setCancelable(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->setCancelable(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/timepicker/c;->Q0()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public t0()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->c:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public v0()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->d:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public x0()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->b:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return-void
.end method

.method public z0()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/timepicker/c;->a:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
