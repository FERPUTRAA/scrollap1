.class public Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;
.super Lcom/google/android/material/appbar/f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xc
    name = "BaseBehavior"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;,
        Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Lcom/google/android/material/appbar/AppBarLayout;",
        ">",
        "Lcom/google/android/material/appbar/f<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final MAX_OFFSET_ANIMATION_DURATION:I = 0x258


# instance fields
.field private lastNestedScrollingChildRef:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private lastStartedType:I

.field private offsetAnimator:Landroid/animation/ValueAnimator;

.field private offsetDelta:I

.field private onDragCallback:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;

.field private savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-direct {p0}, Lcom/google/android/material/appbar/f;-><init>()V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/f;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$200(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetDelta:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p0
.end method

.method private b(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)V
    .locals 10
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    neg-int v1, v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x1

    if-eq v0, v1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p3, v2}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->r:Landroidx/core/view/accessibility/l0$a;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroidx/core/view/accessibility/l0$a;Z)V

    :cond_0
    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v0, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p3, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedPreScrollRange()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    neg-int v6, v0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v6, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->s:Landroidx/core/view/accessibility/l0$a;

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-instance v7, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct/range {v1 .. v6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$b;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 p2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-static {p1, v0, p2, v7}, Landroidx/core/view/k1;->u1(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;Ljava/lang/CharSequence;Landroidx/core/view/accessibility/s0;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_0

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    sget-object p3, Landroidx/core/view/accessibility/l0$a;->s:Landroidx/core/view/accessibility/l0$a;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, p1, p2, p3, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->c(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroidx/core/view/accessibility/l0$a;Z)V

    :cond_2
    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method private c(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroidx/core/view/accessibility/l0$a;Z)V
    .locals 3
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroidx/core/view/accessibility/l0$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroidx/core/view/accessibility/l0$a;",
            "Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    new-instance v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p0, p2, p4}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$c;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Lcom/google/android/material/appbar/AppBarLayout;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, p3, p2, v0}, Landroidx/core/view/k1;->u1(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;Ljava/lang/CharSequence;Landroidx/core/view/accessibility/s0;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IF)V
    .locals 4
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;IF)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    sub-int/2addr v0, p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p4}, Ljava/lang/Math;->abs(F)F

    move-result p4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    cmpl-float v1, p4, v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-lez v1, :cond_0

    int-to-float v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    div-float/2addr v0, p4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/high16 p4, 0x447a0000    # 1000.0f

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    mul-float/2addr v0, p4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    mul-int/lit8 p4, p4, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    int-to-float p4, v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    int-to-float v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    div-float/2addr p4, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v3, 0x3

    const/4 v2, 0x2

    add-float/2addr p4, v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/high16 v0, 0x43160000    # 150.0f

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    mul-float/2addr p4, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    float-to-int p4, p4

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;II)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;II)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;II)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-ne v0, p3, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Landroid/animation/ValueAnimator;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v1}, Landroid/animation/ValueAnimator;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x4

    const/4 v3, 0x3

    sget-object v2, Lcom/google/android/material/animation/a;->e:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v2, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$a;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-direct {v2, p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$a;-><init>(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/16 p2, 0x258

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {p4, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    int-to-long v1, p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v3, 0x4

    const/4 v3, 0x0

    filled-new-array {v0, p3}, [I

    move-result-object p2

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Landroid/animation/ValueAnimator;->setIntValues([I)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method private f(III)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int v0, p2, p3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    div-int/lit8 v0, v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ge p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    move p2, p3

    move p2, p3

    const/4 v2, 0x2

    move p2, p3

    move p2, p3

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p2
.end method

.method private g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)Z
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            ")Z"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->n()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    move-result p3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    sub-int/2addr p1, p3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-gt p1, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method private static h(II)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    and-int/2addr p0, p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    if-ne p0, p1, :cond_0

    const/4 v0, 0x2

    move v1, v0

    const/4 p0, 0x0

    const/4 p0, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p0
.end method

.method private i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;
    .locals 6
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ge v1, v0, :cond_2

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    instance-of v3, v2, Landroidx/core/view/t0;

    const/4 v5, 0x3

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    instance-of v3, v2, Landroid/widget/ListView;

    const/4 v4, 0x2

    move v5, v4

    if-nez v3, :cond_1

    const/4 v5, 0x1

    instance-of v3, v2, Landroid/widget/ScrollView;

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object v2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 p1, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x6

    return-object p1
.end method

.method private static j(Lcom/google/android/material/appbar/AppBarLayout;I)Landroid/view/View;
    .locals 6
    .param p0    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ge v1, v0, :cond_1

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-lt p1, v3, :cond_0

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-gt p1, v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v2

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 p0, 0x0

    move v5, p0

    const/4 v4, 0x7

    return-object p0
.end method

.method private k(Lcom/google/android/material/appbar/AppBarLayout;I)I
    .locals 9
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I)I"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge v1, v0, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v2}, Landroid/view/View;->getBottom()I

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v2}, Lcom/google/android/material/appbar/AppBarLayout$f;->c()I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/16 v6, 0x20

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v5, v6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->h(II)Z

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x0

    if-eqz v5, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget v5, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    sub-int/2addr v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget v2, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    add-int/2addr v4, v2

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    neg-int v2, p2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-gt v3, v2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-lt v4, v2, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    return v1

    :cond_1
    const/4 v7, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 p1, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    return p1
.end method

.method private l(Lcom/google/android/material/appbar/AppBarLayout;I)I
    .locals 10
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I)I"
        }
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    move v3, v2

    move v3, v2

    const/4 v9, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-ge v3, v1, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    const/4 v9, 0x6

    check-cast v5, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v5}, Lcom/google/android/material/appbar/AppBarLayout$f;->d()Landroid/view/animation/Interpolator;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x3

    if-lt v0, v7, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-gt v0, v7, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v6, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v5}, Lcom/google/android/material/appbar/AppBarLayout$f;->c()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    and-int/lit8 v3, v1, 0x1

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz v3, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget v7, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    add-int/2addr v3, v7

    const/4 v8, 0x3

    shl-int/2addr v9, v8

    iget v5, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    add-int/2addr v3, v5

    const/4 v9, 0x2

    add-int/2addr v2, v3

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    and-int/lit8 v1, v1, 0x2

    const/4 v8, 0x2

    shl-int/2addr v9, v8

    if-eqz v1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-static {v4}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    sub-int/2addr v2, v1

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v4}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v1, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    sub-int/2addr v2, p1

    :cond_1
    const/4 v8, 0x2

    move v9, v8

    if-lez v2, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    sub-int/2addr v0, p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    int-to-float p1, v2

    const/4 v9, 0x4

    const/4 v8, 0x6

    int-to-float v0, v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    div-float/2addr v0, p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-interface {v6, v0}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    mul-float/2addr p1, v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->signum(I)I

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    add-int/2addr v0, p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    mul-int/2addr p2, v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    return p2

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    return p2
.end method

.method private m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)Z
    .locals 6
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)Z"
        }
    .end annotation

    const/4 v5, 0x1

    invoke-virtual {p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r(Landroid/view/View;)Ljava/util/List;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ge v1, p2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    check-cast v2, Landroid/view/View;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v2, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    instance-of v3, v2, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/material/appbar/g;->d()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v0, 0x1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v0

    :cond_1
    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v0
.end method

.method private n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 10
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)V"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    add-int/2addr v0, v1

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    sub-int/2addr v1, v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {p0, p2, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->k(Lcom/google/android/material/appbar/AppBarLayout;I)I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-ltz v2, :cond_5

    const/4 v9, 0x7

    invoke-virtual {p2, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    check-cast v4, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v4}, Lcom/google/android/material/appbar/AppBarLayout$f;->c()I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    and-int/lit8 v6, v5, 0x11

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/16 v7, 0x11

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ne v6, v7, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    neg-int v6, v6

    const/4 v8, 0x0

    move v9, v8

    invoke-virtual {v3}, Landroid/view/View;->getBottom()I

    move-result v7

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    neg-int v7, v7

    const/4 v9, 0x4

    const/4 v8, 0x6

    if-nez v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {p2}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-eqz v2, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v3}, Landroidx/core/view/k1;->U(Landroid/view/View;)Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz v2, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    sub-int/2addr v6, v2

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/4 v2, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {v5, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->h(II)Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v3}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    add-int/2addr v7, v2

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v2, 0x5

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-static {v5, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->h(II)Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x6

    if-eqz v2, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {v3}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    add-int/2addr v2, v7

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-ge v1, v2, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v6, v2

    move v6, v2

    const/4 v9, 0x7

    move v6, v2

    move v6, v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    move v7, v2

    move v7, v2

    const/4 v9, 0x7

    move v7, v2

    move v7, v2

    :cond_3
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/16 v2, 0x20

    const/4 v9, 0x5

    invoke-static {v5, v2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->h(II)Z

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v2, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x3

    iget v2, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    add-int/2addr v6, v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget v2, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    sub-int/2addr v7, v2

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {p0, v1, v7, v6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->f(III)I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/2addr v1, v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    neg-int v0, v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v1, v0, v2}, Lo/a;->e(III)I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IF)V

    :cond_5
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    return-void
.end method

.method private o(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 4
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->r:Landroidx/core/view/accessibility/l0$a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/core/view/accessibility/l0$a;->b()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v0}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->s:Landroidx/core/view/accessibility/l0$a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroidx/core/view/accessibility/l0$a;->b()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, v1, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->b(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)V

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method private p(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V
    .locals 7
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;IIZ)V"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->j(Lcom/google/android/material/appbar/AppBarLayout;I)Landroid/view/View;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/google/android/material/appbar/AppBarLayout$f;->c()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    and-int/lit8 v3, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-lez p4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    and-int/lit8 p4, v2, 0xc

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    neg-int p3, p3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result p4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    sub-int/2addr p4, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    sub-int/2addr p4, v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-lt p3, p4, :cond_1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    move v1, v4

    move v1, v4

    move v1, v4

    move v1, v4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    and-int/lit8 p4, v2, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz p4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    neg-int p3, p3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result p4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    sub-int/2addr p4, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    sub-int/2addr p4, v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-lt p3, p4, :cond_1

    const/4 v5, 0x2

    move v6, v5

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result p3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz p3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    move-result-object p3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout;->F(Landroid/view/View;)Z

    move-result v1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Lcom/google/android/material/appbar/AppBarLayout;->C(Z)Z

    move-result p3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez p5, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz p3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz p1, :cond_4

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p2}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    :cond_4
    const/4 v6, 0x6

    return-void
.end method


# virtual methods
.method bridge synthetic canDragView(Landroid/view/View;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->canDragView(Lcom/google/android/material/appbar/AppBarLayout;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p1
.end method

.method canDragView(Lcom/google/android/material/appbar/AppBarLayout;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onDragCallback:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;->a(Lcom/google/android/material/appbar/AppBarLayout;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->lastNestedScrollingChildRef:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast p1, Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    move v3, v0

    :cond_2
    :goto_0
    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v0
.end method

.method bridge synthetic getMaxDragOffset(Landroid/view/View;)I
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getMaxDragOffset(Lcom/google/android/material/appbar/AppBarLayout;)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method getMaxDragOffset(Lcom/google/android/material/appbar/AppBarLayout;)I
    .locals 2
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)I"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedScrollRange()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    neg-int p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method

.method bridge synthetic getScrollRangeForDragFling(Landroid/view/View;)I
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getScrollRangeForDragFling(Lcom/google/android/material/appbar/AppBarLayout;)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method getScrollRangeForDragFling(Lcom/google/android/material/appbar/AppBarLayout;)I
    .locals 2
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)I"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method getTopBottomOffsetForScrollingSibling()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    iget v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetDelta:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    add-int/2addr v0, v1

    const/4 v3, 0x6

    return v0
.end method

.method isOffsetAnimatorRunning()Z
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method bridge synthetic onFlingFinished(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onFlingFinished(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method onFlingFinished(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->i(Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->F(Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->C(Z)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public bridge synthetic onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method public onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;I)Z
    .locals 9
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;I)Z"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/appbar/h;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    move-result p3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getPendingAction()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x3

    if-eqz v1, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    and-int/lit8 v3, v0, 0x8

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-nez v3, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-boolean v0, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->c:Z

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    neg-int v0, v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto/16 :goto_2

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-boolean v0, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->d:Z

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p0, p1, p2, v2}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto/16 :goto_2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget v0, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->e:I

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    neg-int v1, v1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-boolean v3, v3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->g:Z

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v3, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v0}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    add-int/2addr v0, v3

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    int-to-float v0, v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget v3, v3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->f:F

    const/4 v8, 0x1

    mul-float/2addr v0, v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/2addr v1, v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0, p1, p2, v1}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_2

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v0, :cond_8

    const/4 v7, 0x7

    move v8, v7

    and-int/lit8 v1, v0, 0x4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v3, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    if-eqz v1, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    move v1, v3

    move v1, v3

    const/4 v8, 0x7

    move v1, v3

    move v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_1

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v1, v2

    move v1, v2

    const/4 v8, 0x4

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    and-int/lit8 v4, v0, 0x2

    const/4 v7, 0x1

    move v8, v7

    const/4 v5, 0x0

    move v8, v5

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz v4, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getUpNestedPreScrollRange()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    neg-int v0, v0

    const/4 v8, 0x1

    if-eqz v1, :cond_5

    const/4 v8, 0x4

    invoke-direct {p0, p1, p2, v0, v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IF)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_2

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    const/4 v7, 0x1

    move v8, v7

    goto :goto_2

    :cond_6
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    and-int/2addr v0, v3

    const/4 v7, 0x3

    move v8, v7

    if-eqz v0, :cond_8

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v1, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {p0, p1, p2, v2, v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IF)V

    const/4 v8, 0x5

    goto :goto_2

    :cond_7
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p0, p1, p2, v2}, Lcom/google/android/material/appbar/f;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)I

    :cond_8
    :goto_2
    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->w()V

    const/4 v7, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v0, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    iput-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    neg-int v1, v1

    const/4 v7, 0x1

    move v8, v7

    invoke-static {v0, v1, v2}, Lo/a;->e(III)I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/h;->setTopAndBottomOffset(I)Z

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v5, 0x0

    const/4 v8, 0x1

    const/4 v6, 0x1

    const/4 v8, 0x3

    shr-int/2addr v7, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct/range {v1 .. v6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->p(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2, v0}, Lcom/google/android/material/appbar/AppBarLayout;->r(I)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->o(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v8, 0x3

    return p3
.end method

.method public bridge synthetic onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-virtual/range {p0 .. p6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIII)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method public onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIII)Z
    .locals 8
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;IIII)Z"
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v7, 0x7

    const/4 v1, -0x2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-ne v0, v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 p5, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p5, p5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v2, p3

    move v2, p3

    const/4 v7, 0x6

    move v2, p3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    move v3, p4

    move v3, p4

    const/4 v7, 0x0

    move v3, p4

    move v3, p4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    move v5, p6

    move v5, p6

    const/4 v7, 0x6

    move v5, p6

    move v5, p6

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual/range {v0 .. v5}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->I(Landroid/view/View;IIII)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 p1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    return p1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-super/range {p0 .. p6}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    return p1
.end method

.method public bridge synthetic onNestedPreScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;II[II)V
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual/range {p0 .. p7}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onNestedPreScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;II[II)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public onNestedPreScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;II[II)V
    .locals 8
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            "II[II)V"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz p5, :cond_1

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-gez p5, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result p4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    neg-int p4, p4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedPreScrollRange()I

    move-result p7

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    add-int/2addr p7, p4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getUpNestedPreScrollRange()I

    move-result p4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    neg-int p4, p4

    const/4 v7, 0x3

    const/4 p7, 0x2

    const/4 p7, 0x0

    move v7, p7

    :goto_0
    const/4 v6, 0x7

    move v7, v6

    move v4, p4

    move v4, p4

    const/4 v7, 0x6

    move v4, p4

    move v4, p4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    move v5, p7

    move v5, p7

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eq v4, v5, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 p4, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    move v3, p5

    move v3, p5

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/material/appbar/f;->scroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    aput p1, p6, p4

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz p1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout;->F(Landroid/view/View;)Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->C(Z)Z

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-void
.end method

.method public bridge synthetic onNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;IIIII[I)V
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x7

    const/4 v1, 0x3

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual/range {p0 .. p9}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;IIIII[I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public onNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;IIIII[I)V
    .locals 6
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            "IIIII[I)V"
        }
    .end annotation

    if-gez p7, :cond_0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedScrollRange()I

    move-result p3

    neg-int v4, p3

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move v3, p7

    move v3, p7

    move v3, p7

    move v3, p7

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/material/appbar/f;->scroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I

    move-result p3

    const/4 p4, 0x1

    aput p3, p9, p4

    :cond_0
    if-nez p7, :cond_1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->o(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    :cond_1
    return-void
.end method

.method public bridge synthetic onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/os/Parcelable;)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/os/Parcelable;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/os/Parcelable;)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/os/Parcelable;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    instance-of v0, p3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p3, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p3, v0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->restoreScrollState(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p3}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object p3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-super {p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/os/Parcelable;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onRestoreInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/os/Parcelable;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public bridge synthetic onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Landroid/os/Parcelable;
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)Landroid/os/Parcelable;
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;)",
            "Landroid/os/Parcelable;"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onSaveInstanceState(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->saveScrollState(Landroid/os/Parcelable;Lcom/google/android/material/appbar/AppBarLayout;)Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p1
.end method

.method public bridge synthetic onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual/range {p0 .. p6}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;Landroid/view/View;II)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method

.method public onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;Landroid/view/View;II)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            "Landroid/view/View;",
            "II)Z"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    and-int/lit8 p4, p5, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    if-eqz p4, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result p4

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p4, :cond_0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->g(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p1, :cond_1

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p1, :cond_2

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    iget-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetAnimator:Landroid/animation/ValueAnimator;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eqz p2, :cond_2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p2}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_2
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->lastNestedScrollingChildRef:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x5

    iput p6, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->lastStartedType:I

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method public bridge synthetic onStopNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;I)V
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onStopNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public onStopNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;I)V
    .locals 3
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->lastStartedType:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ne p4, v0, :cond_1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2, p3}, Lcom/google/android/material/appbar/AppBarLayout;->F(Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->C(Z)Z

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->lastNestedScrollingChildRef:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method restoreScrollState(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;Z)V
    .locals 3
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p2, :cond_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->savedState:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method saveScrollState(Landroid/os/Parcelable;Lcom/google/android/material/appbar/AppBarLayout;)Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;
    .locals 9
    .param p1    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcelable;",
            "TT;)",
            "Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v3, v2

    move v3, v2

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-ge v3, v1, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/2addr v5, v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-int/2addr v6, v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-gtz v6, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-ltz v5, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-nez p1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    sget-object p1, Landroidx/customview/view/AbsSavedState;->b:Landroidx/customview/view/AbsSavedState;

    :cond_0
    const/4 v7, 0x1

    move v8, v7

    invoke-direct {v1, p1}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 p1, 0x1

    const/4 v8, 0x2

    if-nez v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v6, p1

    move v6, p1

    const/4 v8, 0x3

    move v6, p1

    move v6, p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto :goto_1

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    move v6, v2

    const/4 v8, 0x3

    move v6, v2

    move v6, v2

    :goto_1
    const/4 v7, 0x4

    const/4 v7, 0x6

    iput-boolean v6, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->d:Z

    const/4 v8, 0x4

    const/4 v7, 0x4

    if-nez v6, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    neg-int v0, v0

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-lt v0, v6, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    move v0, p1

    move v0, p1

    const/4 v8, 0x2

    move v0, p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_2

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-boolean v0, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->c:Z

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput v3, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->e:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v4}, Landroidx/core/view/k1;->e0(Landroid/view/View;)I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getTopInset()I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    add-int/2addr v0, p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ne v5, v0, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    move v2, p1

    move v2, p1

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    iput-boolean v2, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->g:Z

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    int-to-float p1, v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    int-to-float p2, p2

    const/4 v8, 0x3

    div-float/2addr p1, p2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    iput p1, v1, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$SavedState;->f:F

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-object v1

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v7, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 p1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object p1
.end method

.method public setDragCallback(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;)V
    .locals 2
    .param p1    # Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->onDragCallback:Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method bridge synthetic setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;III)I
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual/range {p0 .. p5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;III)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    return p1
.end method

.method setHeaderTopBottomOffset(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;III)I
    .locals 10
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TT;III)I"
        }
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v1, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz p4, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-lt v0, p4, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-gt v0, p5, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p3, p4, p5}, Lo/a;->e(III)I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eq v0, v5, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->l()Z

    move-result p3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz p3, :cond_0

    const/4 v8, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, p2, v5}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->l(Lcom/google/android/material/appbar/AppBarLayout;I)I

    move-result p3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    move p3, v5

    move p3, v5

    const/4 v9, 0x4

    move p3, v5

    move p3, v5

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0, p3}, Lcom/google/android/material/appbar/h;->setTopAndBottomOffset(I)Z

    move-result p4

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    sub-int p5, v0, v5

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    sub-int p3, v5, p3

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iput p3, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetDelta:I

    const/4 v9, 0x0

    const/4 p3, 0x1

    const/4 v9, 0x2

    move v8, p3

    move v8, p3

    const/4 v9, 0x0

    if-eqz p4, :cond_2

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x5

    if-ge v1, v2, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout$f;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v2}, Lcom/google/android/material/appbar/AppBarLayout$f;->b()Lcom/google/android/material/appbar/AppBarLayout$d;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v3, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2}, Lcom/google/android/material/appbar/AppBarLayout$f;->c()I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    and-int/2addr v2, p3

    const/4 v9, 0x4

    if-eqz v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x2

    int-to-float v4, v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v3, p2, v2, v4}, Lcom/google/android/material/appbar/AppBarLayout$d;->a(Lcom/google/android/material/appbar/AppBarLayout;Landroid/view/View;F)V

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-nez p4, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->l()Z

    move-result p4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz p4, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->j(Landroid/view/View;)V

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result p4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p2, p4}, Lcom/google/android/material/appbar/AppBarLayout;->r(I)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-ge v5, v0, :cond_4

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 p3, -0x1

    :cond_4
    const/4 v9, 0x2

    move v6, p3

    move v6, p3

    const/4 v9, 0x6

    move v6, p3

    move v6, p3

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct/range {v2 .. v7}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->p(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;IIZ)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    move v1, p5

    move v1, p5

    const/4 v9, 0x5

    move v1, p5

    move v1, p5

    const/4 v9, 0x3

    const/4 v8, 0x5

    goto :goto_2

    :cond_5
    const/4 v9, 0x4

    iput v1, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->offsetDelta:I

    :cond_6
    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->o(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    return v1
.end method
