.class public Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;
.super Lcom/google/android/material/appbar/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ScrollingViewBehavior"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/appbar/g;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/appbar/g;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/material/R$styleable;->ScrollingViewBehavior_Layout:[I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget p2, Lcom/google/android/material/R$styleable;->ScrollingViewBehavior_Layout_behavior_overlapTop:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Lcom/google/android/material/appbar/g;->h(I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method private static k(Lcom/google/android/material/appbar/AppBarLayout;)I
    .locals 3
    .param p0    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@M~yi~/.~ @sau @ @  ~~c@ /@or@d o@t@b@~~i~14  ~b@~@ i l@~b~ mS@f@@ @@o~-K~olt @~fv~@o ~~n~~ o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    instance-of v0, p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->getTopBottomOffsetForScrollingSibling()I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x6

    move v2, v1

    return p0
.end method

.method private l(Landroid/view/View;Landroid/view/View;)V
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    instance-of v1, v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    sub-int/2addr v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;->access$200(Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/2addr v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/appbar/g;->f()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-int/2addr v1, v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, p2}, Lcom/google/android/material/appbar/g;->b(Landroid/view/View;)I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    sub-int/2addr v1, p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, v1}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    :cond_0
    const/4 v4, 0x2

    return-void
.end method

.method private m(Landroid/view/View;Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    instance-of v0, p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->p()Z

    move-result v0

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->F(Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Lcom/google/android/material/appbar/AppBarLayout;->C(Z)Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method bridge synthetic a(Ljava/util/List;)Landroid/view/View;
    .locals 2
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;->j(Ljava/util/List;)Lcom/google/android/material/appbar/AppBarLayout;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method c(Landroid/view/View;)F
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    instance-of v0, p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getDownNestedPreScrollRange()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;->k(Lcom/google/android/material/appbar/AppBarLayout;)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-int v3, v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-gt v3, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sub-int/2addr v0, v2

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    int-to-float p1, p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-float v0, v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    div-float/2addr p1, v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-float/2addr p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    return p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v1
.end method

.method e(Landroid/view/View;)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p1, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/appbar/AppBarLayout;->getTotalScrollRange()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0, p1}, Lcom/google/android/material/appbar/g;->e(Landroid/view/View;)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic getLeftAndRightOffset()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/android/material/appbar/h;->getLeftAndRightOffset()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic getTopAndBottomOffset()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/android/material/appbar/h;->getTopAndBottomOffset()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic isHorizontalOffsetEnabled()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/google/android/material/appbar/h;->isHorizontalOffsetEnabled()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic isVerticalOffsetEnabled()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/android/material/appbar/h;->isVerticalOffsetEnabled()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method j(Ljava/util/List;)Lcom/google/android/material/appbar/AppBarLayout;
    .locals 6
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;)",
            "Lcom/google/android/material/appbar/AppBarLayout;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ge v1, v0, :cond_1

    const/4 v5, 0x7

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v2, Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    instance-of v3, v2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v3, :cond_0

    const/4 v4, 0x0

    and-int/2addr v5, v4

    check-cast v2, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object v2

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object p1
.end method

.method public layoutDependsOn(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    instance-of p1, p3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p1
.end method

.method public onDependentViewChanged(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;->l(Landroid/view/View;Landroid/view/View;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;->m(Landroid/view/View;Landroid/view/View;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public onDependentViewRemoved(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)V
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    instance-of p2, p3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v1, 0x1

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    sget-object p2, Landroidx/core/view/accessibility/l0$a;->r:Landroidx/core/view/accessibility/l0$a;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p2}, Landroidx/core/view/accessibility/l0$a;->b()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1, p2}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    sget-object p2, Landroidx/core/view/accessibility/l0$a;->s:Landroidx/core/view/accessibility/l0$a;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p2}, Landroidx/core/view/accessibility/l0$a;->b()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1, p2}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    :cond_0
    const/4 v0, 0x6

    const/4 v0, 0x7

    return-void
.end method

.method public bridge synthetic onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/appbar/h;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-super/range {p0 .. p6}, Lcom/google/android/material/appbar/g;->onMeasureChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p1
.end method

.method public onRequestChildRectangleOnScreen(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 5
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q(Landroid/view/View;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/appbar/AppBarLayout$ScrollingViewBehavior;->j(Ljava/util/List;)Lcom/google/android/material/appbar/AppBarLayout;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p3, v2, p2}, Landroid/graphics/Rect;->offset(II)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/material/appbar/g;->a:Landroid/graphics/Rect;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2, v1, v1, v2, p1}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2, p3}, Landroid/graphics/Rect;->contains(Landroid/graphics/Rect;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    xor-int/lit8 p2, p4, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p2}, Lcom/google/android/material/appbar/AppBarLayout;->x(ZZ)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v1
.end method

.method public bridge synthetic setHorizontalOffsetEnabled(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/android/material/appbar/h;->setHorizontalOffsetEnabled(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic setLeftAndRightOffset(I)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/android/material/appbar/h;->setLeftAndRightOffset(I)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p1
.end method

.method public bridge synthetic setTopAndBottomOffset(I)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-super {p0, p1}, Lcom/google/android/material/appbar/h;->setTopAndBottomOffset(I)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic setVerticalOffsetEnabled(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/android/material/appbar/h;->setVerticalOffsetEnabled(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method
