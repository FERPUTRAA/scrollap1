.class public final Lcom/google/android/material/datepicker/k;
.super Lcom/google/android/material/datepicker/o;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/material/datepicker/o<",
        "TS;>;"
    }
.end annotation


# static fields
.field private static final e:Ljava/lang/String; = "THEME_RES_ID_KEY"

.field private static final f:Ljava/lang/String; = "DATE_SELECTOR_KEY"

.field private static final g:Ljava/lang/String; = "CALENDAR_CONSTRAINTS_KEY"


# instance fields
.field private b:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private c:Lcom/google/android/material/datepicker/DateSelector;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation
.end field

.field private d:Lcom/google/android/material/datepicker/CalendarConstraints;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/datepicker/o;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method static g0(Lcom/google/android/material/datepicker/DateSelector;ILcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/k;
    .locals 5
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/datepicker/CalendarConstraints;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TT;>;I",
            "Lcom/google/android/material/datepicker/CalendarConstraints;",
            ")",
            "Lcom/google/android/material/datepicker/k<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/material/datepicker/k;

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/google/android/material/datepicker/k;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Landroid/os/Bundle;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "__sSYDEIEMERTE_H"

    const-string v2, "T_s_DRY_IEMESHEE"

    const-string v2, "__TmSIEEKRHM_YED"

    const-string v2, "THEME_RES_ID_KEY"

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1, v2, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    const-string p1, "TAERoODELYE_EKTS_"

    const-string p1, "SREmEAYLEEK_ODTT_"

    const/4 v4, 0x6

    const-string p1, "YAOSDb_KCLTEE_TER"

    const-string p1, "DATE_SELECTOR_KEY"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p1, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string p0, "TDSYRLuOSNCAoANK__EITARC"

    const-string p0, "SENToKACLIARSERY_TCNDAO_"

    const/4 v4, 0x2

    const-string p0, "ERNDAT_pESRCCAKLSO_IANNY"

    const-string p0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p0, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v4, 0x0

    return-object v0
.end method


# virtual methods
.method public e0()Lcom/google/android/material/datepicker/DateSelector;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/k;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "i  tbha q taSgattsenhoc# rt hr nPraeieskgeihlt an wl M,eIreu t(actf oelerSl  tueelrtdebpeotocn. ht sateeaaaxd ttfombnctasn danmcteT.n edh rwftUmaesrtrl shei cD)ltloeneedu neIeec"

    const-string v1, "aegttbtaraalsmnseeicoabnurhwtcbawtece, mstI aldflPex terf( tcor  a iotr Ta ideterU euntrhhl# ctsull  rrM licStknnentemne.e Dse ti Itttehen oo eage dn csa htlfSenpahae h)e.etdode"

    const/4 v3, 0x3

    const-string v1, "T stsotrtaerm ePexn petelnocdeeul aeteheea.ed tlthlrMhsit laoietshtutiI t  cmandkiwacb gretluartea Ste,h ededrtnhchas(o ctes .srnn f a eI#tfDeofw relUa tnca Samennna c  tbie)gor"

    const-string v1, "dateSelector should not be null. Use MaterialTextInputPicker#newInstance() to create this fragment with a DateSelector, and call this method after the fragment has been created."

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onCreate(Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const-string v0, "TEDmS_K_EYIuHE_R"

    const-string v0, "EE__SDuIEKH_TYMR"

    const/4 v2, 0x5

    const-string v0, "ETKEo_DRM_EESIHY"

    const-string v0, "THEME_RES_ID_KEY"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput v0, p0, Lcom/google/android/material/datepicker/k;->b:I

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string v0, "K_OTEbSRTEYE_ADLE"

    const-string v0, "E__RALDpEOESYTTKE"

    const/4 v2, 0x2

    const-string v0, "ASCRETuO_DKLYETE_"

    const-string v0, "DATE_SELECTOR_KEY"

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/datepicker/k;->c:Lcom/google/android/material/datepicker/DateSelector;

    const-string v0, "KCCTEq_pRN_OAYLISNRAEDAT"

    const-string v0, "DREAKRYCqN_OANLCTEAIT_SN"

    const/4 v2, 0x0

    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p1, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/datepicker/k;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 11
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance v0, Landroid/view/ContextThemeWrapper;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x5

    iget v2, p0, Lcom/google/android/material/datepicker/k;->b:I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-direct {v0, v1, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object v3, p0, Lcom/google/android/material/datepicker/k;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v7, p0, Lcom/google/android/material/datepicker/k;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance v8, Lcom/google/android/material/datepicker/k$a;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v8, p0}, Lcom/google/android/material/datepicker/k$a;-><init>(Lcom/google/android/material/datepicker/k;)V

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-interface/range {v3 .. v8}, Lcom/google/android/material/datepicker/DateSelector;->G1(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;Lcom/google/android/material/datepicker/CalendarConstraints;Lcom/google/android/material/datepicker/n;)Landroid/view/View;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object p1
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v2, 0x6

    move v3, v2

    const-string v0, "_R_MKEESqsYH_TEE"

    const-string v0, "EYsME_T_EI_KRESH"

    const/4 v3, 0x4

    const-string v0, "SYsIT_EEEKHRMED_"

    const-string v0, "THEME_RES_ID_KEY"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/datepicker/k;->b:I

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "TSEmT_mYCAKE_ODEL"

    const-string v0, "DLEm_ES_YKEETCTOA"

    const/4 v3, 0x4

    const-string v0, "LDYCoTK_SETEE_ROA"

    const-string v0, "DATE_SELECTOR_KEY"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/datepicker/k;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, "DCSTAbLCOERRAK_oNT_YEASI"

    const-string v0, "IRR_oACTDTCN_OELESKYNASA"

    const/4 v3, 0x1

    const-string v0, "NDLRENuOISK_C_SETTRYNCAA"

    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/k;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method
