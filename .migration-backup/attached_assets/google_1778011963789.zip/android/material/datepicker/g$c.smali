.class Lcom/google/android/material/datepicker/g$c;
.super Lcom/google/android/material/datepicker/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/datepicker/g;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:I

.field final synthetic c:Lcom/google/android/material/datepicker/g;


# direct methods
.method constructor <init>(Lcom/google/android/material/datepicker/g;Landroid/content/Context;IZI)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/datepicker/g$c;->c:Lcom/google/android/material/datepicker/g;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p5, p0, Lcom/google/android/material/datepicker/g$c;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p2, p3, p4}, Lcom/google/android/material/datepicker/p;-><init>(Landroid/content/Context;IZ)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected calculateExtraLayoutSpace(Landroidx/recyclerview/widget/RecyclerView$c0;[I)V
    .locals 4
    .param p1    # Landroidx/recyclerview/widget/RecyclerView$c0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget p1, p0, Lcom/google/android/material/datepicker/g$c;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$c;->c:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput p1, p2, v1

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$c;->c:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput p1, p2, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$c;->c:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    aput p1, p2, v1

    const/4 v2, 0x0

    and-int/2addr v3, v2

    iget-object p1, p0, Lcom/google/android/material/datepicker/g$c;->c:Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/datepicker/g;->g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput p1, p2, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method
