.class public final Lcom/google/android/material/datepicker/h;
.super Landroidx/fragment/app/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/datepicker/h$f;,
        Lcom/google/android/material/datepicker/h$g;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Landroidx/fragment/app/c;"
    }
.end annotation


# static fields
.field private static final A:Ljava/lang/String; = "TITLE_TEXT_KEY"

.field private static final B:Ljava/lang/String; = "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

.field private static final C:Ljava/lang/String; = "POSITIVE_BUTTON_TEXT_KEY"

.field private static final D:Ljava/lang/String; = "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

.field private static final E:Ljava/lang/String; = "NEGATIVE_BUTTON_TEXT_KEY"

.field private static final F:Ljava/lang/String; = "INPUT_MODE_KEY"

.field static final G:Ljava/lang/Object;

.field static final H:Ljava/lang/Object;

.field static final I:Ljava/lang/Object;

.field public static final J:I = 0x0

.field public static final K:I = 0x1

.field private static final w:Ljava/lang/String; = "OVERRIDE_THEME_RES_ID"

.field private static final x:Ljava/lang/String; = "DATE_SELECTOR_KEY"

.field private static final y:Ljava/lang/String; = "CALENDAR_CONSTRAINTS_KEY"

.field private static final z:Ljava/lang/String; = "TITLE_TEXT_RES_ID_KEY"


# instance fields
.field private final a:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Lcom/google/android/material/datepicker/i<",
            "-TS;>;>;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Landroid/view/View$OnClickListener;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Landroid/content/DialogInterface$OnCancelListener;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Landroid/content/DialogInterface$OnDismissListener;",
            ">;"
        }
    .end annotation
.end field

.field private e:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private f:Lcom/google/android/material/datepicker/DateSelector;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation
.end field

.field private g:Lcom/google/android/material/datepicker/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/o<",
            "TS;>;"
        }
    .end annotation
.end field

.field private h:Lcom/google/android/material/datepicker/CalendarConstraints;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Lcom/google/android/material/datepicker/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/g<",
            "TS;>;"
        }
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private k:Ljava/lang/CharSequence;

.field private l:Z

.field private m:I

.field private n:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private o:Ljava/lang/CharSequence;

.field private p:I
    .annotation build Landroidx/annotation/e1;
    .end annotation
.end field

.field private q:Ljava/lang/CharSequence;

.field private r:Landroid/widget/TextView;

.field private s:Lcom/google/android/material/internal/CheckableImageButton;

.field private t:Lcom/google/android/material/shape/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private u:Landroid/widget/Button;

.field private v:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const-string v0, "_NsUGTCTMOsIFA_TRB"

    const-string v0, "TAsRBUMFTNTOOIC_G_"

    const/4 v2, 0x4

    const-string v0, "__BmTMGOUIACNOTFRT"

    const-string v0, "CONFIRM_BUTTON_TAG"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/material/datepicker/h;->G:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "TmNEoUABATCLGN_OT"

    const-string v0, "LACmUCNTTBGT_NEAO"

    const/4 v2, 0x6

    const-string v0, "ABETCbATOUCLNNGT_"

    const-string v0, "CANCEL_BUTTON_TAG"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/material/datepicker/h;->H:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, "T__NoLuOBGOGTAUET"

    const-string v0, "TTNGoOAOB_LG_UGET"

    const/4 v2, 0x7

    const-string v0, "GAUE_BNpGGT_OTOLT"

    const-string v0, "TOGGLE_BUTTON_TAG"

    const/4 v2, 0x0

    const/4 v1, 0x0

    sput-object v0, Lcom/google/android/material/datepicker/h;->I:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Landroidx/fragment/app/c;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->a:Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x4

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->d:Ljava/util/LinkedHashSet;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private static B0(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    new-instance v0, Landroid/graphics/drawable/StateListDrawable;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    const/4 v4, 0x4

    const v1, 0x10100a0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    filled-new-array {v1}, [I

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget v2, Lcom/google/android/material/R$drawable;->material_ic_calendar_black_24dp:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v2}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    or-int/2addr v4, v3

    new-array v1, v1, [I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget v2, Lcom/google/android/material/R$drawable;->material_ic_edit_black_24dp:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p0, v2}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p0}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method private C0(Landroid/view/Window;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/datepicker/h;->v:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget v1, Lcom/google/android/material/R$id;->fullscreen_header:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/material/internal/y;->f(Landroid/view/View;)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1, v3, v1, v2}, Lcom/google/android/material/internal/e;->b(Landroid/view/Window;ZLjava/lang/Integer;Ljava/lang/Integer;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v2, Lcom/google/android/material/datepicker/h$c;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v2, p0, v1, v0, p1}, Lcom/google/android/material/datepicker/h$c;-><init>(Lcom/google/android/material/datepicker/h;ILandroid/view/View;I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2}, Landroidx/core/view/k1;->a2(Landroid/view/View;Landroidx/core/view/z0;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-boolean v3, p0, Lcom/google/android/material/datepicker/h;->v:Z

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method

.method private D0()Lcom/google/android/material/datepicker/DateSelector;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->f:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const-string v1, "KSR_EEADqE_LEbTYO"

    const-string v1, "EKAS_bRELYODTT_EE"

    const/4 v3, 0x0

    const-string v1, "_KsEESCYTLRTOAED_"

    const-string v1, "DATE_SELECTOR_KEY"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->f:Lcom/google/android/material/datepicker/DateSelector;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->f:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method private static F0(Landroid/content/Context;)I
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_calendar_content_padding:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/android/material/datepicker/Month;->e()Lcom/google/android/material/datepicker/Month;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, v1, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_calendar_day_width:I

    const/4 v5, 0x6

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget v3, Lcom/google/android/material/R$dimen;->mtrl_calendar_month_horizontal_padding:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, v3}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    mul-int/lit8 v0, v0, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    mul-int/2addr v2, v1

    const/4 v5, 0x0

    add-int/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    mul-int/2addr v1, p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/2addr v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v0
.end method

.method private H0(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/datepicker/h;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-interface {v0, p1}, Lcom/google/android/material/datepicker/DateSelector;->s0(Landroid/content/Context;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method

.method private I0(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/material/datepicker/h;->I:Ljava/lang/Object;

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/material/datepicker/h;->B0(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/AppCompatImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/material/datepicker/h;->m:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/internal/CheckableImageButton;->setChecked(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/datepicker/h;->V0(Lcom/google/android/material/internal/CheckableImageButton;)V

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v3, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/datepicker/h$e;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/material/datepicker/h$e;-><init>(Lcom/google/android/material/datepicker/h;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method static J0(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    move v2, v1

    const v0, 0x101020d

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/datepicker/h;->M0(Landroid/content/Context;I)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p0
.end method

.method static K0(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget v0, Lcom/google/android/material/R$attr;->nestedScrollable:I

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/datepicker/h;->M0(Landroid/content/Context;I)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p0
.end method

.method static L0(Lcom/google/android/material/datepicker/h$f;)Lcom/google/android/material/datepicker/h;
    .locals 6
    .param p0    # Lcom/google/android/material/datepicker/h$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/material/datepicker/h$f<",
            "TS;>;)",
            "Lcom/google/android/material/datepicker/h<",
            "TS;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/material/datepicker/h;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v0}, Lcom/google/android/material/datepicker/h;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/android/material/datepicker/h$f;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v3, "IRDmIDuETER_VR_OSEM_E"

    const-string v3, "ERETRRuIEOED_VSI_D_EM"

    const/4 v5, 0x1

    const-string v3, "OVERRIDE_THEME_RES_ID"

    const/4 v5, 0x3

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "EKEDoTL_OACEYR_ET"

    const-string v2, "DATE_SELECTOR_KEY"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/google/android/material/datepicker/h$f;->a:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v2, "CNRSEbCNSROIL_N_KEAYpDTT"

    const-string v2, "OLISCTNp_YCENSR_DAERNKTA"

    const/4 v5, 0x5

    const-string v2, "LRAARTuS_CNICENTYAS_OEKN"

    const-string v2, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/material/datepicker/h$f;->c:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v2, "_IqKTE_pSEE_EIYXRLDT_"

    const-string v2, "T_LTRXEIqE_I__EEKDTSY"

    const/4 v5, 0x4

    const-string v2, "_TYTE_KEqER_TLS_XIIED"

    const-string v2, "TITLE_TEXT_RES_ID_KEY"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget v3, p0, Lcom/google/android/material/datepicker/h$f;->d:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string v2, "_EsTEXTKTILT_E"

    const-string v2, "TITLE_TEXT_KEY"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/material/datepicker/h$f;->e:Ljava/lang/CharSequence;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v2, "MKYmPEDIT_OEN_"

    const-string v2, "INPUT_MODE_KEY"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v3, p0, Lcom/google/android/material/datepicker/h$f;->k:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, "OSTsoI__UTETYRTPXEIEDEITO_NBV_K"

    const-string v2, "YEsBRIIN_DPTKE_ET_IUEST_TO_OXVT"

    const/4 v5, 0x7

    const-string v2, "ST_E_bTXOUVKBITI__E_TDRYOSPENIT"

    const-string v2, "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v3, p0, Lcom/google/android/material/datepicker/h$f;->f:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v2, "UBKESPu_TTOTVYETmOT_IXI_"

    const-string v2, "_IUmSEPXTTYTKTETOI_E_VOB"

    const/4 v5, 0x2

    const-string v2, "NITPEB_pE__TKUIOVYXOTEST"

    const-string v2, "POSITIVE_BUTTON_TEXT_KEY"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/material/datepicker/h$f;->g:Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v2, "_DOTX_UEq_RKEITToA_Y_BTESNVGEEI"

    const-string v2, "VE_To__B_EATEUOKNSID_INXTRGTEEY"

    const/4 v5, 0x5

    const-string v2, "EXsI_A_O__DT_RNKVTTNGIEBETEYTEU"

    const-string v2, "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/android/material/datepicker/h$f;->h:I

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v2, "TNAmTTKBENbTGIVEEYU__TOE"

    const-string v2, "NNU_EbETETYAIG_EKTOVTTBX"

    const/4 v5, 0x0

    const-string v2, "NTVTo_UNIETA_EE_XEGYOKBT"

    const-string v2, "NEGATIVE_BUTTON_TEXT_KEY"

    const/4 v5, 0x3

    iget-object p0, p0, Lcom/google/android/material/datepicker/h$f;->i:Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2, p0}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v0
.end method

.method static M0(Landroid/content/Context;I)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    sget v0, Lcom/google/android/material/R$attr;->materialCalendarStyle:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/material/datepicker/g;

    const-class v1, Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/material/datepicker/g;

    const-class v1, Lcom/google/android/material/datepicker/g;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    filled-new-array {p1}, [I

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0, p1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p1
.end method

.method private R0()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/datepicker/h;->H0(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/datepicker/h;->h:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v1, v0, v2}, Lcom/google/android/material/datepicker/g;->C0(Lcom/google/android/material/datepicker/DateSelector;ILcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/g;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/google/android/material/datepicker/h;->i:Lcom/google/android/material/datepicker/g;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/material/datepicker/h;->h:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1, v0, v2}, Lcom/google/android/material/datepicker/k;->g0(Lcom/google/android/material/datepicker/DateSelector;ILcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/k;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->i:Lcom/google/android/material/datepicker/g;

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->g:Lcom/google/android/material/datepicker/o;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->U0()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->q()Landroidx/fragment/app/a0;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget v1, Lcom/google/android/material/R$id;->mtrl_calendar_frame:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/material/datepicker/h;->g:Lcom/google/android/material/datepicker/o;

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/a0;->C(ILandroidx/fragment/app/Fragment;)Landroidx/fragment/app/a0;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroidx/fragment/app/a0;->s()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->g:Lcom/google/android/material/datepicker/o;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/datepicker/h$d;

    const/4 v4, 0x0

    invoke-direct {v1, p0}, Lcom/google/android/material/datepicker/h$d;-><init>(Lcom/google/android/material/datepicker/h;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/datepicker/o;->c0(Lcom/google/android/material/datepicker/n;)Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public static S0()J
    .locals 4

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/Month;->e()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-wide v0, v0, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0
.end method

.method public static T0()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/material/datepicker/u;->t()Ljava/util/Calendar;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-wide v0
.end method

.method private U0()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/datepicker/h;->E0()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->r:Landroid/widget/TextView;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$string;->mtrl_picker_announce_current_selection:I

    const/4 v6, 0x7

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x7

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    aput-object v0, v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->r:Landroid/widget/TextView;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    return-void
.end method

.method private V0(Lcom/google/android/material/internal/CheckableImageButton;)V
    .locals 3
    .param p1    # Lcom/google/android/material/internal/CheckableImageButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/internal/CheckableImageButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$string;->mtrl_picker_toggle_to_calendar_input_mode:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$string;->mtrl_picker_toggle_to_text_input_mode:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic e0(Lcom/google/android/material/datepicker/h;)Ljava/util/LinkedHashSet;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/datepicker/h;->a:Ljava/util/LinkedHashSet;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic f0(Lcom/google/android/material/datepicker/h;)Ljava/util/LinkedHashSet;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/datepicker/h;->b:Ljava/util/LinkedHashSet;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic g0(Lcom/google/android/material/datepicker/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->U0()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic h0(Lcom/google/android/material/datepicker/h;)Lcom/google/android/material/datepicker/DateSelector;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic i0(Lcom/google/android/material/datepicker/h;)Landroid/widget/Button;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic j0(Lcom/google/android/material/datepicker/h;)Lcom/google/android/material/internal/CheckableImageButton;
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic l0(Lcom/google/android/material/datepicker/h;Lcom/google/android/material/internal/CheckableImageButton;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/datepicker/h;->V0(Lcom/google/android/material/internal/CheckableImageButton;)V

    return-void
.end method

.method static synthetic n0(Lcom/google/android/material/datepicker/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->R0()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public A0()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->a:Ljava/util/LinkedHashSet;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x5

    return-void
.end method

.method public E0()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-interface {v0, v1}, Lcom/google/android/material/datepicker/DateSelector;->b1(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public final G0()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TS;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/google/android/material/datepicker/DateSelector;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public N0(Landroid/content/DialogInterface$OnCancelListener;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public O0(Landroid/content/DialogInterface$OnDismissListener;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->d:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p1
.end method

.method public P0(Landroid/view/View$OnClickListener;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method public Q0(Lcom/google/android/material/datepicker/i;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/i<",
            "-TS;>;)Z"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->a:Ljava/util/LinkedHashSet;

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1
.end method

.method public o0(Landroid/content/DialogInterface$OnCancelListener;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .locals 4
    .param p1    # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->c:Ljava/util/LinkedHashSet;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v1, Landroid/content/DialogInterface$OnCancelListener;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnCancelListener;->onCancel(Landroid/content/DialogInterface;)V

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onCancel(Landroid/content/DialogInterface;)V

    const/4 v3, 0x6

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x2

    and-int/2addr v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "VTR_EbIHEOMSDEDRu_REE"

    const-string v0, "EEE_MHuERDSR_D_VRIOTE"

    const/4 v2, 0x6

    const-string v0, "ORDTEVu__EERMEI_SHERI"

    const-string v0, "OVERRIDE_THEME_RES_ID"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/datepicker/h;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "SL_ECYRpED_pKEEAT"

    const-string v0, "DTE_EL_pEYCKSEAOR"

    const/4 v2, 0x4

    const-string v0, "RS__EETEqECOLTKDY"

    const-string v0, "DATE_SELECTOR_KEY"

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->f:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "OCsA_TNLETDNAESNqRI_SAYK"

    const-string v0, "_KSLNTYSqAEO_NRENICTACAD"

    const/4 v2, 0x0

    const-string v0, "TTLmC_SERIADNEO_CSKARYNN"

    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->h:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "ESsTo_TLRIYTKXE___EDE"

    const-string v0, "YSsXEEEDEIRIT_LT_T__K"

    const/4 v2, 0x7

    const-string v0, "SLEX_bTKD_YIET_ITETE_"

    const-string v0, "TITLE_TEXT_RES_ID_KEY"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/datepicker/h;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "T_XYKTuEE_TEIT"

    const-string v0, "TT_mYTEEX_ITKE"

    const/4 v2, 0x3

    const-string v0, "T_TKE_IpLXTEET"

    const-string v0, "TITLE_TEXT_KEY"

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->k:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "KP_MoOTDYNE_IE"

    const/4 v2, 0x0

    const-string v0, "YIUD_EKTqPENM_"

    const-string v0, "INPUT_MODE_KEY"

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput v0, p0, Lcom/google/android/material/datepicker/h;->m:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "_OsRET__VTIOPTDYbNXIETI_EEKS_TB"

    const-string v0, "BSXN_bTEEKIITTET_RP__OO_DYSTIVE"

    const/4 v2, 0x2

    const-string v0, "ED_mY_I_ISORTITSTXOVK__EETTNBEP"

    const-string v0, "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    iput v0, p0, Lcom/google/android/material/datepicker/h;->n:I

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, "NYS_oXTTOVEPuTIEUTO__KBT"

    const-string v0, "O__YOXuTSVITN_PEUKBTIETT"

    const/4 v2, 0x7

    const-string v0, "TYT_PbXVTIES_T_NTIBOEKUE"

    const-string v0, "POSITIVE_BUTTON_TEXT_KEY"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/material/datepicker/h;->o:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "TETKGNuIO_UVETSNEDB__XTREpIY_E_"

    const-string v0, "_XERSTIpN_V_TENGOETKDYEIEUT_B_A"

    const/4 v2, 0x3

    const-string v0, "IITUNETpK_EY_OXR_NEE_TDVG_TBEST"

    const-string v0, "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/datepicker/h;->p:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "BUKTTTOEqEXT_AqEIETY_NN_"

    const-string v0, "_IUETTO_qKBETNNEYVTA_XET"

    const/4 v2, 0x4

    const-string v0, "NEGATIVE_BUTTON_TEXT_KEY"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/datepicker/h;->q:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public final onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
    .locals 8
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance p1, Landroid/app/Dialog;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/datepicker/h;->H0(Landroid/content/Context;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p1, v0, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-boolean v1, p0, Lcom/google/android/material/datepicker/h;->l:Z

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget v1, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-class v2, Lcom/google/android/material/datepicker/h;

    const-class v2, Lcom/google/android/material/datepicker/h;

    const/4 v7, 0x1

    const-class v2, Lcom/google/android/material/datepicker/h;

    const-class v2, Lcom/google/android/material/datepicker/h;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0, v1, v2}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v2, Lcom/google/android/material/shape/j;

    const/4 v7, 0x5

    sget v3, Lcom/google/android/material/R$attr;->materialCalendarStyle:I

    const/4 v7, 0x7

    sget v4, Lcom/google/android/material/R$style;->Widget_MaterialComponents_MaterialCalendar:I

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v5, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v2, v0, v5, v3, v4}, Lcom/google/android/material/shape/j;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-object v2, p0, Lcom/google/android/material/datepicker/h;->t:Lcom/google/android/material/shape/j;

    const/4 v7, 0x0

    invoke-virtual {v2, v0}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->t:Lcom/google/android/material/shape/j;

    const/4 v7, 0x3

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->t:Lcom/google/android/material/shape/j;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v1}, Landroidx/core/view/k1;->R(Landroid/view/View;)F

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->n0(F)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object p1
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 5
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-boolean p3, p0, Lcom/google/android/material/datepicker/h;->l:Z

    const/4 v4, 0x6

    if-eqz p3, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget p3, Lcom/google/android/material/R$layout;->mtrl_picker_fullscreen:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget p3, Lcom/google/android/material/R$layout;->mtrl_picker_dialog:I

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, p3, p2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean p3, p0, Lcom/google/android/material/datepicker/h;->l:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p3, :cond_1

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    sget p3, Lcom/google/android/material/R$id;->mtrl_calendar_frame:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p2}, Lcom/google/android/material/datepicker/h;->F0(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, -0x2

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget p3, Lcom/google/android/material/R$id;->mtrl_calendar_main_pane:I

    const/4 v4, 0x5

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p2}, Lcom/google/android/material/datepicker/h;->F0(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v2, -0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget p3, Lcom/google/android/material/R$id;->mtrl_picker_header_selection_text:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast p3, Landroid/widget/TextView;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object p3, p0, Lcom/google/android/material/datepicker/h;->r:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p3, v0}, Landroidx/core/view/k1;->D1(Landroid/view/View;I)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget p3, Lcom/google/android/material/R$id;->mtrl_picker_header_toggle:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast p3, Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object p3, p0, Lcom/google/android/material/datepicker/h;->s:Lcom/google/android/material/internal/CheckableImageButton;

    const/4 v4, 0x5

    const/4 v3, 0x6

    sget p3, Lcom/google/android/material/R$id;->mtrl_picker_title_text:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    check-cast p3, Landroid/widget/TextView;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->k:Ljava/lang/CharSequence;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_2

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/material/datepicker/h;->j:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p3, v1}, Landroid/widget/TextView;->setText(I)V

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, p2}, Lcom/google/android/material/datepicker/h;->I0(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget p2, Lcom/google/android/material/R$id;->confirm_button:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast p2, Landroid/widget/Button;

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object p2, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->D0()Lcom/google/android/material/datepicker/DateSelector;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p2}, Lcom/google/android/material/datepicker/DateSelector;->X1()Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz p2, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Landroid/view/View;->setEnabled(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_3

    :cond_3
    const/4 v4, 0x5

    iget-object p2, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p3, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, p3}, Landroid/view/View;->setEnabled(Z)V

    :goto_3
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object p3, Lcom/google/android/material/datepicker/h;->G:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/material/datepicker/h;->o:Ljava/lang/CharSequence;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p2, :cond_4

    const/4 v4, 0x4

    iget-object p3, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_4

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget p2, p0, Lcom/google/android/material/datepicker/h;->n:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p2, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object p3, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(I)V

    :cond_5
    :goto_4
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/android/material/datepicker/h;->u:Landroid/widget/Button;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p3, Lcom/google/android/material/datepicker/h$a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p3, p0}, Lcom/google/android/material/datepicker/h$a;-><init>(Lcom/google/android/material/datepicker/h;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget p2, Lcom/google/android/material/R$id;->cancel_button:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x4

    check-cast p2, Landroid/widget/Button;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object p3, Lcom/google/android/material/datepicker/h;->H:Ljava/lang/Object;

    const/4 v4, 0x7

    invoke-virtual {p2, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object p3, p0, Lcom/google/android/material/datepicker/h;->q:Ljava/lang/CharSequence;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p3, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_5

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x3

    iget p3, p0, Lcom/google/android/material/datepicker/h;->p:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p3, :cond_7

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(I)V

    :cond_7
    :goto_5
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance p3, Lcom/google/android/material/datepicker/h$b;

    invoke-direct {p3, p0}, Lcom/google/android/material/datepicker/h$b;-><init>(Lcom/google/android/material/datepicker/h;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v3, 0x1

    move v4, v3

    return-object p1
.end method

.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 4
    .param p1    # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->d:Ljava/util/LinkedHashSet;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v1, Landroid/content/DialogInterface$OnDismissListener;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Landroid/content/DialogInterface$OnDismissListener;->onDismiss(Landroid/content/DialogInterface;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onDismiss(Landroid/content/DialogInterface;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 5
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    invoke-super {p0, p1}, Landroidx/fragment/app/c;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "I_sDMEEREREOE_ITVSRD_"

    const/4 v4, 0x2

    const-string v0, "SRsRHDEE_EVED_RIM_IOT"

    const-string v0, "OVERRIDE_THEME_RES_ID"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/android/material/datepicker/h;->e:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "KE_mYOTASERmT_EEC"

    const-string v0, "AEEmCYTE_OST_EKRL"

    const/4 v4, 0x3

    const-string v0, "TERDoSAKEYE_OC_EL"

    const-string v0, "DATE_SELECTOR_KEY"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->f:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/material/datepicker/CalendarConstraints$b;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->h:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Lcom/google/android/material/datepicker/CalendarConstraints$b;-><init>(Lcom/google/android/material/datepicker/CalendarConstraints;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->i:Lcom/google/android/material/datepicker/g;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/g;->x0()Lcom/google/android/material/datepicker/Month;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->i:Lcom/google/android/material/datepicker/g;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/datepicker/g;->x0()Lcom/google/android/material/datepicker/Month;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-wide v1, v1, Lcom/google/android/material/datepicker/Month;->f:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/datepicker/CalendarConstraints$b;->c(J)Lcom/google/android/material/datepicker/CalendarConstraints$b;

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, "E_CNTbYNACSRo_STIADEOLRN"

    const-string v1, "NEDKoNYR_I_CTONESCARLSAT"

    const/4 v4, 0x1

    const-string v1, "_TLKTEuS_ADYCRIRNSCNNEAO"

    const-string v1, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints$b;->a()Lcom/google/android/material/datepicker/CalendarConstraints;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "__TDXRKpEbT__TTYLIEES"

    const-string v0, "TEEIRb_TDEYTEK___XLTS"

    const-string v0, "YSIIE_X_qEERETT__TLTD"

    const-string v0, "TITLE_TEXT_RES_ID_KEY"

    const/4 v4, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/datepicker/h;->j:I

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v0, "ETsETu_EIKYXLT"

    const-string v0, "YT_XTEuETK_LEI"

    const/4 v4, 0x2

    const-string v0, "TITLE_TEXT_KEY"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->k:Ljava/lang/CharSequence;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v0, "TTImSEDB_NS_PIEOO__XTTUpVERK_ET"

    const-string v0, "RO__BOTpXEP_UDT_EYNVSSTITIE_EKT"

    const/4 v4, 0x1

    const-string v0, "N_EToOISRSBKOTEITXPUTV_T_DEI__Y"

    const-string v0, "POSITIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/android/material/datepicker/h;->n:I

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, "OTKPVbBT_EYUE_OTSIE_IqTX"

    const-string v0, "TTXYPSOEqIETO_TK_VTU_BEI"

    const/4 v4, 0x6

    const-string v0, "YTIOVNuXOEKIUP_ETTT__EST"

    const-string v0, "POSITIVE_BUTTON_TEXT_KEY"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->o:Ljava/lang/CharSequence;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const-string v0, "TTEEGITpUYETVIX_OE__s_NDTSAR_EB"

    const-string v0, "TEsD_TIEERT_Y_XTSBNNGUEEV_A_OIT"

    const/4 v4, 0x4

    const-string v0, "ATKTS__BqTEEE_DUVTEXIRN_GIEYNTO"

    const-string v0, "NEGATIVE_BUTTON_TEXT_RES_ID_KEY"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/datepicker/h;->p:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, "XUsB__mT_OTTEYANIVTTGEKE"

    const-string v0, "TAVmE_Y_BN_UTTEIXGOKTETN"

    const/4 v4, 0x5

    const-string v0, "N__mGTEETVOE_YIKTTUAEBXN"

    const-string v0, "NEGATIVE_BUTTON_TEXT_KEY"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->q:Ljava/lang/CharSequence;

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public onStart()V
    .locals 11

    const/4 v9, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-super {p0}, Landroidx/fragment/app/c;->onStart()V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p0}, Landroidx/fragment/app/c;->requireDialog()Landroid/app/Dialog;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-boolean v1, p0, Lcom/google/android/material/datepicker/h;->l:Z

    const/4 v10, 0x4

    if-eqz v1, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v1, -0x1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/google/android/material/datepicker/h;->t:Lcom/google/android/material/shape/j;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-direct {p0, v0}, Lcom/google/android/material/datepicker/h;->C0(Landroid/view/Window;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v1, -0x2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_calendar_dialog_background_inset:I

    const/4 v10, 0x7

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance v1, Landroid/graphics/Rect;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {v1, v8, v8, v8, v8}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance v2, Landroid/graphics/drawable/InsetDrawable;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v4, p0, Lcom/google/android/material/datepicker/h;->t:Lcom/google/android/material/shape/j;

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    move v5, v8

    move v5, v8

    const/4 v10, 0x3

    move v5, v8

    move v5, v8

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    move v6, v8

    const/4 v10, 0x4

    move v6, v8

    move v6, v8

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    move v7, v8

    move v7, v8

    const/4 v10, 0x3

    move v7, v8

    move v7, v8

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-direct/range {v3 .. v8}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v10, 0x5

    invoke-virtual {v0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v2, Lq4/a;

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/c;->requireDialog()Landroid/app/Dialog;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {v2, v3, v1}, Lq4/a;-><init>(Landroid/app/Dialog;Landroid/graphics/Rect;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/h;->R0()V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    return-void
.end method

.method public onStop()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->g:Lcom/google/android/material/datepicker/o;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/o;->d0()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0}, Landroidx/fragment/app/c;->onStop()V

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-void
.end method

.method public q0(Landroid/content/DialogInterface$OnDismissListener;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->d:Ljava/util/LinkedHashSet;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method

.method public r0(Landroid/view/View$OnClickListener;)Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method public t0(Lcom/google/android/material/datepicker/i;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/i<",
            "-TS;>;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->a:Ljava/util/LinkedHashSet;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method

.method public v0()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->c:Ljava/util/LinkedHashSet;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public x0()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->d:Ljava/util/LinkedHashSet;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public z0()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/h;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method
