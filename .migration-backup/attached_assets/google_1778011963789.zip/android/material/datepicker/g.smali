.class public final Lcom/google/android/material/datepicker/g;
.super Lcom/google/android/material/datepicker/o;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/datepicker/g$l;,
        Lcom/google/android/material/datepicker/g$k;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/material/datepicker/o<",
        "TS;>;"
    }
.end annotation


# static fields
.field private static final l:Ljava/lang/String; = "THEME_RES_ID_KEY"

.field private static final m:Ljava/lang/String; = "GRID_SELECTOR_KEY"

.field private static final n:Ljava/lang/String; = "CALENDAR_CONSTRAINTS_KEY"

.field private static final o:Ljava/lang/String; = "CURRENT_MONTH_KEY"

.field private static final p:I = 0x3

.field static final q:Ljava/lang/Object;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field static final r:Ljava/lang/Object;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field static final s:Ljava/lang/Object;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field static final t:Ljava/lang/Object;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field


# instance fields
.field private b:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private c:Lcom/google/android/material/datepicker/DateSelector;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation
.end field

.field private d:Lcom/google/android/material/datepicker/CalendarConstraints;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Lcom/google/android/material/datepicker/Month;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Lcom/google/android/material/datepicker/g$k;

.field private g:Lcom/google/android/material/datepicker/b;

.field private h:Landroidx/recyclerview/widget/RecyclerView;

.field private i:Landroidx/recyclerview/widget/RecyclerView;

.field private j:Landroid/view/View;

.field private k:Landroid/view/View;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string v0, "SAsGPITO__RGOHUEVN_MT"

    const/4 v2, 0x6

    const-string v0, "_Rs_THOUIGAGETSP_MWON"

    const-string v0, "MONTHS_VIEW_GROUP_TAG"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/material/datepicker/g;->q:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "NAVIGATION_PREV_TAG"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/datepicker/g;->r:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "GANmGN_TVNAT_mITIXA"

    const-string v0, "TTVmIN_TNANGAEIAXG_"

    const/4 v2, 0x4

    const-string v0, "ETAVoAGA_XGTNOT_INN"

    const-string v0, "NAVIGATION_NEXT_TAG"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/material/datepicker/g;->s:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "_ESOObRTEGoL_GTALEG"

    const-string v0, "G_OLoRTLGEAESGCOTE_"

    const/4 v2, 0x1

    const-string v0, "AG_SEEuCRT_EGOTGLOT"

    const-string v0, "SELECTOR_TOGGLE_TAG"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/material/datepicker/g;->t:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/datepicker/o;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private static A0(Landroid/content/Context;)I
    .locals 7
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "asou~@ p oo~@~ @t@@~~vS idlr @yfbo~b~ml~@~~K@~bo@co~ ~   ~~ @@@@ .@  i ~@n@@~~fi~4~@ M1-t /~~@/@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_calendar_navigation_height:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget v1, Lcom/google/android/material/R$dimen;->mtrl_calendar_navigation_top_padding:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    add-int/2addr v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    sget v1, Lcom/google/android/material/R$dimen;->mtrl_calendar_navigation_bottom_padding:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/2addr v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget v1, Lcom/google/android/material/R$dimen;->mtrl_calendar_days_of_week_height:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget v2, Lcom/google/android/material/datepicker/l;->f:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    sget v3, Lcom/google/android/material/R$dimen;->mtrl_calendar_day_height:I

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {p0, v3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    mul-int/2addr v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/lit8 v2, v2, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget v4, Lcom/google/android/material/R$dimen;->mtrl_calendar_month_vertical_padding:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0, v4}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    mul-int/2addr v2, v4

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    add-int/2addr v3, v2

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_calendar_bottom_padding:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    add-int/2addr v0, v1

    const/4 v6, 0x0

    add-int/2addr v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int/2addr v0, p0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return v0
.end method

.method public static C0(Lcom/google/android/material/datepicker/DateSelector;ILcom/google/android/material/datepicker/CalendarConstraints;)Lcom/google/android/material/datepicker/g;
    .locals 5
    .param p0    # Lcom/google/android/material/datepicker/DateSelector;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/datepicker/CalendarConstraints;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TT;>;I",
            "Lcom/google/android/material/datepicker/CalendarConstraints;",
            ")",
            "Lcom/google/android/material/datepicker/g<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/material/datepicker/g;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/material/datepicker/g;-><init>()V

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v1, Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v2, "_EKH_DYIqRM_ESTE"

    const-string v2, "THEME_RES_ID_KEY"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p1, "ORSCEbGR_KYE_DLIE"

    const/4 v4, 0x0

    const-string p1, "LCsIS_REKE_YRDOTE"

    const-string p1, "GRID_SELECTOR_KEY"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, p1, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string p0, "TAEmLADONTNNI_RA_CYRSCSu"

    const-string p0, "DNALESuTRTONNCCKS_AYRIA_"

    const/4 v4, 0x4

    const-string p0, "L_CIoADARKEROTTNCSEASY_N"

    const-string p0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, p0, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo p0, "p_NEHbET_NTKOYRMC"

    const-string p0, "MNKTRTOpECHNE_U_Y"

    const/4 v4, 0x1

    const-string p0, "MEK_YNuHERTNOR_UC"

    const-string p0, "CURRENT_MONTH_KEY"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/datepicker/CalendarConstraints;->n()Lcom/google/android/material/datepicker/Month;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, p0, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method private D0(I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v3, 0x4

    new-instance v1, Lcom/google/android/material/datepicker/g$a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1}, Lcom/google/android/material/datepicker/g$a;-><init>(Lcom/google/android/material/datepicker/g;I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic g0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic h0(Lcom/google/android/material/datepicker/g;)Lcom/google/android/material/datepicker/CalendarConstraints;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic i0(Lcom/google/android/material/datepicker/g;)Lcom/google/android/material/datepicker/DateSelector;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic j0(Lcom/google/android/material/datepicker/g;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic l0(Lcom/google/android/material/datepicker/g;)Lcom/google/android/material/datepicker/b;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->g:Lcom/google/android/material/datepicker/b;

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-object p0
.end method

.method static synthetic n0(Lcom/google/android/material/datepicker/g;)Landroid/view/View;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/datepicker/g;->k:Landroid/view/View;

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic o0(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/Month;)Lcom/google/android/material/datepicker/Month;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method private q0(Landroid/view/View;Lcom/google/android/material/datepicker/m;)V
    .locals 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/datepicker/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget v0, Lcom/google/android/material/R$id;->month_navigation_fragment_toggle:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object v1, Lcom/google/android/material/datepicker/g;->t:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Lcom/google/android/material/datepicker/g$f;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v1, p0}, Lcom/google/android/material/datepicker/g$f;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget v1, Lcom/google/android/material/R$id;->month_navigation_previous:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v1, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v2, Lcom/google/android/material/datepicker/g;->r:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget v2, Lcom/google/android/material/R$id;->month_navigation_next:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v2, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v3, Lcom/google/android/material/datepicker/g;->s:Ljava/lang/Object;

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget v3, Lcom/google/android/material/R$id;->mtrl_calendar_year_selector_frame:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v3, p0, Lcom/google/android/material/datepicker/g;->j:Landroid/view/View;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget v3, Lcom/google/android/material/R$id;->mtrl_calendar_day_selector_frame:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/material/datepicker/g;->k:Landroid/view/View;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object p1, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/g;->F0(Lcom/google/android/material/datepicker/g$k;)V

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/datepicker/Month;->o()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v3, Lcom/google/android/material/datepicker/g$g;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v3, p0, p2, v0}, Lcom/google/android/material/datepicker/g$g;-><init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;Lcom/google/android/material/button/MaterialButton;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1, v3}, Landroidx/recyclerview/widget/RecyclerView;->addOnScrollListener(Landroidx/recyclerview/widget/RecyclerView$u;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance p1, Lcom/google/android/material/datepicker/g$h;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p1, p0}, Lcom/google/android/material/datepicker/g$h;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p1, Lcom/google/android/material/datepicker/g$i;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p1, p0, p2}, Lcom/google/android/material/datepicker/g$i;-><init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p1, Lcom/google/android/material/datepicker/g$j;

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-direct {p1, p0, p2}, Lcom/google/android/material/datepicker/g$j;-><init>(Lcom/google/android/material/datepicker/g;Lcom/google/android/material/datepicker/m;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method private r0()Landroidx/recyclerview/widget/RecyclerView$o;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Lcom/google/android/material/datepicker/g$e;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/android/material/datepicker/g$e;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method static z0(Landroid/content/Context;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget v0, Lcom/google/android/material/R$dimen;->mtrl_calendar_day_height:I

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0
.end method


# virtual methods
.method B0()Landroidx/recyclerview/widget/LinearLayoutManager;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method E0(Lcom/google/android/material/datepicker/Month;)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    check-cast v0, Lcom/google/android/material/datepicker/m;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/datepicker/m;->d(Lcom/google/android/material/datepicker/Month;)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Lcom/google/android/material/datepicker/m;->d(Lcom/google/android/material/datepicker/Month;)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    sub-int v0, v1, v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v3, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    move v7, v6

    if-le v2, v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v2, v4

    move v2, v4

    const/4 v7, 0x0

    move v2, v4

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v2, v5

    move v2, v5

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-lez v0, :cond_1

    const/4 v6, 0x0

    move v7, v6

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v4, v5

    move v4, v5

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v4, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    add-int/lit8 v0, v1, -0x3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/datepicker/g;->D0(I)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_2

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v0, v1, 0x3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/datepicker/g;->D0(I)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_2

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/material/datepicker/g;->D0(I)V

    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method F0(Lcom/google/android/material/datepicker/g$k;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/google/android/material/datepicker/g;->f:Lcom/google/android/material/datepicker/g$k;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/material/datepicker/g$k;->b:Lcom/google/android/material/datepicker/g$k;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/16 v1, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne p1, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/RecyclerView$h;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast v0, Lcom/google/android/material/datepicker/v;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v5, 0x6

    iget v3, v3, Lcom/google/android/material/datepicker/Month;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v3}, Lcom/google/android/material/datepicker/v;->c(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView$p;->scrollToPosition(I)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->j:Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->k:Landroid/view/View;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v0, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne p1, v0, :cond_1

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->j:Landroid/view/View;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->k:Landroid/view/View;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    invoke-virtual {p0, p1}, Lcom/google/android/material/datepicker/g;->E0(Lcom/google/android/material/datepicker/Month;)V

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method G0()V
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->f:Lcom/google/android/material/datepicker/g$k;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object v1, Lcom/google/android/material/datepicker/g$k;->b:Lcom/google/android/material/datepicker/g$k;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget-object v0, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/datepicker/g;->F0(Lcom/google/android/material/datepicker/g$k;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    sget-object v2, Lcom/google/android/material/datepicker/g$k;->a:Lcom/google/android/material/datepicker/g$k;

    const/4 v4, 0x5

    const/4 v3, 0x7

    if-ne v0, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Lcom/google/android/material/datepicker/g;->F0(Lcom/google/android/material/datepicker/g$k;)V

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method

.method public c0(Lcom/google/android/material/datepicker/n;)Z
    .locals 2
    .param p1    # Lcom/google/android/material/datepicker/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/datepicker/n<",
            "TS;>;)Z"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/android/material/datepicker/o;->c0(Lcom/google/android/material/datepicker/n;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    return p1
.end method

.method public e0()Lcom/google/android/material/datepicker/DateSelector;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/datepicker/DateSelector<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onCreate(Landroid/os/Bundle;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    :cond_0
    const/4 v2, 0x7

    const-string v0, "_HIq_KMpSYEETD_R"

    const-string v0, "_KERYMTSqD_EHEI_"

    const/4 v2, 0x0

    const-string v0, "RE_DIKE_qSEH_MYT"

    const-string v0, "THEME_RES_ID_KEY"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/material/datepicker/g;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "EssLRYRED__TOKSIC"

    const-string v0, "RRsG_KE_DOSCLIYTE"

    const/4 v2, 0x7

    const-string v0, "EGYmELRKED_R_OSCT"

    const-string v0, "GRID_SELECTOR_KEY"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/datepicker/g;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "KTYEoRAOAL_NENS_ISCRNADm"

    const-string v0, "EASmRNT_D_LECAOSNITKYANR"

    const/4 v2, 0x4

    const-string v0, "RACYIbSDAR_S_TAEENKTNCON"

    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "YHTRUKu_ECEN_MRTo"

    const-string v0, "CMNRoUT_REH_EKOTY"

    const/4 v2, 0x2

    const-string v0, "MNEUT_EpONHRCR_YK"

    const-string v0, "CURRENT_MONTH_KEY"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p1, Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v1, 0x5

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 12
    .param p1    # Landroid/view/LayoutInflater;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    new-instance p3, Landroid/view/ContextThemeWrapper;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget v1, p0, Lcom/google/android/material/datepicker/g;->b:I

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {p3, v0, v1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v0, Lcom/google/android/material/datepicker/b;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v0, p3}, Lcom/google/android/material/datepicker/b;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iput-object v0, p0, Lcom/google/android/material/datepicker/g;->g:Lcom/google/android/material/datepicker/b;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1, p3}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v11, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/datepicker/CalendarConstraints;->o()Lcom/google/android/material/datepicker/Month;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {p3}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v2, 0x1

    const/4 v11, 0x4

    const/4 v3, 0x0

    const/4 v11, 0x4

    xor-int/2addr v10, v3

    const/4 v11, 0x0

    if-eqz v1, :cond_0

    const/4 v11, 0x4

    sget v1, Lcom/google/android/material/R$layout;->mtrl_calendar_vertical:I

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    move v9, v2

    move v9, v2

    const/4 v11, 0x7

    move v9, v2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto :goto_0

    :cond_0
    const/4 v11, 0x7

    sget v1, Lcom/google/android/material/R$layout;->mtrl_calendar_horizontal:I

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    move v9, v3

    move v9, v3

    const/4 v11, 0x3

    move v9, v3

    move v9, v3

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {p1, v1, p2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {p2}, Lcom/google/android/material/datepicker/g;->A0(Landroid/content/Context;)I

    move-result p2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->setMinimumHeight(I)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget p2, Lcom/google/android/material/R$id;->mtrl_calendar_days_of_week:I

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    check-cast p2, Landroid/widget/GridView;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v1, Lcom/google/android/material/datepicker/g$b;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v1, p0}, Lcom/google/android/material/datepicker/g$b;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {p2, v1}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-instance v1, Lcom/google/android/material/datepicker/f;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v1}, Lcom/google/android/material/datepicker/f;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p2, v1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget v0, v0, Lcom/google/android/material/datepicker/Month;->d:I

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p2, v0}, Landroid/widget/GridView;->setNumColumns(I)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p2, v3}, Landroid/view/View;->setEnabled(Z)V

    const/4 v10, 0x5

    move v11, v10

    sget p2, Lcom/google/android/material/R$id;->mtrl_calendar_months:I

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    iput-object p2, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance p2, Lcom/google/android/material/datepicker/g$c;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v6

    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    const/4 v8, 0x0

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    move v7, v9

    move v7, v9

    move v7, v9

    move v7, v9

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-direct/range {v4 .. v9}, Lcom/google/android/material/datepicker/g$c;-><init>(Lcom/google/android/material/datepicker/g;Landroid/content/Context;IZI)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v0, p2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-object p2, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x3

    const/4 v10, 0x2

    sget-object v0, Lcom/google/android/material/datepicker/g;->q:Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance p2, Lcom/google/android/material/datepicker/m;

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    iget-object v1, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    new-instance v4, Lcom/google/android/material/datepicker/g$d;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-direct {v4, p0}, Lcom/google/android/material/datepicker/g$d;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {p2, p3, v0, v1, v4}, Lcom/google/android/material/datepicker/m;-><init>(Landroid/content/Context;Lcom/google/android/material/datepicker/DateSelector;Lcom/google/android/material/datepicker/CalendarConstraints;Lcom/google/android/material/datepicker/g$l;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v0, p2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p3}, Landroid/view/ContextThemeWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget v1, Lcom/google/android/material/R$integer;->mtrl_calendar_year_selector_span:I

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget v1, Lcom/google/android/material/R$id;->mtrl_calendar_year_selector_frame:I

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    check-cast v1, Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    iput-object v1, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-eqz v1, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    new-instance v4, Landroidx/recyclerview/widget/GridLayoutManager;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-direct {v4, p3, v0, v2, v3}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;IIZ)V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v1, v4}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$p;)V

    const/4 v11, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v1, Lcom/google/android/material/datepicker/v;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/material/datepicker/v;-><init>(Lcom/google/android/material/datepicker/g;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$h;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->h:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {p0}, Lcom/google/android/material/datepicker/g;->r0()Landroidx/recyclerview/widget/RecyclerView$o;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$o;)V

    :cond_1
    const/4 v10, 0x7

    const/4 v11, 0x6

    sget v0, Lcom/google/android/material/R$id;->month_navigation_fragment_toggle:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eqz v0, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/datepicker/g;->q0(Landroid/view/View;Lcom/google/android/material/datepicker/m;)V

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p3}, Lcom/google/android/material/datepicker/h;->J0(Landroid/content/Context;)Z

    move-result p3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-nez p3, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    new-instance p3, Landroidx/recyclerview/widget/a0;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {p3}, Landroidx/recyclerview/widget/a0;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/f0;->attachToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    :cond_3
    const/4 v11, 0x7

    iget-object p3, p0, Lcom/google/android/material/datepicker/g;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p2, v0}, Lcom/google/android/material/datepicker/m;->d(Lcom/google/android/material/datepicker/Month;)I

    move-result p2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->scrollToPosition(I)V

    const/4 v11, 0x3

    return-object p1
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    move v3, v2

    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "_bESRKEYqHEI_TD_"

    const-string v0, "K__EDbEEER_THYIS"

    const/4 v3, 0x7

    const-string v0, "_YsSET_DEIEREMH_"

    const-string v0, "THEME_RES_ID_KEY"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/datepicker/g;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "CuKmGLOSDRYE_IEE_"

    const-string v0, "ICLGO_uRYREKDESE_"

    const/4 v3, 0x0

    const-string v0, "GRID_SELECTOR_KEY"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/g;->c:Lcom/google/android/material/datepicker/DateSelector;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, "NA_RoRSDOSATL_KEINCENTCp"

    const-string v0, "O_ATSACpSENKET_NAIRLRDNC"

    const-string v0, "_ROASbIDKTEAYLE_NSTNANCR"

    const-string v0, "CALENDAR_CONSTRAINTS_KEY"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "UO_MqRuRK_ENENYTH"

    const-string v0, "TMO_ENRKqEHT_URYN"

    const/4 v3, 0x6

    const-string v0, "KHN_CT_pURRETEMON"

    const-string v0, "CURRENT_MONTH_KEY"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method t0()Lcom/google/android/material/datepicker/CalendarConstraints;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->d:Lcom/google/android/material/datepicker/CalendarConstraints;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object v0
.end method

.method v0()Lcom/google/android/material/datepicker/b;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->g:Lcom/google/android/material/datepicker/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method x0()Lcom/google/android/material/datepicker/Month;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/datepicker/g;->e:Lcom/google/android/material/datepicker/Month;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
