.class public Lcom/google/android/gms/signin/internal/a;
.super Lcom/google/android/gms/common/internal/j;

# interfaces
.implements Lcom/google/android/gms/signin/f;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/common/internal/j<",
        "Lcom/google/android/gms/signin/internal/f;",
        ">;",
        "Lcom/google/android/gms/signin/f;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final synthetic g:I


# instance fields
.field private final a:Z

.field private final b:Lcom/google/android/gms/common/internal/g;

.field private final c:Landroid/os/Bundle;

.field private final f:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;ZLcom/google/android/gms/common/internal/g;Landroid/os/Bundle;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Looper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Lcom/google/android/gms/common/internal/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p6    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x7

    const/16 v3, 0x2c

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v6, p7

    move-object v6, p7

    move-object v6, p7

    move-object v6, p7

    const/4 v7, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v7, 0x4

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/google/android/gms/signin/internal/a;->a:Z

    const/4 v7, 0x2

    iput-object p4, p0, Lcom/google/android/gms/signin/internal/a;->b:Lcom/google/android/gms/common/internal/g;

    const/4 v7, 0x4

    iput-object p5, p0, Lcom/google/android/gms/signin/internal/a;->c:Landroid/os/Bundle;

    const/4 v7, 0x6

    invoke-virtual {p4}, Lcom/google/android/gms/common/internal/g;->l()Ljava/lang/Integer;

    move-result-object p1

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/android/gms/signin/internal/a;->f:Ljava/lang/Integer;

    const/4 v7, 0x6

    return-void
.end method

.method public static g(Lcom/google/android/gms/common/internal/g;)Landroid/os/Bundle;
    .locals 6
    .param p0    # Lcom/google/android/gms/common/internal/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/g;->k()Lcom/google/android/gms/signin/a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/g;->l()Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x2

    const-string/jumbo v2, "ncsuc.eceisorrcgq.Rntsto.sdgimlsengonoAntmtadioine...uegellni"

    const-string v2, "Rgsnccc.nsmnstiroee.t.doilttna.o.ns.dgeuqergolnecAoeligdiumni"

    const-string v2, "eiomgrsooemndnreumA..nicnnogtdtcu.e.asltnqeiasdoctnlggliR.cie"

    const-string v2, "com.google.android.gms.signin.internal.clientRequestedAccount"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/g;->b()Landroid/accounts/Account;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string p0, "ameeoicoolimtnoiaormse..ngdgncInolgtrnsCd.onsiie.g.mstld.oteSm."

    const-string p0, "dnImldllnrecdncssootn.nn.maCtiotgo.oo.eisogSmisemgir.a.tme.eign"

    const/4 v5, 0x3

    const-string p0, "em.ntbI.rlmgilgeaiaddrogssCelnSi..otmonedcmoc.sesnnnt..tionogio"

    const-string p0, "com.google.android.gms.common.internal.ClientSettings.sessionId"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, p0, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p0, "sncesluefni.unog.omAoeignnddmotseieRa.tcae.idqnerrsls..lcgoig"

    const-string/jumbo p0, "nRefo..nirosgenenoginocumAsi.qalddccliee.raogledmiss.ft.sgnet"

    const/4 v5, 0x7

    const-string/jumbo p0, "oerneaspn.deiceclagofsotinmciduA.gi.iRstdge.lomgr.nnofsl.sqee"

    const-string p0, "com.google.android.gms.signin.internal.offlineAccessRequested"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, p0, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string p0, "ee.n.sttqRnodenai.emscosikrgglmTiboiialenndenru.ooq.dgg"

    const-string p0, "detdsbs.gogldTaaiceRnoqiedme.iok.ieloninemonursgn.gr.nt"

    const/4 v5, 0x2

    const-string p0, "i.ss.cmmkTeirednoriq.slg.Rtognineegnodiuan..eengodsaodl"

    const-string p0, "com.google.android.gms.signin.internal.idTokenRequested"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, p0, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo p0, "tr.ng.uirgtCiloger.ea.deiodesnIe.cnodnmvsa.nmolginsli"

    const/4 v5, 0x6

    const-string/jumbo p0, "lrtmmngrerl.g.enodeia.sdge.sosoo.ielcvdiaitnICmnn.irn"

    const-string p0, "com.google.android.gms.signin.internal.serverClientId"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v1, p0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string p0, "ePinooroanla.Mmsling.io.tdigFoorppd..estrodcougd.teenghACumonmr"

    const-string/jumbo p0, "tnCupn.poriod.omadg.lPoMmtieleng.ir.onr.dirgeAtoeFuodomsgenchsa"

    const-string/jumbo p0, "usdF.bouo.PoemeoMlnartronphemolggetrisdrmocidsnnC.oia.Adgg.ni.e"

    const-string p0, "com.google.android.gms.signin.internal.usePromptModeForAuthCode"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, p0, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string p0, "diokinui.grncoometrd.er.Tei.enehlrge.fsoClofdsaeoqRFrsoc.nmgong"

    const-string p0, "es.tlofoqione.gnrineTgoamRiosCdr.nki.gefmFc.ecrorodrh.seanlodge"

    const/4 v5, 0x4

    const-string p0, "gdl.Chcp.ndekcarRigd.frismggeeoeonnooilf.iTaoemnt.ornoes.nsorFe"

    const-string p0, "com.google.android.gms.signin.internal.forceCodeForRefreshToken"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, p0, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string p0, "aonglidnqsaeoisc.asreddotirilm..gnnmto.ihgon.mgDso."

    const-string p0, ".asonoiadnmoh.noeeionrgtagg.mcDigl..rsnilmdditeso.s"

    const/4 v5, 0x0

    const-string/jumbo p0, "nosalrilshr..niaosoDi.tdoint.cie.gmeg.dgnnmdasgomno"

    const-string p0, "com.google.android.gms.signin.internal.hostedDomain"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, p0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string p0, ".rmmagdaolggnnlego.nlmonedmeoS.Io.nsci.it.osirisgni"

    const-string/jumbo p0, "ngsmo.ioIs.il.Srioeinlotdgacnggrseglimonns.o.adm.en"

    const-string p0, "eaImo.e.igneg.oindmionosoool..rcs.ndnsnaitgrlggdlSs"

    const-string p0, "com.google.android.gms.signin.internal.logSessionId"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, p0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string p0, "fonaobdow.enomnasotrgg.clirknlF.tsiniAscsidmea.hgesReoiecoT.en.r"

    const-string p0, "Rlgco.i.sFofeniomansganTinhiwdirrakessnnlsegAordc.m.toreo..coete"

    const/4 v5, 0x5

    const-string/jumbo p0, "samonauolo.edlerohgssFiiinR.cgTdfgmewt..nar.eiinn.skAnrtcgreeooc"

    const-string p0, "com.google.android.gms.signin.internal.waitForAccessTokenRefresh"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, p0, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v1
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/signin/internal/e;)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v0, "ExsnibcpggklvIpanaCI  dbeca liltSi"

    const-string/jumbo v0, "xsCSgbgbna  vl kllndtcaiinapceiEII"

    const/4 v8, 0x5

    const-string/jumbo v0, "tlalS IsqvgbcaknneiIgCxia p dnEaci"

    const-string v0, "Expecting a valid ISignInCallbacks"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v0, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/android/gms/signin/internal/a;->b:Lcom/google/android/gms/common/internal/g;

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2}, Lcom/google/android/gms/common/internal/g;->d()Landroid/accounts/Account;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v3, "<>sdtfaectu>luu<n o"

    const-string v3, ">nftodu>cl a<tuu<ce"

    const/4 v8, 0x3

    const-string v3, "du<mtaf>ocnt< >euac"

    const-string v3, "<<default account>>"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v4, v2, Landroid/accounts/Account;->name:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v3, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/e;->getContext()Landroid/content/Context;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {v3}, Lcom/google/android/gms/auth/api/signin/internal/b;->b(Landroid/content/Context;)Lcom/google/android/gms/auth/api/signin/internal/b;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v3}, Lcom/google/android/gms/auth/api/signin/internal/b;->c()Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance v4, Lcom/google/android/gms/common/internal/zat;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v5, p0, Lcom/google/android/gms/signin/internal/a;->f:Ljava/lang/Integer;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v5}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    check-cast v5, Ljava/lang/Integer;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v4, v2, v5, v3}, Lcom/google/android/gms/common/internal/zat;-><init>(Landroid/accounts/Account;ILcom/google/android/gms/auth/api/signin/GoogleSignInAccount;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast v2, Lcom/google/android/gms/signin/internal/f;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v3, Lcom/google/android/gms/signin/internal/zai;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {v3, v0, v4}, Lcom/google/android/gms/signin/internal/zai;-><init>(ILcom/google/android/gms/common/internal/zat;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v2, v3, p1}, Lcom/google/android/gms/signin/internal/f;->X(Lcom/google/android/gms/signin/internal/zai;Lcom/google/android/gms/signin/internal/e;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void

    :catch_0
    move-exception v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string/jumbo v3, "pdynon eResrtpdg mIoabcrhailols  icedw iivn  beels"

    const-string/jumbo v3, "m ypnveplwdbeilgs cIdcohiotiseae d b rs lRiann ere"

    const/4 v8, 0x1

    const-string v3, "Remote service probably died when signIn is called"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v4, "lleIIbimnCpnnqit"

    const-string/jumbo v4, "litneIlCqnSnmIip"

    const-string/jumbo v4, "inIlngulitmSCepn"

    const-string v4, "SignInClientImpl"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v4, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_1
    const/4 v7, 0x7

    new-instance v3, Lcom/google/android/gms/signin/internal/zak;

    const/4 v8, 0x4

    new-instance v5, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x7

    const/16 v6, 0x8

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-direct {v5, v6, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    invoke-direct {v3, v0, v5, v1}, Lcom/google/android/gms/signin/internal/zak;-><init>(ILcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/internal/zav;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {p1, v3}, Lcom/google/android/gms/signin/internal/e;->h(Lcom/google/android/gms/signin/internal/zak;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    return-void

    :catch_1
    const/4 v8, 0x0

    const-string p1, " Sdue npiuba sCnsoeIox ttoScpehemoepmtlCse glsoagdbrnele tlocs,fmRe Iekcnoxnmien#cIEeicepne.s rduehp xt"

    const-string p1, " esuhE e#paoIafonesenrtn ggddSmdinomxo, eRxmpltlCnrustIIccxeaboseclCb eiktnc e emlse oSpeste.nepih ueco"

    const-string p1, "e elgsmtq oiIpanldrExmae Ibg oRsSedptueecdepnuxe tfthnmbe ciShpmeee ctnnnse#oI, oaCcCisk.csonltuerexoo "

    const-string p1, "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException."

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v4, p1, v2}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void
.end method

.method public final b(Lcom/google/android/gms/common/internal/n;Z)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/internal/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    :try_start_0
    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/gms/signin/internal/f;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/gms/signin/internal/a;->f:Ljava/lang/Integer;

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p1, v1, p2}, Lcom/google/android/gms/signin/internal/f;->c(Lcom/google/android/gms/common/internal/n;IZ)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    return-void

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p1, "gImmliitnCnnIlpe"

    const/4 v3, 0x5

    const-string p1, "SnstleInCnpglmii"

    const-string p1, "SignInClientImpl"

    const/4 v3, 0x5

    const-string p2, "Aham bsneo ivoeviaroR emnl s petfc ecetredactailDwuuyoceebds d"

    const-string p2, "ctdcoe  lafuberrsRDoveoveAus ccwb aynlt aom lieedpnaiehsdeiet "

    const/4 v3, 0x0

    const-string/jumbo p2, "uAoeotbDdb ealnc tevvea uiracla  liois femcwprdenetodR lyshesc"

    const-string p2, "Remote service probably died when saveDefaultAccount is called"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .param p1    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v0, "i.eInbsrlgn.cigmn.inoterioongeai.noriSl.Sv.dmcaIgdeng"

    const/4 v3, 0x3

    const-string v0, "gc.SgbeelosrniinnI.osmlciretgea..vnSnd.ngrond.miiigIa"

    const-string v0, "com.google.android.gms.signin.internal.ISignInService"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    instance-of v1, v0, Lcom/google/android/gms/signin/internal/f;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p1, Lcom/google/android/gms/signin/internal/f;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/signin/internal/f;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/signin/internal/f;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p1
.end method

.method public final d()V
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/signin/internal/f;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/signin/internal/a;->f:Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/gms/signin/internal/f;->b(I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    return-void

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "ltguIlunnImCepSn"

    const-string/jumbo v0, "lpmCgIutnnnileIS"

    const/4 v3, 0x2

    const-string/jumbo v0, "tiIgipmpnCeISlnn"

    const-string v0, "SignInClientImpl"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "oAvrconiqerdeS i neonharsalb ceeosc eriea w RSstcypuoelertcFmi lbspldodm"

    const-string/jumbo v1, "oSsodcrplchRieobSscmereoFvlilee wn asdnlso ie o rn eit umreerydpecAaabct"

    const/4 v3, 0x1

    const-string/jumbo v1, "omswlSlobeeeaaoelrtdcnmcnF etrd eAoiroee srvi idtuRlossienc sbeychapS cr"

    const-string v1, "Remote service probably died when clearAccountFromSessionStore is called"

    const/4 v2, 0x5

    const/4 v2, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public final e()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/internal/e$d;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/internal/e$d;-><init>(Lcom/google/android/gms/common/internal/e;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/internal/e;->connect(Lcom/google/android/gms/common/internal/e$c;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/signin/internal/a;->b:Lcom/google/android/gms/common/internal/g;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/g;->h()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/e;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/signin/internal/a;->c:Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/gms/signin/internal/a;->b:Lcom/google/android/gms/common/internal/g;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "..lmlaglnNenaooeriqeCcadsnggmtPncl.es..imrng.atieedgnaaioori"

    const-string/jumbo v2, "ig.soglnqroe.eaao.srlig.ectdtmaadngiiacem.mgnNnea.CellroPnin"

    const/4 v4, 0x6

    const-string/jumbo v2, "rckiolmelmt..Ca.ciglggnnaeior.oiinemntdeP.adsNsoaneo.gaarlge"

    const-string v2, "com.google.android.gms.signin.internal.realClientPackageName"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/g;->h()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/signin/internal/a;->c:Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const v0, 0xbdfcb8

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "S.ngdbv.olISn.midnirgeaiminntscsr...noesoieroIgiglnca"

    const-string/jumbo v0, "nnsIniv.ansi.IlinitdSgd.aoseo.rmgcSo.erngmgl.eeorinci"

    const/4 v2, 0x7

    const-string/jumbo v0, "riivoiul.Sagnrtn.ema.lomrSdnengignIsnnoigcceI.i.gd.se"

    const-string v0, "com.google.android.gms.signin.internal.ISignInService"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, ".oiiiS.pa.sirgRng..mAs.vcmTlesreocemdongdon"

    const-string v0, "cvimiec.idomS.o.gesmongi.ldsnTorgsn.Age.Rra"

    const/4 v2, 0x2

    const-string/jumbo v0, "r.g.Svncqg.sdolncdrT.imooAii.nsoRTeg.agseim"

    const-string v0, "com.google.android.gms.signin.service.START"

    const/4 v1, 0x3

    move v2, v1

    return-object v0
.end method

.method public final requiresSignIn()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/gms/signin/internal/a;->a:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
