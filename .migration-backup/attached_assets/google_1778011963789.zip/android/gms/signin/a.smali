.class public final Lcom/google/android/gms/signin/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/a$d$f;


# static fields
.field public static final j:Lcom/google/android/gms/signin/a;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# instance fields
.field private final a:Z

.field private final b:Z

.field private final c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final d:Z

.field private final e:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final f:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final g:Z

.field private final h:Ljava/lang/Long;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final i:Ljava/lang/Long;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x5

    new-instance v11, Lcom/google/android/gms/signin/a;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    const/4 v1, 0x0

    const/4 v13, 0x7

    const/4 v2, 0x0

    const/4 v13, 0x2

    move v12, v2

    move v12, v2

    const/4 v13, 0x5

    const/4 v3, 0x0

    const/4 v13, 0x3

    move v12, v3

    move v12, v3

    const/4 v13, 0x3

    const/4 v4, 0x0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x6

    const/4 v5, 0x0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v6, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    const/4 v7, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v8, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v9, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v10, 0x0

    move-object v0, v11

    move-object v0, v11

    move-object v0, v11

    move-object v0, v11

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-direct/range {v0 .. v10}, Lcom/google/android/gms/signin/a;-><init>(ZZLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;ZLjava/lang/Long;Ljava/lang/Long;Lcom/google/android/gms/signin/g;)V

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x0

    sput-object v11, Lcom/google/android/gms/signin/a;->j:Lcom/google/android/gms/signin/a;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    return-void
.end method

.method synthetic constructor <init>(ZZLjava/lang/String;ZLjava/lang/String;Ljava/lang/String;ZLjava/lang/Long;Ljava/lang/Long;Lcom/google/android/gms/signin/g;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/signin/a;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/gms/signin/a;->b:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/signin/a;->c:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/gms/signin/a;->d:Z

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/signin/a;->g:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/signin/a;->e:Ljava/lang/String;

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/signin/a;->f:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/signin/a;->h:Ljava/lang/Long;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/signin/a;->i:Ljava/lang/Long;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "u s@~4~Kmo/f@~@~ 1i @ @@i-f@  o@@l~~  ba o/i~@~~Mo~c ty~~~ ~~@~S~@~@~v.~bd@@s@~b   @on t@@ l @~r"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne p1, p0, :cond_0

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    instance-of v1, p1, Lcom/google/android/gms/signin/a;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    return v2

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast p1, Lcom/google/android/gms/signin/a;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-boolean p1, p1, Lcom/google/android/gms/signin/a;->a:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v2
.end method

.method public final hashCode()I
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v0, 0x9

    const/4 v5, 0x6

    const/4 v4, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    aput-object v1, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x1

    move v5, v2

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    aput-object v1, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    const/4 v3, 0x0

    shl-int/2addr v5, v3

    const/4 v4, 0x4

    move v5, v4

    aput-object v3, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput-object v1, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object v1, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput-object v3, v0, v1

    const/4 v1, 0x6

    const/4 v5, 0x7

    move v4, v1

    move v4, v1

    const/4 v5, 0x0

    aput-object v3, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v1, 0x7

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    aput-object v3, v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v1, 0x8

    const/4 v5, 0x1

    aput-object v3, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v0
.end method
