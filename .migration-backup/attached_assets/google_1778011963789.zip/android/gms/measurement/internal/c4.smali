.class abstract Lcom/google/android/gms/measurement/internal/c4;
.super Lcom/google/android/gms/measurement/internal/b3;


# instance fields
.field private b:Z


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/b3;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->i()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected final i()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "n~s @ ~o@  @~ir @vM@ty~ ~do~~~l@t@@ i K ~@ b.~~~4@@Sob1@~ba o@m/soc  @@i~@~ @~@@~~ @fflo/~-~u~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->m()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "edsilniziattN o"

    const/4 v3, 0x1

    const-string v1, "dnimolietzi tNa"

    const-string v1, "Not initialized"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw v0
.end method

.method public final j()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/c4;->b:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->n()Z

    move-result v0

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->g()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/google/android/gms/measurement/internal/c4;->b:Z

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "tiw o zimi/atc/eniiCatl"

    const-string v1, "/aimtetciiit /w naeizlC"

    const/4 v3, 0x7

    const-string/jumbo v1, "iz/ctb /attlieeiCnwinai"

    const-string v1, "Can\'t initialize twice"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v0
.end method

.method public final k()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/c4;->b:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->l()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->g()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/android/gms/measurement/internal/c4;->b:Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v1, "iii tnuizei /ttanCwe/ac"

    const-string v1, "Can\'t initialize twice"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0
.end method

.method protected l()V
    .locals 2
    .annotation build Landroidx/annotation/l1;
    .end annotation

    return-void
.end method

.method final m()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/c4;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method protected abstract n()Z
.end method
