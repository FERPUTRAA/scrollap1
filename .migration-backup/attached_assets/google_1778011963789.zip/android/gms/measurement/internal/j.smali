.class final Lcom/google/android/gms/measurement/internal/j;
.super Lcom/google/android/gms/measurement/internal/r9;


# static fields
.field private static final f:[Ljava/lang/String;

.field private static final g:[Ljava/lang/String;

.field private static final h:[Ljava/lang/String;

.field private static final i:[Ljava/lang/String;

.field private static final j:[Ljava/lang/String;

.field private static final k:[Ljava/lang/String;

.field private static final l:[Ljava/lang/String;

.field private static final m:[Ljava/lang/String;


# instance fields
.field private final d:Lcom/google/android/gms/measurement/internal/i;

.field private final e:Lcom/google/android/gms/measurement/internal/n9;


# direct methods
.method static constructor <clinit>()V
    .locals 55

    const-string v0, "btsanseed_sutmmtslialp"

    const-string v0, "eassttiulne_ms_mptbald"

    const-string v0, "aebmts_mn_upitdsdlltea"

    const-string/jumbo v0, "last_bundled_timestamp"

    const-string/jumbo v1, "t ssoeReCtpNslmOB  dnEamEDn _tM_mNaTU EGD;ARTLtdlLueTA vLeIEA"

    const-string v1, "ACnmTu_ aDndDLitATNAGeEls lL_s mERLvEteptRNM TEe  ;asItUmdBOe"

    const-string v1, ";Alnpb duRCnteNs _ LEdNLBt DmsA_iUTIDE eTtGeMLAaRvaO eEmsTblE"

    const-string v1, "ALTER TABLE events ADD COLUMN last_bundled_timestamp INTEGER;"

    const-string/jumbo v2, "oaddalul_n_tyubd"

    const-string/jumbo v2, "lld_oddybt_ausan"

    const-string v2, "_d_neaupaydtldls"

    const-string/jumbo v2, "last_bundled_day"

    const-string/jumbo v3, "sndbERlOqdALEIanNd; LvuDCtMy E eLAEANR  eUblBDT_T_aGTes"

    const-string v3, "DelBAbAICtb NeNRU TsnsnRG EdDaaEtA_e;y_vuL lTT MELLdOdE"

    const-string/jumbo v3, "ussRNIt lCeAGLs n NUdDAvbaBEey_tEl ;aLd_TeAMETO ERT LnD"

    const-string v3, "ALTER TABLE events ADD COLUMN last_bundled_day INTEGER;"

    const-string v4, "aueml_lvietm__pncmpsxodedl_ea"

    const-string v4, "cemvptulsoep_i_mand_ex_asedll"

    const-string v4, "dpamoi_tcsvemeds_pl_oxe_lntal"

    const-string/jumbo v4, "last_sampled_complex_event_id"

    const-string v5, "NDGaebs_ etBeLomAmLe_RlipMTEEANT A xpcnOE;DI sL lC dUs_t_vletpendRTv"

    const-string v5, "IBE iTApcte_ TCsONMAat_TApLGteElo lvmmneLDLsd_;ER eNDUp_ vREse dnlex"

    const-string v5, "DstENTu_AIE  T _asxldG sEivee_RmALopTeUt_ CO;LvlDeemptALenld aRNMBcE"

    const-string v5, "ALTER TABLE events ADD COLUMN last_sampled_complex_event_id INTEGER;"

    const-string v6, "gteqn_ipsaapl_mrta"

    const-string/jumbo v6, "rtaliemsqa_ptnlg_a"

    const-string/jumbo v6, "last_sampling_rate"

    const-string/jumbo v7, "pD E_G UqEI_lmgeNtaansTesl OBrvECT;LRaM ie TstnLNR tAEAAs"

    const-string v7, "iCsl;ANrITOesERR_sv_ NABL naLepeMaAgtm aGsEDt T ntELTEUl "

    const-string v7, "DEsLt avBNAp;igstaT TOALsAer_ElRREC nM Lea ItUGeTsnD_mlE "

    const-string v7, "ALTER TABLE events ADD COLUMN last_sampling_rate INTEGER;"

    const-string/jumbo v8, "lgfmsmlaxmemtrpt_ap_insmo"

    const-string/jumbo v8, "xa_mmillmnsoegtpftsa_repm"

    const-string/jumbo v8, "last_exempt_from_sampling"

    const-string v9, "E RioAvGOLfDLLt D CUtpesEBmsemIRlnToe_xoEnl_Mr _eNsE AmgtATap ;a"

    const-string/jumbo v9, "xe motA  gBGst;iAE nU_MeOmeeEfTA ELatLTlLCrsNolvDDRsR naIp__pTmE"

    const-string v9, " RUelbEE EsGRpfNgtmTAIN DeD ;vtax_OaieMms_lTs _moEL ArLABntTeCpL"

    const-string v9, "ALTER TABLE events ADD COLUMN last_exempt_from_sampling INTEGER;"

    const-string/jumbo v10, "nstuusuecortirco_nn_s"

    const-string v10, "_sntube_orutsirnonccs"

    const-string v10, "current_session_count"

    const-string v11, "RATioLrptenERT_sutTuDMUe eDsOEoeAvstuLGnLEsBC_nE;IN Ncnr A c"

    const-string/jumbo v11, "onnt_surecMsrCT_ItTNeLLoENtADAEROBnDG;  T escvUn EuAEL iseRu"

    const-string v11, "TTA TCDEqBROEnc_EAeGuseAoee_sEvL UDcsirnM NnILr;tt nL t uRNs"

    const-string v11, "ALTER TABLE events ADD COLUMN current_session_count INTEGER;"

    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->f:[Ljava/lang/String;

    const-string/jumbo v0, "pisnio"

    const-string/jumbo v0, "npoiir"

    const-string/jumbo v0, "origin"

    const-string v1, " TnmeEAEMu  ii RtisDAALLqort;NraTT_EerC tBUXLbO suD"

    const-string/jumbo v1, "uAC D;rEqR TrnLDieANXEisO o sT_TrtB bEAiMeLtULatg u"

    const-string v1, "LuBCoXteD; NoT  b t_LL rD TeEnErEiARitAsOMgAaUsruTT"

    const-string v1, "ALTER TABLE user_attributes ADD COLUMN origin TEXT;"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->g:[Ljava/lang/String;

    const-string/jumbo v1, "nessvbppai_"

    const-string v1, "eosis_npvpa"

    const-string/jumbo v1, "neraspui_po"

    const-string v1, "app_version"

    const-string v2, " eA NappTCpO psAELUL pTnsL TEXBiEoD_TRmarvA ;"

    const-string v2, "ALsmLT EaDsipEoUT _ET;LpO p DB eanvC XAATrRNp"

    const-string v2, " vppA_LsqrCOaTNLATDDasE eTMEREn XTo pUpLB  Ai"

    const-string v2, "ALTER TABLE apps ADD COLUMN app_version TEXT;"

    const-string v3, "es_poopta"

    const-string/jumbo v3, "ops_treas"

    const-string v3, "app_store"

    const-string v4, "EE mUBDs_C  DaEatAOrMLTTApNeTpAT o LLRps; p"

    const-string/jumbo v4, "rBUE bMpRELeLTDO ApApET_;sDtT LaAC   oTpsNa"

    const-string v4, "EpUEoTB; sADATsp TRDa rEeML po LaACT pNXO_L"

    const-string v4, "ALTER TABLE apps ADD COLUMN app_store TEXT;"

    const-string/jumbo v5, "siorvbnpuem"

    const-string/jumbo v5, "ngspvoumier"

    const-string/jumbo v5, "p_girouemvs"

    const-string v5, "gmp_version"

    const-string v6, "EGpoMLsp T LaiEsRBgr_pD NvO ETA TLERA;N pDpnmIAU"

    const-string/jumbo v6, "mRp rC pOiL;NEIMNTDEv A psLGDTpaATU_oRsE Bg LEAn"

    const-string/jumbo v6, "mTC AoLrqB a NEpEOTALepE GIN;DR RvUsMgT_pLnAs ED"

    const-string v6, "ALTER TABLE apps ADD COLUMN gmp_version INTEGER;"

    const-string v7, "cdst_h_ahesev"

    const-string v7, "dev_cert_hash"

    const-string v8, "R;Tm pe_ LpCcs_vANAhErEL IGq hDBtNdsT DeUOLEaMAE R"

    const-string v8, " eMEAR_Nq LAs eaCDa OEp_I ELBDs;RNdEhhUvAp LrGTctT"

    const-string v8, "eDIpoANtLELaas O _DAsEMpECLd NTRGTvhrTeEA_  ;R hcB"

    const-string v8, "ALTER TABLE apps ADD COLUMN dev_cert_hash INTEGER;"

    const-string/jumbo v9, "na_tmbersuenmedslbe"

    const-string/jumbo v9, "leseudnmeraetbam_sn"

    const-string/jumbo v9, "mnueleuestedmra_abe"

    const-string/jumbo v9, "measurement_enabled"

    const-string v10, "BAIsALEpaDd eG OapCAUs_rmmp RE;TaTeeNn nNEbREme lDL MTuL"

    const-string v10, "aGpmaApTMT tONRnDUn Dmees_mNEdeAELbBrAlaL sIeLE Tu REC; "

    const-string v10, "eG epdNsqA maL RBbELCamup;ne a NDeEnTAUAElDtRTIOrLT_MEs "

    const-string v10, "ALTER TABLE apps ADD COLUMN measurement_enabled INTEGER;"

    const-string v11, "de_toalu_atitsbmnetsasrmpl_"

    const-string v11, "_bstms_dsmitlaueealttspnta_"

    const-string/jumbo v11, "last_bundle_start_timestamp"

    const-string v12, " TmmGap s CEa paAAR_TeOu_LdtEL RtM NEsDImD;NLtpEBnbrAe_bTUsttsai"

    const-string/jumbo v12, "rCLIRblpDsnAaNTE Mdt t A _i UeBbOEuaL;ptDsETtpLAGNTe smRasEt_a_m"

    const-string/jumbo v12, "lOs otMpaaEAb pi ;ECrlRTs_aTAL GsERLLmIs_utAeDttnEBDtUa pd_NeN T"

    const-string v12, "ALTER TABLE apps ADD COLUMN last_bundle_start_timestamp INTEGER;"

    const-string/jumbo v13, "yda"

    const-string/jumbo v13, "yda"

    const-string v13, "day"

    const-string v13, "day"

    const-string v14, " IETsCudLEyUTR ORM LNNaAG;BDEpLaEp TADA "

    const-string v14, "ITBUObLDyd LR MNND Ra  AsEaAGEL;pT pACTE"

    const-string v14, "ALTER TABLE apps ADD COLUMN day INTEGER;"

    const-string v15, "eiol_uuv_uttbcacp_ynledsp"

    const-string/jumbo v15, "utea_i_pidv_olcbltcpnyuse"

    const-string v15, "i_o_tdyplvcsi_buetcpnanul"

    const-string v15, "daily_public_events_count"

    const-string v16, "MevsOaElq;cuLndE p inNipy cbqTttUAEl_sARDNLGA_E TuTa  LCe_IRoB"

    const-string/jumbo v16, "p_UIAT _qeBLivuLcNAtAd yT TblOo_;DseaaGMtRnC E plNnEsipRLcuEE "

    const-string v16, "ctsnUILsiNOL ;uTsEAa_ TAAE B ayptllER odD_T_benMcDvCpRGNLiepEu"

    const-string v16, "ALTER TABLE apps ADD COLUMN daily_public_events_count INTEGER;"

    const-string/jumbo v17, "ldumnovcet__sseati"

    const-string/jumbo v17, "nisen_toevlstcud_a"

    const-string/jumbo v17, "uovloat__disenycen"

    const-string v17, "daily_events_count"

    const-string v18, "EaEn;b_RToysEOtM _U AucRCBteTmLT pnvEAis NlGeDL A paDdI"

    const-string v18, "euRmoEi_ LILTpnvD_s;ON n ETGdtA L ctpl aEBCEUAMARayDTes"

    const-string v18, "I_UEl;uOssyTT AiEDNnLEueAR TtBpL Dao ECnvGtL Neap AMd_R"

    const-string v18, "ALTER TABLE apps ADD COLUMN daily_events_count INTEGER;"

    const-string v19, "esodsrnpclciiout_yvnoao"

    const-string v19, "c_yeooi_anlsiscortnoudv"

    const-string/jumbo v19, "yscniunsqola_rdo_evntco"

    const-string v19, "daily_conversions_count"

    const-string v20, "eLslsc_yTpAD TLCo AnopBnILTEtOEs ;urE isaainRNNcdRM GUAEDo_v"

    const-string v20, "ALTER TABLE apps ADD COLUMN daily_conversions_count INTEGER;"

    const-string v21, "emrmtoifecn_g"

    const-string/jumbo v21, "remote_config"

    const-string v22, "O Bmos AAiDcpp DLbrAaBngMRe;EeBUCLNOToL Lof tT "

    const-string/jumbo v22, "nND rbC mLLEo gOO Ltp A;DMpisULRAeBT ABBoecETaf"

    const-string/jumbo v22, "pgesAboLf LO cO RAE_NUeaETCrDopm ALTM BnLDBtB ;"

    const-string v22, "ALTER TABLE apps ADD COLUMN remote_config BLOB;"

    const-string/jumbo v23, "mdin_futecefuhitgc_"

    const-string v23, "f_cnigutdiomctheef_"

    const-string v23, "_fidehepigfonmcet_c"

    const-string v23, "config_fetched_time"

    const-string v24, "BeRocfILqARiETL E tEeTn  pEdTL ;mDfAGNNegMhsp_iOAptC_U c"

    const-string v24, "T GIpDLpAeni AaEEo_LTChetO _Btd NmLfiTMfspcU;ANgE cERe R"

    const-string/jumbo v24, "oEsm p sAIeRcGieTMCA_ALEUcnTgNLfdEihDp LBa_ ED;RT teON t"

    const-string v24, "ALTER TABLE apps ADD COLUMN config_fetched_time INTEGER;"

    const-string/jumbo v25, "mgate_tfqfln_d_focehicii"

    const-string v25, "hcgmeeffdo_iima_it_tnfec"

    const-string v25, "failed_config_fetch_time"

    const-string/jumbo v26, "oR_AoEcg LNiOmEiNEpdUi_BnsAT D  f;DettTa IGAeL_MLfh RcTapECef"

    const-string v26, "_As o ngcpTTfiE f GEeBU_DOeNfIRhAtaTetLmCRLd_;EMpNcDAiE s iaL"

    const-string v26, "fTd_TbeanEi_ IE clAftEitALRUpNAG oTiBe pfsE;MaLhDg mLCc_ NODe"

    const-string v26, "ALTER TABLE apps ADD COLUMN failed_config_fetch_time INTEGER;"

    const-string/jumbo v27, "oprin_um_stanvp"

    const-string/jumbo v27, "taims_pnrvnope_"

    const-string v27, "_itprinp_asnpev"

    const-string v27, "app_version_int"

    const-string/jumbo v28, "pBp_ DtLqNoDe iTRTs s;vAnGr CoT_ pENpIiEAELRAaEnaMLO"

    const-string/jumbo v28, "nLvioAp;C_p EMrA  TADTEiBtpLEa _  TEGOIRnaepsoDsLRNN"

    const-string v28, "Dasinp_pEL pATLvULIAAnaEEtRC_GsiD  eOr N ;MEpNoT TRs"

    const-string v28, "ALTER TABLE apps ADD COLUMN app_version_int INTEGER;"

    const-string v29, "caemneitasi_rs_bidbe"

    const-string v29, "ibsitbc_eardansin_ee"

    const-string v29, "denfoitrn_iseesib_ac"

    const-string v29, "firebase_instance_id"

    const-string v30, "XfTpdbsEbUD_AR s_aLiLOBeDsiLT  nrMn; AeTEtaCEA iT upNa"

    const-string v30, "cT TXruMTUt_eEaL idEDRLfipsTaCO;EADpa _A   nnsBseAiNbL"

    const-string/jumbo v30, "ti AR;ussLrpE_NEACDpTi Tae De EfXn_OaLcUsda LnMTBAiTbe"

    const-string v30, "ALTER TABLE apps ADD COLUMN firebase_instance_id TEXT;"

    const-string/jumbo v31, "nnroeyrptpcle_aiest_uvro"

    const-string/jumbo v31, "teayrs_pocendtulvo_rienr"

    const-string/jumbo v31, "svry_ec_qatnelorunrot_di"

    const-string v31, "daily_error_events_count"

    const-string/jumbo v32, "r slA EOG_ EMTEoLC_dINBTD_LevsEnitR t;cenAyRasUADNTqreruoa pL"

    const-string v32, "BIi;RALcqErTosp_nD_ ertLTN_LGaeO UdrlDCotReuTyaE NAsEnA E vMp"

    const-string v32, "IT mERE r_pelByTLpa ;runeaTEsRAvEGU NDedrDL_AiM_tCsAOon  cNto"

    const-string v32, "ALTER TABLE apps ADD COLUMN daily_error_events_count INTEGER;"

    const-string/jumbo v33, "tonroeuits_l_tnldeeise_acvy"

    const-string/jumbo v33, "yts__v_tsuclreoimilteendnea"

    const-string/jumbo v33, "uietabyedoilmr_s_cantlveent"

    const-string v33, "daily_realtime_events_count"

    const-string v34, ";a RsAuyTo BmOGNEDMRu tc__tlLIeTNvpD neACeLrn_pitEiLsE amed lETa"

    const-string/jumbo v34, "o;lmL_EROtT_CAaEiNtAeaLvipENLG   a nnuTEs tdIMDyTlep emrce_sURBD"

    const-string v34, "atenleOps RtTANDeldaLeE cyLIuCvTEoMDpGBmrUA tLAipiNnR a __EsT_;E"

    const-string v34, "ALTER TABLE apps ADD COLUMN daily_realtime_events_count INTEGER;"

    const-string/jumbo v35, "sleh_rlmqoototimhnaae"

    const-string/jumbo v35, "tarhonslmohl_eaoe_mit"

    const-string/jumbo v35, "ipsrthomhtnmesl_leaao"

    const-string v35, "health_monitor_sample"

    const-string v36, "A_omsMNaDTEAL aO_AnsLilthmhp TBaE RtXEUl mbp;eeDCoLp rT"

    const-string/jumbo v36, "ptRmAbiapsTnBLo DLs_Eph NTaAaT;tDelrMTAmLhlXE eCo  _OEU"

    const-string/jumbo v36, "mMlsooLesEUTaBXiORLma_CrLTAATDnDeppA  ph NthEalTot;  E "

    const-string v36, "ALTER TABLE apps ADD COLUMN health_monitor_sample TEXT;"

    const-string v37, "donuiba_di"

    const-string v37, "ddinoru_ai"

    const-string/jumbo v37, "rdoadiun_d"

    const-string v37, "android_id"

    const-string v38, " IiDAiEppaETTdRsLL  NDN_BpndMALOURa EdGCpE;orT "

    const-string v38, "LTdpLBTpd_LpUd RsAAMr NNO;nARDiaEaoDECT GiI EE "

    const-string v38, "TEL AoBiqni_dsArTMTI  ; aDpONdLEDdEURN ECRGA La"

    const-string v38, "ALTER TABLE apps ADD COLUMN android_id INTEGER;"

    const-string v39, "easlti_bdrnnpid_qgeodr"

    const-string/jumbo v39, "rddnaegpqtieirad_obnl_"

    const-string v39, "adid_reporting_enabled"

    const-string v40, "d ampRTa_rIMdNEAeAERTbLsoGn ;i lepDi NgLCpeEAUtEra snd_DB O"

    const-string v40, "dds ;C aiGrarpebEeADiREnUNEEeanp DAMlpR_NOd tAg T _BLLLIoTs"

    const-string/jumbo v40, "p;eAoTA aeE UDICnNReGLLpaDNigA lEarRMdiLT_bBTdpdEt_o r  nsE"

    const-string v40, "ALTER TABLE apps ADD COLUMN adid_reporting_enabled INTEGER;"

    const-string/jumbo v41, "inamgbtradnpbseod_ilesr"

    const-string/jumbo v41, "rsdmgaodes_aitnnleirbep"

    const-string/jumbo v41, "inp_doursi_rasabglntede"

    const-string/jumbo v41, "ssaid_reporting_enabled"

    const-string v42, "DsrUsoipI EEeRtlL O n_p GeBsapeTnLA_a iaNrddpTNEgLbE;CA AMDT"

    const-string v42, "ALTER TABLE apps ADD COLUMN ssaid_reporting_enabled INTEGER;"

    const-string v43, "aib_d_oaqdmp"

    const-string v43, "admob_app_id"

    const-string v44, ";EsRaA m _MNA BaapCoTXTELA_DUpL TopsDT dbOpdiL"

    const-string/jumbo v44, "sTaaoL_A_ EmCDU;bTMAo OL NXpELp pDTi BRdTaApdE"

    const-string v44, "T_TmaXEAMd_ NopTaabUm LBEpETLAdp CDODALp  sRi "

    const-string v44, "ALTER TABLE apps ADD COLUMN admob_app_id TEXT;"

    const-string v45, "dadiobodkpab___ipnm"

    const-string v45, "aamodb_idk_b_ednipp"

    const-string v45, "dkiilb_dpeaombpnda_"

    const-string/jumbo v45, "linked_admob_app_id"

    const-string v46, "bTlpuUuALa;_NB p  dp RiMA_DLkDLpETaCs _dAE TnoEaXemdT"

    const-string v46, "LEaadUu__ pTiB ;mOsXATpDdTRpLo  DlEML_apeE bA kAdTCNn"

    const-string v46, "ALTER TABLE apps ADD COLUMN linked_admob_app_id TEXT;"

    const-string v47, "eivmnenptroapdsy"

    const-string v47, "dyonremptinsvaie"

    const-string v47, "_iiesaetqdynovnr"

    const-string v47, "dynamite_version"

    const-string v48, "C_srRTsNp   Eos Me mOTIinA;ynLRpLTtEvLdBGDeAAE DNaUEi"

    const-string/jumbo v48, "oE  ATRAqIiArLsGyN;p sEOm eDptL_iLvTnDTa MEdECBeUnNR "

    const-string v48, "DIemoAiETEi ymLOreTLT aRDvGnM n_EpaNRp E CdsUNBtsLA A"

    const-string v48, "ALTER TABLE apps ADD COLUMN dynamite_version INTEGER;"

    const-string/jumbo v49, "isetotsneevfs_dae"

    const-string/jumbo v49, "iesets_defnatsvse"

    const-string v49, "adfsibstetven_sle"

    const-string/jumbo v49, "safelisted_events"

    const-string v50, "atpONUuATef ;seTLMXvLDeTsAlEndA  iLa CTp_etssED REm"

    const-string/jumbo v50, "nMpm TDtsED_TTe;aUieeCeXTEplLLssNRdA tEBAsaA fLOv  "

    const-string v50, " ACa_;DpEsn edBDatTLTEiMNvAAUefLpsXRO e  sTltTELe s"

    const-string v50, "ALTER TABLE apps ADD COLUMN safelisted_events TEXT;"

    const-string v51, "a_pi_ogdq"

    const-string v51, "a_igopd_p"

    const-string v51, "ags_da_ip"

    const-string v51, "ga_app_id"

    const-string v52, "NUOmBaAgb;E DL p pT_pLEdDX_aTELp  MaiATCsRA"

    const-string v52, "LOD _b BaRpXDTgCTTU; aMTEAN LApAiasLEdE _pp"

    const-string v52, " A To_ ag_COTDNapL XLpEEAspTTUBDa;ARMid L p"

    const-string v52, "ALTER TABLE apps ADD COLUMN ga_app_id TEXT;"

    const-string/jumbo v53, "iie_ubso_diftgefdmin_ocma"

    const-string/jumbo v53, "imdocmuigdfi_seat_iot_efn"

    const-string v53, "codiiousgnadil__tiftmefme"

    const-string v53, "config_last_modified_time"

    const-string v54, ";DL_o_epTif mE t_lsmOgdpiXApCfUeELp AsTBntiMDAaNTR  dTELc i"

    const-string/jumbo v54, "m_AULoOpTAtdDfC LsMsTEdpND;TpL AXEaecn m_eBi  Tlii _ioREtgf"

    const-string v54, " fp_sT tqCmNn; _dLRELUseDMiXOgBTEeo_LmpdlDT iiiTAAftEoAa a "

    const-string v54, "ALTER TABLE apps ADD COLUMN config_last_modified_time TEXT;"

    filled-new-array/range {v1 .. v54}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->h:[Ljava/lang/String;

    const-string v0, "aisreqlt"

    const-string/jumbo v0, "qeatirel"

    const-string/jumbo v0, "reemltai"

    const-string/jumbo v0, "realtime"

    const-string/jumbo v1, "meeDonIteL_ UDNEv sEEMeCA ALTTRatE rAO as rw;TRLiNB"

    const-string v1, "BDsNLEE R er Ta MrOneaERT;DNAiI  GTLECUvtsAw_LmteeA"

    const-string v1, " RniNbDIA TeArLDG CTmLaAa;TLv eR UwEEelEtEOetsrB NM"

    const-string v1, "ALTER TABLE raw_events ADD COLUMN realtime INTEGER;"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->i:[Ljava/lang/String;

    const-string/jumbo v0, "onmcyturter"

    const-string/jumbo v0, "ttymerocrnu"

    const-string/jumbo v0, "rtrocntpyue"

    const-string/jumbo v0, "retry_count"

    const-string/jumbo v1, "nyc;rTNoqUC  e  TuAuEetIERLtLGAD_MErTRuBEDoe AOL "

    const-string/jumbo v1, "tMuEo ALcTNCR DeT uu UIEeA LNET oeLDGnOrAyRtBE_;r"

    const-string v1, "c_sLturNrRLE CT IUTEt;DeqAe  GAoEET DNAneRMy LOuu"

    const-string v1, "ALTER TABLE queue ADD COLUMN retry_count INTEGER;"

    const-string/jumbo v2, "ieammrseablh"

    const-string v2, "arealbsei_hm"

    const-string/jumbo v2, "teiaoshrae_l"

    const-string v2, "has_realtime"

    const-string v3, " _EL;uuuE LA CqTeTGRDatB iDmOLMeEarI TseRN lhAUeAN"

    const-string v3, "eaAAlbee_ETiBCmTNEDeqr hGLEt;TaN UI LLOEsDMu Au  R"

    const-string v3, "ALTER TABLE queue ADD COLUMN has_realtime INTEGER;"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->j:[Ljava/lang/String;

    const-string/jumbo v0, "sERfT;usrTL  LnON ev elMeo_s OesNttLAiEAAsCBOioecDDEpBp _LdA"

    const-string/jumbo v0, "tpdvniop BLtss_eNes TDeAMAeEC iNO;L sfOL renDRAlA Loc_TOEEBs"

    const-string v0, " N;AenBpiEoTiD_TLs ULpLNL Ose_ essEvBldeDRn sAt EMAoCrAfOetc"

    const-string v0, "ALTER TABLE event_filters ADD COLUMN session_scoped BOOLEAN;"

    const-string/jumbo v1, "onoedsseqqpis_"

    const-string/jumbo v1, "sinpsds_qeoeoc"

    const-string v1, "_cseiopsndsses"

    const-string/jumbo v1, "session_scoped"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->k:[Ljava/lang/String;

    const-string/jumbo v0, "sOsmoDACNspfeAOLpNssE UM iA eLctEBeERlTDyo  e;roOtrn LdT_ripBAL"

    const-string v0, "cNs rMLsp ryspApo LsE_e E NsEeeOiiDACDnrdUTLe; fABtRltoBOOoLTAs"

    const-string v0, "ALTER TABLE property_filters ADD COLUMN session_scoped BOOLEAN;"

    filled-new-array {v1, v0}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->l:[Ljava/lang/String;

    const-string/jumbo v0, "trc_oimenatpu_slsoilvo"

    const-string/jumbo v0, "scum_tisr_vnoolnpilate"

    const-string/jumbo v0, "pllnsbnstuuo__ctvoiiar"

    const-string/jumbo v0, "previous_install_count"

    const-string v1, " ULNoRup Aito EpcDtANaB2oC_sOvEn;LAlEIsEGrRTTuuLepDa_nl M  "

    const-string/jumbo v1, "ploNopBinlo i_rGLO sCL s ptEtITA ;_cuDnU Ava2DuEaeNLEEATMRR"

    const-string v1, "Ge ItclptsNALTM2E; pooiNARaRD_L T  uUEsOpAiE nulBvTCaDnErpL"

    const-string v1, "ALTER TABLE app2 ADD COLUMN previous_install_count INTEGER;"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/google/android/gms/measurement/internal/j;->m:[Ljava/lang/String;

    return-void
.end method

.method constructor <init>(Lcom/google/android/gms/measurement/internal/ba;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/r9;-><init>(Lcom/google/android/gms/measurement/internal/ba;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance p1, Lcom/google/android/gms/measurement/internal/n9;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Lcom/google/android/gms/measurement/internal/n9;-><init>(Lcom/google/android/gms/common/util/g;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/j;->e:Lcom/google/android/gms/measurement/internal/n9;

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance p1, Lcom/google/android/gms/measurement/internal/i;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "egdmtnpmq.bprseaa_egbouo_"

    const-string v1, "bnmpebro.aasd__pmueotegge"

    const/4 v3, 0x3

    const-string v1, "google_app_measurement.db"

    const/4 v3, 0x3

    invoke-direct {p1, p0, v0, v1}, Lcom/google/android/gms/measurement/internal/i;-><init>(Lcom/google/android/gms/measurement/internal/j;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/j;->d:Lcom/google/android/gms/measurement/internal/i;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method static bridge synthetic A()[Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ sn@~ o@@iv@ s~~@m f@-1t4t  bb~~~~@~@ o @oM~o@~@ a .@@  l@~ir f~o~ ~d/~Sc~~ o~~Kyli@/~~@ u b~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->m:[Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method static bridge synthetic B()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->h:[Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method static bridge synthetic C()[Ljava/lang/String;
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->f:[Ljava/lang/String;

    const/4 v1, 0x3

    move v2, v1

    return-object v0
.end method

.method static bridge synthetic D()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->k:[Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method static bridge synthetic E()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->l:[Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method static bridge synthetic F()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->j:[Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method static bridge synthetic G()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->i:[Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method static bridge synthetic H()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/measurement/internal/j;->g:[Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method static final J(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/Object;)V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo p1, "vuleu"

    const/4 v2, 0x4

    const-string/jumbo p1, "vaemu"

    const-string/jumbo p1, "value"

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    instance-of v0, p2, Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p2, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    instance-of v0, p2, Ljava/lang/Long;

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p2, Ljava/lang/Long;

    invoke-virtual {p0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x6

    instance-of v0, p2, Ljava/lang/Double;

    const/4 v2, 0x5

    const/4 v1, 0x1

    if-eqz v0, :cond_2

    const/4 v1, 0x6

    move v2, v1

    check-cast p2, Ljava/lang/Double;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Double;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-void

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string p1, "ia Iotleylupavpnd "

    const-string/jumbo p1, "tnpaveup I vylidla"

    const/4 v2, 0x0

    const-string/jumbo p1, "u ellbpnevtyida Iv"

    const-string p1, "Invalid value type"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    throw p0
.end method

.method private final L(Ljava/lang/String;[Ljava/lang/String;)J
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1, p2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v1, p2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-wide p1

    :cond_0
    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    new-instance p2, Landroid/database/sqlite/SQLiteException;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v0, "a esaruD msde ryantttetbeue"

    const-string v0, "Database returned empty set"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p2, v0}, Landroid/database/sqlite/SQLiteException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p2
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception p2

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v2, "esoDraepqabtar"

    const-string/jumbo v2, "rbaDo eaqtsaer"

    const/4 v4, 0x0

    const-string v2, " aabreteqorrDs"

    const-string v2, "Database error"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v2, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_0
    const/4 v3, 0x4

    move v4, v3

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    throw p1
.end method

.method private final M(Ljava/lang/String;[Ljava/lang/String;J)J
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 p2, 0x2

    const/4 p2, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v1, p2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-wide p3

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :catch_0
    move-exception p2

    :try_start_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p4, "a sassbtDeraor"

    const-string p4, "Dosebetsaaarr "

    const/4 v3, 0x5

    const-string p4, "aramos aetrreb"

    const-string p4, "Database error"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p3, p4, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p1
.end method

.method static bridge synthetic Y(Lcom/google/android/gms/measurement/internal/j;)Lcom/google/android/gms/measurement/internal/n9;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/j;->e:Lcom/google/android/gms/measurement/internal/n9;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public final I(Ljava/lang/String;JJLcom/google/android/gms/measurement/internal/aa;)V
    .locals 20

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p6

    move-object/from16 v2, p6

    invoke-static/range {p6 .. p6}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v3, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_6
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const-string v5, ""

    const-string v5, ""

    const-string v5, ""

    const-string v5, ""

    const-wide/16 v13, -0x1

    const-wide/16 v13, -0x1

    const-wide/16 v13, -0x1

    const-wide/16 v13, -0x1

    const/4 v15, 0x2

    const/4 v12, 0x1

    const/4 v11, 0x0

    if-eqz v4, :cond_3

    cmp-long v4, p4, v13

    if-eqz v4, :cond_0

    :try_start_1
    new-array v6, v15, [Ljava/lang/String;

    invoke-static/range {p4 .. p5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v11

    invoke-static/range {p2 .. p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v12

    goto :goto_0

    :cond_0
    new-array v6, v12, [Ljava/lang/String;

    invoke-static/range {p2 .. p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v11
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_6
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :goto_0
    if-eqz v4, :cond_1

    const-string v5, " o=iormd<w? d  "

    const-string v5, " d mor=i ?d<n w"

    const-string v5, "  iadb<od?= wr "

    const-string/jumbo v5, "rowid <= ? and "

    :cond_1
    :try_start_2
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit16 v4, v4, 0x94

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string/jumbo v4, "reaarwute_amiitomw  rstslrre eavef,npfeo gn d_tptp ceendhi"

    const-string v4, " _reolirp_vdeper  _sreaefmga  titmdhae, rfpnntesnwoiceattw"

    const-string v4, "emri_vepie dpeaf_  ,wrnmhpas tee rtn_rgaere sftatwdontilap"

    const-string/jumbo v4, "select app_id, metadata_fingerprint from raw_events where "

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "htm tbblip>re  cs=md_dpaa emeie  io1rnl)efdif i erf ocrspt_yp p_eoi_igod ( cadw ei?wrt;nhp"

    const-string/jumbo v4, "wir  _cnq i> ?afobnepd tp ie er ihmila(frpimt el sa ooip=o ciremhf_d;pews r_ tgd_1ptycde)e"

    const-string v4, "app_id in (select app_id from apps where config_fetched_time >= ?) order by rowid limit 1;"

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4, v6}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_6
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :try_start_3
    invoke-interface {v4}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v5
    :try_end_3
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    if-nez v5, :cond_2

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-void

    :cond_2
    :try_start_4
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4}, Landroid/database/Cursor;->close()V
    :try_end_4
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    goto :goto_2

    :catch_0
    move-exception v0

    goto/16 :goto_6

    :cond_3
    cmp-long v4, p4, v13

    if-eqz v4, :cond_4

    :try_start_5
    new-array v6, v15, [Ljava/lang/String;

    aput-object v3, v6, v11

    invoke-static/range {p4 .. p5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v6, v12

    goto :goto_1

    :cond_4
    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v6
    :try_end_5
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_5 .. :try_end_5} :catch_6
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :goto_1
    if-eqz v4, :cond_5

    const-string/jumbo v5, "o sd = iw n<?ru"

    const-string v5, "  n? wud =r<iao"

    const-string v5, "<? mdwan = oidr"

    const-string v5, " and rowid <= ?"

    :cond_5
    :try_start_6
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v4

    add-int/lit8 v4, v4, 0x54

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v4, "fte oeftsh wt me_eveogra_cirn?aat_apd ern  =mp dplrewnarites"

    const-string/jumbo v4, "select metadata_fingerprint from raw_events where app_id = ?"

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "wiyromlpb tr;1 dioredi  "

    const-string v4, "  iirbm;  boodydirw etr1"

    const-string v4, " order by rowid limit 1;"

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4, v6}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4
    :try_end_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_6 .. :try_end_6} :catch_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :try_start_7
    invoke-interface {v4}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v5
    :try_end_7
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    if-nez v5, :cond_6

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-void

    :cond_6
    :try_start_8
    invoke-interface {v4, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4}, Landroid/database/Cursor;->close()V
    :try_end_8
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :goto_2
    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    :try_start_9
    new-array v6, v12, [Ljava/lang/String;

    const-string v4, "atdtamua"

    const-string/jumbo v4, "qmattdaa"

    const-string v4, "dmeaaatp"

    const-string/jumbo v4, "metadata"

    aput-object v4, v6, v11

    filled-new-array {v3, v10}, [Ljava/lang/String;

    move-result-object v8

    const-string v5, "ea_sw_aeqrtmnsadtev"

    const-string/jumbo v5, "ntsmeaw_aa_daseertv"

    const-string/jumbo v5, "tdsntw__mtvesearaea"

    const-string/jumbo v5, "raw_events_metadata"

    const-string v7, "=?_mng d fidpitaprtratn ? dn ie_aepmaam"

    const-string v7, "e gm_pd_nr?tadappr?d=  nitta finm eaai "

    const-string v7, "_d ?opepr =tanaitnapmnd  i=?tafgi erd a"

    const-string v7, "app_id = ? and metadata_fingerprint = ?"

    const/4 v9, 0x0

    const/16 v17, 0x0

    const-string v18, "bwoid"

    const-string/jumbo v18, "idowo"

    const-string/jumbo v18, "wudio"

    const-string/jumbo v18, "rowid"

    const-string v19, "2"

    const-string v19, "2"

    const-string v19, "2"

    const-string v19, "2"

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v15, v10

    move-object v15, v10

    move-object v15, v10

    move-object v15, v10

    move-object/from16 v10, v17

    move-object/from16 v10, v17

    move-object/from16 v10, v17

    move-object/from16 v10, v17

    move v13, v11

    move v13, v11

    move v13, v11

    move-object/from16 v11, v18

    move-object/from16 v11, v18

    move-object/from16 v11, v18

    move v14, v12

    move v14, v12

    move v14, v12

    move v14, v12

    move-object/from16 v12, v19

    move-object/from16 v12, v19

    move-object/from16 v12, v19

    move-object/from16 v12, v19

    invoke-virtual/range {v4 .. v12}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v12
    :try_end_9
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_9 .. :try_end_9} :catch_5
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :try_start_a
    invoke-interface {v12}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v4

    if-nez v4, :cond_7

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string/jumbo v2, "mbspaodpa InriaiadRs  ridenetge mv pc.attwe"

    const-string/jumbo v2, "sactibiaanr eets do waRmeI edn vrdpp.tsigma"

    const-string/jumbo v2, "s ai tr qrRnit.pIawd o msn sctegeedpmvaidae"

    const-string v2, "Raw event metadata record is missing. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_a
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_a .. :try_end_a} :catch_4
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    invoke-interface {v12}, Landroid/database/Cursor;->close()V

    return-void

    :cond_7
    :try_start_b
    invoke-interface {v12, v13}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v4
    :try_end_b
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_b .. :try_end_b} :catch_4
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :try_start_c
    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzfy;->zzu()Lcom/google/android/gms/internal/measurement/zzfx;

    move-result-object v5

    invoke-static {v5, v4}, Lcom/google/android/gms/measurement/internal/da;->D(Lcom/google/android/gms/internal/measurement/zzlb;[B)Lcom/google/android/gms/internal/measurement/zzlb;

    move-result-object v4

    check-cast v4, Lcom/google/android/gms/internal/measurement/zzfx;

    invoke-virtual {v4}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v4

    check-cast v4, Lcom/google/android/gms/internal/measurement/zzfy;
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_c .. :try_end_c} :catch_4
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    :try_start_d
    invoke-interface {v12}, Landroid/database/Cursor;->moveToNext()Z

    move-result v5

    if-eqz v5, :cond_8

    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v5

    const-string/jumbo v6, "responi a ctuwaesaevpdrena  cdmptm,d  ltex ot eleIaper.euted"

    const-string v6, ",eropmux  .dereecttsdecawupI lm pdevtelanpeeta  da rtnio tae"

    const-string v6, "d omdl, ctGlpntt xretmd  eeIeaaecdwmnts tppp. aoeee evuriaae"

    const-string v6, "Get multiple raw event metadata records, expected one. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_8
    invoke-interface {v12}, Landroid/database/Cursor;->close()V

    invoke-static {v4}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v4, v2, Lcom/google/android/gms/measurement/internal/aa;->a:Lcom/google/android/gms/internal/measurement/zzfy;

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    cmp-long v4, p4, v4

    const/4 v11, 0x3

    if-eqz v4, :cond_9

    const-string/jumbo v4, "pn poa? ia =afngrtn?atw=d e a_n oi i_  <md ptiderp=add"

    const-string/jumbo v4, "wti  _ prpiet  <=f t?=nanpeir?_daoa a=dgdmaadipd? n  n"

    const-string v4, "  andbndwi t?n_ran=_agot ?adiipaap=e=dpm e ri<  f r?d "

    const-string v4, "app_id = ? and metadata_fingerprint = ? and rowid <= ?"

    new-array v5, v11, [Ljava/lang/String;

    aput-object v3, v5, v13

    aput-object v15, v5, v14

    invoke-static/range {p4 .. p5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x2

    aput-object v6, v5, v7

    goto :goto_3

    :cond_9
    const-string v4, "e a=iduapmrd_eqn np r ni?tft taad ia?_p"

    const-string/jumbo v4, "it__f p qaa ntieiraae a =?pnddd?mnpgtr "

    const-string/jumbo v4, "n=?  gtpenptanrd priai eaf?_ dada=_i tm"

    const-string v4, "app_id = ? and metadata_fingerprint = ?"

    filled-new-array {v3, v15}, [Ljava/lang/String;

    move-result-object v5

    :goto_3
    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    const/4 v4, 0x4

    new-array v6, v4, [Ljava/lang/String;

    const-string/jumbo v4, "swrqi"

    const-string/jumbo v4, "rdswi"

    const-string/jumbo v4, "wisor"

    const-string/jumbo v4, "rowid"

    aput-object v4, v6, v13

    const-string/jumbo v4, "nmea"

    const-string v4, "amen"

    const-string v4, "eman"

    const-string/jumbo v4, "name"

    aput-object v4, v6, v14

    const-string v4, "atsmemimt"

    const-string/jumbo v4, "tsimmptae"

    const-string/jumbo v4, "meamotspt"

    const-string/jumbo v4, "timestamp"

    const/4 v5, 0x2

    aput-object v4, v6, v5

    const-string/jumbo v4, "tdaa"

    const-string/jumbo v4, "tada"

    const-string v4, "adta"

    const-string v4, "data"

    aput-object v4, v6, v11

    const-string/jumbo v5, "sroatben_w"

    const-string/jumbo v5, "vnseo_atrw"

    const-string v5, "_snteauerw"

    const-string/jumbo v5, "raw_events"

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v15, "bwpdo"

    const-string v15, "bdwio"

    const-string/jumbo v15, "odrqw"

    const-string/jumbo v15, "rowid"
    :try_end_d
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_d .. :try_end_d} :catch_4
    .catchall {:try_start_d .. :try_end_d} :catchall_1

    const/16 v16, 0x0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move v14, v11

    move v14, v11

    move-object v11, v15

    move-object v11, v15

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    :try_start_e
    invoke-virtual/range {v4 .. v12}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4
    :try_end_e
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_e .. :try_end_e} :catch_3
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    :try_start_f
    invoke-interface {v4}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_c

    :cond_a
    invoke-interface {v4, v13}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v5

    invoke-interface {v4, v14}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v0
    :try_end_f
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_f .. :try_end_f} :catch_0
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    :try_start_10
    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzfo;->zze()Lcom/google/android/gms/internal/measurement/zzfn;

    move-result-object v7

    invoke-static {v7, v0}, Lcom/google/android/gms/measurement/internal/da;->D(Lcom/google/android/gms/internal/measurement/zzlb;[B)Lcom/google/android/gms/internal/measurement/zzlb;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfn;
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_10 .. :try_end_10} :catch_0
    .catchall {:try_start_10 .. :try_end_10} :catchall_4

    const/4 v7, 0x1

    :try_start_11
    invoke-interface {v4, v7}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Lcom/google/android/gms/internal/measurement/zzfn;->zzi(Ljava/lang/String;)Lcom/google/android/gms/internal/measurement/zzfn;

    const/4 v8, 0x2

    invoke-interface {v4, v8}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v9

    invoke-virtual {v0, v9, v10}, Lcom/google/android/gms/internal/measurement/zzfn;->zzm(J)Lcom/google/android/gms/internal/measurement/zzfn;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfo;

    invoke-virtual {v2, v5, v6, v0}, Lcom/google/android/gms/measurement/internal/aa;->a(JLcom/google/android/gms/internal/measurement/zzfo;)Z

    move-result v0
    :try_end_11
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_11 .. :try_end_11} :catch_0
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    if-nez v0, :cond_b

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-void

    :catch_1
    move-exception v0

    const/4 v7, 0x1

    const/4 v8, 0x2

    :try_start_12
    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v5

    const-string v6, " is steaaplsaw e perrgta. aFmt evooddDu In."

    const-string v6, "ddga.au ra  repo .Fe  eIDtnavpem ewltstaois"

    const-string v6, "a  mp raepvosFetdtntsw ga lolaeiem eI.ad.rD"

    const-string v6, "Data loss. Failed to merge raw event. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v5, v6, v9, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_b
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0
    :try_end_12
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_12 .. :try_end_12} :catch_0
    .catchall {:try_start_12 .. :try_end_12} :catchall_4

    if-nez v0, :cond_a

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-void

    :cond_c
    :try_start_13
    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v2, "a eroeI d wadtvhntdisaoewinp.aen aRipad caltpt anesirp"

    const-string v2, "aewdsinppnhtdal oR .t a iIi ews patate aernvnaeaprcidd"

    const-string v2, " srp btrneiaaen.h sdtpnli twe  iapedpoIdtwReaai avndac"

    const-string v2, "Raw event data disappeared while in transaction. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_13
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_13 .. :try_end_13} :catch_0
    .catchall {:try_start_13 .. :try_end_13} :catchall_4

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-void

    :catch_2
    move-exception v0

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    :try_start_14
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v4, ".qt aoudnwetsaFaeI lata   treelv mt d.sDi ampgeaedar"

    const-string v4, "at l.pm qDln  e etaaetowdmaesr sdveg  iatIat.rFdaaoe"

    const-string/jumbo v4, "sea eFape eta voa a t  tld.tdproimpg.watedaanslDrIem"

    const-string v4, "Data loss. Failed to merge raw event metadata. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v4, v5, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_14
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_14 .. :try_end_14} :catch_3
    .catchall {:try_start_14 .. :try_end_14} :catchall_0

    invoke-interface {v15}, Landroid/database/Cursor;->close()V

    return-void

    :catchall_0
    move-exception v0

    goto :goto_4

    :catch_3
    move-exception v0

    goto :goto_5

    :catchall_1
    move-exception v0

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    :goto_4
    move-object v3, v15

    move-object v3, v15

    move-object v3, v15

    move-object v3, v15

    goto :goto_7

    :catch_4
    move-exception v0

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    :goto_5
    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    goto :goto_6

    :catchall_2
    move-exception v0

    move-object/from16 v3, v16

    move-object/from16 v3, v16

    goto :goto_7

    :catch_5
    move-exception v0

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    goto :goto_6

    :catchall_3
    move-exception v0

    goto :goto_7

    :catch_6
    move-exception v0

    move-object v4, v3

    move-object v4, v3

    :goto_6
    :try_start_15
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v5, " .nrwlr qic sdDsaoIv.regeptaltnase rEpteoa "

    const-string v5, " ese.satergrdatvtroc rIsn waD. ela oEn ippl"

    const-string v5, "dcsn  aor ete.rso IlEi aagpvlpen.srwat setD"

    const-string v5, "Data loss. Error selecting raw event. appId"

    invoke-static {v3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v5, v3, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_4

    if-eqz v4, :cond_d

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    :cond_d
    return-void

    :catchall_4
    move-exception v0

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_7
    if-eqz v3, :cond_e

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_e
    throw v0
.end method

.method public final K(Ljava/lang/String;Ljava/lang/String;)I
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v2, "clompoinpi_rtsneertdmo"

    const-string/jumbo v2, "t_dmserantolpnpiroeico"

    const/4 v5, 0x5

    const-string v2, "epaiosdrninoptloor_tei"

    const-string v2, "conditional_properties"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string/jumbo v3, "ma d?bn_edop=?=ianp"

    const-string/jumbo v3, "pda?o =an?ep_min =d"

    const/4 v5, 0x4

    const-string v3, " a?aa?u=d=dpnpim_en"

    const-string v3, "app_id=? and name=?"

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v3, v1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return p1

    :catch_0
    move-exception v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, p2}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v2, "rgtotEyp radldntcboelrn ipopore rei"

    const-string v2, " yeeEboeldirangtp trnot dporiclorrn"

    const/4 v5, 0x7

    const-string v2, "delonronqyatte  olcer Eirrtoipigrpd"

    const-string v2, "Error deleting conditional property"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2, p1, p2, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    return p1
.end method

.method protected final N(Ljava/lang/String;Ljava/lang/String;)J
    .locals 13
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo p2, "teofncu_nsro_piu"

    const-string/jumbo p2, "tcsseufproo_ti_n"

    const-string p2, "first_open_count"

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    const/16 v4, 0x30

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v4, "eslmetp"

    const-string/jumbo v4, "pltscee"

    const-string/jumbo v4, "le sotc"

    const-string/jumbo v4, "select "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "oarqpbfahe2de_irpw mpp=  "

    const-string v4, "e _f pwhq?=ar2amppieo drp"

    const-string v4, " fh=a_ui2e?poarpwdpm  rpe"

    const-string v4, " from app2 where app_id=?"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    invoke-direct {p0, v3, v4, v5, v6}, Lcom/google/android/gms/measurement/internal/j;->M(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v3
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    cmp-long v7, v3, v5

    const-string/jumbo v8, "ppa2"

    const-string v8, "2app"

    const-string v8, "app2"

    const-string/jumbo v9, "pppdi_"

    const-string v9, "app_id"

    if-nez v7, :cond_1

    :try_start_1
    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    invoke-virtual {v3, v9, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, p2, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v7, "iuou_ssnqllocrs_atitpe"

    const-string/jumbo v7, "s_slin_loocasievtturpu"

    const-string v7, "_rsntuolvunspis_teciao"

    const-string/jumbo v7, "previous_install_count"

    invoke-virtual {v3, v7, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v4, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v8, v4, v3, v7}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v3

    cmp-long v3, v3, v5

    if-nez v3, :cond_0

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string v4, "  -m t.adc1osmtFtrdp  i(la)ngioplme eou"

    const-string v4, "etmm na piel(tu s pl1aoiotd -F. Icor)dg"

    const-string v4, " neaop.Io  ro)o tdpt1mt -anildgu(e slFi"

    const-string v4, "Failed to insert column (got -1). appId"

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v3, v4, v7, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-wide v5

    :cond_0
    move-wide v3, v1

    :cond_1
    :try_start_2
    new-instance v7, Landroid/content/ContentValues;

    invoke-direct {v7}, Landroid/content/ContentValues;-><init>()V

    invoke-virtual {v7, v9, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    add-long/2addr v9, v3

    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-virtual {v7, p2, v9}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v9

    const-string v10, "?a pobid_p"

    const-string v10, "=p_aoip ?d"

    const-string v10, "=ppda u? _"

    const-string v10, "app_id = ?"

    invoke-virtual {v0, v8, v7, v10, v9}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v7

    int-to-long v7, v7

    cmp-long v1, v7, v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const-string v2, "0gmaeboadpulocp u  tn.eod  )pFti(dat I"

    const-string v2, " t  diep)F(duaep  ll.popattuImadn gc0o"

    const-string v2, "Failed to update column (got 0). appId"

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v1, v2, v7, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-wide v5

    :cond_2
    :try_start_3
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_3
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_1

    :catch_0
    move-exception v1

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :catch_1
    move-exception v3

    move-wide v11, v1

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-wide v3, v11

    :goto_0
    :try_start_4
    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v5, "nsrrpru nroiconE gp a.tmdleuI"

    const-string/jumbo v5, "rcaipn nqrrngEt ruoeIpsodi. m"

    const-string v5, "Error inserting column. appId"

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v2, v5, p1, p2, v1}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :goto_1
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-wide v3

    :goto_2
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw p1
.end method

.method public final O()J
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v3, "ams_xmmep_euucqs  d tl)imatestdeuofbrnl(epe"

    const-string v3, " eeufpdpql(t)uea__dnsletmmarce mst mxiobeeu"

    const/4 v5, 0x2

    const-string/jumbo v3, "otqm fsu(us__en euree)enmtamit xledcmaemdlb"

    const-string/jumbo v3, "select max(bundle_end_timestamp) from queue"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p0, v3, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/j;->M(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-wide v0
.end method

.method public final P()J
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v3, "_im(ocemfvsta e nwsqrlmtrpm)te oesate"

    const-string v3, "fx s_eevqeaiml smrwme )(ttrtcopatensm"

    const/4 v5, 0x0

    const-string/jumbo v3, "selrtbic_mwa)oms xtneef  amttp(rvmeae"

    const-string/jumbo v3, "select max(timestamp) from raw_events"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p0, v3, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/j;->M(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-wide v0
.end method

.method public final Q(Ljava/lang/String;)J
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v0, "_see/iu/ptsrme  l? en=(ktvns_ep) to/%scdn nr/une!de /! eooci/hpa w a/cf / tamaeel"

    const-string/jumbo v0, "usslte epair//soaeecate! n1edfn/a%ln/mi  (c/en e?o hn/ppo_es/ =m e  )kt dtvr!cw_/"

    const/4 v4, 0x0

    const-string v0, "?nearo)pahp eicptiw !%oa_el /!( e/secdf nse = uk eo/t ed/ec/m/ se ap/vrlt /t_n1mn"

    const-string/jumbo v0, "select count(1) from events where app_id=? and name not like \'!_%\' escape \'!\'"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0, v0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/j;->M(Ljava/lang/String;[Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-wide v0
.end method

.method final R()Landroid/database/sqlite/SQLiteDatabase;
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/j;->d:Lcom/google/android/gms/measurement/internal/i;

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/i;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "rgaboparqosn teraem nE"

    const-string/jumbo v2, "tbemara ag rnioEpreson"

    const/4 v4, 0x1

    const-string/jumbo v2, "rgsor  prianeeEbaasont"

    const-string v2, "Error opening database"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v2, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw v0
.end method

.method public final S(Ljava/lang/String;)Landroid/os/Bundle;
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v8, 0x2

    const/4 v0, 0x2

    const/4 v8, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v3, "iasmode_e rp?onwpuf__pcletrateteedea t=srvfsrharma mpa l m"

    const-string/jumbo v3, "prmloem a_ adw=?vpesetreanehtlsstefrc edaurat_rp ia _emopf"

    const/4 v8, 0x1

    const-string v3, "atedoeeatter iho_re?enm_dapwseafcm=srevf  per_ urlasmlatpp"

    const-string/jumbo v3, "select parameters from default_event_params where app_id=?"

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1, v3, v2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-nez v2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v2, "Dlueabfarveneebo tatdnfets  onprut"

    const-string/jumbo v2, "v rtnbo etdetnlru supaafDeaetf eon"

    const/4 v8, 0x7

    const-string v2, "Default event parameters not found"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p1, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object v0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, 0x0

    :try_start_2
    const/4 v8, 0x1

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v2
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzfo;->zze()Lcom/google/android/gms/internal/measurement/zzfn;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v3, v2}, Lcom/google/android/gms/measurement/internal/da;->D(Lcom/google/android/gms/internal/measurement/zzlb;[B)Lcom/google/android/gms/internal/measurement/zzlb;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    check-cast v2, Lcom/google/android/gms/internal/measurement/zzfn;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v2, Lcom/google/android/gms/internal/measurement/zzfo;
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/internal/measurement/zzfo;->zzi()Ljava/util/List;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v2, Landroid/os/Bundle;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v3, :cond_5

    const/4 v8, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    check-cast v3, Lcom/google/android/gms/internal/measurement/zzfs;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzg()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzu()Z

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v5, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zza()D

    move-result-wide v5

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v2, v4, v5, v6}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzv()Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v5, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzb()F

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzy()Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v5, :cond_4

    const/4 v7, 0x2

    xor-int/2addr v8, v7

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzh()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_0

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzw()Z

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzfs;->zzd()J

    move-result-wide v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v2, v4, v5, v6}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V
    :try_end_4
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v8, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    return-object v2

    :catch_0
    move-exception v2

    :try_start_5
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo v4, "vtrrIpuatreitettFi dafn.daesl lpr eemue epadee au "

    const-string v4, "anar auemfIe edptupeedtertrst voletFrd.al i ae epi"

    const/4 v8, 0x7

    const-string v4, " omdtdtpnaealpasa f paF.re  eeuvieivreeple tedtIrt"

    const-string v4, "Failed to retrieve default event parameters. appId"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3, v4, p1, v2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_5
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_5 .. :try_end_5} :catch_1
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-object v0

    :catch_1
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    goto :goto_2

    :catch_2
    move-exception p1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_1
    :try_start_6
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x6

    or-int/2addr v8, v7

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const-string v3, " rvisfnaqrpsurteattecnElt geree alpdo rm"

    const-string v3, "astgearptlr   lpvceEts rednereonumetaifr"

    const/4 v8, 0x6

    const-string v3, "Ers r geafeeriatlusa oeenvsdlmttrnprcte "

    const-string v3, "Error selecting default event parameters"

    const/4 v8, 0x2

    invoke-virtual {v2, v3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v1, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    return-object v0

    :catchall_1
    move-exception p1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v0, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    :cond_7
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    throw p1
.end method

.method public final T(Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/e5;
    .locals 24
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v3, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v4

    const/16 v0, 0x1c

    new-array v6, v0, [Ljava/lang/String;

    const-string v0, "cnipnsteqd_a_ia"

    const-string/jumbo v0, "nnemsad_ppcii_a"

    const-string v0, "app_instance_id"

    const/4 v12, 0x0

    aput-object v0, v6, v12

    const-string/jumbo v0, "ms_dop_ipa"

    const-string v0, "_mspi_papd"

    const-string/jumbo v0, "mpgp_bd_ia"

    const-string v0, "gmp_app_id"

    const/4 v13, 0x1

    aput-object v0, v6, v13

    const-string v0, "ebicedutd_vseehtmh_s_alia"

    const-string v0, "_ahmrsedislbeih_ceea_ttvd"

    const-string v0, "ebaies_pidhtcedah_t_veers"

    const-string/jumbo v0, "resettable_device_id_hash"

    const/4 v14, 0x2

    aput-object v0, v6, v14

    const-string v0, "exulo_teqdi_ndbsn"

    const-string/jumbo v0, "ixduonatednlbes__"

    const-string/jumbo v0, "nxssudalldin_teb_"

    const-string/jumbo v0, "last_bundle_index"

    const/4 v15, 0x3

    aput-object v0, v6, v15

    const-string/jumbo v0, "lmtmtl_mnieaeasdu_s_brttpsb"

    const-string v0, "d_nasbm_mtptsusl_latatebire"

    const-string/jumbo v0, "ssttoidperae__msmtb_lutaltn"

    const-string/jumbo v0, "last_bundle_start_timestamp"

    const/4 v11, 0x4

    aput-object v0, v6, v11

    const-string/jumbo v0, "metdlb_sbueetu_nn_dplaait"

    const-string/jumbo v0, "mn_plbueestsautdteid_anl_"

    const-string/jumbo v0, "nne_leubtsusd_dtia_mampel"

    const-string/jumbo v0, "last_bundle_end_timestamp"

    const/4 v10, 0x5

    aput-object v0, v6, v10

    const-string v0, "apnp_sopevr"

    const-string v0, "app_version"

    const/4 v9, 0x6

    aput-object v0, v6, v9

    const-string/jumbo v0, "otrpapepq"

    const-string v0, "eprsaptpo"

    const-string/jumbo v0, "taspsorp_"

    const-string v0, "app_store"

    const/4 v8, 0x7

    aput-object v0, v6, v8

    const-string/jumbo v0, "monmiqpgsvr"

    const-string v0, "gio_vmnsqrp"

    const-string/jumbo v0, "posgonirvem"

    const-string v0, "gmp_version"

    const/16 v7, 0x8

    aput-object v0, v6, v7

    const-string v0, "h__evbasdethc"

    const-string v0, "_rstheevdch_a"

    const-string v0, "hrsev_uc_dhat"

    const-string v0, "dev_cert_hash"

    const/16 v5, 0x9

    aput-object v0, v6, v5

    const-string/jumbo v0, "tbrnedspenu_almeemm"

    const-string/jumbo v0, "urdmtel_emaaesenbmn"

    const-string/jumbo v0, "meubamesql_taennede"

    const-string/jumbo v0, "measurement_enabled"

    const/16 v15, 0xa

    aput-object v0, v6, v15

    const-string v0, "ady"

    const-string v0, "ayd"

    const-string v0, "day"

    const/16 v15, 0xb

    aput-object v0, v6, v15

    const-string/jumbo v0, "neciopv_oayesclt_bdu_uilt"

    const-string/jumbo v0, "ucsuapytoecbsllvnd__ni_et"

    const-string v0, "daily_public_events_count"

    const/16 v15, 0xc

    aput-object v0, v6, v15

    const-string v0, "_s_mndelctnuoebyva"

    const-string/jumbo v0, "t_nalbt_eyscoenudv"

    const-string/jumbo v0, "o_avoctinlney_uted"

    const-string v0, "daily_events_count"

    const/16 v15, 0xd

    aput-object v0, v6, v15

    const-string/jumbo v0, "scsueb_ucndonnoyivrol_t"

    const-string/jumbo v0, "ssnurcuyalo_nv_niotcdeo"

    const-string v0, "daily_conversions_count"

    const/16 v15, 0xe

    aput-object v0, v6, v15

    const-string v0, "_epefeuithf_tcnogdi"

    const-string/jumbo v0, "mide_fepeintgfco_ht"

    const-string/jumbo v0, "tfthneepocicgefim_d"

    const-string v0, "config_fetched_time"

    const/16 v15, 0xf

    aput-object v0, v6, v15

    const-string v0, "_nicdfqfqcteieofmilet_ag"

    const-string/jumbo v0, "iigtfaocqcit_fnlde__mefe"

    const-string v0, "failed_config_fetch_time"

    const/16 v16, 0x10

    aput-object v0, v6, v16

    const-string v0, "i_santienpsvp_r"

    const-string v0, "app_version_int"

    const/16 v15, 0x11

    aput-object v0, v6, v15

    const-string v0, "bismicfnniaesered_s_"

    const-string v0, "_fssdnieeciarinestb_"

    const-string/jumbo v0, "r_f_oniaaisecsnitebe"

    const-string v0, "firebase_instance_id"

    const/16 v17, 0x12

    aput-object v0, v6, v17

    const-string/jumbo v0, "ocarvbrenmrotsydnietu_el"

    const-string/jumbo v0, "ncymriduoae_sn_teerrtvlo"

    const-string/jumbo v0, "tr_denuirrvlc_oenyasue_o"

    const-string v0, "daily_error_events_count"

    const/16 v17, 0x13

    aput-object v0, v6, v17

    const-string v0, "enn_tvcpaeoeati_sudlyie_tol"

    const-string v0, "_tceo_rv_latouendsiaeielytn"

    const-string v0, "adyn_vtiqacoee_tlirlt_semne"

    const-string v0, "daily_realtime_events_count"

    const/16 v17, 0x14

    aput-object v0, v6, v17

    const-string v0, "hrsaato_ohmilsmb_enep"

    const-string/jumbo v0, "mnolrbaopt_m_aetsiheh"

    const-string v0, "hetmms_ltnmra_opeiohl"

    const-string v0, "health_monitor_sample"

    const/16 v17, 0x15

    aput-object v0, v6, v17

    const-string/jumbo v0, "rn_doiioda"

    const-string v0, "android_id"

    const/16 v15, 0x16

    aput-object v0, v6, v15

    const-string v0, "e_epibnurli_dodtbaarde"

    const-string v0, "epebdiulonriertaddn_a_"

    const-string v0, "iaoatlureeerpdgn_bdd_n"

    const-string v0, "adid_reporting_enabled"

    const/16 v15, 0x17

    aput-object v0, v6, v15

    const-string v0, "d_oabippa_pm"

    const-string v0, "admob_app_id"

    const/16 v18, 0x18

    aput-object v0, v6, v18

    const-string v0, "epimve_dqanirnts"

    const-string v0, "_dnaenspvetrmyii"

    const-string v0, "dynamite_version"

    const/16 v15, 0x19

    aput-object v0, v6, v15

    const-string/jumbo v0, "lesqeiavstednsfs_"

    const-string v0, "eliveeafqstsd_snt"

    const-string/jumbo v0, "safelisted_events"

    const/16 v15, 0x1a

    aput-object v0, v6, v15

    const-string/jumbo v0, "idam_s_ag"

    const-string v0, "disaga_p_"

    const-string v0, "dgppo__ia"

    const-string v0, "ga_app_id"

    const/16 v19, 0x1b

    aput-object v0, v6, v19

    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v19, "sppa"

    const-string/jumbo v19, "paps"

    const-string/jumbo v19, "sppa"

    const-string v19, "apps"

    const-string/jumbo v20, "p?ipmb_a"

    const-string/jumbo v20, "p?am_pdi"

    const-string v20, "=i_ppdu?"

    const-string v20, "app_id=?"

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move v15, v5

    move v15, v5

    move v15, v5

    move v15, v5

    move-object/from16 v5, v19

    move-object/from16 v5, v19

    move-object/from16 v5, v19

    move v15, v7

    move v15, v7

    move v15, v7

    move v15, v7

    move-object/from16 v7, v20

    move-object/from16 v7, v20

    move-object/from16 v7, v20

    move-object/from16 v7, v20

    move v15, v8

    move v15, v8

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move v0, v9

    move v0, v9

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    move v15, v10

    move v15, v10

    move v15, v10

    move v15, v10

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move-object/from16 v10, v22

    move v0, v11

    move v0, v11

    move-object/from16 v11, v23

    move-object/from16 v11, v23

    move-object/from16 v11, v23

    move-object/from16 v11, v23

    invoke-virtual/range {v4 .. v11}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {v4}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v5
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v5, :cond_0

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-object v3

    :cond_0
    :try_start_2
    new-instance v5, Lcom/google/android/gms/measurement/internal/e5;

    iget-object v6, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/ba;->b0()Lcom/google/android/gms/measurement/internal/z4;

    move-result-object v6

    invoke-direct {v5, v6, v2}, Lcom/google/android/gms/measurement/internal/e5;-><init>(Lcom/google/android/gms/measurement/internal/z4;Ljava/lang/String;)V

    invoke-interface {v4, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/google/android/gms/measurement/internal/e5;->i(Ljava/lang/String;)V

    invoke-interface {v4, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/google/android/gms/measurement/internal/e5;->y(Ljava/lang/String;)V

    invoke-interface {v4, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/google/android/gms/measurement/internal/e5;->H(Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-interface {v4, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->D(J)V

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->E(J)V

    invoke-interface {v4, v15}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->C(J)V

    const/4 v0, 0x6

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->k(Ljava/lang/String;)V

    const/4 v0, 0x7

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->j(Ljava/lang/String;)V

    const/16 v0, 0x8

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->z(J)V

    const/16 v0, 0x9

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->t(J)V

    const/16 v0, 0xa

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-nez v6, :cond_2

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    move v0, v12

    move v0, v12

    move v0, v12

    move v0, v12

    goto :goto_1

    :cond_2
    :goto_0
    move v0, v13

    move v0, v13

    move v0, v13

    move v0, v13

    :goto_1
    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->F(Z)V

    const/16 v0, 0xb

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->s(J)V

    const/16 v0, 0xc

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->q(J)V

    const/16 v0, 0xd

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->p(J)V

    const/16 v0, 0xe

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->n(J)V

    const/16 v0, 0xf

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->m(J)V

    const/16 v0, 0x10

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->v(J)V

    const/16 v0, 0x11

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-eqz v6, :cond_3

    const-wide/32 v6, -0x80000000

    const-wide/32 v6, -0x80000000

    goto :goto_2

    :cond_3
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    int-to-long v6, v0

    :goto_2
    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->l(J)V

    const/16 v0, 0x12

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->w(Ljava/lang/String;)V

    const/16 v0, 0x13

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->o(J)V

    const/16 v0, 0x14

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->r(J)V

    const/16 v0, 0x15

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->B(Ljava/lang/String;)V

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    sget-object v6, Lcom/google/android/gms/measurement/internal/z2;->o0:Lcom/google/android/gms/measurement/internal/y2;

    invoke-virtual {v0, v3, v6}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v0

    if-nez v0, :cond_5

    const/16 v0, 0x16

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-eqz v6, :cond_4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    goto :goto_3

    :cond_4
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    :goto_3
    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->h(J)V

    :cond_5
    const/16 v0, 0x17

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-nez v6, :cond_6

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    if-eqz v0, :cond_7

    :cond_6
    move v12, v13

    move v12, v13

    move v12, v13

    move v12, v13

    :cond_7
    invoke-virtual {v5, v12}, Lcom/google/android/gms/measurement/internal/e5;->g(Z)V

    const/16 v0, 0x18

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->f(Ljava/lang/String;)V

    const/16 v0, 0x19

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-eqz v6, :cond_8

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    goto :goto_4

    :cond_8
    invoke-interface {v4, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v6

    :goto_4
    invoke-virtual {v5, v6, v7}, Lcom/google/android/gms/measurement/internal/e5;->u(J)V

    const/16 v0, 0x1a

    invoke-interface {v4, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v6

    if-nez v6, :cond_9

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v6, ","

    const-string v6, ","

    const-string v6, ","

    const-string v6, ","

    const/4 v7, -0x1

    invoke-virtual {v0, v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->I(Ljava/util/List;)V

    :cond_9
    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzom;->zzc()Z

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    sget-object v6, Lcom/google/android/gms/measurement/internal/z2;->e0:Lcom/google/android/gms/measurement/internal/y2;

    invoke-virtual {v0, v2, v6}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v0

    if-eqz v0, :cond_a

    const/16 v0, 0x1b

    invoke-interface {v4, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/google/android/gms/measurement/internal/e5;->x(Ljava/lang/String;)V

    :cond_a
    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/e5;->d()V

    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_b

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v6, " reaelGp .optlpdaopf,dod rscutoIpm ptenre p eeixc"

    const-string/jumbo v6, "prp oi,fe eappGrrmInoddte . lcaoxlutodptcep e ose"

    const-string/jumbo v6, "nefperdcqdttdleuppmo o Gppreo peixal,.at o reI cs"

    const-string v6, "Got multiple records for app, expected one. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_b
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    return-object v5

    :catch_0
    move-exception v0

    goto :goto_5

    :catchall_0
    move-exception v0

    goto :goto_6

    :catch_1
    move-exception v0

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_5
    :try_start_3
    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v5

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v5

    const-string/jumbo v6, "pdseqbyraorruaIEn gr ipp."

    const-string v6, " p.gqbErIreuopar iaryn dp"

    const-string/jumbo v6, "pg.m iprr yeraqoappnu rEI"

    const-string v6, "Error querying app. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v5, v6, v2, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v4, :cond_c

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    :cond_c
    return-object v3

    :catchall_1
    move-exception v0

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_6
    if-eqz v3, :cond_d

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_d
    throw v0
.end method

.method public final U(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/zzab;
    .locals 36
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v9, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v10

    const/16 v0, 0xb

    new-array v12, v0, [Ljava/lang/String;

    const-string/jumbo v0, "ouinog"

    const-string/jumbo v0, "uigonr"

    const-string/jumbo v0, "roiinb"

    const-string/jumbo v0, "origin"

    const/4 v2, 0x0

    aput-object v0, v12, v2

    const-string/jumbo v0, "vuplu"

    const-string/jumbo v0, "ulpva"

    const-string/jumbo v0, "uaple"

    const-string/jumbo v0, "value"

    const/4 v3, 0x1

    aput-object v0, v12, v3

    const-string v0, "ecqtqv"

    const-string/jumbo v0, "tvqice"

    const-string v0, "eascvi"

    const-string v0, "active"

    const/4 v4, 0x2

    aput-object v0, v12, v4

    const-string/jumbo v0, "trigger_event_name"

    const/4 v5, 0x3

    aput-object v0, v12, v5

    const-string v0, "_tumroterteggis"

    const-string/jumbo v0, "oes_guttriigert"

    const-string/jumbo v0, "iemooitugttgr_r"

    const-string/jumbo v0, "trigger_timeout"

    const/4 v6, 0x4

    aput-object v0, v12, v6

    const-string/jumbo v0, "utevtbndemtime_"

    const-string/jumbo v0, "ttvmndee_tiemu_"

    const-string v0, "_ndetuuvoitmete"

    const-string/jumbo v0, "timed_out_event"

    const/4 v7, 0x5

    aput-object v0, v12, v7

    const-string/jumbo v0, "to_mmtpprciaenosie"

    const-string/jumbo v0, "tacmo_seanrptioime"

    const-string v0, "iatnespoqmiaecrtmt"

    const-string v0, "creation_timestamp"

    const/4 v15, 0x6

    aput-object v0, v12, v15

    const-string v0, "gvsdeeitrgenter"

    const-string/jumbo v0, "veetibergtndegr"

    const-string/jumbo v0, "t_nmvegtedirger"

    const-string/jumbo v0, "triggered_event"

    const/4 v14, 0x7

    aput-object v0, v12, v14

    const-string/jumbo v0, "itmgouteeetridmgrs_"

    const-string/jumbo v0, "ptmrdgutgmeeeri_tis"

    const-string/jumbo v0, "triggered_timestamp"

    const/16 v13, 0x8

    aput-object v0, v12, v13

    const-string/jumbo v0, "miloebte_itv"

    const-string/jumbo v0, "time_to_live"

    const/16 v11, 0x9

    aput-object v0, v12, v11

    const-string v0, "en_epdutixrev"

    const-string v0, "expired_event"

    const/16 v7, 0xa

    aput-object v0, v12, v7

    filled-new-array/range {p1 .. p2}, [Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v16, "toaicteprpnr_lppneoodi"

    const-string/jumbo v16, "tdaiiippnreocpreo_ntlo"

    const-string/jumbo v16, "loo_spdpqtieoancrinret"

    const-string v16, "conditional_properties"

    const-string v17, "apsni?n paqa_?dm=ed"

    const-string/jumbo v17, "n_ai dpeqpa=m?a=?nd"

    const-string v17, " npm?pnmd _ad=aea?="

    const-string v17, "app_id=? and name=?"

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    move v7, v11

    move v7, v11

    move v7, v11

    move-object/from16 v11, v16

    move-object/from16 v11, v16

    move-object/from16 v11, v16

    move v7, v13

    move v7, v13

    move v7, v13

    move v7, v13

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move v7, v14

    move v7, v14

    move v7, v14

    move v7, v14

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move v0, v15

    move v0, v15

    move v0, v15

    move v0, v15

    move-object/from16 v15, v18

    move-object/from16 v15, v18

    move-object/from16 v15, v18

    move-object/from16 v15, v18

    move-object/from16 v16, v19

    move-object/from16 v16, v19

    move-object/from16 v16, v19

    move-object/from16 v16, v19

    move-object/from16 v17, v20

    move-object/from16 v17, v20

    move-object/from16 v17, v20

    invoke-virtual/range {v10 .. v17}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v10
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {v10}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v11
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v11, :cond_0

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    return-object v9

    :cond_0
    :try_start_2
    invoke-interface {v10, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_1

    const-string v11, ""

    const-string v11, ""

    :cond_1
    move-object/from16 v23, v11

    move-object/from16 v23, v11

    move-object/from16 v23, v11

    move-object/from16 v23, v11

    invoke-virtual {v1, v10, v3}, Lcom/google/android/gms/measurement/internal/j;->a0(Landroid/database/Cursor;I)Ljava/lang/Object;

    move-result-object v11

    invoke-interface {v10, v4}, Landroid/database/Cursor;->getInt(I)I

    move-result v4

    if-eqz v4, :cond_2

    move/from16 v27, v3

    move/from16 v27, v3

    move/from16 v27, v3

    move/from16 v27, v3

    goto :goto_0

    :cond_2
    move/from16 v27, v2

    move/from16 v27, v2

    move/from16 v27, v2

    :goto_0
    invoke-interface {v10, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v28

    invoke-interface {v10, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v30

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v2

    const/4 v3, 0x5

    invoke-interface {v10, v3}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v3

    sget-object v4, Lcom/google/android/gms/measurement/internal/zzat;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v2, v3, v4}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    check-cast v29, Lcom/google/android/gms/measurement/internal/zzat;

    invoke-interface {v10, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v25

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v0

    invoke-interface {v10, v7}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    move-object/from16 v32, v0

    move-object/from16 v32, v0

    move-object/from16 v32, v0

    move-object/from16 v32, v0

    check-cast v32, Lcom/google/android/gms/measurement/internal/zzat;

    const/16 v0, 0x8

    invoke-interface {v10, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v5

    const/16 v0, 0x9

    invoke-interface {v10, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v33

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v0

    const/16 v2, 0xa

    invoke-interface {v10, v2}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    move-object/from16 v35, v0

    move-object/from16 v35, v0

    move-object/from16 v35, v0

    move-object/from16 v35, v0

    check-cast v35, Lcom/google/android/gms/measurement/internal/zzat;

    new-instance v24, Lcom/google/android/gms/measurement/internal/zzkv;

    move-object/from16 v2, v24

    move-object/from16 v2, v24

    move-object/from16 v2, v24

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-wide v4, v5

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    invoke-direct/range {v2 .. v7}, Lcom/google/android/gms/measurement/internal/zzkv;-><init>(Ljava/lang/String;JLjava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/google/android/gms/measurement/internal/zzab;

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v21, v0

    move-object/from16 v22, p1

    move-object/from16 v22, p1

    move-object/from16 v22, p1

    move-object/from16 v22, p1

    invoke-direct/range {v21 .. v35}, Lcom/google/android/gms/measurement/internal/zzab;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/measurement/internal/zzkv;JZLjava/lang/String;Lcom/google/android/gms/measurement/internal/zzat;JLcom/google/android/gms/measurement/internal/zzat;JLcom/google/android/gms/measurement/internal/zzat;)V

    invoke-interface {v10}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2

    if-eqz v2, :cond_3

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v3, "e,luoroG pnxylerom neeipr ert potsfdil s ittcdcoooe actonrd"

    const-string/jumbo v3, "iiscenp syd xr eptcrroa,eooe fopeuGcrrod tintmlotn edtell o"

    const-string v3, "dnpetbp mtt conoenloeopyrllraotdxcG  oes,drci ere ito frpiu"

    const-string v3, "Got multiple records for conditional property, expected one"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v5

    invoke-virtual {v5, v8}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4, v5}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_3
    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    return-object v0

    :catch_0
    move-exception v0

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :catch_1
    move-exception v0

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    :goto_1
    :try_start_3
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v3, "tcygpiunrEripudrronoriqlem ya onor "

    const-string/jumbo v3, "pr meto rluingoynqicorr inrdprtoayE"

    const-string v3, "Ean oeepro gyon rcyondtqrrpilrptuii"

    const-string v3, "Error querying conditional property"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v5

    invoke-virtual {v5, v8}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4, v5, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v10, :cond_4

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    :cond_4
    return-object v9

    :catchall_1
    move-exception v0

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    :goto_2
    if-eqz v9, :cond_5

    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    :cond_5
    throw v0
.end method

.method public final V(JLjava/lang/String;ZZZZZ)Lcom/google/android/gms/measurement/internal/h;
    .locals 11
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p1

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move/from16 v8, p6

    move/from16 v8, p6

    move/from16 v10, p8

    move/from16 v10, p8

    move/from16 v10, p8

    invoke-virtual/range {v0 .. v10}, Lcom/google/android/gms/measurement/internal/j;->W(JLjava/lang/String;JZZZZZ)Lcom/google/android/gms/measurement/internal/h;

    move-result-object v0

    return-object v0
.end method

.method public final W(JLjava/lang/String;JZZZZZ)Lcom/google/android/gms/measurement/internal/h;
    .locals 23
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    const-string v0, "_iriooaeqa_tnsvemdutleyletn"

    const-string/jumbo v0, "voyloaet_ilnmetn_ieed_taurs"

    const-string v0, "_tsecunsdeteynetl_oviaiarml"

    const-string v0, "daily_realtime_events_count"

    const-string/jumbo v2, "ieamusonon_rcbede_ryvtrl"

    const-string/jumbo v2, "resanbi__yueedrovocrn_tl"

    const-string/jumbo v2, "snalovretye_iu_ore_crdno"

    const-string v2, "daily_error_events_count"

    const-string/jumbo v3, "u_lnrcucoivndsesoto_iny"

    const-string/jumbo v3, "uno_nbodicayctorvlssen_"

    const-string v3, "daily_conversions_count"

    const-string/jumbo v4, "ldinatuyvbns_cuceet_iuol_"

    const-string v4, "daily_public_events_count"

    const-string/jumbo v5, "yspvt_np_tdolenieu"

    const-string/jumbo v5, "nsvtcdtpeyu__iolen"

    const-string/jumbo v5, "yeaucvneqdtnio__st"

    const-string v5, "daily_events_count"

    const-string v6, "dya"

    const-string/jumbo v6, "yda"

    const-string/jumbo v6, "yad"

    const-string v6, "day"

    invoke-static/range {p3 .. p3}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    filled-new-array/range {p3 .. p3}, [Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lcom/google/android/gms/measurement/internal/h;

    invoke-direct {v8}, Lcom/google/android/gms/measurement/internal/h;-><init>()V

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v15

    const/4 v10, 0x6

    new-array v12, v10, [Ljava/lang/String;

    const/4 v14, 0x0

    aput-object v6, v12, v14

    const/4 v13, 0x1

    aput-object v5, v12, v13

    const/4 v11, 0x2

    aput-object v4, v12, v11

    const/4 v10, 0x3

    aput-object v3, v12, v10

    const/4 v9, 0x4

    aput-object v2, v12, v9

    const/4 v9, 0x5

    aput-object v0, v12, v9

    filled-new-array/range {p3 .. p3}, [Ljava/lang/String;

    move-result-object v16

    const-string/jumbo v17, "sapp"

    const-string v17, "apsp"

    const-string v17, "aspp"

    const-string v17, "apps"

    const-string/jumbo v18, "p?spa=_d"

    const-string/jumbo v18, "q=p_da?p"

    const-string/jumbo v18, "pd?mi_p="

    const-string v18, "app_id=?"

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move v9, v10

    move v9, v10

    move v9, v10

    move v9, v10

    move-object v10, v15

    move-object v10, v15

    move-object v10, v15

    move-object v10, v15

    move v9, v11

    move v9, v11

    move v9, v11

    move v9, v11

    move-object/from16 v11, v17

    move-object/from16 v11, v17

    move-object/from16 v11, v17

    move-object/from16 v11, v17

    move v9, v13

    move v9, v13

    move v9, v13

    move v9, v13

    move-object/from16 v13, v18

    move-object/from16 v13, v18

    move-object/from16 v13, v18

    move-object/from16 v13, v18

    move v9, v14

    move v9, v14

    move v9, v14

    move v9, v14

    move-object/from16 v14, v16

    move-object/from16 v14, v16

    move-object/from16 v14, v16

    move-object/from16 v14, v16

    move-object/from16 v22, v15

    move-object/from16 v22, v15

    move-object/from16 v22, v15

    move-object/from16 v22, v15

    move-object/from16 v15, v19

    move-object/from16 v15, v19

    move-object/from16 v15, v19

    move-object/from16 v15, v19

    move-object/from16 v16, v20

    move-object/from16 v16, v20

    move-object/from16 v16, v20

    move-object/from16 v16, v20

    move-object/from16 v17, v21

    move-object/from16 v17, v21

    invoke-virtual/range {v10 .. v17}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v10
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-interface {v10}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v11

    if-nez v11, :cond_0

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v2, " npgoatsoasd,pu o n apduIii dp.ciotkatpw n nlstyo "

    const-string v2, "gpspNayi tktuiscp ootd ao,n il .pdtanndp s aIuwn o"

    const-string v2, "dayuibnipao oasns,n i o N pc. ppt otln udntdaIpkgw"

    const-string v2, "Not updating daily counts, app is not known. appId"

    invoke-static/range {p3 .. p3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    return-object v8

    :cond_0
    :try_start_2
    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    cmp-long v9, v11, p1

    if-nez v9, :cond_1

    const/4 v9, 0x1

    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->b:J

    const/4 v9, 0x2

    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->a:J

    const/4 v9, 0x3

    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->c:J

    const/4 v9, 0x4

    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->d:J

    const/4 v9, 0x5

    invoke-interface {v10, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->e:J

    :cond_1
    if-eqz p6, :cond_2

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->b:J

    add-long v11, v11, p4

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->b:J

    :cond_2
    if-eqz p7, :cond_3

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->a:J

    add-long v11, v11, p4

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->a:J

    :cond_3
    if-eqz p8, :cond_4

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->c:J

    add-long v11, v11, p4

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->c:J

    :cond_4
    if-eqz p9, :cond_5

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->d:J

    add-long v11, v11, p4

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->d:J

    :cond_5
    if-eqz p10, :cond_6

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->e:J

    add-long v11, v11, p4

    iput-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->e:J

    :cond_6
    new-instance v9, Landroid/content/ContentValues;

    invoke-direct {v9}, Landroid/content/ContentValues;-><init>()V

    invoke-static/range {p1 .. p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    invoke-virtual {v9, v6, v11}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->a:J

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v9, v4, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-wide v11, v8, Lcom/google/android/gms/measurement/internal/h;->b:J

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v9, v5, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-wide v4, v8, Lcom/google/android/gms/measurement/internal/h;->c:J

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v9, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-wide v3, v8, Lcom/google/android/gms/measurement/internal/h;->d:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v9, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    iget-wide v2, v8, Lcom/google/android/gms/measurement/internal/h;->e:J

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v9, v0, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string/jumbo v0, "pspa"

    const-string/jumbo v0, "sapp"

    const-string/jumbo v0, "sppa"

    const-string v0, "apps"

    const-string/jumbo v2, "p?i_a=up"

    const-string v2, "app_id=?"

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    invoke-virtual {v3, v0, v9, v2, v7}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    return-object v8

    :catchall_0
    move-exception v0

    move-object v9, v10

    move-object v9, v10

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    goto :goto_0

    :catchall_1
    move-exception v0

    const/4 v9, 0x0

    goto :goto_1

    :catch_1
    move-exception v0

    const/4 v9, 0x0

    :goto_0
    :try_start_3
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v3, "aaIdu.lpttoy  prpmspd unnoiric Ega"

    const-string v3, "Itamp.  uryruann tgocdopidip Elsar"

    const-string v3, ".dtp n iqrotdauIiudgocynaapEpl rr "

    const-string v3, "Error updating daily counts. appId"

    invoke-static/range {p3 .. p3}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v3, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v9, :cond_7

    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    :cond_7
    return-object v8

    :catchall_2
    move-exception v0

    :goto_1
    if-eqz v9, :cond_8

    invoke-interface {v9}, Landroid/database/Cursor;->close()V

    :cond_8
    throw v0
.end method

.method public final X(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/p;
    .locals 29
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    new-instance v0, Ljava/util/ArrayList;

    const-string v2, "f_sloeuotnitie"

    const-string/jumbo v2, "otm_oetfeluiin"

    const-string v2, "efom_incelimtu"

    const-string/jumbo v2, "lifetime_count"

    const-string v3, "buneo_rloctu_crutdnb"

    const-string/jumbo v3, "o_treblcuendrutu_bcn"

    const-string v3, "buurrbtcecldo_tnn_un"

    const-string v3, "current_bundle_count"

    const-string/jumbo v4, "stfs_mupaiileuetr_t"

    const-string/jumbo v4, "m__etturapsefstilmi"

    const-string v4, "_esslfmpptmetitaar_"

    const-string/jumbo v4, "last_fire_timestamp"

    const-string v5, "bamslpliqnttd__msdeeta"

    const-string v5, "edtapbtp_n_mlmsdltsaei"

    const-string/jumbo v5, "slsbpitmdtt_ae_neudmsl"

    const-string/jumbo v5, "last_bundled_timestamp"

    const-string v6, "_nlmd_ydudtlaabs"

    const-string/jumbo v6, "last_bundled_day"

    const-string v7, "_icsoxe_ol_pslmeqdtl_paadvnee"

    const-string/jumbo v7, "spmio_mdqla_vacepleenldstx__e"

    const-string v7, "dsseeb_ndmlal_cmpapeeoxvi_lt_"

    const-string/jumbo v7, "last_sampled_complex_event_id"

    const-string v8, "aaa_ipultltmerss_g"

    const-string/jumbo v8, "pasmas_tlatgielrs_"

    const-string/jumbo v8, "pln_tasp_tlsaegari"

    const-string/jumbo v8, "last_sampling_rate"

    const-string/jumbo v9, "sso_i_g_qlamptntfmmxmrpla"

    const-string/jumbo v9, "tsgmexproftalsmm_il__apnm"

    const-string v9, "_as_eenxlftmasmp_ilrtsgom"

    const-string/jumbo v9, "last_exempt_from_sampling"

    const-string/jumbo v10, "unomnnresrtuetsc__cos"

    const-string v10, "current_session_count"

    filled-new-array/range {v2 .. v10}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v3

    const/4 v11, 0x0

    new-array v4, v11, [Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    check-cast v5, [Ljava/lang/String;

    filled-new-array/range {p1 .. p2}, [Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v4, "tsevon"

    const-string/jumbo v4, "vtneos"

    const-string v4, "entvsb"

    const-string v4, "events"

    const-string v6, "=pb?a_upn ieddaa= n"

    const-string v6, "ap _abi dm=e=a?ndnp"

    const-string v6, "ia m= ep?n?d_n=apdp"

    const-string v6, "app_id=? and name=?"

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {v3}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v0, :cond_0

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    return-object v2

    :cond_0
    :try_start_2
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v15

    const/4 v0, 0x1

    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v17

    const/4 v4, 0x2

    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v21

    const/4 v4, 0x3

    invoke-interface {v3, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    if-eqz v5, :cond_1

    move-wide/from16 v23, v6

    goto :goto_0

    :cond_1
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    move-wide/from16 v23, v4

    :goto_0
    const/4 v4, 0x4

    invoke-interface {v3, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-eqz v5, :cond_2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    goto :goto_1

    :cond_2
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    move-object/from16 v25, v4

    move-object/from16 v25, v4

    move-object/from16 v25, v4

    move-object/from16 v25, v4

    :goto_1
    const/4 v4, 0x5

    invoke-interface {v3, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-eqz v5, :cond_3

    move-object/from16 v26, v2

    move-object/from16 v26, v2

    move-object/from16 v26, v2

    move-object/from16 v26, v2

    goto :goto_2

    :cond_3
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    move-object/from16 v26, v4

    move-object/from16 v26, v4

    move-object/from16 v26, v4

    move-object/from16 v26, v4

    :goto_2
    const/4 v4, 0x6

    invoke-interface {v3, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-eqz v5, :cond_4

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    goto :goto_3

    :cond_4
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    move-object/from16 v27, v4

    move-object/from16 v27, v4

    move-object/from16 v27, v4

    move-object/from16 v27, v4

    :goto_3
    const/4 v4, 0x7

    invoke-interface {v3, v4}, Landroid/database/Cursor;->isNull(I)Z

    move-result v5

    if-nez v5, :cond_6

    invoke-interface {v3, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    cmp-long v4, v4, v8

    if-nez v4, :cond_5

    move v11, v0

    move v11, v0

    move v11, v0

    move v11, v0

    :cond_5
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    move-object/from16 v28, v0

    move-object/from16 v28, v0

    move-object/from16 v28, v0

    move-object/from16 v28, v0

    goto :goto_4

    :cond_6
    move-object/from16 v28, v2

    move-object/from16 v28, v2

    move-object/from16 v28, v2

    move-object/from16 v28, v2

    :goto_4
    const/16 v0, 0x8

    invoke-interface {v3, v0}, Landroid/database/Cursor;->isNull(I)Z

    move-result v4

    if-eqz v4, :cond_7

    move-wide/from16 v19, v6

    goto :goto_5

    :cond_7
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v4

    move-wide/from16 v19, v4

    :goto_5
    new-instance v0, Lcom/google/android/gms/measurement/internal/p;

    move-object v12, v0

    move-object v12, v0

    move-object v12, v0

    move-object v12, v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    invoke-direct/range {v12 .. v28}, Lcom/google/android/gms/measurement/internal/p;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJJLjava/lang/Long;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Boolean;)V

    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    move-result v4

    if-eqz v4, :cond_8

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const-string v5, "dedu  etqmoxe agrre  tno,cpoepefeie glnpptlrae gt v.seGutrdsoI"

    const-string/jumbo v5, "xetIt ugnaev ,rtplmpof o eerpgsacGed  peere.gl idttarndeu eoso"

    const-string v5, "  stppurecpgglvam sdt rtiaeele oerxI cGasfdotoroeee.e gndetn, "

    const-string v5, "Got multiple records for event aggregates, expected one. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_8
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    return-object v0

    :catch_0
    move-exception v0

    goto :goto_6

    :catchall_0
    move-exception v0

    goto :goto_7

    :catch_1
    move-exception v0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_6
    :try_start_3
    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const-string/jumbo v5, "rEump optp srdnrg.nqvereaeI "

    const-string v5, "gtr rprpv nodrEe Ii.neauqspe"

    const-string v5, "Error querying events. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    iget-object v7, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v7

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/i3;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v5, v6, v7, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-eqz v3, :cond_9

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_9
    return-object v2

    :catchall_1
    move-exception v0

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_7
    if-eqz v2, :cond_a

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_a
    throw v0
.end method

.method public final Z(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/fa;
    .locals 14
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v2, 0x0

    :try_start_0
    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v3

    const/4 v0, 0x3

    new-array v5, v0, [Ljava/lang/String;

    const-string/jumbo v0, "tmspotsqitmea"

    const-string v0, "eipsetttqmsam"

    const-string v0, "aettsbeti_mps"

    const-string/jumbo v0, "set_timestamp"

    const/4 v11, 0x0

    aput-object v0, v5, v11

    const-string/jumbo v0, "luaue"

    const-string/jumbo v0, "value"

    const/4 v12, 0x1

    aput-object v0, v5, v12

    const-string/jumbo v0, "rpogni"

    const-string/jumbo v0, "nisrog"

    const-string/jumbo v0, "orqigi"

    const-string/jumbo v0, "origin"

    const/4 v13, 0x2

    aput-object v0, v5, v13

    filled-new-array/range {p1 .. p2}, [Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v4, "itsssetearmtuu_"

    const-string/jumbo v4, "uarmusttbsie_et"

    const-string/jumbo v4, "tiems_utrrbeuts"

    const-string/jumbo v4, "user_attributes"

    const-string/jumbo v6, "m? =oen=?pdaaipd_o "

    const-string v6, "ae ?opd=da n?_=mipn"

    const-string v6, "d_ =pbm e=nni?daaa?"

    const-string v6, "app_id=? and name=?"

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual/range {v3 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v3
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {v3}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v0, :cond_0

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    return-object v2

    :cond_0
    :try_start_2
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v8

    invoke-virtual {p0, v3, v12}, Lcom/google/android/gms/measurement/internal/j;->a0(Landroid/database/Cursor;I)Ljava/lang/Object;

    move-result-object v10
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-nez v10, :cond_1

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    return-object v2

    :cond_1
    :try_start_3
    invoke-interface {v3, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    new-instance v0, Lcom/google/android/gms/measurement/internal/fa;

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v5, p1

    move-object v5, p1

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    move-object/from16 v7, p2

    invoke-direct/range {v4 .. v10}, Lcom/google/android/gms/measurement/internal/fa;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/Object;)V

    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    move-result v4

    if-eqz v4, :cond_2

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const-string/jumbo v5, "rrrx,uuptob c  eoetsdpno rpdp  fluloepyosdGa.c trpmeiIer et"

    const-string/jumbo v5, "urstobf.relGoIitsp  ldrctypotapre pucpe,eeeo  mrrxn epdo d "

    const-string/jumbo v5, "iylpet pepdnteodprrsxrpr efG aI,e.co ceotp  trelopuemo sud "

    const-string v5, "Got multiple records for user property, expected one. appId"

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_3
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_2
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    return-object v0

    :catch_0
    move-exception v0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :catch_1
    move-exception v0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_0
    :try_start_4
    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const-string/jumbo v5, "iepua gtqnuqr esrEeudppy  .rrroyoIp"

    const-string/jumbo v5, "opurerups.prqyg  iIrEdoreeya ur ntp"

    const-string/jumbo v5, "p seurEerrn pgroory. asprI iedyurqt"

    const-string v5, "Error querying user property. appId"

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    iget-object v7, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v7

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v5, v6, v7, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    if-eqz v3, :cond_3

    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    :cond_3
    return-object v2

    :catchall_1
    move-exception v0

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_1
    if-eqz v2, :cond_4

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_4
    throw v0
.end method

.method final a0(Landroid/database/Cursor;I)Ljava/lang/Object;
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getType(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eq v0, v2, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v0, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eq v0, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eq v0, p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    const-string/jumbo p2, "ugim dnoLtl,n agvrnpa eoduekeoiayvdn tpl iniw "

    const-string p2, ",logLripwnlnivenund i oea anutedkdnvy tgp aio "

    const/4 v4, 0x1

    const-string p2, " ndaoaiii a,ovenLynidnwtneou pdik rnu gglvl eo"

    const-string p2, "Loaded invalid unknown value type, ignoring it"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, p2, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x6

    return-object v1

    :cond_0
    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo p2, "ti vqbn prn edialooLgbv lgbodda uinili,ya e"

    const-string/jumbo p2, "lin iebLqloia v og on, unediaayplid rdtgbev"

    const/4 v4, 0x2

    const-string p2, "blenaouLuneio eidvota  , rgvbnpaidl tldiiy "

    const-string p2, "Loaded invalid blob type value, ignoring it"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p1

    :cond_2
    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getDouble(I)D

    move-result-wide p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p1

    :cond_3
    const/4 v4, 0x4

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object p1

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string p2, "dassel pu oldirnmideaaonv  aeLufltabv l"

    const-string/jumbo p2, "vas eaeatnroadvolLnlesbul m uai fda ild"

    const/4 v4, 0x0

    const-string p2, "Loaded invalid null value from database"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v1
.end method

.method public final b0()Ljava/lang/String;
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v2, "e   a_boql dt rd mi crlims a ueeio1wsrsacepdd iera rqimyf,stmuoclehtpee"

    const-string v2, "durmiadsopciuoq rd  ctic _rayf  o eeiwlliss,st leeatmme m1b;pheedr  aer"

    const/4 v7, 0x5

    const-string/jumbo v2, "sase  trldrh ;eaisbq mmcoe wycao ui eeisacpe ltp,_medird  1l sutdfe_oir"

    const-string/jumbo v2, "select app_id from queue order by has_realtime desc, rowid asc limit 1;"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    move v7, v6

    const/4 v2, 0x0

    and-int/2addr v7, v2

    const/4 v6, 0x4

    move v7, v6

    invoke-interface {v0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-object v1

    :catch_0
    move-exception v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_1

    :catch_1
    move-exception v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v4, " tnmneopr  taleDbardopa tdtg aerebuniixse"

    const-string v4, "bpg otae ubdorneei rpan rnsiattge lDdaext"

    const/4 v7, 0x7

    const-string v4, "ed toDapi neeu bgtgstr naraoetxprand el i"

    const-string v4, "Database error getting next bundle app id"

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v3, v4, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object v1

    :catchall_1
    move-exception v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    throw v0
.end method

.method public final c0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/google/android/gms/measurement/internal/zzab;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v3, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "bda=?bpi"

    const-string v1, "?ai=pbdp"

    const/4 v3, 0x6

    const-string v1, "aipd_?up"

    const-string v1, "app_id=?"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string p2, "dran ogpn=iiu"

    const-string/jumbo p2, "oiadi=unnrg  "

    const/4 v3, 0x5

    const-string p2, "= r ?ngdqiona"

    const-string p2, " and origin=?"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p2, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p3, "*"

    const-string p3, "*"

    const/4 v3, 0x4

    const-string p3, "*"

    const-string p3, "*"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo p2, "oadbge p? nman l"

    const/4 v3, 0x5

    const-string p2, " as noa bgnedm l"

    const-string p2, " and name glob ?"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-array p2, p2, [Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast p2, [Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/measurement/internal/j;->d0(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method

.method public final d0(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;
    .locals 41
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/google/android/gms/measurement/internal/zzab;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v10, "1001"

    const-string v10, "0011"

    const-string v10, "1001"

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    const-string/jumbo v3, "osimne_cnpioterpordtqa"

    const-string/jumbo v3, "ptosiparq_eretnoiidnoc"

    const-string/jumbo v3, "idtoopetlcpronnisraio_"

    const-string v3, "conditional_properties"

    const/16 v4, 0xd

    new-array v4, v4, [Ljava/lang/String;

    const-string/jumbo v5, "p_psib"

    const-string/jumbo v5, "ipsap_"

    const-string/jumbo v5, "uadi_p"

    const-string v5, "app_id"

    const/4 v12, 0x0

    aput-object v5, v4, v12

    const-string/jumbo v5, "rpniig"

    const-string/jumbo v5, "nigmir"

    const-string/jumbo v5, "riqgoi"

    const-string/jumbo v5, "origin"

    const/4 v13, 0x1

    aput-object v5, v4, v13

    const-string/jumbo v5, "mean"

    const-string/jumbo v5, "nmea"

    const-string/jumbo v5, "name"

    const-string/jumbo v5, "name"

    const/4 v14, 0x2

    aput-object v5, v4, v14

    const-string v5, "evsoa"

    const-string v5, "aveuo"

    const-string v5, "euvma"

    const-string/jumbo v5, "value"

    const/4 v15, 0x3

    aput-object v5, v4, v15

    const-string v5, "cvitoe"

    const-string v5, "evtcib"

    const-string v5, "eicavb"

    const-string v5, "active"

    const/4 v9, 0x4

    aput-object v5, v4, v9

    const-string v5, "eeearruet_mgv_nngt"

    const-string/jumbo v5, "trigger_event_name"

    const/4 v8, 0x5

    aput-object v5, v4, v8

    const-string v5, "_giteteprtuuogr"

    const-string v5, "eri_gtuoturegit"

    const-string v5, "gteti_grqretium"

    const-string/jumbo v5, "trigger_timeout"

    const/4 v7, 0x6

    aput-object v5, v4, v7

    const-string/jumbo v5, "ousediemept_t_t"

    const-string v5, "euio_dep_ttmtev"

    const-string/jumbo v5, "timed_out_event"

    const/4 v6, 0x7

    aput-object v5, v4, v6

    const-string v5, "_mqmtmaatepntiisrc"

    const-string/jumbo v5, "tpatnseaqtrc_iimem"

    const-string/jumbo v5, "mnseomctaetor_atpi"

    const-string v5, "creation_timestamp"

    const/16 v11, 0x8

    aput-object v5, v4, v11

    const-string/jumbo v5, "iesgrre_vdegent"

    const-string/jumbo v5, "tirggb_eeentvrd"

    const-string/jumbo v5, "triggered_event"

    const/16 v11, 0x9

    aput-object v5, v4, v11

    const-string/jumbo v5, "tdeimpua_msegtergtr"

    const-string v5, "esem_ggamdpttmirter"

    const-string v5, "_tpgtrepaesdegrtimm"

    const-string/jumbo v5, "triggered_timestamp"

    const/16 v11, 0xa

    aput-object v5, v4, v11

    const-string/jumbo v5, "mtloiit_q_ev"

    const-string/jumbo v5, "te_lomi_tivo"

    const-string/jumbo v5, "ieseovlt__im"

    const-string/jumbo v5, "time_to_live"

    const/16 v11, 0xb

    aput-object v5, v4, v11

    const-string/jumbo v5, "itembxee_vrne"

    const-string v5, "_pnxrbevieete"

    const-string v5, "e_xeopdinvter"

    const-string v5, "expired_event"

    const/16 v11, 0xc

    aput-object v5, v4, v11

    const-string v21, "brwoi"

    const-string/jumbo v21, "rowid"

    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move-object/from16 v5, p1

    move v11, v6

    move v11, v6

    move v11, v6

    move v11, v6

    move-object/from16 v6, p2

    move-object/from16 v6, p2

    move-object/from16 v6, p2

    move v11, v7

    move v11, v7

    move v11, v7

    move v11, v7

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move v11, v8

    move v11, v8

    move v11, v8

    move v11, v8

    move-object/from16 v8, v23

    move-object/from16 v8, v23

    move-object/from16 v8, v23

    move-object/from16 v8, v23

    move v11, v9

    move v11, v9

    move v11, v9

    move v11, v9

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    move-object/from16 v9, v21

    invoke-virtual/range {v2 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3

    if-eqz v3, :cond_3

    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v4, 0x3e8

    if-lt v3, v4, :cond_0

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string/jumbo v5, "ixnsrguln nRraidedaealh icouo tat regrnoporhdpw,oe  aenm eo iltettxim"

    const-string/jumbo v5, "oremtouaetreirmhei orxegrepanadda,n   ghoiloRoiwtclntnxp neaaslti d  "

    const-string v5, "a le iopmai onogi d tRoaat erehmrra,xsonitxcttllgno  ehpeneadn iperwd"

    const-string v5, "Read more than the max allowed conditional properties, ignoring extra"

    iget-object v6, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v5, v4}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_2

    :cond_0
    invoke-interface {v2, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v2, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v2, v15}, Lcom/google/android/gms/measurement/internal/j;->a0(Landroid/database/Cursor;I)Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v2, v11}, Landroid/database/Cursor;->getInt(I)I

    move-result v4

    if-eqz v4, :cond_1

    move/from16 v23, v13

    move/from16 v23, v13

    move/from16 v23, v13

    move/from16 v23, v13

    goto :goto_1

    :cond_1
    move/from16 v23, v12

    move/from16 v23, v12

    move/from16 v23, v12

    move/from16 v23, v12

    :goto_1
    const/4 v9, 0x5

    invoke-interface {v2, v9}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v25

    const/4 v6, 0x6

    invoke-interface {v2, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v26

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v4

    const/4 v7, 0x7

    invoke-interface {v2, v7}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v6

    sget-object v7, Lcom/google/android/gms/measurement/internal/zzat;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {v4, v6, v7}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v4

    move-object/from16 v28, v4

    move-object/from16 v28, v4

    move-object/from16 v28, v4

    move-object/from16 v28, v4

    check-cast v28, Lcom/google/android/gms/measurement/internal/zzat;

    const/16 v6, 0x8

    invoke-interface {v2, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v29

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v4

    const/16 v11, 0x9

    invoke-interface {v2, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v6

    invoke-virtual {v4, v6, v7}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v4

    move-object/from16 v31, v4

    move-object/from16 v31, v4

    move-object/from16 v31, v4

    check-cast v31, Lcom/google/android/gms/measurement/internal/zzat;

    const/16 v6, 0xa

    invoke-interface {v2, v6}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v18

    const/16 v4, 0xb

    invoke-interface {v2, v4}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v32

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/ba;->f0()Lcom/google/android/gms/measurement/internal/da;

    move-result-object v4

    const/16 v11, 0xc

    invoke-interface {v2, v11}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v6

    invoke-virtual {v4, v6, v7}, Lcom/google/android/gms/measurement/internal/da;->A([BLandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v4

    move-object/from16 v34, v4

    move-object/from16 v34, v4

    move-object/from16 v34, v4

    move-object/from16 v34, v4

    check-cast v34, Lcom/google/android/gms/measurement/internal/zzat;

    new-instance v21, Lcom/google/android/gms/measurement/internal/zzkv;

    const/16 v35, 0xb

    move-object/from16 v4, v21

    move-object/from16 v4, v21

    move-object/from16 v4, v21

    move-object/from16 v4, v21

    const/16 v36, 0xa

    const/16 v37, 0x8

    const/16 v38, 0x7

    const/16 v39, 0x6

    move-wide/from16 v6, v18

    move/from16 v40, v9

    move/from16 v40, v9

    move/from16 v40, v9

    move/from16 v40, v9

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    invoke-direct/range {v4 .. v9}, Lcom/google/android/gms/measurement/internal/zzkv;-><init>(Ljava/lang/String;JLjava/lang/Object;Ljava/lang/String;)V

    new-instance v4, Lcom/google/android/gms/measurement/internal/zzab;

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v18, v10

    move-object/from16 v18, v10

    move-object/from16 v18, v10

    move-object/from16 v19, v21

    move-object/from16 v19, v21

    move-object/from16 v19, v21

    move-object/from16 v19, v21

    move-wide/from16 v20, v29

    move/from16 v22, v23

    move/from16 v22, v23

    move/from16 v22, v23

    move-object/from16 v23, v25

    move-object/from16 v23, v25

    move-object/from16 v23, v25

    move-object/from16 v23, v25

    move-object/from16 v24, v28

    move-object/from16 v24, v28

    move-object/from16 v24, v28

    move-wide/from16 v25, v26

    move-object/from16 v27, v31

    move-object/from16 v27, v31

    move-object/from16 v27, v31

    move-object/from16 v27, v31

    move-wide/from16 v28, v32

    move-object/from16 v30, v34

    move-object/from16 v30, v34

    move-object/from16 v30, v34

    move-object/from16 v30, v34

    invoke-direct/range {v16 .. v30}, Lcom/google/android/gms/measurement/internal/zzab;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/measurement/internal/zzkv;JZLjava/lang/String;Lcom/google/android/gms/measurement/internal/zzat;JLcom/google/android/gms/measurement/internal/zzat;JLcom/google/android/gms/measurement/internal/zzat;)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v3, :cond_2

    :goto_2
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    return-object v0

    :cond_2
    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_3
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    return-object v0

    :catchall_0
    move-exception v0

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    goto :goto_4

    :catch_0
    move-exception v0

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    goto :goto_3

    :catchall_1
    move-exception v0

    const/4 v11, 0x0

    goto :goto_4

    :catch_1
    move-exception v0

    const/4 v11, 0x0

    :goto_3
    :try_start_2
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v3, "e ar vdoqrtrryioelpnerpsnErer  giouanult opuiq"

    const-string v3, " i nlnrptyg rooeovnpyiqrpeuer otareaiusrlE udr"

    const-string/jumbo v3, "lrsureyoar neEo ounri ilyarir vrucppgqeedn tos"

    const-string v3, "Error querying conditional user property value"

    invoke-virtual {v2, v3, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    if-eqz v11, :cond_4

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_4
    return-object v0

    :catchall_2
    move-exception v0

    :goto_4
    if-eqz v11, :cond_5

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_5
    throw v0
.end method

.method public final e0(Ljava/lang/String;)Ljava/util/List;
    .locals 16
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/google/android/gms/measurement/internal/fa;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v10, "0001"

    const-string v10, "1000"

    const-string v10, "0010"

    const-string v10, "1000"

    const/4 v11, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    const-string/jumbo v3, "trumssar_eettbu"

    const-string v3, "btrt_resqtauesu"

    const-string/jumbo v3, "rtreoauss_uetti"

    const-string/jumbo v3, "user_attributes"

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/String;

    const-string/jumbo v5, "mane"

    const-string v5, "anme"

    const-string/jumbo v5, "nema"

    const-string/jumbo v5, "name"

    const/4 v12, 0x0

    aput-object v5, v4, v12

    const-string/jumbo v5, "oiginb"

    const-string/jumbo v5, "nisiog"

    const-string/jumbo v5, "uiigor"

    const-string/jumbo v5, "origin"

    const/4 v13, 0x1

    aput-object v5, v4, v13

    const-string/jumbo v5, "tseitetps_mmp"

    const-string/jumbo v5, "s_tmimsepmtte"

    const-string v5, "_eepmatiqstst"

    const-string/jumbo v5, "set_timestamp"

    const/4 v14, 0x2

    aput-object v5, v4, v14

    const-string v5, "eusao"

    const-string v5, "euvao"

    const-string/jumbo v5, "laume"

    const-string/jumbo v5, "value"

    const/4 v15, 0x3

    aput-object v5, v4, v15

    const-string v5, "da_?pbip"

    const-string v5, "?pdioap_"

    const-string v5, "app_id=?"

    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object v6

    const-string v9, "biuwr"

    const-string/jumbo v9, "wudir"

    const-string/jumbo v9, "rowid"

    iget-object v7, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v2 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v11

    invoke-interface {v11}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_3

    :cond_0
    invoke-interface {v11, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v11, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    :cond_1
    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    invoke-interface {v11, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v7

    invoke-virtual {v1, v11, v15}, Lcom/google/android/gms/measurement/internal/j;->a0(Landroid/database/Cursor;I)Ljava/lang/Object;

    move-result-object v9

    if-nez v9, :cond_2

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v3, "ppnnpespr yled diI .aoiatg lipdroeretu iuavnRav ig, "

    const-string/jumbo v3, "ppnnpespr yled diI .aoiatg lipdroeretu iuavnRav ig, "

    const-string v3, "grisroudIRvypao  .d  avei,lleniaptp   nuniprditregau"

    const-string v3, "Read invalid user property value, ignoring it. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    new-instance v2, Lcom/google/android/gms/measurement/internal/fa;

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    invoke-direct/range {v3 .. v9}, Lcom/google/android/gms/measurement/internal/fa;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/Object;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    invoke-interface {v11}, Landroid/database/Cursor;->moveToNext()Z

    move-result v2
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v2, :cond_0

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    return-object v0

    :cond_3
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    return-object v0

    :catchall_0
    move-exception v0

    goto :goto_1

    :catch_0
    move-exception v0

    :try_start_1
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v3, "sd.erirpr I rurt rpqunpoe eyasrEoiqge"

    const-string/jumbo v3, "rrrrpi uqpp un.tseioqsoeryeeg rr dIaE"

    const-string/jumbo v3, "rp.ni peqrIsEpdo  supir gurtrreaeqory"

    const-string v3, "Error querying user properties. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v3, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz v11, :cond_4

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_4
    return-object v0

    :goto_1
    if-eqz v11, :cond_5

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_5
    throw v0
.end method

.method public final f0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;
    .locals 19
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Lcom/google/android/gms/measurement/internal/fa;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v10, "0110"

    const-string v10, "1100"

    const-string v10, "0110"

    const-string v10, "1001"

    :try_start_0
    new-instance v2, Ljava/util/ArrayList;

    const/4 v12, 0x3

    invoke-direct {v2, v12}, Ljava/util/ArrayList;-><init>(I)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    :try_start_1
    invoke-interface {v2, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v4, "s_s?pdap"

    const-string v4, "d?spap_="

    const-string v4, "dpim=p_?"

    const-string v4, "app_id=?"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static/range {p2 .. p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_2
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v4, :cond_0

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    :try_start_2
    invoke-interface {v2, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v4, "r ?ioidan=mno"

    const-string v4, "dnomi=rinag? "

    const-string/jumbo v4, "in  gb=?rnaod"

    const-string v4, " and origin=?"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    :goto_0
    invoke-static/range {p3 .. p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_1

    invoke-static/range {p3 .. p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "*"

    const-string v5, "*"

    const-string v5, "*"

    const-string v5, "*"

    invoke-virtual {v4, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string/jumbo v4, "l ea?du o gnonab"

    const-string v4, "?gn o ademb lona"

    const-string v4, " nlo? npebg  dma"

    const-string v4, " and name glob ?"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v4

    new-array v4, v4, [Ljava/lang/String;

    invoke-interface {v2, v4}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    check-cast v6, [Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    const-string v4, "arsti_stqterueu"

    const-string/jumbo v4, "user_attributes"

    const/4 v5, 0x4

    new-array v5, v5, [Ljava/lang/String;

    const-string/jumbo v7, "mnea"

    const-string/jumbo v7, "maen"

    const-string v7, "amen"

    const-string/jumbo v7, "name"

    const/4 v15, 0x0

    aput-object v7, v5, v15

    const-string/jumbo v7, "ttssemembp_ia"

    const-string v7, "e_tmmbesiaspt"

    const-string v7, "_memtpmetitas"

    const-string/jumbo v7, "set_timestamp"

    const/4 v9, 0x1

    aput-object v7, v5, v9

    const-string v7, "euuvl"

    const-string v7, "elvuo"

    const-string/jumbo v7, "value"

    const/4 v8, 0x2

    aput-object v7, v5, v8

    const-string/jumbo v7, "ogrpib"

    const-string/jumbo v7, "oprigi"

    const-string/jumbo v7, "uirino"

    const-string/jumbo v7, "origin"

    aput-object v7, v5, v12

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v16, "qipwo"

    const-string/jumbo v16, "wriqo"

    const-string/jumbo v16, "iwdqo"

    const-string/jumbo v16, "rowid"

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object/from16 v7, v17

    move-object/from16 v7, v17

    move v11, v8

    move v11, v8

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move v12, v9

    move v12, v9

    move v12, v9

    move v12, v9

    move-object/from16 v9, v16

    move-object/from16 v9, v16

    move-object/from16 v9, v16

    move-object/from16 v9, v16

    invoke-virtual/range {v2 .. v10}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v3
    :try_end_3
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-nez v3, :cond_2

    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    return-object v0

    :cond_2
    :goto_1
    :try_start_4
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v4, 0x3e8

    if-lt v3, v4, :cond_3

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string/jumbo v5, "xsseasnogRncderse dp eiw r gsaepo lu iim hrnoet  oxsel,eehrmrta"

    const-string/jumbo v5, "risehia oeapex,cmtxoel erl en  tnsg Resughs rp  nirsmdtadorweeo"

    const-string/jumbo v5, "wismsanea eloir ihln utoprrahped ae  mtx stc sgooxerdgeerRn e,e"

    const-string v5, "Read more than the max allowed user properties, ignoring excess"

    iget-object v6, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v5, v4}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_3

    :cond_3
    invoke-interface {v2, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v2, v12}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v7

    invoke-virtual {v1, v2, v11}, Lcom/google/android/gms/measurement/internal/j;->a0(Landroid/database/Cursor;I)Ljava/lang/Object;

    move-result-object v9

    const/4 v10, 0x3

    invoke-interface {v2, v10}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v14

    if-nez v9, :cond_4

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string v4, " nomliRt  gigunvrr2ler(,a)ituov iipdydn easrp ae"

    const-string/jumbo v4, "uRtio rni rroe,)(vvnpilgr o ee t e2linsapayiudag"

    const-string v4, "(2)Read invalid user property value, ignoring it"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    invoke-virtual {v3, v4, v5, v14, v6}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_2

    :cond_4
    new-instance v5, Lcom/google/android/gms/measurement/internal/fa;

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v5, v14

    move-object v5, v14

    invoke-direct/range {v3 .. v9}, Lcom/google/android/gms/measurement/internal/fa;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/Object;)V

    invoke-interface {v0, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_2
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3
    :try_end_4
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-eqz v3, :cond_5

    goto/16 :goto_1

    :cond_5
    :goto_3
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    return-object v0

    :catchall_0
    move-exception v0

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    goto :goto_7

    :catch_0
    move-exception v0

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    goto :goto_6

    :catch_1
    move-exception v0

    goto :goto_5

    :catch_2
    move-exception v0

    goto :goto_4

    :catchall_1
    move-exception v0

    const/4 v11, 0x0

    goto :goto_7

    :catch_3
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    :goto_4
    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    move-object/from16 v14, p2

    :goto_5
    const/4 v11, 0x0

    :goto_6
    :try_start_5
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v3, "iuiuqb oe y opgeetrsroe)rrErr(n2p"

    const-string v3, "eypso2rngrpreuo t erir(q u)iEeror"

    const-string/jumbo v3, "tngrr2uu p p yieerEr(irorseouesr)"

    const-string v3, "(2)Error querying user properties"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v3, v4, v14, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    if-eqz v11, :cond_6

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_6
    return-object v0

    :catchall_2
    move-exception v0

    :goto_7
    if-eqz v11, :cond_7

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_7
    throw v0
.end method

.method public final g0()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public final h0(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, " iwrnd(pbi"

    const-string v1, " n(irbwid "

    const/4 v5, 0x1

    const-string v1, " dwio i(qn"

    const-string/jumbo v1, "rowid in ("

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ge v1, v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v2, ","

    const-string v2, ","

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast v2, Ljava/lang/Long;

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v5, 0x7

    const-string v1, ")"

    const-string v1, ")"

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v3, "vrstsweuan"

    const-string/jumbo v3, "srveeaunwt"

    const/4 v5, 0x6

    const-string/jumbo v3, "nwtmseeavr"

    const-string/jumbo v3, "raw_events"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1, v3, v0, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    if-eq v0, v1, :cond_2

    const/4 v4, 0x4

    move v5, v4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "wemfotsnfp c eedtep a  xta ewreabn rrlevosl eteroteheD"

    const-string v2, " ewnwe pe rnl  ftocoaaaedm xsvereet b peesetflthtrerdD"

    const/4 v5, 0x7

    const-string v2, "eeetfbwlndaorxeb lereedm h   ttn wwsvsteDrtceeao rfaep"

    const-string v2, "Deleted fewer rows from raw events table than expected"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void
.end method

.method public final i0()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method final j0(Ljava/util/List;)V
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->t(I)I

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->w()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v0, ","

    const-string v0, ","

    const/4 v6, 0x6

    const-string v0, ","

    const-string v0, ","

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, p1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-int/lit8 v0, v0, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v0, "("

    const-string v0, "("

    const/4 v6, 0x1

    const-string v0, "("

    const-string v0, "("

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string p1, ")"

    const-string p1, ")"

    const/4 v6, 0x6

    const-string p1, ")"

    const-string p1, ")"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x50

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "qrUeEEuRueTRu H1CIM  NdENFOE(T W oCw)iLS  "

    const-string v2, "SELECT COUNT(1) FROM queue WHERE rowid IN "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v2, "ty7I e4p21c7 o68L4 rMAN 34Tr  q_DIu=tn"

    const-string v2, "6 _4N1ArqeytILcD =38tI1  7 r44uT no7M2"

    const/4 v6, 0x2

    const-string v2, "I=tI3yL_q Nu7c1t oDr8T4A 62  4M4n  7re"

    const-string v2, " AND retry_count =  2147483647 LIMIT 1"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {p0, v1, v2}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    cmp-long v1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-lez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v2, "rdsuWacfatixoiue aemelb  sm lnthecelhim pu  hrrT.id.ntseedsrlie oen ng"

    const-string/jumbo v2, "unse.mhi o radnhlfgeuWnmliis  p l o rcebeeurdcteeTtsr.teaieax ihl dn m"

    const/4 v6, 0x7

    const-string/jumbo v2, "l imnrei fuoeeesaerinmTtlle hcl. .gahdi embed ai xtsuWerhoptmeu nrdc  "

    const-string v2, "The number of upload retries exceeds the limit. Will remain unchanged."

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_1
    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x7f

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v2, "rE0 onTc NHD=L(,T U1E  ueoUL+mreF_We StE_oirR tIP   ruIqtntEyNcAdeor  uw)"

    const-string v2, "etrmTt uur E  dnReSyErNcL(LIq=  eN1  +IPiUToFwcrDn uWot_ ) rEHe0,_ uAUoEt"

    const/4 v6, 0x2

    const-string v2, "Enu Eb tNtUyEt  eLireHo(o_qn  eD 1tTe)uI rF IuPNAS= uLE RTrrcyUo+ dw0cW,r"

    const-string v2, "UPDATE queue SET retry_count = IFNULL(retry_count, 0) + 1 WHERE rowid IN "

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v0, "ur _tUu rc<NLr_oeNAnct   R DoreLy(IOy Sn uo"

    const-string/jumbo v0, "rertoy_nSIrANruN    tUcRLo eO<L c_(uonD  yt"

    const/4 v6, 0x4

    const-string v0, " O cr  pn<trLu eSnNtoDtc  Re_(rLAoNU yIu_ry"

    const-string v0, " AND (retry_count IS NULL OR retry_count < "

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const v0, 0x7fffffff

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, p1}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo v1, "oinrrbe.rtcry tcn rnrgornr ioeur Emee"

    const/4 v6, 0x5

    const-string v1, " roeiromqrntEyr. nc rnirurerntgeero t"

    const-string v1, "Error incrementing retry count. error"

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method protected final l()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method final m()V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->w()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/ba;->d0()Lcom/google/android/gms/measurement/internal/x8;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/x8;->g:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/y3;->a()J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {v2}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    sub-long v0, v2, v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v6, 0x0

    shr-int/2addr v7, v6

    sget-object v4, Lcom/google/android/gms/measurement/internal/z2;->z:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    or-int/2addr v7, v6

    invoke-virtual {v4, v5}, Lcom/google/android/gms/measurement/internal/y2;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    check-cast v4, Ljava/lang/Long;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    cmp-long v0, v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-lez v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/ba;->d0()Lcom/google/android/gms/measurement/internal/x8;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/x8;->g:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;->b(J)V

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v6, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->w()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {v1}, Lcom/google/android/gms/common/util/g;->a()J

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v6, 0x2

    move v7, v6

    invoke-static {}, Lcom/google/android/gms/measurement/internal/f;->i()J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v2, "uuuee"

    const/4 v7, 0x4

    const-string v2, "eesqu"

    const-string/jumbo v2, "queue"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v3, "meem t_sg-i(>a pea de ?nlmdb_c)bt?sa(sintaru)npt e"

    const-string v3, " -ba>d ptt)tsi ea agpt?s_ane?bie(_ ns(mucr)l enmed"

    const/4 v7, 0x0

    const-string v3, " en)od(t_t tgaa)? lraep_(ne>?b-ubmc   esnssstiiemd"

    const-string v3, "abs(bundle_end_timestamp - ?) > cast(? as integer)"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v2, v3, v1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-lez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v2, "lre.ebldwweesetoeeta DtqlDrdsso"

    const-string/jumbo v2, "lDew eslqeoDaeerestoed tsrw.tld"

    const/4 v7, 0x3

    const-string/jumbo v2, "seeeDlute. swatewltdrsl rDeo oe"

    const-string v2, "Deleted stale rows. rowsDeleted"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void
.end method

.method public final n(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v2, "rs_tatiptsesebr"

    const-string/jumbo v2, "t_stetrebsrasui"

    const-string/jumbo v2, "ssurtrbtqte_uai"

    const-string/jumbo v2, "user_attributes"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v3, "=is=mnadpma d _ena?"

    const-string v3, "d?_maa = iaenm?=npd"

    const/4 v5, 0x5

    const-string v3, "anampiem=?dda?_p  n"

    const-string v3, "app_id=? and name=?"

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v3, v1}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v2, "trroolE dIerpapu .egyepodrire o nrt"

    const-string v2, "eurioe.dprElreoep nrot  tprgpy raId"

    const/4 v5, 0x3

    const-string v2, "e rprbrue i Epn eprddrpgoyttoaeIls."

    const-string v2, "Error deleting user property. appId"

    const/4 v4, 0x3

    or-int/2addr v5, v4

    invoke-virtual {v1, v2, p1, p2, v0}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method final o(Ljava/lang/String;Ljava/util/List;)V
    .locals 24
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/google/android/gms/internal/measurement/zzeh;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    const-string/jumbo v4, "na?iidupbde_anudad=c=_ei  "

    const-string v4, "dpi=pbdcna?__ad= iea endui"

    const-string v4, "a?aei=np_pdd c=dpde?ina ui"

    const-string v4, "app_id=? and audience_id=?"

    const-string/jumbo v0, "qa?pd=p_"

    const-string v0, "app_id=?"

    const-string/jumbo v5, "rvse_tfteeuln"

    const-string/jumbo v5, "leett_unfsevr"

    const-string v5, "ersmeevt_tlni"

    const-string v5, "event_filters"

    const-string v6, "epr_opirylreotpt"

    const-string/jumbo v6, "ltyeptoprisrp_re"

    const-string/jumbo v6, "rtf_ibpyrroestlp"

    const-string/jumbo v6, "property_filters"

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x0

    :goto_0
    invoke-interface/range {p2 .. p2}, Ljava/util/List;->size()I

    move-result v9

    if-ge v8, v9, :cond_8

    invoke-interface {v3, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/measurement/zzeh;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbv()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/measurement/zzeg;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/zzeg;->zza()I

    move-result v11

    if-eqz v11, :cond_5

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    const/4 v11, 0x0

    :goto_1
    invoke-virtual {v12}, Lcom/google/android/gms/internal/measurement/zzeg;->zza()I

    move-result v13

    if-ge v11, v13, :cond_4

    invoke-virtual {v12, v11}, Lcom/google/android/gms/internal/measurement/zzeg;->zze(I)Lcom/google/android/gms/internal/measurement/zzej;

    move-result-object v13

    invoke-virtual {v13}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbv()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v13

    check-cast v13, Lcom/google/android/gms/internal/measurement/zzei;

    invoke-virtual {v13}, Lcom/google/android/gms/internal/measurement/zzjt;->zzax()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v14

    check-cast v14, Lcom/google/android/gms/internal/measurement/zzei;

    invoke-virtual {v13}, Lcom/google/android/gms/internal/measurement/zzei;->zze()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/google/android/gms/measurement/internal/x5;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    if-eqz v15, :cond_0

    invoke-virtual {v14, v15}, Lcom/google/android/gms/internal/measurement/zzei;->zzb(Ljava/lang/String;)Lcom/google/android/gms/internal/measurement/zzei;

    const/4 v15, 0x1

    goto :goto_2

    :cond_0
    const/4 v15, 0x0

    :goto_2
    const/4 v10, 0x0

    :goto_3
    invoke-virtual {v13}, Lcom/google/android/gms/internal/measurement/zzei;->zza()I

    move-result v7

    if-ge v10, v7, :cond_2

    invoke-virtual {v13, v10}, Lcom/google/android/gms/internal/measurement/zzei;->zzd(I)Lcom/google/android/gms/internal/measurement/zzel;

    move-result-object v7

    move-object/from16 v16, v13

    move-object/from16 v16, v13

    move-object/from16 v16, v13

    move-object/from16 v16, v13

    invoke-virtual {v7}, Lcom/google/android/gms/internal/measurement/zzel;->zze()Ljava/lang/String;

    move-result-object v13

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    sget-object v4, Lcom/google/android/gms/measurement/internal/y5;->a:[Ljava/lang/String;

    sget-object v2, Lcom/google/android/gms/measurement/internal/y5;->b:[Ljava/lang/String;

    invoke-static {v13, v4, v2}, Lcom/google/android/gms/measurement/internal/n7;->b(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {v7}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbv()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v4

    check-cast v4, Lcom/google/android/gms/internal/measurement/zzek;

    invoke-virtual {v4, v2}, Lcom/google/android/gms/internal/measurement/zzek;->zza(Ljava/lang/String;)Lcom/google/android/gms/internal/measurement/zzek;

    invoke-virtual {v4}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/internal/measurement/zzel;

    invoke-virtual {v14, v10, v2}, Lcom/google/android/gms/internal/measurement/zzei;->zzc(ILcom/google/android/gms/internal/measurement/zzel;)Lcom/google/android/gms/internal/measurement/zzei;

    const/4 v15, 0x1

    :cond_1
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v13, v16

    move-object/from16 v13, v16

    move-object/from16 v13, v16

    move-object/from16 v13, v16

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    goto :goto_3

    :cond_2
    move-object/from16 v17, v4

    move-object/from16 v17, v4

    if-eqz v15, :cond_3

    invoke-virtual {v12, v11, v14}, Lcom/google/android/gms/internal/measurement/zzeg;->zzc(ILcom/google/android/gms/internal/measurement/zzei;)Lcom/google/android/gms/internal/measurement/zzeg;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/internal/measurement/zzeh;

    invoke-interface {v3, v8, v2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    :cond_3
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    goto/16 :goto_1

    :cond_4
    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    goto :goto_4

    :cond_5
    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    :goto_4
    invoke-virtual {v12}, Lcom/google/android/gms/internal/measurement/zzeg;->zzb()I

    move-result v2

    if-eqz v2, :cond_7

    const/4 v2, 0x0

    :goto_5
    invoke-virtual {v12}, Lcom/google/android/gms/internal/measurement/zzeg;->zzb()I

    move-result v4

    if-ge v2, v4, :cond_7

    invoke-virtual {v12, v2}, Lcom/google/android/gms/internal/measurement/zzeg;->zzf(I)Lcom/google/android/gms/internal/measurement/zzes;

    move-result-object v4

    invoke-virtual {v4}, Lcom/google/android/gms/internal/measurement/zzes;->zze()Ljava/lang/String;

    move-result-object v7

    sget-object v10, Lcom/google/android/gms/measurement/internal/z5;->a:[Ljava/lang/String;

    sget-object v11, Lcom/google/android/gms/measurement/internal/z5;->b:[Ljava/lang/String;

    invoke-static {v7, v10, v11}, Lcom/google/android/gms/measurement/internal/n7;->b(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_6

    invoke-virtual {v4}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbv()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v4

    check-cast v4, Lcom/google/android/gms/internal/measurement/zzer;

    invoke-virtual {v4, v7}, Lcom/google/android/gms/internal/measurement/zzer;->zza(Ljava/lang/String;)Lcom/google/android/gms/internal/measurement/zzer;

    invoke-virtual {v12, v2, v4}, Lcom/google/android/gms/internal/measurement/zzeg;->zzd(ILcom/google/android/gms/internal/measurement/zzer;)Lcom/google/android/gms/internal/measurement/zzeg;

    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaA()Lcom/google/android/gms/internal/measurement/zzjx;

    move-result-object v4

    check-cast v4, Lcom/google/android/gms/internal/measurement/zzeh;

    invoke-interface {v3, v8, v4}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move-object v12, v9

    move-object v12, v9

    move-object v12, v9

    :cond_6
    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_7
    add-int/lit8 v8, v8, 0x1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    goto/16 :goto_0

    :cond_8
    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v4

    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v6, v0, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v5, v0, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzeh;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zzk()Z

    move-result v9

    if-nez v9, :cond_9

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v7, "i nhqcuIDAp d aeniIteopu d"

    const-string v7, " d ndioaq hiAeDcn wuIIeppt"

    const-string v7, "ancuI DpoeApwtd p.  idIneh"

    const-string v7, "Audience with no ID. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v0, v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_6

    :cond_9
    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zza()I

    move-result v9

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zzg()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_a
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/google/android/gms/internal/measurement/zzej;

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzp()Z

    move-result v11

    if-nez v11, :cond_a

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v7, "enlunodtqpcInhid   v efwtnrgiIriduIe.dne enif. ct edoena, oEdiiepita iA"

    const-string v7, "Event filter with no ID. Audience definition ignored. appId, audienceId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v0, v7, v8, v9}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_6

    :cond_b
    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zzh()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_c
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_d

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/google/android/gms/internal/measurement/zzes;

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzes;->zzj()Z

    move-result v11

    if-nez v11, :cond_c

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v7, "ghsa  I.re .eAdneectfsPptIirdcdua ydnepiitn urwoilDIip doo tieoidnnnree i "

    const-string/jumbo v7, "oeswpd dPn nddDoIrf dii, etnau. ce e r iieghoydiptroni.eclpueAaitnIi rnteI"

    const-string v7, ".tfme.Ihiwedi i,rl coir oenA gp tIy ndpiueDntntfo cioieePeieIrd dpdrnaadn "

    const-string v7, "Property filter with no ID. Audience definition ignored. appId, audienceId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v0, v7, v8, v9}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_6

    :cond_d
    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zzg()Ljava/util/List;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_7
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v15, "dtaa"

    const-string v15, "data"

    const-string v15, "daat"

    const-string v15, "data"

    const-string/jumbo v7, "sneeoicossdsop"

    const-string/jumbo v7, "session_scoped"

    const-string/jumbo v12, "lrtmfb_di"

    const-string/jumbo v12, "riimfd_tl"

    const-string/jumbo v12, "irfeitud_"

    const-string v12, "filter_id"

    const-string/jumbo v13, "iduiedcpoen"

    const-string/jumbo v13, "iuneoeiddac"

    const-string v13, "edeidn_aqci"

    const-string v13, "audience_id"

    const-string v8, "apsp_i"

    const-string v8, "iapp_b"

    const-string v8, "ad_mip"

    const-string v8, "app_id"

    if-eqz v11, :cond_13

    :try_start_1
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/google/android/gms/internal/measurement/zzej;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static {v11}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzg()Ljava/lang/String;

    move-result-object v21

    invoke-static/range {v21 .. v21}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v21

    if-eqz v21, :cond_f

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v7, "aeetode nIai dae tlvntun,von umond. eldiA d,iIEecepi tefget iohdnn edfnrraeedi icuIfn.ip"

    const-string v7, "eeent udnn inv nilEicdhdAdiarf,dn  lIn aneeutan dmpdid,.  eputec.feoieefgearoe  tvIIiito"

    const-string/jumbo v7, "m,eedbotci odte iepariIfinupetcndeevInfrnidf oAedEntd  negr ueen.iia,nah iv altd. eld  I"

    const-string v7, "Event filter had no event name. Audience definition ignored. appId, audienceId, filterId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzp()Z

    move-result v12

    if-eqz v12, :cond_e

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzb()I

    move-result v11

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    goto :goto_8

    :cond_e
    const/16 v20, 0x0

    :goto_8
    invoke-static/range {v20 .. v20}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v7, v8, v10, v11}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    goto/16 :goto_f

    :cond_f
    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzih;->zzbs()[B

    move-result-object v14

    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    invoke-virtual {v3, v8, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v3, v13, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzp()Z

    move-result v8

    if-eqz v8, :cond_10

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzb()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    goto :goto_9

    :cond_10
    const/4 v8, 0x0

    :goto_9
    invoke-virtual {v3, v12, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string v8, "eenvntue_a"

    const-string v8, "event_name"

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzg()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v8, v12}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzq()Z

    move-result v8

    if-eqz v8, :cond_11

    invoke-virtual {v11}, Lcom/google/android/gms/internal/measurement/zzej;->zzn()Z

    move-result v8

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    goto :goto_a

    :cond_11
    const/4 v8, 0x0

    :goto_a
    invoke-virtual {v3, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {v3, v15, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v7

    const/4 v8, 0x5

    const/4 v11, 0x0

    invoke-virtual {v7, v5, v11, v3, v8}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v7

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    cmp-long v3, v7, v11

    if-nez v3, :cond_12

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string/jumbo v7, "ps  rFfptte( tlleneip dipv.I tnrteod eoa1-ia "

    const-string/jumbo v7, "o   goFpetp1aIrspitettdrla-n.t(eve deli f i n"

    const-string v7, " pvtr pFqr e e.netl oiof1adniseIi d)(el -tgat"

    const-string v7, "Failed to insert event filter (got -1). appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v3, v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_12
    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    goto/16 :goto_7

    :catch_0
    move-exception v0

    :try_start_3
    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string v7, "epsrgtlpro ari It.reof Eqvedsi nt"

    const-string/jumbo v7, "tEeritgrqasvr ptnoe ldipr rfoI.e "

    const-string/jumbo v7, "optmosr itrvrpearreitln.Ene g  Id"

    const-string v7, "Error storing event filter. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v3, v7, v8, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_f

    :cond_13
    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzeh;->zzh()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/google/android/gms/internal/measurement/zzes;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-static {v3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zze()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_15

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v7, "cItpoo mnaorri  dotednoiuofaptdaesideh if e.dPinenren,g eeunr il ry eyItlncap rep. rdApdetidIf"

    const-string v7, "  sPpr,Ip dden gl duimrrerirnud Any crid.fteaitaodaI.eoreepnnetpnoodefIpan tcf iletd heoieiy ,"

    const-string/jumbo v7, "ircIibanfdt, flraI dn,no m  pfiydnddd nryoeretupitder.p.a oueie  erenepedlcioetoPiphe ItA rgna"

    const-string v7, "Property filter had no property name. Audience definition ignored. appId, audienceId, filterId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zzj()Z

    move-result v11

    if-eqz v11, :cond_14

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zza()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_c

    :cond_14
    const/4 v3, 0x0

    :goto_c
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v7, v8, v10, v3}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_f

    :cond_15
    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzih;->zzbs()[B

    move-result-object v10

    new-instance v11, Landroid/content/ContentValues;

    invoke-direct {v11}, Landroid/content/ContentValues;-><init>()V

    invoke-virtual {v11, v8, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v11, v13, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zzj()Z

    move-result v14

    if-eqz v14, :cond_16

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zza()I

    move-result v14

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    goto :goto_d

    :cond_16
    const/4 v14, 0x0

    :goto_d
    invoke-virtual {v11, v12, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v14, "mn_raoueymrpe"

    const-string/jumbo v14, "perme_mraoynt"

    const-string/jumbo v14, "prnm_ypptoeea"

    const-string/jumbo v14, "property_name"

    move-object/from16 v23, v0

    move-object/from16 v23, v0

    move-object/from16 v23, v0

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zze()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zzk()Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-virtual {v3}, Lcom/google/android/gms/internal/measurement/zzes;->zzi()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    goto :goto_e

    :cond_17
    const/4 v0, 0x0

    :goto_e
    invoke-virtual {v11, v7, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {v11, v15, v10}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v10, 0x5

    invoke-virtual {v0, v6, v3, v11, v10}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v20

    const-wide/16 v18, -0x1

    const-wide/16 v18, -0x1

    const-wide/16 v18, -0x1

    const-wide/16 v18, -0x1

    cmp-long v0, v20, v18

    if-nez v0, :cond_18

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v3, "Id  orFi arl(pitope to pdg) l iyetpf.torera1s-en"

    const-string/jumbo v3, "pdnr( otqeierfr aa lI.e1Fsp yiedttooi tt- )plrp "

    const-string v3, "Failed to insert property filter (got -1). appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v0, v3, v7}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_4
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_f

    :cond_18
    move-object/from16 v0, v23

    move-object/from16 v0, v23

    move-object/from16 v0, v23

    move-object/from16 v0, v23

    goto/16 :goto_b

    :catch_1
    move-exception v0

    :try_start_5
    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string v7, ".rsIbrpropts aoindrpytl goerri rt pe"

    const-string/jumbo v7, "yrrp brd ofsor.iepltprrr taoeIi gptn"

    const-string v7, "Error storing property filter. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v3, v7, v8, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_f
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v3, 0x2

    new-array v7, v3, [Ljava/lang/String;

    const/4 v3, 0x0

    aput-object v4, v7, v3

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    aput-object v3, v7, v8

    move-object/from16 v3, v17

    move-object/from16 v3, v17

    invoke-virtual {v0, v6, v3, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/String;

    const/4 v8, 0x0

    aput-object v4, v7, v8

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x1

    aput-object v8, v7, v9

    invoke-virtual {v0, v5, v3, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    goto/16 :goto_6

    :cond_19
    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    move-object/from16 v4, v22

    goto/16 :goto_6

    :cond_1a
    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_10
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_1c

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/google/android/gms/internal/measurement/zzeh;

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/zzeh;->zzk()Z

    move-result v7

    if-eqz v7, :cond_1b

    invoke-virtual {v6}, Lcom/google/android/gms/internal/measurement/zzeh;->zza()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    goto :goto_11

    :cond_1b
    move-object v11, v3

    move-object v11, v3

    move-object v11, v3

    move-object v11, v3

    :goto_11
    invoke-interface {v0, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_10

    :cond_1c
    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v3
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "rc mts ir(t_?nuavfeeun=oao_ll)wcedeiuefpdsmrp1a  ecei_t hl"

    const-string/jumbo v6, "select count(1) from audience_filter_values where app_id=?"

    invoke-direct {v1, v6, v5}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v5
    :try_end_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_6 .. :try_end_6} :catch_2
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :try_start_7
    iget-object v7, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v7

    sget-object v8, Lcom/google/android/gms/measurement/internal/z2;->G:Lcom/google/android/gms/measurement/internal/y2;

    invoke-virtual {v7, v4, v8}, Lcom/google/android/gms/measurement/internal/f;->o(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)I

    move-result v7

    const/16 v8, 0x7d0

    invoke-static {v8, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/4 v8, 0x0

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    int-to-long v8, v7

    cmp-long v5, v5, v8

    if-gtz v5, :cond_1d

    goto/16 :goto_13

    :cond_1d
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    :goto_12
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v8

    if-ge v6, v8, :cond_1e

    invoke-interface {v0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    if-eqz v8, :cond_1f

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v5, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_12

    :cond_1e
    const-string v0, ","

    const-string v0, ","

    const-string v0, ","

    const-string v0, ","

    invoke-static {v0, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v6, 0x2

    add-int/2addr v5, v6

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v5}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v5, "("

    const-string v5, "("

    const-string v5, "("

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ")"

    const-string v0, ")"

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v5, "ialnoeafdulucere_vesui"

    const-string v5, "i_evrcuuundfleeleaisa_"

    const-string/jumbo v5, "ltedab_ciue_svaluefnie"

    const-string v5, "audience_filter_values"

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v6

    add-int/lit16 v6, v6, 0x8c

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v6}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v6, "etediwuane fnru(eie_sdii it?nimu  ieddacnnhad= cdauoeeu _n eip osilr_  iteaacinure_lepfvaeddc d__en c"

    const-string v6, "audience_id in (select audience_id from audience_filter_values where app_id=? and audience_id not in "

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " -ofi rplsei d ocmr)wrstfo teb?y 1 eid "

    const-string v0, " order by rowid desc limit -1 offset ?)"

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    new-array v0, v6, [Ljava/lang/String;

    const/4 v6, 0x0

    aput-object v4, v0, v6

    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    aput-object v4, v0, v6

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v5, v4, v0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    goto :goto_13

    :catch_2
    move-exception v0

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const-string/jumbo v5, "o eadistqparp ueerapqeIfn.rarDtirbys l"

    const-string v5, "Isiediep s.tfrare n upoeaprD ayqrtlrba"

    const-string v5, "Database error querying filters. appId"

    invoke-static/range {p1 .. p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v5, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_1f
    :goto_13
    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-void

    :catchall_0
    move-exception v0

    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw v0
.end method

.method public final p()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public final q(Lcom/google/android/gms/measurement/internal/e5;)V
    .locals 9
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v0, "apps"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->e0()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v2, Landroid/content/ContentValues;

    const/4 v8, 0x1

    invoke-direct {v2}, Landroid/content/ContentValues;-><init>()V

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    const-string v3, "dqsapp"

    const-string/jumbo v3, "paq_dp"

    const/4 v8, 0x2

    const-string/jumbo v3, "pp_mai"

    const-string v3, "app_id"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v2, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string/jumbo v3, "ni_ioatpsscdpne"

    const-string/jumbo v3, "pistcnpe_i_snda"

    const/4 v8, 0x6

    const-string v3, "epdanbc_sntiia_"

    const-string v3, "app_instance_id"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->f0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v3, "g_a_dpuipm"

    const-string v3, "gmp_app_id"

    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->k0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const-string v3, "icvsateplmteeasedrdehb__i"

    const-string/jumbo v3, "viemlesitcehea_es_rbadt_d"

    const/4 v8, 0x5

    const-string v3, "eliveitaqbh_a_crdedets_sh"

    const-string/jumbo v3, "resettable_device_id_hash"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->Z()J

    move-result-wide v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v4, "xlsudselntna__idb"

    const-string v4, "_dduolx_abtneslin"

    const/4 v8, 0x3

    const-string/jumbo v4, "xaem_dnntlsieldb_"

    const-string/jumbo v4, "last_bundle_index"

    const/4 v8, 0x5

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->a0()J

    move-result-wide v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo v4, "tasto_patdrmtutbsls_lna_emi"

    const-string v4, "_u_t_bmapltesettiastrmanlds"

    const/4 v8, 0x6

    const-string/jumbo v4, "lttstb_m__nasiadraptebtuesm"

    const-string/jumbo v4, "last_bundle_start_timestamp"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->Y()J

    move-result-wide v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo v4, "l_eatludntebspimuuta__emn"

    const-string/jumbo v4, "masautudbte_etlelpd_m_nni"

    const/4 v8, 0x5

    const-string/jumbo v4, "m_la_ndpmed_uplsitneettsa"

    const-string/jumbo v4, "last_bundle_end_timestamp"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v3, "s_vppraeqnp"

    const-string/jumbo v3, "rnppivap_se"

    const/4 v8, 0x2

    const-string/jumbo v3, "piso_senvap"

    const-string v3, "app_version"

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->h0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v3, "srematqo_"

    const-string v3, "eoat_sprq"

    const/4 v8, 0x4

    const-string v3, "_roaospet"

    const-string v3, "app_store"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->g0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->X()J

    move-result-wide v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v4, "ermnobs_isv"

    const-string v4, "_nsmsgvorie"

    const/4 v8, 0x4

    const-string/jumbo v4, "ro_neiupmvg"

    const-string v4, "gmp_version"

    const/4 v8, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->U()J

    move-result-wide v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v4, "ce_aehrp_dtmv"

    const-string v4, "_armtevhe_hdc"

    const-string v4, "_es_cartqhedv"

    const-string v4, "dev_cert_hash"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->K()Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v4, "lesodeams_etueanemn"

    const-string/jumbo v4, "luemod_ebmetnenaaes"

    const-string/jumbo v4, "nnems_letebmadreaeu"

    const-string/jumbo v4, "measurement_enabled"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->T()J

    move-result-wide v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string/jumbo v4, "yda"

    const-string v4, "day"

    const/4 v8, 0x0

    const-string v4, "dya"

    const-string v4, "day"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->R()J

    move-result-wide v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v4, "cbusodpivn_uyecito_lalteb"

    const-string v4, "aenpubcl__oecilyu_tvtsbdi"

    const/4 v8, 0x3

    const-string v4, "dcieub_tlloavsn__pbnuecyi"

    const-string v4, "daily_public_events_count"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->Q()J

    move-result-wide v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v4, "tuy_lvueodceinnau_"

    const-string/jumbo v4, "ilavcyu_esoetn_ndu"

    const/4 v8, 0x6

    const-string v4, "etu_n_ipeansodcvly"

    const-string v4, "daily_events_count"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->O()J

    move-result-wide v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v4, "uaocts__qnnoleiyodpscni"

    const-string/jumbo v4, "lennscopia_dso_cntoyuvi"

    const/4 v8, 0x6

    const-string v4, "daily_conversions_count"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->N()J

    move-result-wide v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v4, "ofs_cmeqt_ciheefdig"

    const-string v4, "hmo_et_cqtigcefdfei"

    const/4 v8, 0x3

    const-string v4, "eeimf_cfocgimntht_d"

    const-string v4, "config_fetched_time"

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->W()J

    move-result-wide v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v4, "acslef_cmtigtdeoeifh_ifn"

    const/4 v8, 0x5

    const-string v4, "fi_coiigoelen_teha_ctdff"

    const-string v4, "failed_config_fetch_time"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->M()J

    move-result-wide v3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v4, "iaposbn_v_rmtie"

    const-string v4, "epimint_s_porav"

    const-string/jumbo v4, "npsitvuio_ear_p"

    const-string v4, "app_version_int"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo v3, "iirnso_pbtei_adfsece"

    const-string v3, "etecor_sbfnsndiie_ai"

    const/4 v8, 0x0

    const-string v3, "fn_rs_saqdaiteibeenc"

    const-string v3, "firebase_instance_id"

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->i0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->P()J

    move-result-wide v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v4, "cesrdoie_srnueblnttva_r_"

    const-string/jumbo v4, "t_ncrbeudarnoo_sei_eltrv"

    const/4 v8, 0x5

    const-string/jumbo v4, "rltmrenevrdiy_noo_au_etc"

    const-string v4, "daily_error_events_count"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->S()J

    move-result-wide v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string/jumbo v4, "snecouyetaeatimd_uel_ovirtn"

    const-string v4, "ae_yevuitiaulcsneoer_n_dmtt"

    const/4 v8, 0x3

    const-string v4, "_vanmb_ti_estutdnrllayeeice"

    const-string v4, "daily_realtime_events_count"

    const/4 v8, 0x2

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v3, "_aasneipmhm_lhotlreto"

    const/4 v8, 0x6

    const-string/jumbo v3, "rniehluo_mtehtop_smal"

    const-string v3, "health_monitor_sample"

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->a()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->A()J

    move-result-wide v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v4, "dadnod_pqi"

    const-string v4, "do_iidnaqd"

    const/4 v8, 0x1

    const-string/jumbo v4, "ida_rddiqn"

    const-string v4, "android_id"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->J()Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v4, "_assbdtene_dipgeirraon"

    const-string/jumbo v4, "ngsbrtpdden_reoe_aadii"

    const/4 v8, 0x5

    const-string/jumbo v4, "rd_melddgarept_anoiine"

    const-string v4, "adid_reporting_enabled"

    const/4 v8, 0x1

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo v3, "pmmboa_aoid_"

    const-string/jumbo v3, "pibmaao_mdd_"

    const/4 v8, 0x6

    const-string v3, "admob_app_id"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->c0()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v2, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->V()J

    move-result-wide v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v4, "et_ioedyrmnnaisv"

    const/4 v8, 0x7

    const-string v4, "iaedrbyvnmneot_s"

    const-string v4, "dynamite_version"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->c()Ljava/util/List;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v3, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v4, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v4, " aies ueiptdatu ltetnIyetd msb osspo neda hlSe plfnv"

    const-string/jumbo v4, "teveeb apon dnu sdiifnaaeIbpSsyetdtmst o lsl  htl pe"

    const/4 v8, 0x6

    const-string/jumbo v4, "tnalp  pv i aoiItsnptfsdede.beatse ntel lmd po Sshue"

    const-string v4, "Safelisted events should not be an empty list. appId"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v3, v4, v1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v4, ","

    const-string v4, ","

    const/4 v8, 0x0

    invoke-static {v4, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string/jumbo v4, "safelisted_events"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzom;->zzc()Z

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget-object v4, Lcom/google/android/gms/measurement/internal/z2;->e0:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v3, v1, v4}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v3, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v3, "_upaidg_q"

    const-string/jumbo v3, "idgpaau__"

    const/4 v8, 0x6

    const-string v3, "_gspaaid_"

    const-string v3, "ga_app_id"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/e5;->j0()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v2, v3, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v4, " pampid?p_"

    const-string v4, "_ ipd=ppa?"

    const/4 v8, 0x4

    const-string v4, "a dpop_=i "

    const-string v4, "app_id = ?"

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1, v0, v2, v4, v3}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    int-to-long v3, v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    cmp-long v3, v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-nez v3, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v4, 0x5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p1, v0, v3, v2, v4}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v8, 0x0

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v7, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    cmp-long p1, v2, v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez p1, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const-string v0, "Failed to insert/update app (got -1). appId"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1, v0, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v2, "EoI.pbpor grp taandiprrs"

    const-string/jumbo v2, "rnrrrIgaq.p pEdiotpso pa"

    const/4 v8, 0x2

    const-string/jumbo v2, "rasptpupr.ga o op EIirrn"

    const-string v2, "Error storing app. appId"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v2, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v8, 0x7

    return-void
.end method

.method public final r(Lcom/google/android/gms/measurement/internal/p;)V
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x4

    move v6, v5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v0, Landroid/content/ContentValues;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p1, Lcom/google/android/gms/measurement/internal/p;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v2, "pp_ias"

    const-string/jumbo v2, "pas_pi"

    const/4 v6, 0x2

    const-string/jumbo v2, "pdqp_a"

    const-string v2, "app_id"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v1, "aenm"

    const-string v1, "eamn"

    const/4 v6, 0x3

    const-string v1, "amen"

    const-string/jumbo v1, "name"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/p;->b:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/p;->c:J

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, "fosunitleem_tm"

    const-string v2, "_limnmfeuttceo"

    const/4 v6, 0x7

    const-string/jumbo v2, "oetmlmui_ncife"

    const-string/jumbo v2, "lifetime_count"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v5, 0x1

    move v6, v5

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/p;->d:J

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x4

    const-string/jumbo v2, "oecnodbunrl_uoturcen"

    const-string/jumbo v2, "ruu_otndunntreoclbce"

    const-string v2, "_ucu_bctenntredobrlu"

    const-string v2, "current_bundle_count"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/p;->f:J

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "miprbeutmlttssaf_ei"

    const-string/jumbo v2, "iet_lbste_mrimspfta"

    const-string v2, "f_amtetpss_lrimpeit"

    const-string/jumbo v2, "last_fire_timestamp"

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/p;->g:J

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v2, "tiaupassqdemmllteb_t_n"

    const-string/jumbo v2, "last_bundled_timestamp"

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "saseduun__bdlyad"

    const-string v1, "d_ldenu_asdylbua"

    const-string/jumbo v1, "ul_mn_sdlayadtde"

    const-string/jumbo v1, "last_bundled_day"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/p;->h:Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x6

    const-string v1, "_lemoces_npld__pvlxdosttaeeim"

    const-string/jumbo v1, "last_sampled_complex_event_id"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/p;->i:Ljava/lang/Long;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v1, "era_pbapsltagnmist"

    const-string v1, "atlslirpasmpatn_eg"

    const/4 v6, 0x3

    const-string/jumbo v1, "rlsitsunp_eg_amtaa"

    const-string/jumbo v1, "last_sampling_rate"

    const/4 v6, 0x5

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/p;->j:Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x4

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/p;->e:J

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v2, "_ucrctnpetnre_uqososn"

    const-string/jumbo v2, "srniosrnqtuccunet_eo_"

    const/4 v6, 0x5

    const-string/jumbo v2, "snsouoe_qrcrtts_nunce"

    const-string v2, "current_session_count"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v5, 0x1

    move v6, v5

    iget-object v1, p1, Lcom/google/android/gms/measurement/internal/p;->k:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const-wide/16 v3, 0x1

    const/4 v6, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string/jumbo v3, "onsemm_aerfxittp_sa_lslpg"

    const-string v3, "gasisxlelpemtamn_mot_f_pr"

    const/4 v6, 0x4

    const-string v3, "fgtmsealamnel___xisommrtp"

    const-string/jumbo v3, "last_exempt_from_sampling"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const-string/jumbo v3, "mvesoe"

    const-string/jumbo v3, "teemsv"

    const/4 v6, 0x0

    const-string v3, "evensb"

    const-string v3, "events"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v4, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1, v3, v2, v0, v4}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v6, 0x6

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    cmp-long v0, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v1, "i   tdun( o.t e/rg-e eagpdsgaIvtgtnseupardoFi)teeap ltoe"

    const-string v1, "ggtto-ogetv eauaa napn(id) etreFeoi  ltdsteIep ga .dprs/"

    const/4 v6, 0x1

    const-string/jumbo v1, "peelaeaputa rean oadsttIppede1o es /Fn dig).rigv-g(gt tt"

    const-string v1, "Failed to insert/update event aggregates (got -1). appId"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/p;->a:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/p;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const-string v2, "atr gi tqebne gnapsogerdtaIgpoe.vrrr "

    const-string/jumbo v2, "nn ogb rsde pavi gat.teIgetrgparrsore"

    const/4 v6, 0x3

    const-string/jumbo v2, "nrsstpgirI .s n aeaergEdv oeorpatggre"

    const-string v2, "Error storing event aggregates. appId"

    const/4 v5, 0x0

    and-int/2addr v6, v5

    invoke-virtual {v1, v2, p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-void
.end method

.method public final s(Ljava/lang/String;[BLjava/lang/String;)V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/content/ContentValues;

    const/4 v3, 0x6

    or-int/2addr v4, v3

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v1, "remote_config"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo p2, "oatmn_isoidimcgm_tfiule_e"

    const-string/jumbo p2, "iflnaiu_m_gimooe_sdtfceti"

    const/4 v4, 0x7

    const-string/jumbo p2, "oftfol_at_msoeginddiicei_"

    const-string p2, "config_last_modified_time"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p2, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "paps"

    const-string/jumbo v1, "paps"

    const/4 v4, 0x4

    const-string/jumbo v1, "sppa"

    const-string v1, "apps"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "_p i bp?=d"

    const-string/jumbo v2, "p=ip ?_pd "

    const/4 v4, 0x4

    const-string/jumbo v2, "id_ a upp?"

    const-string v2, "app_id = ?"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2, v1, v0, v2, p3}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    int-to-long p2, p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    cmp-long p2, p2, v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string p3, "e oaItpp 0fp agooep )rmeo dtu actFndiigd.(qte"

    const-string p3, " l eea(dqddIp. a pncrgoi)pt0oeotf goiauFttme "

    const/4 v4, 0x6

    const-string p3, "en daopgqm).fetot( Iig ai eceodr p0a u doFltt"

    const-string p3, "Failed to update remote config (got 0). appId"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p2, p3, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception p2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, "dcsgf g noEooi .srriteeartnrps rIm"

    const-string/jumbo v0, "mrs gf.edo gItrc oitinrpr rEopnesa"

    const/4 v4, 0x2

    const-string v0, " ormpocndaeitrroI n s.erpg oEmtrgf"

    const-string v0, "Error storing remote config. appId"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p3, v0, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public final t()Z
    .locals 6

    const/4 v5, 0x1

    const-string/jumbo v0, "ut)mem a es0 >t(  _n1ctlrorefsowvne"

    const/4 v5, 0x1

    const-string v0, "elnro rnfc_so)tcus( vtamo ew>e 01t "

    const-string/jumbo v0, "select count(1) > 0 from raw_events"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v0
.end method

.method public final u()Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v0, "(1 rob l >ei)t u furrm0owatqemne h_th=e csaloee e1uce"

    const-string/jumbo v0, "tehroauee 1m1ofece(l_r m uswot l>ece)=  qasiernt0hu  "

    const/4 v5, 0x7

    const-string/jumbo v0, "lte whuceqe1reoum toee0>r un c1r =f)ehtm_(ua  ls a se"

    const-string/jumbo v0, "select count(1) > 0 from queue where has_realtime = 1"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v0
.end method

.method public final v()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v0, "select count(1) > 0 from raw_events where realtime = 1"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x4

    or-int/2addr v5, v4

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v0
.end method

.method protected final w()Z
    .locals 4
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "_ggdasnpe.toer_pobammeupe"

    const-string v1, "google_app_measurement.db"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0
.end method

.method public final x(Ljava/lang/String;Ljava/lang/Long;JLcom/google/android/gms/internal/measurement/zzfo;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p5}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p5}, Lcom/google/android/gms/internal/measurement/zzih;->zzbs()[B

    move-result-object p5

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Lcom/google/android/gms/measurement/internal/i3;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    array-length v2, p5

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v3, "eveiia  q nl,atpemc t gvpioSzm,ap sIndxdaea"

    const-string v3, "Saving complex main event, appId, data size"

    const/4 v5, 0x2

    invoke-virtual {v0, v3, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v0, Landroid/content/ContentValues;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const-string v1, "basdip"

    const-string v1, "aip_db"

    const/4 v5, 0x4

    const-string/jumbo v1, "papm_i"

    const-string v1, "app_id"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, "en_eotiu"

    const-string v1, "_eindtue"

    const/4 v5, 0x1

    const-string/jumbo v1, "ievenbd_"

    const-string v1, "event_id"

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string p2, "cohcnpurtrpeesodsil"

    const-string/jumbo p2, "rseicrepstlodphnco_"

    const/4 v5, 0x6

    const-string p2, "crrsih_ps_enlpoocde"

    const-string p2, "children_to_process"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p3, p4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, p2, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo p2, "neavtniqqe"

    const-string/jumbo p2, "vanie_tnqe"

    const/4 v5, 0x5

    const-string/jumbo p2, "nisenamtve"

    const-string/jumbo p2, "main_event"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, p2, p5}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 p2, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo p4, "ptemm_ansane_mvai"

    const-string/jumbo p4, "spsnntvi_amm_aeae"

    const/4 v5, 0x6

    const-string/jumbo p4, "m_taoav_nmsniarep"

    const-string/jumbo p4, "main_event_params"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 p5, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p3, p4, p5, v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide p3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    cmp-long p3, p3, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez p3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string p4, "atpdabiex nremet 1nv)n  plic- seiI(F .tmmoopatd ogl"

    const-string p4, "e emI  t ogirl tcalnt)eap mFp1otnsnx-( d iv.oedpima"

    const/4 v5, 0x2

    const-string/jumbo p4, "pte i uplse ae(tv.1toenmogxIrm  aondt pe  F)ai-licd"

    const-string p4, "Failed to insert complex main event (got -1). appId"

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p5

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p3, p4, p5}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    return p2

    :cond_0
    const/4 v5, 0x7

    const/4 p1, 0x6

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    return p1

    :catch_0
    move-exception p3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p4}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo p5, "nmacr tpppvxor Eierensep I.ngmrtoi ood "

    const-string/jumbo p5, "n rrogtame EdxorameoIt pin npc o.vsreip"

    const/4 v5, 0x6

    const-string p5, "El vgrrrqd.eic pip I enoaxtoneao srtmmn"

    const-string p5, "Error storing complex main event. appId"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p4, p5, p1, p3}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    return p2
.end method

.method public final y(Lcom/google/android/gms/measurement/internal/zzab;)Z
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/zzab;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/google/android/gms/measurement/internal/zzkv;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/j;->Z(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/fa;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v2, "p sadO) SdCnEitlTbM_po1RN_nsriEWLUt?(R HeFceOTEio  pEorip="

    const-string v2, "1rE_CbHELpF sdpE eTii?e(pSrWdnto_ ERM)piToanClNcR=t  OOUio"

    const/4 v6, 0x2

    const-string v2, "e  mOiEEnoiNadU?o=coC_)TEeR pnFiErH a1l(CdppRsrMTpSt i_OLt"

    const-string v2, "SELECT COUNT(1) FROM conditional_properties WHERE app_id=?"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0, v2, v1}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v1

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v6, 0x7

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x7

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    cmp-long v1, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-gez v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 p1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return p1

    :cond_1
    :goto_0
    const/4 v5, 0x3

    move v6, v5

    new-instance v1, Landroid/content/ContentValues;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v2, "pa_pou"

    const-string/jumbo v2, "upapi_"

    const-string/jumbo v2, "p_ipab"

    const-string v2, "app_id"

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const-string/jumbo v2, "uingro"

    const-string/jumbo v2, "origin"

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/zzab;->b:Ljava/lang/String;

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v6, 0x7

    iget-object v2, v2, Lcom/google/android/gms/measurement/internal/zzkv;->b:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v3, "neam"

    const-string/jumbo v3, "mena"

    const/4 v6, 0x1

    const-string v3, "aenm"

    const-string/jumbo v3, "name"

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/zzkv;->y2()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v3, "peplu"

    const-string v3, "evpul"

    const/4 v6, 0x7

    const-string/jumbo v3, "uelqv"

    const-string/jumbo v3, "value"

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {v1, v3, v2}, Lcom/google/android/gms/measurement/internal/j;->J(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-boolean v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->e:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "tcqeai"

    const/4 v6, 0x5

    const-string/jumbo v3, "tiseca"

    const-string v3, "active"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v6, 0x0

    const-string v2, "_es_annimevgterrtg"

    const/4 v6, 0x5

    const-string v2, "eetm_tnrnmvaegrie_"

    const-string/jumbo v2, "trigger_event_name"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/zzab;->f:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-wide v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->h:J

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v3, "gi_moeiteuotmrg"

    const-string/jumbo v3, "igmmetei_tougrt"

    const/4 v6, 0x4

    const-string/jumbo v3, "mug_ebtiretrgio"

    const-string/jumbo v3, "trigger_timeout"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/zzab;->g:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Lcom/google/android/gms/measurement/internal/ha;->c0(Landroid/os/Parcelable;)[B

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v3, "nteitouetuodm_e"

    const-string/jumbo v3, "t_eeodnmuieot_t"

    const/4 v6, 0x4

    const-string v3, "etm_etipv_eondu"

    const-string/jumbo v3, "timed_out_event"

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->d:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v3, "_aoemitpqmncebttsi"

    const-string v3, "eiisabepctrnomtmt_"

    const/4 v6, 0x1

    const-string v3, "_asspoeittrtmcemni"

    const-string v3, "creation_timestamp"

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/zzab;->i:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Lcom/google/android/gms/measurement/internal/ha;->c0(Landroid/os/Parcelable;)[B

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v3, "euem_gerdnitevg"

    const-string v3, "gdee_tunrreivge"

    const/4 v6, 0x1

    const-string/jumbo v3, "triggered_event"

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-wide v2, v2, Lcom/google/android/gms/measurement/internal/zzkv;->c:J

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v3, "tisdom_ptggertemrpa"

    const-string/jumbo v3, "mse_gttparimptgried"

    const/4 v6, 0x7

    const-string/jumbo v3, "tgiegbtepaemrdt_isr"

    const-string/jumbo v3, "triggered_timestamp"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-wide v2, p1, Lcom/google/android/gms/measurement/internal/zzab;->j:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v3, "i_iloemtqvet"

    const/4 v6, 0x7

    const-string v3, "_eomleuv_tit"

    const-string/jumbo v3, "time_to_live"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/zzab;->k:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Lcom/google/android/gms/measurement/internal/ha;->c0(Landroid/os/Parcelable;)[B

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "teipeerpvedn_"

    const-string v2, "expired_event"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v2, "iisdnotpqe_pnrsialcoer"

    const-string v2, "_tscirrooiadltnppsneei"

    const/4 v6, 0x6

    const-string/jumbo v2, "nlsdpiitptnsaoi_orcoee"

    const-string v2, "conditional_properties"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x0

    move v6, v3

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v4, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1, v2, v3, v1, v4}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x0

    const-wide/16 v3, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    cmp-long p1, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v1, "ir)moaieril utnp(  rnist m a tp oo/eygedtt-Fdoldcs1euepoar"

    const-string v1, "a)im i/oet  gt ct1-opeeo l ddosarautpsne(Fiipedtryl rrtnou"

    const/4 v6, 0x6

    const-string v1, "aui1oiyr)pl  /r ratg t-Fdrsteentdpeoes o(c tniitolpnodo ua"

    const-string v1, "Failed to insert/update conditional user property (got -1)"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "p  oournapliidtesrrEtsgteorrcryino n or"

    const/4 v6, 0x5

    const-string/jumbo v2, "roosibcroEspntoiryrd iete o unrtrp nlga"

    const-string v2, "Error storing conditional user property"

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_2
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 p1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return p1
.end method

.method public final z(Lcom/google/android/gms/measurement/internal/fa;)Z
    .locals 10
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v1, p1, Lcom/google/android/gms/measurement/internal/fa;->c:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/j;->Z(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/fa;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-nez v0, :cond_2

    const/4 v9, 0x4

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/fa;->c:Ljava/lang/String;

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/ha;->W(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v0, :cond_1

    const/4 v9, 0x4

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v2, "pnedltuue tts _!bur t ac!/%n ar sam/(1laeehm //k?_panro c)piu oenebt/_t wr f d//c/iseeoise"

    const-string v2, "  ws boeepb_ u mmttn eiprlns) klrtip/ht!or1_afcocdueee%u /// !aecdrse t/n?a(ean_st/ a /ei/"

    const/4 v9, 0x5

    const-string/jumbo v2, "spar_weperknor tcotiru_eeame1)mp/eunet=?_/aaoee s! dp //silct  /u%h(  i!/n  ts/ lt/ dacfeb"

    const-string/jumbo v2, "select count(1) from user_attributes where app_id=? and name not like \'!_%\' escape \'!\'"

    const/4 v9, 0x5

    invoke-direct {p0, v2, v0}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v4, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x6

    sget-object v5, Lcom/google/android/gms/measurement/internal/z2;->H:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/16 v6, 0x19

    const/4 v9, 0x0

    const/16 v7, 0x64

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0, v4, v5, v6, v7}, Lcom/google/android/gms/measurement/internal/f;->p(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;II)I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    int-to-long v4, v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    cmp-long v0, v2, v4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-gez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    return v1

    :cond_1
    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v0, "p_na"

    const-string/jumbo v0, "pna_"

    const/4 v9, 0x4

    const-string/jumbo v0, "n_pa"

    const-string v0, "_npa"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->c:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-nez v0, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->b:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string/jumbo v2, "ns/ periqi c/dtek_?leu) /etoe_ rn/aed fscc_lAp tpg=e(n!m iNtses%hi/a ar=!twbarouD/i / 1/r eeo ?unmu"

    const-string/jumbo v2, "rw(/l_uNes%eo/  t nicn A at_= c!e fue=d/a lpistg /upesie/c/teai)ednpsearok ?b r tue_ rmDir/o/m!1n?h"

    const/4 v9, 0x0

    const-string v2, "  sobrcr ekNrie/mei/pd)arae!e/1o(ttlettse=// _cc_agenr s n? aiee l/f!ssDu/_npd =Aatui /  whnmp%?i o"

    const-string/jumbo v2, "select count(1) from user_attributes where app_id=? and origin=? AND name like \'!_%\' escape \'!\'"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {p0, v2, v0}, Lcom/google/android/gms/measurement/internal/j;->L(Ljava/lang/String;[Ljava/lang/String;)J

    move-result-wide v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v9, 0x7

    const-wide/16 v4, 0x19

    const-wide/16 v4, 0x19

    const/4 v9, 0x5

    const-wide/16 v4, 0x19

    const-wide/16 v4, 0x19

    const/4 v9, 0x1

    cmp-long v0, v2, v4

    const/4 v9, 0x0

    const/4 v8, 0x6

    if-ltz v0, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    return v1

    :cond_2
    :goto_0
    const/4 v8, 0x1

    move v9, v8

    new-instance v0, Landroid/content/ContentValues;

    const/4 v9, 0x2

    const/4 v8, 0x1

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string v1, "dpimp_"

    const-string/jumbo v1, "ipapd_"

    const/4 v9, 0x6

    const-string/jumbo v1, "p_pdoa"

    const-string v1, "app_id"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v1, "irqoin"

    const/4 v9, 0x3

    const-string/jumbo v1, "iognrb"

    const-string/jumbo v1, "origin"

    const/4 v9, 0x4

    const/4 v8, 0x4

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->b:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string/jumbo v1, "nmae"

    const-string/jumbo v1, "maen"

    const-string v1, "enam"

    const-string/jumbo v1, "name"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->c:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-wide v1, p1, Lcom/google/android/gms/measurement/internal/fa;->d:J

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v2, "m_etimuesastt"

    const-string/jumbo v2, "testmims_stea"

    const/4 v9, 0x6

    const-string/jumbo v2, "set_timestamp"

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v9, 0x0

    const-string v1, "ampvl"

    const-string v1, "elvma"

    const/4 v9, 0x2

    const-string v1, "aulqe"

    const-string/jumbo v1, "value"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->e:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/j;->J(Landroid/content/ContentValues;Ljava/lang/String;Ljava/lang/Object;)V

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/j;->R()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v2, "essbaoetsuui_tr"

    const-string/jumbo v2, "srttotiueuebsa_"

    const/4 v9, 0x3

    const-string v2, "_esmrasruiutett"

    const-string/jumbo v2, "user_attributes"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x5

    const/4 v4, 0x2

    const/4 v9, 0x0

    const/4 v4, 0x5

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v1, v2, v3, v0, v4}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    move-result-wide v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-wide/16 v2, -0x1

    const/4 v9, 0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    cmp-long v0, v0, v2

    if-nez v0, :cond_3

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string v1, "(ps opslt abrIaioneu /Fgop)-dd.iad1rpeetru tet et  or"

    const-string v1, ")tel-ba /a attpodudI (ieidpts p 1srunepror gepet. For"

    const/4 v9, 0x7

    const-string/jumbo v1, "raiieb-ge dp.p)etudFasttd1Isop u reerl  r/ p(tot yopn"

    const-string v1, "Failed to insert/update user property (got -1). appId"

    const/4 v9, 0x6

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v9, 0x6

    invoke-static {v2}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/fa;->a:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const-string/jumbo v2, "r snrdupoi r  Io.strrrEpgytaueoppu"

    const-string/jumbo v2, "pdgosrutyer o upe.  ropaEtrnIprrsi"

    const/4 v9, 0x7

    const-string/jumbo v2, "ipupgtoptrered r Ernppy a.rsIrro o"

    const-string v2, "Error storing user property. appId"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v1, v2, p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_3
    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 p1, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    return p1
.end method
