.class final Lcom/google/android/gms/measurement/internal/d4;
.super Lcom/google/android/gms/measurement/internal/u5;


# static fields
.field static final x:Landroid/util/Pair;
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private c:Landroid/content/SharedPreferences;

.field public d:Lcom/google/android/gms/measurement/internal/a4;

.field public final e:Lcom/google/android/gms/measurement/internal/y3;

.field public final f:Lcom/google/android/gms/measurement/internal/y3;

.field public final g:Lcom/google/android/gms/measurement/internal/b4;

.field private h:Ljava/lang/String;

.field private i:Z

.field private j:J

.field public final k:Lcom/google/android/gms/measurement/internal/y3;

.field public final l:Lcom/google/android/gms/measurement/internal/w3;

.field public final m:Lcom/google/android/gms/measurement/internal/b4;

.field public final n:Lcom/google/android/gms/measurement/internal/w3;

.field public final o:Lcom/google/android/gms/measurement/internal/y3;

.field public p:Z

.field public final q:Lcom/google/android/gms/measurement/internal/w3;

.field public final r:Lcom/google/android/gms/measurement/internal/w3;

.field public final s:Lcom/google/android/gms/measurement/internal/y3;

.field public final t:Lcom/google/android/gms/measurement/internal/b4;

.field public final u:Lcom/google/android/gms/measurement/internal/b4;

.field public final v:Lcom/google/android/gms/measurement/internal/y3;

.field public final w:Lcom/google/android/gms/measurement/internal/x3;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Landroid/util/Pair;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v2, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x6

    sput-object v0, Lcom/google/android/gms/measurement/internal/d4;->x:Landroid/util/Pair;

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    return-void
.end method

.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/u5;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x1

    or-int/2addr v6, v5

    const-string v0, "esssiiossen_tuo"

    const-string/jumbo v0, "sissmsueetoio_n"

    const/4 v6, 0x0

    const-string v0, "ee_mosnotmiisut"

    const-string/jumbo v0, "session_timeout"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-wide/32 v1, 0x1b7740

    const/4 v6, 0x4

    const-wide/32 v1, 0x1b7740

    const-wide/32 v1, 0x1b7740

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->k:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x4

    new-instance p1, Lcom/google/android/gms/measurement/internal/w3;

    const-string/jumbo v0, "sesiom__ronestwna"

    const-string/jumbo v0, "sstmin_eoersa_swn"

    const/4 v6, 0x1

    const-string/jumbo v0, "start_new_session"

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {p1, p0, v0, v1}, Lcom/google/android/gms/measurement/internal/w3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->l:Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x6

    const/4 v5, 0x5

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v0, "spuiebat__moael"

    const-string/jumbo v0, "pumtoe__leasais"

    const/4 v6, 0x6

    const-string/jumbo v0, "sietuautase__pl"

    const-string/jumbo v0, "last_pause_time"

    const/4 v6, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->o:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance p1, Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v0, "onassbdndlozrnieepa_"

    const/4 v6, 0x2

    const-string/jumbo v0, "nn_eznlpdrasop_aesod"

    const-string/jumbo v0, "non_personalized_ads"

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x2

    move v5, v3

    move v5, v3

    invoke-direct {p1, p0, v0, v3}, Lcom/google/android/gms/measurement/internal/b4;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->m:Lcom/google/android/gms/measurement/internal/b4;

    const/4 v5, 0x2

    move v6, v5

    new-instance p1, Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string v0, "dtoelmyiqawumlrn_oee_"

    const-string/jumbo v0, "r_otiyuadnemelmaoe_wl"

    const/4 v6, 0x3

    const-string/jumbo v0, "tmsmdenyoallreo_witae"

    const-string v0, "allow_remote_dynamite"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    invoke-direct {p1, p0, v0, v4}, Lcom/google/android/gms/measurement/internal/w3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Z)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->n:Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v0, "sftm_eopempi_rn"

    const-string/jumbo v0, "noprimepts_fi_e"

    const-string v0, "fsn_opeteiitmor"

    const-string v0, "first_open_time"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->e:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v0, "aliplbnqta_m_ist"

    const-string/jumbo v0, "ltmsea_lq_iatipn"

    const-string v0, "_tnapiupleis_ltm"

    const-string v0, "app_install_time"

    const/4 v6, 0x0

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->f:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v0, "pcipianpse_s_da"

    const-string v0, "desnp_caipits_a"

    const/4 v6, 0x1

    const-string v0, "aistaecpqpnnd_i"

    const-string v0, "app_instance_id"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {p1, p0, v0, v3}, Lcom/google/android/gms/measurement/internal/b4;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->g:Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance p1, Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v0, "rgsbumdaecpanpod"

    const-string v0, "acpmaengrdkpubod"

    const/4 v6, 0x3

    const-string v0, "_pkmnacrddobapeg"

    const-string v0, "app_backgrounded"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {p1, p0, v0, v4}, Lcom/google/android/gms/measurement/internal/w3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Z)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->q:Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance p1, Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v0, "imeeopleoetell_kedcti_ovr_rn"

    const-string/jumbo v0, "iedeonole_rcepletlim__vtrkpe"

    const-string/jumbo v0, "lelkebeoepetl_cdpevtm__irnra"

    const-string v0, "deep_link_retrieval_complete"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p1, p0, v0, v4}, Lcom/google/android/gms/measurement/internal/w3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Z)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->r:Lcom/google/android/gms/measurement/internal/w3;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string/jumbo v0, "nr_tebipkasd_evaeeirmtptlet_"

    const/4 v6, 0x2

    const-string/jumbo v0, "printtuli__re_sapteedltekmve"

    const-string v0, "deep_link_retrieval_attempts"

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->s:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x7

    const/4 v5, 0x7

    new-instance p1, Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x1

    const-string v0, "foe_ettproiefulureuaalb_r"

    const-string/jumbo v0, "r_l_ueuteriftfsraeoelouab"

    const/4 v6, 0x1

    const-string/jumbo v0, "loiteefuqesfaarb__etuorrs"

    const-string v0, "firebase_feature_rollouts"

    const/4 v6, 0x3

    invoke-direct {p1, p0, v0, v3}, Lcom/google/android/gms/measurement/internal/b4;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->t:Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance p1, Lcom/google/android/gms/measurement/internal/b4;

    const/4 v5, 0x4

    move v6, v5

    const-string/jumbo v0, "nusieefcctr_dtebat_hepriar"

    const-string v0, "dtbaeccprirt_rn_uedefaiteh"

    const-string v0, "fdumrebc_ieradcreethnta_it"

    const-string v0, "deferred_attribution_cache"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {p1, p0, v0, v3}, Lcom/google/android/gms/measurement/internal/b4;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->u:Lcom/google/android/gms/measurement/internal/b4;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v0, "anqcoeiaotmremtefi_dputdcre_est_btha"

    const-string v0, "caertteeqrtam_iepbrhd_niufetd_ctmaso"

    const/4 v6, 0x6

    const-string/jumbo v0, "ior_tbnrti_madctaheeupeefteatmbc_dri"

    const-string v0, "deferred_attribution_cache_timestamp"

    const/4 v5, 0x5

    move v6, v5

    invoke-direct {p1, p0, v0, v1, v2}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->v:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/x3;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string/jumbo v0, "use_rpudreemfav_etttelsa"

    const-string v0, "easrtt_evmlfe_npseudrate"

    const-string/jumbo v0, "s_tetn_pdpertmfaeeeraavu"

    const-string v0, "default_event_parameters"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p1, p0, v0, v3}, Lcom/google/android/gms/measurement/internal/x3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/d4;->w:Lcom/google/android/gms/measurement/internal/x3;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void
.end method


# virtual methods
.method protected final i()V
    .locals 11
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Lq9/d$a;
        value = {
            .subannotation Lq9/d;
                value = {
                    "this.preferences"
                }
            .end subannotation,
            .subannotation Lq9/d;
                value = {
                    "this.monitoringSample"
                }
            .end subannotation
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const-string/jumbo v1, "odom.dc.qrmsumleensstrgngemam.iaefgp.eo."

    const-string v1, ".nomeeggdd..mnoarecmsmpoe.uagesiflmr.tso"

    const/4 v10, 0x3

    const-string v1, "com.google.android.gms.measurement.prefs"

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->c:Landroid/content/SharedPreferences;

    const/4 v10, 0x3

    const-string/jumbo v1, "nasse_o_eoneheb"

    const-string v1, "aonnoh_eb_seeep"

    const/4 v10, 0x3

    const-string/jumbo v1, "paemne_heonbesd"

    const-string v1, "has_been_opened"

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    iput-boolean v0, p0, Lcom/google/android/gms/measurement/internal/d4;->p:Z

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-nez v0, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->c:Landroid/content/SharedPreferences;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    const/4 v2, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance v0, Lcom/google/android/gms/measurement/internal/a4;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v9, 0x7

    move v10, v9

    const-string/jumbo v5, "onbho_ltamrhto"

    const-string/jumbo v5, "tonhtbeo_ahmrl"

    const/4 v10, 0x3

    const-string/jumbo v5, "nloetbm_rthahi"

    const-string v5, "health_monitor"

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    sget-object v1, Lcom/google/android/gms/measurement/internal/z2;->d:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/measurement/internal/y2;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    check-cast v1, Ljava/lang/Long;

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v6

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v8, 0x0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-direct/range {v3 .. v8}, Lcom/google/android/gms/measurement/internal/a4;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;JLcom/google/android/gms/measurement/internal/z3;)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->d:Lcom/google/android/gms/measurement/internal/a4;

    const/4 v10, 0x4

    const/4 v9, 0x1

    return-void
.end method

.method protected final j()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method protected final o()Landroid/content/SharedPreferences;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->c:Landroid/content/SharedPreferences;

    const/4 v1, 0x3

    move v2, v1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->c:Landroid/content/SharedPreferences;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method final p(Ljava/lang/String;)Landroid/util/Pair;
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {v1}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/d4;->h:Ljava/lang/String;

    const/4 v7, 0x5

    if-eqz v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-wide v4, p0, Lcom/google/android/gms/measurement/internal/d4;->j:J

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    cmp-long v4, v1, v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ltz v4, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance p1, Landroid/util/Pair;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/d4;->i:Z

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {p1, v3, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-object p1

    :cond_1
    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x4

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x4

    sget-object v4, Lcom/google/android/gms/measurement/internal/z2;->c:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, p1, v4}, Lcom/google/android/gms/measurement/internal/f;->r(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)J

    move-result-wide v3

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-long/2addr v1, v3

    const/4 v7, 0x7

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/d4;->j:J

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 p1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->c(Z)V

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->getAdvertisingIdInfo(Landroid/content/Context;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->h:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->getId()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/d4;->h:Ljava/lang/String;

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->isLimitAdTrackingEnabled()Z

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-boolean p1, p0, Lcom/google/android/gms/measurement/internal/d4;->i:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->q()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v2, " vinteueaU tbreguldtig dains"

    const-string v2, "en etgubiUdng laeidaot visrt"

    const/4 v7, 0x7

    const-string v2, "eogisreptdding i ntl  taevUa"

    const-string v2, "Unable to get advertising id"

    const/4 v7, 0x1

    invoke-virtual {v1, v2, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->h:Ljava/lang/String;

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 p1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->c(Z)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance p1, Landroid/util/Pair;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->h:Ljava/lang/String;

    const/4 v7, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/measurement/internal/d4;->i:Z

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p1, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object p1
.end method

.method final q()Lcom/google/android/gms/measurement/internal/g;
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "nsettcgnq_sisnpo"

    const-string/jumbo v1, "nc_tsttpnesgsion"

    const/4 v4, 0x0

    const-string/jumbo v1, "ntststngosceies_"

    const-string v1, "consent_settings"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "1G"

    const-string v2, "G1"

    const/4 v4, 0x5

    const-string v2, "G1"

    const-string v2, "G1"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/g;->b(Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/g;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method final r()Ljava/lang/Boolean;
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "nemmemeeaqsednltubr"

    const-string v1, "eeeamnnmqbtresudeal"

    const/4 v4, 0x1

    const-string/jumbo v1, "menuotesbaemleren_d"

    const-string/jumbo v1, "measurement_enabled"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x1

    move v3, v0

    move v3, v0

    const/4 v4, 0x2

    return-object v0
.end method

.method final s(Ljava/lang/Boolean;)V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "esednbat_elnuambmse"

    const-string v1, "eesanemlsn_edebtuam"

    const/4 v3, 0x4

    const-string v1, "_eeesnulaanetedrmbm"

    const-string/jumbo v1, "measurement_enabled"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method final t(Z)V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "teeecpnpirec umr tlnAtro eme ansmpoigltdesf"

    const-string v1, "eepm eAcdnalnprucotriel  g mettfenesdtmrsoi"

    const/4 v4, 0x3

    const-string v1, " gnmotslq eneraeneAteitilucppctreros m fded"

    const-string v1, "App measurement setting deferred collection"

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "dosinineettaseollfacceol__dyr"

    const-string v1, "_ocaoldnettyccrseldoieena_ilf"

    const/4 v4, 0x3

    const-string/jumbo v1, "nccmirfsy_ilca_olndrttaeeeleo"

    const-string v1, "deferred_analytics_collection"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method final u()Z
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->c:Landroid/content/SharedPreferences;

    const/4 v3, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "ice_abyednnaldctsrfeirclelo_t"

    const/4 v3, 0x6

    const-string/jumbo v1, "y_ceorendaletsita_iroccendllf"

    const-string v1, "deferred_analytics_collection"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method final v(J)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->k:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/y3;->a()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sub-long/2addr p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/d4;->o:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/y3;->a()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    cmp-long p1, p1, v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-lez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p1
.end method

.method final w(I)Z
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "nseosbntccou_u"

    const-string/jumbo v1, "osccoeunu_tesn"

    const/4 v4, 0x4

    const-string v1, "_stecsunoruoen"

    const-string v1, "consent_source"

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const/16 v2, 0x64

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/measurement/internal/g;->l(II)Z

    move-result p1

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    return p1
.end method
