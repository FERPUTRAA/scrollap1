.class public final Lcom/google/android/gms/measurement/internal/m9;
.super Lcom/google/android/gms/measurement/internal/c4;


# instance fields
.field private c:Landroid/os/Handler;

.field protected final d:Lcom/google/android/gms/measurement/internal/l9;

.field protected final e:Lcom/google/android/gms/measurement/internal/k9;

.field protected final f:Lcom/google/android/gms/measurement/internal/h9;


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/c4;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/measurement/internal/l9;

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-direct {p1, p0}, Lcom/google/android/gms/measurement/internal/l9;-><init>(Lcom/google/android/gms/measurement/internal/m9;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/m9;->d:Lcom/google/android/gms/measurement/internal/l9;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-instance p1, Lcom/google/android/gms/measurement/internal/k9;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p1, p0}, Lcom/google/android/gms/measurement/internal/k9;-><init>(Lcom/google/android/gms/measurement/internal/m9;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/m9;->e:Lcom/google/android/gms/measurement/internal/k9;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p1, Lcom/google/android/gms/measurement/internal/h9;

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p1, p0}, Lcom/google/android/gms/measurement/internal/h9;-><init>(Lcom/google/android/gms/measurement/internal/m9;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/m9;->f:Lcom/google/android/gms/measurement/internal/h9;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static bridge synthetic o(Lcom/google/android/gms/measurement/internal/m9;)Landroid/os/Handler;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s @al~ ~ @~ f. o~/ib @ @~r otl@oi~@ @@@~~s~c  @~uib~~vm~o4d @~y@t@@@~@@-~oS1@  K~ @@n/~b~M~  f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/m9;->c:Landroid/os/Handler;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method static bridge synthetic p(Lcom/google/android/gms/measurement/internal/m9;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/m9;->s()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method static bridge synthetic q(Lcom/google/android/gms/measurement/internal/m9;J)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/m9;->s()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "em mttdei pAiat,cusvi"

    const-string v1, "Activity paused, time"

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/m9;->f:Lcom/google/android/gms/measurement/internal/h9;

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/measurement/internal/h9;->a(J)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/m9;->e:Lcom/google/android/gms/measurement/internal/k9;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/measurement/internal/k9;->b(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method

.method static bridge synthetic r(Lcom/google/android/gms/measurement/internal/m9;J)V
    .locals 5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/m9;->s()V

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, "  yeoietdusritvsiteAm,"

    const-string/jumbo v1, "misuAvdy rte ,istiteem"

    const/4 v4, 0x2

    const-string v1, "diuceb tArtsemi,m etyv"

    const-string v1, "Activity resumed, time"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/d4;->q:Lcom/google/android/gms/measurement/internal/w3;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/w3;->b()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/m9;->e:Lcom/google/android/gms/measurement/internal/k9;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/measurement/internal/k9;->c(J)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/m9;->f:Lcom/google/android/gms/measurement/internal/h9;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/h9;->b()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/m9;->d:Lcom/google/android/gms/measurement/internal/l9;

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/l9;->a:Lcom/google/android/gms/measurement/internal/m9;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/l9;->a:Lcom/google/android/gms/measurement/internal/m9;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->o()Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez p1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/l9;->a:Lcom/google/android/gms/measurement/internal/m9;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1}, Lcom/google/android/gms/common/util/g;->a()J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/gms/measurement/internal/l9;->b(JZ)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method private final s()V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/m9;->c:Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzby;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/measurement/zzby;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/m9;->c:Landroid/os/Handler;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method protected final n()Z
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method
