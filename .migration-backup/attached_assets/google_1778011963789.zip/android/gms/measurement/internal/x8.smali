.class public final Lcom/google/android/gms/measurement/internal/x8;
.super Lcom/google/android/gms/measurement/internal/r9;


# instance fields
.field private d:Ljava/lang/String;

.field private e:Z

.field private f:J

.field public final g:Lcom/google/android/gms/measurement/internal/y3;

.field public final h:Lcom/google/android/gms/measurement/internal/y3;

.field public final i:Lcom/google/android/gms/measurement/internal/y3;

.field public final j:Lcom/google/android/gms/measurement/internal/y3;

.field public final k:Lcom/google/android/gms/measurement/internal/y3;


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/ba;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/r9;-><init>(Lcom/google/android/gms/measurement/internal/ba;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "atslseltlssdetae_"

    const-string v1, "adsttletlee_als_s"

    const/4 v5, 0x7

    const-string v1, "_ltmesdl_eataelse"

    const-string/jumbo v1, "last_delete_stale"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/x8;->g:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "kbmfoca"

    const-string v1, "bkamcff"

    const/4 v5, 0x4

    const-string/jumbo v1, "kfbcabo"

    const-string v1, "backoff"

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v4, 0x2

    or-int/2addr v5, v4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/x8;->h:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "pusoolut_da"

    const-string v1, "_ostolulpda"

    const/4 v5, 0x7

    const-string/jumbo v1, "otldapupl_s"

    const-string/jumbo v1, "last_upload"

    const/4 v5, 0x6

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/x8;->i:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x5

    or-int/2addr v5, v4

    const-string v1, "dt_mbleaqlapt_ttosu"

    const-string v1, "dptltbmtualstop_ae_"

    const/4 v5, 0x6

    const-string/jumbo v1, "l_sl_atsottdapteuma"

    const-string/jumbo v1, "last_upload_attempt"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/x8;->j:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "iufmdmeot_iftgn"

    const-string v1, "f_mdtfuiesitgon"

    const/4 v5, 0x3

    const-string v1, "gftnofeodti_him"

    const-string/jumbo v1, "midnight_offset"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/google/android/gms/measurement/internal/y3;-><init>(Lcom/google/android/gms/measurement/internal/d4;Ljava/lang/String;J)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/x8;->k:Lcom/google/android/gms/measurement/internal/y3;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method


# virtual methods
.method protected final l()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/ i @bfv@rt4~~~SM~@a ~ @o y/o @b n  c~~s @~~ i~~ @@~t~~ 1@-mo.l@o @~ ~@ul@o@~~~~b@@f@o~ i@bK d~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method final m(Ljava/lang/String;)Landroid/util/Pair;
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v1}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/x8;->d:Ljava/lang/String;

    const/4 v7, 0x0

    if-eqz v3, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-wide v4, p0, Lcom/google/android/gms/measurement/internal/x8;->f:J

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    cmp-long v4, v1, v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ltz v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance p1, Landroid/util/Pair;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/x8;->e:Z

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-direct {p1, v3, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object p1

    :cond_1
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget-object v4, Lcom/google/android/gms/measurement/internal/z2;->c:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v3, p1, v4}, Lcom/google/android/gms/measurement/internal/f;->r(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)J

    move-result-wide v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    add-long/2addr v1, v3

    const/4 v7, 0x5

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/x8;->f:J

    const/4 p1, 0x1

    const/4 p1, 0x1

    const/4 v7, 0x4

    const/4 p1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->c(Z)V

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->getAdvertisingIdInfo(Landroid/content/Context;)Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/x8;->d:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->getId()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/x8;->d:Ljava/lang/String;

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;->isLimitAdTrackingEnabled()Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/measurement/internal/x8;->e:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x5

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->q()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo v2, "noUbiiutp alt esdvtn eeg dra"

    const-string v2, "boeeedapigtn tisvrdinUlt a  "

    const/4 v7, 0x6

    const-string v2, "eeettgip dannil vbt s grUdia"

    const-string v2, "Unable to get advertising id"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v2, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/x8;->d:Ljava/lang/String;

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 p1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p1}, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient;->c(Z)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance p1, Landroid/util/Pair;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/x8;->d:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/measurement/internal/x8;->e:Z

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p1, v0, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object p1
.end method

.method final n(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/g;)Landroid/util/Pair;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/google/android/gms/measurement/internal/g;",
            ")",
            "Landroid/util/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/g;->j()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/x8;->m(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object p1

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Landroid/util/Pair;

    const/4 v1, 0x1

    move v2, v1

    const-string p2, ""

    const-string p2, ""

    const/4 v2, 0x2

    const-string p2, ""

    const-string p2, ""

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p1, p2, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method

.method final o(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/x8;->m(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget-object p1, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {}, Lcom/google/android/gms/measurement/internal/ha;->s()Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v4, Ljava/math/BigInteger;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v4, v2, p1}, Ljava/math/BigInteger;-><init>(I[B)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    aput-object v4, v3, p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const-string p1, "032qX"

    const-string p1, "%032X"

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {v1, p1, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p1
.end method
