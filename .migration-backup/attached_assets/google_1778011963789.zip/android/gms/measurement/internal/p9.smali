.class public final Lcom/google/android/gms/measurement/internal/p9;
.super Lcom/google/android/gms/measurement/internal/r9;


# instance fields
.field private final d:Landroid/app/AlarmManager;

.field private e:Lcom/google/android/gms/measurement/internal/m;

.field private f:Ljava/lang/Integer;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/measurement/internal/ba;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/r9;-><init>(Lcom/google/android/gms/measurement/internal/ba;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const-string/jumbo v0, "sasal"

    const-string/jumbo v0, "lrsaa"

    const/4 v2, 0x2

    const-string/jumbo v0, "larma"

    const-string v0, "alarm"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p1, Landroid/app/AlarmManager;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/p9;->d:Landroid/app/AlarmManager;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private final o()I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->f:Ljava/lang/Integer;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "masrommeeun"

    const-string v2, "asmmmeurnet"

    const/4 v4, 0x7

    const-string v2, "eameubestrm"

    const-string/jumbo v2, "measurement"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v2}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->f:Ljava/lang/Integer;

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->f:Ljava/lang/Integer;

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x4

    return v0
.end method

.method private final p()Landroid/app/PendingIntent;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v2, "eo.guaud.eReimcr.moveonugeamolorrtdA.ptpeemnsiegcsa.enMrm"

    const-string/jumbo v2, "islmo.tegeacnedomscnaerM.pomtepev.Rurrdugnseaermo.ogemA.i"

    const/4 v5, 0x2

    const-string/jumbo v2, "v.snroopnmeg.apescd.gARrecmrmase.etanoie.eoimtdmgpeuMleer"

    const-string v2, "com.google.android.gms.measurement.AppMeasurementReceiver"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v2, "adAgDscrqOu.tomnno.rmeoL.demolgsmgiaP..be"

    const-string v2, ".domobcAogar.rPgLnaodmegsetisnOem..leu.mD"

    const/4 v5, 0x4

    const-string/jumbo v2, "slsag..oeesAm..ecrimomdgDugenoOLtPmndor.a"

    const-string v2, "com.google.android.gms.measurement.UPLOAD"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget v2, Lcom/google/android/gms/internal/measurement/zzbs;->zza:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v3, v1, v2}, Lcom/google/android/gms/internal/measurement/zzbs;->zza(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object v0
.end method

.method private final q()Lcom/google/android/gms/measurement/internal/m;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->e:Lcom/google/android/gms/measurement/internal/m;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Lcom/google/android/gms/measurement/internal/o9;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/ba;->b0()Lcom/google/android/gms/measurement/internal/z4;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-direct {v0, p0, v1}, Lcom/google/android/gms/measurement/internal/o9;-><init>(Lcom/google/android/gms/measurement/internal/p9;Lcom/google/android/gms/measurement/internal/v5;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->e:Lcom/google/android/gms/measurement/internal/m;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->e:Lcom/google/android/gms/measurement/internal/m;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method private final r()V
    .locals 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "hucmseljdroe"

    const-string/jumbo v1, "jobscheduler"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    check-cast v0, Landroid/app/job/JobScheduler;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->o()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/app/job/JobScheduler;->cancel(I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method protected final l()Z
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->d:Landroid/app/AlarmManager;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->p()Landroid/app/PendingIntent;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/16 v1, 0x18

    const/4 v3, 0x4

    if-lt v0, v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->r()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method public final m()V
    .locals 4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v2, 0x5

    or-int/2addr v3, v2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "uUcsonualoedngdluih"

    const-string/jumbo v1, "lodnueuacnUlidugsh "

    const/4 v3, 0x5

    const-string v1, "epcUhbuldsa onlgiun"

    const-string v1, "Unscheduling upload"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/p9;->d:Landroid/app/AlarmManager;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->p()Landroid/app/PendingIntent;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    :cond_0
    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->q()Lcom/google/android/gms/measurement/internal/m;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/m;->b()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 v1, 0x18

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-lt v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->r()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public final n(J)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->d()Lcom/google/android/gms/measurement/internal/b;

    const/4 v9, 0x7

    move v10, v9

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/ha;->X(Landroid/content/Context;)Z

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-nez v1, :cond_0

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->q()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string/jumbo v2, "tse/ieutRrerivncergbpeeelnoad e"

    const-string v2, "bigReinptrd eaelencr ereso/evte"

    const/4 v10, 0x6

    const-string/jumbo v2, "rertb epeeiagenncRsvoe /dlteire"

    const-string v2, "Receiver not registered/enabled"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v0, v1}, Lcom/google/android/gms/measurement/internal/ha;->Y(Landroid/content/Context;Z)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-nez v0, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->q()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string v1, "dlqvsnerqateSe eidt/gcirre eon"

    const-string v1, "bnee eltqiavsrreS /erdneiodgct"

    const/4 v10, 0x2

    const-string v1, "ersint/re eegaebcovlet Sdnidre"

    const-string v1, "Service not registered/enabled"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/p9;->m()V

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string v1, "c hm ussi,lpnmigladuSlole"

    const-string/jumbo v1, "uisSgmu alld phlidlsonce,"

    const/4 v10, 0x0

    const-string v1, "Scheduling upload, millis"

    const/4 v10, 0x0

    const/4 v9, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v9, 0x0

    move v10, v9

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-interface {v0}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    add-long v4, v0, p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    sget-object v0, Lcom/google/android/gms/measurement/internal/z2;->y:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/y2;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    check-cast v0, Ljava/lang/Long;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x1

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-static {v6, v7, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    cmp-long v0, p1, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-gez v0, :cond_2

    const/4 v9, 0x3

    move v10, v9

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->q()Lcom/google/android/gms/measurement/internal/m;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/m;->e()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez v0, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->q()Lcom/google/android/gms/measurement/internal/m;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/measurement/internal/m;->d(J)V

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->d()Lcom/google/android/gms/measurement/internal/b;

    const/4 v10, 0x1

    const/4 v9, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/16 v2, 0x18

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-lt v0, v2, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-instance v1, Landroid/content/ComponentName;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string/jumbo v2, "uecpooomommveagl.eiernmratenoSmcsteJmrnipgerse.ebo.d.gasAd."

    const-string/jumbo v2, "vc.moetcrssoinngoremuagrmgdpeaeoloa.Apem.rmmtJu.enesdSiee.b"

    const/4 v10, 0x0

    const-string v2, "Jrt.nbvugeooeamtsmuepmabdceilm.noocmsgr.niMadsAeereeger.poS"

    const-string v2, "com.google.android.gms.measurement.AppMeasurementJobService"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-direct {v1, v0, v2}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->o()I

    move-result v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance v3, Landroid/os/PersistableBundle;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-direct {v3}, Landroid/os/PersistableBundle;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const-string/jumbo v4, "uitoac"

    const-string v4, "icotoa"

    const/4 v10, 0x2

    const-string v4, "cptino"

    const-string v4, "action"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-string/jumbo v5, "o.a.ALndqn.PeemDrb.rdlammogiOUstgse.ucome"

    const-string v5, "eLnOmbreocmmsmUaol..gdoPu...igdareDtnAseg"

    const/4 v10, 0x2

    const-string v5, "com.google.android.gms.measurement.UPLOAD"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    move v10, v9

    new-instance v4, Landroid/app/job/JobInfo$Builder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    invoke-direct {v4, v2, v1}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    const/4 v10, 0x4

    invoke-virtual {v4, p1, p2}, Landroid/app/job/JobInfo$Builder;->setMinimumLatency(J)Landroid/app/job/JobInfo$Builder;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-long/2addr p1, p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v1, p1, p2}, Landroid/app/job/JobInfo$Builder;->setOverrideDeadline(J)Landroid/app/job/JobInfo$Builder;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p1, v3}, Landroid/app/job/JobInfo$Builder;->setExtras(Landroid/os/PersistableBundle;)Landroid/app/job/JobInfo$Builder;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p1}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    const-string p2, "gmsomcolsnd.eggu.ro.ad"

    const-string p2, "dg.goouo.gem.rsconlamd"

    const/4 v10, 0x5

    const-string/jumbo p2, "olcmge.d.go.domsaiornm"

    const-string p2, "com.google.android.gms"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v1, "plomoalAUpa"

    const-string v1, "aomapAlprlU"

    const/4 v10, 0x3

    const-string v1, "daAoUbrlalm"

    const-string v1, "UploadAlarm"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-static {v0, p1, p2, v1}, Lcom/google/android/gms/internal/measurement/zzbt;->zza(Landroid/content/Context;Landroid/app/job/JobInfo;Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-void

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/p9;->d:Landroid/app/AlarmManager;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v2, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v3, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    sget-object v0, Lcom/google/android/gms/measurement/internal/z2;->t:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/y2;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    check-cast v0, Ljava/lang/Long;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v6

    const/4 v10, 0x3

    const/4 v9, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/measurement/internal/p9;->p()Landroid/app/PendingIntent;

    move-result-object v8

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual/range {v2 .. v8}, Landroid/app/AlarmManager;->setInexactRepeating(IJJLandroid/app/PendingIntent;)V

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-void
.end method
