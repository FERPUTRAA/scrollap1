.class public final Lcom/google/android/gms/measurement/internal/v7;
.super Lcom/google/android/gms/measurement/internal/c4;


# instance fields
.field private volatile c:Lcom/google/android/gms/measurement/internal/o7;

.field private volatile d:Lcom/google/android/gms/measurement/internal/o7;

.field protected e:Lcom/google/android/gms/measurement/internal/o7;
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation
.end field

.field private final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/app/Activity;",
            "Lcom/google/android/gms/measurement/internal/o7;",
            ">;"
        }
    .end annotation
.end field

.field private g:Landroid/app/Activity;
    .annotation build Landroidx/annotation/b0;
        value = "activityLock"
    .end annotation
.end field

.field private volatile h:Z
    .annotation build Landroidx/annotation/b0;
        value = "activityLock"
    .end annotation
.end field

.field private volatile i:Lcom/google/android/gms/measurement/internal/o7;

.field private j:Lcom/google/android/gms/measurement/internal/o7;

.field private k:Z
    .annotation build Landroidx/annotation/b0;
        value = "activityLock"
    .end annotation
.end field

.field private final l:Ljava/lang/Object;

.field private m:Lcom/google/android/gms/measurement/internal/o7;
    .annotation build Landroidx/annotation/b0;
        value = "this"
    .end annotation
.end field

.field private n:Ljava/lang/String;
    .annotation build Landroidx/annotation/b0;
        value = "this"
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/c4;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private final H(Landroid/app/Activity;)Lcom/google/android/gms/measurement/internal/o7;
    .locals 7
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "/Ks~~~S  4c@~~@o mn/ @~o Mis@~@@tl@@ ~ 1~@@ tu@o @i o y~ @~io~bodf@b~@@~~l~~fa~ @.~-r~  @@v@~b ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v6, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    check-cast v0, Lcom/google/android/gms/measurement/internal/o7;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v1, "svymAcit"

    const-string/jumbo v1, "itsAyicv"

    const/4 v6, 0x3

    const-string/jumbo v1, "ityAocit"

    const-string v1, "Activity"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/measurement/internal/v7;->u(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lcom/google/android/gms/measurement/internal/o7;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/ha;->r0()J

    move-result-wide v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v1, v4, v0, v2, v3}, Lcom/google/android/gms/measurement/internal/o7;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v6, 0x3

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->i:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p1, :cond_1

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->i:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object p1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object v0
.end method

.method private final o(Landroid/app/Activity;Lcom/google/android/gms/measurement/internal/o7;Z)V
    .locals 16
    .annotation build Landroidx/annotation/l0;
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    if-nez v1, :cond_0

    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/v7;->d:Lcom/google/android/gms/measurement/internal/o7;

    goto :goto_0

    :cond_0
    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    :goto_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    iget-object v1, v0, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    if-nez v1, :cond_2

    if-eqz p1, :cond_1

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string/jumbo v2, "iiActbmy"

    const-string/jumbo v2, "ticmiAty"

    const-string v2, "ctitviuA"

    const-string v2, "Activity"

    invoke-virtual {v7, v1, v2}, Lcom/google/android/gms/measurement/internal/v7;->u(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    new-instance v1, Lcom/google/android/gms/measurement/internal/o7;

    iget-object v9, v0, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    iget-wide v11, v0, Lcom/google/android/gms/measurement/internal/o7;->c:J

    iget-boolean v13, v0, Lcom/google/android/gms/measurement/internal/o7;->e:Z

    iget-wide v14, v0, Lcom/google/android/gms/measurement/internal/o7;->f:J

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    invoke-direct/range {v8 .. v15}, Lcom/google/android/gms/measurement/internal/o7;-><init>(Ljava/lang/String;Ljava/lang/String;JZJ)V

    move-object v2, v1

    move-object v2, v1

    goto :goto_2

    :cond_2
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_2
    iget-object v0, v7, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    iput-object v0, v7, Lcom/google/android/gms/measurement/internal/v7;->d:Lcom/google/android/gms/measurement/internal/o7;

    iput-object v2, v7, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    iget-object v0, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v0

    invoke-interface {v0}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v4

    iget-object v0, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v8

    new-instance v9, Lcom/google/android/gms/measurement/internal/q7;

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move/from16 v6, p3

    move/from16 v6, p3

    move/from16 v6, p3

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/measurement/internal/q7;-><init>(Lcom/google/android/gms/measurement/internal/v7;Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;JZ)V

    invoke-virtual {v8, v9}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    return-void
.end method

.method private final p(Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;JZLandroid/os/Bundle;)V
    .locals 15
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-wide/from16 v3, p3

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v2, :cond_1

    iget-wide v8, v2, Lcom/google/android/gms/measurement/internal/o7;->c:J

    iget-wide v10, v1, Lcom/google/android/gms/measurement/internal/o7;->c:J

    cmp-long v8, v8, v10

    if-nez v8, :cond_1

    iget-object v8, v2, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    invoke-static {v8, v9}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_1

    iget-object v8, v2, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    invoke-static {v8, v9}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_0

    goto :goto_0

    :cond_0
    move v8, v6

    move v8, v6

    move v8, v6

    move v8, v6

    goto :goto_1

    :cond_1
    :goto_0
    move v8, v7

    move v8, v7

    move v8, v7

    :goto_1
    if-eqz p5, :cond_2

    iget-object v9, v0, Lcom/google/android/gms/measurement/internal/v7;->e:Lcom/google/android/gms/measurement/internal/o7;

    if-eqz v9, :cond_2

    move v6, v7

    move v6, v7

    move v6, v7

    move v6, v7

    :cond_2
    if-eqz v8, :cond_c

    if-eqz v5, :cond_3

    new-instance v8, Landroid/os/Bundle;

    invoke-direct {v8, v5}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    goto :goto_2

    :cond_3
    new-instance v8, Landroid/os/Bundle;

    invoke-direct {v8}, Landroid/os/Bundle;-><init>()V

    :goto_2
    move-object v14, v8

    move-object v14, v8

    move-object v14, v8

    invoke-static {v1, v14, v7}, Lcom/google/android/gms/measurement/internal/ha;->x(Lcom/google/android/gms/measurement/internal/o7;Landroid/os/Bundle;Z)V

    if-eqz v2, :cond_6

    iget-object v5, v2, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    if-eqz v5, :cond_4

    const-string/jumbo v8, "pn_"

    const-string/jumbo v8, "n_p"

    const-string/jumbo v8, "pn_"

    const-string v8, "_pn"

    invoke-virtual {v14, v8, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    iget-object v5, v2, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    if-eqz v5, :cond_5

    const-string v8, "c_p"

    const-string/jumbo v8, "pc_"

    const-string v8, "c_p"

    const-string v8, "_pc"

    invoke-virtual {v14, v8, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    const-string/jumbo v5, "ip_"

    const-string/jumbo v5, "ip_"

    const-string v5, "_pi"

    const-string v5, "_pi"

    iget-wide v8, v2, Lcom/google/android/gms/measurement/internal/o7;->c:J

    invoke-virtual {v14, v5, v8, v9}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_6
    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    if-eqz v6, :cond_7

    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->M()Lcom/google/android/gms/measurement/internal/m9;

    move-result-object v2

    iget-object v2, v2, Lcom/google/android/gms/measurement/internal/m9;->e:Lcom/google/android/gms/measurement/internal/k9;

    iget-wide v10, v2, Lcom/google/android/gms/measurement/internal/k9;->b:J

    sub-long v10, v3, v10

    iput-wide v3, v2, Lcom/google/android/gms/measurement/internal/k9;->b:J

    cmp-long v2, v10, v8

    if-lez v2, :cond_7

    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    invoke-virtual {v2, v14, v10, v11}, Lcom/google/android/gms/measurement/internal/ha;->v(Landroid/os/Bundle;J)V

    :cond_7
    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v2

    if-nez v2, :cond_8

    const-string/jumbo v2, "m_ts"

    const-string/jumbo v2, "t_ms"

    const-string/jumbo v2, "tm_s"

    const-string v2, "_mst"

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    invoke-virtual {v14, v2, v10, v11}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_8
    iget-boolean v2, v1, Lcom/google/android/gms/measurement/internal/o7;->e:Z

    if-eq v7, v2, :cond_9

    const-string/jumbo v2, "taou"

    const-string/jumbo v2, "tauo"

    const-string/jumbo v2, "uaot"

    const-string v2, "auto"

    goto :goto_3

    :cond_9
    const-string/jumbo v2, "pap"

    const-string/jumbo v2, "pap"

    const-string v2, "app"

    :goto_3
    move-object v10, v2

    move-object v10, v2

    move-object v10, v2

    move-object v10, v2

    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v2

    invoke-interface {v2}, Lcom/google/android/gms/common/util/g;->a()J

    move-result-wide v11

    iget-boolean v2, v1, Lcom/google/android/gms/measurement/internal/o7;->e:Z

    if-eqz v2, :cond_b

    move-wide/from16 p5, v11

    iget-wide v11, v1, Lcom/google/android/gms/measurement/internal/o7;->f:J

    cmp-long v2, v11, v8

    if-nez v2, :cond_a

    goto :goto_4

    :cond_a
    move-wide v12, v11

    goto :goto_5

    :cond_b
    move-wide/from16 p5, v11

    :goto_4
    move-wide/from16 v12, p5

    :goto_5
    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->I()Lcom/google/android/gms/measurement/internal/h7;

    move-result-object v9

    const-string/jumbo v11, "v_s"

    const-string/jumbo v11, "s_v"

    const-string/jumbo v11, "v_s"

    const-string v11, "_vs"

    invoke-virtual/range {v9 .. v14}, Lcom/google/android/gms/measurement/internal/h7;->v(Ljava/lang/String;Ljava/lang/String;JLandroid/os/Bundle;)V

    :cond_c
    if-eqz v6, :cond_d

    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/v7;->e:Lcom/google/android/gms/measurement/internal/o7;

    invoke-direct {p0, v2, v7, v3, v4}, Lcom/google/android/gms/measurement/internal/v7;->q(Lcom/google/android/gms/measurement/internal/o7;ZJ)V

    :cond_d
    iput-object v1, v0, Lcom/google/android/gms/measurement/internal/v7;->e:Lcom/google/android/gms/measurement/internal/o7;

    iget-boolean v2, v1, Lcom/google/android/gms/measurement/internal/o7;->e:Z

    if-eqz v2, :cond_e

    iput-object v1, v0, Lcom/google/android/gms/measurement/internal/v7;->j:Lcom/google/android/gms/measurement/internal/o7;

    :cond_e
    iget-object v2, v0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->L()Lcom/google/android/gms/measurement/internal/w8;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/google/android/gms/measurement/internal/w8;->u(Lcom/google/android/gms/measurement/internal/o7;)V

    return-void
.end method

.method private final q(Lcom/google/android/gms/measurement/internal/o7;ZJ)V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->y()Lcom/google/android/gms/measurement/internal/a2;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/a2;->n(J)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-boolean v1, p1, Lcom/google/android/gms/measurement/internal/o7;->d:Z

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    const/4 v4, 0x4

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->M()Lcom/google/android/gms/measurement/internal/m9;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, v2, Lcom/google/android/gms/measurement/internal/m9;->e:Lcom/google/android/gms/measurement/internal/k9;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2, v1, p2, p3, p4}, Lcom/google/android/gms/measurement/internal/k9;->d(ZZJ)Z

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz p2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    iput-boolean v0, p1, Lcom/google/android/gms/measurement/internal/o7;->d:Z

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method static bridge synthetic r(Lcom/google/android/gms/measurement/internal/v7;)Lcom/google/android/gms/measurement/internal/o7;
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/v7;->j:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method static bridge synthetic v(Lcom/google/android/gms/measurement/internal/v7;Lcom/google/android/gms/measurement/internal/o7;)V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x2

    shr-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->j:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method static bridge synthetic w(Lcom/google/android/gms/measurement/internal/v7;Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;JZLandroid/os/Bundle;)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-wide v3, p3

    const/4 v7, 0x7

    move v5, p5

    move v5, p5

    move v5, p5

    move v5, p5

    const/4 v7, 0x3

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/measurement/internal/v7;->p(Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;JZLandroid/os/Bundle;)V

    const/4 v7, 0x5

    return-void
.end method

.method static bridge synthetic x(Lcom/google/android/gms/measurement/internal/v7;Landroid/os/Bundle;Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;J)V
    .locals 9

    const-string v0, "aencesop_rn"

    const-string v0, "a_ceomrsnen"

    const-string/jumbo v0, "menrs_ecqna"

    const-string/jumbo v0, "screen_name"

    const/4 v8, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v8, 0x5

    const-string/jumbo v0, "sbssraecl_ec"

    const-string v0, "al_erbcsecss"

    const-string v0, "caemces_srns"

    const-string/jumbo v0, "screen_class"

    const/4 v8, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v6, 0x1

    or-int/2addr v8, v6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x1

    const-string v2, "euseov_ewin"

    const-string v2, "cveniwuese_"

    const-string/jumbo v2, "snceebwe_rv"

    const-string/jumbo v2, "screen_view"

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v8, 0x6

    const/4 v5, 0x0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x2

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->v0(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)Landroid/os/Bundle;

    move-result-object v0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-wide v4, p4

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    const/4 v8, 0x3

    invoke-direct/range {v1 .. v7}, Lcom/google/android/gms/measurement/internal/v7;->p(Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;JZLandroid/os/Bundle;)V

    const/4 v8, 0x2

    return-void
.end method

.method static bridge synthetic y(Lcom/google/android/gms/measurement/internal/v7;Lcom/google/android/gms/measurement/internal/o7;ZJ)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/gms/measurement/internal/v7;->q(Lcom/google/android/gms/measurement/internal/o7;ZJ)V

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final A(Landroid/app/Activity;)V
    .locals 4
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->g:Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne p1, v1, :cond_0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->g:Landroid/app/Activity;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    throw p1
.end method

.method public final B(Landroid/app/Activity;)V
    .locals 6
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-enter v0

    const/4 v4, 0x0

    move v5, v4

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x1

    iput-boolean v1, p0, Lcom/google/android/gms/measurement/internal/v7;->k:Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput-boolean v1, p0, Lcom/google/android/gms/measurement/internal/v7;->h:Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput-object v3, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v2, Lcom/google/android/gms/measurement/internal/s7;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v2, p0, v0, v1}, Lcom/google/android/gms/measurement/internal/s7;-><init>(Lcom/google/android/gms/measurement/internal/v7;J)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v2}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/v7;->H(Landroid/app/Activity;)Lcom/google/android/gms/measurement/internal/o7;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/google/android/gms/measurement/internal/v7;->d:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object v3, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v3, Lcom/google/android/gms/measurement/internal/t7;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v3, p0, p1, v0, v1}, Lcom/google/android/gms/measurement/internal/t7;-><init>(Lcom/google/android/gms/measurement/internal/v7;Lcom/google/android/gms/measurement/internal/o7;J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    throw p1
.end method

.method public final C(Landroid/app/Activity;)V
    .locals 6
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-enter v0

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-boolean v1, p0, Lcom/google/android/gms/measurement/internal/v7;->k:Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->g:Landroid/app/Activity;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq p1, v1, :cond_0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->g:Landroid/app/Activity;

    const/4 v5, 0x2

    iput-boolean v2, p0, Lcom/google/android/gms/measurement/internal/v7;->h:Z

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->i:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v3, Lcom/google/android/gms/measurement/internal/u7;

    const/4 v5, 0x6

    invoke-direct {v3, p0}, Lcom/google/android/gms/measurement/internal/u7;-><init>(Lcom/google/android/gms/measurement/internal/v7;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v3}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_3
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p1

    :cond_0
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->i:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/gms/measurement/internal/r7;

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/gms/measurement/internal/r7;-><init>(Lcom/google/android/gms/measurement/internal/v7;)V

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p1, v0}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :cond_1
    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/v7;->H(Landroid/app/Activity;)Lcom/google/android/gms/measurement/internal/o7;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {p0, p1, v0, v2}, Lcom/google/android/gms/measurement/internal/v7;->o(Landroid/app/Activity;Lcom/google/android/gms/measurement/internal/o7;Z)V

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->y()Lcom/google/android/gms/measurement/internal/a2;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v0

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v3, Lcom/google/android/gms/measurement/internal/z0;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v3, p1, v0, v1}, Lcom/google/android/gms/measurement/internal/z0;-><init>(Lcom/google/android/gms/measurement/internal/a2;J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    return-void

    :catchall_1
    move-exception p1

    :try_start_5
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    throw p1
.end method

.method public final D(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 6
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v4, 0x1

    move v5, v4

    if-nez p2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast p1, Lcom/google/android/gms/measurement/internal/o7;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    return-void

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v1, "id"

    const-string v1, "id"

    const-string v1, "id"

    const-string v1, "id"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v2, p1, Lcom/google/android/gms/measurement/internal/o7;->c:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v1, "eanm"

    const-string v1, "enma"

    const/4 v5, 0x5

    const-string v1, "enma"

    const-string/jumbo v1, "name"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p1, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v1, "errarfuerpm_n"

    const-string/jumbo v1, "rfeean_prmerr"

    const/4 v5, 0x4

    const-string/jumbo v1, "rrmf_aepnreer"

    const-string/jumbo v1, "referrer_name"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo p1, "rlussme.qe._cenge_rn.asipcagcqotemeoeprve"

    const-string p1, "gpla.g_iqrpsmesmeeeeocvsucrnron._meeteca."

    const/4 v5, 0x6

    const-string p1, ".esotssolic__ogmercneaer.ee.ueavcgmerpsmn"

    const-string p1, "com.google.app_measurement.screen_service"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p2, p1, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-void
.end method

.method public final E(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/c1;
            max = 0x24L
            min = 0x1L
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/c1;
            max = 0x24L
            min = 0x1L
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string p2, "Ss mnrtbwrannr letn rcb eeocCstreendised  gcaupseeadilo lc .eeiishtnr"

    const-string/jumbo p2, "lesrSiboni tnri.l ngneeto eecsb edr pnesCscwltatsauecrchr  der dleain"

    const/4 v4, 0x2

    const-string/jumbo p2, "tinlot srSlndreesle.nCe iadcurrewtrsae lonia ptegehce ce dsnco bnber "

    const-string/jumbo p2, "setCurrentScreen cannot be called while screen reporting is disabled."

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    return-void

    :cond_0
    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v4, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo p2, "rt C b rocneeclrlhudateintnemoae seStbiln wtietcvev  cayan"

    const-string/jumbo p2, "n Cmovhcsaiinw ecceeaSreuntealctvlyter  eb atodltntie nir "

    const/4 v4, 0x4

    const-string p2, "eeSte u oinc l rdaecervnnCalryc tbvcei h niateeuncatiwotst"

    const-string/jumbo p2, "setCurrentScreen cannot be called while no activity active"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v3, 0x0

    move v4, v3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v4, 0x4

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string p2, " wcyleap reyhcititleiiS cte uyc rcvn nustthaamel oe ivittcnies tt Cerlfban"

    const-string/jumbo p2, "lrrloctei nulac ciyislcn   iee vt emtthuh tyseatSCerci n fitecvibeateawytn"

    const/4 v4, 0x5

    const-string/jumbo p2, "sticeCScqaey lattcefheur icile tianve cw tmilyeurliec at evn bttihd nsrt y"

    const-string/jumbo p2, "setCurrentScreen must be called with an activity in the activity lifecycle"

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    return-void

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez p3, :cond_3

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v1, "vtsAbity"

    const-string/jumbo v1, "itAvibyt"

    const/4 v4, 0x4

    const-string v1, "Activity"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, p3, v1}, Lcom/google/android/gms/measurement/internal/v7;->u(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, v0, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    const/4 v4, 0x4

    invoke-static {v1, p3}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-static {v0, p2}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_4

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x6

    and-int/2addr v4, v3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-string p2, "Chbmsotadsena uwneellitcsea  amc ct euee racmt r lsee nrnndnht"

    const-string/jumbo p2, "setnaSunrucetmttwebo mhs n c Cacerahnse tscin ella nd aeede lr"

    const/4 v4, 0x7

    const-string p2, "an womm nhstareulet leehdncbetsndaeeito csetcr al CnSaac  srn "

    const-string/jumbo p2, "setCurrentScreen cannot be called with the same class and name"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_5
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/16 v0, 0x64

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p2, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-lez v1, :cond_6

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-gt v1, v0, :cond_6

    const/4 v4, 0x3

    goto :goto_1

    :cond_6
    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string p3, "en gebanseIveirlen shtedSngc tnenrrinuh. mpnCl aetLr c"

    const-string p3, "ertuannpegnltisSmgnive  nrhnerececdLeCensIe t.ln ahr  "

    const-string p3, "elieemuneen red cnashctgn enSvetgL ti rCa .ulrnsnIhnte"

    const-string p3, "Invalid screen name length in setCurrentScreen. Length"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1, p3, p2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void

    :cond_7
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p3, :cond_9

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-lez v1, :cond_8

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-gt v1, v0, :cond_8

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_2

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo p3, "nesinmep gcgenthrrCcenta nutIn ls  dseeSa laehntlvqiL"

    const-string p3, "Lhanleeaqta nllt nmt ngnt dsreir uninesrgeeC vhcIScse"

    const/4 v4, 0x2

    const-string p3, "Lngmr stqahteSnsCe  Iildrsne.gnl ctn ecnlraevn eauhti"

    const-string p3, "Invalid class name length in setCurrentScreen. Length"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, p3, p2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    return-void

    :cond_9
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez p2, :cond_a

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "llnu"

    const-string/jumbo v1, "null"

    const/4 v4, 0x4

    const-string/jumbo v1, "llun"

    const-string/jumbo v1, "null"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_3

    :cond_a
    move-object v1, p2

    move-object v1, p2

    :goto_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "rnseerctsctcg  m, rteeSsn nstnis aeal"

    const-string v2, " tsrtsneec,esgiS antcm ctenolrsa e nr"

    const/4 v4, 0x4

    const-string/jumbo v2, "t,emislca genn r t menone aeSusrtrsct"

    const-string v2, "Setting current screen to name, class"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1, p3}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/gms/measurement/internal/o7;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/ha;->r0()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, p2, p3, v1, v2}, Lcom/google/android/gms/measurement/internal/o7;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0, p1, v0, p2}, Lcom/google/android/gms/measurement/internal/v7;->o(Landroid/app/Activity;Lcom/google/android/gms/measurement/internal/o7;Z)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method public final F(Landroid/os/Bundle;J)V
    .locals 12

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->l:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-boolean v1, p0, Lcom/google/android/gms/measurement/internal/v7;->k:Z

    if-nez v1, :cond_0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const-string p2, "annaoden eh v amnhs toe  trneote egpCcki ri gwnobnlcivtps euwh."

    const-string p2, " nemenrptaun eoip dvil ic Cehtatnh.bgkssg aho  oe wcv n nneretw"

    const-string p2, "avr hbnvb oannn   tertieiitp wkCl eno  gceganpsweceehnt h u.sde"

    const-string p2, "Cannot log screen view event when the app is in the background."

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    monitor-exit v0

    return-void

    :cond_0
    const-string/jumbo v1, "nnecrsuaemo"

    const-string/jumbo v1, "nancormeees"

    const-string/jumbo v1, "smceranpe_n"

    const-string/jumbo v1, "screen_name"

    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v1, 0x64

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_1

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    if-le v2, v1, :cond_2

    :cond_1
    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const-string/jumbo p2, "s.nm gIfqeLvinnnlbwneehnevier eoa  lr te rsecthdac"

    const-string/jumbo p2, "ln evbdsw e nevLfnn alc rcgeenet erhaeinsi. ohtmIr"

    const-string p2, " esgweIdvle rcenr tLmovg n.nhiee fn nitshsacen ral"

    const-string p2, "Invalid screen name length for screen view. Length"

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result p3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    monitor-exit v0

    return-void

    :cond_2
    const-string/jumbo v2, "rssmnuecaes_"

    const-string/jumbo v2, "nrses_uaelsc"

    const-string/jumbo v2, "secloa_escsr"

    const-string/jumbo v2, "screen_class"

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_3

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    iget-object v5, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    if-le v4, v1, :cond_4

    :cond_3
    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const-string p2, " c i.bnsnl enlh se getprafrLteewnc gehsinIvocadsevl"

    const-string/jumbo p2, "v sventpo nhcLtnrs ecilnese fd l eliagena.w geIcsrh"

    const-string p2, " ahnwiuvesrc ngliI edsLgct t o eennce.savee rnfrshl"

    const-string p2, "Invalid screen class length for screen view. Length"

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result p3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    monitor-exit v0

    return-void

    :cond_4
    if-nez v2, :cond_6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->g:Landroid/app/Activity;

    if-eqz v1, :cond_5

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string/jumbo v2, "iiqtyctp"

    const-string/jumbo v2, "qticytiA"

    const-string/jumbo v2, "qitycvAt"

    const-string v2, "Activity"

    invoke-virtual {p0, v1, v2}, Lcom/google/android/gms/measurement/internal/v7;->u(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_5
    const-string/jumbo v1, "iysicttA"

    const-string v1, "cisitytA"

    const-string/jumbo v1, "viimAtcy"

    const-string v1, "Activity"

    :goto_0
    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    goto :goto_1

    :cond_6
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_1
    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    iget-boolean v2, p0, Lcom/google/android/gms/measurement/internal/v7;->h:Z

    if-eqz v2, :cond_7

    if-eqz v1, :cond_7

    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/google/android/gms/measurement/internal/v7;->h:Z

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    invoke-static {v2, v4}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    iget-object v1, v1, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v2, :cond_7

    if-eqz v1, :cond_7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const-string/jumbo p2, "norwoglge wedta ptenem.o ehn  ivrc p ileveartcisrangol es mtIlita"

    const-string p2, " eomarolend aletrpweci mgnittrtlsc p a .g nnioheclv aseeIw trvieg"

    const-string p2, "cnewlbrl s  cvlee.tIiinoppr vtao uoraeecnehr ltemia gsnwd  tateig"

    const-string p2, "Ignoring call to log screen view event with duplicate parameters."

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    monitor-exit v0

    return-void

    :cond_7
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    if-nez v3, :cond_8

    const-string/jumbo v1, "ulnl"

    const-string/jumbo v1, "ulln"

    const-string/jumbo v1, "unll"

    const-string/jumbo v1, "null"

    goto :goto_2

    :cond_8
    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :goto_2
    if-nez v4, :cond_9

    const-string/jumbo v2, "luln"

    const-string/jumbo v2, "unll"

    const-string/jumbo v2, "lnul"

    const-string/jumbo v2, "null"

    goto :goto_3

    :cond_9
    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :goto_3
    const-string/jumbo v5, "omg e ucrnsisocnwi, swaetae  vlLegnh"

    const-string/jumbo v5, "wr lonisha en,iL vtswgm aosigecce en"

    const-string/jumbo v5, "igaova ps nt wgeenwcscr,lghne mLii e"

    const-string v5, "Logging screen view with name, class"

    invoke-virtual {v0, v5, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    if-nez v0, :cond_a

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->d:Lcom/google/android/gms/measurement/internal/o7;

    goto :goto_4

    :cond_a
    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    :goto_4
    new-instance v1, Lcom/google/android/gms/measurement/internal/o7;

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/ha;->r0()J

    move-result-wide v5

    const/4 v7, 0x1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-wide v8, p2

    invoke-direct/range {v2 .. v9}, Lcom/google/android/gms/measurement/internal/o7;-><init>(Ljava/lang/String;Ljava/lang/String;JZJ)V

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->d:Lcom/google/android/gms/measurement/internal/o7;

    iput-object v1, p0, Lcom/google/android/gms/measurement/internal/v7;->i:Lcom/google/android/gms/measurement/internal/o7;

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object p2

    invoke-interface {p2}, Lcom/google/android/gms/common/util/g;->c()J

    move-result-wide v10

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object p2

    new-instance p3, Lcom/google/android/gms/measurement/internal/p7;

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    invoke-direct/range {v5 .. v11}, Lcom/google/android/gms/measurement/internal/p7;-><init>(Lcom/google/android/gms/measurement/internal/v7;Landroid/os/Bundle;Lcom/google/android/gms/measurement/internal/o7;Lcom/google/android/gms/measurement/internal/o7;J)V

    invoke-virtual {p2, p3}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final G(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/o7;)V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->n:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz p2, :cond_1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->n:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/google/android/gms/measurement/internal/v7;->m:Lcom/google/android/gms/measurement/internal/o7;

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p1
.end method

.method protected final n()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    return v0
.end method

.method public final s()Lcom/google/android/gms/measurement/internal/o7;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/v7;->c:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public final t(Z)Lcom/google/android/gms/measurement/internal/o7;
    .locals 2
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->e:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->e:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eqz p1, :cond_1

    const/4 v1, 0x7

    return-object p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/v7;->j:Lcom/google/android/gms/measurement/internal/o7;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method final u(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo p1, "qytvcbtA"

    const-string/jumbo p1, "tvtiybcA"

    const-string p1, "Aysvtcti"

    const-string p1, "Activity"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p2, "//."

    const-string p2, ".//"

    const/4 v2, 0x4

    const-string p2, ".//"

    const-string p2, "\\."

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    array-length p2, p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    if-lez p2, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    add-int/lit8 p2, p2, -0x1

    const/4 v2, 0x4

    aget-object p1, p1, p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string p1, ""

    const-string p1, ""

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/16 v0, 0x64

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-le p2, v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x5

    shr-int/2addr v1, p2

    const/4 v2, 0x3

    invoke-virtual {p1, p2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method public final z(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 7
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->D()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez p2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v0, "ar.mlmmnvoi.eee.gectmosceura_oe_snrppuecg"

    const-string v0, "gcslaeumooenoei.pe_cesrg_upamrms.en.rtvce"

    const/4 v6, 0x7

    const-string v0, "egcpoeue.rsmsgo.aev_sorenomatriencc_me.el"

    const-string v0, "com.google.app_measurement.screen_service"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez p2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v0, Lcom/google/android/gms/measurement/internal/o7;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v1, "nema"

    const-string/jumbo v1, "mean"

    const/4 v6, 0x1

    const-string/jumbo v1, "mena"

    const-string/jumbo v1, "name"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v2, "eerfmbnpr_aee"

    const-string v2, "arnereeprm_ef"

    const/4 v6, 0x4

    const-string v2, "eafmrru_erren"

    const-string/jumbo v2, "referrer_name"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "di"

    const-string v3, "id"

    const/4 v6, 0x4

    const-string v3, "di"

    const-string v3, "id"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p2, v3}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/android/gms/measurement/internal/o7;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/v7;->f:Ljava/util/Map;

    const/4 v5, 0x0

    move v6, v5

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void
.end method
