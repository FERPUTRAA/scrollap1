.class public final Lcom/google/android/gms/measurement/internal/n;
.super Lcom/google/android/gms/measurement/internal/u5;


# instance fields
.field private c:J

.field private d:Ljava/lang/String;

.field private e:Landroid/accounts/AccountManager;

.field private f:Ljava/lang/Boolean;

.field private g:J


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/u5;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected final j()Z
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " /s ~1@ol~@~  n ~ a~~~ i~.fSr~@ b@ ~tbbuK @ @f@@ ~~@~c-~~ ~i4@s/ M@ o@~lmy~~~@@@oi@o~ot@ v@ @d~o"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    sget-object v1, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/16 v2, 0xf

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/16 v3, 0x10

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-int/2addr v2, v0

    const/4 v6, 0x6

    int-to-long v2, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/concurrent/TimeUnit;->convert(JLjava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/google/android/gms/measurement/internal/n;->c:J

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v2, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v1, "-"

    const/4 v6, 0x7

    const-string v1, "-"

    const-string v1, "-"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->d:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    return v0
.end method

.method final o()J
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-wide v0
.end method

.method public final p()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/android/gms/measurement/internal/n;->c:J

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method

.method public final q()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method final r()V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method final s()Z
    .locals 11
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v9, 0x3

    move v10, v9

    const-string v0, "cgmmoeso.l"

    const-string/jumbo v0, "mlscogo.eo"

    const/4 v10, 0x2

    const-string/jumbo v0, "lm.oogcgoe"

    const-string v0, "com.google"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-interface {v1}, Lcom/google/android/gms/common/util/g;->a()J

    move-result-wide v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-wide v3, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v10, 0x6

    const/4 v9, 0x2

    sub-long v3, v1, v3

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-wide/32 v5, 0x5265c00

    const/4 v10, 0x7

    const-wide/32 v5, 0x5265c00

    const-wide/32 v5, 0x5265c00

    const/4 v10, 0x5

    cmp-long v3, v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x1

    if-lez v3, :cond_0

    const/4 v10, 0x4

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v3, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string v5, ".GTsibprdNemTSndnoCsiAE.Om_oaUC"

    const-string v5, "CAmmEniorG_TUrssNaCpTdnOoS..eid"

    const/4 v10, 0x2

    const-string/jumbo v5, "nmNdS.uCEpsUCidiroGrnesAaoOT.iT"

    const-string v5, "android.permission.GET_ACCOUNTS"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v3, v5}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v5, 0x0

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-eqz v3, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->y()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v3, " rinonrpon ah/r reok ocnshccfdPom rustniesogrisaurcee"

    const-string/jumbo v3, "ruaooonrgrs oorin ceuePsifrt/ecrcas  kmccsn hnihenrod"

    const/4 v10, 0x1

    const-string/jumbo v3, "n eo rkrqufecoie sn dorac/iromcgtPsrsoercir nnischuan"

    const-string v3, "Permission error checking for dasher/unicorn accounts"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v3}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    return v5

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/n;->e:Landroid/accounts/AccountManager;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez v3, :cond_2

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v3}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    iput-object v3, p0, Lcom/google/android/gms/measurement/internal/n;->e:Landroid/accounts/AccountManager;

    :cond_2
    :try_start_0
    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/n;->e:Landroid/accounts/AccountManager;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v6, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    new-array v7, v6, [Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string v8, "OEsTcesDSrbHi_"

    const-string/jumbo v8, "rSOEeb_vDHcsTi"

    const/4 v10, 0x5

    const-string/jumbo v8, "vOemcrH_DTeiEs"

    const-string/jumbo v8, "service_HOSTED"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    aput-object v8, v7, v5

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v3, v0, v7, v4, v4}, Landroid/accounts/AccountManager;->getAccountsByTypeAndFeatures(Ljava/lang/String;[Ljava/lang/String;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x2

    invoke-interface {v3}, Landroid/accounts/AccountManagerFuture;->getResult()Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    check-cast v3, [Landroid/accounts/Account;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    if-eqz v3, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    array-length v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-lez v3, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    return v6

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/n;->e:Landroid/accounts/AccountManager;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-array v7, v6, [Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v8, "euacoervusc"

    const-string v8, "_cveasucrue"

    const/4 v10, 0x2

    const-string v8, "acir_becuve"

    const-string/jumbo v8, "service_uca"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    aput-object v8, v7, v5

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v3, v0, v7, v4, v4}, Landroid/accounts/AccountManager;->getAccountsByTypeAndFeatures(Ljava/lang/String;[Ljava/lang/String;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-interface {v0}, Landroid/accounts/AccountManagerFuture;->getResult()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    check-cast v0, [Landroid/accounts/Account;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v0, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x3

    array-length v0, v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    if-lez v0, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/n;->g:J
    :try_end_0
    .catch Landroid/accounts/AuthenticatorException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/accounts/OperationCanceledException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    return v6

    :catch_0
    move-exception v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    goto :goto_0

    :catch_1
    move-exception v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_0

    :catch_2
    move-exception v0

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->t()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string/jumbo v4, "toeccgupckx cnioyisah tEu teepcp"

    const-string/jumbo v4, "khu icop setctgc opcencnpExaetiy"

    const/4 v10, 0x4

    const-string v4, "gyo otupakc ennppEtctehxnsc icce"

    const-string v4, "Exception checking account types"

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v3, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-wide v1, p0, Lcom/google/android/gms/measurement/internal/n;->g:J

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/n;->f:Ljava/lang/Boolean;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    return v5

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    return v0
.end method
