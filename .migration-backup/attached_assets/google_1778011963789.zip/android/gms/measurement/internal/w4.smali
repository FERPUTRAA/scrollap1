.class public final Lcom/google/android/gms/measurement/internal/w4;
.super Lcom/google/android/gms/measurement/internal/u5;


# static fields
.field private static final l:Ljava/util/concurrent/atomic/AtomicLong;


# instance fields
.field private c:Lcom/google/android/gms/measurement/internal/v4;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Lcom/google/android/gms/measurement/internal/v4;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final e:Ljava/util/concurrent/PriorityBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/PriorityBlockingQueue<",
            "Lcom/google/android/gms/measurement/internal/u4<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final f:Ljava/util/concurrent/BlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/BlockingQueue<",
            "Lcom/google/android/gms/measurement/internal/u4<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final g:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private final h:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private final i:Ljava/lang/Object;

.field private final j:Ljava/util/concurrent/Semaphore;

.field private volatile k:Z


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x0

    const-wide/high16 v1, -0x8000000000000000L

    const-wide/high16 v1, -0x8000000000000000L

    const/4 v4, 0x6

    const-wide/high16 v1, -0x8000000000000000L

    const-wide/high16 v1, -0x8000000000000000L

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    sput-object v0, Lcom/google/android/gms/measurement/internal/w4;->l:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/u5;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->i:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p1, Ljava/util/concurrent/Semaphore;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->j:Ljava/util/concurrent/Semaphore;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/PriorityBlockingQueue;

    const/4 v1, 0x7

    and-int/2addr v2, v1

    invoke-direct {p1}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->e:Ljava/util/concurrent/PriorityBlockingQueue;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->f:Ljava/util/concurrent/BlockingQueue;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/gms/measurement/internal/t4;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, "hpsUosardeitwetctg n  tanrd oarucdkaTehhhexeo en "

    const-string/jumbo v0, "rus raepnw teTa  ctckeUnoohhe dgrtehxidotaedh :na"

    const/4 v2, 0x6

    const-string v0, " dtmkontoar d   eU gho:ercraxhatnideephhewTactrun"

    const-string v0, "Thread death: Uncaught exception on worker thread"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p1, p0, v0}, Lcom/google/android/gms/measurement/internal/t4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->g:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/measurement/internal/t4;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string v0, " Tn oatrxhgtptnemo nn: rhk tdaaeeccaeieoh ueUdrtwh"

    const-string/jumbo v0, "nhamo rcetcTaeha rdhdxewup tgikaU ttto:enrno heen "

    const/4 v2, 0x4

    const-string/jumbo v0, "t:heebprdhoahTe da ncweru x gt hdnktUtneoonriaac t"

    const-string v0, "Thread death: Uncaught exception on network thread"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1, p0, v0}, Lcom/google/android/gms/measurement/internal/t4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->h:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method static bridge synthetic B(Lcom/google/android/gms/measurement/internal/w4;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b~ @ mu /otl@y~@~@uc o@~@@ f@ 1~@aio@4@@~ @~~~o/ bsof~ M ldv~~ @ ~~@o~~ii@~~@.~r~~ SK @   ~@-b@t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-boolean p0, p0, Lcom/google/android/gms/measurement/internal/w4;->k:Z

    const/4 v1, 0x6

    const/4 p0, 0x0

    const/4 v1, 0x5

    move v0, p0

    move v0, p0

    const/4 v1, 0x6

    return p0
.end method

.method private final D(Lcom/google/android/gms/measurement/internal/u4;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/measurement/internal/u4<",
            "*>;)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/w4;->i:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->e:Ljava/util/concurrent/PriorityBlockingQueue;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/util/concurrent/PriorityBlockingQueue;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p1, Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v1, "oeemoaMkre rWrsten"

    const/4 v4, 0x3

    const-string v1, "Measurement Worker"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/w4;->e:Ljava/util/concurrent/PriorityBlockingQueue;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p1, p0, v1, v2}, Lcom/google/android/gms/measurement/internal/v4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/String;Ljava/util/concurrent/BlockingQueue;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->g:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/v4;->a()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    throw p1
.end method

.method static bridge synthetic o(Lcom/google/android/gms/measurement/internal/w4;)Lcom/google/android/gms/measurement/internal/v4;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method static bridge synthetic p(Lcom/google/android/gms/measurement/internal/w4;)Lcom/google/android/gms/measurement/internal/v4;
    .locals 2

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic q(Lcom/google/android/gms/measurement/internal/w4;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/w4;->i:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic u(Lcom/google/android/gms/measurement/internal/w4;)Ljava/util/concurrent/Semaphore;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/w4;->j:Ljava/util/concurrent/Semaphore;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic v()Ljava/util/concurrent/atomic/AtomicLong;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/measurement/internal/w4;->l:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method

.method static bridge synthetic w(Lcom/google/android/gms/measurement/internal/w4;Lcom/google/android/gms/measurement/internal/v4;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method static bridge synthetic x(Lcom/google/android/gms/measurement/internal/w4;Lcom/google/android/gms/measurement/internal/v4;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/Runnable;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/measurement/internal/u4;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const-string/jumbo v2, "rth kbeankoTao rewdtcpe  srenox"

    const/4 v4, 0x5

    const-string v2, "Task exception on worker thread"

    const/4 v4, 0x2

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/u4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/Runnable;ZLjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/measurement/internal/w4;->D(Lcom/google/android/gms/measurement/internal/u4;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method

.method public final C()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0
.end method

.method public final g()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "edw e tpxtCku oaemrlotaeercdhr np"

    const-string/jumbo v1, "nlptx uolrometcke ratdweedC hear "

    const/4 v3, 0x2

    const-string/jumbo v1, "wdloe keqto etdhfxtlmnrecCaar rep"

    const-string v1, "Call expected from network thread"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw v0
.end method

.method public final h()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "oosefdCppe l xdma rerha krtetelr"

    const-string/jumbo v1, "mxfarhrpltk  eree padw Crdoleeot"

    const/4 v3, 0x2

    const-string v1, "codmrrt  eehwkxa fdeC ltparmoelr"

    const-string v1, "Call expected from worker thread"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw v0
.end method

.method protected final j()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method final r(Ljava/util/concurrent/atomic/AtomicReference;JLjava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "TT;>;J",
            "Ljava/lang/String;",
            "Ljava/lang/Runnable;",
            ")TT;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p5}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, p2, p3}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string p3, "T twrieoq iunofgidta m"

    const/4 v2, 0x0

    const-string p3, "Timed out waiting for "

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result p5

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p5, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p3, p4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p4, Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p4, p3}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p2, p3}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object p1

    :catch_0
    :try_start_3
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string p3, "egiroosuItr re  waninfdt"

    const-string p3, "arswf  uttI idernirtgeno"

    const/4 v2, 0x5

    const-string p3, "dgte b  pnnaieriwfuotrrt"

    const-string p3, "Interrupted waiting for "

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result p5

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p5, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p3, p4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_1

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p4, Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p4, p3}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    move-object p3, p4

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p2, p3}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    monitor-exit p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1

    :catchall_0
    move-exception p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    throw p2
.end method

.method public final s(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Callable<",
            "TV;>;)",
            "Ljava/util/concurrent/Future<",
            "TV;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/gms/measurement/internal/u4;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    or-int/2addr v4, v1

    const/4 v3, 0x6

    and-int/2addr v4, v3

    const-string/jumbo v2, "n hnseumt o akwoTixdorcrteeakr "

    const-string v2, "ernm roencTw kstaah ektrdeo xio"

    const/4 v4, 0x1

    const-string v2, "  keTotpokhcri exaadrreonsetwpn"

    const-string v2, "Task exception on worker thread"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/u4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/util/concurrent/Callable;ZLjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x0

    if-ne p1, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->e:Ljava/util/concurrent/PriorityBlockingQueue;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v1, "rube.h lqtuew leqi Cakesadlpkepoer"

    const-string v1, "Callable skipped the worker queue."

    const/4 v3, 0x0

    or-int/2addr v4, v3

    invoke-virtual {p1, v1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/FutureTask;->run()V

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/measurement/internal/w4;->D(Lcom/google/android/gms/measurement/internal/u4;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v0
.end method

.method public final t(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Callable<",
            "TV;>;)",
            "Ljava/util/concurrent/Future<",
            "TV;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/measurement/internal/u4;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-string v2, " rsrie ooTdoecenttw erahnsxkpok"

    const-string/jumbo v2, "k  eorepkn rnxtieowdohocateaTsr"

    const/4 v4, 0x5

    const-string v2, " etmx c srornakeieeo opanwThktr"

    const-string v2, "Task exception on worker thread"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/u4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/util/concurrent/Callable;ZLjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->c:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/FutureTask;->run()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/measurement/internal/w4;->D(Lcom/google/android/gms/measurement/internal/u4;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v0
.end method

.method public final y(Ljava/lang/Runnable;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/measurement/internal/u4;

    const/4 v3, 0x0

    move v4, v3

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v2, "bTn odh naekt wsorekriep taooexc"

    const-string/jumbo v2, "ksncrbeneT pewtk r idoott aeoahx"

    const-string v2, "da kcbtrep toenihekeoxsrnTn towa"

    const-string v2, "Task exception on network thread"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/u4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/Runnable;ZLjava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/w4;->i:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-enter p1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->f:Ljava/util/concurrent/BlockingQueue;

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v1, v0}, Ljava/util/concurrent/BlockingQueue;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v1, "tsmrtNurweMuke eaon"

    const/4 v4, 0x7

    const-string v1, "aeeks uNwmMeenutror"

    const-string v1, "Measurement Network"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/w4;->f:Ljava/util/concurrent/BlockingQueue;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0, p0, v1, v2}, Lcom/google/android/gms/measurement/internal/v4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/String;Ljava/util/concurrent/BlockingQueue;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/w4;->h:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/w4;->d:Lcom/google/android/gms/measurement/internal/v4;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/v4;->a()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    monitor-exit p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw v0
.end method

.method public final z(Ljava/lang/Runnable;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/u5;->k()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/measurement/internal/u4;

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v2, "ohnawkeptareo k eepxsn rdriT po"

    const-string/jumbo v2, "ki ernoptrkdawo eterpanxeo hTs "

    const/4 v4, 0x7

    const-string/jumbo v2, "thx a srqtoek  eeranowpkcdrTnei"

    const-string v2, "Task exception on worker thread"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/gms/measurement/internal/u4;-><init>(Lcom/google/android/gms/measurement/internal/w4;Ljava/lang/Runnable;ZLjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/measurement/internal/w4;->D(Lcom/google/android/gms/measurement/internal/u4;)V

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    return-void
.end method
