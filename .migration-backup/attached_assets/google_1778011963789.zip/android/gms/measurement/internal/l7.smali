.class public final Lcom/google/android/gms/measurement/internal/l7;
.super Lcom/google/android/gms/measurement/internal/u5;


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/u5;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected final j()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@s~~ bt ~@c@ry ~Kn@o@ t @  @o ~m @1u @~~~@Sio.~@@f  @M@~/ ~oi~  o~ ~~~so~-v al@~@ilfb@@~@d/~4~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
