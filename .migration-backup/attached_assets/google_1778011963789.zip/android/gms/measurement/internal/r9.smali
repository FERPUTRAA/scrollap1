.class abstract Lcom/google/android/gms/measurement/internal/r9;
.super Lcom/google/android/gms/measurement/internal/q9;


# instance fields
.field private c:Z


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/ba;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/q9;-><init>(Lcom/google/android/gms/measurement/internal/ba;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/ba;->q()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected final i()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~as~ ~~l~o1~y@rM~ ~~~o~o ~f@ /@@uf@~t@~ n @S@ io~@c~bK~  ~m@. lv 4@@@ st@@  b @@ /@ bd~~io~o@@i~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->k()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const-string/jumbo v1, "ltzmaiosdeiintN"

    const-string v1, "iNsoditaz ilnte"

    const/4 v3, 0x4

    const-string v1, " odtoaezitiiliN"

    const-string v1, "Not initialized"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw v0
.end method

.method public final j()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/r9;->c:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->l()Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/q9;->b:Lcom/google/android/gms/measurement/internal/ba;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/ba;->l()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/google/android/gms/measurement/internal/r9;->c:Z

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x2

    move v3, v2

    const-string v1, "a//e biCant wnmiiteiitz"

    const-string v1, "atim iet/tnanCwezicii /"

    const/4 v3, 0x4

    const-string/jumbo v1, "tiC ncuiinai /iezt/twle"

    const-string v1, "Can\'t initialize twice"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw v0
.end method

.method final k()Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/r9;->c:Z

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method protected abstract l()Z
.end method
