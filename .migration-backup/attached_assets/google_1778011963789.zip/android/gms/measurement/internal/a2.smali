.class public final Lcom/google/android/gms/measurement/internal/a2;
.super Lcom/google/android/gms/measurement/internal/b3;


# instance fields
.field private final b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private d:J


# direct methods
.method public constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/b3;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    new-instance p1, Landroidx/collection/a;

    const/4 v1, 0x2

    invoke-direct {p1}, Landroidx/collection/a;-><init>()V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    new-instance p1, Landroidx/collection/a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p1}, Landroidx/collection/a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic i(Lcom/google/android/gms/measurement/internal/a2;Ljava/lang/String;J)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " rs@ bf~Ki~~@@~~1~o~@4 @/@b ~o@l@i.~l@a~ iv~ ~bt~@cmt@ o s@@@~@S M- ~@ @/~d n f~~ @oo~~~ u@ @~ o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-wide p2, p0, Lcom/google/android/gms/measurement/internal/a2;->d:J

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/2addr p2, v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/16 v2, 0x64

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-lt v0, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo p1, "noimTa ssiomvla bdse"

    const-string/jumbo p1, "iesavndosTo  smia lb"

    const/4 v4, 0x4

    const-string/jumbo p1, "seidomTbianoyls  vo "

    const-string p1, "Too many ads visible"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method static synthetic j(Lcom/google/android/gms/measurement/internal/a2;Ljava/lang/String;J)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v0, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->K()Lcom/google/android/gms/measurement/internal/v7;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/measurement/internal/v7;->t(Z)Lcom/google/android/gms/measurement/internal/o7;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast v0, Ljava/lang/Long;

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v0, "resisb rtpt t  eednsaaestxv ewoi rmimnuFe"

    const-string v0, "artmoieFstesiirp mxre ean sts e wuudv net"

    const/4 v7, 0x4

    const-string/jumbo v0, "rsoe sui etevenpsxdws a e tai imenrr utFt"

    const-string v0, "First ad unit exposure time was never set"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    sub-long v2, p2, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-direct {p0, p1, v2, v3, v1}, Lcom/google/android/gms/measurement/internal/a2;->p(Ljava/lang/String;JLcom/google/android/gms/measurement/internal/o7;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz p1, :cond_2

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/google/android/gms/measurement/internal/a2;->d:J

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    cmp-long p1, v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez p1, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string p1, "First ad exposure time was never set"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    sub-long/2addr p2, v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {p0, p2, p3, v1}, Lcom/google/android/gms/measurement/internal/a2;->o(JLcom/google/android/gms/measurement/internal/o7;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-wide v4, p0, Lcom/google/android/gms/measurement/internal/a2;->d:J

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-void

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/a2;->c:Ljava/util/Map;

    const/4 v7, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-void

    :cond_4
    const/4 v7, 0x2

    iget-object p0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const-string/jumbo p2, "loueaCapou wdlnxrtiontp en EdiouddnA it  kfUrns "

    const-string/jumbo p2, "uaUsooCewnfpi  Aneonlitdndt txk larEdru on ud oi"

    const/4 v7, 0x4

    const-string/jumbo p2, "onndltonqi dk wdrpd us   innf tAueUlEeunoatiroCx"

    const-string p2, "Call to endAdUnitExposure for unknown ad unit id"

    const/4 v7, 0x3

    invoke-virtual {p0, p2, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void
.end method

.method static bridge synthetic k(Lcom/google/android/gms/measurement/internal/a2;J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/measurement/internal/a2;->q(J)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method private final o(JLcom/google/android/gms/measurement/internal/o7;)V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p3, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo p2, "otseoaggu. otl vainNe Nryatt vcxdeib ciipos"

    const-string p2, "gNovebi  ioeagya tunoiv.ptsxNogdeitc rtc la"

    const/4 v3, 0x0

    const-string p2, "ceomtgNs vxoainol uivi.e apNocgta  id ygtrt"

    const-string p2, "Not logging ad exposure. No active activity"

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x7

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    cmp-long v0, p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-gez v0, :cond_1

    const/4 v3, 0x3

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "ptl1ogsn0 eoNsaox0oseeag 0 .e sopsm Lre.  rtugn dhuu"

    const-string/jumbo v0, "iuopetu0 seuet Nhd a  00pesrx smeons.gg1slarLoo.gn  "

    const-string v0, " oxu bero0s  a1esxi0 egsrg.snmntegpoh eLNld o0. upsa"

    const-string v0, "Not logging ad exposure. Less than 1000 ms. exposure"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p3, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x4

    const-string v1, "_tx"

    const-string v1, "_tx"

    const/4 v3, 0x2

    const-string v1, "_xt"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1, p2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p3, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->x(Lcom/google/android/gms/measurement/internal/o7;Landroid/os/Bundle;Z)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->I()Lcom/google/android/gms/measurement/internal/h7;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string p2, "am"

    const-string p2, "am"

    const/4 v3, 0x5

    const-string p2, "am"

    const-string p2, "am"

    const/4 v2, 0x5

    and-int/2addr v3, v2

    const-string/jumbo p3, "xa_"

    const-string p3, "_xa"

    const/4 v3, 0x4

    const-string p3, "a_x"

    const-string p3, "_xa"

    const/4 v3, 0x5

    invoke-virtual {p1, p2, p3, v0}, Lcom/google/android/gms/measurement/internal/h7;->u(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private final p(Ljava/lang/String;JLcom/google/android/gms/measurement/internal/o7;)V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p4, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo p2, "votdoguteatcxg. epitsgiyri oucuNtl an  o pieNvni"

    const-string/jumbo p2, "ouvNge pvttcxtayeiei ir nlotNc gntis digap ou.o "

    const/4 v3, 0x5

    const-string/jumbo p2, "uN vnvgpytoeex  ttticigcrnotagN.u ai oals eip od"

    const-string p2, "Not logging ad unit exposure. No active activity"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x2

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    cmp-long v0, p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-gez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p4, "u NmdextqgenpgoLxg ls1athes.iss  e ruor.0no sa0 un0 eoit "

    const-string p4, "Not logging ad unit exposure. Less than 1000 ms. exposure"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, p4, p2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string v1, "a_i"

    const-string v1, "_ai"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const-string/jumbo p1, "xt_"

    const-string p1, "_xt"

    const/4 v3, 0x1

    const-string/jumbo p1, "x_t"

    const-string p1, "_xt"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p4, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->x(Lcom/google/android/gms/measurement/internal/o7;Landroid/os/Bundle;Z)V

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->I()Lcom/google/android/gms/measurement/internal/h7;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p2, "am"

    const-string/jumbo p2, "ma"

    const/4 v3, 0x1

    const-string p2, "am"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo p3, "ux_"

    const-string p3, "_ux"

    const/4 v3, 0x2

    const-string/jumbo p3, "u_x"

    const-string p3, "_xu"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, p2, p3, v0}, Lcom/google/android/gms/measurement/internal/h7;->u(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private final q(J)V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v2, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-wide p1, p0, Lcom/google/android/gms/measurement/internal/a2;->d:J

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method


# virtual methods
.method public final l(Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v1, Lcom/google/android/gms/measurement/internal/a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/google/android/gms/measurement/internal/a;-><init>(Lcom/google/android/gms/measurement/internal/a2;Ljava/lang/String;J)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo p2, "mtsg i adye ot utednsnnum nr-  tiqisp"

    const-string/jumbo p2, "yasunnstqp  no tnidu geirm t d bm-iet"

    const/4 v3, 0x5

    const-string/jumbo p2, "t imetbndtert-mnpo g Aisany duu nm si"

    const-string p2, "Ad unit id must be a non-empty string"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public final m(Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->a()Lcom/google/android/gms/measurement/internal/w4;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v1, Lcom/google/android/gms/measurement/internal/y;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/google/android/gms/measurement/internal/y;-><init>(Lcom/google/android/gms/measurement/internal/a2;Ljava/lang/String;J)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/w4;->z(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p2, "ptnboiut tsmdy idrnso Aa e- suitm nn "

    const-string/jumbo p2, "iosp  um- sr nddsAtnitug tbe nmtayn i"

    const/4 v3, 0x2

    const-string/jumbo p2, "toaimb bynAsg nus piui  dn-rnmttd  te"

    const-string p2, "Ad unit id must be a non-empty string"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public final n(J)V
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->K()Lcom/google/android/gms/measurement/internal/v7;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/v7;->t(Z)Lcom/google/android/gms/measurement/internal/o7;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/Long;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    sub-long v3, p1, v3

    const/4 v6, 0x2

    invoke-direct {p0, v2, v3, v4, v0}, Lcom/google/android/gms/measurement/internal/a2;->p(Ljava/lang/String;JLcom/google/android/gms/measurement/internal/o7;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/a2;->b:Ljava/util/Map;

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/google/android/gms/measurement/internal/a2;->d:J

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    sub-long v1, p1, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {p0, v1, v2, v0}, Lcom/google/android/gms/measurement/internal/a2;->o(JLcom/google/android/gms/measurement/internal/o7;)V

    :cond_1
    const/4 v6, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/measurement/internal/a2;->q(J)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method
