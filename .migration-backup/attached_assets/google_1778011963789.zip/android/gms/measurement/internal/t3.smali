.class public final Lcom/google/android/gms/measurement/internal/t3;
.super Lcom/google/android/gms/measurement/internal/r9;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/measurement/internal/ba;)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/r9;-><init>(Lcom/google/android/gms/measurement/internal/ba;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected final l()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public final m()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/r9;->i()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "viscetticons"

    const-string/jumbo v1, "tnsevtniicoc"

    const/4 v3, 0x0

    const-string/jumbo v1, "octmitineyvc"

    const-string v1, "connectivity"

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    check-cast v0, Landroid/net/ConnectivityManager;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x5

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    return v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method
