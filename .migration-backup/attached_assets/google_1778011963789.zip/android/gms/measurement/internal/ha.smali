.class public final Lcom/google/android/gms/measurement/internal/ha;
.super Lcom/google/android/gms/measurement/internal/u5;


# static fields
.field private static final g:[Ljava/lang/String;

.field private static final h:[Ljava/lang/String;

.field public static final synthetic i:I


# instance fields
.field private c:Ljava/security/SecureRandom;

.field private final d:Ljava/util/concurrent/atomic/AtomicLong;

.field private e:I

.field private f:Ljava/lang/Integer;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v0, "o_soslg"

    const-string/jumbo v0, "ols_ggo"

    const/4 v4, 0x4

    const-string v0, "gogml_e"

    const-string v0, "google_"

    const/4 v3, 0x6

    move v4, v3

    const-string v1, "_ag"

    const-string v1, "_ga"

    const/4 v4, 0x0

    const-string v1, "ga_"

    const-string v1, "ga_"

    const/4 v4, 0x2

    const-string v2, "emiaoe_rb"

    const-string/jumbo v2, "r_emibesa"

    const/4 v4, 0x1

    const-string v2, "as_bebfei"

    const-string v2, "firebase_"

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/gms/measurement/internal/ha;->g:[Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, "err_"

    const-string v0, "e_rr"

    const/4 v4, 0x0

    const-string v0, "err_"

    const-string v0, "_err"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    sput-object v0, Lcom/google/android/gms/measurement/internal/ha;->h:[Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method

.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/u5;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x4

    move v3, v2

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/ha;->f:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p1, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method static V(Ljava/lang/String;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ub ~4auv @sS@ .@ @@o@rft~@@i t~@ ~@f@~  ~~o @n di~m b~i~o@~ y/ ~o~@ ~~~ ~lMK/~ 1 b@@@oc~~l-@o~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "_"

    const/4 v2, 0x6

    const-string v0, "_"

    const-string v0, "_"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    const/4 p0, 0x1

    or-int/2addr v2, p0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p0
.end method

.method static W(Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v0, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 v2, 0x5f

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ne v1, v2, :cond_1

    const/4 v4, 0x6

    const-string v1, "ep_"

    const-string/jumbo v1, "p_e"

    const/4 v4, 0x4

    const-string v1, "_ep"

    const-string v1, "_ep"

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p0
.end method

.method static X(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v2, Landroid/content/ComponentName;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v3, "nume.napoeieeimmtee.drgsmmtvoer.ac.opAg.opoRrrMsdsncgeleu"

    const-string/jumbo v3, "peMlom.tcm.eo.ragnmeepermvAgcsoearsi.nRugedi.mrodtnseouae"

    const/4 v5, 0x7

    const-string v3, "a.er.stmqoosopetggeeuc.Rii.Mrv.eAagmrnesancnpedemlmroemdu"

    const-string v3, "com.google.android.gms.measurement.AppMeasurementReceiver"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v2, p0, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getReceiverInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-boolean p0, p0, Landroid/content/pm/ActivityInfo;->enabled:Z
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 p0, 0x1

    move v5, p0

    const/4 v4, 0x6

    and-int/2addr v5, v4

    return p0

    :catch_0
    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v0
.end method

.method static Y(Landroid/content/Context;Z)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/16 v0, 0x18

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-lt p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo p1, "o.drgbe.psnagcbe.imvcortslpo.deAmeoumgnrMoiete.umenaaJemsre"

    const/4 v2, 0x2

    const-string/jumbo p1, "npsord.uamrS.si.McgelseeJectietmseo.mn.gumAmaorroebopgeeadv"

    const-string p1, "com.google.android.gms.measurement.AppMeasurementJobService"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->i0(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string p1, "g.amnndrsemmerirSd.rmot.cmposigseeotue.oAvua.lmpegeaceMe"

    const-string/jumbo p1, "or.eAeumSm.peacs.Mivld.easicemeorogsueogutnedg.ernmpratm"

    const/4 v2, 0x0

    const-string/jumbo p1, "rmo.o.rclgrdsdeemnAacmpom.aeSermus.nvpu.nieeeMgiteogtaos"

    const-string p1, "com.google.android.gms.measurement.AppMeasurementService"

    const/4 v1, 0x4

    move v2, v1

    invoke-static {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->i0(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p0
.end method

.method static Z(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-nez p0, :cond_1

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-nez p0, :cond_2

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x0

    return p0

    :cond_2
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method public static a0(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x7

    sget-object v0, Lcom/google/android/gms/measurement/internal/ha;->h:[Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    aget-object v0, v0, v1

    const/4 v2, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p0
.end method

.method static final d0(Landroid/os/Bundle;I)Z
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v0, "re_r"

    const-string v0, "_err"

    const/4 v6, 0x0

    const-string/jumbo v0, "r_re"

    const-string v0, "_err"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    cmp-long v1, v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    if-nez v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    int-to-long v1, p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 p0, 0x1

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    return p0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 p0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    return p0
.end method

.method static final e0(Ljava/lang/String;)Z
    .locals 3
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const-string v0, "a.^d:bc-p1a]0p+a(p*:p[)f-di-|b/9/:uoa-$rn+"

    const-string v0, ":^-*o$[pd/a1/+--appfa]+.n(0acb:i)ru--9dp:|"

    const/4 v2, 0x7

    const-string v0, "-]^:dnu9*//ao.|p(+au-rfdda+0pi:-c-):a1-p[b"

    const-string v0, "^(1:\\d+:android:[a-f0-9]+|ca-app-pub-.*)$"

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p0
.end method

.method private final f0(Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "l_ld"

    const-string v0, "_lld"

    const/4 v4, 0x7

    const-string v0, "dl_l"

    const-string v0, "_ldl"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/16 p1, 0x800

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v0, "_di"

    const-string v0, "i_d"

    const/4 v4, 0x0

    const-string v0, "_id"

    const-string v0, "_id"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v2, Lcom/google/android/gms/measurement/internal/z2;->d0:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v0, "cqidl_g"

    const/4 v4, 0x7

    const-string/jumbo v0, "p_ldigl"

    const-string v0, "_lgclid"

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/16 p1, 0x64

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 p1, 0x24

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_2
    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 p1, 0x100

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    return p1
.end method

.method private final g0(ILjava/lang/Object;ZZ)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    instance-of v1, p2, Ljava/lang/Long;

    const/4 v3, 0x6

    if-nez v1, :cond_e

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    instance-of v1, p2, Ljava/lang/Double;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto/16 :goto_3

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, p2, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast p2, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-long p1, p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    instance-of v1, p2, Ljava/lang/Byte;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x4

    check-cast p2, Ljava/lang/Byte;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/Byte;->byteValue()B

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-long p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, p2, Ljava/lang/Short;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p2, Ljava/lang/Short;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/Short;->shortValue()S

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    int-to-long p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, p2, Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_6

    const/4 v3, 0x1

    check-cast p2, Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eq p2, p1, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x6

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v2, 0x6

    move v3, v2

    goto :goto_0

    :cond_5
    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-wide/16 p1, 0x1

    const-wide/16 p1, 0x1

    const/4 v3, 0x5

    const-wide/16 p1, 0x1

    const-wide/16 p1, 0x1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    return-object p1

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, p2, Ljava/lang/Float;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_7

    const/4 v3, 0x2

    const/4 v2, 0x1

    check-cast p2, Ljava/lang/Float;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/Float;->doubleValue()D

    move-result-wide p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1

    :cond_7
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, p2, Ljava/lang/String;

    const/4 v3, 0x1

    if-nez v1, :cond_d

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, p2, Ljava/lang/Character;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_d

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    instance-of v1, p2, Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_8

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto/16 :goto_2

    :cond_8
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p4, :cond_c

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of p1, p2, [Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p1, :cond_9

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of p1, p2, [Landroid/os/Parcelable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p1, :cond_c

    :cond_9
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    check-cast p2, [Landroid/os/Parcelable;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    array-length p3, p2

    const/4 v3, 0x7

    const/4 p4, 0x0

    const/4 v3, 0x0

    move v2, p4

    move v2, p4

    :goto_1
    const/4 v3, 0x2

    if-ge p4, p3, :cond_b

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    aget-object v0, p2, p4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v1, v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_a

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/gms/measurement/internal/ha;->u0(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v1, :cond_a

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_a
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 p4, p4, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    goto :goto_1

    :cond_b
    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-array p2, p2, [Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p1, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    return-object p1

    :cond_c
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_d
    :goto_2
    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, p2, p1, p3}, Lcom/google/android/gms/measurement/internal/ha;->q(Ljava/lang/String;IZ)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :cond_e
    :goto_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p2
.end method

.method private static h0(Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    array-length v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x0

    or-int/2addr v5, v1

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    aget-object v3, p1, v2

    const/4 v4, 0x1

    move v5, v4

    invoke-static {p0, v3}, Lcom/google/android/gms/measurement/internal/ha;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 p0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    return p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    return v1
.end method

.method private static i0(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v2, Landroid/content/ComponentName;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v2, p0, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getServiceInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ServiceInfo;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-boolean p0, p0, Landroid/content/pm/ServiceInfo;->enabled:Z
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    if-eqz p0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return p0

    :catch_0
    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method static q0([B)J
    .locals 10
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    array-length v0, p0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-lez v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    move v2, v1

    move v2, v1

    const/4 v9, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-ltz v0, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    array-length v4, p0

    const/4 v8, 0x1

    move v9, v8

    add-int/lit8 v4, v4, -0x8

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-lt v0, v4, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    aget-byte v4, p0, v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    int-to-long v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-wide/16 v6, 0xff

    const-wide/16 v6, 0xff

    const/4 v9, 0x1

    const-wide/16 v6, 0xff

    const-wide/16 v6, 0xff

    const/4 v8, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    and-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    shl-long/2addr v4, v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    add-long/2addr v2, v4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    add-int/lit8 v1, v1, 0x8

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-wide v2
.end method

.method static s()Ljava/security/MessageDigest;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ge v0, v1, :cond_1

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "DM5"

    const-string v1, "5DM"

    const/4 v3, 0x5

    const-string v1, "D5M"

    const-string v1, "MD5"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    return-object v1

    :catch_0
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public static u(Ljava/util/List;)Ljava/util/ArrayList;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/google/android/gms/measurement/internal/zzab;",
            ">;)",
            "Ljava/util/ArrayList<",
            "Landroid/os/Bundle;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez p0, :cond_0

    const/4 v7, 0x1

    new-instance p0, Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-object p0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v1, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    check-cast v1, Lcom/google/android/gms/measurement/internal/zzab;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v2, Landroid/os/Bundle;

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->a:Ljava/lang/String;

    const/4 v7, 0x3

    const-string/jumbo v4, "paq_pd"

    const-string v4, "a_sppd"

    const/4 v7, 0x4

    const-string/jumbo v4, "pasp_d"

    const-string v4, "app_id"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v3, "oirmin"

    const-string/jumbo v3, "origin"

    const/4 v7, 0x5

    const/4 v6, 0x7

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/zzab;->b:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v3, "esitocet_aimratnmm"

    const-string/jumbo v3, "tncmpemimtar_aeist"

    const/4 v7, 0x1

    const-string/jumbo v3, "tm_inbtriceepoaamt"

    const-string v3, "creation_timestamp"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-wide v4, v1, Lcom/google/android/gms/measurement/internal/zzab;->d:J

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v3, v3, Lcom/google/android/gms/measurement/internal/zzkv;->b:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string v4, "aenm"

    const-string/jumbo v4, "neam"

    const/4 v7, 0x2

    const-string v4, "aemn"

    const-string/jumbo v4, "name"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/zzkv;->y2()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v2, v3}, Lcom/google/android/gms/measurement/internal/w5;->b(Landroid/os/Bundle;Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v3, "uaecvt"

    const-string v3, "active"

    const/4 v7, 0x7

    iget-boolean v4, v1, Lcom/google/android/gms/measurement/internal/zzab;->e:Z

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->f:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string/jumbo v4, "ttgve_epn_eergriom"

    const-string/jumbo v4, "rtevon__eteiemngrg"

    const-string/jumbo v4, "me_tgg_vqeanteerin"

    const-string/jumbo v4, "trigger_event_name"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v2, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->g:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v4, "aes__db_nteemmveuton"

    const-string/jumbo v4, "idvnubm__tmenaeee_to"

    const/4 v7, 0x3

    const-string/jumbo v4, "me_maetu_t_tvmeinden"

    const-string/jumbo v4, "timed_out_event_name"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v5, v3, Lcom/google/android/gms/measurement/internal/zzat;->a:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    iget-object v3, v3, Lcom/google/android/gms/measurement/internal/zzat;->b:Lcom/google/android/gms/measurement/internal/zzar;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v4, "ivtdopmreetomn_eta_s_u"

    const-string/jumbo v4, "timed_out_event_params"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/zzar;->A2()Landroid/os/Bundle;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_2
    const/4 v7, 0x1

    const-string/jumbo v3, "rtrgibett_iogem"

    const-string v3, "gegtrtui_iotrem"

    const/4 v7, 0x4

    const-string/jumbo v3, "teiguruierg_tmo"

    const-string/jumbo v3, "trigger_timeout"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-wide v4, v1, Lcom/google/android/gms/measurement/internal/zzab;->h:J

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->i:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v3, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v4, "rege_tdpeevage_nptni"

    const-string v4, "ee_gdtnptenriavgeer_"

    const/4 v7, 0x1

    const-string v4, "erev_egnqadetgrenti_"

    const-string/jumbo v4, "triggered_event_name"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v5, v3, Lcom/google/android/gms/measurement/internal/zzat;->a:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v3, v3, Lcom/google/android/gms/measurement/internal/zzat;->b:Lcom/google/android/gms/measurement/internal/zzar;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v3, :cond_3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v4, "ee_an_etqirrgrvdamgtep"

    const/4 v7, 0x7

    const-string v4, "drsieegarpa_tsmtngvee_"

    const-string/jumbo v4, "triggered_event_params"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/zzar;->A2()Landroid/os/Bundle;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/zzab;->c:Lcom/google/android/gms/measurement/internal/zzkv;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-wide v3, v3, Lcom/google/android/gms/measurement/internal/zzkv;->c:J

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v5, "_tamgrperieidgtsmtm"

    const-string/jumbo v5, "misggirre_eattepmtd"

    const-string/jumbo v5, "prttosi_eeimredgatm"

    const-string/jumbo v5, "triggered_timestamp"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2, v5, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v3, "oimttb_mv_le"

    const-string v3, "_vtmetoilmi_"

    const/4 v7, 0x3

    const-string v3, "i_vtleuiomte"

    const-string/jumbo v3, "time_to_live"

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-wide v4, v1, Lcom/google/android/gms/measurement/internal/zzab;->j:J

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v7, 0x6

    iget-object v1, v1, Lcom/google/android/gms/measurement/internal/zzab;->k:Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v7, 0x6

    if-eqz v1, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v3, "e_odmetppnrie_vxae"

    const-string v3, "dneeo__ptinearexmv"

    const/4 v7, 0x1

    const-string/jumbo v3, "xnvnad_eqpr_eieete"

    const-string v3, "expired_event_name"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v4, v1, Lcom/google/android/gms/measurement/internal/zzat;->a:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v1, v1, Lcom/google/android/gms/measurement/internal/zzat;->b:Lcom/google/android/gms/measurement/internal/zzar;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v1, :cond_4

    const/4 v7, 0x1

    const-string v3, "aesbpriavmesnxprted_"

    const-string v3, "dpetabivxrams_eep_rn"

    const/4 v7, 0x3

    const-string/jumbo v3, "vspmxeieemnpr_adt_re"

    const-string v3, "expired_event_params"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/zzar;->A2()Landroid/os/Bundle;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v2, v3, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto/16 :goto_0

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-object v0
.end method

.method public static x(Lcom/google/android/gms/measurement/internal/o7;Landroid/os/Bundle;Z)V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x1

    const-string v0, "_si"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v1, "n_s"

    const-string/jumbo v1, "n_s"

    const/4 v5, 0x1

    const-string v1, "_sn"

    const-string v1, "_sn"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v2, "c_s"

    const-string v2, "_cs"

    const/4 v5, 0x7

    const-string v2, "_cs"

    const-string v2, "_sc"

    const/4 v5, 0x4

    if-eqz p1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p0, :cond_4

    const/4 v5, 0x3

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x6

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 p2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_3

    :cond_1
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/o7;->a:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/o7;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz p2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1, v2, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    goto :goto_2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    :goto_2
    const/4 v5, 0x1

    iget-wide v1, p0, Lcom/google/android/gms/measurement/internal/o7;->c:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :cond_4
    :goto_3
    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p1, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez p0, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v5, 0x5

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method final A(Lcom/google/android/gms/measurement/internal/ga;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x1

    invoke-static {v0, p3}, Lcom/google/android/gms/measurement/internal/ha;->d0(Landroid/os/Bundle;I)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p4, p5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 p4, 0x5

    const/4 p4, 0x6

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq p3, p4, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p4, 0x7

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq p3, p4, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 p4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ne p3, p4, :cond_2

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p3, "_el"

    const-string p3, "e_l"

    const/4 v3, 0x0

    const-string p3, "e_l"

    const-string p3, "_el"

    const/4 v3, 0x2

    const/4 v2, 0x2

    int-to-long p4, p6

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p3, p4, p5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo p3, "re_r"

    const-string p3, "_err"

    const/4 v3, 0x2

    const-string/jumbo p3, "r_er"

    const-string p3, "_err"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {p1, p2, p3, v0}, Lcom/google/android/gms/measurement/internal/ga;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v3, 0x4

    return-void
.end method

.method final B(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    instance-of v0, p3, Ljava/lang/Long;

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v0, p3, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    move v3, v2

    invoke-static {p3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v0, p3, Ljava/lang/Double;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    check-cast p3, Ljava/lang/Double;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    return-void

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v0, p3, [Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast p3, [Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, p2, p3}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p2, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p3, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Lcom/google/android/gms/measurement/internal/i3;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, " p .orueytunevlndNaepelteavetm I ena,  vieuap.aiytm tton pg"

    const-string/jumbo v0, "uIty tuipelu.n emerntvpavN  n  aoatl ared.tmvtpie yegeea,np"

    const/4 v3, 0x6

    const-string v0, "edepebtm rgaN   mtetatyIyp,eanntelpauna.ui vnv lpi .eovrett"

    const-string v0, "Not putting event parameter. Invalid value type. name, type"

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-virtual {p3, v0, p2, p1}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_6
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public final C(Lcom/google/android/gms/internal/measurement/zzcf;Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x5

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v0, "retrarunbounueooniE  aerwvlprlepa org  p"

    const-string/jumbo v0, "prre tapt ulioano ero eeavw nbprrlnoguEr"

    const/4 v3, 0x0

    const-string v0, "ar eervpperutrowrabgo trnluan iE el orop"

    const-string v0, "Error returning boolean value to wrapper"

    const/4 v3, 0x4

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public final D(Lcom/google/android/gms/internal/measurement/zzcf;Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/internal/measurement/zzcf;",
            "Ljava/util/ArrayList<",
            "Landroid/os/Bundle;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x1

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "n wl r gqirntEerueirstrbrtepoupr d nol"

    const/4 v3, 0x2

    const-string v0, "aiueeeEtqr  lrlttrn n idrrpobu ngsrwop"

    const-string v0, "Error returning bundle list to wrapper"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public final E(Lcom/google/android/gms/internal/measurement/zzcf;Landroid/os/Bundle;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p1, p2}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "evseprr lonrnaeg ow eErbptuu iu ntlrrsd"

    const-string/jumbo v0, "vrsteerdr  ra noaEne nilupgwerurbuol tp"

    const/4 v2, 0x3

    const-string/jumbo v0, "lvrmoerlruubtdn reniao eger rpuEta  npr"

    const-string v0, "Error returning bundle value to wrapper"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public final F(Lcom/google/android/gms/internal/measurement/zzcf;[B)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x2

    const-string/jumbo v1, "r"

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v0, v1, p2}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "iparoore yrrEerprm baerguat nwryr nto"

    const-string v0, " ebmgearna Eiy ryrr  ppretaronrtwrour"

    const/4 v3, 0x3

    const-string/jumbo v0, "poetrb prrgwe rt yoiana erbartrrnrEyu"

    const-string v0, "Error returning byte array to wrapper"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public final G(Lcom/google/android/gms/internal/measurement/zzcf;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x0

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :try_start_0
    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, "errEnrunitpuove rg a traioeuptw rnlo"

    const-string/jumbo v0, "inr o urnwt ioptproreEvael grareuntr"

    const/4 v3, 0x3

    const-string/jumbo v0, "inwr rnpureErp rgo e lrpaettoarni ut"

    const-string v0, "Error returning int value to wrapper"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public final H(Lcom/google/android/gms/internal/measurement/zzcf;J)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x3

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x7

    const-string p3, "envoiro qgtt nE pprenerbwrruraalrog l"

    const-string/jumbo p3, "rpr obo  rilaueElegv  prnrettagnrnorw"

    const/4 v3, 0x3

    const-string p3, "Error returning long value to wrapper"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2, p3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public final I(Lcom/google/android/gms/internal/measurement/zzcf;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v3, 0x2

    const-string/jumbo v1, "r"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Lcom/google/android/gms/internal/measurement/zzcf;->zzd(Landroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "nssgg  rreiaupuernEttaruwvo retiro rrpn"

    const-string v0, " rgunrurlrrunret ro Evaesptiwo iarengpt"

    const/4 v3, 0x4

    const-string v0, "a  mr uitrrtnrltgeaiEgospor vrpue rrenn"

    const-string v0, "Error returning string value to wrapper"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method final J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Landroid/os/Bundle;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v11, p4

    move-object/from16 v11, p4

    move-object/from16 v11, p4

    move-object/from16 v11, p4

    move-object/from16 v12, p5

    move-object/from16 v12, p5

    move-object/from16 v12, p5

    move-object/from16 v12, p5

    if-nez v11, :cond_0

    return-void

    :cond_0
    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    new-instance v0, Ljava/util/TreeSet;

    invoke-virtual/range {p4 .. p4}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v13

    const/4 v15, 0x0

    :cond_1
    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    check-cast v8, Ljava/lang/String;

    if-eqz v12, :cond_3

    invoke-interface {v12, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_1

    :cond_2
    const/4 v2, 0x0

    goto :goto_3

    :cond_3
    :goto_1
    if-nez p6, :cond_4

    invoke-virtual {v9, v8}, Lcom/google/android/gms/measurement/internal/ha;->m0(Ljava/lang/String;)I

    move-result v0

    goto :goto_2

    :cond_4
    const/4 v0, 0x0

    :goto_2
    if-nez v0, :cond_5

    invoke-virtual {v9, v8}, Lcom/google/android/gms/measurement/internal/ha;->l0(Ljava/lang/String;)I

    move-result v0

    :cond_5
    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_3
    if-eqz v2, :cond_7

    const/4 v0, 0x3

    if-ne v2, v0, :cond_6

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    goto :goto_4

    :cond_6
    const/4 v0, 0x0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    :goto_4
    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p4

    move-object/from16 v1, p4

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v11, v8}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    goto :goto_0

    :cond_7
    invoke-virtual {v11, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v9, v0}, Lcom/google/android/gms/measurement/internal/ha;->T(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v1, "elanoaeeneNssvart eei t areeimae,mhc apl Bu er,oadtnrn nertae pd .a;aoldawmsddn mpal cded mr "

    const-string/jumbo v1, "ta dsNnpla  p tidmdmderela reramrd a  veeetawaBsmuoe eepeas,l.ntaaramhene naccion, d l ernp;d"

    const-string v1, ".lndebrneiade mepaotdv le esna npilmccasm,rNddarmteaa r urea;tods amhm rpa  e ed  eew,ntenaaB"

    const-string v1, "Nested Bundle parameters are not allowed; discarded. event name, param name, child param name"

    move-object/from16 v7, p3

    move-object/from16 v7, p3

    move-object/from16 v7, p3

    move-object/from16 v7, p3

    invoke-virtual {v0, v1, v10, v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x16

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    move-object v14, v8

    move-object v14, v8

    goto :goto_5

    :cond_8
    move-object/from16 v7, p3

    move-object/from16 v7, p3

    move-object/from16 v7, p3

    move-object/from16 v7, p3

    invoke-virtual {v11, v8}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object/from16 v5, p4

    move-object/from16 v5, p4

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v7, p6

    move-object v14, v8

    move-object v14, v8

    move-object v14, v8

    move-object v14, v8

    move/from16 v8, v16

    move/from16 v8, v16

    move/from16 v8, v16

    move/from16 v8, v16

    invoke-virtual/range {v0 .. v8}, Lcom/google/android/gms/measurement/internal/ha;->O(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I

    move-result v0

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_5
    if-eqz v2, :cond_9

    const-string v0, "ev_"

    const-string v0, "e_v"

    const-string/jumbo v0, "v_e"

    const-string v0, "_ev"

    invoke-virtual {v0, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    invoke-virtual {v11, v14}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p4

    move-object/from16 v1, p4

    move-object/from16 v1, p4

    move-object/from16 v1, p4

    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v4, v14

    move-object v4, v14

    move-object v4, v14

    move-object v4, v14

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v11, v14}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_9
    invoke-static {v14}, Lcom/google/android/gms/measurement/internal/ha;->W(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/google/android/gms/measurement/internal/y5;->d:[Ljava/lang/String;

    invoke-static {v14, v0}, Lcom/google/android/gms/measurement/internal/ha;->h0(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    add-int/lit8 v15, v15, 0x1

    if-lez v15, :cond_1

    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    iget-object v1, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v1

    invoke-virtual {v1, v10}, Lcom/google/android/gms/measurement/internal/i3;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v2

    invoke-virtual {v2, v11}, Lcom/google/android/gms/measurement/internal/i3;->b(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "umtotmu toere naiapscatnmncnIqota e s"

    const-string/jumbo v3, "no ani aqctaem tr mansctoetutrnIpoesm"

    const-string v3, "  emesnpmtaatasrpnucetcrtco noI ioamt"

    const-string v3, "Item cannot contain custom parameters"

    invoke-virtual {v0, v3, v1, v2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x17

    invoke-static {v11, v0}, Lcom/google/android/gms/measurement/internal/ha;->d0(Landroid/os/Bundle;I)Z

    invoke-virtual {v11, v14}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_a
    return-void
.end method

.method final K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/ha;->e0(Ljava/lang/String;)Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez p2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->q()Z

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p3, "inoIpelSqlil.eaagaspdsei/dan .lsatte dto dAeoFdhrporl.iO_ bggoi iNdpdsei.e/v:/ AO _ bsIgOy"

    const-string p3, "Aistsl dSl _i aaold.ideOghdcyalvbeeIdiagletepFApiei/a pON/_tso on .dnre.sgb d. /igpIor:oOs"

    const/4 v4, 0x3

    const-string p3, "des.ibae dI.FApt_/seeOova.A lilhcieSgln/os:s ngdr./aigoltdopi ly Nd_pOdIovpadt biaOes i er"

    const-string p3, "Invalid google_app_id. Firebase Analytics disabled. See https://goo.gl/NAOOOI. provided id"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2, p3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x2

    return v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzom;->zzc()Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v2, Lcom/google/android/gms/measurement/internal/z2;->e0:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v2}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p1, :cond_3

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-nez p1, :cond_4

    const/4 v4, 0x2

    invoke-static {p2}, Lcom/google/android/gms/measurement/internal/ha;->e0(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string p3, "_yAmIamnd.a lsoatpdcib pdmeldalnisi_db v."

    const-string/jumbo p3, "mesmsiIdt illi ocypdnaab_.vid la.dpa_dbnA"

    const/4 v4, 0x4

    const-string p3, "Invalid admob_app_id. Analytics disabled."

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p2}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1, p3, p2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x6

    or-int/2addr v4, v3

    return v1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->q()Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz p1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string p2, "Oradoi ogl  l seia/__ay.diehioNstpegAsbdsOOsaoen. n:pgellbtiASg/etIM/ c.oogis"

    const-string p2, "eAgsopan _dbMe aeoI.gpi/pgoetsdiaAShilogslntils/ic absdl_OtyOiNg oe..:/ Osr e"

    const/4 v4, 0x1

    const-string p2, "bls pb_NOabagpoaASAFOgi/ s do oOe.cnsari tpgio:ieidIygltsdsMie_ehtl/nle/.eg s"

    const-string p2, "Missing google_app_id. Firebase Analytics disabled. See https://goo.gl/NAOOOI"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v1
.end method

.method final L(Ljava/lang/String;ILjava/lang/String;)Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez p3, :cond_0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p3, " tlN b enpau/arTicdbnenmyesqaee d/ru .li "

    const/4 v4, 0x4

    const-string p3, "e eetiuTda .n lq a r/dersa pc/num leubyni"

    const-string p3, "Name is required and can\'t be null. Type"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, p3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p3, v0, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-le v1, p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "m pela,porgsaxdn . mmaNmueihs otnlui e guteepympo  Ttn"

    const-string/jumbo v2, "mps   uenego l.roanaphsalot gxteiotTd ui, eemmmNy unmp"

    const/4 v4, 0x5

    const-string/jumbo v2, "mTnn  mmqg ouattg e it.aNleepouason mdophir,ex se yl,m"

    const-string v2, "Name is too long. Type, maximum supported length, name"

    const/4 v4, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, v2, p1, p2, p3}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 p1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return p1
.end method

.method final M(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez p4, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string p3, " isnmeu Tepaer a  uysr tNedql/n/bip ad.ln"

    const-string/jumbo p3, "rbp.al pitr//y sndT c unea min lNaeuee dq"

    const/4 v5, 0x1

    const-string p3, " mlm ualeb ry /ntadnNTr. auqn/eeeid siec "

    const-string p3, "Name is required and can\'t be null. Type"

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2, p3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p4}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object v1, Lcom/google/android/gms/measurement/internal/ha;->g:[Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    move v2, v0

    move v2, v0

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    move v5, v4

    if-ge v2, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    aget-object v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p4, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string p3, "f rro.sax e Tpimewedh rie eaeptmry,Nst vtqse"

    const-string p3, " rvt sehq .e m iaxer wiepTdsfyeNe,asamrttpre"

    const/4 v5, 0x6

    const-string p3, "ere sbraitireyvtpshT.erefa m n ewsNpt ,deam "

    const-string p3, "Name starts with reserved prefix. Type, name"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2, p3, p1, p4}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x7

    return v0

    :cond_1
    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz p2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {p4, p2}, Lcom/google/android/gms/measurement/internal/ha;->h0(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz p2, :cond_4

    const/4 v5, 0x4

    if-eqz p3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p4, p3}, Lcom/google/android/gms/measurement/internal/ha;->h0(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez p2, :cond_4

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string p3, "adpmseu,veme nN ir. areTesy "

    const-string p3, "aesrr e .seaemNep vdsnyTm ,i"

    const/4 v5, 0x2

    const-string p3, "e ,npyepse eve idrTms aNr.ma"

    const-string p3, "Name is reserved. Type, name"

    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2, p3, p1, p4}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    return p1
.end method

.method final N(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    if-nez p4, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    instance-of v1, p4, Ljava/lang/Long;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    instance-of v1, p4, Ljava/lang/Float;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v1, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x1

    instance-of v1, p4, Ljava/lang/Integer;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    instance-of v1, p4, Ljava/lang/Byte;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v1, :cond_4

    const/4 v4, 0x2

    instance-of v1, p4, Ljava/lang/Short;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    instance-of v1, p4, Ljava/lang/Boolean;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v1, :cond_4

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    instance-of v1, p4, Ljava/lang/Double;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    instance-of v1, p4, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    instance-of v1, p4, Ljava/lang/Character;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    instance-of v1, p4, Ljava/lang/CharSequence;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v3, 0x2

    move v4, v3

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v2

    :cond_3
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {p4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p4

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p4, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-le v1, p3, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result p4

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p4

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, "e le iadqd t,ld re nV lV lleua inaaiesmud to;,kogncsmgahove."

    const-string/jumbo v0, "su muedenei i,ieeda l V eo  V;rst,tdcn.khgl aamudov lolngaal"

    const/4 v4, 0x0

    const-string v0, "Value is too long; discarded. Value kind, name, value length"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p3, v0, p1, p2, p4}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    return v2

    :cond_4
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v0
.end method

.method final O(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I
    .locals 14
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            "Landroid/os/Bundle;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;ZZ)I"
        }
    .end annotation

    move-object v7, p0

    move-object v7, p0

    move-object/from16 v8, p3

    move-object/from16 v8, p3

    move-object/from16 v0, p4

    move-object/from16 v0, p4

    move-object/from16 v0, p4

    move-object/from16 v0, p4

    move-object/from16 v1, p5

    move-object/from16 v1, p5

    move-object/from16 v1, p5

    move-object/from16 v1, p5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual {p0, v0}, Lcom/google/android/gms/measurement/internal/ha;->T(Ljava/lang/Object;)Z

    move-result v2

    const-string/jumbo v3, "pamro"

    const-string/jumbo v3, "mpsaa"

    const-string/jumbo v3, "param"

    const/4 v4, 0x0

    if-eqz v2, :cond_7

    if-eqz p8, :cond_6

    sget-object v2, Lcom/google/android/gms/measurement/internal/y5;->c:[Ljava/lang/String;

    invoke-static {v8, v2}, Lcom/google/android/gms/measurement/internal/ha;->h0(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_0

    const/16 v0, 0x14

    return v0

    :cond_0
    iget-object v2, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->L()Lcom/google/android/gms/measurement/internal/w8;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/w8;->B()Z

    move-result v5

    if-nez v5, :cond_1

    goto :goto_0

    :cond_1
    iget-object v2, v2, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/ha;->o0()I

    move-result v2

    const v5, 0x310c4

    if-ge v2, v5, :cond_2

    const/16 v0, 0x19

    return v0

    :cond_2
    :goto_0
    iget-object v2, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    instance-of v2, v0, [Landroid/os/Parcelable;

    if-eqz v2, :cond_3

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    check-cast v5, [Landroid/os/Parcelable;

    array-length v5, v5

    goto :goto_1

    :cond_3
    instance-of v5, v0, Ljava/util/ArrayList;

    if-eqz v5, :cond_7

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    check-cast v5, Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    :goto_1
    const/16 v6, 0xc8

    if-le v5, v6, :cond_7

    iget-object v9, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v9

    const-string v10, "Parameter array is too long; discarded. Value kind, name, array length"

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v9, v10, v3, v8, v5}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v5, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v5, 0x11

    if-eqz v2, :cond_4

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    check-cast v2, [Landroid/os/Parcelable;

    array-length v9, v2

    if-le v9, v6, :cond_5

    invoke-static {v2, v6}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Landroid/os/Parcelable;

    invoke-virtual {v1, v8, v2}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    goto :goto_2

    :cond_4
    instance-of v2, v0, Ljava/util/ArrayList;

    if-eqz v2, :cond_5

    move-object v2, v0

    move-object v2, v0

    check-cast v2, Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-le v9, v6, :cond_5

    new-instance v9, Ljava/util/ArrayList;

    invoke-virtual {v2, v4, v6}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v2

    invoke-direct {v9, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1, v8, v9}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_5
    :goto_2
    move v9, v5

    move v9, v5

    move v9, v5

    move v9, v5

    goto :goto_3

    :cond_6
    const/16 v0, 0x15

    return v0

    :cond_7
    move v9, v4

    move v9, v4

    move v9, v4

    :goto_3
    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v1

    sget-object v2, Lcom/google/android/gms/measurement/internal/z2;->T:Lcom/google/android/gms/measurement/internal/y2;

    move-object v10, p1

    move-object v10, p1

    move-object v10, p1

    move-object v10, p1

    invoke-virtual {v1, p1, v2}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-static/range {p2 .. p2}, Lcom/google/android/gms/measurement/internal/ha;->V(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_9

    :cond_8
    invoke-static/range {p3 .. p3}, Lcom/google/android/gms/measurement/internal/ha;->V(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_a

    :cond_9
    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v1, 0x100

    goto :goto_4

    :cond_a
    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/16 v1, 0x64

    :goto_4
    invoke-virtual {p0, v3, v8, v1, v0}, Lcom/google/android/gms/measurement/internal/ha;->N(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    return v9

    :cond_b
    if-eqz p8, :cond_12

    instance-of v1, v0, Landroid/os/Bundle;

    if-eqz v1, :cond_c

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    check-cast v4, Landroid/os/Bundle;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    invoke-virtual/range {v0 .. v6}, Lcom/google/android/gms/measurement/internal/ha;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    goto/16 :goto_8

    :cond_c
    instance-of v1, v0, [Landroid/os/Parcelable;

    if-eqz v1, :cond_e

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    check-cast v11, [Landroid/os/Parcelable;

    array-length v12, v11

    move v13, v4

    :goto_5
    if-ge v13, v12, :cond_11

    aget-object v0, v11, v13

    instance-of v1, v0, Landroid/os/Bundle;

    if-nez v1, :cond_d

    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v2, " .em]elPclp ,tmu mVtuyue esyolrplsle  eeb ae nnneAbtfa a lBbm[edle"

    const-string v2, "V ]mlbt eub nltl nAeey sleeecd byeP ap.Bl olfepat uet eems[m,rnaul"

    const-string v2, "All Parcelable[] elements must be of type Bundle. Value type, name"

    invoke-virtual {v1, v2, v0, v8}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_9

    :cond_d
    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    check-cast v4, Landroid/os/Bundle;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    invoke-virtual/range {v0 .. v6}, Lcom/google/android/gms/measurement/internal/ha;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_5

    :cond_e
    instance-of v1, v0, Ljava/util/ArrayList;

    if-eqz v1, :cond_12

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    check-cast v11, Ljava/util/ArrayList;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v12

    move v13, v4

    move v13, v4

    move v13, v4

    :goto_6
    if-ge v13, v12, :cond_11

    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Landroid/os/Bundle;

    if-nez v1, :cond_10

    iget-object v1, v7, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    if-eqz v0, :cond_f

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    goto :goto_7

    :cond_f
    const-string/jumbo v0, "unll"

    const-string/jumbo v0, "null"

    const-string/jumbo v0, "ulln"

    const-string/jumbo v0, "null"

    :goto_7
    const-string v2, " seyoe aytA e t nelflLmruea,oe urudlt y.tAnnlVi Bu pelsmebep mt"

    const-string/jumbo v2, "lmu tVuueAre .yLeaeely nee leAetnoanpi  r ,m  utlyssalBtmptf bd"

    const-string/jumbo v2, "u rd,be eaylayB  nesp yutsAttapi  Atm  te.nslVfelolnm lumeeeLbe"

    const-string v2, "All ArrayList elements must be of type Bundle. Value type, name"

    invoke-virtual {v1, v2, v0, v8}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_9

    :cond_10
    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    check-cast v4, Landroid/os/Bundle;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v5, p6

    move-object/from16 v5, p6

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    move/from16 v6, p7

    invoke-virtual/range {v0 .. v6}, Lcom/google/android/gms/measurement/internal/ha;->J(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)V

    add-int/lit8 v13, v13, 0x1

    goto :goto_6

    :cond_11
    :goto_8
    return v9

    :cond_12
    :goto_9
    const/4 v0, 0x4

    return v0
.end method

.method final P(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x0

    if-nez p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v1, "r  td.ub iN emql n/ pce/idyuelarepneTun s"

    const-string/jumbo v1, "q   /pep/yrilsde da.e nNareuum leitnc bTn"

    const/4 v7, 0x6

    const-string/jumbo v1, "ue rpadp/ delnbTinuneayc .eN ei ast/r  ql"

    const-string v1, "Name is required and can\'t be null. Type"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p2, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    return v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-nez v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v1, "meryq abq s/T ptN/au  dtaermqd.eee einnyc "

    const-string/jumbo v1, "ptdeb asqcT qtnapuNmeeanyr /iedr e  m e/y."

    const/4 v7, 0x3

    const-string v1, "eysmeat.i ra msqpd bn diN /  treeyn/aepuTe"

    const-string v1, "Name is required and can\'t be empty. Type"

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    return v0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/String;->codePointAt(I)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v1}, Ljava/lang/Character;->isLetter(I)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/16 v3, 0x5f

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-nez v2, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-ne v1, v3, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v1, v3

    move v1, v3

    const/4 v7, 0x5

    move v1, v3

    move v1, v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v2, "t,am e asprhntl myea_tNT eesodtertt c wirerm(ne. uaor)mus  "

    const-string/jumbo v2, "snsah (e,rNrp mt atia eT rme ronulmtou eay)we c  .tertst_ed"

    const/4 v7, 0x0

    const-string/jumbo v2, "y)tiootcr tl.aeerNas et hsmet Trmra,e  wnenr( ou dta_mpsu e"

    const-string v2, "Name must start with a letter or _ (underscore). Type, name"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, v2, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    return v0

    :cond_3
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    move-result v1

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-ge v1, v2, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/String;->codePointAt(I)I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eq v4, v3, :cond_5

    const/4 v7, 0x0

    invoke-static {v4}, Ljava/lang/Character;->isLetterOrDigit(I)Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v5, :cond_4

    const/4 v7, 0x0

    goto :goto_2

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v2, "eml pbsimeteesoscseT Nc,uuty i amf_endramsrnser t o(, n .droi o) ts"

    const-string v2, "e  mnmusnmetuscoicos ee.idfel  sireg_yso tm(e a,,Nts)Tror p dtnra s"

    const/4 v7, 0x6

    const-string/jumbo v2, "nedou uiimeeTofge( cta scl s,t.trmyrs,e  Nutom _dais )tesnosserr  n"

    const-string v2, "Name must consist of letters, digits or _ (underscores). Type, name"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v2, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    return v0

    :cond_5
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v4}, Ljava/lang/Character;->charCount(I)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    add-int/2addr v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_6
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 p1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    return p1
.end method

.method final Q(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x4

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez p2, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v1, "ysoenn puniNlm/aau .c elqd er bptar eTe /"

    const-string v1, "/erdordes e y.batlNc  ep  qaeu/T ailumnnn"

    const/4 v6, 0x2

    const-string/jumbo v1, "tyl spa q ardNiT  rnq cnaed/in/uuem leeeb"

    const-string v1, "Name is required and can\'t be null. Type"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p2, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v1, " esN neyy m pie rdd.bi /aemTtnaasqr /cpetb"

    const-string v1, "e    b/d sTb/.rapaar cptnenetm ydeiimeqyeN"

    const/4 v6, 0x1

    const-string v1, "dmcmpi nt ae/mTbnep/ qyayer  s.Nee dratiu "

    const-string v1, "Name is required and can\'t be empty. Type"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p2, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    return v0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/String;->codePointAt(I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/Character;->isLetter(I)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v2, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v2, "tanyotmT ,aatspi eetu wlh.rmemras tue t e"

    const-string/jumbo v2, "lart tue tyap inm,e Ttareemmwtse uaths. N"

    const/4 v6, 0x7

    const-string/jumbo v2, "tpNm b ha er,mti.elt  t tuayestanema eTsr"

    const-string v2, "Name must start with a letter. Type, name"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return v0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v1}, Ljava/lang/Character;->charCount(I)I

    move-result v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v1, v2, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/String;->codePointAt(I)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/16 v4, 0x5f

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq v3, v4, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v3}, Ljava/lang/Character;->isLetterOrDigit(I)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v4, :cond_3

    const/4 v5, 0x1

    move v6, v5

    goto :goto_1

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v2, "esesfouT r eg (_,mstoep ,Ndssmiyl)rcet r deniusaot a.s ittm  nonucr"

    const-string v2, "Name must consist of letters, digits or _ (underscores). Type, name"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1, v2, p1, p2}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v0

    :cond_4
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-static {v3}, Ljava/lang/Character;->charCount(I)I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    add-int/2addr v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_5
    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 p1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    return p1
.end method

.method final R(Ljava/lang/String;)Z
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/wrappers/c;->a(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    return p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->q()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "Poa sdnpttgriro neemis"

    const-string v1, "Permission not granted"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 p1, 0x0

    move v3, p1

    const/4 v2, 0x5

    move v3, v2

    return p1
.end method

.method final S(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->u()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->d()Lcom/google/android/gms/measurement/internal/b;

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p1
.end method

.method final T(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    instance-of v0, p1, [Landroid/os/Parcelable;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of v0, p1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    instance-of p1, p1, Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method final U(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljavax/security/auth/x500/X500Principal;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "piNinSodqgoCO =,rerddbu=AD,dUCA"

    const-string v1, "CiDdgeNp= bn,SioAduO,=UoCd=rrdA"

    const/4 v3, 0x7

    const-string/jumbo v1, "iesOddidDS ,bArNCdroo,A=nn=gU=u"

    const-string v1, "CN=Android Debug,O=Android,C=US"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljavax/security/auth/x500/X500Principal;-><init>(Ljava/lang/String;)V

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 v1, 0x40

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, p2, v1}, Lcom/google/android/gms/common/wrappers/c;->f(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    or-int/2addr v3, v2

    array-length p2, p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lez p2, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p2, 0x0

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    aget-object p1, p1, p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string p2, "05.mX"

    const-string p2, "5X.q0"

    const/4 v3, 0x7

    const-string p2, ".90Xo"

    const-string p2, "X.509"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v2, 0x3

    or-int/2addr v3, v2

    invoke-virtual {p2, v1}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p1, Ljava/security/cert/X509Certificate;

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/security/cert/X509Certificate;->getSubjectX500Principal()Ljavax/security/auth/x500/X500Principal;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljavax/security/auth/x500/X500Principal;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catch Ljava/security/cert/CertificateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p1

    :catch_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "mdegPbontananukc oa e "

    const-string/jumbo v0, "oksodaeg tnamceP un an"

    const/4 v3, 0x5

    const-string/jumbo v0, "kmendouncte ofaPaag  n"

    const-string v0, "Package name not found"

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :catch_1
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "rnbmcioiainraifg o ectterrE"

    const/4 v3, 0x0

    const-string v0, "Eioita pe rtiifcaergnontrrb"

    const-string v0, "Error obtaining certificate"

    const/4 v3, 0x5

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p1
.end method

.method final b0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v3

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez p1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p3, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v2

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v3

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez p1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    return v2

    :cond_4
    const/4 v4, 0x6

    return v3

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v0, :cond_9

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    if-eqz p1, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x2

    return v3

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez p1, :cond_8

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p3, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez p1, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_7
    const/4 v5, 0x1

    return v3

    :cond_8
    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v2

    :cond_9
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-nez p1, :cond_b

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {p3, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez p1, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_1

    :cond_a
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v3

    :cond_b
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v2
.end method

.method final c0(Landroid/os/Parcelable;)[B
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p1, v0, v1}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->marshall()[B

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x3

    throw p1
.end method

.method protected final i()V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v0, Ljava/security/SecureRandom;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    move-result-wide v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    cmp-long v5, v1, v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez v5, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/Random;->nextLong()J

    move-result-wide v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    cmp-long v0, v1, v3

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v3, "dniainlaq tolRmogUm dtc knosdaaio  f b rlf"

    const-string v3, "Utils falling back to Random for random id"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v3}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-void
.end method

.method protected final j()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    return v0
.end method

.method final j0(Ljava/lang/String;Ljava/lang/Object;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v0, "dl_l"

    const-string/jumbo v0, "l_dl"

    const/4 v3, 0x7

    const-string/jumbo v0, "l_dl"

    const-string v0, "_ldl"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string v0, " ssru rfpeoepeerretyrr"

    const-string v0, "eepeo euryrf rrprosret"

    const-string v0, " tsmrrpyurpfe oeeeerrr"

    const-string/jumbo v0, "user property referrer"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->f0(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0, p1, v1, p2}, Lcom/google/android/gms/measurement/internal/ha;->N(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v0, "y spobtrrurpe"

    const-string/jumbo v0, "rre rbopsutyp"

    const/4 v3, 0x4

    const-string/jumbo v0, "rp ypbouerers"

    const-string/jumbo v0, "user property"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->f0(Ljava/lang/String;)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0, p1, v1, p2}, Lcom/google/android/gms/measurement/internal/ha;->N(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Z

    move-result p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    move v3, v2

    const/4 p1, 0x0

    move v3, p1

    return p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x7

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1
.end method

.method final k0(Ljava/lang/String;)I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v0, "uuene"

    const-string v0, "euven"

    const/4 v5, 0x1

    const-string/jumbo v0, "ntpee"

    const-string v0, "event"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->P(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object v1, Lcom/google/android/gms/measurement/internal/x5;->a:[Ljava/lang/String;

    const/4 v4, 0x6

    move v5, v4

    sget-object v3, Lcom/google/android/gms/measurement/internal/x5;->b:[Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v1, v3, p1}, Lcom/google/android/gms/measurement/internal/ha;->M(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/16 p1, 0xd

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    return p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v1, 0x28

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->L(Ljava/lang/String;ILjava/lang/String;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    return v2

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    return p1
.end method

.method final l0(Ljava/lang/String;)I
    .locals 5

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v0, "vte aeapqrn"

    const-string/jumbo v0, "vaetam prne"

    const/4 v4, 0x4

    const-string/jumbo v0, "v saprnatee"

    const-string v0, "event param"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->P(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    return v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v1, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->M(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-nez v1, :cond_1

    const/4 v4, 0x2

    const/16 p1, 0xe

    const/4 v4, 0x4

    const/4 v3, 0x3

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/16 v1, 0x28

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->L(Ljava/lang/String;ILjava/lang/String;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v2

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    return p1
.end method

.method final m0(Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v0, "vnememp ara"

    const-string v0, "event param"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->Q(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v1, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->M(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 p1, 0xe

    const/4 v3, 0x5

    const/4 v4, 0x1

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 v1, 0x28

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->L(Ljava/lang/String;ILjava/lang/String;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_2

    const/4 v4, 0x5

    return v2

    :cond_2
    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    return p1
.end method

.method final n0(Ljava/lang/String;)I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v0, "preoo sypuret"

    const-string/jumbo v0, "user property"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->P(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x7

    return v2

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Lcom/google/android/gms/measurement/internal/z5;->a:[Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1, v3, p1}, Lcom/google/android/gms/measurement/internal/ha;->M(Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/16 p1, 0xf

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    return p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v1, 0x18

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/gms/measurement/internal/ha;->L(Ljava/lang/String;ILjava/lang/String;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v2

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return p1
.end method

.method final o(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v0, "_ev"

    const-string v0, "_ev"

    const/4 v4, 0x5

    const-string/jumbo v0, "v_e"

    const-string v0, "_ev"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/16 v1, 0x100

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0, v1, p2, v2, v2}, Lcom/google/android/gms/measurement/internal/ha;->g0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/ha;->V(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/16 v1, 0x64

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, v1, p2, p1, v2}, Lcom/google/android/gms/measurement/internal/ha;->g0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p1
.end method

.method public final o0()I
    .locals 4
    .annotation runtime Lq9/d;
        value = {
            "this.apkVersion"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->f:Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/g;->b(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    div-int/lit16 v0, v0, 0x3e8

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->f:Ljava/lang/Integer;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->f:Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v0
.end method

.method final p(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x5

    const-string v0, "_lld"

    const-string/jumbo v0, "l_dl"

    const/4 v3, 0x4

    const-string v0, "_ldl"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->f0(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/google/android/gms/measurement/internal/ha;->g0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->f0(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, p1, p2, v1, v1}, Lcom/google/android/gms/measurement/internal/ha;->g0(ILjava/lang/Object;ZZ)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method

.method public final p0(I)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const v1, 0xbdfcb8

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/google/android/gms/common/g;->k(Landroid/content/Context;I)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method public final q(Ljava/lang/String;IZ)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v2, v1}, Ljava/lang/String;->codePointCount(II)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    if-le v1, p2, :cond_2

    const/4 v4, 0x1

    if-eqz p3, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v2, p2}, Ljava/lang/String;->offsetByCodePoints(II)I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v2, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string p2, "..."

    const-string p2, "..."

    const/4 v4, 0x5

    const-string p2, "..."

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1

    :cond_1
    const/4 v4, 0x7

    return-object v0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object p1
.end method

.method public final r(JLjava/lang/String;Ljava/lang/String;J)Ljava/net/URL;
    .locals 6

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p4}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 p1, 0x4

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 p2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-array v0, p2, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-wide/32 v1, 0xb3b0

    const-wide/32 v1, 0xb3b0

    const/4 v5, 0x1

    const-wide/32 v1, 0xb3b0

    const-wide/32 v1, 0xb3b0

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput-object v1, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/ha;->o0()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    aput-object v1, v0, v3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v1, "qs%%sb"

    const-string/jumbo v1, "vsqs%%"

    const/4 v5, 0x5

    const-string/jumbo v1, "uv%s%."

    const-string/jumbo v1, "v%s.%s"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    aput-object v0, p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    aput-object p4, p1, v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    aput-object p3, p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p5, p6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 p4, 0x3

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    aput-object p2, p1, p4

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string p2, "d/=det%pwddnt:ygddrabvuntsde/ap=tr&nge_er&el_erwsieiv%&s&sosciipmdgns=lekddrpv%.oic=oa/y/wn?a%p/eelsiaosss.=/ekporiisphd"

    const-string p2, "/psvacemwddpi/we.spespgd=pdnkdtygaie=rpasdlr%&d&trw%/./ee/n&linaseo=e_isdbcoy%ilnei?uas=r=s&d_:ronv/%hoetecgsditksodisrv"

    const/4 v5, 0x2

    const-string/jumbo p2, "tos&swmvq%/.adi=lnessedy?rns:_re_%udpdrdpwocia%pobpydsgclko/a=&w/d=korpve.l&&//rastcdh=td%engidpatoreiiseseivieedis=eng/"

    const-string p2, "https://www.googleadservices.com/pagead/conversion/app/deeplink?id_type=adid&sdk_version=%s&rdid=%s&bundleid=%s&retry=%s"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/f;->v()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-eqz p2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo p2, "tlseds1md&="

    const-string/jumbo p2, "s=dm_t1lde&"

    const/4 v5, 0x1

    const-string p2, "dltmst1_&d="

    const-string p2, "&ddl_test=1"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p2, Ljava/net/URL;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object p2

    :catch_0
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :catch_1
    move-exception p1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo p3, "pLeOoeDrntoocedrcfBLxr Uaodao eFDWe t.ienieeR rfikele  pt "

    const-string p3, "ef codiearlLcWotexFiee eno eDfDpr oORiL.trU dre B eakep nt"

    const/4 v5, 0x0

    const-string/jumbo p3, "pitdrb.iakeeOoBnDr L edF ecitaep n eWeclrefeorU  fxRt oD e"

    const-string p3, "Failed to create BOW URL for Deferred Deep Link. exception"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p2, p3, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x1

    return-object p1
.end method

.method public final r0()J
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    cmp-long v0, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v1, Ljava/util/Random;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->c()Lcom/google/android/gms/common/util/g;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v4}, Lcom/google/android/gms/common/util/g;->a()J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    xor-long/2addr v2, v4

    const/4 v6, 0x5

    move v7, v6

    invoke-direct {v1, v2, v3}, Ljava/util/Random;-><init>(J)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/Random;->nextLong()J

    move-result-wide v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget v3, p0, Lcom/google/android/gms/measurement/internal/ha;->e:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput v3, p0, Lcom/google/android/gms/measurement/internal/ha;->e:I

    const/4 v6, 0x5

    move v7, v6

    int-to-long v3, v3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    add-long/2addr v1, v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-wide v1

    :catchall_0
    move-exception v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    throw v1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    monitor-enter v0

    :try_start_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x6

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v3, v4, v5}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/ha;->d:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    move-result-wide v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    monitor-exit v0

    const/4 v7, 0x4

    return-wide v1

    :catchall_1
    move-exception v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x2

    throw v1
.end method

.method public final s0(JJ)J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-wide/32 v0, 0xea60

    const-wide/32 v0, 0xea60

    const/4 v3, 0x1

    const-wide/32 v0, 0xea60

    const-wide/32 v0, 0xea60

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    mul-long/2addr p3, v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-long/2addr p1, p3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide/32 p3, 0x5265c00

    const-wide/32 p3, 0x5265c00

    const/4 v3, 0x2

    const-wide/32 p3, 0x5265c00

    const-wide/32 p3, 0x5265c00

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    div-long/2addr p1, p3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-wide p1
.end method

.method final t()Ljava/security/SecureRandom;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "this.secureRandom"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->c:Ljava/security/SecureRandom;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/security/SecureRandom;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->c:Ljava/security/SecureRandom;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/ha;->c:Ljava/security/SecureRandom;

    const/4 v2, 0x4

    return-object v0
.end method

.method final t0(Landroid/net/Uri;)Landroid/os/Bundle;
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz p1, :cond_c

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/net/Uri;->isHierarchical()Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v2, "bucil"

    const-string v2, "bdilc"

    const/4 v8, 0x1

    const-string v2, "gcpli"

    const-string v2, "gclid"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-eqz v1, :cond_0

    :try_start_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v1, "icummaanqp_g"

    const-string/jumbo v1, "pgcmnmutaia_"

    const/4 v8, 0x7

    const-string v1, "gustpacnmiam"

    const-string/jumbo v1, "utm_campaign"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v3, "espmrtucm_"

    const-string/jumbo v3, "m_stuecpor"

    const/4 v8, 0x5

    const-string/jumbo v3, "urucoso_me"

    const-string/jumbo v3, "utm_source"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v4, "mutqibdmmu"

    const-string v4, "dimtuu_mqm"

    const/4 v8, 0x7

    const-string/jumbo v4, "utm_medium"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p1, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_1
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_0

    :cond_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v6, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v6, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v6, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-object v0

    :cond_2
    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v6, :cond_3

    const-string v6, "gmasaiup"

    const-string/jumbo v6, "masgpian"

    const/4 v8, 0x3

    const-string/jumbo v6, "pmaganip"

    const-string v6, "campaign"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0, v6, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    if-nez v1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const-string v1, "cuqmro"

    const-string/jumbo v1, "rcomsu"

    const/4 v8, 0x0

    const-string/jumbo v1, "source"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v1, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v8, 0x7

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v1, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string/jumbo v1, "uesido"

    const-string/jumbo v1, "idmeou"

    const/4 v8, 0x1

    const-string v1, "emimdu"

    const-string/jumbo v1, "medium"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    const/4 v7, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-nez v1, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v0, v2, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    const/4 v7, 0x5

    const-string/jumbo v1, "ruetomtm"

    const-string/jumbo v1, "terutbmm"

    const/4 v8, 0x0

    const-string v1, "_utrtbmm"

    const-string/jumbo v1, "utm_term"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v2, :cond_7

    const/4 v8, 0x4

    const/4 v7, 0x4

    const-string/jumbo v2, "trem"

    const-string/jumbo v2, "tmer"

    const/4 v8, 0x4

    const-string/jumbo v2, "mtre"

    const-string/jumbo v2, "term"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo v1, "uuncenut_tt"

    const-string v1, "_octenutunt"

    const/4 v8, 0x2

    const-string/jumbo v1, "tuen_ncpott"

    const-string/jumbo v1, "utm_content"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-nez v2, :cond_8

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v2, "nqtcone"

    const-string v2, "content"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    const/4 v8, 0x7

    const/4 v7, 0x0

    const-string v1, "dcsla"

    const-string v1, "dcpal"

    const/4 v8, 0x6

    const-string v1, "iacml"

    const-string v1, "aclid"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-nez v3, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v1, "c1p"

    const-string/jumbo v1, "p1c"

    const/4 v8, 0x4

    const-string/jumbo v1, "pc1"

    const-string v1, "cp1"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v3, :cond_a

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_a
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v1, "inda"

    const-string v1, "dnia"

    const/4 v8, 0x1

    const-string/jumbo v1, "nida"

    const-string v1, "anid"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-nez v2, :cond_b

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_b
    const/4 v7, 0x6

    move v8, v7

    return-object v0

    :catch_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v2, "alsrolUr urftn icq ieanaIlRhsheial e Ircr/trr/"

    const-string/jumbo v2, "isrI lcfq ehcaih/UReuinlral arrrs rnaetIr/ l t"

    const/4 v8, 0x1

    const-string/jumbo v2, "sllenb eRairsiienrrhrcc ea l/ fU Iatrrh/utlI a"

    const-string v2, "Install referrer url isn\'t a hierarchical URI"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v1, v2, p1}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_c
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-object v0
.end method

.method final u0(Landroid/os/Bundle;)Landroid/os/Bundle;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v0, Landroid/os/Bundle;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    if-eqz p1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0, v2, v3}, Lcom/google/android/gms/measurement/internal/ha;->o(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-nez v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v4, v2}, Lcom/google/android/gms/measurement/internal/i3;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v4, "a/s/u ml Pvnacelre anbutla"

    const/4 v6, 0x1

    const-string/jumbo v4, "u uvlauPelanteba /  /cnlma"

    const-string v4, "Param value can\'t be null"

    invoke-virtual {v3, v4, v2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0, v0, v2, v3}, Lcom/google/android/gms/measurement/internal/ha;->B(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object v0
.end method

.method final v(Landroid/os/Bundle;J)V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v0, "_et"

    const-string v0, "e_t"

    const/4 v7, 0x0

    const-string/jumbo v0, "te_"

    const-string v0, "_et"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    cmp-long v5, v1, v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v5, :cond_0

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x5

    and-int/2addr v7, v6

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v4, "ngemadaegcare al rstiemnada ynPnoet"

    const/4 v7, 0x6

    const-string v4, "eearnntpnrim ae ynaelPocgdadgmaeat "

    const-string v4, "Params already contained engagement"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v3, v4, v5}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    move-wide v1, v3

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    add-long/2addr p2, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1, v0, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-void
.end method

.method final v0(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)Landroid/os/Bundle;
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Landroid/os/Bundle;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)",
            "Landroid/os/Bundle;"
        }
    .end annotation

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    move-object/from16 v12, p4

    move-object/from16 v12, p4

    move-object/from16 v12, p4

    move-object/from16 v12, p4

    sget-object v0, Lcom/google/android/gms/measurement/internal/x5;->d:[Ljava/lang/String;

    invoke-static {v10, v0}, Lcom/google/android/gms/measurement/internal/ha;->h0(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v13

    if-eqz v11, :cond_d

    new-instance v15, Landroid/os/Bundle;

    invoke-direct {v15, v11}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->m()I

    move-result v8

    new-instance v0, Ljava/util/TreeSet;

    invoke-virtual/range {p3 .. p3}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v16

    const/16 v17, 0x0

    move/from16 v18, v17

    :goto_0
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    check-cast v7, Ljava/lang/String;

    if-eqz v12, :cond_1

    invoke-interface {v12, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    move/from16 v2, v17

    move/from16 v2, v17

    move/from16 v2, v17

    move/from16 v2, v17

    goto :goto_3

    :cond_1
    :goto_1
    if-nez p5, :cond_2

    invoke-virtual {v9, v7}, Lcom/google/android/gms/measurement/internal/ha;->m0(Ljava/lang/String;)I

    move-result v0

    goto :goto_2

    :cond_2
    move/from16 v0, v17

    move/from16 v0, v17

    move/from16 v0, v17

    move/from16 v0, v17

    :goto_2
    if-nez v0, :cond_3

    invoke-virtual {v9, v7}, Lcom/google/android/gms/measurement/internal/ha;->l0(Ljava/lang/String;)I

    move-result v0

    :cond_3
    move v2, v0

    move v2, v0

    move v2, v0

    :goto_3
    if-eqz v2, :cond_5

    const/4 v0, 0x3

    if-ne v2, v0, :cond_4

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    goto :goto_4

    :cond_4
    const/4 v5, 0x0

    :goto_4
    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object v3, v7

    move-object v3, v7

    move-object v3, v7

    move-object v3, v7

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v15, v7}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    move v14, v8

    move v14, v8

    move v14, v8

    move v14, v8

    goto/16 :goto_7

    :cond_5
    invoke-virtual {v11, v7}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object v3, v7

    move-object v3, v7

    move-object v5, v15

    move-object v5, v15

    move-object v5, v15

    move-object v5, v15

    move-object/from16 v6, p4

    move-object/from16 v6, p4

    move-object/from16 v19, v7

    move-object/from16 v19, v7

    move-object/from16 v19, v7

    move-object/from16 v19, v7

    move/from16 v7, p5

    move/from16 v7, p5

    move/from16 v7, p5

    move/from16 v7, p5

    move v14, v8

    move v14, v8

    move v14, v8

    move v14, v8

    move v8, v13

    move v8, v13

    move v8, v13

    invoke-virtual/range {v0 .. v8}, Lcom/google/android/gms/measurement/internal/ha;->O(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;Landroid/os/Bundle;Ljava/util/List;ZZ)I

    move-result v2

    const/16 v0, 0x11

    if-ne v2, v0, :cond_6

    const/16 v2, 0x11

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object v1, v15

    move-object/from16 v3, v19

    move-object/from16 v3, v19

    move-object/from16 v3, v19

    move-object/from16 v3, v19

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_6

    :cond_6
    if-eqz v2, :cond_8

    const-string v0, "_ev"

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    const/16 v0, 0x15

    if-ne v2, v0, :cond_7

    move-object v3, v10

    move-object v3, v10

    move-object v3, v10

    goto :goto_5

    :cond_7
    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    :goto_5
    invoke-virtual {v11, v6}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object v1, v15

    move-object v1, v15

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v15, v6}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    goto :goto_7

    :cond_8
    :goto_6
    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    :cond_9
    invoke-static {v6}, Lcom/google/android/gms/measurement/internal/ha;->W(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    add-int/lit8 v0, v18, 0x1

    if-le v0, v14, :cond_a

    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v2, 0x30

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string/jumbo v2, "tan e ntqen/o/ncroinvtoama h  t"

    const-string/jumbo v2, "otmvoaancnrtneoa    e/nt /hEtin"

    const-string v2, "/asnea temcvoht iEanoctrn  nn/ "

    const-string v2, "Event can\'t contain more than "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "pbrmam "

    const-string/jumbo v2, "map sbr"

    const-string v2, "aspmor "

    const-string v2, " params"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v3, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v3}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v3

    invoke-virtual {v3, v10}, Lcom/google/android/gms/measurement/internal/i3;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v4

    invoke-virtual {v4, v11}, Lcom/google/android/gms/measurement/internal/i3;->b(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v1, v3, v4}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x5

    invoke-static {v15, v1}, Lcom/google/android/gms/measurement/internal/ha;->d0(Landroid/os/Bundle;I)Z

    invoke-virtual {v15, v6}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    :cond_a
    move/from16 v18, v0

    move/from16 v18, v0

    move/from16 v18, v0

    move/from16 v18, v0

    :cond_b
    :goto_7
    move v8, v14

    move v8, v14

    move v8, v14

    move v8, v14

    goto/16 :goto_0

    :cond_c
    move-object v14, v15

    move-object v14, v15

    move-object v14, v15

    goto :goto_8

    :cond_d
    const/4 v14, 0x0

    :goto_8
    return-object v14
.end method

.method final w(Landroid/os/Bundle;ILjava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/android/gms/measurement/internal/ha;->d0(Landroid/os/Bundle;I)Z

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-eqz p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v1, 0x1

    const/16 p2, 0x28

    const/4 v0, 0x0

    move v1, v0

    const/4 p4, 0x1

    move v1, p4

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p3, p2, p4}, Lcom/google/android/gms/measurement/internal/ha;->q(Ljava/lang/String;IZ)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    const-string p3, "e_v"

    const-string p3, "e_v"

    const/4 v1, 0x1

    const-string/jumbo p3, "v_e"

    const-string p3, "_ev"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1, p3, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x6

    if-eqz p5, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    instance-of p2, p5, Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    if-nez p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    instance-of p2, p5, Ljava/lang/CharSequence;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eqz p2, :cond_1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    int-to-long p2, p2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    const-string p4, "e_l"

    const-string p4, "_el"

    const/4 v1, 0x2

    const-string p4, "el_"

    const-string p4, "_el"

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p4, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method final w0(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZZ)Lcom/google/android/gms/measurement/internal/zzat;
    .locals 7

    const/4 v6, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p8

    const/4 v6, 0x3

    if-eqz p8, :cond_0

    const/4 p1, 0x0

    xor-int/2addr v6, p1

    return-object p1

    :cond_0
    invoke-virtual {p0, p2}, Lcom/google/android/gms/measurement/internal/ha;->k0(Ljava/lang/String;)I

    move-result p8

    const/4 v6, 0x1

    if-nez p8, :cond_3

    const/4 v6, 0x4

    if-eqz p3, :cond_1

    new-instance p8, Landroid/os/Bundle;

    const/4 v6, 0x5

    invoke-direct {p8, p3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    new-instance p8, Landroid/os/Bundle;

    const/4 v6, 0x4

    invoke-direct {p8}, Landroid/os/Bundle;-><init>()V

    :goto_0
    move-object v3, p8

    move-object v3, p8

    move-object v3, p8

    move-object v3, p8

    const/4 v6, 0x2

    const-string/jumbo p3, "o_"

    const-string/jumbo p3, "o_"

    const-string p3, "_o"

    const-string p3, "_o"

    const/4 v6, 0x3

    invoke-virtual {v3, p3, p4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    invoke-static {p3}, Lcom/google/android/gms/common/util/h;->c(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v6, 0x2

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/ha;->v0(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Ljava/util/List;Z)Landroid/os/Bundle;

    move-result-object p1

    const/4 v6, 0x0

    if-eqz p7, :cond_2

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/ha;->u0(Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object p1

    :cond_2
    const/4 v6, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    new-instance p3, Lcom/google/android/gms/measurement/internal/zzat;

    const/4 v6, 0x4

    new-instance v2, Lcom/google/android/gms/measurement/internal/zzar;

    const/4 v6, 0x5

    invoke-direct {v2, p1}, Lcom/google/android/gms/measurement/internal/zzar;-><init>(Landroid/os/Bundle;)V

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-wide v4, p5

    const/4 v6, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/measurement/internal/zzat;-><init>(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/zzar;Ljava/lang/String;J)V

    const/4 v6, 0x2

    return-object p3

    :cond_3
    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v6, 0x3

    iget-object p3, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v6, 0x7

    invoke-virtual {p3}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object p3

    const/4 v6, 0x3

    invoke-virtual {p3, p2}, Lcom/google/android/gms/measurement/internal/i3;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const-string p3, "Invalid conditional property event name"

    const/4 v6, 0x1

    invoke-virtual {p1, p3, p2}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v6, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v6, 0x2

    throw p1
.end method

.method final y(Landroid/os/Bundle;Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez p2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, p1, v1, v3}, Lcom/google/android/gms/measurement/internal/ha;->B(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method final z(Lcom/google/android/gms/measurement/internal/o3;I)V
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance v0, Ljava/util/TreeSet;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v1, p1, Lcom/google/android/gms/measurement/internal/o3;->d:Landroid/os/Bundle;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v0, v1}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v1, 0x0

    :cond_0
    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    check-cast v2, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v2}, Lcom/google/android/gms/measurement/internal/ha;->W(Ljava/lang/String;)Z

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v3, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-le v1, p2, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/16 v4, 0x30

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string v4, " rnnnau/t attamEnte/oiec   vohn"

    const/4 v9, 0x7

    const-string v4, "i raabEt/tn eht naco nn/vcemtno"

    const-string v4, "Event can\'t contain more than "

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v4, "rsamppu"

    const-string/jumbo v4, "psaarmp"

    const/4 v9, 0x7

    const-string/jumbo v4, "paprsm "

    const-string v4, " params"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->s()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v6, p1, Lcom/google/android/gms/measurement/internal/o3;->a:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v5, v6}, Lcom/google/android/gms/measurement/internal/i3;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v6, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->D()Lcom/google/android/gms/measurement/internal/i3;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v7, p1, Lcom/google/android/gms/measurement/internal/o3;->d:Landroid/os/Bundle;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v6, v7}, Lcom/google/android/gms/measurement/internal/i3;->b(Landroid/os/Bundle;)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v4, v3, v5, v6}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/o3;->d:Landroid/os/Bundle;

    const/4 v8, 0x1

    and-int/2addr v9, v8

    const/4 v4, 0x5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v3, v4}, Lcom/google/android/gms/measurement/internal/ha;->d0(Landroid/os/Bundle;I)Z

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v3, p1, Lcom/google/android/gms/measurement/internal/o3;->d:Landroid/os/Bundle;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v3, v2}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v9, 0x1

    return-void
.end method
