.class public final Lcom/google/android/gms/measurement/internal/g3;
.super Lcom/google/android/gms/measurement/internal/c4;


# instance fields
.field private final c:Lcom/google/android/gms/measurement/internal/f3;

.field private d:Z


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/c4;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p1, Lcom/google/android/gms/measurement/internal/f3;

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v2, 0x7

    move v3, v2

    const-string/jumbo v1, "mpsgsees_np_a_.leocdlmabetuolgo"

    const-string/jumbo v1, "pnseoo_cgdlem.abe_ueaasopmt_lgl"

    const/4 v3, 0x1

    const-string/jumbo v1, "pegmcmlomp_uoat_oeardln.lgaebe_"

    const-string v1, "google_app_measurement_local.db"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1, p0, v0, v1}, Lcom/google/android/gms/measurement/internal/f3;-><init>(Lcom/google/android/gms/measurement/internal/g3;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/android/gms/measurement/internal/g3;->c:Lcom/google/android/gms/measurement/internal/f3;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method private final x(I[B)Z
    .locals 16
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    iget-boolean v0, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    return v2

    :cond_0
    new-instance v3, Landroid/content/ContentValues;

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const-string v0, "etyp"

    const-string/jumbo v0, "pyte"

    const-string/jumbo v0, "tyep"

    const-string/jumbo v0, "type"

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v0, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v0, "ntmyo"

    const-string/jumbo v0, "tyemn"

    const-string v0, "betry"

    const-string v0, "entry"

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    invoke-virtual {v3, v0, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v4, 0x5

    move v5, v2

    move v5, v2

    move v5, v2

    move v5, v2

    move v6, v4

    move v6, v4

    move v6, v4

    :goto_0
    if-ge v5, v4, :cond_c

    const/4 v7, 0x1

    const/4 v8, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/g3;->o()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v9
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_0 .. :try_end_0} :catch_8
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_0 .. :try_end_0} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_5
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-nez v9, :cond_1

    :try_start_1
    iput-boolean v7, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    return v2

    :cond_1
    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    const-string/jumbo v0, "mfmslsuo( egteenc)o1ocss  urt"

    const-string v0, "1oe os lrtt(nse)gcmm sauefosc"

    const-string v0, "es( ecrpoesesm1sutma ofncl) t"

    const-string/jumbo v0, "select count(1) from messages"

    invoke-virtual {v9, v0, v8}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v10
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_1 .. :try_end_1} :catch_7
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    if-eqz v10, :cond_2

    :try_start_2
    invoke-interface {v10}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {v10, v2}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v11
    :try_end_2
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    goto/16 :goto_9

    :catch_0
    move-exception v0

    goto/16 :goto_2

    :catch_1
    move-exception v0

    goto/16 :goto_3

    :cond_2
    :goto_1
    const-wide/32 v13, 0x186a0

    const-wide/32 v13, 0x186a0

    const-wide/32 v13, 0x186a0

    const-wide/32 v13, 0x186a0

    cmp-long v0, v11, v13

    const-string/jumbo v15, "qesmebag"

    const-string/jumbo v15, "seamebgs"

    const-string/jumbo v15, "sessmeag"

    const-string/jumbo v15, "messages"

    if-ltz v0, :cond_3

    :try_start_3
    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v4, " dlm s outlllsalfauo Dcb"

    const-string/jumbo v4, "l soctuf Dlllo sla,dub a"

    const-string v4, " aftosco llDdo blsl,al a"

    const-string v4, "Data loss, local db full"

    invoke-virtual {v0, v4}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    sub-long/2addr v13, v11

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    add-long/2addr v13, v11

    new-array v0, v7, [Ljava/lang/String;

    invoke-static {v13, v14}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v2

    const-string v4, "  irsb eserwf swoomaodmla  ditrt   eibrecy)orw?odnmgpc esi(iri l"

    const-string/jumbo v4, "moi omipoowbrdeiretl cn i  rlg rs ymec ewto s?f r)adiewsa(disrs "

    const-string v4, " itob uwf? ai onemctrweycsse rils  e) d oomai(idlgrrw d dresmosr"

    const-string/jumbo v4, "rowid in (select rowid from messages order by rowid asc limit ?)"

    invoke-virtual {v9, v15, v4, v0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    int-to-long v11, v0

    cmp-long v0, v11, v13

    if-eqz v0, :cond_3

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v4, " eee f,pntii qeetvfeclce enxddb,pef.eu daoc fdhceortc t n cdxie etdieeraDerlpnlt"

    const-string v4, " infntrpqeie,etaev nt ldfp fen bt tec,iedecxhueeddfdreDcide  eo rceot.cea leclxn"

    const-string v4, "Different delete count than expected in local db. expected, received, difference"

    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    sub-long/2addr v13, v11

    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    invoke-virtual {v0, v4, v2, v7, v11}, Lcom/google/android/gms/measurement/internal/l3;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_3
    invoke-virtual {v9, v15, v8, v3}, Landroid/database/sqlite/SQLiteDatabase;->insertOrThrow(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V
    :try_end_3
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-eqz v10, :cond_4

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    :cond_4
    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteClosable;->close()V

    const/4 v2, 0x1

    return v2

    :catch_2
    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    goto :goto_5

    :catchall_1
    move-exception v0

    goto/16 :goto_a

    :catch_3
    move-exception v0

    move-object v10, v8

    move-object v10, v8

    :goto_2
    move-object v8, v9

    move-object v8, v9

    move-object v8, v9

    goto :goto_4

    :catch_4
    move-exception v0

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    :goto_3
    move-object v8, v9

    move-object v8, v9

    move-object v8, v9

    move-object v8, v9

    goto :goto_6

    :catchall_2
    move-exception v0

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    goto :goto_a

    :catch_5
    move-exception v0

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    :goto_4
    if-eqz v8, :cond_5

    :try_start_4
    invoke-virtual {v8}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {v8}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    :cond_5
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string/jumbo v4, "r  nirtsqa tscr brleyawndetgoiaaElt o"

    const-string/jumbo v4, "lasre eobt o twyo nsrltcgrtdaaainEi r"

    const-string v4, " asya enta rgEirwatboo rdnrteltlsco i"

    const-string v4, "Error writing entry to local database"

    invoke-virtual {v2, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    if-eqz v10, :cond_6

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    :cond_6
    if-eqz v8, :cond_9

    goto :goto_7

    :catch_6
    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    :catch_7
    :goto_5
    int-to-long v10, v6

    :try_start_5
    invoke-static {v10, v11}, Landroid/os/SystemClock;->sleep(J)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    add-int/lit8 v6, v6, 0x14

    if-eqz v8, :cond_7

    invoke-interface {v8}, Landroid/database/Cursor;->close()V

    :cond_7
    if-eqz v9, :cond_9

    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteClosable;->close()V

    goto :goto_8

    :catch_8
    move-exception v0

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    move-object v10, v8

    :goto_6
    :try_start_6
    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v2

    const-string v4, "e tm ourtroEtlrdasrlagfanenamcwri ; b yi"

    const-string/jumbo v4, "y rmfarewreri;l bstcll Eooirtantu dag an"

    const-string v4, "Elrooclrarsetwtat yrlfinorbea  u d;lang "

    const-string v4, "Error writing entry; local database full"

    invoke-virtual {v2, v4, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v2, 0x1

    iput-boolean v2, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    if-eqz v10, :cond_8

    invoke-interface {v10}, Landroid/database/Cursor;->close()V

    :cond_8
    if-eqz v8, :cond_9

    :goto_7
    invoke-virtual {v8}, Landroid/database/sqlite/SQLiteClosable;->close()V

    :cond_9
    :goto_8
    add-int/lit8 v5, v5, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    goto/16 :goto_0

    :catchall_3
    move-exception v0

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    :goto_9
    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    :goto_a
    if-eqz v8, :cond_a

    invoke-interface {v8}, Landroid/database/Cursor;->close()V

    :cond_a
    if-eqz v9, :cond_b

    invoke-virtual {v9}, Landroid/database/sqlite/SQLiteClosable;->close()V

    :cond_b
    throw v0

    :cond_c
    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string/jumbo v2, "oltnob oFla   setiaeta tctrdayeawdb rli"

    const-string v2, " llFo et ctibe at rtatdosyelwrnaoda iao"

    const-string/jumbo v2, "nbl aruottieaeyoldaictae  trw adol tF e"

    const-string v2, "Failed to write entry to local database"

    invoke-virtual {v0, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v2, 0x0

    return v2
.end method


# virtual methods
.method protected final n()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "- @~ 1 p~@trl @ ~@ K~@io~t.b/bio @uS@~~@@v/@   @ ~~o@s fo b~m~~@M~oli@~~ on@ca ~~@@df4@@@ y~~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method final o()Landroid/database/sqlite/SQLiteDatabase;
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/database/sqlite/SQLiteException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    return-object v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/g3;->c:Lcom/google/android/gms/measurement/internal/f3;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f3;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0
.end method

.method public final p(I)Ljava/util/List;
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;",
            ">;"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    const-string v2, "dbwqr"

    const-string v2, "bdrwo"

    const-string/jumbo v2, "wosri"

    const-string/jumbo v2, "rowid"

    const-string v3, "Eesmsraamnfdinroglrroaclur  oba a rei dee"

    const-string v3, "eldoreuir dbo a tEeaorlarmenrianragcssf  "

    const-string v3, "forsora aomdnt aerti blse rlr ndeagaircEe"

    const-string v3, "Error reading entries from local database"

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    iget-boolean v0, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    return-object v4

    :cond_0
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/g3;->s()Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v6, 0x5

    const/4 v7, 0x0

    move v9, v6

    move v9, v6

    move v9, v6

    move v9, v6

    move v8, v7

    move v8, v7

    :goto_0
    if-ge v8, v6, :cond_13

    const/4 v10, 0x1

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/g3;->o()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v15
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_0 .. :try_end_0} :catch_14
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_0 .. :try_end_0} :catch_13
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_12
    .catchall {:try_start_0 .. :try_end_0} :catchall_b

    if-nez v15, :cond_1

    :try_start_1
    iput-boolean v10, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    return-object v4

    :cond_1
    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    const-string v0, "3"

    const-string v0, "3"

    const-string v0, "3"

    const-string v0, "3"
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_1 .. :try_end_1} :catch_11
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_1 .. :try_end_1} :catch_e
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_d
    .catchall {:try_start_1 .. :try_end_1} :catchall_a

    :try_start_2
    const-string/jumbo v12, "sagepbse"

    const-string/jumbo v12, "sgeseamp"

    const-string/jumbo v12, "seasgmus"

    const-string/jumbo v12, "messages"

    new-array v13, v10, [Ljava/lang/String;

    aput-object v2, v13, v7

    const-string/jumbo v14, "pp=?tq"

    const-string/jumbo v14, "ypq=?t"

    const-string/jumbo v14, "y=qt?e"

    const-string/jumbo v14, "type=?"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-string/jumbo v18, "wcsd deiso"

    const-string/jumbo v18, "odsrcdswi "

    const-string/jumbo v18, "rowid desc"

    const-string v19, "1"

    const-string v19, "1"
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_8

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    move-object v15, v0

    move-object v15, v0

    :try_start_3
    invoke-virtual/range {v11 .. v19}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v11
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_7

    :try_start_4
    invoke-interface {v11}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const-wide/16 v20, -0x1

    const-wide/16 v20, -0x1

    const-wide/16 v20, -0x1

    const-wide/16 v20, -0x1

    if-eqz v0, :cond_2

    invoke-interface {v11, v7}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v12
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_6

    :try_start_5
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    goto :goto_1

    :cond_2
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    move-wide/from16 v12, v20

    :goto_1
    cmp-long v0, v12, v20

    if-eqz v0, :cond_3

    const-string/jumbo v0, "wdimr?o"

    const-string/jumbo v0, "wdrmi<?"

    const-string/jumbo v0, "rowid<?"

    new-array v11, v10, [Ljava/lang/String;

    invoke-static {v12, v13}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v11, v7

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move-object v15, v11

    move-object v15, v11

    goto :goto_2

    :cond_3
    move-object v14, v4

    move-object v14, v4

    move-object v14, v4

    move-object v15, v14

    move-object v15, v14

    move-object v15, v14

    :goto_2
    const/4 v0, 0x3

    new-array v13, v0, [Ljava/lang/String;

    aput-object v2, v13, v7

    const-string/jumbo v11, "peyt"

    const-string/jumbo v11, "ptey"

    const-string/jumbo v11, "type"

    aput-object v11, v13, v10

    const-string/jumbo v11, "nroto"

    const-string/jumbo v11, "tenro"

    const-string v11, "entry"

    const/4 v12, 0x2

    aput-object v11, v13, v12

    const-string/jumbo v16, "msbasbes"

    const-string/jumbo v16, "segasbsm"

    const-string v16, "aesessug"

    const-string/jumbo v16, "messages"

    const/16 v17, 0x0

    const/16 v18, 0x0

    const-string/jumbo v19, "oicdarups"

    const-string v19, "coardsuiw"

    const-string/jumbo v19, "ric aosdq"

    const-string/jumbo v19, "rowid asc"

    const/16 v11, 0x64

    invoke-static {v11}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v22

    move-object/from16 v11, p1

    move-object/from16 v11, p1

    move-object/from16 v11, p1

    move-object/from16 v11, p1

    move v6, v12

    move v6, v12

    move v6, v12

    move v6, v12

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    move-object/from16 v16, v17

    move-object/from16 v16, v17

    move-object/from16 v16, v17

    move-object/from16 v16, v17

    move-object/from16 v17, v18

    move-object/from16 v17, v18

    move-object/from16 v17, v18

    move-object/from16 v17, v18

    move-object/from16 v18, v19

    move-object/from16 v18, v19

    move-object/from16 v18, v19

    move-object/from16 v18, v19

    move-object/from16 v19, v22

    move-object/from16 v19, v22

    invoke-virtual/range {v11 .. v19}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v11
    :try_end_5
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_5 .. :try_end_5} :catch_a
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_5 .. :try_end_5} :catch_9
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_5 .. :try_end_5} :catch_8
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    :cond_4
    :goto_3
    :try_start_6
    invoke-interface {v11}, Landroid/database/Cursor;->moveToNext()Z

    move-result v12

    if-eqz v12, :cond_9

    invoke-interface {v11, v7}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v20

    invoke-interface {v11, v10}, Landroid/database/Cursor;->getInt(I)I

    move-result v12

    invoke-interface {v11, v6}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v13

    if-nez v12, :cond_5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v12
    :try_end_6
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_6 .. :try_end_6} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_6 .. :try_end_6} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_6 .. :try_end_6} :catch_5
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    :try_start_7
    array-length v14, v13

    invoke-virtual {v12, v13, v7, v14}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v12, v7}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object v13, Lcom/google/android/gms/measurement/internal/zzat;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v13, v12}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/google/android/gms/measurement/internal/zzat;
    :try_end_7
    .catch Lh4/a$a; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    :try_start_8
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    if-eqz v13, :cond_4

    invoke-interface {v5, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_8
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_8 .. :try_end_8} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_8 .. :try_end_8} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_8 .. :try_end_8} :catch_5
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    goto :goto_3

    :catchall_0
    move-exception v0

    goto :goto_4

    :catch_0
    :try_start_9
    iget-object v13, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v13

    const-string v14, "basldooceol iv lat tmsepf daela ertFon a"

    const-string/jumbo v14, "tefec dpadl  a vrtmlioFaalna ebtol ooesa"

    const-string/jumbo v14, "to mloriaelFlabao td eo aas m eleacfvtdd"

    const-string v14, "Failed to load event from local database"

    invoke-virtual {v13, v14}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    :try_start_a
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    goto :goto_3

    :goto_4
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    throw v0

    :cond_5
    if-ne v12, v10, :cond_6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v12
    :try_end_a
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_a .. :try_end_a} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_a .. :try_end_a} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_a .. :try_end_a} :catch_5
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    :try_start_b
    array-length v14, v13

    invoke-virtual {v12, v13, v7, v14}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v12, v7}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object v13, Lcom/google/android/gms/measurement/internal/zzkv;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v13, v12}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/google/android/gms/measurement/internal/zzkv;
    :try_end_b
    .catch Lh4/a$a; {:try_start_b .. :try_end_b} :catch_1
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :try_start_c
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V
    :try_end_c
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_c .. :try_end_c} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_c .. :try_end_c} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_c .. :try_end_c} :catch_5
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    goto :goto_5

    :catchall_1
    move-exception v0

    goto :goto_6

    :catch_1
    :try_start_d
    iget-object v13, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v13

    const-string/jumbo v14, "rebstlaeqursoa oiyot lrodatceeafl prla F m  dpad"

    const-string/jumbo v14, "ta eotFl  clsolarraf iap oebsprmydedorolt odaaue"

    const-string v14, "Failed to load user property from local database"

    invoke-virtual {v13, v14}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_1

    :try_start_e
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    move-object v13, v4

    move-object v13, v4

    move-object v13, v4

    move-object v13, v4

    :goto_5
    if-eqz v13, :cond_4

    invoke-interface {v5, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_3

    :goto_6
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    throw v0

    :cond_6
    if-ne v12, v6, :cond_7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v12
    :try_end_e
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_e .. :try_end_e} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_e .. :try_end_e} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_e .. :try_end_e} :catch_5
    .catchall {:try_start_e .. :try_end_e} :catchall_4

    :try_start_f
    array-length v14, v13

    invoke-virtual {v12, v13, v7, v14}, Landroid/os/Parcel;->unmarshall([BII)V

    invoke-virtual {v12, v7}, Landroid/os/Parcel;->setDataPosition(I)V

    sget-object v13, Lcom/google/android/gms/measurement/internal/zzab;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-interface {v13, v12}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/google/android/gms/measurement/internal/zzab;
    :try_end_f
    .catch Lh4/a$a; {:try_start_f .. :try_end_f} :catch_2
    .catchall {:try_start_f .. :try_end_f} :catchall_2

    :try_start_10
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V
    :try_end_10
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_10 .. :try_end_10} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_10 .. :try_end_10} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_10 .. :try_end_10} :catch_5
    .catchall {:try_start_10 .. :try_end_10} :catchall_4

    goto :goto_7

    :catchall_2
    move-exception v0

    goto :goto_8

    :catch_2
    :try_start_11
    iget-object v13, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v13

    const-string v14, "bintabtcs a coafF  ynrsoo piourl iraaeldtseaoelae prd ldtdom"

    const-string v14, " nsaldoreaaolo feptptaiottusm resolbyrio  rcd n callia edadF"

    const-string v14, "clsddrudtooe o nbeytpoilnamoulc  o sfF paaraaeiltolrdrti  ae"

    const-string v14, "Failed to load conditional user property from local database"

    invoke-virtual {v13, v14}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_2

    :try_start_12
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    move-object v13, v4

    move-object v13, v4

    move-object v13, v4

    move-object v13, v4

    :goto_7
    if-eqz v13, :cond_4

    invoke-interface {v5, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_3

    :goto_8
    invoke-virtual {v12}, Landroid/os/Parcel;->recycle()V

    throw v0

    :cond_7
    if-ne v12, v0, :cond_8

    iget-object v12, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v12}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v12

    invoke-virtual {v12}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v12

    const-string v13, "ch iaSnp prn gaekmpbpplui"

    const-string v13, "aabm pnapic nuhpeS likrgp"

    const-string/jumbo v13, "leuch  aqnkaaki pSirpppng"

    const-string v13, "Skipping app launch break"

    invoke-virtual {v12, v13}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    goto/16 :goto_3

    :cond_8
    iget-object v12, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v12}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v12

    invoke-virtual {v12}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v12

    const-string v13, "c spnboooakdiUelnr  nsdwato laeyanetr"

    const-string/jumbo v13, "snpcodyd   eelb cwnonlraoaiarttUoanke"

    const-string/jumbo v13, "il mo otoaptwUcsbee  arrad nleynnnckd"

    const-string v13, "Unknown record type in local database"

    invoke-virtual {v12, v13}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    goto/16 :goto_3

    :cond_9
    new-array v0, v10, [Ljava/lang/String;

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v0, v7

    const-string/jumbo v6, "sseeogas"

    const-string/jumbo v6, "messages"

    const-string v12, "bwr db=i<o"

    const-string v12, "= r<dbo?wi"

    const-string v12, " wi<dour? "

    const-string/jumbo v12, "rowid <= ?"
    :try_end_12
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_12 .. :try_end_12} :catch_7
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_12 .. :try_end_12} :catch_6
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_12 .. :try_end_12} :catch_5
    .catchall {:try_start_12 .. :try_end_12} :catchall_4

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    :try_start_13
    invoke-virtual {v13, v6, v12, v0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    if-ge v0, v6, :cond_a

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v6, "hifaermptee xa anosdwtnmd aFlosloreer tuv edeeter bp ce"

    const-string/jumbo v6, "ro voduee  lbtseams eiemcrehdt pwcr  aeadteFofantrnxele"

    const-string v6, "dweee vcqoenaoeeibr cmFr lattardalds fman o  eespthexrt"

    const-string v6, "Fewer entries removed from local database than expected"

    invoke-virtual {v0, v6}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_a
    invoke-virtual {v13}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    invoke-virtual {v13}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V
    :try_end_13
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_13 .. :try_end_13} :catch_4
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_13 .. :try_end_13} :catch_10
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_13 .. :try_end_13} :catch_3
    .catchall {:try_start_13 .. :try_end_13} :catchall_3

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    invoke-virtual {v13}, Landroid/database/sqlite/SQLiteClosable;->close()V

    return-object v5

    :catchall_3
    move-exception v0

    goto :goto_9

    :catch_3
    move-exception v0

    goto/16 :goto_e

    :catch_4
    move-exception v0

    goto/16 :goto_12

    :catchall_4
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    :goto_9
    move-object v4, v11

    move-object v4, v11

    move-object v4, v11

    move-object v4, v11

    goto :goto_c

    :catch_5
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_e

    :catch_6
    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_10

    :catch_7
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_12

    :catchall_5
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_c

    :catch_8
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_d

    :catch_9
    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_f

    :catch_a
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_11

    :catchall_6
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_b

    :catchall_7
    move-exception v0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    goto :goto_a

    :catchall_8
    move-exception v0

    move-object v13, v15

    move-object v13, v15

    :goto_a
    move-object v11, v4

    move-object v11, v4

    :goto_b
    if-eqz v11, :cond_b

    :try_start_14
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_b
    throw v0
    :try_end_14
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_14 .. :try_end_14} :catch_c
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_14 .. :try_end_14} :catch_f
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_14 .. :try_end_14} :catch_b
    .catchall {:try_start_14 .. :try_end_14} :catchall_9

    :catchall_9
    move-exception v0

    goto :goto_c

    :catch_b
    move-exception v0

    goto :goto_d

    :catch_c
    move-exception v0

    goto :goto_11

    :catchall_a
    move-exception v0

    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    :goto_c
    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    goto/16 :goto_18

    :catch_d
    move-exception v0

    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    :goto_d
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    :goto_e
    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    goto :goto_13

    :catch_e
    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    :catch_f
    :goto_f
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    :catch_10
    :goto_10
    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    goto :goto_14

    :catch_11
    move-exception v0

    move-object v13, v15

    move-object v13, v15

    move-object v13, v15

    :goto_11
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    :goto_12
    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    move-object v15, v13

    goto :goto_16

    :catchall_b
    move-exception v0

    move-object v15, v4

    move-object v15, v4

    move-object v15, v4

    move-object v15, v4

    goto :goto_18

    :catch_12
    move-exception v0

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v15, v11

    :goto_13
    if-eqz v15, :cond_c

    :try_start_15
    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    move-result v6

    if-eqz v6, :cond_c

    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    :cond_c
    iget-object v6, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v6

    invoke-virtual {v6, v3, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    iput-boolean v10, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_c

    if-eqz v11, :cond_d

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_d
    if-eqz v15, :cond_10

    goto :goto_15

    :catch_13
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    :goto_14
    int-to-long v12, v9

    :try_start_16
    invoke-static {v12, v13}, Landroid/os/SystemClock;->sleep(J)V
    :try_end_16
    .catchall {:try_start_16 .. :try_end_16} :catchall_c

    add-int/lit8 v9, v9, 0x14

    if-eqz v11, :cond_e

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_e
    if-eqz v15, :cond_10

    :goto_15
    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteClosable;->close()V

    goto :goto_17

    :catch_14
    move-exception v0

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    :goto_16
    :try_start_17
    iget-object v6, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v6

    invoke-virtual {v6, v3, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    iput-boolean v10, v1, Lcom/google/android/gms/measurement/internal/g3;->d:Z
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_c

    if-eqz v11, :cond_f

    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    :cond_f
    if-eqz v15, :cond_10

    goto :goto_15

    :cond_10
    :goto_17
    add-int/lit8 v8, v8, 0x1

    const/4 v6, 0x5

    goto/16 :goto_0

    :catchall_c
    move-exception v0

    move-object v4, v11

    move-object v4, v11

    move-object v4, v11

    :goto_18
    if-eqz v4, :cond_11

    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    :cond_11
    if-eqz v15, :cond_12

    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteClosable;->close()V

    :cond_12
    throw v0

    :cond_13
    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string v2, " lslFaprndnf abra e iaesoo aedtirvteeiambe to assted e"

    const-string v2, "fbva edp nebr earnnatilot dtaee sis a saaeoeiodertmF l"

    const-string v2, "eeomaebeaosse  ne idilt ar do afdam Fnsblnrirvttmee aa"

    const-string v2, "Failed to read events from database in reasonable time"

    invoke-virtual {v0, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    return-object v4

    :cond_14
    return-object v5
.end method

.method public final q()V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/g3;->o()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, "eqasomes"

    const-string/jumbo v1, "qmeasses"

    const/4 v4, 0x6

    const-string/jumbo v1, "semsabsg"

    const-string/jumbo v1, "messages"

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2, v2}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-lez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "endo cues sRac tlalli.ascty oadatre"

    const-string/jumbo v2, "t sara.natoscoa ec iR dtsylrleelcda"

    const/4 v4, 0x2

    const-string v2, "aa ets ptocyoadcadslRilnera. ltscr "

    const-string v2, "Reset local analytics data. records"

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, v2, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "oaasaratqd m reolynreroci cetltr .nrgrE atl"

    const-string/jumbo v2, "otrma daacErr.erale rilea ttonn t orsyicglr"

    const/4 v4, 0x3

    const-string/jumbo v2, "lssy.a ioegacrl  o tinrrre stlreanrEcrtatdo"

    const-string v2, "Error resetting local analytics data. error"

    const/4 v4, 0x5

    invoke-virtual {v1, v2, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public final r()Z
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    or-int/2addr v3, v2

    new-array v0, v0, [B

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x0

    move v2, v1

    move v2, v1

    const/4 v3, 0x7

    invoke-direct {p0, v1, v0}, Lcom/google/android/gms/measurement/internal/g3;->x(I[B)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0
.end method

.method final s()Z
    .locals 4
    .annotation build Lcom/google/android/gms/common/util/VisibleForTesting;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "ebdmmoorgela_lnelmua_ts.pacpego"

    const-string v1, "google_app_measurement_local.db"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method public final t()Z
    .locals 12
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v0, "ar eorpluoenarhcigfleotaokaEn rls d p laoc  aatredb"

    const-string/jumbo v0, "odbaotlEnrgraelrcpaau frpal octekba eais  lhdnr o e"

    const/4 v11, 0x7

    const-string v0, "ercbpbrf pardirk uael arbglo atEnl oa la ocstdmneha"

    const-string v0, "Error deleting app launch break from local database"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    const/4 v11, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v10, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    const/4 v2, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v1, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    return v2

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/g3;->s()Z

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eqz v1, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/4 v1, 0x5

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    move v4, v1

    move v4, v1

    const/4 v11, 0x4

    move v4, v1

    move v4, v1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    move v3, v2

    move v3, v2

    const/4 v11, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-ge v3, v1, :cond_5

    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/4 v5, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v6, 0x1

    :try_start_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/g3;->o()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v10, 0x3

    if-nez v5, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x2

    iput-boolean v6, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    return v2

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    new-array v7, v6, [Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v8, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    aput-object v8, v7, v2

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string v8, "gbsaesus"

    const-string v8, "asgesbse"

    const/4 v11, 0x2

    const-string v8, "asessgep"

    const-string/jumbo v8, "messages"

    const/4 v11, 0x4

    const-string v9, "e? pt yuq"

    const-string/jumbo v9, "pt e=yu ?"

    const/4 v11, 0x6

    const-string v9, "= syt ?ep"

    const-string/jumbo v9, "type == ?"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v5, v8, v9, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    const/4 v11, 0x6

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V

    const/4 v11, 0x4

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V
    :try_end_0
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteClosable;->close()V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    return v6

    :catchall_0
    move-exception v0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto/16 :goto_5

    :catch_0
    move-exception v7

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto :goto_1

    :catch_1
    move-exception v7

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto :goto_3

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-eqz v5, :cond_2

    :try_start_1
    const/4 v10, 0x1

    move v11, v10

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    move-result v8

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v8, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    :cond_2
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v8

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v8, v0, v7}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput-boolean v6, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v5, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    goto :goto_2

    :catch_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    int-to-long v6, v4

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v6, v7}, Landroid/os/SystemClock;->sleep(J)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    add-int/lit8 v4, v4, 0x14

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v5, :cond_3

    :goto_2
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteClosable;->close()V

    const/4 v11, 0x1

    goto :goto_4

    :goto_3
    :try_start_2
    const/4 v11, 0x0

    const/4 v10, 0x5

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v8

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v8, v0, v7}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    iput-boolean v6, p0, Lcom/google/android/gms/measurement/internal/g3;->d:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v10, 0x6

    move v11, v10

    if-eqz v5, :cond_3

    const/4 v10, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    goto :goto_2

    :cond_3
    :goto_4
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    goto/16 :goto_0

    :goto_5
    const/4 v11, 0x1

    const/4 v10, 0x0

    if-eqz v5, :cond_4

    const/4 v11, 0x3

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteClosable;->close()V

    :cond_4
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    throw v0

    :cond_5
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v10, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const-string/jumbo v1, "tscm daaalbpe aa a  rcrgrioeeselrhedoareapolmlblbtk  eir aiEnntun onm "

    const-string/jumbo v1, "keblrlhpioednal lte   ralacEgrfrndpr oea rt isia se autmoabmacbeoe ann"

    const/4 v11, 0x4

    const-string v1, "btrcoaaleol fu rrmpgehenteakor or e a bdcdnira aElt enap iia slmolsanb"

    const-string v1, "Error deleting app launch break from local database in reasonable time"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :cond_6
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    return v2
.end method

.method public final u(Lcom/google/android/gms/measurement/internal/zzab;)Z
    .locals 4

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/gms/measurement/internal/ha;->c0(Landroid/os/Parcelable;)[B

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    array-length v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/high16 v1, 0x20000

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-le v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->t()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v0, "eo  otplqe nllytoaotcc vsa gdncSr bt o aeirsntlCaforrugiyeiredds opdote.ein aonl r"

    const/4 v3, 0x1

    const-string/jumbo v0, "r   dbfostdiesoaodl lribtgcreolcC er pny e y nlopad n ovon.ncltuittieoaeegSiatrsao"

    const-string v0, "Conditional user property too long for local database. Sending directly to service"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/g3;->x(I[B)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return p1
.end method

.method public final v(Lcom/google/android/gms/measurement/internal/zzat;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/measurement/internal/s;->a(Lcom/google/android/gms/measurement/internal/zzat;Landroid/os/Parcel;I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->marshall()[B

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    array-length v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/high16 v2, 0x20000

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-le v0, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->t()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v0, "d iltou scvgsn. anfdeneaviigee   vdorrt loolSetc aec o raysoltnttbisEe "

    const-string/jumbo v0, "ldsovgect  t. ventfiocli  aesattn eelelcoentagrvySaosieEb dd i rro s no"

    const/4 v4, 0x1

    const-string v0, "i  b  opdldaesigyeiel novSc tenrsdtne ertioce.lnotvoo nlg  crEsfa vtate"

    const-string v0, "Event is too long for local database. Sending event directly to service"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, v1, p1}, Lcom/google/android/gms/measurement/internal/g3;->x(I[B)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return p1
.end method

.method public final w(Lcom/google/android/gms/measurement/internal/zzkv;)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x7

    move v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/measurement/internal/ea;->a(Lcom/google/android/gms/measurement/internal/zzkv;Landroid/os/Parcel;I)V

    invoke-virtual {v0}, Landroid/os/Parcel;->marshall()[B

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x6

    array-length v0, p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/high16 v2, 0x20000

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-le v0, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/measurement/internal/n3;->t()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v0, "iortascaqtroidflcrop dlUmgvd eeee oey rpcsSn l olg.aote  rnatso etnriy"

    const-string v0, "clim.ersoa eeoeoo  aidg nnyltns  pvdgrdfecrtalrsyUpttoor o rael  citSe"

    const/4 v4, 0x0

    const-string/jumbo v0, "rrsbaesyeaitne tcgse ivtncorosclad .elooley Sdot nrppUo erfr  doltia g"

    const-string v0, "User property too long for local database. Sending directly to service"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, v0, p1}, Lcom/google/android/gms/measurement/internal/g3;->x(I[B)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return p1
.end method
