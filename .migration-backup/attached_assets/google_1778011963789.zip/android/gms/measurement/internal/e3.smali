.class public final Lcom/google/android/gms/measurement/internal/e3;
.super Lcom/google/android/gms/measurement/internal/c4;


# instance fields
.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:I

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:J

.field private final i:J

.field private j:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private k:I

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/google/android/gms/measurement/internal/z4;J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/measurement/internal/c4;-><init>(Lcom/google/android/gms/measurement/internal/z4;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-wide p2, p0, Lcom/google/android/gms/measurement/internal/e3;->i:J

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected final l()V
    .locals 15
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "appId",
            "appStore",
            "appName",
            "gmpAppId",
            "gaAppId"
        }
    .end annotation

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x1

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v1

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    const/high16 v2, -0x80000000

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x5

    const/4 v3, 0x0

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x7

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x1

    const-string/jumbo v5, "wnsosnn"

    const-string/jumbo v5, "wnskonn"

    const/4 v14, 0x0

    const-string/jumbo v5, "nwumnko"

    const-string/jumbo v5, "unknown"

    const/4 v14, 0x6

    const-string/jumbo v6, "onkwomn"

    const-string/jumbo v6, "nwnmkno"

    const-string/jumbo v6, "onUknbw"

    const-string v6, "Unknown"

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x5

    if-nez v1, :cond_1

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x3

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x6

    const-string/jumbo v8, "nPcliautcaigsnkap  painmatomeaeInr y, pi eaiMnln eactit or obthiudp.arggeu "

    const-string/jumbo v8, "oe todgnni anmIyabrlcietgeu tep apitaPcMppkaasnm,ioiar  a hdtin.lurigane c "

    const/4 v14, 0x5

    const-string/jumbo v8, "igd tidpes iaugp tplcy,itauatae ctpaIa.nirPhofir egeobcn peanak  rian Mnnlm"

    const-string v8, "PackageManager is null, app identity information might be inaccurate. appId"

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x2

    invoke-virtual {v7, v8, v9}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_0
    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x1

    goto/16 :goto_4

    :cond_1
    :try_start_0
    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x6

    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x7

    goto :goto_0

    :catch_0
    const/4 v14, 0x7

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x5

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    const-string/jumbo v8, "prpnardsqrae.raelp nagorIbe gipemaEa ie plknvtir  "

    const-string/jumbo v8, "onaplb pe.iaee nr pIier ase atravlmadrnrrikc ggppE"

    const/4 v14, 0x3

    const-string v8, "eds.atr  IsgEeprmn niata erpp pclnreio rilvepkgaar"

    const-string v8, "Error retrieving app installer package name. appId"

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-virtual {v7, v8, v9}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :goto_0
    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x5

    if-nez v5, :cond_2

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    const-string v5, "i_nmmaslluulna"

    const-string/jumbo v5, "laanlluimnu_st"

    const/4 v14, 0x2

    const-string/jumbo v5, "nat_onaiumlall"

    const-string/jumbo v5, "manual_install"

    const/4 v14, 0x7

    const/4 v13, 0x7

    goto :goto_1

    :cond_2
    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string/jumbo v7, "pc.ddbnnoerioavg.dm"

    const-string/jumbo v7, "ndge.ncprda.miovdon"

    const/4 v14, 0x3

    const-string v7, ".ncviourmdaneingddo"

    const-string v7, "com.android.vending"

    const/4 v14, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v14, 0x3

    const/4 v13, 0x3

    if-eqz v7, :cond_3

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    :cond_3
    :goto_1
    :try_start_1
    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x6

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v7

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v1, v7, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v7

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x7

    if-eqz v7, :cond_0

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x0

    iget-object v8, v7, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    invoke-virtual {v1, v8}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v8

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x5

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x3

    if-nez v9, :cond_4

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x5

    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v8
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_2

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x4

    goto :goto_2

    :cond_4
    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    :goto_2
    :try_start_2
    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x5

    iget-object v6, v7, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x1

    iget v2, v7, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v13, 0x1

    const/4 v14, 0x1

    goto :goto_4

    :catch_1
    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x1

    goto :goto_3

    :catch_2
    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    :goto_3
    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x4

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v8

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v8

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string v9, "fN rvrnpEapaigrae,apmpqnprgeaed    i.ieprtIoo"

    const-string/jumbo v9, "indp iirqac Iavear re ea.opmo,trfgea pgpNnprE"

    const/4 v14, 0x1

    const-string v9, ".N,aten qepr riapoieca parkEg imponedgvrpf rI"

    const-string v9, "Error retrieving package info. appId, appName"

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x4

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-virtual {v8, v9, v10, v6}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_4
    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x6

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->c:Ljava/lang/String;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x0

    iput-object v5, p0, Lcom/google/android/gms/measurement/internal/e3;->f:Ljava/lang/String;

    const/4 v14, 0x5

    iput-object v6, p0, Lcom/google/android/gms/measurement/internal/e3;->d:Ljava/lang/String;

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x6

    iput v2, p0, Lcom/google/android/gms/measurement/internal/e3;->e:I

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x7

    iput-object v8, p0, Lcom/google/android/gms/measurement/internal/e3;->g:Ljava/lang/String;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x1

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v14, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x0

    iput-wide v5, p0, Lcom/google/android/gms/measurement/internal/e3;->h:J

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->O()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x1

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x1

    const/4 v5, 0x1

    const/4 v14, 0x6

    const/4 v13, 0x2

    if-nez v2, :cond_5

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x3

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->P()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x2

    const-string/jumbo v6, "ma"

    const-string/jumbo v6, "ma"

    const/4 v14, 0x4

    const-string v6, "am"

    const-string v6, "am"

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x5

    invoke-virtual {v6, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v14, 0x3

    const/4 v13, 0x4

    if-eqz v2, :cond_5

    const/4 v13, 0x1

    shl-int/2addr v14, v13

    move v2, v5

    move v2, v5

    const/4 v14, 0x2

    move v2, v5

    move v2, v5

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x3

    goto :goto_5

    :cond_5
    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x3

    move v2, v3

    move v2, v3

    const/4 v14, 0x5

    move v2, v3

    move v2, v3

    :goto_5
    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x4

    iget-object v6, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-virtual {v6}, Lcom/google/android/gms/measurement/internal/z4;->x()I

    move-result v6

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x2

    packed-switch v6, :pswitch_data_0

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x6

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->u()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x5

    const-string v8, "dcsbtmpsli soimAo nesguedna nes r uedde aeotnedeeapttr"

    const/4 v14, 0x4

    const-string/jumbo v8, "tesers aelpim enetesgnct odepda osund mnd tusdreaAeoib"

    const-string v8, "App measurement disabled due to denied storage consent"

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x3

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x5

    goto/16 :goto_6

    :pswitch_0
    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x2

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->u()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x3

    const-string v8, " somae medgtea imlAbinateulbaheslg dop mtnndsctil clvti eetpara"

    const-string/jumbo v8, "tp me pa  ianilastsruvon itlomheaelcded  t lbtgmgabdncateAilese"

    const-string/jumbo v8, "ospto  la abt scicedoiutpAdrlblnhl nea st eaemmttvgaeeglea nodi"

    const-string v8, "App measurement disabled via the global data collection setting"

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    goto/16 :goto_6

    :pswitch_1
    const/4 v13, 0x6

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x5

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x6

    const-string v8, "T hdebitotepfireafoeteec  isyP l e aipne/sesbeiaeiaeoldese.erstt /cc/dmast /esmaoss roa ia/ospub ag hrsdihmpn inevlcrte:.s.etrrlgpeumdtbredaovgA-duugt.p"

    const-string v8, " seeo/ slg gtvsPeeapt p rpaT iia heseidogeaicaesoclurcusarhbyorbvn spftbpm.eotel/.mct dtuf/o arueseil e dritt ieednahsnaesroded/-tdssrtAe:p.mcei/aeg.mie"

    const-string/jumbo v8, "tltpsruoeycmeemco sdl.e bpr eeta/s ai iti ee/lsse/otiiTnmevscrrfPumr.etpegfpan duaisrtevpa o Agtuha  eeser:.o-baaiigus.hbrpoos aecda sdtd/dihe/sdnlgceet"

    const-string v8, "App measurement deactivated via resources. This method is being deprecated. Please refer to https://firebase.google.com/support/guides/disable-analytics"

    const/4 v14, 0x7

    const/4 v13, 0x4

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x7

    goto/16 :goto_6

    :pswitch_2
    const/4 v14, 0x3

    const/4 v13, 0x3

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x4

    const-string/jumbo v8, "t bbum pvasesnepiealt mthp teimd  aiiprarnerAaed"

    const-string v8, " di  brv  emrepettaptrnesaeamistA ambuaehldeinip"

    const/4 v14, 0x5

    const-string/jumbo v8, "tsAepi vqia pmaubemnhlertria m teeaasetie n rdps"

    const-string v8, "App measurement disabled via the init parameters"

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x3

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x3

    goto/16 :goto_6

    :pswitch_3
    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x1

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x6

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x0

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->u()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x3

    const-string v8, "easdmnmpseienud apAe iemtf vlsi bts eatuh"

    const-string/jumbo v8, "tdnsh ummeief u Aittdirse pbmlneavaas pee"

    const-string/jumbo v8, "veem heaeritunteaAampbi smtd lea fnspsm d"

    const-string v8, "App measurement disabled via the manifest"

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x7

    goto/16 :goto_6

    :pswitch_4
    const/4 v14, 0x7

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x2

    const/4 v13, 0x3

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->u()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x2

    const-string v8, "(ldlomsdsbprtlfAeuotteain esaeaiy lbolmecncsEdpe) l eptbayianCen"

    const-string v8, "deisotepdnyta aeo(laeCAsEt pllbupmamenltesci ry els)bsfndliecnab"

    const/4 v14, 0x4

    const-string/jumbo v8, "nfbtsbpaCscndnmlleadc A) ysy alneedusEilersittlt(m aboilbepeaAee"

    const-string v8, "App measurement disabled by setAnalyticsCollectionEnabled(false)"

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x4

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x5

    goto :goto_6

    :pswitch_5
    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x3

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x3

    const-string v8, " ave nuu ep tteavmptetrnaiqreasadrh cdeapeA titsmii"

    const-string/jumbo v8, "mpmtadsrqtepviet stnpruAieaa enetadvie ae  tihmrc a"

    const/4 v14, 0x5

    const-string/jumbo v8, "ieerstupcpatnt tAa ihede eapr mtmiimana vt avrdpeee"

    const-string v8, "App measurement deactivated via the init parameters"

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x4

    goto :goto_6

    :pswitch_6
    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x6

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x5

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x7

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->u()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x1

    const/4 v13, 0x2

    const-string v8, "es  atafqmddinaesthpptmneer  tieeuvAcae mait"

    const-string v8, "App measurement deactivated via the manifest"

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    goto :goto_6

    :pswitch_7
    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x0

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v7

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x3

    const-string v8, "epsllaep Aeoln tbnudcmsc etieearso"

    const-string/jumbo v8, "o s eredoeeaceullnctstnp mnlAapebi"

    const/4 v14, 0x2

    const-string v8, "eeemcperooma pc nulelseAnditabm ln"

    const-string v8, "App measurement collection enabled"

    const/4 v14, 0x7

    invoke-virtual {v7, v8}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :goto_6
    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x6

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x6

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x3

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->n:Ljava/lang/String;

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x3

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x4

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->d()Lcom/google/android/gms/measurement/internal/b;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x5

    if-eqz v2, :cond_6

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->O()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x2

    iput-object v2, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    :cond_6
    const/4 v13, 0x1

    const/4 v14, 0x6

    const/4 v2, 0x0

    :try_start_3
    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x1

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v7}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v7

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x1

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x5

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->R()Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x5

    const-string/jumbo v9, "lpi_ogpgo_oae"

    const-string v9, "google_app_id"

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-static {v7, v9, v8}, Lcom/google/android/gms/measurement/internal/n7;->c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x6

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x1

    if-eq v5, v8, :cond_7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x2

    goto :goto_7

    :cond_7
    move-object v8, v4

    move-object v8, v4

    :goto_7
    const/4 v13, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    iput-object v8, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    const/4 v13, 0x6

    shl-int/2addr v14, v13

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzom;->zzc()Z

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x0

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v8

    const/4 v14, 0x3

    const/4 v13, 0x6

    sget-object v9, Lcom/google/android/gms/measurement/internal/z2;->e0:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v13, 0x7

    move v14, v13

    invoke-virtual {v8, v2, v9}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v8
    :try_end_3
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_3

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x4

    const-string v9, "_i_pabaoddmp"

    const-string/jumbo v9, "oa_mpbidpa_d"

    const/4 v14, 0x3

    const-string v9, "__obdmuadppa"

    const-string v9, "admob_app_id"

    const/4 v14, 0x5

    if-eqz v8, :cond_b

    :try_start_4
    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x0

    iget-object v8, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v8}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v8

    const/4 v14, 0x5

    const/4 v13, 0x0

    iget-object v10, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-virtual {v10}, Lcom/google/android/gms/measurement/internal/z4;->R()Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x2

    invoke-static {v8}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x2

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x2

    if-nez v12, :cond_8

    const/4 v13, 0x7

    xor-int/2addr v14, v13

    goto :goto_8

    :cond_8
    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-static {v8}, Lcom/google/android/gms/measurement/internal/r4;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v10

    :goto_8
    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x6

    const-string v8, "gap_oidp_"

    const-string v8, "aa_dop_ig"

    const/4 v14, 0x6

    const-string/jumbo v8, "ppg_ia_dq"

    const-string v8, "ga_app_id"

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-static {v8, v11, v10}, Lcom/google/android/gms/measurement/internal/r4;->b(Ljava/lang/String;Landroid/content/res/Resources;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x1

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    const/4 v14, 0x3

    const/4 v13, 0x2

    if-eq v5, v12, :cond_9

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    :cond_9
    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x3

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->n:Ljava/lang/String;

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x7

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x0

    if-eqz v4, :cond_a

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x3

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x4

    if-nez v4, :cond_d

    :cond_a
    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x2

    invoke-static {v9, v11, v10}, Lcom/google/android/gms/measurement/internal/r4;->b(Ljava/lang/String;Landroid/content/res/Resources;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x1

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x2

    goto :goto_a

    :cond_b
    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x5

    if-nez v4, :cond_d

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x0

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v4

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x4

    iget-object v5, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->R()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-static {v4}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x1

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x4

    if-nez v8, :cond_c

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x2

    goto :goto_9

    :cond_c
    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x3

    invoke-static {v4}, Lcom/google/android/gms/measurement/internal/r4;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    :goto_9
    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-static {v9, v7, v5}, Lcom/google/android/gms/measurement/internal/r4;->b(Ljava/lang/String;Landroid/content/res/Resources;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x3

    const/4 v13, 0x6

    iput-object v4, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    :cond_d
    :goto_a
    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x7

    if-nez v6, :cond_f

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x0

    iget-object v4, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x7

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v4

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-virtual {v4}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v4

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x1

    const-string v5, "cesseandp p p e fgerdato bl kppngpmea,aoAmiga rel bpeu"

    const-string v5, "elefnbei mrapop cedpm ge bp kapgu eoeld aA,aatp snaprg"

    const/4 v14, 0x4

    const-string v5, "App measurement enabled for app package, google app id"

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    iget-object v6, p0, Lcom/google/android/gms/measurement/internal/e3;->c:Ljava/lang/String;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x5

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x7

    if-eqz v7, :cond_e

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    const/4 v14, 0x6

    goto :goto_b

    :cond_e
    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x4

    iget-object v7, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    :goto_b
    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x3

    invoke-virtual {v4, v5, v6, v7}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catch Ljava/lang/IllegalStateException; {:try_start_4 .. :try_end_4} :catch_3

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x4

    goto :goto_c

    :catch_3
    move-exception v4

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x3

    iget-object v5, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v5

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v5

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    const-string v6, "  emi ItledadnFptchufntplapig o ewoGIo. d eApicgiex"

    const-string/jumbo v6, "optn GuwFp ppidhl ed  tnIacgod.at lii fceioegAeIpex"

    const/4 v14, 0x5

    const-string v6, "e. xoofi ncchG deedolpptA wpgIth lniiIt oeaiedgF pa"

    const-string v6, "Fetching Google App Id failed with exception. appId"

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/n3;->z(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x7

    invoke-virtual {v5, v6, v0, v4}, Lcom/google/android/gms/measurement/internal/l3;->c(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_f
    :goto_c
    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x6

    iput-object v2, p0, Lcom/google/android/gms/measurement/internal/e3;->j:Ljava/util/List;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->d()Lcom/google/android/gms/measurement/internal/b;

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v13, 0x1

    shl-int/2addr v14, v13

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x6

    const-string v2, "dsc_ibaplyfivseeaatstensn.t"

    const-string/jumbo v2, "sfi.eeepstaiavtdtessl_canyn"

    const/4 v14, 0x3

    const-string v2, "analytics.safelisted_events"

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    invoke-virtual {v0, v2}, Lcom/google/android/gms/measurement/internal/f;->y(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x1

    if-nez v0, :cond_10

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x5

    goto :goto_d

    :cond_10
    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v14, 0x4

    const/4 v13, 0x7

    if-nez v2, :cond_11

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x7

    const-string/jumbo v2, "nin eeugS sarsd tiil qetnviyete ptf.Ismg"

    const-string v2, ".issegvsq leiea nteirpng nSty tdItefmi l"

    const/4 v14, 0x4

    const-string/jumbo v2, "nIgv nipitayelngro.ids tmf  esettepSe ls"

    const-string v2, "Safelisted event list is empty. Ignoring"

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x2

    invoke-virtual {v0, v2}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    goto :goto_e

    :cond_11
    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_12
    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x7

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x2

    if-eqz v4, :cond_13

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    check-cast v4, Ljava/lang/String;

    const/4 v14, 0x4

    const/4 v13, 0x7

    iget-object v5, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v5}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v5

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x2

    const-string/jumbo v6, "lev sstiqneadtee"

    const-string v6, " estsvsdileetena"

    const/4 v14, 0x1

    const-string v6, " dsetsevntslieea"

    const-string/jumbo v6, "safelisted event"

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v5, v6, v4}, Lcom/google/android/gms/measurement/internal/ha;->P(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x7

    if-nez v4, :cond_12

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x5

    goto :goto_e

    :cond_13
    :goto_d
    const/4 v14, 0x0

    iput-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->j:Ljava/util/List;

    :goto_e
    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x5

    if-eqz v1, :cond_14

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v14, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/wrappers/a;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x2

    iput v0, p0, Lcom/google/android/gms/measurement/internal/e3;->k:I

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x7

    return-void

    :cond_14
    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x4

    iput v3, p0, Lcom/google/android/gms/measurement/internal/e3;->k:I

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x4

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method protected final n()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x1

    or-int/2addr v2, v0

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method final o()I
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/measurement/internal/e3;->k:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    return v0
.end method

.method final p()I
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/android/gms/measurement/internal/e3;->e:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method final q(Ljava/lang/String;)Lcom/google/android/gms/measurement/internal/zzp;
    .locals 34
    .annotation build Landroidx/annotation/l1;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    new-instance v31, Lcom/google/android/gms/measurement/internal/zzp;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/e3;->s()Ljava/lang/String;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/e3;->u()Ljava/lang/String;

    move-result-object v4

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    iget-object v5, v1, Lcom/google/android/gms/measurement/internal/e3;->d:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    iget v0, v1, Lcom/google/android/gms/measurement/internal/e3;->e:I

    int-to-long v6, v0

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/e3;->f:Ljava/lang/String;

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v8, v1, Lcom/google/android/gms/measurement/internal/e3;->f:Ljava/lang/String;

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/f;->q()J

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    iget-wide v9, v1, Lcom/google/android/gms/measurement/internal/e3;->h:J

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v11, 0x0

    cmp-long v0, v9, v11

    const/4 v2, 0x0

    if-nez v0, :cond_4

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->N()Lcom/google/android/gms/measurement/internal/ha;

    move-result-object v9

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v0

    iget-object v10, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v10}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v10}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v13

    invoke-static {}, Lcom/google/android/gms/measurement/internal/ha;->s()Ljava/security/MessageDigest;

    move-result-object v14

    const-wide/16 v15, -0x1

    const-wide/16 v15, -0x1

    const-wide/16 v15, -0x1

    const-wide/16 v15, -0x1

    if-nez v14, :cond_0

    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string/jumbo v9, "naDmmoC etMudtngtl n 5oe c"

    const-string/jumbo v9, "uc5mn  o seMtdaCoDnnttelg "

    const-string v9, " 5oooadnece DtuMnntsCilgt "

    const-string v9, "Could not get MD5 instance"

    invoke-virtual {v0, v9}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :goto_0
    move-wide v9, v15

    goto :goto_1

    :cond_0
    if-eqz v13, :cond_3

    :try_start_0
    invoke-virtual {v9, v0, v10}, Lcom/google/android/gms/measurement/internal/ha;->U(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_2

    invoke-static {v0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object v0

    iget-object v10, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v10}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    const/16 v13, 0x40

    invoke-virtual {v0, v10, v13}, Lcom/google/android/gms/common/wrappers/c;->f(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    if-eqz v0, :cond_1

    array-length v10, v0

    if-lez v10, :cond_1

    aget-object v0, v0, v2

    invoke-virtual {v0}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v0

    invoke-virtual {v14, v0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v0

    invoke-static {v0}, Lcom/google/android/gms/measurement/internal/ha;->q0([B)J

    move-result-wide v9

    move-wide v15, v9

    goto :goto_0

    :cond_1
    iget-object v0, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/n3;->w()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v0

    const-string/jumbo v10, "onoCo utegte nlstd sirgu"

    const-string v10, "Cdtolbuitu ggtnseano e r"

    const-string v10, "Could not get signatures"

    invoke-virtual {v0, v10}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :cond_2
    move-wide v15, v11

    goto :goto_0

    :catch_0
    move-exception v0

    iget-object v9, v9, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/n3;->r()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v9

    const-string v10, "ac nnbeoau efngmP dkto"

    const-string/jumbo v10, "taao aufnceumekng doPn"

    const-string v10, "Package name not found"

    invoke-virtual {v9, v10, v0}, Lcom/google/android/gms/measurement/internal/l3;->b(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_3
    move-wide v9, v11

    :goto_1
    iput-wide v9, v1, Lcom/google/android/gms/measurement/internal/e3;->h:J

    :cond_4
    move-wide v13, v9

    iget-object v0, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->o()Z

    move-result v0

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v9

    iget-boolean v9, v9, Lcom/google/android/gms/measurement/internal/d4;->p:Z

    const/4 v10, 0x1

    xor-int/lit8 v15, v9, 0x1

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->o()Z

    move-result v9

    const/4 v11, 0x0

    if-nez v9, :cond_5

    :goto_2
    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    goto/16 :goto_4

    :cond_5
    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzpt;->zzc()Z

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v9

    sget-object v12, Lcom/google/android/gms/measurement/internal/z2;->g0:Lcom/google/android/gms/measurement/internal/y2;

    invoke-virtual {v9, v11, v12}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v9

    if-eqz v9, :cond_6

    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/n3;->v()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v9

    const-string v12, " sa  fDps.buDtIloedIeti"

    const-string v12, "IiDseIus lbds.aeft tDo "

    const-string v12, "IlDreseaq tbd t fsDIs.o"

    const-string v12, "Disabled IID for tests."

    invoke-virtual {v9, v12}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    goto :goto_2

    :cond_6
    :try_start_1
    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v9

    invoke-virtual {v9}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v9

    const-string v12, "AssleFpiacrc.mc.gnnalltitooegseire.bfbaiayaosse"

    const-string/jumbo v12, "lfAlalcpsonasF.oeegasy.tccabsgibianyit.eiomeerr"

    const-string v12, "acamysrryA..iiaaalsntmbleiosielneFg.ctsefoc.bog"

    const-string v12, "com.google.firebase.analytics.FirebaseAnalytics"

    invoke-virtual {v9, v12}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v9
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_3

    if-nez v9, :cond_7

    goto :goto_2

    :cond_7
    :try_start_2
    new-array v12, v10, [Ljava/lang/Class;

    const-class v18, Landroid/content/Context;

    const-class v18, Landroid/content/Context;

    const-class v18, Landroid/content/Context;

    const-class v18, Landroid/content/Context;

    aput-object v18, v12, v2

    const-string v11, "aIntnsgtqee"

    const-string v11, "aeIeocgtsnt"

    const-string v11, "getInstance"

    invoke-virtual {v9, v11, v12}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v11

    new-array v12, v10, [Ljava/lang/Object;

    iget-object v10, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v10}, Lcom/google/android/gms/measurement/internal/z4;->f()Landroid/content/Context;

    move-result-object v10

    aput-object v10, v12, v2

    const/4 v10, 0x0

    invoke-virtual {v11, v10, v12}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    if-nez v11, :cond_8

    goto :goto_3

    :cond_8
    :try_start_3
    const-string v10, "esdnFbsanebciersItIte"

    const-string v10, "IesdtnsaIeabtiecenFsr"

    const-string v10, "ersncsugetabIFInadite"

    const-string v10, "getFirebaseInstanceId"

    new-array v12, v2, [Ljava/lang/Class;

    invoke-virtual {v9, v10, v12}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v9

    new-array v10, v2, [Ljava/lang/Object;

    invoke-virtual {v9, v11, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    goto :goto_4

    :catch_1
    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/n3;->x()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v9

    const-string/jumbo v10, "tteIriep ae edrtlediFirvc eF b nmaseIsn"

    const-string/jumbo v10, "rtFmiarnal tiee b IvI erctseie eFnesadd"

    const-string v10, " anaidteqrvrI aecFl n ebdFsteteriIoeies"

    const-string v10, "Failed to retrieve Firebase Instance Id"

    invoke-virtual {v9, v10}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    goto :goto_3

    :catch_2
    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->b()Lcom/google/android/gms/measurement/internal/n3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/n3;->y()Lcom/google/android/gms/measurement/internal/l3;

    move-result-object v9

    const-string v10, "eostaFacnsbFsan ni stly nebrietldtAecai o ii"

    const-string v10, "Failed to obtain Firebase Analytics instance"

    invoke-virtual {v9, v10}, Lcom/google/android/gms/measurement/internal/l3;->a(Ljava/lang/String;)V

    :catch_3
    :goto_3
    const/16 v20, 0x0

    :goto_4
    iget-object v9, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v9}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v10

    iget-object v10, v10, Lcom/google/android/gms/measurement/internal/d4;->e:Lcom/google/android/gms/measurement/internal/y3;

    invoke-virtual {v10}, Lcom/google/android/gms/measurement/internal/y3;->a()J

    move-result-wide v10

    const-wide/16 v16, 0x0

    const-wide/16 v16, 0x0

    cmp-long v12, v10, v16

    if-nez v12, :cond_9

    iget-wide v9, v9, Lcom/google/android/gms/measurement/internal/z4;->G:J

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-wide/from16 v21, v9

    goto :goto_5

    :cond_9
    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    iget-wide v2, v9, Lcom/google/android/gms/measurement/internal/z4;->G:J

    invoke-static {v2, v3, v10, v11}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    move-wide/from16 v21, v2

    :goto_5
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    iget v11, v1, Lcom/google/android/gms/measurement/internal/e3;->k:I

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/f;->A()Z

    move-result v23

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/d4;->o()Landroid/content/SharedPreferences;

    move-result-object v2

    const-string/jumbo v3, "t_emtooncdoaediyllrnscc_efrla"

    const-string/jumbo v3, "llcnoycddoit_tosnrelair_aeefc"

    const-string v3, "cdeeoa_daecirsnyfelcilltrno_o"

    const-string v3, "deferred_analytics_collection"

    const/4 v9, 0x0

    invoke-interface {v2, v3, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v24

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    iget-object v3, v1, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v2

    const-string v9, "_twtnb_ngsabruesf_aoltaaalaigcei_naodoollinsyg_epzoaillls"

    const-string v9, "aiwo_baaae_gos__yclsesouglitznlaaetflnlslpanagi_dltiron_o"

    const-string/jumbo v9, "saisnaunlowyinnzaeostlgdg_aoo_eruapli__dolfa_sigltt_aallc"

    const-string v9, "google_analytics_default_allow_ad_personalization_signals"

    invoke-virtual {v2, v9}, Lcom/google/android/gms/measurement/internal/f;->t(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v2

    if-nez v2, :cond_a

    const/16 v25, 0x0

    goto :goto_6

    :cond_a
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v9, 0x1

    xor-int/2addr v2, v9

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    move-object/from16 v25, v2

    :goto_6
    iget-wide v9, v1, Lcom/google/android/gms/measurement/internal/e3;->i:J

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/e3;->j:Ljava/util/List;

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzom;->zzc()Z

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v2

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    sget-object v3, Lcom/google/android/gms/measurement/internal/z2;->e0:Lcom/google/android/gms/measurement/internal/y2;

    move-wide/from16 v26, v9

    const/4 v9, 0x0

    invoke-virtual {v2, v9, v3}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v2

    if-eqz v2, :cond_b

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/measurement/internal/e3;->t()Ljava/lang/String;

    move-result-object v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    move-object/from16 v29, v2

    goto :goto_7

    :cond_b
    move-object/from16 v29, v9

    move-object/from16 v29, v9

    move-object/from16 v29, v9

    move-object/from16 v29, v9

    :goto_7
    const-wide/32 v9, 0xb3b0

    const-wide/32 v9, 0xb3b0

    const-wide/32 v9, 0xb3b0

    const-wide/32 v9, 0xb3b0

    const-wide/16 v17, 0x0

    const-wide/16 v17, 0x0

    iget-object v2, v1, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/z4;->F()Lcom/google/android/gms/measurement/internal/d4;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/d4;->q()Lcom/google/android/gms/measurement/internal/g;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/g;->i()Ljava/lang/String;

    move-result-object v30

    move-object/from16 v28, v16

    move-object/from16 v28, v16

    move-object/from16 v28, v16

    move-object/from16 v28, v16

    move-object/from16 v2, v31

    move-object/from16 v2, v31

    move-object/from16 v2, v31

    move-object/from16 v2, v31

    move-object/from16 v32, v19

    move-object/from16 v32, v19

    move-object/from16 v32, v19

    move-object/from16 v32, v19

    move-object v3, v12

    move-object v3, v12

    move-object v3, v12

    move/from16 v33, v11

    move/from16 v33, v11

    move/from16 v33, v11

    move/from16 v33, v11

    move-wide v11, v13

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move v14, v0

    move v14, v0

    move v14, v0

    move v14, v0

    move-object/from16 v16, v20

    move-object/from16 v16, v20

    move-object/from16 v16, v20

    move-wide/from16 v19, v21

    move/from16 v21, v33

    move/from16 v21, v33

    move/from16 v21, v33

    move/from16 v21, v33

    move/from16 v22, v23

    move/from16 v22, v23

    move/from16 v22, v23

    move/from16 v22, v23

    move/from16 v23, v24

    move/from16 v23, v24

    move/from16 v23, v24

    move-object/from16 v24, v32

    move-object/from16 v24, v32

    move-object/from16 v24, v32

    move-object/from16 v24, v32

    invoke-direct/range {v2 .. v30}, Lcom/google/android/gms/measurement/internal/zzp;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;JJLjava/lang/String;ZZLjava/lang/String;JJIZZLjava/lang/String;Ljava/lang/Boolean;JLjava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    return-object v31
.end method

.method final r()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->m:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method final s()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->c:Ljava/lang/String;

    return-object v0
.end method

.method final t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->n:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->n:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method final u()Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zznx;->zzc()Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/t5;->a:Lcom/google/android/gms/measurement/internal/z4;

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/measurement/internal/z4;->z()Lcom/google/android/gms/measurement/internal/f;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v2, Lcom/google/android/gms/measurement/internal/z2;->u0:Lcom/google/android/gms/measurement/internal/y2;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/measurement/internal/f;->B(Ljava/lang/String;Lcom/google/android/gms/measurement/internal/y2;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/t5;->h()V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/c4;->i()V

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->l:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method final v()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/measurement/internal/e3;->j:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method
