.class public final Lcom/google/android/gms/internal/auth/zzbe;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final zze:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/auth/api/c;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v3, 0x10

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-nez p4, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance p1, Landroid/os/Bundle;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p4}, Lcom/google/android/gms/auth/api/c;->a()Landroid/os/Bundle;

    move-result-object p1

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/auth/zzbe;->zze:Landroid/os/Bundle;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~msi~b4~b @~~von ~i @@ /~oso Sul@@~tc/~~~~~d @ r@M~  @Kyoo@~@~~~.1 @ i~@@l@@@a@fot~f ~@@ b~ -  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const-string v0, "eus.caaSnolAsrgpd.doeiaiunmteomI.hagrtlit..vh.ginoc.e"

    const/4 v3, 0x3

    const-string v0, "airmsun.votil.te.Ietdaiau.ggmachorilgAm.ph.doneen.rSo"

    const-string v0, "com.google.android.gms.auth.api.internal.IAuthService"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Lcom/google/android/gms/internal/auth/zzbh;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/gms/internal/auth/zzbh;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/auth/zzbh;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth/zzbh;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzbe;->zze:Landroid/os/Bundle;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const v0, 0xbdfcb8

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "ampAorrcteglSngoiadgh.mt.atIlodiuicuea.smvhe.r.onie.n"

    const-string/jumbo v0, "uSimaoioaai.nc.Idrg.mitohneogptgctder..mh.easleurAvnl"

    const/4 v2, 0x5

    const-string/jumbo v0, "muiidb.igho.nlesrrapctnge.meovAoa.uhgdatiectISl.onar."

    const-string v0, "com.google.android.gms.auth.api.internal.IAuthService"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "SvohogunA.mogcdmslrT.e.isr.oTecdgitaue.R."

    const-string v0, ".Tc.oT.gietmu.ord..SamnRoridvseogsAhlcgeo"

    const/4 v2, 0x3

    const-string/jumbo v0, "oAiamrSp.eTdovslcmo.itngeaRgsug.coT.e.drh"

    const-string v0, "com.google.android.gms.auth.service.START"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public final requiresSignIn()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/j;->getClientSettings()Lcom/google/android/gms/common/internal/g;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/g;->c()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/auth/api/b;->a:Lcom/google/android/gms/common/api/a;

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/internal/g;->f(Lcom/google/android/gms/common/api/a;)Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    or-int/2addr v3, v0

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method
