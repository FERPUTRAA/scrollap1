.class final Lcom/google/android/gms/internal/auth/zzbr;
.super Lcom/google/android/gms/internal/auth/zzbd;


# instance fields
.field final synthetic zza:Lcom/google/android/gms/internal/auth/zzbs;


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/auth/zzbs;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/auth/zzbr;->zza:Lcom/google/android/gms/internal/auth/zzbs;

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzbd;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zzc(Ljava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~ 4i ~  ufS on~~~t/@ t~~~b @ Mab/~mviKo@  c~@~ood@~@~ ~@lbr.@@@y~1@ ~@o@-i~@o~  @  ~@ l@~@@s@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzbr;->zza:Lcom/google/android/gms/internal/auth/zzbs;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Lcom/google/android/gms/internal/auth/zzbv;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v1, p1}, Lcom/google/android/gms/internal/auth/zzbv;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/gms/internal/auth/zzbr;->zza:Lcom/google/android/gms/internal/auth/zzbs;

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0xbbe

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/Status;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v1, Lcom/google/android/gms/internal/auth/zzbv;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v1, v0}, Lcom/google/android/gms/internal/auth/zzbv;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x4

    return-void
.end method
