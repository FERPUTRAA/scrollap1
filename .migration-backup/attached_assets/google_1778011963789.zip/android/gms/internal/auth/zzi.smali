.class final Lcom/google/android/gms/internal/auth/zzi;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/16 v3, 0xe0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @si@@@~o@@~ ~1@~ M~obt~@~ ~@f@u~. ~o@fm  ~d~@-b@@c @~/~ S b~@~K ov l4o@/iln@s@o  @i a~~ ~~rt~ y"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const-string v0, "SdnmegrodcilAIma.mctl.esugaGnoh.goa..ouetgavditheust.o.roao"

    const-string v0, ".esooIailttmscSt.ac.m.idnogughuogohGrveac.oa.ddlneo.reaguAt"

    const/4 v3, 0x7

    const-string/jumbo v0, "uhouogdocitacteel..vaadaoceooreAm.Iar.ingdsl.mugtoh.go.ntSG"

    const-string v0, "com.google.android.gms.auth.account.data.IGoogleAuthService"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v1, v0, Lcom/google/android/gms/internal/auth/zzp;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/internal/auth/zzp;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/internal/auth/zzp;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth/zzp;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p1
.end method

.method public final disconnect(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo v1, "rwethbAtplCni:ohteugicno ne oeciaieGrmdlvdn elmsoIS ct"

    const-string/jumbo v1, "wgnmdiiGrmceltupeIc solneoinoSadiv :tseeon  tCAterclhh"

    const/4 v3, 0x1

    const-string/jumbo v1, "sonetouAuihtnigS narnIweile:oe cl ctphocCeGiesemdrt vd"

    const-string v1, "GoogleAuthServiceClientImpl disconnected with reason: "

    const/4 v2, 0x2

    and-int/2addr v3, v2

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "eStlonoutlAImoclphgviCG"

    const/4 v3, 0x5

    const-string v1, "AmloGIcpllvoiCpSentthug"

    const-string v1, "GoogleAuthSvcClientImpl"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-super {p0, p1}, Lcom/google/android/gms/common/internal/e;->disconnect(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 5

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-array v0, v0, [Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Lcom/google/android/gms/auth/k;->j:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v2, Lcom/google/android/gms/auth/k;->i:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x4

    const/4 v3, 0x1

    aput-object v2, v0, v1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object v2, Lcom/google/android/gms/auth/k;->a:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const v0, 0x1110e58

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "S.ohuA.oqoevc.gienntt.olrciel.eag.dgaobIuaaorhodm.gscutmatG"

    const-string v0, ".elaobo.hctcAnrrS.deeeco.tgn.aolostacg.gdait.gumIuuamiovohG"

    const/4 v2, 0x7

    const-string v0, "ansv.unoomootgacIau.oeeosee.c.org.uarlcigamdth.ctlidgSht.AG"

    const-string v0, "com.google.android.gms.auth.account.data.IGoogleAuthService"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "oTomcAa.uadd.mlnimhnapoeoRtrc.ttuuiggcS.uoaT.g.sh"

    const-string v0, "creoTnutS.mdsopid.toTo.hhuaua.glAcnm.cit.guoa.Rga"

    const/4 v2, 0x7

    const-string v0, "SuehohTomtgiuco.uatT.sc.gdnmaoc.o.Adaa.gtpiRnloar"

    const-string v0, "com.google.android.gms.auth.account.authapi.START"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method
