.class public final Lcom/google/android/gms/internal/auth/zzhq;
.super Lcom/google/android/gms/internal/auth/zzes;

# interfaces
.implements Lcom/google/android/gms/internal/auth/zzfx;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzhr;->zzj()Lcom/google/android/gms/internal/auth/zzhr;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/auth/zzes;-><init>(Lcom/google/android/gms/internal/auth/zzeu;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/auth/zzhp;)V
    .locals 2

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzhr;->zzj()Lcom/google/android/gms/internal/auth/zzhr;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/auth/zzes;-><init>(Lcom/google/android/gms/internal/auth/zzeu;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method
