.class public final Lcom/google/android/gms/internal/auth/zzam;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x0

    const/16 v3, 0x78

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x3

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/android/gms/auth/account/g;->a(Landroid/os/IBinder;)Lcom/google/android/gms/auth/account/h;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-array v0, v0, [Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v2, Lcom/google/android/gms/auth/k;->l:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const v0, 0xbdfcb8

    const/4 v2, 0x6

    const/4 v1, 0x6

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "mosacudg.o.u.e..oonIrStlAigtusedaomncvtocrckWniseha.cor"

    const-string/jumbo v0, "sIsmoicaotclu.gohanegockg.tmdceAouneravo.tdo.Wr.unr.Sci"

    const/4 v2, 0x3

    const-string v0, "com.google.android.gms.auth.account.IWorkAccountService"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "..nmnRtrScogg.etduAmctucoccrmkauo.os.a.aaoTToliwdnh.g"

    const-string v0, ".ohmRat..uAcacmStocrnTkuuawnmisagegc..troTd.ocdo.ngoo"

    const-string v0, "com.google.android.gms.auth.account.workaccount.START"

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    return v0
.end method
