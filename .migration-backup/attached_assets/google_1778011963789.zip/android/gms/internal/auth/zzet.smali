.class public abstract Lcom/google/android/gms/internal/auth/zzet;
.super Lcom/google/android/gms/internal/auth/zzeu;

# interfaces
.implements Lcom/google/android/gms/internal/auth/zzfx;


# instance fields
.field protected final zzb:Lcom/google/android/gms/internal/auth/zzep;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzeu;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzep;->zza()Lcom/google/android/gms/internal/auth/zzep;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/internal/auth/zzet;->zzb:Lcom/google/android/gms/internal/auth/zzep;

    const/4 v2, 0x3

    return-void
.end method
