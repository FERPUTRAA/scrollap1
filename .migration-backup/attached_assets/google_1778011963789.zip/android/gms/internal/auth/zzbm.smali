.class final Lcom/google/android/gms/internal/auth/zzbm;
.super Lcom/google/android/gms/internal/auth/zzbd;


# instance fields
.field final synthetic zza:Lcom/google/android/gms/tasks/TaskCompletionSource;


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/auth/zzbo;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/internal/auth/zzbm;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzbd;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zzb(Lcom/google/android/gms/auth/api/proxy/ProxyResponse;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i/s@f~y ~b@/a~~  tK@  @~o~  ~~~b4@o~ol~  mri~@@@ v1os @~@~@@ nl~@~@@@ @  ~ofM~@ @S~b~c~ @tdiuo-~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, p1, Lcom/google/android/gms/auth/api/proxy/ProxyResponse;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/Status;-><init>(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/internal/auth/zzbm;->zza:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, p1, v1}, Lcom/google/android/gms/common/api/internal/b0;->b(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method
