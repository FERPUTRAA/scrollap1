.class public final Lcom/google/android/gms/internal/auth/zzap;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final zze:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/auth/api/accounttransfer/v;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x1

    const/16 v3, 0x80

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-nez p4, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance p1, Landroid/os/Bundle;

    const/4 v8, 0x6

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p4}, Lcom/google/android/gms/auth/api/accounttransfer/v;->a()Landroid/os/Bundle;

    move-result-object p1

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/auth/zzap;->zze:Landroid/os/Bundle;

    const/4 v8, 0x0

    const/4 v7, 0x6

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sbS @b@oldo@~  ~~i@n @o~ 4 r@fs ~~~ @/~ao v~  b@@~@/f lKt~o@~y~  i~c@@om~@@~~~ Mt~.- i~~1@ @@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, ".A.meroeatngntiatt.Sulecroeeifcfu.maohorasndccro.Taiipoacnn.lsndtnerrssrmIauc.g."

    const-string/jumbo v0, "s.scstTpmeor.aoduotnnnlvchfSufisIAarg.rel.i.enauonteriaarc.arm.cteoego.cctnndira"

    const/4 v3, 0x0

    const-string/jumbo v0, "ncriort.eeirapstmAa.f..oITgScfrctvaimesadlaneuhi.nocneroangcnolcert..rdn.tgouuos"

    const-string v0, "com.google.android.gms.auth.api.accounttransfer.internal.IAccountTransferService"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/gms/internal/auth/zzau;

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/gms/internal/auth/zzau;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/internal/auth/zzau;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth/zzau;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p1
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzap;->zze:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const v0, 0xbdfcb8

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "eahutbl.cvntna.cm.f.rstftSdrpolootagecTco.eAirs.reoisugaIdnroeunicraaen.nria.ncm"

    const-string v0, "e.cmlriunh.ctun.nercsoru.arrt.psaoSr.caitsnargmoffgeditecoITodoaetnln.Aeianavcm."

    const/4 v2, 0x7

    const-string v0, "g.Anenua.duenrorgraerccf..nrmttdoauastegv.ns.rIlneipc.olastciiueoctmaoarfnh.TSio"

    const-string v0, "com.google.android.gms.auth.api.accounttransfer.internal.IAccountTransferService"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "sogcmmApgndrosvifaadaocc..tSTnoh.or..cupaiios.eeerTl.ruR.nagt"

    const-string v0, ".oivoSia.ghs.d.tcnstiuteRoo.r.lsoeccraueAcrpardT.gm.naTafnmog"

    const/4 v2, 0x3

    const-string v0, "f.n.ohivqapo.itcongtsrglaacdeesuRAgSru.sio..cnaoTetraTrc.emm."

    const-string v0, "com.google.android.gms.auth.api.accounttransfer.service.START"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
