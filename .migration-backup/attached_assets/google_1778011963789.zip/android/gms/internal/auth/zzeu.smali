.class public abstract Lcom/google/android/gms/internal/auth/zzeu;
.super Lcom/google/android/gms/internal/auth/zzdp;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<MessageType:",
        "Lcom/google/android/gms/internal/auth/zzeu<",
        "TMessageType;TBuilderType;>;BuilderType:",
        "Lcom/google/android/gms/internal/auth/zzes<",
        "TMessageType;TBuilderType;>;>",
        "Lcom/google/android/gms/internal/auth/zzdp<",
        "TMessageType;TBuilderType;>;"
    }
.end annotation


# static fields
.field private static final zzb:Ljava/util/Map;


# instance fields
.field protected zzc:Lcom/google/android/gms/internal/auth/zzgz;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/internal/auth/zzeu;->zzb:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzdp;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzgz;->zza()Lcom/google/android/gms/internal/auth/zzgz;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/internal/auth/zzeu;->zzc:Lcom/google/android/gms/internal/auth/zzgz;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method static zza(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzeu;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "4tso ou/@vcf@n~i1dl~m~   ~tsy~.@@@@br @So@- ~b~/M@o@  ~ @~~@ o@  o@~  @~i~@~ l~@~ ~~iKf~a~@ @~b@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    sget-object v0, Lcom/google/android/gms/internal/auth/zzeu;->zzb:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    check-cast v1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v5, 0x5

    if-nez v1, :cond_0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1, v3, v2}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    check-cast v1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v1, "sitmniitcataanninioosl . faalCsil"

    const-string v1, "iastniailaflintlCiiazos.a scotn n"

    const/4 v5, 0x7

    const-string v1, "ialfo   itnsiCoicia.ntiatalnnosaz"

    const-string v1, "Class initialization cannot fail."

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw v0

    :cond_0
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v1, :cond_2

    const/4 v4, 0x3

    move v5, v4

    invoke-static {p0}, Lcom/google/android/gms/internal/auth/zzhi;->zze(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3, v3}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw p0

    :cond_2
    :goto_1
    const/4 v4, 0x2

    return-object v1
.end method

.method protected static zzb(Lcom/google/android/gms/internal/auth/zzeu;[B)Lcom/google/android/gms/internal/auth/zzeu;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/auth/zzfa;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    array-length v0, p1

    const/4 v4, 0x0

    sget-object v1, Lcom/google/android/gms/internal/auth/zzek;->zza:Lcom/google/android/gms/internal/auth/zzek;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x2

    invoke-static {p0, p1, v2, v0, v1}, Lcom/google/android/gms/internal/auth/zzeu;->zzj(Lcom/google/android/gms/internal/auth/zzeu;[BIILcom/google/android/gms/internal/auth/zzek;)Lcom/google/android/gms/internal/auth/zzeu;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, p1, v0, v0}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    check-cast v1, Ljava/lang/Byte;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Byte;->byteValue()B

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ne v1, p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1, p0}, Lcom/google/android/gms/internal/auth/zzgh;->zzi(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x6

    move v4, v3

    if-eq p1, v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0, v2, p1, v0}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    new-instance p1, Lcom/google/android/gms/internal/auth/zzgx;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p1, p0}, Lcom/google/android/gms/internal/auth/zzgx;-><init>(Lcom/google/android/gms/internal/auth/zzfw;)V

    const/4 v3, 0x6

    or-int/2addr v4, v3

    invoke-virtual {p1}, Lcom/google/android/gms/internal/auth/zzgx;->zza()Lcom/google/android/gms/internal/auth/zzfa;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/auth/zzfa;->zze(Lcom/google/android/gms/internal/auth/zzfw;)Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw p1

    :cond_3
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p0
.end method

.method protected static zzc()Lcom/google/android/gms/internal/auth/zzey;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzgf;->zze()Lcom/google/android/gms/internal/auth/zzgf;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method static varargs zze(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    :try_start_0
    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    instance-of p1, p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    if-nez p1, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    instance-of p1, p0, Ljava/lang/Error;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p0, Ljava/lang/Error;

    const/4 v1, 0x1

    throw p0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    const-string/jumbo p2, "mbe ebheirdwUy.deranccoxtoroe eoetnhc gsxnd tsetemepc  np"

    const-string p2, "et mcrcongxeeptn.nhrec  hsdeeabotnydoUocseetewt eir  xdpm"

    const/4 v1, 0x4

    const-string p2, "heywitu enrdct ep nsneh  xoU.npedo eertdaemogxeeasorcctct"

    const-string p2, "Unexpected exception thrown by generated accessor method."

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    throw p1

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    throw p0

    :catch_1
    move-exception p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    const-string/jumbo p2, "slorelCpec iinttno/uieo d  sea cno fmra eclpJfs vop/omo.lgetttneteaermu"

    const-string p2, "Couldn\'t use Java reflection to implement protocol message reflection."

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    throw p1
.end method

.method protected static zzf(Lcom/google/android/gms/internal/auth/zzfw;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/gms/internal/auth/zzgg;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, "00010/u/q01uuu000/0u10u0/u0a/0/000000000u/00/10010u0o//0010u10000u0100//"

    const-string v0, "1/01o0011000000/000u0/u0u/0/000u/0uu0/u00101/0uu0000/01a/uu0/000/00010u0"

    const/4 v2, 0x5

    const-string v0, "00s00/0/0u/010/00u00000u101u1000/00/00100011u/u/00000u00001//u0/0uu0a/u0"

    const-string v0, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001a"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1, p0, v0, p2}, Lcom/google/android/gms/internal/auth/zzgg;-><init>(Lcom/google/android/gms/internal/auth/zzfw;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method protected static zzg(Ljava/lang/Class;Lcom/google/android/gms/internal/auth/zzeu;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/auth/zzeu;->zzb:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private static zzj(Lcom/google/android/gms/internal/auth/zzeu;[BIILcom/google/android/gms/internal/auth/zzek;)Lcom/google/android/gms/internal/auth/zzeu;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/auth/zzfa;
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 p2, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p0, p2, v0, v0}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast p0, Lcom/google/android/gms/internal/auth/zzeu;

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object p2

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p2, v0}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance v5, Lcom/google/android/gms/internal/auth/zzds;

    const/4 v7, 0x6

    invoke-direct {v5, p4}, Lcom/google/android/gms/internal/auth/zzds;-><init>(Lcom/google/android/gms/internal/auth/zzek;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v3, 0x0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    move v4, p3

    move v4, p3

    const/4 v7, 0x2

    move v4, p3

    move v4, p3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface/range {v0 .. v5}, Lcom/google/android/gms/internal/auth/zzgh;->zzg(Ljava/lang/Object;[BIILcom/google/android/gms/internal/auth/zzds;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {p2, p0}, Lcom/google/android/gms/internal/auth/zzgh;->zze(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/auth/zzdp;->zza:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez p1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object p0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    throw p1
    :try_end_0
    .catch Lcom/google/android/gms/internal/auth/zzfa; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lcom/google/android/gms/internal/auth/zzgx; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzfa;->zzf()Lcom/google/android/gms/internal/auth/zzfa;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/auth/zzfa;->zze(Lcom/google/android/gms/internal/auth/zzfw;)Lcom/google/android/gms/internal/auth/zzfa;

    throw p1

    :catch_1
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    instance-of p2, p2, Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast p0, Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    throw p0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p2, Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/auth/zzfa;-><init>(Ljava/io/IOException;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2, p0}, Lcom/google/android/gms/internal/auth/zzfa;->zze(Lcom/google/android/gms/internal/auth/zzfw;)Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    throw p2

    :catch_2
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/internal/auth/zzgx;->zza()Lcom/google/android/gms/internal/auth/zzfa;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/auth/zzfa;->zze(Lcom/google/android/gms/internal/auth/zzfw;)Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    throw p1

    :catch_3
    move-exception p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/auth/zzfa;->zze(Lcom/google/android/gms/internal/auth/zzfw;)Lcom/google/android/gms/internal/auth/zzfa;

    const/4 v6, 0x1

    move v7, v6

    throw p1
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ne p0, p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq v1, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v0

    :cond_2
    const/4 v4, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    check-cast p1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/auth/zzgh;->zzh(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    return p1
.end method

.method public final hashCode()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/auth/zzdp;->zza:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/auth/zzgh;->zza(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v0, p0, Lcom/google/android/gms/internal/auth/zzdp;->zza:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/auth/zzfy;->zza(Lcom/google/android/gms/internal/auth/zzfw;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public final synthetic zzd()Lcom/google/android/gms/internal/auth/zzfv;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/internal/auth/zzes;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Lcom/google/android/gms/internal/auth/zzes;->zze(Lcom/google/android/gms/internal/auth/zzeu;)Lcom/google/android/gms/internal/auth/zzes;

    const/4 v3, 0x6

    return-object v0
.end method

.method public final synthetic zzh()Lcom/google/android/gms/internal/auth/zzfw;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v3, 0x3

    return-object v0
.end method

.method protected abstract zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
