.class public final Lcom/google/android/gms/internal/auth/zzhr;
.super Lcom/google/android/gms/internal/auth/zzeu;

# interfaces
.implements Lcom/google/android/gms/internal/auth/zzfx;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/auth/zzhr;


# instance fields
.field private zzd:Lcom/google/android/gms/internal/auth/zzey;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/auth/zzhr;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/auth/zzhr;->zzb:Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/auth/zzhr;

    const-class v1, Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/auth/zzhr;

    const-class v1, Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/auth/zzeu;->zzg(Ljava/lang/Class;Lcom/google/android/gms/internal/auth/zzeu;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzeu;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzeu;->zzc()Lcom/google/android/gms/internal/auth/zzey;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/auth/zzhr;->zzd:Lcom/google/android/gms/internal/auth/zzey;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic zzj()Lcom/google/android/gms/internal/auth/zzhr;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/auth/zzhr;->zzb:Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public static zzk([B)Lcom/google/android/gms/internal/auth/zzhr;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/auth/zzfa;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/auth/zzhr;->zzb:Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/android/gms/internal/auth/zzeu;->zzb(Lcom/google/android/gms/internal/auth/zzeu;[B)Lcom/google/android/gms/internal/auth/zzeu;

    move-result-object p0

    const/4 v2, 0x2

    check-cast p0, Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method


# virtual methods
.method protected final zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 p2, 0x1

    const/4 v1, 0x5

    if-eqz p1, :cond_4

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p3, 0x2

    const/4 v1, 0x7

    if-eq p1, p3, :cond_3

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p2, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eq p1, p2, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p3, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eq p1, p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p2, 0x5

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eq p1, p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p3

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    sget-object p1, Lcom/google/android/gms/internal/auth/zzhr;->zzb:Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    new-instance p1, Lcom/google/android/gms/internal/auth/zzhq;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/auth/zzhq;-><init>(Lcom/google/android/gms/internal/auth/zzhp;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1

    :cond_2
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/auth/zzhr;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1

    :cond_3
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x7

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x2

    aput-object p3, p1, p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    sget-object p2, Lcom/google/android/gms/internal/auth/zzhr;->zzb:Lcom/google/android/gms/internal/auth/zzhr;

    const/4 v1, 0x5

    const-string/jumbo p3, "u1ss00000u0000001/0100///001100100au100u01000//uu0u/u00000/u0/00u/0//uu0"

    const-string p3, "0/su//00/001uu100100u0/000a00u01u00uuu110///u100100000u0000000/0//000/0u"

    const/4 v1, 0x2

    const-string p3, "00um00001u0/00/00uu1001000000010/10/10/0ua0/0u/0uuu000/u//0010/0u/u00010"

    const-string p3, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001a"

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/auth/zzeu;->zzf(Lcom/google/android/gms/internal/auth/zzfw;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1

    :cond_4
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public final zzl()Ljava/util/List;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzhr;->zzd:Lcom/google/android/gms/internal/auth/zzey;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method
