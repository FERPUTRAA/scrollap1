.class final Lcom/google/android/gms/internal/auth/zzdy;
.super Lcom/google/android/gms/internal/auth/zzeb;


# instance fields
.field private final zzc:I


# direct methods
.method constructor <init>([BII)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/auth/zzeb;-><init>([B)V

    const/4 v1, 0x4

    const/4 p2, 0x7

    const/4 v1, 0x4

    const/4 p2, 0x0

    const/4 v1, 0x6

    array-length p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/auth/zzee;->zzi(III)I

    const/4 v0, 0x5

    const/4 v0, 0x4

    iput p3, p0, Lcom/google/android/gms/internal/auth/zzdy;->zzc:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza(I)B
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~s~@mcS~~~~ obi~lv@@@~ t @~bb@   @~@t  ~Ma/d l@@~@f~~Kio1on~/@@~o@suoo~ @@ .y@@ f  ~- @4 ~i@r ~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/auth/zzdy;->zzc:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 v1, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    sub-int v1, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    or-int/2addr v1, p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-gez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-gez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "se0mIdn <  "

    const-string v2, "exs0<I   dn"

    const/4 v5, 0x1

    const-string v2, " ed0ox :In "

    const-string v2, "Index < 0: "

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    throw v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v3, "e  m bnehnl:dt>I"

    const-string v3, " tIm e:nend>l hx"

    const/4 v5, 0x3

    const-string/jumbo v3, "n eex u:hgnt >lI"

    const-string v3, "Index > length: "

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string p1, ", "

    const-string p1, ", "

    const/4 v5, 0x0

    const-string p1, ", "

    const-string p1, ", "

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    throw v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzeb;->zza:[B

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-byte p1, v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return p1
.end method

.method final zzb(I)B
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzeb;->zza:[B

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    aget-byte p1, v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method protected final zzc()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x0

    and-int/2addr v2, v0

    const/4 v1, 0x3

    and-int/2addr v2, v1

    return v0
.end method

.method public final zzd()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/auth/zzdy;->zzc:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method
