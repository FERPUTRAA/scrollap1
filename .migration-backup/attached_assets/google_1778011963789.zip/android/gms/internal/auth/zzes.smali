.class public Lcom/google/android/gms/internal/auth/zzes;
.super Lcom/google/android/gms/internal/auth/zzdo;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<MessageType:",
        "Lcom/google/android/gms/internal/auth/zzeu<",
        "TMessageType;TBuilderType;>;BuilderType:",
        "Lcom/google/android/gms/internal/auth/zzes<",
        "TMessageType;TBuilderType;>;>",
        "Lcom/google/android/gms/internal/auth/zzdo<",
        "TMessageType;TBuilderType;>;"
    }
.end annotation


# instance fields
.field protected zza:Lcom/google/android/gms/internal/auth/zzeu;

.field protected zzb:Z

.field private final zzc:Lcom/google/android/gms/internal/auth/zzeu;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/internal/auth/zzeu;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TMessageType;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/auth/zzdo;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/auth/zzes;->zzc:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1, v1}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x0

    move v3, v2

    iput-boolean p1, p0, Lcom/google/android/gms/internal/auth/zzes;->zzb:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private static final zzj(Lcom/google/android/gms/internal/auth/zzeu;Lcom/google/android/gms/internal/auth/zzeu;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "dos@~~s~~@tc@~ @@b ~n4~~lSu~@  ~~ i@~ti~@r  @ o~.@f-a@1o@@ y ~ @~~vl~fKm i/@@o  /o@~ o@~ b~M @~b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/auth/zzgh;->zzf(Ljava/lang/Object;Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/auth/zzes;->zzd()Lcom/google/android/gms/internal/auth/zzes;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public final bridge synthetic zza()Lcom/google/android/gms/internal/auth/zzdo;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/auth/zzes;->zzd()Lcom/google/android/gms/internal/auth/zzes;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final synthetic zzb(Lcom/google/android/gms/internal/auth/zzdp;)Lcom/google/android/gms/internal/auth/zzdo;
    .locals 2

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/auth/zzes;->zze(Lcom/google/android/gms/internal/auth/zzeu;)Lcom/google/android/gms/internal/auth/zzes;

    const/4 v1, 0x2

    return-object p0
.end method

.method public final zzd()Lcom/google/android/gms/internal/auth/zzes;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzc:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2, v2}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast v0, Lcom/google/android/gms/internal/auth/zzes;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/auth/zzes;->zzf()Lcom/google/android/gms/internal/auth/zzeu;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/auth/zzes;->zze(Lcom/google/android/gms/internal/auth/zzeu;)Lcom/google/android/gms/internal/auth/zzes;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object v0
.end method

.method public final zze(Lcom/google/android/gms/internal/auth/zzeu;)Lcom/google/android/gms/internal/auth/zzes;
    .locals 3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzb:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/auth/zzes;->zzi()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzb:Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/auth/zzes;->zzj(Lcom/google/android/gms/internal/auth/zzeu;Lcom/google/android/gms/internal/auth/zzeu;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public zzf()Lcom/google/android/gms/internal/auth/zzeu;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TMessageType;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzb:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/auth/zzge;->zza()Lcom/google/android/gms/internal/auth/zzge;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/gms/internal/auth/zzge;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/auth/zzgh;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v1, v0}, Lcom/google/android/gms/internal/auth/zzgh;->zze(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v0, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzb:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0
.end method

.method public bridge synthetic zzg()Lcom/google/android/gms/internal/auth/zzfw;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/auth/zzes;->zzf()Lcom/google/android/gms/internal/auth/zzeu;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public final synthetic zzh()Lcom/google/android/gms/internal/auth/zzfw;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zzc:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method protected zzi()V
    .locals 5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2, v2}, Lcom/google/android/gms/internal/auth/zzeu;->zzi(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast v0, Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/google/android/gms/internal/auth/zzes;->zzj(Lcom/google/android/gms/internal/auth/zzeu;Lcom/google/android/gms/internal/auth/zzeu;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/auth/zzes;->zza:Lcom/google/android/gms/internal/auth/zzeu;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method
