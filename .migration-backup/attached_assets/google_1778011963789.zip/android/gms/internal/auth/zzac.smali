.class final Lcom/google/android/gms/internal/auth/zzac;
.super Lcom/google/android/gms/common/api/internal/e$a;


# instance fields
.field final synthetic zza:Z


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/auth/zzal;Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/l;Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-boolean p4, p0, Lcom/google/android/gms/internal/auth/zzac;->zza:Z

    const/4 v1, 0x2

    invoke-direct {p0, p2, p3}, Lcom/google/android/gms/common/api/internal/e$a;-><init>(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/l;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected final createFailedResult(Lcom/google/android/gms/common/api/Status;)Lcom/google/android/gms/common/api/v;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/internal/auth/zzaj;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth/zzaj;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final bridge synthetic doExecute(Lcom/google/android/gms/common/api/a$b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p1, Lcom/google/android/gms/internal/auth/zzam;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    check-cast p1, Lcom/google/android/gms/auth/account/h;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/internal/auth/zzac;->zza:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p1, v0}, Lcom/google/android/gms/auth/account/h;->v(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    new-instance p1, Lcom/google/android/gms/internal/auth/zzaj;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/common/api/Status;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Lcom/google/android/gms/internal/auth/zzaj;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public final bridge synthetic setResult(Ljava/lang/Object;)V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/gms/common/api/v;

    const/4 v0, 0x6

    move v1, v0

    invoke-super {p0, p1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method
