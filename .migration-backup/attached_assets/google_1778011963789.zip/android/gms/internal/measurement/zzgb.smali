.class public final Lcom/google/android/gms/internal/measurement/zzgb;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzgb;",
        "Lcom/google/android/gms/internal/measurement/zzfz;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzgb;


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:Lcom/google/android/gms/internal/measurement/zzke;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "Lcom/google/android/gms/internal/measurement/zzfq;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzgb;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzgb;->zza:Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgb;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x7

    move v2, v1

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgb;->zzf:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbA()Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgb;->zzg:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/measurement/zzfz;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "vos@~ fn @r @~ ~i@~@Kmi  ~o~b~@Mlo. ~~cf~@@b~S ~1 @@l/o@-t@ ~@~~sat@/do@@~y @~~~ i~4@~@o b  u @ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgb;->zza:Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfz;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/measurement/zzgb;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgb;->zza:Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzc(Lcom/google/android/gms/internal/measurement/zzgb;Lcom/google/android/gms/internal/measurement/zzfq;)V
    .locals 4

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgb;->zzg:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/google/android/gms/internal/measurement/zzke;->zzc()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbB(Lcom/google/android/gms/internal/measurement/zzke;)Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgb;->zzg:Lcom/google/android/gms/internal/measurement/zzke;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p0, p0, Lcom/google/android/gms/internal/measurement/zzgb;->zzg:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz p1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 p3, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v0, 0x4

    const/4 v4, 0x6

    and-int/2addr v5, v4

    const/4 v1, 0x3

    move v5, v1

    const/4 v4, 0x0

    move v5, v4

    const/4 v2, 0x2

    xor-int/2addr v5, v2

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq p1, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq p1, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq p1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq p1, p3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object p2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzgb;->zza:Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfz;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzfz;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzgb;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x6

    const/4 v5, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 p3, 0x0

    move v5, p3

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    const-string v3, "ezz"

    const-string/jumbo v3, "zze"

    const/4 v5, 0x7

    const-string/jumbo v3, "zze"

    const/4 v5, 0x5

    aput-object v3, p1, p3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo p3, "zfz"

    const-string p3, "fzz"

    const/4 v5, 0x6

    const-string p3, "fzz"

    const-string/jumbo p3, "zzf"

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    aput-object p3, p1, p2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzga;->zza:Lcom/google/android/gms/internal/measurement/zzkb;

    const/4 v5, 0x1

    const/4 v4, 0x7

    aput-object p2, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string p2, "gzz"

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    aput-object p2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-class p2, Lcom/google/android/gms/internal/measurement/zzfq;

    const-class p2, Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    aput-object p2, p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzgb;->zza:Lcom/google/android/gms/internal/measurement/zzgb;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string p3, "/u/m/u000/0//0000/uu00/0/0000002/100uc000u020u010001s0u2/00001/ub0/0u10u000000u01/u0u200/u"

    const-string p3, "0/s00u00b0u00u0/0/0/u100000//0u020uc1001u0/2/u1/0u0u1000/0/u/uu/00000u00/0120001u00000/002"

    const/4 v5, 0x2

    const-string p3, "0010o000/010000uu0u021uu0/1001/0000buuu/u000//00u0c/200/0u/0/00/0u000/021u00/000u00u0012/0"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u100c\u0000\u0002\u001b"

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object p1

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object p1
.end method
