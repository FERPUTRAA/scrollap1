.class public abstract Lcom/google/android/gms/internal/measurement/zzjx;
.super Lcom/google/android/gms/internal/measurement/zzih;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<MessageType:",
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "TMessageType;TBuilderType;>;BuilderType:",
        "Lcom/google/android/gms/internal/measurement/zzjt<",
        "TMessageType;TBuilderType;>;>",
        "Lcom/google/android/gms/internal/measurement/zzih<",
        "TMessageType;TBuilderType;>;"
    }
.end annotation


# static fields
.field private static final zza:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Lcom/google/android/gms/internal/measurement/zzjx<",
            "**>;>;"
        }
    .end annotation
.end field


# instance fields
.field protected zzc:Lcom/google/android/gms/internal/measurement/zzmc;

.field protected zzd:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzjx;->zza:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzih;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzmc;->zzc()Lcom/google/android/gms/internal/measurement/zzmc;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzc:Lcom/google/android/gms/internal/measurement/zzmc;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzd:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method protected static zzbA()Lcom/google/android/gms/internal/measurement/zzke;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "TE;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4~s~@ lv1~~~~@ @ ~ ~~n@@~b- f@@~  l@s@i~ ft@ ~ .@oKb~So/diua~o@M  ~ co~~@@~i ~o o/@rt@~  @@@y@~m"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzll;->zze()Lcom/google/android/gms/internal/measurement/zzll;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method protected static zzbB(Lcom/google/android/gms/internal/measurement/zzke;)Lcom/google/android/gms/internal/measurement/zzke;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "TE;>;)",
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/16 v0, 0xa

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    add-int/2addr v0, v0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0, v0}, Lcom/google/android/gms/internal/measurement/zzke;->zzd(I)Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method static varargs zzbE(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    instance-of p1, p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-nez p1, :cond_1

    instance-of p1, p0, Ljava/lang/Error;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    check-cast p0, Ljava/lang/Error;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    throw p0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    const-string/jumbo p2, "tnsmcpyc drttexxeeU rwatnngcoto hdoa.e ehnioerbeesmp  ede"

    const-string p2, "e srtd aoceexex.toh ntdoepUmtc canwsyeednesptnhge r broie"

    const/4 v1, 0x5

    const-string/jumbo p2, "oeneow gtshpoddxpmyctte exodcnreec.tenrhe  ainoebsrUc eat"

    const-string p2, "Unexpected exception thrown by generated accessor method."

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    throw p1

    :cond_1
    const/4 v1, 0x0

    check-cast p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    throw p0

    :catch_1
    move-exception p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    const-string/jumbo p2, "otogoblvuptr/u neCmae i  t.e tsdalf cler rtes/oaiinlltmn oocsmenpeoeemf"

    const-string/jumbo p2, "prempife Cefcoe cvaiotomriolnoeettd lm eantl lmanee//oolsu sttn. uc rgs"

    const/4 v1, 0x5

    const-string/jumbo p2, "ue ultueonef .e sts o n llepelairt ecsrotfpianeoog lcvortamcemmoi/d/ntC"

    const-string p2, "Couldn\'t use Java reflection to implement protocol message reflection."

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    throw p1
.end method

.method protected static zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzlm;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, p2}, Lcom/google/android/gms/internal/measurement/zzlm;-><init>(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method protected static zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/internal/measurement/zzjx;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;TT;)V"
        }
    .end annotation

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzjx;->zza:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method static zzbw(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/zzjx;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/internal/measurement/zzjx;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzjx;->zza:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast v1, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v1, :cond_0

    :try_start_0
    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v1, v3, v2}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v1, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "t.aziifpsi loiacltCi aailsoonnn a"

    const-string/jumbo v1, "oiltozsi clnttanafniCi ioaia la.s"

    const/4 v5, 0x6

    const-string v1, "ains znsqo.noitliiaaitta lflCc ia"

    const-string v1, "Class initialization cannot fail."

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    move v5, v4

    throw v0

    :cond_0
    :goto_0
    const/4 v4, 0x4

    move v5, v4

    if-nez v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/google/android/gms/internal/measurement/zzml;->zze(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    check-cast v1, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x6

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3, v3}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v1, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw p0

    :cond_2
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    return-object v1
.end method

.method protected static zzbx()Lcom/google/android/gms/internal/measurement/zzkc;
    .locals 3

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzjy;->zzf()Lcom/google/android/gms/internal/measurement/zzjy;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method protected static zzby()Lcom/google/android/gms/internal/measurement/zzkd;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzkr;->zzf()Lcom/google/android/gms/internal/measurement/zzkr;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method protected static zzbz(Lcom/google/android/gms/internal/measurement/zzkd;)Lcom/google/android/gms/internal/measurement/zzkd;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/16 v0, 0xa

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    add-int/2addr v0, v0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p0, v0}, Lcom/google/android/gms/internal/measurement/zzkd;->zze(I)Lcom/google/android/gms/internal/measurement/zzkd;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne p0, p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez p1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eq v1, v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzlk;->zza()Lcom/google/android/gms/internal/measurement/zzlk;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/measurement/zzlk;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/zzln;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast p1, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/measurement/zzln;->zzi(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    return p1
.end method

.method public final hashCode()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzih;->zzb:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzlk;->zza()Lcom/google/android/gms/internal/measurement/zzlk;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/measurement/zzlk;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/zzln;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/measurement/zzln;->zzb(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzih;->zzb:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/measurement/zzle;->zza(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public final synthetic zzbC()Lcom/google/android/gms/internal/measurement/zzlb;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public final synthetic zzbD()Lcom/google/android/gms/internal/measurement/zzlb;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzay(Lcom/google/android/gms/internal/measurement/zzjx;)Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public final zzbH(Lcom/google/android/gms/internal/measurement/zzje;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzlk;->zza()Lcom/google/android/gms/internal/measurement/zzlk;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/measurement/zzlk;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/zzln;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/internal/measurement/zzjf;->zza(Lcom/google/android/gms/internal/measurement/zzje;)Lcom/google/android/gms/internal/measurement/zzjf;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/measurement/zzln;->zzm(Ljava/lang/Object;Lcom/google/android/gms/internal/measurement/zzjf;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public final synthetic zzbL()Lcom/google/android/gms/internal/measurement/zzlc;
    .locals 4

    const/4 v2, 0x7

    move v3, v2

    const/4 v0, 0x6

    move v3, v0

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method final zzbo()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzd:I

    const/4 v1, 0x7

    move v2, v1

    return v0
.end method

.method final zzbr(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method

.method public final zzbt()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzd:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzlk;->zza()Lcom/google/android/gms/internal/measurement/zzlk;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/measurement/zzlk;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/measurement/zzln;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/measurement/zzln;->zza(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzjx;->zzd:I

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method protected final zzbu()Lcom/google/android/gms/internal/measurement/zzjt;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<MessageType:",
            "Lcom/google/android/gms/internal/measurement/zzjx<",
            "TMessageType;TBuilderType;>;BuilderType:",
            "Lcom/google/android/gms/internal/measurement/zzjt<",
            "TMessageType;TBuilderType;>;>()TBuilderType;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public final zzbv()Lcom/google/android/gms/internal/measurement/zzjt;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TBuilderType;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzay(Lcom/google/android/gms/internal/measurement/zzjx;)Lcom/google/android/gms/internal/measurement/zzjt;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method

.method protected abstract zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
