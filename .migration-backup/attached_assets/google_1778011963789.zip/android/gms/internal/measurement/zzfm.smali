.class public final Lcom/google/android/gms/internal/measurement/zzfm;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfm;",
        "Lcom/google/android/gms/internal/measurement/zzfl;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfm;


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfm;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfm;->zza:Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfm;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/measurement/zzfl;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s@@a~s~~4  ~ @@@~@~n@b@M@i@@ vyl1   /~o b ~ li~ro@cS~t@m~~ t~~ @/ ~f~foi~o@~@b@ ~@o~~do u  ~.-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfm;->zza:Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfl;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/measurement/zzfm;
    .locals 3

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfm;->zza:Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/measurement/zzfm;I)V
    .locals 3

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zzf:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/measurement/zzfm;J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    or-int/lit8 v0, v0, 0x2

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-wide p1, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zzg:J

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zzf:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public final zzb()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zzg:J

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-wide v0
.end method

.method public final zzg()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    return v0
.end method

.method public final zzh()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfm;->zze:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p1, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p3, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x2

    if-eq p1, v0, :cond_3

    const/4 v2, 0x6

    and-int/2addr v3, v2

    if-eq p1, p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p2, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 p3, 0x0

    shl-int/2addr v3, p3

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq p1, p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p2, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p1, p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p3

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfm;->zza:Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v3, 0x0

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfl;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/measurement/zzfl;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v3, 0x0

    return-object p1

    :cond_2
    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfm;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 p3, 0x6

    const/4 p3, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "ezz"

    const-string/jumbo v1, "zez"

    const/4 v3, 0x3

    const-string v1, "ezz"

    const-string/jumbo v1, "zze"

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object v1, p1, p3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zzf"

    const/4 v3, 0x3

    aput-object p3, p1, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x1

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    aput-object p2, p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfm;->zza:Lcom/google/android/gms/internal/measurement/zzfm;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string p3, "/0um/000/2u0u0uuuu001400002u100000u21u0s21///0001100u000u00//00000000u000u//00u0/0/020000/u/00/0"

    const-string p3, "00s0uuu0210001/0u/0000001u/001000u//000/0/0000//uu21u0002//00/00010204000uu00uu000u/21/0000/uu00"

    const/4 v3, 0x0

    const-string p3, "0/02o10u000010//u0/0u002u0000/020//0u/11000000/02u/000u0/uu/0u00u000000/000//0004u0u20u111uu000/"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1004\u0000\u0002\u1002\u0001"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p1
.end method
