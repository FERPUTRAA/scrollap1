.class public final Lcom/google/android/gms/internal/measurement/zzfu;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfu;",
        "Lcom/google/android/gms/internal/measurement/zzft;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfu;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;

.field private zzh:Lcom/google/android/gms/internal/measurement/zzfi;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfu;-><init>()V

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfu;->zza:Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfu;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfu;->zzf:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfu;->zzg:Ljava/lang/String;

    return-void
.end method

.method static synthetic zza()Lcom/google/android/gms/internal/measurement/zzfu;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s K~   ~@m@~f~4 r ~~o@i~b@S~ @od v ~~~n@@ib~s b.@@tlM@@o@ u~~ 1-~o@lo~f~ti@~~@~o @a@c@@/    ~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfu;->zza:Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p3, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eq p1, v1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eq p1, v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eq p1, p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p3, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eq p1, p3, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p2

    :cond_0
    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfu;->zza:Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v4, 0x3

    return-object p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzft;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzft;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfu;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p3, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v2, "zez"

    const-string v2, "ezz"

    const/4 v4, 0x7

    const-string v2, "ezz"

    const-string/jumbo v2, "zze"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    aput-object v2, p1, p3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p3, "zfz"

    const/4 v4, 0x0

    const-string/jumbo p3, "zzf"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    aput-object p3, p1, p2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo p2, "zgz"

    const-string p2, "gzz"

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x2

    aput-object p2, p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo p2, "zhz"

    const-string p2, "hzz"

    const/4 v4, 0x4

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-object p2, p1, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfu;->zza:Lcom/google/android/gms/internal/measurement/zzfu;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string p3, "000m0u000u0u/0uu0012//0000/0/00000/00/u000093uu0010/100u0/u00/u/0s0300/1000u/2u/0/00000008000300u3u/uu/uu/800/1101"

    const-string p3, "03s2u10//00u0/0///00uu8/00000////000u0200/u000000u0u0/3/100u00000/100/101uu00/0uu00900u101u3u00/3080000uu0/000000u"

    const/4 v4, 0x1

    const-string p3, "0811ou/001//uu/u000u00000u0uu0uu000/0031000//00u01/0u00/000u0000/u00/000190/u//003/03u0uu3u0/20/1200000/000081000/"

    const-string p3, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001\u0003\u1009\u0002"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p1
.end method
