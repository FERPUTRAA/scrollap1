.class public final Lcom/google/android/gms/internal/measurement/zzfw;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfw;",
        "Lcom/google/android/gms/internal/measurement/zzfv;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfw;


# instance fields
.field private zze:Lcom/google/android/gms/internal/measurement/zzke;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "Lcom/google/android/gms/internal/measurement/zzfy;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfw;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfw;->zza:Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfw;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfw;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbA()Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/measurement/zzfv;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "M~s@~/@~~ @~os4i@ n@~f~~~  /@KS1@c  ~@~t ~ ~b@oo @ @ @~~@-o@@y orf~t @b i~@~a@ m~ @d~.v@iub ol~l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfw;->zza:Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfv;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/measurement/zzfw;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfw;->zza:Lcom/google/android/gms/internal/measurement/zzfw;

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/measurement/zzfw;Lcom/google/android/gms/internal/measurement/zzfy;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/google/android/gms/internal/measurement/zzke;->zzc()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbB(Lcom/google/android/gms/internal/measurement/zzke;)Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p0, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public final zzc(I)Lcom/google/android/gms/internal/measurement/zzfy;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Lcom/google/android/gms/internal/measurement/zzfy;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method

.method public final zzd()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/android/gms/internal/measurement/zzfy;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfw;->zze:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 p2, 0x1

    shl-int/2addr v2, p2

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    if-eqz p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 p3, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p1, p3, :cond_3

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eq p1, p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p2, 0x4

    const/4 p3, 0x2

    const/4 p3, 0x2

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eq p1, p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 p2, 0x5

    and-int/2addr v2, p2

    if-eq p1, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p3

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfw;->zza:Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfv;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/measurement/zzfv;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfw;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "zze"

    const/4 v2, 0x3

    const-string/jumbo v0, "zez"

    const-string/jumbo v0, "zze"

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    aput-object v0, p1, p3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-class p3, Lcom/google/android/gms/internal/measurement/zzfy;

    const-class p3, Lcom/google/android/gms/internal/measurement/zzfy;

    const/4 v2, 0x1

    const-class p3, Lcom/google/android/gms/internal/measurement/zzfy;

    const-class p3, Lcom/google/android/gms/internal/measurement/zzfy;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    aput-object p3, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfw;->zza:Lcom/google/android/gms/internal/measurement/zzfw;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string p3, "000m//u00/0/0/0u0/000u1/000s0/000/1/0100000u/uu00111ub000000u10/u0uu010u"

    const-string/jumbo p3, "u0s000uu0/u100u0100//00//uu0u0u/100u0010/0//01000u100/0100u000/1000/0b00"

    const/4 v2, 0x3

    const-string p3, "0000o0u00100011000u100/u0000u///u00u00b00u01/00u00110/uu000/100u/0//u/0/"

    const-string p3, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b"

    const/4 v2, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1

    :cond_4
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method
