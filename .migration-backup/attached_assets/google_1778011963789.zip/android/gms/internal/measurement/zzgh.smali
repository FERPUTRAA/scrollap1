.class public final Lcom/google/android/gms/internal/measurement/zzgh;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzgh;",
        "Lcom/google/android/gms/internal/measurement/zzgg;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzgh;


# instance fields
.field private zze:I

.field private zzf:J

.field private zzg:Ljava/lang/String;

.field private zzh:Ljava/lang/String;

.field private zzi:J

.field private zzj:F

.field private zzk:D


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzgh;-><init>()V

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgh;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzg:Ljava/lang/String;

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzh:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public static zzd()Lcom/google/android/gms/internal/measurement/zzgg;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~bs ~b @@@d @t@~c~~~M om~~@~@  @4y@i@S~~~a  o~~t~@K~@@@ f i os@o ~ @rl~vlb~@/~n~ ou @. of/~@-i@1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgg;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zze()Lcom/google/android/gms/internal/measurement/zzgh;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/measurement/zzgh;J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzf:J

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/measurement/zzgh;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    or-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzg:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic zzj(Lcom/google/android/gms/internal/measurement/zzgh;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzh:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/gms/internal/measurement/zzgh;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, v0, Lcom/google/android/gms/internal/measurement/zzgh;->zzh:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzh:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic zzm(Lcom/google/android/gms/internal/measurement/zzgh;J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzi:J

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic zzn(Lcom/google/android/gms/internal/measurement/zzgh;)V
    .locals 4

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    and-int/lit8 v0, v0, -0x9

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzi:J

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic zzo(Lcom/google/android/gms/internal/measurement/zzgh;D)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x20

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x6

    iput-wide p1, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzk:D

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic zzp(Lcom/google/android/gms/internal/measurement/zzgh;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    and-int/lit8 v0, v0, -0x21

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzk:D

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public final zza()D
    .locals 4

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzk:D

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0
.end method

.method public final zzb()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzi:J

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method

.method public final zzc()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzf:J

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-wide v0
.end method

.method public final zzf()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzg:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public final zzg()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zzh:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 p2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz p1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 p3, 0x5

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v0, 0x4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v1, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eq p1, v2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eq p1, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 p2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    if-eq p1, v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eq p1, p3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-object p2

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object p1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgg;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzgg;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzgh;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    return-object p1

    :cond_3
    const/4 v6, 0x4

    const/4 p1, 0x5

    const/4 v6, 0x0

    const/4 p1, 0x7

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v4, "ezz"

    const-string v4, "ezz"

    const/4 v6, 0x6

    const-string/jumbo v4, "zze"

    const-string/jumbo v4, "zze"

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    aput-object v4, p1, v3

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo v3, "zfz"

    const-string/jumbo v3, "zzf"

    aput-object v3, p1, p2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    aput-object p2, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x1

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    aput-object p2, p1, v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo p2, "izz"

    const-string/jumbo p2, "ziz"

    const/4 v6, 0x5

    const-string/jumbo p2, "zzi"

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    aput-object p2, p1, v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo p2, "jzz"

    const-string/jumbo p2, "zzj"

    const/4 v6, 0x2

    const-string/jumbo p2, "jzz"

    const-string/jumbo p2, "zzj"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    aput-object p2, p1, p3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 p2, 0x6

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo p3, "kzz"

    const-string/jumbo p3, "kzz"

    const-string/jumbo p3, "zkz"

    const-string/jumbo p3, "zzk"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    aput-object p3, p1, p2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzgh;->zza:Lcom/google/android/gms/internal/measurement/zzgh;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string p3, "00/m8/00u0/40u0/00102000000/1uu6006000106/00/u/0/0/000u8uu0/u000001/00/0001u00//000uu000//00u/1300/u/00010u//1/0u0/02uu00000u2u0/60u40200u0u001050/01u0000u001/0u053/u0u"

    const-string p3, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u1002\u0000\u0002\u1008\u0001\u0003\u1008\u0002\u0004\u1002\u0003\u0005\u1001\u0004\u0006\u1000\u0005"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-object p1

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p1
.end method

.method public final zzq()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public final zzr()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public final zzs()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method public final zzt()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgh;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    and-int/2addr v1, v0

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method
