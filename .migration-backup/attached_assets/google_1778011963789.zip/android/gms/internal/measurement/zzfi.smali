.class public final Lcom/google/android/gms/internal/measurement/zzfi;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfi;",
        "Lcom/google/android/gms/internal/measurement/zzfh;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfi;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;

.field private zzh:Ljava/lang/String;

.field private zzi:Ljava/lang/String;

.field private zzj:Ljava/lang/String;

.field private zzk:Ljava/lang/String;

.field private zzl:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfi;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfi;->zza:Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfi;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzf:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzg:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzh:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzi:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzj:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzk:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfi;->zzl:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic zza()Lcom/google/android/gms/internal/measurement/zzfi;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfi;->zza:Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 p2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-eqz p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 p3, 0x1

    const/4 p3, 0x5

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v0, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v1, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eq p1, v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq p1, v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 p2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eq p1, v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eq p1, p3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-object p2

    :cond_0
    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfi;->zza:Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object p1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfh;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzfh;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    return-object p1

    :cond_2
    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v6, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfi;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object p1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/16 p1, 0x8

    const/4 v6, 0x7

    const/4 v5, 0x2

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string v4, "ezz"

    const-string/jumbo v4, "zze"

    const/4 v6, 0x3

    const-string v4, "ezz"

    const-string/jumbo v4, "zze"

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    aput-object v4, p1, v3

    const-string v3, "fzz"

    const-string/jumbo v3, "zfz"

    const-string/jumbo v3, "zfz"

    const-string/jumbo v3, "zzf"

    const/4 v6, 0x2

    aput-object v3, p1, p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zgz"

    const/4 v6, 0x4

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    aput-object p2, p1, v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const-string/jumbo p2, "zhz"

    const-string/jumbo p2, "zhz"

    const/4 v6, 0x6

    const-string/jumbo p2, "zzh"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    aput-object p2, p1, v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    aput-object p2, p1, v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo p2, "zzj"

    const-string/jumbo p2, "zzj"

    const/4 v6, 0x2

    const-string/jumbo p2, "jzz"

    const-string/jumbo p2, "zzj"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput-object p2, p1, p3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 p2, 0x6

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo p3, "zzk"

    const-string/jumbo p3, "zzk"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    aput-object p3, p1, p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 p2, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo p3, "zzl"

    const-string/jumbo p3, "zzl"

    const-string/jumbo p3, "zzl"

    const-string/jumbo p3, "zzl"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    aput-object p3, p1, p2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfi;->zza:Lcom/google/android/gms/internal/measurement/zzfi;

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string p3, "10s0/100/0/01000/u01/7u81700u001/80u004400u00/0/00000u05u0000/uu/0u0080u0u0800/u1u00u0000u/780u020u06u//001/0/80000/0/0/0001/u0u00/00/0/1306/730u00//1u/u/0000000800001u0u002u0usu0u/00u05"

    const-string p3, "70s400000001/1/0u30/510//u000088//00000/u5u0100u00000u7000/u00u10000610uuu0u0008/0180000/00000/0u/0///u031/0010uuu00/00uu2u00//0u000u/01u06///80001u0//0u/7/u000/0008u00u1u0008u700240u0/0"

    const/4 v6, 0x3

    const-string p3, "0/8m0u0000u00u400u00u0//1uu71000u00/16u//0001/0704u805000u/000/0u//07100/000000008/080/u20011uu0u/0/uu000/10u/u0/00/00000/1u000uu03020/0000/001/30/00u7u0000000u///00u/0u0u800//u0u0861185"

    const-string p3, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001\u0003\u1008\u0002\u0004\u1008\u0003\u0005\u1008\u0004\u0006\u1008\u0005\u0007\u1008\u0006"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object p1

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object p1
.end method
