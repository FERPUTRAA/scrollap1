.class public final Lcom/google/android/gms/internal/measurement/zzfa;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfa;",
        "Lcom/google/android/gms/internal/measurement/zzez;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfa;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Z

.field private zzh:Z

.field private zzi:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfa;-><init>()V

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfa;->zza:Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfa;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfa;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzf:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/measurement/zzfa;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s -o t/iS~ @~~n~i@/  @yo@~ f@d~o@m~a@@~.K1Mo@@@@~o@    f~it~v@@~~ b@l @bu~@~~@ c4~  ~~@robs ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfa;->zza:Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzd(Lcom/google/android/gms/internal/measurement/zzfa;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zze:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zze:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzf:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzi:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public final zzc()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzf:Ljava/lang/String;

    const/4 v2, 0x7

    return-object v0
.end method

.method public final zze()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzg:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public final zzf()Z
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zzh:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public final zzg()Z
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    or-int/2addr v2, v1

    return v0
.end method

.method public final zzh()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zze:I

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public final zzi()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfa;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 p2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 p3, 0x5

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x4

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x3

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x1

    move v5, v4

    if-eq p1, v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eq p1, v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 p2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq p1, v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    if-eq p1, p3, :cond_0

    const/4 v4, 0x7

    and-int/2addr v5, v4

    return-object p2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfa;->zza:Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzez;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzez;-><init>(Lcom/google/android/gms/internal/measurement/zzey;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object p1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfa;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object p1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 p3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v3, "zez"

    const-string/jumbo v3, "zez"

    const/4 v5, 0x1

    const-string/jumbo v3, "zze"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    aput-object v3, p1, p3

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    const-string p3, "fzz"

    const-string/jumbo p3, "zfz"

    const/4 v5, 0x1

    const-string/jumbo p3, "zzf"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    aput-object p3, p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    aput-object p2, p1, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo p2, "zhz"

    const-string/jumbo p2, "zhz"

    const/4 v5, 0x6

    const-string/jumbo p2, "zzh"

    const-string/jumbo p2, "zzh"

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    aput-object p2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v5, 0x0

    const-string/jumbo p2, "ziz"

    const-string/jumbo p2, "zzi"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    aput-object p2, p1, v0

    const/4 v5, 0x6

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfa;->zza:Lcom/google/android/gms/internal/measurement/zzfa;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string p3, "302m007100u01u0000/0uu000u/0/u0/0u300000/0u0u0080u00uu40u0040u0/10/000u0u0000020/11/00/00/0//4u4/0410u///0/u/1u17000u00u0/0/10s00000"

    const-string p3, "01s0/1/u008u0/4u03u00100u11//4/0u1000000/00700/000u1u000u00/00//40uu240000//u030/u0000/u010u7u000/0000/u000u0//u200u0u0u004/0/100000"

    const/4 v5, 0x2

    const-string p3, "/u00o0//0003070/100u0u0000/000uuu//400u0u3/000u0u011///u04u00040u00000/0140010011070/00000/0u8/002000//u000//000u0/0/1u01040u0u2uu/0"

    const-string p3, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1007\u0001\u0003\u1007\u0002\u0004\u1004\u0003"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    return-object p1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object p1
.end method
