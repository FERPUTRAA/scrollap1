.class public final Lcom/google/android/gms/internal/measurement/zzgc;
.super Lcom/google/android/gms/internal/measurement/zzjt;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjt<",
        "Lcom/google/android/gms/internal/measurement/zzgd;",
        "Lcom/google/android/gms/internal/measurement/zzgc;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgd;->zzg()Lcom/google/android/gms/internal/measurement/zzgd;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/measurement/zzff;)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgd;->zzg()Lcom/google/android/gms/internal/measurement/zzgd;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final zza(Ljava/lang/Iterable;)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/google/android/gms/internal/measurement/zzfm;",
            ">;)",
            "Lcom/google/android/gms/internal/measurement/zzgc;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s @~~@b@@ @@v/ K~io@m a@o1S  ob~ls~@4~-o@~ @@f~  o@~~@ ~@ yMft@c~i d@bi~to@l u~ ~~/r . ~~@~ @n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzs(Lcom/google/android/gms/internal/measurement/zzgd;Ljava/lang/Iterable;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public final zzb(Ljava/lang/Iterable;)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Long;",
            ">;)",
            "Lcom/google/android/gms/internal/measurement/zzgc;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzq(Lcom/google/android/gms/internal/measurement/zzgd;Ljava/lang/Iterable;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public final zzc(Ljava/lang/Iterable;)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/google/android/gms/internal/measurement/zzgf;",
            ">;)",
            "Lcom/google/android/gms/internal/measurement/zzgc;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x6

    const/4 v1, 0x2

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzu(Lcom/google/android/gms/internal/measurement/zzgd;Ljava/lang/Iterable;)V

    const/4 v2, 0x4

    return-object p0
.end method

.method public final zzd(Ljava/lang/Iterable;)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Long;",
            ">;)",
            "Lcom/google/android/gms/internal/measurement/zzgc;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzo(Lcom/google/android/gms/internal/measurement/zzgd;Ljava/lang/Iterable;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public final zze()Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/zzgd;->zzr(Lcom/google/android/gms/internal/measurement/zzgd;)V

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public final zzf()Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    move v1, v0

    move v1, v0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/zzgd;->zzp(Lcom/google/android/gms/internal/measurement/zzgd;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public final zzg(I)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzt(Lcom/google/android/gms/internal/measurement/zzgd;I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public final zzh(I)Lcom/google/android/gms/internal/measurement/zzgc;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgd;->zzv(Lcom/google/android/gms/internal/measurement/zzgd;I)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method
