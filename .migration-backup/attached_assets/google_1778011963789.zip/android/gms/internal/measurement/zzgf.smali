.class public final Lcom/google/android/gms/internal/measurement/zzgf;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzgf;",
        "Lcom/google/android/gms/internal/measurement/zzge;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzgf;


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:Lcom/google/android/gms/internal/measurement/zzkd;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzgf;-><init>()V

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzgf;->zza:Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgf;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzjx;->zzby()Lcom/google/android/gms/internal/measurement/zzkd;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public static zzd()Lcom/google/android/gms/internal/measurement/zzge;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s  d1n t4o~ a~.~ol~@oo~   ~~~~b@@m o@sSl~@@~@i~c  ~@ b@b~~Kfot-~ @@@v/~y/~ @i@@@u ~@M ~f i@ r~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgf;->zza:Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzge;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zze()Lcom/google/android/gms/internal/measurement/zzgf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgf;->zza:Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/measurement/zzgf;I)V
    .locals 3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zze:I

    const/4 v1, 0x6

    const/4 v1, 0x1

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzf:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/measurement/zzgf;Ljava/lang/Iterable;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/internal/measurement/zzke;->zzc()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbz(Lcom/google/android/gms/internal/measurement/zzkd;)Lcom/google/android/gms/internal/measurement/zzkd;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object p0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-static {p1, p0}, Lcom/google/android/gms/internal/measurement/zzih;->zzbq(Ljava/lang/Iterable;Ljava/util/List;)V

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public final zzb()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzf:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public final zzc(I)J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lcom/google/android/gms/internal/measurement/zzkd;->zza(I)J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method public final zzf()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zzg:Lcom/google/android/gms/internal/measurement/zzkd;

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-object v0
.end method

.method public final zzi()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzgf;->zze:I

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    move v3, v2

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p3, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eq p1, v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x3

    if-eq p1, p3, :cond_2

    const/4 v3, 0x3

    const/4 p2, 0x4

    const/4 v3, 0x0

    move v2, p2

    move v2, p2

    const/4 v3, 0x7

    const/4 p3, 0x4

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eq p1, p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p2, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x7

    if-eq p1, p2, :cond_0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    return-object p3

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzgf;->zza:Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzge;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/measurement/zzge;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzgf;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p3, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "zze"

    const-string/jumbo v1, "zez"

    const/4 v3, 0x4

    const-string/jumbo v1, "zze"

    const/4 v3, 0x6

    aput-object v1, p1, p3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p3, "fzz"

    const-string/jumbo p3, "zfz"

    const/4 v3, 0x3

    const-string/jumbo p3, "zzf"

    aput-object p3, p1, p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x1

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    aput-object p2, p1, v0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzgf;->zza:Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p3, "00s/0u01/00//00u/u/400/01000/0u0000u0u/00u10uu100u000000u0u021uu0/u20000000/2101/020/0400/"

    const/4 v3, 0x6

    const-string p3, "020m0u0u000/100u020200u1uu0004u/0/000/0u0u00/000/0/u00100u1u000/1410001//02//0/u/0u0/00u00"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u1004\u0000\u0002\u0014"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p1

    :cond_4
    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p1
.end method
