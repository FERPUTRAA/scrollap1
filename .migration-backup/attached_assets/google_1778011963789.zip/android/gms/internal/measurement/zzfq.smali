.class public final Lcom/google/android/gms/internal/measurement/zzfq;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfq;",
        "Lcom/google/android/gms/internal/measurement/zzfp;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfq;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfq;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfq;->zza:Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfq;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfq;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zzf:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/measurement/zzfp;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s so@ oi/f~Sa~~@ o@~@~@i @f~@~lr@v~b1ub@@ ~ ~~-~~@ i @~@ nd  cm ~o/~oK@.@~@yb~  @@t@M ~@lo~ t4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfq;->zza:Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfp;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/measurement/zzfq;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfq;->zza:Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzc(Lcom/google/android/gms/internal/measurement/zzfq;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zzf:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic zzd(Lcom/google/android/gms/internal/measurement/zzfq;J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zze:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    or-int/lit8 v0, v0, 0x2

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zze:I

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/google/android/gms/internal/measurement/zzfq;->zzg:J

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x0

    const/4 p2, 0x7

    const/4 p2, 0x1

    or-int/2addr v3, p2

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p3, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x1

    and-int/2addr v3, v2

    if-eq p1, v0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eq p1, p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p2, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 p3, 0x0

    xor-int/2addr v3, p3

    const/4 v2, 0x0

    or-int/2addr v3, v2

    if-eq p1, p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 p2, 0x5

    shr-int/2addr v3, p2

    const/4 v2, 0x3

    move v3, v2

    if-eq p1, p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p3

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfq;->zza:Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x3

    return-object p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfp;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/measurement/zzfp;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v2, 0x7

    const/4 v2, 0x2

    return-object p1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfq;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "zez"

    const-string/jumbo v1, "zze"

    const/4 v3, 0x0

    const-string v1, "ezz"

    const-string/jumbo v1, "zze"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object v1, p1, p3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo p3, "zzf"

    const-string p3, "fzz"

    const/4 v3, 0x0

    const-string p3, "fzz"

    const-string/jumbo p3, "zzf"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    aput-object p3, p1, p2

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p2, "gzz"

    const-string p2, "gzz"

    const/4 v3, 0x7

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-object p2, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfq;->zza:Lcom/google/android/gms/internal/measurement/zzfq;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string p3, "00s010/0u000u//0u0020u02/0/0u000001000/0/u00/010000/0u0//100/001u00000u01u/0082/12uuu00//00u02u0"

    const/4 v3, 0x6

    const-string p3, "100m0000100/0/000002u2u0/0/u2000/20000uu/100u0u1080u000001////u10u0u/0uu0/0u20/001000000u/000u0/"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1002\u0001"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p1
.end method
