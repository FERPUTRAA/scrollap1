.class public final Lcom/google/android/gms/internal/measurement/zzgl;
.super Lcom/google/android/gms/internal/measurement/zzjt;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjt<",
        "Lcom/google/android/gms/internal/measurement/zzgm;",
        "Lcom/google/android/gms/internal/measurement/zzgl;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgm;->zza()Lcom/google/android/gms/internal/measurement/zzgm;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/measurement/zzgi;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgm;->zza()Lcom/google/android/gms/internal/measurement/zzgm;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method
