.class public final Lcom/google/android/gms/internal/measurement/zzfk;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfk;",
        "Lcom/google/android/gms/internal/measurement/zzfj;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfk;


# instance fields
.field private zze:I

.field private zzf:I

.field private zzg:Lcom/google/android/gms/internal/measurement/zzgd;

.field private zzh:Lcom/google/android/gms/internal/measurement/zzgd;

.field private zzi:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfk;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfk;->zza:Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfk;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/measurement/zzfj;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os@4@ ~ r@~ l@o@~~ y~1 ~~f~ @~oi~a i@@cu~  tb@/  to@.~@~@b~iS~ m@os@~~~ ~~M @@K~ @ob~ vl@- @fd/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfk;->zza:Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbu()Lcom/google/android/gms/internal/measurement/zzjt;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzfj;

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/measurement/zzfk;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfk;->zza:Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/measurement/zzfk;I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzf:I

    const/4 v1, 0x7

    or-int/2addr v2, v1

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/measurement/zzfk;Lcom/google/android/gms/internal/measurement/zzgd;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzg:Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/measurement/zzfk;Lcom/google/android/gms/internal/measurement/zzgd;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzh:Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/measurement/zzfk;Z)V
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    or-int/lit8 v0, v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzi:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzf:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    return v0
.end method

.method public final zzd()Lcom/google/android/gms/internal/measurement/zzgd;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzg:Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgd;->zzh()Lcom/google/android/gms/internal/measurement/zzgd;

    move-result-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object v0
.end method

.method public final zze()Lcom/google/android/gms/internal/measurement/zzgd;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzh:Lcom/google/android/gms/internal/measurement/zzgd;

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgd;->zzh()Lcom/google/android/gms/internal/measurement/zzgd;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public final zzj()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zzi:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public final zzk()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 p2, 0x1

    move v5, p2

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 p3, 0x5

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v0, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq p1, v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq p1, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 p2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq p1, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq p1, p3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p2

    :cond_0
    const/4 v4, 0x1

    const/4 v4, 0x1

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfk;->zza:Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfj;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzfj;-><init>(Lcom/google/android/gms/internal/measurement/zzff;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v5, 0x0

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfk;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 p3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v3, "zze"

    const-string/jumbo v3, "zez"

    const/4 v5, 0x7

    const-string/jumbo v3, "zze"

    const-string/jumbo v3, "zze"

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    aput-object v3, p1, p3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo p3, "zzf"

    const-string/jumbo p3, "zfz"

    const/4 v5, 0x3

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zzf"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    aput-object p3, p1, p2

    const-string/jumbo p2, "zgz"

    const/4 v5, 0x0

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    aput-object p2, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p2, "zzh"

    const-string/jumbo p2, "zhz"

    const/4 v5, 0x4

    const-string/jumbo p2, "zhz"

    const-string/jumbo p2, "zzh"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    aput-object p2, p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const-string/jumbo p2, "ziz"

    const/4 v5, 0x7

    const-string/jumbo p2, "zzi"

    const-string/jumbo p2, "zzi"

    const/4 v5, 0x5

    aput-object p2, p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfk;->zza:Lcom/google/android/gms/internal/measurement/zzfk;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string p3, "/0/m/u0/10u0000000/1/901//4/0000/0/u0uuu010000/0/u1/012u00u0/04uu00s004u00102000u4u/u000/0u00000u00/01130uu/039004/000u0/000000u700u"

    const-string/jumbo p3, "u0s/90000/0/u20/uu/00u/u000u/0014u203101///00/000u00u/900001u0/000/40u00000117u000/0014//u01u00/0/400000000u0u00u1/4000uu00000/u03/u"

    const/4 v5, 0x5

    const-string p3, "0u0/o710u0000u100040/00001u0/00/1u004/0/00030u/0004010/00041030/10uuu00002/u00010uu20/0/0u04u0u/00//0/u0/u/0/00/0/u090u100u90u00/000"

    const-string p3, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1004\u0000\u0002\u1009\u0001\u0003\u1009\u0002\u0004\u1007\u0003"

    const/4 v4, 0x4

    or-int/2addr v5, v4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object p1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object p1
.end method

.method public final zzm()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    return v0
.end method

.method public final zzn()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/measurement/zzfk;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method
