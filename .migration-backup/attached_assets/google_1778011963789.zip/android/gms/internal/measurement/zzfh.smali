.class public final Lcom/google/android/gms/internal/measurement/zzfh;
.super Lcom/google/android/gms/internal/measurement/zzjt;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjt<",
        "Lcom/google/android/gms/internal/measurement/zzfi;",
        "Lcom/google/android/gms/internal/measurement/zzfh;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzfi;->zza()Lcom/google/android/gms/internal/measurement/zzfi;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v2, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/measurement/zzff;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzfi;->zza()Lcom/google/android/gms/internal/measurement/zzfi;

    move-result-object p1

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
