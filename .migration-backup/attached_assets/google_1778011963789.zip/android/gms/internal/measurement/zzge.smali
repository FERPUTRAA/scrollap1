.class public final Lcom/google/android/gms/internal/measurement/zzge;
.super Lcom/google/android/gms/internal/measurement/zzjt;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjt<",
        "Lcom/google/android/gms/internal/measurement/zzgf;",
        "Lcom/google/android/gms/internal/measurement/zzge;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgf;->zze()Lcom/google/android/gms/internal/measurement/zzgf;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/measurement/zzff;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgf;->zze()Lcom/google/android/gms/internal/measurement/zzgf;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/measurement/zzjt;-><init>(Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zza(Ljava/lang/Iterable;)Lcom/google/android/gms/internal/measurement/zzge;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Ljava/lang/Long;",
            ">;)",
            "Lcom/google/android/gms/internal/measurement/zzge;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@s @o~v@~ @@~i1 @@t@sr~d~ @  o~@ o~ ~~a~@@@@Sf o~o/~n~~Kyl~b Mf.uo@  -~/mt @ @@b~  l@~c4i~~i ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgf;->zzh(Lcom/google/android/gms/internal/measurement/zzgf;Ljava/lang/Iterable;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public final zzb(I)Lcom/google/android/gms/internal/measurement/zzge;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/measurement/zzjt;->zzaE()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zzb:Z

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzjt;->zza:Lcom/google/android/gms/internal/measurement/zzjx;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/measurement/zzgf;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/measurement/zzgf;->zzg(Lcom/google/android/gms/internal/measurement/zzgf;I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method
