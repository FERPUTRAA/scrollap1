.class public final Lcom/google/android/gms/internal/measurement/zzgo;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzgo;",
        "Lcom/google/android/gms/internal/measurement/zzgn;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzgo;


# instance fields
.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/measurement/zzke;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/internal/measurement/zzke<",
            "Lcom/google/android/gms/internal/measurement/zzgt;",
            ">;"
        }
    .end annotation
.end field

.field private zzg:Lcom/google/android/gms/internal/measurement/zzgk;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzgo;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzgo;->zza:Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgo;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgo;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgo;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbA()Lcom/google/android/gms/internal/measurement/zzke;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgo;->zzf:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/measurement/zzgo;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~MsaS ~iio ~ ~~ c@@@ tK~4@@ @/ l-  d~f~mu.@v~/@r~~ ~oy@so1o~@@@b@ ~~@ltn@i@~ @b~@b ~@f ~ ~@~ o ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzgo;->zza:Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public final zza()Lcom/google/android/gms/internal/measurement/zzgk;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgo;->zzg:Lcom/google/android/gms/internal/measurement/zzgk;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/measurement/zzgk;->zzc()Lcom/google/android/gms/internal/measurement/zzgk;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public final zzc()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/android/gms/internal/measurement/zzgt;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzgo;->zzf:Lcom/google/android/gms/internal/measurement/zzke;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 p2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p1, :cond_4

    const/4 v4, 0x6

    const/4 p3, 0x1

    const/4 v4, 0x0

    const/4 p3, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eq p1, v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eq p1, v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, p3, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 p3, 0x2

    const/4 p3, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eq p1, p3, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object p2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzgo;->zza:Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgn;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/measurement/zzgn;-><init>(Lcom/google/android/gms/internal/measurement/zzgi;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzgo;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 p3, 0x3

    const/4 v4, 0x1

    const/4 p3, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v2, "zze"

    const-string v2, "ezz"

    const/4 v4, 0x5

    const-string/jumbo v2, "zze"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object v2, p1, p3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zzf"

    const/4 v4, 0x1

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zzf"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput-object p3, p1, p2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-class p2, Lcom/google/android/gms/internal/measurement/zzgt;

    const-class p2, Lcom/google/android/gms/internal/measurement/zzgt;

    const/4 v4, 0x0

    const-class p2, Lcom/google/android/gms/internal/measurement/zzgt;

    const-class p2, Lcom/google/android/gms/internal/measurement/zzgt;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    aput-object p2, p1, v1

    const/4 v4, 0x1

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zgz"

    const/4 v4, 0x2

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput-object p2, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzgo;->zza:Lcom/google/android/gms/internal/measurement/zzgo;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo p3, "u1s010/0000u0002u00/u0/uu00/0/01000u0u///0u120u00000u0u0012u00000000ub09///0/0u/1/12000/00"

    const/4 v4, 0x1

    const-string p3, "00um0/00202/01/0/0/u000110000u0/uuu/uu0000009/01//00000/00u0/0u/10200u120/00000u10u0/b000u"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002\u1009\u0000"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p1
.end method
