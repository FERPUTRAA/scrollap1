.class public final Lcom/google/android/gms/internal/measurement/zzfe;
.super Lcom/google/android/gms/internal/measurement/zzjx;

# interfaces
.implements Lcom/google/android/gms/internal/measurement/zzld;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/internal/measurement/zzjx<",
        "Lcom/google/android/gms/internal/measurement/zzfe;",
        "Lcom/google/android/gms/internal/measurement/zzfd;",
        ">;",
        "Lcom/google/android/gms/internal/measurement/zzld;"
    }
.end annotation


# static fields
.field private static final zza:Lcom/google/android/gms/internal/measurement/zzfe;


# instance fields
.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/measurement/zzfe;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/measurement/zzfe;->zza:Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfe;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfe;

    const-class v1, Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbG(Ljava/lang/Class;Lcom/google/android/gms/internal/measurement/zzjx;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/measurement/zzjx;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfe;->zzf:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfe;->zzg:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic zza()Lcom/google/android/gms/internal/measurement/zzfe;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/sMao  o~~t@  ~ vb@ f @d~~@o@~c-@lsbo@~~~@ @~@1 f@ 4 y~S~ K o@i~@~u~~o tl~n~~~ i@~@~m@r@@/i@ . "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/measurement/zzfe;->zza:Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public final zzb()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfe;->zzf:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public final zzc()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/measurement/zzfe;->zzg:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final zzl(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p1, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x6

    shl-int/2addr v2, v0

    const/4 v3, 0x2

    if-eq p1, v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq p1, p3, :cond_2

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 p2, 0x6

    const/4 p2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p3, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eq p1, p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p2, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq p1, p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p3

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p1, Lcom/google/android/gms/internal/measurement/zzfe;->zza:Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfd;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/measurement/zzfd;-><init>(Lcom/google/android/gms/internal/measurement/zzey;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/measurement/zzfe;-><init>()V

    const/4 v3, 0x4

    return-object p1

    :cond_3
    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "ezz"

    const-string/jumbo v1, "zze"

    const/4 v3, 0x4

    const-string/jumbo v1, "zez"

    const-string/jumbo v1, "zze"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object v1, p1, p3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo p3, "zfz"

    const-string/jumbo p3, "zzf"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p3, p1, p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const-string/jumbo p2, "zzg"

    const-string p2, "gzz"

    const/4 v3, 0x0

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    aput-object p2, p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object p2, Lcom/google/android/gms/internal/measurement/zzfe;->zza:Lcom/google/android/gms/internal/measurement/zzfe;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p3, "u00m00/0/10/0u0u0//000u/u000201u/00/101/000u0u/20u010000u0/80u200000000u0101u2080u000/s/000/0uu/"

    const-string p3, "00su10/010/002/00000u/1000u100u0200u00u82u0///00000u8//u0/00/0/00u0000u/000/u0200u/1001u001/00uu"

    const/4 v3, 0x5

    const-string p3, "0uu0o0/01100/u/1020001010000/0u000/00u00/00u00/20/u1u00/0/u//0uu/00000u/u00u000//0200020080u0u10"

    const-string p3, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1008\u0000\u0002\u1008\u0001"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/measurement/zzjx;->zzbF(Lcom/google/android/gms/internal/measurement/zzlc;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    return-object p1
.end method
