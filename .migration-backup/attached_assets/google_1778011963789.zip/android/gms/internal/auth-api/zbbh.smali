.class public final Lcom/google/android/gms/internal/auth-api/zbbh;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final zba:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/auth/api/identity/y;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/16 v3, 0xd4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance p1, Landroid/os/Bundle;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/auth-api/zbbh;->zba:Landroid/os/Bundle;

    const/4 v8, 0x5

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ds~~~f@@l m@ @b@ oiv4  n~ s  ~o~~@~@caio~ @@ @ ofMr~~~~~/~    u.@@-~@@o1@t@@~~~i  /~b@by@S~~oKt"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, "a.tmgeSur.agr.Itsieniaeolnadnitrodlcsnmcy.eeni.oihngo.vtSIp.gmid"

    const-string v0, "hgsiintanlt.ci.luieSepo.dnacieov.Soo.dtn..gyaignmndIteI.garsmrre"

    const/4 v3, 0x0

    const-string/jumbo v0, "r.ntoeg.S.nII.ottacSiadinhecisniaugy.ilvoen.mgi.roidno.readgeplm"

    const-string v0, "com.google.android.gms.auth.api.identity.internal.ISignInService"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    instance-of v1, v0, Lcom/google/android/gms/internal/auth-api/zbam;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/internal/auth-api/zbam;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/auth-api/zbam;

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth-api/zbam;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/auth-api/zbbi;->zbi:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/auth-api/zbbh;->zba:Landroid/os/Bundle;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const v0, 0x1110e58

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "auiiabmnnIdIop..ahaegleSr.isvnmlmteoSroecg.nc.nti.ttg.ioedgnr.iy"

    const-string v0, "Sdamyee.r.nmios.giniranSneplv.iha.I.ngtoegcireIaliottndiu.m.tgco"

    const/4 v2, 0x6

    const-string v0, "Iinoldumamlu.doarvno.nyerSinetiar.iionsth..ep.e..tggIgncdciSigae"

    const-string v0, "com.google.android.gms.auth.api.identity.internal.ISignInService"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "iisoipcpuTgd.nditldstigi..oav.e.ooanrAmy.eisaggn.tr.Rho.SeTen"

    const-string v0, ".eirosroggSogcyi.i.eTint.tlsaegAsRahid.uovp.ien.mdio..Tntmdna"

    const/4 v2, 0x7

    const-string/jumbo v0, "ign.gtT.qcotosgaihAesidiaoeRocmesn.euiamyvn.rrdtn..gpT.Sldii."

    const-string v0, "com.google.android.gms.auth.api.identity.service.signin.START"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method
