.class public final Lcom/google/android/gms/internal/auth-api/zbw;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final zba:Landroid/os/Bundle;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/auth/api/identity/g;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x2

    const/16 v3, 0xdb

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p3}, Lcom/google/android/gms/auth/api/identity/g;->a()Landroid/os/Bundle;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/auth-api/zbw;->zba:Landroid/os/Bundle;

    const/4 v8, 0x6

    const/4 v7, 0x6

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s @@  a@@1ir ~u~n~@~@4@l~~y~~@obi @o.v@@f SoK~@ @lto~d@ ~~o b@  ~~/ @@s~ /~@-~~tmMb oc~~~fi @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v0, "dlnmcrolhnrt.stIttee..niateirany.eSzcA.euiim.mohgvgnoiuadp.riootigo.aai"

    const-string v0, "com.google.android.gms.auth.api.identity.internal.IAuthorizationService"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    instance-of v1, v0, Lcom/google/android/gms/internal/auth-api/zbaa;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/gms/internal/auth-api/zbaa;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, Lcom/google/android/gms/internal/auth-api/zbaa;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth-api/zbaa;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/auth-api/zbbi;->zbi:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/auth-api/zbw;->zba:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const v0, 0x1110e58

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "icorooySonaAdvdnaeluetdme.itiioiastiahIi.o.premacsegi.ognttrtrnlhz...ng"

    const-string v0, "aSsolyeiAgeo.e.aadhgtnnIvticiaitrstiiemzn..uttginlrieodo.mrnohpdo.ca..r"

    const/4 v2, 0x1

    const-string v0, ".mAarbdo.ahrigviaeta.nzd.egnrio.sImit.eotor.pgonnnluceod.iihciyletitauS"

    const-string v0, "com.google.android.gms.auth.api.identity.internal.IAuthorizationService"

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const-string v0, ".yins.urgru.moAozh.mSeotiioaltvddTisndTgat..mhpge.aeroe.ccitatanRiiu"

    const-string v0, "aavm.ormrdiu.ecmTSie..iiyi.nhgasecphid.tto.AaToizd.tanRrlongstgo.eut"

    const/4 v2, 0x6

    const-string/jumbo v0, "oaSa.gvp.Rroi.eiehcrsseztonl..i.ingguaetaTnapti.tmyiichdtdmodAooruT."

    const-string v0, "com.google.android.gms.auth.api.identity.service.authorization.START"

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    move v2, v1

    return v0
.end method
