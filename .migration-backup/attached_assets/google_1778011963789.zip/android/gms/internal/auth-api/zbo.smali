.class public final Lcom/google/android/gms/internal/auth-api/zbo;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final zba:Lcom/google/android/gms/auth/api/a$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/auth/api/a$a;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/16 v3, 0x44

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x2

    new-instance p1, Lcom/google/android/gms/auth/api/a$a$a;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez p4, :cond_0

    const/4 v8, 0x1

    sget-object p4, Lcom/google/android/gms/auth/api/a$a;->d:Lcom/google/android/gms/auth/api/a$a;

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {p1, p4}, Lcom/google/android/gms/auth/api/a$a$a;-><init>(Lcom/google/android/gms/auth/api/a$a;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/auth-api/zbbj;->zba()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/gms/auth/api/a$a$a;->b(Ljava/lang/String;)Lcom/google/android/gms/auth/api/a$a$a;

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance p2, Lcom/google/android/gms/auth/api/a$a;

    const/4 v7, 0x4

    move v8, v7

    invoke-direct {p2, p1}, Lcom/google/android/gms/auth/api/a$a;-><init>(Lcom/google/android/gms/auth/api/a$a$a;)V

    const/4 v7, 0x1

    and-int/2addr v8, v7

    iput-object p2, p0, Lcom/google/android/gms/internal/auth-api/zbo;->zba:Lcom/google/android/gms/auth/api/a$a;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1~s.~t@i~~@@ @@@a~~o~o~@cul @M o@ ~ f~@ y~ ~ - @~~mb  @ ~ d@@@/~lsbit~ ob~KfivS @@~~r4 ~@ @n~/@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v0, "ng.msoliCgcn.iiIepeutedhc.reser..dSnra.lnmidaronrlsgiaticaoaaes.eltedmvo"

    const-string/jumbo v0, "prste.eia.nasdae.eci.iIelghoonrsroletcacrteilSunngmidda.asC.ir.odlvemtng"

    const/4 v3, 0x6

    const-string v0, ".ocpoer.thongela.andoStelnil.ndesig.rtnmceie.Iao.sarrtCeaividmslga.uedir"

    const-string v0, "com.google.android.gms.auth.api.credentials.internal.ICredentialsService"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    instance-of v1, v0, Lcom/google/android/gms/internal/auth-api/zbt;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast p1, Lcom/google/android/gms/internal/auth-api/zbt;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/auth-api/zbt;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth-api/zbt;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p1
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/auth-api/zbo;->zba:Lcom/google/android/gms/auth/api/a$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/auth/api/a$a;->a()Landroid/os/Bundle;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const v0, 0xc35000

    const/4 v2, 0x2

    const/4 v1, 0x7

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "lnltgberidlCredirhnre.aeeclm.v.eosdiisr..agcdtIaaaoueisn.apmntoSnec.t.og"

    const-string/jumbo v0, "os.mleeameolr.p.ta..lrnveSadiimctrodoairnerenchgls.attCedan.guIicegni.sd"

    const/4 v2, 0x1

    const-string/jumbo v0, "tenrohunm.rrmuISeoa..eivcecso.ie.deslrpicsledgg.ingionetdrln.aaiCat.aadl"

    const-string v0, "com.google.android.gms.auth.api.credentials.internal.ICredentialsService"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "rviSmTspeo.Aie.dopgrlRusdo.i.nlo.aindhat.gmcaTre.cs.taeeo"

    const-string/jumbo v0, "legioh.sdr..nsa..o..eeclopToTetcmguaiiva.cisRdAmontrrdeSa"

    const/4 v2, 0x2

    const-string v0, "dao.enpgqvtriAseee.asmrcrnTooguR.d.a.mdcstliiglhecTS..a.o"

    const-string v0, "com.google.android.gms.auth.api.credentials.service.START"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method final zba()Lcom/google/android/gms/auth/api/a$a;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/auth-api/zbo;->zba:Lcom/google/android/gms/auth/api/a$a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-object v0
.end method
