.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwa;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzvz;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s.@du M~@~n@y/ ~c@~@~i~l  ~@~/oo b@b ~ fs@@Ki ~@~~ t~~- ~4i@So~@~@ @  o@lbt@v   @ mooa@r~~@1~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvz;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwa;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzwa;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzwa;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zze:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzwa;Lcom/google/android/gms/internal/firebase-auth-api/zzwd;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzd:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzwa;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p3, 0x4

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eq p1, v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq p1, v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq p1, p3, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 p3, 0x1

    const/4 p3, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eq p1, p3, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object p2

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v3, 0x6

    move v4, v3

    return-object p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvz;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzvz;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvy;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p1

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p3, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "zdz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    aput-object v2, p1, p3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const/4 v4, 0x6

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-object p3, p1, p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput-object p2, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object p2, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwa;

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    const-string p3, "000mu/////u0u/u00000u/s00u/0u/u0u0010/0bu0090/0//000n/u0u/0u00031000100000u000/02/000000003033u010"

    const-string p3, "0/s00000n10/03000/0/009u300u00/1/0/1u00u0/0/00000/0u0uu0uu000u00//0uu00000u00000u/00u1b/00/303/0/2"

    const/4 v4, 0x4

    const-string p3, "0030o/0000/1/02u0000/u0000/u00/0u00/0030u00u0000u100uu/u00009u00010/000uu3////03/0u/000/1ubn00/000"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    const/4 v4, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p1

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p1
.end method

.method public final zzk()Z
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwa;->zzd:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0
.end method
