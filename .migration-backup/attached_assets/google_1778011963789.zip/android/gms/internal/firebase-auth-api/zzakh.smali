.class public abstract Lcom/google/android/gms/internal/firebase-auth-api/zzakh;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# instance fields
.field protected final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzakc;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzakc;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzakc;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakh;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzakc;

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-void
.end method
