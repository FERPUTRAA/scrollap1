.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzup;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzup;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzuo;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@f~  @u~ ~i@@bo y  ~@@~1 as oM /4~t~t@ .n @So ~ ~@@o~vdr~-@~~~c@~~/f~i@b@ool ~l  @b@@~@@m@i~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuo;

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzup;
    .locals 3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzup;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzup;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zze:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzup;Lcom/google/android/gms/internal/firebase-auth-api/zzus;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzd:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzup;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzus;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x7

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x3

    const/4 v4, 0x6

    and-int/2addr v3, v0

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x2

    shl-int/2addr v3, v1

    if-eq p1, v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eq p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 p2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eq p1, p3, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p3, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq p1, p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p2

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuo;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzuo;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzun;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object p1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzup;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p3, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x6

    const-string v2, "dzz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    aput-object v2, p1, p3

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x4

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    aput-object p3, p1, p2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x0

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x1

    const/4 v3, 0x5

    aput-object p2, p1, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo p2, "zzg"

    const-string p2, "gzz"

    const/4 v4, 0x2

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    aput-object p2, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzup;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzup;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string p3, "0//m1009u/0/00000u////b21300000/0u1u/uu00u/u000u/000u00000000/00001/u0n00/u0s3000//0uuu00030300u00"

    const-string p3, "00su0u0000u/0000/00/000/00/0u20//00/30000u000100uu/u0u/0b00000u/33101u100//n0//0/00/9uu00000uu0u30"

    const/4 v4, 0x1

    const-string/jumbo p3, "u/0/o/uuu0091000000u/0/0/u00/000000/0001u///003/u/0030/0u0130/00010u0u0000u00/000n3/u000b0uu200000"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    return-object p1
.end method
