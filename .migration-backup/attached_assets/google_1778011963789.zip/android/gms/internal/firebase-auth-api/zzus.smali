.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzus;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

.field private zzh:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzus;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x6

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzh:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzur;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "obs S~Mf@t ~1 t@s4o~@l~ n~~@//@r~ @. b~~K ~-@@io@i @@~@io~o@ @~~lou @@a~  b   ~~~@@@~@cydv~fm~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzur;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzus;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x3

    return-object v0
.end method

.method public static zze()Lcom/google/android/gms/internal/firebase-auth-api/zzus;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public static zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzus;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzus;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zze:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/gms/internal/firebase-auth-api/zzus;Lcom/google/android/gms/internal/firebase-auth-api/zzum;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v0, 0x7

    and-int/2addr v1, v0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzl(Lcom/google/android/gms/internal/firebase-auth-api/zzus;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic zzm(Lcom/google/android/gms/internal/firebase-auth-api/zzus;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzh:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zze:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzum;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public final zzg()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public final zzh()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzh:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 p2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p1, :cond_4

    const/4 v5, 0x2

    const/4 p3, 0x7

    const/4 v5, 0x3

    const/4 p3, 0x5

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x3

    move v5, v1

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq p1, v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq p1, v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 p2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eq p1, v0, :cond_1

    const/4 v5, 0x0

    if-eq p1, p3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p2

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzur;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzur;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzuq;)V

    const/4 v5, 0x0

    return-object p1

    :cond_2
    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzus;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object p1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 p3, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v3, "zzd"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    aput-object v3, p1, p3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo p3, "zez"

    const-string p3, "ezz"

    const/4 v5, 0x7

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x5

    move v5, v4

    aput-object p3, p1, p2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    aput-object p2, p1, v2

    const/4 v5, 0x6

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zgz"

    const/4 v5, 0x4

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x3

    aput-object p2, p1, v1

    const/4 v5, 0x6

    const-string/jumbo p2, "zzh"

    const-string/jumbo p2, "zhz"

    const/4 v5, 0x3

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    aput-object p2, p1, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzus;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzus;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo p3, "u00m/0/10/310/0940000u000/40/000u14u0/u0/u0//0/0000/u//001u00u0000bu/000240000u000u0///un00u0s0/nu0000u000"

    const-string p3, "00s0u0//00//u20000/000000un/un4u0u00001400u00u00001u/u//000/000bu40u00/01///90uu0/000/0/0000000304u1/00u/0"

    const/4 v5, 0x0

    const-string p3, "400uo0400//00/00uu//n002000/00000u0000000/000n0u0010u010u///u/u0u0uu3//9/004/0/u/0//0b010u00uu00u000010400"

    const-string p3, "\u0000\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n\u0004\n"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    return-object p1
.end method
