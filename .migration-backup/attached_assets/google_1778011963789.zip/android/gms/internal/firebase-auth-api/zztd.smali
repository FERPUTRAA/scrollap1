.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztd;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;


# instance fields
.field private zzd:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztd;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zztc;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @si~ @o t @@~.@ ~fi~1~  ~o~ ~~b@obd@va~nf@/l c@ @/@~ @o bursy@~~~~m@4~K~@Mo@~ S- i~~@l@ t~  ~o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztc;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztd;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zztd;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zztd;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzd:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzd:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-eqz p1, :cond_4

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p3, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eq p1, p3, :cond_3

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p2, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eq p1, p2, :cond_2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p2, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p3, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eq p1, p2, :cond_1

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p2, 0x5

    const/4 v1, 0x4

    const/4 v0, 0x1

    if-eq p1, p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p3

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztc;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zztc;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zztb;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1

    :cond_2
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztd;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1

    :cond_3
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    const-string p3, "dzz"

    const-string p3, "dzz"

    const/4 v1, 0x2

    const-string p3, "dzz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    aput-object p3, p1, p2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    const-string p3, "0b0mu00000u1/0usu/0u0000u00u0000u100000000///u0u00//0010/000/00/0/0u00/1"

    const-string p3, "01s//0/u0u0u000000100u00/0/0000u00u000uu/010000/010/0u000/00b0uu0/01//00"

    const/4 v1, 0x0

    const-string p3, "//0/ou0u000u00//000001/10u0001u00000/0/0000//u000u000u/u000u010u0010u0/0"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u000b"

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1

    :cond_4
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method
