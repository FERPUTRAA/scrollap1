.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwq;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwq;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Ljava/lang/String;

.field private zzf:I

.field private zzg:Z

.field private zzh:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x7

    or-int/2addr v2, v1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzd:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zze:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzh:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic zza()Lcom/google/android/gms/internal/firebase-auth-api/zzwq;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "ibsK/~~u~@@ ~~ bb~~@/-~ofS l4o@ ~o@@  ~o~yl~ fo@1~@@tn~ @t ir@ ~M @d~  ~ @@m@~acsi~ ~.@@ o@@@~~v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 p2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 p3, 0x5

    shl-int/2addr v5, p3

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    const/4 v0, 0x4

    move v5, v0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v5, 0x5

    move v4, v1

    move v4, v1

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x6

    shr-int/2addr v4, v2

    const/4 v5, 0x0

    if-eq p1, v2, :cond_3

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    if-eq p1, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eq p1, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq p1, p3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p2

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    return-object p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwp;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzwp;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzwo;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 p3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v3, "zzd"

    const-string v3, "dzz"

    const/4 v5, 0x6

    const-string/jumbo v3, "zdz"

    const-string/jumbo v3, "zzd"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    aput-object v3, p1, p3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v5, 0x3

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v5, 0x2

    aput-object p3, p1, p2

    const/4 v5, 0x7

    const-string p2, "fzz"

    const-string/jumbo p2, "zfz"

    const/4 v5, 0x0

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    aput-object p2, p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x0

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object p2, p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo p2, "zhz"

    const/4 v5, 0x5

    const-string p2, "hzz"

    const-string/jumbo p2, "zzh"

    const/4 v5, 0x1

    const/4 v4, 0x7

    aput-object p2, p1, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string p3, "0u0m00u0u23u0u/00u05/00/u00002u1000//20000u0000b00////5/00u08000/0001u0000/000uu0uu/u0/0000/00/uuu800/24/0/05/000u800570"

    const-string p3, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001\u0208\u0002\u0208\u0003\u000b\u0004\u0007\u0005\u0208"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object p1
.end method
