.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwi;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

.field private zzf:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzd:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzwf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t@s io~@n b~/~a@~i o~f@~@@lK  /~~t@@@@~ ~~@mf  @ @~@@1 4~S~yM r~oi ~~~bb ~o-vsd~o~@u. lc@~ @  @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwf;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwi;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwi;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzwi;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzd:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzwi;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzwi;Lcom/google/android/gms/internal/firebase-auth-api/zzwh;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zza()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzf:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzwh;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzf:I

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_4

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v0, v1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-eq v0, v1, :cond_2

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    const/4 v1, 0x3

    shr-int/2addr v3, v1

    const/4 v2, 0x0

    move v3, v2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    :cond_4
    :goto_0
    const/4 v3, 0x0

    if-nez v1, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwh;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwh;

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object v0

    :cond_5
    const/4 v3, 0x4

    return-object v1
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x6

    move v2, v1

    return-object v0
.end method

.method public final zzf()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzd:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p1, :cond_4

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    const/4 p3, 0x3

    shl-int/2addr v3, p3

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eq p1, v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq p1, p3, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p2, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x5

    if-eq p1, p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 p2, 0x3

    const/4 p2, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq p1, p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object p3

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x3

    move v3, v2

    return-object p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwf;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzwf;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzwe;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p3, 0x0

    const/4 v3, 0x1

    const-string/jumbo v1, "zdz"

    const-string v1, "dzz"

    const/4 v3, 0x6

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x5

    const-string/jumbo p3, "zze"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    aput-object p3, p1, p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v3, 0x7

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    aput-object p2, p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const-string p3, "/u3m0/0uu01u00/02s000008u0//00//00/u0030n//u023000000/3c00u000/00000u0/u0u000/1u0000/00u0u0u"

    const-string p3, "/us3u020u//000/0n0u/0/00/800/0u02/0u/0c0u3/010u00u0u1000000/00u0030/0uu300u0000u0/00//000000"

    const/4 v3, 0x4

    const-string/jumbo p3, "u0//o0001/u0300200u/0002u0/c/0u0u/00///u000000//u03000000/0000n0/u00u00u3u/000000010u0008/uu"

    const-string p3, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0208\u0002\n\u0003\u000c"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p1
.end method
