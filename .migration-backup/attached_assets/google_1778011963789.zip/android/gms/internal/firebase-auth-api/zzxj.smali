.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxj;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxi;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sMonu@     ~ ~@ @@4@~@~cf .~ii@-~~o1@bo by@S~~t ol/o~@ it~~  ~@~@~sf @v@o~r@bKd~@~@@~~ l/a  ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxi;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxj;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v2, 0x0

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzxj;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v2, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzxj;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zze:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzxj;Lcom/google/android/gms/internal/firebase-auth-api/zzxm;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzd:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzxm;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eq p1, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq p1, p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 p2, 0x4

    move v3, p2

    const/4 v2, 0x7

    const/4 p3, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq p1, p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 p2, 0x2

    const/4 p2, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eq p1, p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p3

    :cond_0
    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x5

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxi;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxi;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxh;)V

    const/4 v3, 0x6

    return-object p1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "dzz"

    const/4 v3, 0x5

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    aput-object v1, p1, p3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    aput-object p3, p1, p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zfz"

    const/4 v3, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    aput-object p2, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxj;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p3, "/0umb/00/00000/u00010u0/00/00/22s/02u/uu/002/000009000u1u000/0000u/01u000u000u00u/01uu00/0"

    const-string p3, "00s0u00/0u0uu00090000000u0//000/0000u0/1u00/u/0/00/200/0/1/01/uuu/00u0/000u1200u000220b00u"

    const/4 v3, 0x4

    const-string p3, "0/0/o00000200012uu0020/00/000///100b00u0100//u//u0000uu0u0u000u00uu00u00/290u/0/00000000/1"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1
.end method
