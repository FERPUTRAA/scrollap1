.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztm;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;-><init>()V

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zztl;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s c@~~ @@~~i~@i@v@l@@ ~@1ytr~~~on/~of ao@4t~bMo~@~ @ s~~ ~ oi@@-  .~Ku  l b b@@@@@d~ o~mS~f ~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztl;

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztm;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zztm;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zztm;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zztm;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzd:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p2, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_4

    const/4 v2, 0x2

    const/4 p3, 0x0

    const/4 v2, 0x4

    const/4 p3, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq p1, p3, :cond_3

    const/4 v2, 0x1

    const/4 p2, 0x3

    const/4 v2, 0x3

    and-int/2addr v1, p2

    const/4 v2, 0x5

    if-eq p1, p2, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p3, 0x0

    const/4 v2, 0x0

    if-eq p1, p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p2, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p1, p2, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p3

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :cond_1
    const/4 v1, 0x6

    move v2, v1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztl;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zztl;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zztk;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 p3, 0x0

    move v2, p3

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x4

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    aput-object v0, p1, p3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x0

    const/4 v1, 0x0

    aput-object p3, p1, p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x5

    const-string p3, "00um0/3n00/000000//u00/0/00030u00/0/00/0/u/00u01u0uu002/02/s0u0000ub/0u001000uu0"

    const-string p3, "0us/03b0000u/u0/0u0u/000/u020n200u0/0000u0300u0/0//10/0/u0/u010u00/00/0000u00000"

    const/4 v2, 0x3

    const-string p3, "0//no01/000/u200ub0020/0u00u000/0100u/0uuu/300u000//u0000/3//0u00000000u000u0000"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0003\u0002\u0000\u0000\u0000\u0001\u000b\u0003\n"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method
