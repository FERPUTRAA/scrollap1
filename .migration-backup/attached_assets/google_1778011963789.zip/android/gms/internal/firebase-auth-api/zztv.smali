.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztv;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;


# instance fields
.field private zzd:I

.field private zze:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztv;-><init>()V

    const/4 v2, 0x3

    move v3, v2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztu;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ksfm@o  @ct1o@/ n d~l -~~@ v~o@i t@ i~@ @ ~@ sM@l@@~~.i@@~@~ ~4 ~~~f~@b/  Sbuo@oa~~~br  @@@~oy~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztu;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zztv;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zztv;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zztv;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzd:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public final zzb()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p3, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eq p1, p3, :cond_3

    const/4 v2, 0x2

    const/4 p2, 0x4

    const/4 p2, 0x3

    shl-int/2addr v2, p2

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq p1, p2, :cond_2

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x2

    or-int/2addr v1, p2

    const/4 v2, 0x3

    const/4 p3, 0x0

    const/4 v2, 0x6

    const/4 p3, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x0

    if-eq p1, p2, :cond_1

    const/4 v2, 0x2

    const/4 p2, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p1, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p3

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztu;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zztu;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zztt;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p1

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztv;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    aput-object v0, p1, p3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const-string/jumbo p3, "zez"

    const/4 v2, 0x5

    const-string/jumbo p3, "zze"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    aput-object p3, p1, p2

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zztv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztv;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string p3, "//bmu/0s0201uuu//0u/0000/u000000/uu00u00/2/0/0u2010u002000000000/000/u0b00000000u00u"

    const-string p3, "02s0u0u0u1000/00u/000b/u00000b0/uu0/0u0/0002u200000/////001u00/0u000/00u00u000200/u0"

    const/4 v2, 0x3

    const-string p3, "0000o/100b000/u00u0uu0//000/02/0/0/0000/uu0u001/00000/0/0u//00000u0u02u20u0ub0u00002"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u000b"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p1

    :cond_4
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method
