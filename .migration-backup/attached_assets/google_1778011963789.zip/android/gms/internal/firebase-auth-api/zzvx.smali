.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzvx;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvw;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvw;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzvx;Lcom/google/android/gms/internal/firebase-auth-api/zzvr;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zza()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzd:I

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzvx;Lcom/google/android/gms/internal/firebase-auth-api/zzvp;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zza()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zze:I

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzvx;Lcom/google/android/gms/internal/firebase-auth-api/zzvn;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zza()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzf:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final zza()Lcom/google/android/gms/internal/firebase-auth-api/zzvn;
    .locals 4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzf:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzvn;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    move v3, v2

    if-eq v0, v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x0

    or-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzvn;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzvn;

    const/4 v3, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvn;

    :cond_3
    :goto_0
    const/4 v3, 0x3

    if-nez v1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvn;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvn;

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v1
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzvp;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zze:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzvp;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    and-int/2addr v2, v1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzvp;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzvp;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvp;

    :cond_3
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvp;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvp;

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v1
.end method

.method public final zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzvr;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzd:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq v0, v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eq v0, v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    const/4 v2, 0x3

    move v3, v2

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    :cond_4
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v1, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvr;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvr;

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    return-object v0

    :cond_5
    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v1
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    if-eq p1, v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eq p1, p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p3, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eq p1, p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p2, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq p1, p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p3

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvw;

    const/4 v3, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzvw;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvv;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const-string v1, "dzz"

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x0

    aput-object v1, p1, p3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    aput-object p3, p1, p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v3, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p2, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p3, "uss3/0/0u00/3/000c/0u3/0c000/u0u00/000030000000//0/000000u000/000100u1uu/uuuu20u00uc0/000/0u/000"

    const-string p3, "00su///0/000020u0u000uc0u0/u000//00/0030001u03c03/00000/00/0u00uc00u00/030u0u0u/1/u/000uu00000/0"

    const/4 v3, 0x6

    const-string p3, "00/m/000///0u0uc000u0u0uu1000//300u002/000003300u0u0/000c01000u0/0000//0uu0/000/c000uu/03u0u00/0"

    const-string p3, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000c\u0002\u000c\u0003\u000c"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1
.end method
