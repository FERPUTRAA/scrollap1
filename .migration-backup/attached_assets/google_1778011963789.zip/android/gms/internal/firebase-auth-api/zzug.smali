.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzug;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzug;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x7

    move v3, v2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzuf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " uso@ @l b~~lb~@~ i~i /~1@~r 4@@aM~ Sf~~~.@mt~- oc~ f@~o~@ti/~ o@@ y ~@~@dn~~@@voo~ b ~@@ @@@K  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v1, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuf;

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzug;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzug;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzug;Lcom/google/android/gms/internal/firebase-auth-api/zzwn;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzd:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwn;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwn;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    move-result-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v1, 0x2

    move v2, v1

    const/4 p3, 0x2

    shr-int/2addr v2, p3

    const/4 v1, 0x4

    and-int/2addr v2, v1

    if-eq p1, p3, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p2, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p1, p2, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p2, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 p3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eq p1, p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p2, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq p1, p2, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p3

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1

    :cond_1
    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuf;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzuf;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzue;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzug;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x7

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, "dzz"

    const-string v0, "dzz"

    const/4 v2, 0x3

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    aput-object v0, p1, p3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const-string/jumbo p3, "zze"

    const-string p3, "ezz"

    const/4 v2, 0x3

    const-string/jumbo p3, "zze"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    aput-object p3, p1, p2

    const/4 v2, 0x6

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string p3, "//2m0/000/u000100uu00/00000u00010/0002/00u0000//0u02//u9u01/0u0u/u00000s1000u0"

    const-string p3, "00s0/0100u090u2/0/000010/u200001000/0/0000u/uuuu0//0/0/0010uu200/u000000/000u0"

    const/4 v2, 0x0

    const-string p3, "00/uo0u00/00u000009/u0/0/100100//2000uu000000000uuu000/1u00000uu2//01//0200u0/"

    const-string p3, "\u0000\u0001\u0000\u0001\u0002\u0002\u0001\u0000\u0000\u0000\u0002\u1009\u0000"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method
