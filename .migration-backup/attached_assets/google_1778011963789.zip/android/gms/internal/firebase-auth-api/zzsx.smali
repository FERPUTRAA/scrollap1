.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsx;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;-><init>()V

    const/4 v2, 0x5

    move v3, v2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsw;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@Ms o/~~~~f~rom~osK@ c f@iy~@b~ /.~t @l@~   b1~ o@@@ ~@~~ ~ @@o4 @o@a@ @~v@  ut@i n~l~d@~~~i@~b-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsw;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzsx;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzsx;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzsx;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zze:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzsx;Lcom/google/android/gms/internal/firebase-auth-api/zztd;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzd:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzsx;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zze:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zztd;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 p3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-eq p1, v1, :cond_3

    const/4 v4, 0x4

    if-eq p1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq p1, p3, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 p3, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eq p1, p3, :cond_0

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p2

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v4, 0x5

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsw;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzsw;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsv;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p3, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v2, "zzd"

    const-string v2, "dzz"

    const/4 v4, 0x3

    const-string v2, "dzz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput-object v2, p1, p3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string p3, "ezz"

    const-string/jumbo p3, "zez"

    const/4 v4, 0x0

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object p3, p1, p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v4, 0x6

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    aput-object p2, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string p2, "gzz"

    const-string/jumbo p2, "zgz"

    const/4 v4, 0x1

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-object p2, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsx;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string p3, "000m0/s0u/000u/0u00000u030/0/u0uu000//00030u//u90u0u00/0unu/20/000000010//0/0u30010b00/1u00310u/00"

    const-string/jumbo p3, "u0s//0u0/000/u/0/00000ub//3//00003301uu0000000000//uuu0000n00000uu0000/100u090/u2u/000u00u10/1003/"

    const-string p3, "0101o00000uu000900u/0/uu0u/u0000//u/00u03/u030u0/000u2/00000u0u0/00b0/0100//130/0/0000u0u00/n0/000"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p1

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p1
.end method
