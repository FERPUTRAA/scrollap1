.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzvf;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzve;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s a~ @~  ~~f@1@ic~ -@~ o @ v~lt~~oSy@Mr@@@~o u b@d~@ib/l @mK~o /o@ @ tf4i@~~.~n@@ b@~ ~~~@s o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzve;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzvf;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzvf;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzvf;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zze:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzvf;Lcom/google/android/gms/internal/firebase-auth-api/zzvl;)V
    .locals 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/gms/internal/firebase-auth-api/zzvf;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public final zzg()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p3, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eq p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq p1, p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 p3, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eq p1, p3, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p2

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzve;

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzve;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvd;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p3, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x5

    const-string v2, "dzz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    aput-object v2, p1, p3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x3

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    aput-object p3, p1, p2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v4, 0x2

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    aput-object p2, p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p2, "gzz"

    const-string/jumbo p2, "zgz"

    const/4 v4, 0x6

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput-object p2, p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v4, 0x3

    const-string p3, "00um0u0uu/1u009u00u00//00/00u00/000//000u000u0bns/0/303/0000010000000u20100u100000/u0/3/u300/0//uu"

    const-string/jumbo p3, "uusu20/0u//0/0000u00/03/0000u/0001/00010u0uubu0/300/000u000n/9100/u0/0u/00000000/033u0u0000010/00u"

    const/4 v4, 0x3

    const-string p3, "0000o//n0/u000u/1uu0000000u01300u30/000/0uu0300b/u00/30u0020/u/0/u/01/1u00/u00000/u00000000/0/000u"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p1

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object p1
.end method
