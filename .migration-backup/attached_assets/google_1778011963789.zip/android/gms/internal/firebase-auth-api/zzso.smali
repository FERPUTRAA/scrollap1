.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzso;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzso;-><init>()V

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsn;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@o@@fc v r K~ s~ iul@a Sfy/~~M-@. o/b@~1t@di  ~o~~b@@~@@4n~ ~@@ @@b~@t@~@~~olo o@m~~i@ ~  ~~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsn;

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzso;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzso;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzso;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzso;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zze:I

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzso;Lcom/google/android/gms/internal/firebase-auth-api/zzsu;)V
    .locals 2

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzd:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzd:I

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/gms/internal/firebase-auth-api/zzso;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    move-result-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final zzg()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p3, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq p1, v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eq p1, p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 p3, 0x5

    move v4, p3

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    if-eq p1, p3, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1

    :cond_1
    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsn;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzsn;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsm;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzso;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object p1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 p3, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x3

    const-string/jumbo v2, "zdz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    aput-object v2, p1, p3

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput-object p3, p1, p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string p2, "fzz"

    const-string p2, "fzz"

    const/4 v4, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    aput-object p2, p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const-string/jumbo p2, "zzg"

    const-string p2, "gzz"

    const/4 v4, 0x5

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-object p2, p1, v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string p3, "0/0m2uu0u//00u0n0/0u/0/u100u00//u00190s000/0u100/30000000/000030u0/0ub/0u30000000/u/00uu00010/0u/0"

    const-string p3, "00s000000nu0/u00u0/3/00/u003/01300uuu0/0u000u00/0000/000/0/u000u021//0000000u0/10/0/uub10u09/0/3u0"

    const/4 v4, 0x1

    const-string/jumbo p3, "u00/o1uuu0u/00/0//0000/u00//0/n/1//0000000u0/300000000u9u300u0buu00002u/000000030uu030000110/u/0/0"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object p1
.end method
