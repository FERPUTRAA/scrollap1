.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzta;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

.field private zzf:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzta;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsz;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s . o@  l~ @~~~vM@u ~~ fo@Si l~~@ ~ @ ~o@4~t ~~~@~~d-tiof@/Km@c@as@@b~y@~@io~1bo@b r/~@@~  n ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsz;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzta;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzta;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzta;Lcom/google/android/gms/internal/firebase-auth-api/zztd;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzd:I

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzta;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzf:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzf:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zztd;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zztd;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zztd;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v3, 0x7

    const/4 p3, 0x3

    const/4 v3, 0x5

    move v2, p3

    move v2, p3

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x2

    move v2, v0

    move v2, v0

    const/4 v3, 0x4

    if-eq p1, v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p1, p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p1, p2, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 p2, 0x5

    xor-int/2addr v3, p2

    const/4 v2, 0x7

    move v3, v2

    if-eq p1, p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p3

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsz;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzsz;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsy;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzta;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 p3, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "zzd"

    const-string v1, "dzz"

    const/4 v3, 0x6

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zez"

    const/4 v3, 0x3

    const-string/jumbo p3, "zze"

    const/4 v3, 0x7

    aput-object p3, p1, p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v3, 0x7

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    aput-object p2, p1, v0

    const/4 v2, 0x7

    move v3, v2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzta;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzta;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p3, "00/m9000u000100uu00//u/00/00s001u/0/2000u00u0//u/u/00b0/1/0u010002//000uu002000u000u00u000"

    const-string p3, "/us000000//0//0000/000uuu/b90u00u000101002/0/00u000/00/u2uu2uu//00010000/u00000u0u00000/01"

    const/4 v3, 0x7

    const-string p3, "0u10ou1/0000u/00//002/0u000/00u2u0000000/00020/0/0u0u0010000u00010//0u/00u/00/00/u0bu090u2"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u000b"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1
.end method
