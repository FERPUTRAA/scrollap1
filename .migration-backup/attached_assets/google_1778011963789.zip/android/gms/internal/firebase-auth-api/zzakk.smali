.class public abstract Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzaip;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<MessageType:",
        "Lcom/google/android/gms/internal/firebase-auth-api/zzakk<",
        "TMessageType;TBuilderType;>;BuilderType:",
        "Lcom/google/android/gms/internal/firebase-auth-api/zzakg<",
        "TMessageType;TBuilderType;>;>",
        "Lcom/google/android/gms/internal/firebase-auth-api/zzaip<",
        "TMessageType;TBuilderType;>;"
    }
.end annotation


# static fields
.field private static final zzb:Ljava/util/Map;


# instance fields
.field protected zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzamw;

.field private zzd:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb:Ljava/util/Map;

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaip;-><init>()V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v1, 0x4

    and-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzamw;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzamw;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzamw;

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method protected static zzA()Lcom/google/android/gms/internal/firebase-auth-api/zzakp;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzaly;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzaly;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected static zzB(Lcom/google/android/gms/internal/firebase-auth-api/zzakp;)Lcom/google/android/gms/internal/firebase-auth-api/zzakp;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0xa

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    add-int/2addr v0, v0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakp;->zzd(I)Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method static varargs zzD(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    instance-of p1, p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p1, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    instance-of p1, p0, Ljava/lang/Error;

    const/4 v1, 0x6

    const/4 v0, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p0, Ljava/lang/Error;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    throw p0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    const-string/jumbo p2, "xwsb dnet mestetxpnn ipg rocosh cdeoeerUceateetasrh yeod."

    const-string/jumbo p2, "ttse.coocxe sc tndhp e meng tp nUsertberxreecydaaoiheeowd"

    const/4 v1, 0x3

    const-string p2, "abymrdoad.mesc nrtnotUoescedx encpepegwinoxeee tcrteh  th"

    const-string p2, "Unexpected exception thrown by generated accessor method."

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    throw p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p0, Ljava/lang/RuntimeException;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    throw p0

    :catch_1
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const-string/jumbo p2, "lc. oileeCsteoot trimptrvme/ltet s fnd ou/ale eip srfno uclogennaemJcao"

    const-string p2, "csCmlnvef utatoslcp efineroe tnoocrn imlltpoado Jl/gttu. rie/me eeaeso "

    const/4 v1, 0x1

    const-string p2, " oerlbetCu /oecasecmvJtan edenilermrng aofu toests iotmp/  cllefniopo.t"

    const-string p2, "Couldn\'t use Java reflection to implement protocol message reflection."

    const/4 v1, 0x4

    invoke-direct {p1, p2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    throw p1
.end method

.method protected static zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzalz;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzalz;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method protected static zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzG()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method private final zza(Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zza(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return p1
.end method

.method private static zzb(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzK()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw v0

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method private static zzc(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;[BIILcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzw()Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p2, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v3, 0x0

    new-instance v5, Lcom/google/android/gms/internal/firebase-auth-api/zzais;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v5, p4}, Lcom/google/android/gms/internal/firebase-auth-api/zzais;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)V

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    move v4, p3

    move v4, p3

    const/4 v7, 0x7

    move v4, p3

    const/4 v7, 0x5

    invoke-interface/range {v0 .. v5}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzi(Ljava/lang/Object;[BIILcom/google/android/gms/internal/firebase-auth-api/zzais;)V

    const/4 v7, 0x2

    invoke-interface {p2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzf(Ljava/lang/Object;)V
    :try_end_0
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzaks; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzamu; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x5

    return-object p0

    :catch_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzj()Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    throw p1

    :catch_1
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    instance-of p2, p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz p2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    throw p0

    :cond_0
    const/4 v7, 0x7

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-virtual {p2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    throw p2

    :catch_2
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v6, 0x6

    move v7, v6

    throw p1

    :catch_3
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzl()Z

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x5

    if-eqz p2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v6, 0x5

    move v7, v6

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw p1
.end method

.method static zzv(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 6

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    check-cast v1, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v1, :cond_0

    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1, v3, v2}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v1, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v1, "cltainuia ioots tsi.lnCnoiaanlaf "

    const-string v1, "iantoizaiclsnnlaaiCil.  nooftta s"

    const/4 v5, 0x4

    const-string v1, "iaalonnpstin fi tzaal.ascioinC li"

    const-string v1, "Class initialization cannot fail."

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw v0

    :cond_0
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    if-nez v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzanf;->zze(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    check-cast v1, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v2, 0x6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v1, v2, v3, v3}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v1, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    throw p0

    :cond_2
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v1
.end method

.method protected static zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzh()Lcom/google/android/gms/internal/firebase-auth-api/zzajl;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzw()Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajm;->zzq(Lcom/google/android/gms/internal/firebase-auth-api/zzajl;)Lcom/google/android/gms/internal/firebase-auth-api/zzajm;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, p0, v1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzh(Ljava/lang/Object;Lcom/google/android/gms/internal/firebase-auth-api/zzama;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)V

    const/4 v2, 0x6

    move v3, v2

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzf(Ljava/lang/Object;)V
    :try_end_0
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzaks; {:try_start_0 .. :try_end_0} :catch_4
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzamu; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p2, 0x0

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajl;->zzz(I)V
    :try_end_1
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzaks; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    throw p1

    :catch_1
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    instance-of p1, p1, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw p0

    :catch_2
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of p2, p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw p2

    :catch_3
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x4

    const/4 v2, 0x3

    throw p1

    :catch_4
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzl()Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p2, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x6

    throw p1
.end method

.method protected static zzy(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Ljava/io/InputStream;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajj;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 v1, 0x1000

    const/4 v3, 0x0

    move v4, v3

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1, v2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajj;-><init>(Ljava/io/InputStream;ILcom/google/android/gms/internal/firebase-auth-api/zzaji;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzw()Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajm;->zzq(Lcom/google/android/gms/internal/firebase-auth-api/zzajl;)Lcom/google/android/gms/internal/firebase-auth-api/zzajm;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p1, p0, v0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzh(Ljava/lang/Object;Lcom/google/android/gms/internal/firebase-auth-api/zzama;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzf(Ljava/lang/Object;)V
    :try_end_0
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzaks; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzamu; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p0

    :catch_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    instance-of p1, p1, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p0

    :catch_1
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    instance-of p2, p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-eqz p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    throw p0

    :cond_1
    const/4 v4, 0x4

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    invoke-virtual {p2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v3, 0x0

    move v4, v3

    throw p2

    :catch_2
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamu;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    throw p1

    :catch_3
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzl()Z

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz p2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p2, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x0

    invoke-direct {p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;-><init>(Ljava/io/IOException;)V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzaks;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;)Lcom/google/android/gms/internal/firebase-auth-api/zzaks;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    throw p1
.end method

.method protected static zzz(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;[BLcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    array-length v0, p1

    const/4 v1, 0x7

    or-int/2addr v3, v1

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0, p1, v1, v0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzc(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;[BIILcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzb(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v3, 0x0

    const/4 v2, 0x3

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ne p0, p1, :cond_0

    const/4 v3, 0x6

    and-int/2addr v4, v3

    const/4 p1, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    return v0

    :cond_1
    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eq v1, v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzj(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return p1
.end method

.method public final hashCode()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzL()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaip;->zza:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzr()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzaip;->zza:I

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzr()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzalr;->zza(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public final synthetic zzC()Lcom/google/android/gms/internal/firebase-auth-api/zzalo;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method protected final zzF()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzf(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzG()V

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method final zzG()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const v1, 0x7fffffff

    const/4 v2, 0x4

    move v3, v2

    and-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method final zzI(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/high16 v0, -0x80000000

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    and-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const v0, 0x7fffffff

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public final zzJ(Lcom/google/android/gms/internal/firebase-auth-api/zzajs;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajt;->zza(Lcom/google/android/gms/internal/firebase-auth-api/zzajs;)Lcom/google/android/gms/internal/firebase-auth-api/zzajt;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzm(Ljava/lang/Object;Lcom/google/android/gms/internal/firebase-auth-api/zzajt;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public final zzK()Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v2, Ljava/lang/Byte;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/Byte;->byteValue()B

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne v2, v0, :cond_0

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v3, v2}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzk(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eq v0, v2, :cond_2

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :cond_2
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0, v3, v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v2
.end method

.method final zzL()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/high16 v1, -0x80000000

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method public final synthetic zzM()Lcom/google/android/gms/internal/firebase-auth-api/zzalp;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method

.method protected abstract zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method final zzn(Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzL()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const-string v1, "etu avmtq eias e-sbzwal,onsz nrse deni ieg"

    const-string/jumbo v1, "serialized size must be non-negative, was "

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zza(Ljava/lang/Object;)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-ltz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    throw v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const v2, 0x7fffffff

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    and-int/2addr v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ne v0, v2, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {p1, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zza(Ljava/lang/Object;)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ltz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v4, 0x1

    const/high16 v1, -0x80000000

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    and-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    or-int/2addr v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw v0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return v0
.end method

.method final zzr()I
    .locals 4

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zza()Lcom/google/android/gms/internal/firebase-auth-api/zzalx;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalx;->zzb(Ljava/lang/Class;)Lcom/google/android/gms/internal/firebase-auth-api/zzamb;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzb(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public final zzs()I
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzL()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "ulse esiaibweasn,zeeean dosg i -tzsrvbtnmi"

    const-string v1, "adnslbbive ,zieuitt waos-zmsnae g  eiesern"

    const-string/jumbo v1, "iv mdts -ea  emzanwzir so,e seltegnbauinei"

    const-string/jumbo v1, "serialized size must be non-negative, was "

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    or-int/2addr v5, v4

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p0, v2}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zza(Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ltz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const v3, 0x7fffffff

    const/4 v5, 0x0

    const/4 v4, 0x7

    and-int/2addr v0, v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v0, v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0, v2}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zza(Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ltz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    const/4 v5, 0x5

    const/high16 v2, -0x80000000

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    and-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    or-int/2addr v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzd:I

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    throw v2
.end method

.method protected final zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method public final zzu()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method final zzw()Lcom/google/android/gms/internal/firebase-auth-api/zzakk;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0
.end method
