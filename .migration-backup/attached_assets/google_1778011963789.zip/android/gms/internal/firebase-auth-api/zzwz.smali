.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwz;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:I

.field private zzf:I

.field private zzg:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v2, 0x2

    const/4 v2, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzd:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzwy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~us~b Sb a@~l di@o @~t ~@n4@~M @ iv~l~~s~c @-oi @/~~~@t @~~~@ mo@~@b1~.~ ~f/o@fy~~@oK@  @ o  @@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwy;

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwz;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzwz;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzd:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzwz;Lcom/google/android/gms/internal/firebase-auth-api/zzxo;)V
    .locals 2

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxo;->zza()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzg:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzwz;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzf:I

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzwz;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwk;->zza(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zze:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzf:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x2

    const/4 p2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 p3, 0x4

    const/4 p3, 0x4

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eq p1, v1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eq p1, v0, :cond_2

    const/4 p2, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x1

    shl-int/2addr v3, p2

    const/4 v4, 0x7

    if-eq p1, p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p3, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p1, p3, :cond_0

    const/4 v4, 0x2

    return-object p2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwy;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzwy;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzww;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p1

    :cond_2
    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p3, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v2, "zdz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x7

    const-string v2, "dzz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x5

    const/4 v3, 0x7

    aput-object v2, p1, p3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x6

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x0

    const/4 v3, 0x6

    aput-object p3, p1, p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string p2, "fzz"

    const-string p2, "fzz"

    const/4 v4, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    aput-object p2, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x2

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    aput-object p2, p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string p3, "000m00/00/u0000100/b803/u00000000/uu0u/0000/4u0//020/400u0020/uu000u1cu000//0/uu000u00u04000uc00/0/0u00/40us"

    const-string p3, "03s0004000200040u0u0///u41000uu0000/u000/0c000///0uu00u/uu040u/000/0u/u0u0/0/0800/000/000b0c00000201000uu0/u"

    const/4 v4, 0x6

    const-string p3, "c0u0o0/u0200/0/100/0u000uc/000//u0u00000000u0u00/8000100/00/00//040002u0/u0u04uu04/0/0uuu/0/u03400u/00b00000"

    const-string p3, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0208\u0002\u000c\u0003\u000b\u0004\u000c"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1
.end method
