.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztl;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/firebase-auth-api/zztk;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zza(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)Lcom/google/android/gms/internal/firebase-auth-api/zztl;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@fsisd~o~~~o fb@@ ~u@ ovo~t~~~~@~i ~a ~M~@-@@~ / /4l1~  o@~   @@r@~~m@ Kcb@@n~by@ l~ i~t@  @o@.S"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzm()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzg(Lcom/google/android/gms/internal/firebase-auth-api/zztm;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public final zzb(I)Lcom/google/android/gms/internal/firebase-auth-api/zztl;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzm()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p1, Lcom/google/android/gms/internal/firebase-auth-api/zztm;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztm;->zzf(Lcom/google/android/gms/internal/firebase-auth-api/zztm;I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method
