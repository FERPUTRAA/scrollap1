.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsr;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

.field private zzf:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;-><init>()V

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsq;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@.sSy ~iu4@ or@v~1tb@l@o@o~@f   @c ~@~ b~ ~@i/@ -@ ~m~l@ @/~ ~~ oo ~t~Ka~~~ ~ f~~@n@do@@i~bM@s ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsq;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzsr;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsr;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzsr;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzsr;Lcom/google/android/gms/internal/firebase-auth-api/zzsu;)V
    .locals 2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v0, 0x6

    and-int/2addr v1, v0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzsr;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzf:I

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzf:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p2, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p3, 0x3

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    const/4 v0, 0x2

    move v3, v0

    const/4 v2, 0x7

    and-int/2addr v3, v2

    if-eq p1, v0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eq p1, p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p2, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x3

    if-eq p1, p2, :cond_1

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    const/4 p2, 0x4

    const/4 p2, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eq p1, p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p3

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsq;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzsq;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsp;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;-><init>()V

    const/4 v3, 0x7

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p3, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "dzz"

    const-string v1, "dzz"

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo p3, "zez"

    const-string p3, "ezz"

    const/4 v3, 0x3

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x1

    aput-object p3, p1, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x6

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    aput-object p2, p1, v0

    const/4 v3, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v3, 0x2

    const-string p3, "0/s/0/0000u//uu0000000u00u/0/0920uu000ub000u002u//0002u00/0/012/00//10100u0uu000000u0000/1"

    const/4 v3, 0x4

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u000b"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method
