.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztj;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;


# instance fields
.field private zzd:I

.field private zze:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztj;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzti;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s @@~l@b @.@~1@K~~@ -udc~o @4/~   @ l nyivso  ~@ ~om~~~oifb~@a@@ S~to~o@~~t~ @Mf@~~ bi~@@ @~/ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzti;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zztj;
    .locals 3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zztj;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zztj;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzd:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public final zzb()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zze:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x5

    const/4 p2, 0x1

    const/4 v2, 0x2

    xor-int/2addr v1, p2

    const/4 v2, 0x3

    if-eqz p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 p3, 0x0

    const/4 p3, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq p1, p3, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p2, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq p1, p2, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p2, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eq p1, p2, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eq p1, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p3

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzti;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzti;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzth;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztj;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x3

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    aput-object v0, p1, p3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zez"

    const/4 v2, 0x3

    const-string/jumbo p3, "zze"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    aput-object p3, p1, p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zztj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztj;

    const/4 v1, 0x3

    move v2, v1

    const-string p3, "0/s00u0/000b/20/00u00//0000u0u0u0u0/200uu002/b0u203000u/00000/0uu000//000000u0/0u0/0"

    const/4 v2, 0x7

    const-string p3, "000m/u00u00uu0u/u02u0u0/000300//2b000000u000003/0uu//2b0000uu/000//00000200/00/000u0"

    const-string p3, "\u0000\u0002\u0000\u0000\u0002\u0003\u0002\u0000\u0000\u0000\u0002\u000b\u0003\u000b"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1

    :cond_4
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object p1
.end method
