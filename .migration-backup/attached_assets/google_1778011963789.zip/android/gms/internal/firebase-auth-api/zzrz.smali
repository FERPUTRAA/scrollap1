.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzrz;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x1

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzry;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ls~@.r ~~ @~@@@@~@i @s~o@v~t @@~b~ ~o  ~dc ~@a@@~ yK   /bfo@S~-@1 /@n ui~m4@@~~toiob ~ M f~@~ol"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzry;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzrz;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzrz;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v1, 0x7

    move v2, v1

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzrz;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zze:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzrz;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzrz;Lcom/google/android/gms/internal/firebase-auth-api/zzsf;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zze:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzsf;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzsf;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    move-result-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 p2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v4, 0x2

    const/4 p3, 0x7

    const/4 v4, 0x3

    const/4 p3, 0x4

    const/4 v3, 0x4

    move v4, v3

    const/4 v0, 0x3

    xor-int/2addr v4, v0

    const/4 v3, 0x6

    move v4, v3

    const/4 v1, 0x2

    move v4, v1

    const/4 v3, 0x6

    or-int/2addr v4, v3

    if-eq p1, v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-eq p1, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eq p1, p3, :cond_1

    const/4 v3, 0x1

    move v4, v3

    const/4 p3, 0x3

    const/4 p3, 0x5

    const/4 v4, 0x6

    if-eq p1, p3, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p2

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v4, 0x3

    const/4 v3, 0x0

    return-object p1

    :cond_1
    const/4 v3, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzry;

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzry;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzrx;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object p1

    :cond_2
    const/4 v4, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;-><init>()V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    return-object p1

    :cond_3
    const/4 v3, 0x6

    move v4, v3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p3, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "dzz"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x4

    const-string v2, "dzz"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput-object v2, p1, p3

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x5

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    aput-object p3, p1, p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v4, 0x4

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    aput-object p2, p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    aput-object p2, p1, v0

    const/4 v4, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzrz;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzrz;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const-string p3, "010m3u000/0u0/0/20/00u0000u001/0000bu00u00/000su/0u100/n00u/1u/u00//09u/0u0//0300u30000000u0u03/00"

    const-string p3, "/0s00u////00u00/0u3u0/000u01010uu30000/0/u00/n0310uu00/2ub00u0100/u0/003u090000/0000u00//0u/000000"

    const/4 v4, 0x6

    const-string/jumbo p3, "u0/0o0000u0003n000/00/0///00300020b03/u//u/u01009000uuu00uu00/31000/u/0u0000u010/u00/0000010uu0//0"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\n\u0003\u1009\u0000"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p1
.end method
