.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxd;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;-><init>()V

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v2, 0x4

    move v3, v2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxc;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "r/sy@~oa ~@n@~@Km/ bv@@i~~o ~u~b@s~~.@o~b@ @i~4~ ~d- @@@cf   @~~to1 ~~@ o t@ f~iS@@ l~~~@Ml  @~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxc;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxd;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzxd;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzxd;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zze:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzxd;Lcom/google/android/gms/internal/firebase-auth-api/zzxg;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzd:I

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzxg;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 p3, 0x3

    xor-int/2addr v3, p3

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eq p1, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eq p1, p3, :cond_2

    const/4 v2, 0x5

    or-int/2addr v3, v2

    const/4 p2, 0x3

    const/4 p2, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p3, 0x0

    const/4 v3, 0x0

    if-eq p1, p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p2, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eq p1, p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p3

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxc;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxc;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxb;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1

    :cond_2
    const/4 v3, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p3, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, "dzz"

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x5

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x3

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x7

    const/4 v2, 0x5

    aput-object p3, p1, p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    aput-object p2, p1, v0

    const/4 v3, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxd;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p3, "00/m00uu000000u0s/00/u000/u0000/u0/u100/000001u/0/02/u0/u0/u2uu0u/0020000b/01/u00010090000"

    const-string p3, "1/s0///0u0/u/u0000u91/020000u0200u/u00u0200u00/2u0u00////000u00u000u/0/0000u000b0011000000"

    const/4 v3, 0x5

    const-string/jumbo p3, "u00/o00000b09000000u00/u0/000/u/u/u02/101u000/020000u010//000/0000u0u021u/0200uu00u0//00/u"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p1

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p1
.end method
