.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzuv;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzuu;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os/@~n@ob ~@.l~~s1u@ @K @ ~  ~a~ @@@-r~ ot t@bS@~@ @~ ~mv4@ @~f@f~o/i@~@b~c ii~@ y~l ~  dM~@~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuu;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzuv;
    .locals 3

    const/4 v1, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzuv;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzuv;Lcom/google/android/gms/internal/firebase-auth-api/zzux;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zza()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzuv;Lcom/google/android/gms/internal/firebase-auth-api/zzvc;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zza()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zze:I

    const/4 v0, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzuv;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzux;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzd:I

    const/4 v2, 0x1

    move v3, v2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_4

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v1, 0x2

    move v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eq v0, v1, :cond_3

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eq v0, v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    move v3, v2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    const/4 v3, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    :cond_4
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v1, :cond_5

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzux;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzux;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v1
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvc;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zze:I

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zzb(I)Lcom/google/android/gms/internal/firebase-auth-api/zzvc;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzvc;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p1, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p3, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eq p1, v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eq p1, p3, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p2, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq p1, p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p2, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq p1, p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p3

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuu;

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzuu;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzut;)V

    const/4 v2, 0x6

    move v3, v2

    return-object p1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v1, "zzd"

    const-string v1, "dzz"

    const/4 v3, 0x4

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    aput-object v1, p1, p3

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo p3, "zze"

    const-string p3, "ezz"

    const/4 v3, 0x4

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    aput-object p3, p1, p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    aput-object p2, p1, v0

    const/4 v3, 0x1

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p3, "003m/n01/u00u0/00000/0u0/uc1/00uub003/02000000//00//0000uu00u00uc0us/00/000/0b0uuu00000u0//0"

    const-string p3, "0/s0000u/u//uu/0u000unu00u00u1/0200u00c003000u0000///0010000/u0000u0000/00b//03/000u/0cbu0/0"

    const/4 v3, 0x3

    const-string p3, "00b0ou200u/00/00c10000/c0u0//0u0u0uu00//330/01//0000uu00000b00/u00u0/000000u/0u0/00n0/0u0/u0"

    const-string p3, "\u0000\u0003\u0000\u0000\u0001\u000b\u0003\u0000\u0000\u0000\u0001\u000c\u0002\u000c\u000b\n"

    const/4 v3, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p1
.end method
