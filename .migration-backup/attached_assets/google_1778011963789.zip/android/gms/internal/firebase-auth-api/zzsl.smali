.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsl;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzsk;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4@s@ ~od .bol@@/@~ ~f~~n~i/l~o @ ~@~bcoai m@@@@~ ~@y~@~  vo @@so-iSM ~~@~~ ub~@ fK~~~  r1t @@ t@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsk;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsl;
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zzc(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzsl;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v1, 0x4

    move v2, v1

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzsl;Lcom/google/android/gms/internal/firebase-auth-api/zzsr;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzd:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzsl;Lcom/google/android/gms/internal/firebase-auth-api/zzvi;)V
    .locals 2

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzd:I

    const/4 v0, 0x2

    move v1, v0

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsr;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzsr;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsr;

    move-result-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvi;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq p1, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq p1, p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq p1, p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 p2, 0x2

    const/4 p2, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq p1, p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p3

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x3

    return-object p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsk;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzsk;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsj;)V

    const/4 v2, 0x3

    move v3, v2

    return-object p1

    :cond_2
    const/4 v3, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p3, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    aput-object v1, p1, p3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x0

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    aput-object p3, p1, p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string p2, "fzz"

    const/4 v3, 0x4

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    aput-object p2, p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsl;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo p3, "u10m/0010/9100uu/00000uu2u0uuuuu0000000u0020/0000/00u00/0/02///011000s0/u0900/0/u0u/0001000//200"

    const-string p3, "01s0u/00u0900000u000/0u0000000010u00001u00u2/0/0u00/0/u0/u0/00/9u/u2/210uu0//2011/0000/u000/00u0"

    const/4 v3, 0x6

    const-string p3, "0u20o0u000200/u0uu/000/00000u/000/u0u0u/u0u01000uu200/102u0001900/0/1000/000100090//0/0001//u/0u"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u1009\u0001"

    const/4 v3, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p1
.end method
