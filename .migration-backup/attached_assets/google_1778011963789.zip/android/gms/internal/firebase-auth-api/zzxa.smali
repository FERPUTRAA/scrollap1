.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxa;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzA()Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzwx;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " is oo ~r@~ @ ~~@@@vlb~bo~ ~@ /@ @~M@~oa i   @~~~1  t4du@ @~~bs~K~@cntlo@@~y@@. ~mf@o~/-~ @@~~fS"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwx;

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxa;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzxa;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzxa;Lcom/google/android/gms/internal/firebase-auth-api/zzwz;)V
    .locals 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakp;->zzc()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzB(Lcom/google/android/gms/internal/firebase-auth-api/zzakp;)Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object p0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public final zzb(I)Lcom/google/android/gms/internal/firebase-auth-api/zzwz;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    move v2, v1

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p3, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x3

    if-eq p1, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq p1, p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 p2, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eq p1, p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 p2, 0x4

    const/4 p2, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq p1, p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p3

    :cond_0
    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwx;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzwx;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzww;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p3, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "zzd"

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object v1, p1, p3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const-string/jumbo p3, "zze"

    const/4 v3, 0x2

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x3

    const/4 v2, 0x2

    aput-object p3, p1, p2

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-class p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v3, 0x4

    const-class p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const-class p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwz;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    aput-object p2, p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxa;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string p3, "/u/mu0u000/00000u00u/u0b00100000000u/00bu100000uu010uu0/00100000/00220s20u/0////0/u0"

    const-string p3, "00s02uuu//00/00/1000//uu10002bu0/00u0000/000//u0/0//u010u000u0100b000002000u000uu002"

    const/4 v3, 0x5

    const-string p3, "0000ob00000u00000020u0202uu1/u0/0/0/u///000001/000u1000b0u00/u0uu/0/0u0/1000020uu00/"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u000b\u0002\u001b"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p1
.end method
