.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzvi;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

.field private zzf:I

.field private zzg:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzvh;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~as@ron o/ o@~t~ -b  ~ ~@M  v@@o4~d@~~@i.1 @~@~~@~us mo@y~ ~i~ ~fob ~@@@S~fb @ @@/~@~tK~c  l@@li"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvh;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvi;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public static zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvi;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public static zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzvi;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzvi;Lcom/google/android/gms/internal/firebase-auth-api/zzvl;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzd:I

    const/4 v0, 0x2

    move v1, v0

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzd:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzvi;I)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzf:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzf:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public final zzb()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzg:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public final zzg()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x6

    const/4 p2, 0x4

    const/4 v4, 0x6

    const/4 p2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 p3, 0x4

    move v4, p3

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x2

    move v3, v0

    move v3, v0

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x3

    move v3, v1

    move v3, v1

    const/4 v4, 0x3

    if-eq p1, v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq p1, v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq p1, p3, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p3, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq p1, p3, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p2

    :cond_0
    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-object p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvh;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzvh;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvg;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p1

    :cond_2
    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object p1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 p3, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v2, "zzd"

    const-string v2, "dzz"

    const/4 v4, 0x2

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x6

    const/4 v3, 0x1

    aput-object v2, p1, p3

    const/4 v4, 0x4

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x1

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object p3, p1, p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v4, 0x5

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    aput-object p2, p1, v1

    const/4 v4, 0x7

    const-string/jumbo p2, "zzg"

    const-string p2, "gzz"

    const/4 v4, 0x1

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x5

    aput-object p2, p1, v0

    const/4 v4, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzvi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvi;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string p3, "000m0u000u000u//00u0u0000000/31000003u00000003000uu/0/02u0u001/39u0//ub/0000//0u0/0/00/s/u0uu0/0100u0/"

    const-string p3, "00s000//0000u0/u00b001u03/u00u//0u0///00u0u/000000001030000u0uu/21u000/000000/9u/3u000300/u01//0u000u0"

    const/4 v4, 0x6

    const-string/jumbo p3, "u//0o0020u0030/0ub00/0u00/0u00u/0003/0000u1000001/0u00/00/u009u0/0/u/010/bu0u03000/00u0uu00001000/03u0"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u000b\u0003\u000b"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p1
.end method
