.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzamt;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;


# instance fields
.field private zzd:J

.field private zze:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzams;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s @o~ -~bf@~4f ~~~@oi~~uco@dv~@~@~~1 ~  b St K bnyi@tl@~~ .~@@  @/M ~so r a@@~@~l m@~i@@~@~oo "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzams;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzamt;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzamt;J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzd:J

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzamt;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zze:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zze:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public final zzb()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzd:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-wide v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p1, :cond_4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq p1, p3, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p2, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eq p1, p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p2, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eq p1, p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x5

    const/4 v2, 0x1

    if-eq p1, p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p3

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzams;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzams;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzamr;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p1

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-object p1

    :cond_3
    const/4 v1, 0x0

    move v2, v1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p3, 0x0

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zdz"

    const/4 v2, 0x6

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x4

    aput-object v0, p1, p3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x6

    const-string/jumbo p3, "zze"

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    aput-object p3, p1, p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzamt;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzamt;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p3, Lcom/google/android/gms/internal/firebase-auth-api/zzalz;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, "/0um/u0/00u0000/00u2u/20u00/01100/00uuuu00/00040u00/000000002000u002///00000/0002/0u"

    const-string v0, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0004"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p3, p2, v0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzalz;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p3

    :cond_4
    const/4 v1, 0x6

    const/4 v1, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method
