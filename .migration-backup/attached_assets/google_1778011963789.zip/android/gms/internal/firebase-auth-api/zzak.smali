.class final Lcom/google/android/gms/internal/firebase-auth-api/zzak;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzad;


# instance fields
.field private final zza:Lcom/google/android/gms/internal/firebase-auth-api/zzam;


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/firebase-auth-api/zzam;I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzad;-><init>(II)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzak;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzam;

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method protected final zza(I)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ns~@/S~~@~~sb @r@K@~m~o.to~~@~   ~1 ~ ~tvi@@ oy @~ ~ d@iua/M@@  f~i@ @~4- o~~@lcl~ ~o@ b@b~@@ f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzak;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzam;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method
