.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzty;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzty;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x5

    move v2, v1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zztx;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "sosbb@@@o~  @b  ~~ c /@~@~~o@. ~  @~fi4@K~~~i@@~l~n  oSMr~@@~1d @~ @@o@~@ato~ fm~@ u /v@ ~ytli~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztx;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzty;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzty;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzty;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzd:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzty;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzd:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    if-eqz p1, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq p1, p3, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p2, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eq p1, p2, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p1, p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p2, 0x5

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eq p1, p2, :cond_0

    const/4 v2, 0x0

    return-object p3

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztx;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zztx;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zztw;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzty;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object p1

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v2, 0x6

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    aput-object v0, p1, p3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string/jumbo p3, "zze"

    const-string p3, "ezz"

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    aput-object p3, p1, p2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzty;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzty;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p3, "/00m/u0n2b000//u000002001u10//0u000u00000/0/u//u00000s//00u00000u0002u/00/0uu2u0"

    const-string p3, "0/s1//020000/000u/0u/00020u00u0/0bu0000n0/000uu00/u0/000/2u000/uu000000//0uu0012"

    const/4 v2, 0x1

    const-string p3, "0/u0o00u02uu020100/000200//2u00001u000//0u00u/0/000u0u0/00u0///00000u00/nub0000/"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\n"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1

    :cond_4
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1
.end method
