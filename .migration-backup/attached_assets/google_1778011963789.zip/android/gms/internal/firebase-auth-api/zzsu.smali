.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsu;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;


# instance fields
.field private zzd:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzst;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzst;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsu;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzsu;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzd:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzd:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 p2, 0x6

    const/4 p2, 0x1

    const/4 v1, 0x0

    if-eqz p1, :cond_4

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p3, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-eq p1, p3, :cond_3

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eq p1, p2, :cond_2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 p2, 0x4

    const/4 p2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p3, 0x0

    const/4 v1, 0x6

    if-eq p1, p2, :cond_1

    const/4 v1, 0x3

    const/4 p2, 0x5

    const/4 v1, 0x6

    move v0, p2

    move v0, p2

    const/4 v1, 0x6

    if-eq p1, p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p3

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzst;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzst;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzss;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1

    :cond_2
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;-><init>()V

    const/4 v1, 0x0

    return-object p1

    :cond_3
    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    const-string p3, "dzz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x4

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    aput-object p3, p1, p2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsu;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    const-string/jumbo p3, "u/s00u000/u000/00/0000u0uu/0000010/1/0/0/b0u00u/01u0000uu00/10u00/000100"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u000b"

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1

    :cond_4
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method
