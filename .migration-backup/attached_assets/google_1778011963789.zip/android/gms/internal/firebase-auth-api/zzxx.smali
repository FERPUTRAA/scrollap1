.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxx;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;


# instance fields
.field private zzd:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-void
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxx;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s@ -@S.4@f@s o@~nl ~~~~/~ @@/to~obo@u @@d~@~@b~vma~@~i~i@~~r ~  ~ M@i l y~~  ~~o@f@b1@c@@o~K t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxx;
    .locals 3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzxx;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v2, 0x3

    return-object p0
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzd:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x3

    const/4 p2, 0x1

    const/4 v1, 0x2

    move v0, p2

    move v0, p2

    const/4 v1, 0x1

    if-eqz p1, :cond_4

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p3, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eq p1, p3, :cond_3

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eq p1, p2, :cond_2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p3, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    if-eq p1, p2, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p2, 0x5

    const/4 v0, 0x2

    move v1, v0

    if-eq p1, p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p3

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxw;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxw;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxv;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1

    :cond_2
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1

    :cond_3
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 p2, 0x0

    shl-int/2addr v1, p2

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zdz"

    const/4 v1, 0x2

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    aput-object p3, p1, p2

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxx;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxx;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string p3, "00s00//0/0u0u00/0100000100/000001u00u00u/b01/000u/000/00uuu/0/u000u100u0"

    const-string p3, "/0/m00u/0u010u00/000000bu00000/0/00/0u000011u00//0u000u10u00u00u001/0/0u"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u000b"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1

    :cond_4
    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method
