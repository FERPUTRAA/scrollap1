.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzvl;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;


# instance fields
.field private zzd:I

.field private zze:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;-><init>()V

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzvk;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@@@s it @ @@@b@l~@ / ~4~~~ Mof~St@~~v.bn@yo/  @~~~a@bo ~o@K~~o ~@ulr@~@-f~d~m~ @i @~ c io~ ~1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvk;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x4

    return-object v0
.end method

.method public static zze()Lcom/google/android/gms/internal/firebase-auth-api/zzvl;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzvl;Lcom/google/android/gms/internal/firebase-auth-api/zzvc;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zza()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzd:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzvl;I)V
    .locals 2

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zze:I

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zze:I

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzvc;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzd:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zzb(I)Lcom/google/android/gms/internal/firebase-auth-api/zzvc;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvc;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzvc;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p3, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x4

    if-eq p1, p3, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eq p1, p2, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p2, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq p1, p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p2, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq p1, p2, :cond_0

    const/4 v2, 0x1

    return-object p3

    :cond_0
    const/4 v2, 0x4

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvk;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzvk;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvj;)V

    const/4 v1, 0x5

    and-int/2addr v2, v1

    return-object p1

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    return-object p1

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "zdz"

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const/4 v1, 0x4

    aput-object v0, p1, p3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string p3, "ezz"

    const-string/jumbo p3, "zez"

    const/4 v2, 0x2

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    aput-object p3, p1, p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzvl;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvl;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo p3, "uus//000ub0//02/00000u00200000/u00/10u00u0/00u01/u000u00000/000/uu/0/u02/c0200000u00"

    const/4 v2, 0x3

    const-string p3, "0/um0/0000u00/u0/0uuuu0020000000000020u/1/0/000u102/u0/000c000b/uu000/00/0uu0200/000"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000c\u0002\u000b"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object p1
.end method
