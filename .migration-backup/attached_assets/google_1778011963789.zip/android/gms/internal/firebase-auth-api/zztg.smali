.class public final Lcom/google/android/gms/internal/firebase-auth-api/zztg;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zztg;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zztf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/ssr@i@~m~@ @@Kt M@@. /~ ~ o@o~o@~1@ @~ a~@ f   S~ i-~bi~ o 4@@~ ~@c@tob@@~nfolv~b~@l~ ~~~u~yd "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zztf;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zztg;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v1, 0x1

    move v2, v1

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zztg;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zztg;I)V
    .locals 2

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzd:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zztg;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzd:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 p2, 0x1

    or-int/2addr v2, p2

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    if-eqz p1, :cond_4

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eq p1, p3, :cond_3

    const/4 v2, 0x7

    const/4 p2, 0x2

    const/4 v2, 0x4

    const/4 p2, 0x3

    const/4 v2, 0x5

    if-eq p1, p2, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p2, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eq p1, p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p2, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p1, p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    return-object p3

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztf;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zztf;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzte;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p1

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zztg;-><init>()V

    const/4 v2, 0x1

    return-object p1

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const-string/jumbo v0, "zdz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    aput-object v0, p1, p3

    const/4 v2, 0x3

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const/4 v2, 0x1

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    aput-object p3, p1, p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zztg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zztg;

    const/4 v2, 0x0

    const-string p3, "00um00/0/0020/00000//00000/000uu0000u0/000u/33100s0u0n0u/000u0/000b0/120/0/uuuu/"

    const-string p3, "00su/000u0/200u00/00u00/b000u0000/3/00003/u/00/0000000//uu/10n0/u00u0000u0u002/1"

    const/4 v2, 0x0

    const-string p3, "/00/o00000u0u/00u10u02b00u0u/00n0000u/010/00/30000000//0u00u3u00/u//000/u0020/00"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0003\u0002\u0000\u0000\u0000\u0001\u000b\u0003\n"

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p1
.end method
