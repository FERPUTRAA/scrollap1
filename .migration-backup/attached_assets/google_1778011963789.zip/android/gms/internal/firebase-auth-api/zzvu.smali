.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzvu;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzvt;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/@s K~~vlo@@~~~ .~ ~@o ~o m@y ~-~~@o ~  @@r  fdfb@i~@t @@s ~~o~@biM1i~  @S @cn@luo ~@a@b4@~@~/~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvt;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzvu;
    .locals 3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzc(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzvu;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzvu;Lcom/google/android/gms/internal/firebase-auth-api/zzvx;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v1, 0x3

    const/4 v0, 0x1

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    move-result-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p2, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p1, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p3, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x2

    if-eq p1, p3, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 p2, 0x1

    const/4 p2, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p1, p2, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eq p1, p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p2, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p1, p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p3

    :cond_0
    const/4 v2, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvt;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzvt;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzvs;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-object p1

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "zzd"

    const-string v0, "dzz"

    const/4 v2, 0x4

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    aput-object v0, p1, p3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const/4 v2, 0x6

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    aput-object p3, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzvu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzvu;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string p3, "000mu//u009u0000u0u000/0000100u//u000010000//00u0//01001/0001usu0u/10100/u00u0"

    const-string p3, "00s01/0u0u000//09000/0110/0000/00u010/u0000/00u101u00u1/u00/0000u//u000uu00u0/"

    const/4 v2, 0x1

    const-string/jumbo p3, "u000o00000u0/000000/01000u000000u009010///0011/uuuuu0/01/u00u0100/100u0u0///0/"

    const-string p3, "\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u1009\u0000"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-object p1

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p1
.end method
