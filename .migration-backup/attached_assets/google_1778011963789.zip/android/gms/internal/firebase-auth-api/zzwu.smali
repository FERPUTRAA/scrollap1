.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwu;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

.field private zzf:I

.field private zzg:I

.field private zzh:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwt;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s ~~o. ~@@~ t~ ~@~b@l@ /co ~@@~ il@@~oo~K@@  ~@~yn ~ot ~bi~rb-~~S@i/m@ @f @@Mv@~d~f41 aou~ @@s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwt;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwu;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzwu;Lcom/google/android/gms/internal/firebase-auth-api/zzwi;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzwu;Lcom/google/android/gms/internal/firebase-auth-api/zzxo;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxo;->zza()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzh:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzwu;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzg:I

    const/4 v0, 0x0

    or-int/2addr v1, v0

    return-void
.end method

.method static synthetic zzl(Lcom/google/android/gms/internal/firebase-auth-api/zzwu;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x3

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwk;->zza(I)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzf:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzg:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzwi;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwi;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwi;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzxo;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzh:I

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxo;->zzb(I)Lcom/google/android/gms/internal/firebase-auth-api/zzxo;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxo;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxo;

    :cond_0
    const/4 v2, 0x0

    return-object v0
.end method

.method public final zzi()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzd:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x5

    move v3, v2

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v5, 0x1

    const/4 p3, 0x5

    const/4 v5, 0x3

    move v4, p3

    move v4, p3

    const/4 v5, 0x5

    const/4 v0, 0x2

    const/4 v5, 0x6

    const/4 v0, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    if-eq p1, v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq p1, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 p2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq p1, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq p1, p3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-object p2

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v5, 0x5

    return-object p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwt;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzwt;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzwr;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object p1

    :cond_2
    const/4 v5, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p1

    :cond_3
    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 p3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v3, "dzz"

    const-string/jumbo v3, "zzd"

    const/4 v5, 0x0

    const-string/jumbo v3, "zzd"

    const-string/jumbo v3, "zzd"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v3, p1, p3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    aput-object p3, p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v5, 0x0

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object p2, p1, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x2

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    aput-object p2, p1, v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo p2, "zhz"

    const/4 v5, 0x2

    const-string/jumbo p2, "zzh"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    aput-object p2, p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwu;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string p3, "000m00/0/00/uu00//uus000u0000130/0b0u002u00u0004/c/4/0u0u/000000000000/u/004u0000uu0/1000/u00/000u4u00u0c91//0u010"

    const-string p3, "00s0/u0000u//0/u0000u000u0u/000/00040009/100u/0/u0100/0/uu0//u00000u00/0//u0c/0000u0124000b40u1u0u03c000400u0u00/0"

    const/4 v5, 0x5

    const-string p3, "00u0o00/000/u/9020000/0/01uu/00130u4//0u00400//0u004/c/0000cu10000u0u00u/0u10//00/0000/u0/0u0/0004ub000u0uu000u000"

    const-string p3, "\u0000\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u000c\u0003\u000b\u0004\u000c"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object p1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object p1
.end method

.method public final zzk()I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwu;->zzf:I

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v2, 0x6

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v0, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eq v0, v1, :cond_1

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq v0, v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x5

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    move v1, v3

    move v1, v3

    move v1, v3

    move v1, v3

    :cond_3
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    return v2

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v1
.end method
