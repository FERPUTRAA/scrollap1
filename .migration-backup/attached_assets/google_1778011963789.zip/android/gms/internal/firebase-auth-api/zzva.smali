.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzva;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzva;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzuz;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " cs   ~~~ut @ ~@~s~@-@~@ to@oo v/~~   foS@o~~i~~fy@@.dib~@ @@M@m4~~~lbi~/@@ l~~b o  ~@K @@~@r1@a"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuz;

    const/4 v2, 0x7

    const/4 v1, 0x3

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzva;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static zzc(Ljava/io/InputStream;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzva;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzy(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Ljava/io/InputStream;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzva;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzva;Lcom/google/android/gms/internal/firebase-auth-api/zzxa;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzxa;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzd:I

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p3, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq p1, v0, :cond_3

    const/4 v3, 0x4

    if-eq p1, p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 p2, 0x2

    const/4 p2, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq p1, p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p2, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq p1, p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p3

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuz;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzuz;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzuy;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzva;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object p1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 p3, 0x0

    xor-int/2addr v3, p3

    const/4 v2, 0x5

    move v3, v2

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x7

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    aput-object v1, p1, p3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string p3, "ezz"

    const-string p3, "ezz"

    const/4 v3, 0x4

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    aput-object p3, p1, p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo p2, "zzf"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    aput-object p2, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzva;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzva;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p3, "0u0m//n20u000u9/00000/0000302s000//03u/0u00u02/u0u0/00u0/0000/u/000/010uuu02/u00000000"

    const-string p3, "/0s0u00u20200u/200uu000/0u9000u/0u00300u0/0u0/000un/000/000000000/000301u010/0//u//u02"

    const/4 v3, 0x0

    const-string p3, "09u0o0u00u00002u/0000000u0/0/00110/u0300020/20///0u0u0//0//u02000n0u0uuu/00000000u0/30"

    const-string p3, "\u0000\u0002\u0000\u0001\u0002\u0003\u0002\u0000\u0000\u0000\u0002\n\u0003\u1009\u0000"

    const/4 v3, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1
.end method
