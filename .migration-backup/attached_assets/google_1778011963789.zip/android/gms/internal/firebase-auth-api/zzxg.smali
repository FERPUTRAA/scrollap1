.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxg;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;


# instance fields
.field private zzd:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzd:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzxf;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s-~ luSab.i~ @s@~@@~~t K @n@~@ft~y/@@@~b~v~ oro ~ @~   ~ @oo @1  @i@~/l i4o M@@o~@~fcm@@~d ~~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxf;

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxg;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxg;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzxg;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzxg;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzd:Ljava/lang/String;

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final zze()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzd:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_4

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p3, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eq p1, p3, :cond_3

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x7

    if-eq p1, p2, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p2, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 p3, 0x0

    move v1, p3

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    if-eq p1, p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-eq p1, p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p3

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxf;

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxf;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxe;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1

    :cond_2
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1

    :cond_3
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-array p1, p2, [Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    const/4 p2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    const-string/jumbo p3, "zzd"

    const-string/jumbo p3, "zdz"

    const/4 v1, 0x6

    const-string p3, "dzz"

    const-string/jumbo p3, "zzd"

    const/4 v1, 0x1

    aput-object p3, p1, p2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxg;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxg;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    const-string p3, "000m010/uu/uu/00/200u0/00000su0/u0000000110000uu00u00//01/u008/00001u0/0"

    const-string p3, "/us010u1/010u00001000000/00000/00/000/uu/0u1/0uu80uu0u002//0/00/000000u0"

    const/4 v1, 0x4

    const-string p3, "//00o0000/u00000/00uuu0//10//0/00u000000u0u801002u010u1000/1u000u/0u0/00"

    const-string p3, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0208"

    const/4 v1, 0x2

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1

    :cond_4
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method
