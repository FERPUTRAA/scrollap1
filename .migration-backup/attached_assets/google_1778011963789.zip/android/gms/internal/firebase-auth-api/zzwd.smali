.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwd;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v3, 0x7

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x4

    and-int/2addr v2, v1

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwc;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/ts~@~nsv~l~b~@ @@ @~oc @@~~ m~-M~@ iy~~   4f~ ~ bi ~b @u.t~i@o @~o~l  d@f~/Sa@~@@o ~@roo@@K ~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwc;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zze()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public static zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzwd;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zze:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;Lcom/google/android/gms/internal/firebase-auth-api/zzvx;)V
    .locals 2

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzd:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzd:I

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic zzk(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zze:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvx;->zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzvx;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final zzg()Lcom/google/android/gms/internal/firebase-auth-api/zzajf;
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzajf;

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v3, 0x4

    move v4, v3

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz p1, :cond_4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p3, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p1, v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eq p1, v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    if-eq p1, p3, :cond_1

    const/4 v4, 0x5

    const/4 p3, 0x5

    const/4 v4, 0x4

    const/4 p3, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x0

    if-eq p1, p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object p2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v4, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwc;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzwc;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzwb;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p3, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "zdz"

    const-string v2, "dzz"

    const/4 v4, 0x0

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x4

    aput-object v2, p1, p3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zez"

    const/4 v4, 0x4

    const-string/jumbo p3, "zze"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object p3, p1, p2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p2, "fzz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x1

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    aput-object p2, p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x2

    const-string/jumbo p2, "zzg"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    aput-object p2, p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo p3, "uu0m0u0/0000103u0/00/30u0u0000300010000/00000/0//0011u00000u0uu///0000//2000uu/09/30nu0b0/0u000//s"

    const-string p3, "00s0/u000b/0u0uu/000//3100u000/0001u0/u090/000u00u000/23300u000/0001//u/uu0000//100/00/uu30000000n"

    const/4 v4, 0x5

    const-string p3, "000uo/0//000u0/000/b03u/u003120uuu/00/u010/0000uu00000u00uuu00n9u003000//0/110/00000000/3//u/00000"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\n"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-object p1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p1
.end method

.method public final zzl()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzd:I

    const/4 v2, 0x5

    move v3, v2

    const/4 v1, 0x1

    move v3, v1

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method
