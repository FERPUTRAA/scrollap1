.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsc;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsb;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@ss@o@~@~~~~b~  /dn@ u~iito@~yfo~o@~c@@@rm/t~f~~ @~ Mla@ Kb @ @Si  ~ ~-o~1 o4@~.l@ v ~ b~@ @ @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsb;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzsc;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzsc;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zzf(Lcom/google/android/gms/internal/firebase-auth-api/zzsc;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zze:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzsc;Lcom/google/android/gms/internal/firebase-auth-api/zzsf;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzd:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zze:I

    const/4 v2, 0x3

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzsf;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzsf;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzsf;

    move-result-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p3, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p1, v0, :cond_3

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eq p1, p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p2, 0x4

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p3, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eq p1, p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p2, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eq p1, p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p3

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsb;

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzsb;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsa;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_2
    const/4 v2, 0x3

    const/4 v2, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "dzz"

    const-string v1, "dzz"

    const/4 v3, 0x1

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    aput-object v1, p1, p3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    aput-object p3, p1, p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x0

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x0

    const/4 v2, 0x2

    aput-object p2, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsc;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsc;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string p3, "00/mu0/0/000u0/000000u002u00000101/01uu/0200u000020u00/2090u0000ubuu/0000/0u////s000/001u/"

    const-string p3, "00s0/0/0u00u0/10u00/001002/0uu0u0200u0020/00b0000/102u910/0/u/u00//000000/u0u0/00u0000u0u/"

    const/4 v3, 0x6

    const-string p3, "000/o20uu020bu0/000u01u/0/010///01u//020000100u020000/00u/0000u009u00u0/0/00uu000/0u0u0/00"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000"

    const/4 v3, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p1
.end method
