.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxr;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;


# instance fields
.field private zzd:Ljava/lang/String;

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x4

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzd:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzA()Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzakp;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic zza()Lcom/google/android/gms/internal/firebase-auth-api/zzxr;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v2, 0x1

    return-object v0
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxr;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq p1, v0, :cond_3

    const/4 v3, 0x7

    if-eq p1, p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p2, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 p3, 0x5

    const/4 p3, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eq p1, p2, :cond_1

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 v3, 0x7

    const/4 p2, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eq p1, p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p3

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxq;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxq;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxp;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p1

    :cond_2
    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 p3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "zzd"

    const-string/jumbo v1, "zdz"

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    aput-object v1, p1, p3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo p3, "zez"

    const-string p3, "ezz"

    const/4 v3, 0x4

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    aput-object p3, p1, p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-class p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const-class p2, Lcom/google/android/gms/internal/firebase-auth-api/zzwq;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    aput-object p2, p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxr;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxr;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p3, "u0s021000/0000u/u0//u8uu00u0/2u00u2000002000////00/00u00u200000u00/0//0100u0b/011u00"

    const-string p3, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u0208\u0002\u001b"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method
