.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzwc;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/internal/firebase-auth-api/zzwb;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final zza(Lcom/google/android/gms/internal/firebase-auth-api/zzvx;)Lcom/google/android/gms/internal/firebase-auth-api/zzwc;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzm()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;Lcom/google/android/gms/internal/firebase-auth-api/zzvx;)V

    const/4 v2, 0x7

    return-object p0
.end method

.method public final zzb(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)Lcom/google/android/gms/internal/firebase-auth-api/zzwc;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzm()V

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzk(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public final zzc(I)Lcom/google/android/gms/internal/firebase-auth-api/zzwc;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zzm()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzakg;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p1, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzwd;->zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzwd;I)V

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method
