.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzuj;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzum;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v3, 0x2

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public static zza()Lcom/google/android/gms/internal/firebase-auth-api/zzui;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzui;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzuj;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zzc(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzuj;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method static synthetic zze(Lcom/google/android/gms/internal/firebase-auth-api/zzuj;Lcom/google/android/gms/internal/firebase-auth-api/zzum;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzd:I

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzd:I

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public final zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzum;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zze()Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    move-result-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    const/4 p2, 0x5

    const/4 p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_4

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 p3, 0x2

    const/4 p3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq p1, p3, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x3

    const/4 v2, 0x1

    if-eq p1, p2, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 p2, 0x4

    shl-int/2addr v2, p2

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq p1, p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p2, 0x5

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p1, p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p3

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x4

    return-object p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzui;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzui;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzuh;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1

    :cond_2
    const/4 v2, 0x7

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p3, 0x0

    const/4 v1, 0x4

    move v2, v1

    const-string/jumbo v0, "zzd"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x6

    const-string v0, "dzz"

    const-string/jumbo v0, "zzd"

    const/4 v2, 0x1

    aput-object v0, p1, p3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string p3, "ezz"

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v2, 0x4

    aput-object p3, p1, p2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzuj;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzuj;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string p3, "00su/0u000100u/0000u001100u00u00///101u0u0/u00u/900000u0u00/00/u000///00100/10"

    const/4 v2, 0x1

    const-string/jumbo p3, "u0s000/00/001u00u00000000/0000u0u0/1u/00000/0010uuu/100u//0uu/u10//1010/000000"

    const-string p3, "\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u1009\u0000"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-object p1

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method
