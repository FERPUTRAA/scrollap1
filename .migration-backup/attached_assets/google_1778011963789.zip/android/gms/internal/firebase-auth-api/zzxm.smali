.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzxm;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;


# instance fields
.field private zzd:I

.field private zze:Ljava/lang/String;

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zze:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzxl;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s@~~b @ S~  y/~Kvubo1 b   @~oM@l~~@@otso~ @ @~~@~-.~~~~@o~/ id~@@~@4~@t@l~no @faic@~i  ~ f@ m@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxl;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzxm;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method public static zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzxm;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public static zze(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzxm;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzxm;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zze:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzxm;Lcom/google/android/gms/internal/firebase-auth-api/zzwn;)V
    .locals 2

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final zza()Lcom/google/android/gms/internal/firebase-auth-api/zzwn;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzwn;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzwn;

    move-result-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public final zzf()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zze:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public final zzi()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzd:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p3, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-eq p1, v0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eq p1, p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 p2, 0x6

    const/4 p2, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p3, 0x0

    const/4 v3, 0x7

    if-eq p1, p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p2, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eq p1, p2, :cond_0

    const/4 v2, 0x1

    return-object p3

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p1

    :cond_1
    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxl;

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzxl;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzxk;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p1

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "dzz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x3

    const-string/jumbo v1, "zdz"

    const-string/jumbo v1, "zzd"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    aput-object v1, p1, p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p3, "zze"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x0

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    aput-object p3, p1, p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p2, "zzf"

    const-string p2, "fzz"

    const/4 v3, 0x3

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput-object p2, p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzxm;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzxm;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string p3, "1/0m2s/u001/20//0u//000001u002uu201uu000000/0u0/200/u/0000/u/000u00800uu000000000u0/0000u9"

    const-string p3, "00s0uu0/u10/u0//0u000u00u000100/220u00000u90u/0u000uu0001u02/00//020/800/00/0010/200u/0000"

    const/4 v3, 0x7

    const-string p3, "00/0o00010900/uu00u00/u10uu020/u00u0000000u0//00208u020/0110000/0u/000///uu000/0/u0/00u022"

    const-string p3, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0208\u0002\u1009\u0000"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p1
.end method
