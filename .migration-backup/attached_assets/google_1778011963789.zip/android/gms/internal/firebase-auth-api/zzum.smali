.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzum;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;


# instance fields
.field private zzd:I

.field private zze:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

.field private zzg:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzum;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzul;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzul;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzum;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public static zze()Lcom/google/android/gms/internal/firebase-auth-api/zzum;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzum;Lcom/google/android/gms/internal/firebase-auth-api/zzuv;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzd:I

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzum;Lcom/google/android/gms/internal/firebase-auth-api/zzug;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzd:I

    const/4 v1, 0x7

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzd:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzum;Lcom/google/android/gms/internal/firebase-auth-api/zzud;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zza()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzg:I

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final zza()Lcom/google/android/gms/internal/firebase-auth-api/zzud;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzg:I

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzud;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq v0, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x3

    move v3, v1

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zzd:Lcom/google/android/gms/internal/firebase-auth-api/zzud;

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zzc:Lcom/google/android/gms/internal/firebase-auth-api/zzud;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v1, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzud;

    :cond_3
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzud;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzud;

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v1
.end method

.method public final zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzug;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzug;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzug;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzuv;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzuv;->zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzuv;

    move-result-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p3, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq p1, v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eq p1, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 p2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eq p1, p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 p3, 0x5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eq p1, p3, :cond_0

    const/4 v4, 0x4

    return-object p2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x0

    and-int/2addr v4, v3

    return-object p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzul;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzul;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzuk;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzum;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 p3, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "zdz"

    const-string/jumbo v2, "zdz"

    const/4 v4, 0x1

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput-object v2, p1, p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo p3, "zze"

    const-string p3, "ezz"

    const/4 v4, 0x1

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput-object p3, p1, p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string p2, "fzz"

    const-string p2, "fzz"

    const/4 v4, 0x3

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object p2, p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zgz"

    const/4 v4, 0x0

    const-string/jumbo p2, "zgz"

    const-string/jumbo p2, "zzg"

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    aput-object p2, p1, v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzum;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzum;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p3, "00s0000/0u0/00/031000001010u00/000u0uu090//u00/u00000u00/u///0u091010000003/s/0/uu000/0/302010u0/03u0u0u0cu0"

    const-string p3, "11s0020/0u/09000u0u0/000/u0/00/000u0000300093uu/003/u00000u0/u/11/u/01/0000uu00/0u/00u/1/00000u00/0u0000c300"

    const/4 v4, 0x7

    const-string p3, "000m30000uu9090/300/00001//0/0/10u000u00000u0100u0//u0u/000/0u0/00u3/002u/u/u100u0u//0c00000/0000010uu01/300"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u1009\u0001\u0003\u000c"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p1

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p1
.end method
