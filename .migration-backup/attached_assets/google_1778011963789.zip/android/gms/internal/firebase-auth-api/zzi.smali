.class final Lcom/google/android/gms/internal/firebase-auth-api/zzi;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzh;


# static fields
.field static final zza:Lcom/google/android/gms/internal/firebase-auth-api/zzi;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x5

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzi;

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzi;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzi;->zza:Lcom/google/android/gms/internal/firebase-auth-api/zzi;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "Mosncrhataesh)(eCn"

    const-string v0, "ChstMna(onecarhr)e"

    const/4 v2, 0x5

    const-string v0, "CermaceorMt)hn.an("

    const-string v0, "CharMatcher.none()"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzh;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public final zza(C)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@ @oo~/~t4@~/~tonS~@@b  ~b r~1~vi~.~d-~iMl ~~l@o~@f@ys  @of~b ~@@~  @@ @  oKi~m u~ @~@ @@@ ac~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x2

    throw p1
.end method
