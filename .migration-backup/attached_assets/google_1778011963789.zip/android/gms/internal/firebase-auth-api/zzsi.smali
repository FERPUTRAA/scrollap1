.class public final Lcom/google/android/gms/internal/firebase-auth-api/zzsi;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

# interfaces
.implements Lcom/google/android/gms/internal/firebase-auth-api/zzalq;


# static fields
.field private static final zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

.field private zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;-><init>()V

    sput-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v3, 0x0

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const-class v1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzH(Ljava/lang/Class;Lcom/google/android/gms/internal/firebase-auth-api/zzakk;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static zzb()Lcom/google/android/gms/internal/firebase-auth-api/zzsh;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "i@sb  ~ ~~ ~@.  fK ~ @1@at~~~y@b@io~~fo@r~ d~b@Ml@cm@vl~o@ ~ o~io@o~@~@~~S @@@n  t- @4 ~~s@u~@//"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzt()Lcom/google/android/gms/internal/firebase-auth-api/zzakg;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsh;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic zzc()Lcom/google/android/gms/internal/firebase-auth-api/zzsi;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public static zzd(Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzsi;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/internal/firebase-auth-api/zzaks;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzx(Lcom/google/android/gms/internal/firebase-auth-api/zzakk;Lcom/google/android/gms/internal/firebase-auth-api/zzajf;Lcom/google/android/gms/internal/firebase-auth-api/zzajx;)Lcom/google/android/gms/internal/firebase-auth-api/zzakk;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v2, 0x3

    return-object p0
.end method

.method static synthetic zzg(Lcom/google/android/gms/internal/firebase-auth-api/zzsi;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zze:I

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic zzh(Lcom/google/android/gms/internal/firebase-auth-api/zzsi;Lcom/google/android/gms/internal/firebase-auth-api/zzso;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzd:I

    const/4 v0, 0x1

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzd:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method

.method static synthetic zzi(Lcom/google/android/gms/internal/firebase-auth-api/zzsi;Lcom/google/android/gms/internal/firebase-auth-api/zzvf;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzd:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzd:I

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final zza()I
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zze:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method

.method public final zze()Lcom/google/android/gms/internal/firebase-auth-api/zzso;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzf:Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzso;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzso;

    move-result-object v0

    :cond_0
    const/4 v2, 0x1

    return-object v0
.end method

.method public final zzf()Lcom/google/android/gms/internal/firebase-auth-api/zzvf;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzg:Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/internal/firebase-auth-api/zzvf;->zzd()Lcom/google/android/gms/internal/firebase-auth-api/zzvf;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method protected final zzj(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const/4 v4, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_4

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p3, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eq p1, v1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eq p1, v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p1, p3, :cond_1

    const/4 v4, 0x2

    const/4 p3, 0x5

    const/4 v4, 0x6

    const/4 p3, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x7

    if-eq p1, p3, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p2

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    sget-object p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v4, 0x6

    const/4 v3, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsh;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzsh;-><init>(Lcom/google/android/gms/internal/firebase-auth-api/zzsg;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance p1, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p3, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const-string/jumbo v2, "zzd"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput-object v2, p1, p3

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string p3, "ezz"

    const-string p3, "ezz"

    const/4 v4, 0x7

    const-string/jumbo p3, "zez"

    const-string/jumbo p3, "zze"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    aput-object p3, p1, p2

    const/4 v3, 0x0

    or-int/2addr v4, v3

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zfz"

    const/4 v4, 0x4

    const-string/jumbo p2, "zfz"

    const-string/jumbo p2, "zzf"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    aput-object p2, p1, v1

    const/4 v4, 0x7

    const-string p2, "gzz"

    const-string/jumbo p2, "zzg"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    aput-object p2, p1, v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object p2, Lcom/google/android/gms/internal/firebase-auth-api/zzsi;->zzb:Lcom/google/android/gms/internal/firebase-auth-api/zzsi;

    const/4 v3, 0x5

    const/4 v3, 0x3

    const-string p3, "/10m//000u0u00/0100900u0u00/uub/0u001/03/0u1/0u00000/3/00000003/0u00/0309/002000000/u100u0uu000010/u00/00uu/"

    const-string p3, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000\u0003\u1009\u0001"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p2, p3, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzakk;->zzE(Lcom/google/android/gms/internal/firebase-auth-api/zzalp;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p1

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object p1
.end method
