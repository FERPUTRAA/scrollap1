.class final Lcom/google/android/gms/internal/firebase-auth-api/zzajq;
.super Lcom/google/android/gms/internal/firebase-auth-api/zzajn;


# instance fields
.field private final zzg:Ljava/io/OutputStream;


# direct methods
.method constructor <init>(Ljava/io/OutputStream;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;-><init>(I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzg:Ljava/io/OutputStream;

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    return-void
.end method

.method private final zzG()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s@ @~~@ @di@r~bi@tv~n  ~~M@f so/u~  @l@@~  if@@o~@o~@oo4o ~~@ .~~S@mbt ~/a1 ~~~c -~  ~l Ky@~@b"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzg:Ljava/io/OutputStream;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3, v0}, Ljava/io/OutputStream;->write([BII)V

    const/4 v5, 0x7

    iput v3, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method private final zzH(I)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ge v0, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzG()V

    :cond_0
    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public final zzI()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-lez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzG()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public final zzJ(B)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzG()V

    :cond_0
    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc(B)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public final zzK(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/16 v0, 0xb

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc(B)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public final zzL(ILcom/google/android/gms/internal/firebase-auth-api/zzajf;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    shl-int/lit8 p1, p1, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzd()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v1, 0x2

    invoke-virtual {p2, p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajf;->zzj(Lcom/google/android/gms/internal/firebase-auth-api/zzaiv;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public final zza([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzp([BII)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public final zzh(II)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/16 v0, 0xe

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    or-int/lit8 p1, p1, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public final zzi(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public final zzj(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 v0, 0x12

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x2

    or-int/lit8 p1, p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p2, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zze(J)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public final zzk(J)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zze(J)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public final zzl(II)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/16 v0, 0x14

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ltz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    int-to-long p1, p2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzg(J)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public final zzm(I)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ltz p1, :cond_0

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-long v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzu(J)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method final zzn(ILcom/google/android/gms/internal/firebase-auth-api/zzalp;Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    shl-int/lit8 p1, p1, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/gms/internal/firebase-auth-api/zzaip;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzaip;->zzn(Lcom/google/android/gms/internal/firebase-auth-api/zzamb;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajs;->zze:Lcom/google/android/gms/internal/firebase-auth-api/zzajt;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-interface {p3, p2, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzamb;->zzm(Ljava/lang/Object;Lcom/google/android/gms/internal/firebase-auth-api/zzajt;)V

    const/4 v0, 0x5

    or-int/2addr v1, v0

    return-void
.end method

.method public final zzo(ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    shl-int/lit8 p1, p1, 0x3

    const/4 v1, 0x1

    or-int/lit8 p1, p1, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzv(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public final zzp([BII)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget p2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sub-int/2addr p2, v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-lt p2, p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1, v1, p2, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    add-int/2addr p1, p3

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    add-int/2addr p1, p3

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p1, v1, v2, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-int/2addr v0, p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzG()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    sub-int/2addr p3, p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-gt p3, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    iput p3, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzg:Ljava/io/OutputStream;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/OutputStream;->write([BII)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/2addr p1, p3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput p1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method public final zzq(II)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    shl-int/lit8 p1, p1, 0x3

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    or-int/2addr p1, p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public final zzr(II)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/16 v0, 0x14

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public final zzs(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public final zzt(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/16 v0, 0x14

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v1, 0x4

    move v2, v1

    shl-int/lit8 p1, p1, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p2, p3}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzg(J)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public final zzu(J)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v0, 0xa

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzH(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzg(J)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public final zzv(Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    mul-int/lit8 v0, v0, 0x3

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajs;->zzA(I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int v2, v1, v0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget v3, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v6, 0x0

    if-le v2, v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    new-array v1, v0, [B

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1, v1, v2, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzank;->zzb(Ljava/lang/CharSequence;[BII)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzs(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0, v1, v2, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzp([BII)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v5, 0x0

    move v6, v5

    sub-int/2addr v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    if-le v2, v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajq;->zzG()V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajs;->zzA(I)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I
    :try_end_0
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzanj; {:try_start_0 .. :try_end_0} :catch_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-ne v0, v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int v1, v2, v0

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    iput v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v5, 0x3

    move v6, v5

    iget-object v3, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v4, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzb:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    sub-int/2addr v4, v1

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1, v3, v1, v4}, Lcom/google/android/gms/internal/firebase-auth-api/zzank;->zzb(Ljava/lang/CharSequence;[BII)I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iput v2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    sub-int v3, v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    sub-int/2addr v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0, v3}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/android/gms/internal/firebase-auth-api/zzank;->zzc(Ljava/lang/CharSequence;)I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v3}, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzf(I)V

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    iget-object v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zza:[B

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v6, 0x5

    invoke-static {p1, v0, v1, v3}, Lcom/google/android/gms/internal/firebase-auth-api/zzank;->zzb(Ljava/lang/CharSequence;[BII)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/2addr v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I
    :try_end_1
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzanj; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    return-void

    :catch_0
    move-exception v0

    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v1, Lcom/google/android/gms/internal/firebase-auth-api/zzajp;

    const/4 v5, 0x0

    move v6, v5

    invoke-direct {v1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajp;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    throw v1

    :catch_1
    move-exception v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v3, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    sub-int/2addr v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    sub-int/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput v1, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzd:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    iput v2, p0, Lcom/google/android/gms/internal/firebase-auth-api/zzajn;->zzc:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    throw v0
    :try_end_2
    .catch Lcom/google/android/gms/internal/firebase-auth-api/zzanj; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    move-exception v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/internal/firebase-auth-api/zzajs;->zzE(Ljava/lang/String;Lcom/google/android/gms/internal/firebase-auth-api/zzanj;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method
