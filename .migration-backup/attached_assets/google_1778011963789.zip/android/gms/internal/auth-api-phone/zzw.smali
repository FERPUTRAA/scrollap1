.class public final Lcom/google/android/gms/internal/auth-api-phone/zzw;
.super Lcom/google/android/gms/common/internal/j;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/common/internal/j<",
        "Lcom/google/android/gms/internal/auth-api-phone/zzh;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/16 v3, 0x7e

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    return-void
.end method


# virtual methods
.method protected final bridge synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@sb~~~ s @m~o~l  @@i~~~bi~~.@~ r ~u@cv ~/~@@@@ @~4f@o-@o/n @a~ ~d@ Kool@ ~ i1@~bo~M  fS  ~@~t@t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x6

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "tmim.rmtpeetuShngrocraavaeRidS.ropn.mnlIs.giio.oosndAshleeeeverp.c.gii"

    const-string v0, "gispoh.vrRliieeliaSeA.im.heogegemaprcaSducrnv.eInrestmani.ortdntso.po."

    const/4 v3, 0x2

    const-string/jumbo v0, "oSvpoeRenucmrarnam..ti.tiegmoh.iseider..oglge.nivreshAlponrSi.aaodectI"

    const-string v0, "com.google.android.gms.auth.api.phone.internal.ISmsRetrieverApiService"

    const/4 v2, 0x0

    move v3, v2

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v1, v0, Lcom/google/android/gms/internal/auth-api-phone/zzh;

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/internal/auth-api-phone/zzh;

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/internal/auth-api-phone/zzh;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth-api-phone/zzh;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/internal/auth-api-phone/zzac;->zze:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const v0, 0xbdfcb8

    const/4 v2, 0x4

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string v0, "giintb.hv.amSdi.gIniopnreeAheragpeciluoRortplt.om.oeve.sra..acsmnSeied"

    const-string v0, "icrm.pIonrgvSiAhgortpn.asieaeieciogem.reu...mhSelnnoo.lt.pvsiteddamRea"

    const/4 v2, 0x5

    const-string v0, "iaSt.iuRtdconmaeumeAorsoteeerp..rashIledp.ihgrpv.gliegrio.onvm.iaecn.n"

    const-string v0, "com.google.android.gms.auth.api.phone.internal.ISmsRetrieverApiService"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "Sdns..rpS.ttrhdreApmi.oaavogiSecmne.il.s.vTeoRuipesrgAocRerec.gmvepiToa.oi"

    const-string/jumbo v0, "ivngo.oAThetpevmg.i..du.oRieoipmTaer.SscRaiapAc.eSsl.eg.voStrsomrecirrhnde"

    const/4 v2, 0x1

    const-string v0, "c.ighrpsqAvacmSogelrirRpec....oe.mehrpRi.eoendsdntsogaTAiiSvieeomuSaTv.e.r"

    const-string v0, "com.google.android.gms.auth.api.phone.service.SmsRetrieverApiService.START"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x5

    return v0
.end method
