.class public final Lcom/google/android/gms/internal/auth_blockstore/zzf;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/16 v3, 0x102

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x4

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~ @4@b .@o  ob@/ @r@~~~ -dov@ @ ~mMa b ~o~~~o~@y@lin~~~@~~ u ~l@Scf @ s~i/fi~ t1@ @~ot@@ K@~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x7

    move v3, v2

    const/4 p1, 0x0

    shl-int/2addr v3, p1

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "tonml.oooiemrnvo..sIlermng.eBbh.lcuetdsolkaaeogScrrcrdtaiitk.os.cs"

    const-string/jumbo v0, "s.simkS.ortsn.cnobh.kdcasolaltcguoBolgavegri..iIorrtlemdeoctern.oe"

    const/4 v3, 0x1

    const-string/jumbo v0, "mrehoa.caImuongsonleto.rlSotlti.dvreonslBbekc.er.r.eaco.gcigotkios"

    const-string v0, "com.google.android.gms.auth.blockstore.internal.IBlockstoreService"

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Lcom/google/android/gms/internal/auth_blockstore/zzg;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/internal/auth_blockstore/zzg;

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/internal/auth_blockstore/zzg;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/auth_blockstore/zzg;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/internal/auth_blockstore/zzab;->zzl:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x2

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const v0, 0x1110e58

    const/4 v2, 0x3

    const/4 v1, 0x1

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const-string v0, "eooaobknsltooeobecmo.nm.trrr.Sclglcs.urBelioatshregaimdv.nc.tI.dik"

    const-string v0, "gtcmgclldkreoethBactraes.orsrdnvguoembc.skrao.eoInoS..l.nii.omotli"

    const/4 v2, 0x3

    const-string v0, "com.google.android.gms.auth.blockstore.internal.IBlockstoreService"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "grggoeuodosmc.Rokaosmres.n.Toa.ic.vl.et.AhicToSretdl"

    const-string v0, ".doao.Ar.cavrmgcel.isRtonSotmgsske.eoTr.co.eohiTgdbl"

    const/4 v2, 0x7

    const-string/jumbo v0, "tRnooldp.hi..oakbrmcmouidgasATeegSost.ccvgorle..s.re"

    const-string v0, "com.google.android.gms.auth.blockstore.service.START"

    const/4 v2, 0x6

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method
