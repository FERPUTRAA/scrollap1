.class final Lcom/google/android/gms/internal/fido/zzar;
.super Lcom/google/android/gms/internal/fido/zzao;


# instance fields
.field private final zza:Lcom/google/android/gms/internal/fido/zzat;


# direct methods
.method constructor <init>(Lcom/google/android/gms/internal/fido/zzat;I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-direct {p0, v0, p2}, Lcom/google/android/gms/internal/fido/zzao;-><init>(II)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/internal/fido/zzar;->zza:Lcom/google/android/gms/internal/fido/zzat;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method protected final zza(I)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@su@@ bbt~~  @ o~~ii-o~ i r~~~@ ~@@~v@ @@b@@o @/ ~ l~M@sy1~~o f@~@tS@K@~o  ~ ~cmd~@/f4n~@ ~al ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/internal/fido/zzar;->zza:Lcom/google/android/gms/internal/fido/zzat;

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p1
.end method
