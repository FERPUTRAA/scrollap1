.class public final Lcom/google/android/gms/internal/fido/zzp;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x4

    const/16 v3, 0x94

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s  ~~@ @~@ ~f ~~b. @M~Srl~i@~ ~~@ i~ ~-@1@ob@@@@y~  o @~ vn~sc @~bod~fo/a ~Koio~4~~l@@ttu@@/ m"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x2

    const-string v0, "Fonm..Adcgur.ooIn.2g.dodpaimvrrcan..ele2lreogogsieiiseiddpSo.fflmtr"

    const-string v0, "eisFvodedo2riolrrenAegog2l.idgormnoia..dt.mpdacl.SfegcrpiunIa.of.s."

    const/4 v3, 0x7

    const-string/jumbo v0, "l.r.oIdldee.rar.fcrogdeona..im.oserpitioogfocii.udAgmnn2lF2gpaeSvid"

    const-string v0, "com.google.android.gms.fido.fido2.internal.regular.IFido2AppService"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/gms/internal/fido/zzs;

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p1, Lcom/google/android/gms/internal/fido/zzs;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/fido/zzs;

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/fido/zzs;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v0, v0, [Lcom/google/android/gms/common/Feature;

    const/4 v3, 0x2

    move v4, v3

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    sget-object v2, Lj4/c;->h:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v2, Lj4/c;->g:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "ECRDOb2_E_CSVRTOAIT_ATFSIN"

    const-string v1, "FIDO2_ACTION_START_SERVICE"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "..megduoiTS.og2rfu.lAsgmroo.enmgddoaardR.cfTiil"

    const-string v2, "d.fmf.meamgnTcraTggiulldidgSeooAsoiR2.o.o...rdr"

    const/4 v4, 0x1

    const-string v2, "fogi.2gpngr.SdeoR.dfl.lcerms..TdoiTomi.udaraoAg"

    const-string v2, "com.google.android.gms.fido.fido2.regular.START"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    move v4, v3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const v0, 0xc65d40

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const-string/jumbo v0, "nidlml2dqdgtiaSeAFrfoi2earnoeano.e.dsorgg.ripiuoc.eov.fIimogcr.pod."

    const-string/jumbo v0, "lmpioo2Ada.rnnilgeelnoe.cio.dIorSerggi.fdg.tipo2msreai.ofd.oducvrFa"

    const/4 v2, 0x5

    const-string v0, "2rs.nl.ddamuoi2A.ifnr.nt.iaro.odgF.rglocIecgpid.osieeSgevooedfarpil"

    const-string v0, "com.google.android.gms.fido.fido2.internal.regular.IFido2AppService"

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string v0, "gl.mao.goiiorS2eilc.fdam..r.Tosdgofogbren.AdTdm"

    const-string/jumbo v0, "ooadlbd.eomaf..d2..irdcrToifggsArn.leTgSo.uogmi"

    const/4 v2, 0x4

    const-string v0, "com.google.android.gms.fido.fido2.regular.START"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method
