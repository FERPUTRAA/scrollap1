.class public final Lcom/google/android/gms/internal/fido/zzk;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/16 v3, 0x95

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s~~ byo@~@ r1o@~ o~ ~~ @t /~@@ li~~m@ b~@n@~~o@@~@t ~/~4@io~~.fs~@ -@lu@bKf~ vd@ ~i a@~cM  S o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v0, "Soimicdiendilnridoeof.etfrrgeg.d.de.ilrgvomvlei.sagpmloiFcdnege.oa2i..rP2Iivd"

    const-string v0, "com.google.android.gms.fido.fido2.internal.privileged.IFido2PrivilegedService"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    instance-of v1, v0, Lcom/google/android/gms/internal/fido/zzn;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/internal/fido/zzn;

    const/4 v3, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/internal/fido/zzn;

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/fido/zzn;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-array v0, v0, [Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-object v2, Lj4/c;->h:Lcom/google/android/gms/common/Feature;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object v2, Lj4/c;->i:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x3

    const/4 v3, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "FIDO2_ACTION_START_SERVICE"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v2, "eogmosigoT.rdTS.ii...aAfemido.cpdlovgolRdfids2nr.o"

    const-string/jumbo v2, "ilsrgir.g2f.memgd.dscoTpoToodfid.ni.dRvoeel.iASao."

    const-string v2, "glseibvTddoi..figRg.Adpd.iS.gmTdom.conelor2oef.ior"

    const-string v2, "com.google.android.gms.fido.fido2.privileged.START"

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const v0, 0xc65d40

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "idleIdueiiFpeffcme.da2oiro.igdo.olrmrsevtiaggliolo.ri.dvdeenncgSm..gorPvin.di"

    const-string/jumbo v0, "v2tmadraleooImi..mifeivreoccen.ooiegl.id.eilgidngdirFglrov.SpdndfiseoiP..gred"

    const/4 v2, 0x7

    const-string v0, "Irilarmpiomaoe.nFcdelecsoefldr.irgi.e.te2odofggpggi.v.ovnreiiidi2vdneSddP.oil"

    const-string v0, "com.google.android.gms.fido.fido2.internal.privileged.IFido2PrivilegedService"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "Ropgf.e.qsidcdS.f.imigarogdl.oodolroim.iT2AdeT.gen"

    const-string v0, "com.google.android.gms.fido.fido2.privileged.START"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method
