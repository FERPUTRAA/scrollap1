.class public final Lcom/google/android/gms/internal/fido/zzac;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/16 v3, 0x77

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v7, 0x0

    move v8, v7

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s~d~yK@ M~~a@~~~@ooub@@~b @~l/~  ~ ~t~@/ r@@ti@o1 ~ff .~  m  ~~~l@cno@~@o@i o bi~~@ @~v@@4-@sS"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "mrmmeeea.vrenfsp.efil.cdr2orcoin.isoy..Uu2otzeIaodg.rtrfgaaSnyZd.rtloig"

    const-string/jumbo v0, "sesctrSeeP.o.ea.agoarir.galr.y.edffdigip.yvoomienrrocltIZmdounfzr.U2tn2"

    const/4 v3, 0x4

    const-string v0, "com.google.android.gms.fido.u2f.internal.zeroparty.IU2fZeroPartyService"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/google/android/gms/internal/fido/zzz;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/gms/internal/fido/zzz;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/internal/fido/zzz;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/fido/zzz;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    return-object p1
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v1, "ENSRoCATICASE_ImTR_V"

    const-string v1, "CREm_NIRTTVSEASTIC_A"

    const/4 v4, 0x2

    const-string v1, "I_IOVbCT_AEENASCRTST"

    const-string v1, "ACTION_START_SERVICE"

    const/4 v4, 0x4

    const-string v2, ".mo.TeuiooA2gr.fdosSd.Totgeo.a.yrfgirmplRaodn.c"

    const-string/jumbo v2, "p.e.oRiaTdmTorom2ocgs.tny.ufi.orrl.ogAodSfe.dag"

    const/4 v4, 0x4

    const-string v2, "TrRiz..poo.oaefg.n..sgAmoladomctrgru.2dydiepfST"

    const-string v2, "com.google.android.gms.fido.u2f.zeroparty.START"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const v0, 0xc65d40

    const/4 v2, 0x7

    const/4 v1, 0x5

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string/jumbo v0, "idn.oesoq.t2gnU.remfgirancird.farId.Zeaoi.gvmefSoo.zyeltrypot.uorcPlae2"

    const-string v0, "com.google.android.gms.fido.u2f.internal.zeroparty.IU2fZeroPartyService"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string v0, "dosgrdrafST.z2b.ongegofcdeo.im..RpuTiry.oAmosl."

    const-string/jumbo v0, "oir.ebo.zodgpafmif.AT.2TagloRygr.mo.r.duocdeSsn"

    const/4 v2, 0x0

    const-string v0, "gupmSetd.oi.dc2meo.agrrn.s.mogdToolio.rfz.fTyaR"

    const-string v0, "com.google.android.gms.fido.u2f.zeroparty.START"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
