.class public final Lcom/google/android/gms/internal/fido/zzy;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/16 v3, 0x75

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/~sbobb @4t@~ ol~.@ s @S~tM~ ~~ ~@od~r @@@~~@@@@~lvo1u@@~~in@~@ i~/ @~ci  fa  @~o- oK~ f ~~@@ my"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, "gc.mairoSrsemm2.doedr.frgoplug.lis.oiclnenaouA2de.p.tInafri.fgU"

    const-string/jumbo v0, "iosoUadioeund.mfA.o.lglgdrue.rlefs2.ppineornrc.mggetf2.ic.raSIa"

    const/4 v3, 0x0

    const-string v0, "eA.ao..rlonaei2rIi.ou.cr.gppe.cuoggiSfdvtodimsdle2gafmnlnreUf.o"

    const-string v0, "com.google.android.gms.fido.u2f.internal.regular.IU2fAppService"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, v0, Lcom/google/android/gms/internal/fido/zzw;

    const/4 v2, 0x6

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/internal/fido/zzw;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/internal/fido/zzw;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/internal/fido/zzw;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "TTmREbAITSVCISACNR__"

    const-string v1, "ACSmIO_TRRCVNESTTIA_"

    const/4 v4, 0x7

    const-string v1, "SR_COCuS_ETETIRNVIAA"

    const-string v1, "ACTION_START_SERVICE"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v2, "iur.pggphddomoT.afy.2..dlRomfcirdTengtoorAtoaS.."

    const-string v2, "epr.o.drgoro.Sm..iooihfonugda.glydtdci.tTAT2faRm"

    const/4 v4, 0x5

    const-string/jumbo v2, "ir.mfdoeqdaAo.gmnR2SopylTrt.ghi.g..oaifTudsct.rd"

    const-string v2, "com.google.android.gms.fido.u2f.thirdparty.START"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const v0, 0xc65d40

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "omsoIioaggadnm2sn..d.Sfigcrufr.tfaU2elpoepdbuo.Aev.rilngrec..ie"

    const-string/jumbo v0, "oen.pbu.go2fS.l2i.c.Aoerlm.ugro.sdandoifpeeInaUifrvamrrg.geditc"

    const/4 v2, 0x6

    const-string v0, "g2lm..poSeeaAgdogcnailmvfi...toer.difd.gf.nlrouaecispIUr2urrnme"

    const-string v0, "com.google.android.gms.fido.u2f.internal.regular.IU2fAppService"

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "dm.ro.psyfRnAa.oiSTtrdiog.ghci2dol.rfutd.m.aougT"

    const-string v0, "edocfruamsolTymTgttng...h.dp.AdgraRifSi.i2oduo.r"

    const/4 v2, 0x6

    const-string/jumbo v0, "mo.oibAdp2ddhyr.g.e.srocRtoig.fufnT.adaiorSmgtT."

    const-string v0, "com.google.android.gms.fido.u2f.thirdparty.START"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x1

    and-int/2addr v2, v0

    const/4 v1, 0x2

    move v2, v1

    return v0
.end method
