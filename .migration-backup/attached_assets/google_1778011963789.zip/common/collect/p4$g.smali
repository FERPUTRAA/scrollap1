.class final Lcom/google/common/collect/p4$g;
.super Lcom/google/common/collect/p4$i;

# interfaces
.implements Ljava/util/Spliterator$OfLong;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/p4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<InElementT:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/p4$i<",
        "TInElementT;",
        "Ljava/lang/Long;",
        "Ljava/util/function/LongConsumer;",
        "Ljava/util/Spliterator$OfLong;",
        ">;",
        "Ljava/util/Spliterator$OfLong;"
    }
.end annotation


# direct methods
.method constructor <init>(Ljava/util/Spliterator$OfLong;Ljava/util/Spliterator;Ljava/util/function/Function;IJ)V
    .locals 9
    .param p1    # Ljava/util/Spliterator$OfLong;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "prefix",
            "from",
            "function",
            "characteristics",
            "estimatedSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Spliterator$OfLong;",
            "Ljava/util/Spliterator<",
            "TInElementT;>;",
            "Ljava/util/function/Function<",
            "-TInElementT;",
            "Ljava/util/Spliterator$OfLong;",
            ">;IJ)V"
        }
    .end annotation

    const/4 v8, 0x6

    new-instance v4, Lcom/google/common/collect/g5;

    const/4 v8, 0x3

    invoke-direct {v4}, Lcom/google/common/collect/g5;-><init>()V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v8, 0x5

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    move-wide v6, p5

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v7}, Lcom/google/common/collect/p4$i;-><init>(Ljava/util/Spliterator$OfPrimitive;Ljava/util/Spliterator;Ljava/util/function/Function;Lcom/google/common/collect/p4$d$a;IJ)V

    const/4 v8, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic forEachRemaining(Ljava/util/function/LongConsumer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "action"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~~i  ~~b~  @@@4o~do~~ @s frtK ~-n @S~f~M@o@c @/~@1lt  @~.a ~~l~@u@@ ~ ~m @bo @@y~i@/@~i@~boo "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/common/collect/p4$i;->forEachRemaining(Ljava/lang/Object;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic tryAdvance(Ljava/util/function/LongConsumer;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "action"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/common/collect/p4$i;->tryAdvance(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic trySplit()Ljava/util/Spliterator$OfLong;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/common/collect/p4$d;->trySplit()Ljava/util/Spliterator;

    move-result-object v0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/common/collect/f5;->a(Ljava/lang/Object;)Ljava/util/Spliterator$OfLong;

    move-result-object v0

    const/4 v2, 0x5

    return-object v0
.end method
