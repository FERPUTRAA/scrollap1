.class final Lcom/google/common/collect/bf$b;
.super Lcom/google/common/collect/jb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/bf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/bf$b$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/jb<",
        "TK;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field private final map:Lcom/google/common/collect/bf;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/bf<",
            "TK;*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/collect/bf;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "map"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/bf<",
            "TK;*>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/jb;-><init>()V

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/collect/bf$b;->map:Lcom/google/common/collect/bf;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/bf$b;->map:Lcom/google/common/collect/bf;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/collect/w9;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p1
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return v0
.end method

.method get(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TK;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/bf$b;->map:Lcom/google/common/collect/bf;

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/google/common/collect/bf;->f:[Ljava/util/Map$Entry;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    aget-object p1, v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/bf$b;->map:Lcom/google/common/collect/bf;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/google/common/collect/bf;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
