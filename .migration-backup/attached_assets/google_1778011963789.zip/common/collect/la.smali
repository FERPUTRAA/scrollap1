.class public abstract Lcom/google/common/collect/la;
.super Lcom/google/common/collect/na;

# interfaces
.implements Lcom/google/common/collect/ae;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/la$f;,
        Lcom/google/common/collect/la$c;,
        Lcom/google/common/collect/la$b;,
        Lcom/google/common/collect/la$e;,
        Lcom/google/common/collect/la$d;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/na<",
        "TE;>;",
        "Lcom/google/common/collect/ae<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
    serializable = true
.end annotation


# instance fields
.field private transient c:Lcom/google/common/collect/t9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/t9<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation runtime Lz4/b;
    .end annotation
.end field

.field private transient d:Lcom/google/common/collect/qa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation runtime Lz4/b;
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/na;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static A(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "e1",
            "e2",
            "e3",
            "e4"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;TE;TE;TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    aput-object p0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    aput-object p1, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p0, 0x2

    const/4 v3, 0x7

    aput-object p2, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p0, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    aput-object p3, v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0
.end method

.method public static B(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "e1",
            "e2",
            "e3",
            "e4",
            "e5"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;TE;TE;TE;TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x4

    move v3, v2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    aput-object p0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v2, 0x7

    move v3, v2

    aput-object p1, v0, p0

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 p0, 0x2

    move v3, p0

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    aput-object p2, v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    aput-object p3, v0, p0

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p0, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    aput-object p4, v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p0
.end method

.method public static varargs C(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "e1",
            "e2",
            "e3",
            "e4",
            "e5",
            "e6",
            "others"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;TE;TE;TE;TE;TE;[TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/la$b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/common/collect/la$b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p3}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p4}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p5}, Lcom/google/common/collect/la$b;->h(Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p6}, Lcom/google/common/collect/la$b;->i([Ljava/lang/Object;)Lcom/google/common/collect/la$b;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/la$b;->m()Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static E()Ljava/util/stream/Collector;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Ljava/util/stream/Collector<",
            "TE;*",
            "Lcom/google/common/collect/la<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/ja;->a()Ljava/util/function/Function;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v1, Lcom/google/common/collect/ka;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-direct {v1}, Lcom/google/common/collect/ka;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/common/collect/c4;->r0(Ljava/util/function/Function;Ljava/util/function/ToIntFunction;)Ljava/util/stream/Collector;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method public static F(Ljava/util/function/Function;Ljava/util/function/ToIntFunction;)Ljava/util/stream/Collector;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "elementFunction",
            "countFunction"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/function/Function<",
            "-TT;+TE;>;",
            "Ljava/util/function/ToIntFunction<",
            "-TT;>;)",
            "Ljava/util/stream/Collector<",
            "TT;*",
            "Lcom/google/common/collect/la<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/google/common/collect/c4;->r0(Ljava/util/function/Function;Ljava/util/function/ToIntFunction;)Ljava/util/stream/Collector;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public static synthetic i(Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/collect/la;->u(Ljava/lang/Object;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p0
.end method

.method public static j()Lcom/google/common/collect/la$b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/la$b<",
            "TE;>;"
        }
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    new-instance v0, Lcom/google/common/collect/la$b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/collect/la$b;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method private static varargs k([Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/common/collect/jc;->o()Lcom/google/common/collect/jc;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/google/common/collect/la;->l(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method static l(Ljava/util/Collection;)Lcom/google/common/collect/la;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entries"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "+",
            "Lcom/google/common/collect/ae$a<",
            "+TE;>;>;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/common/collect/la;->w()Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/common/collect/cf;->G(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public static m(Ljava/lang/Iterable;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "+TE;>;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v0, p0, Lcom/google/common/collect/la;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Lcom/google/common/collect/la;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/common/collect/n9;->g()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    instance-of v0, p0, Lcom/google/common/collect/ae;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/google/common/collect/de;->d(Ljava/lang/Iterable;)Lcom/google/common/collect/ae;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/google/common/collect/jc;->q(Ljava/lang/Iterable;)Lcom/google/common/collect/jc;

    move-result-object p0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/google/common/collect/la;->l(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method

.method public static n(Ljava/util/Iterator;)Lcom/google/common/collect/la;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator<",
            "+TE;>;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/common/collect/jc;->o()Lcom/google/common/collect/jc;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/common/collect/yb;->a(Ljava/util/Collection;Ljava/util/Iterator;)Z

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/google/common/collect/la;->l(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static o([Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method private p()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/la$d;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/la$d;-><init>(Lcom/google/common/collect/la;Lcom/google/common/collect/la$a;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/InvalidObjectException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v1, 0x2

    move v2, v1

    const-string/jumbo v0, "zisFiSeredsarsem o"

    const-string v0, "eSseFailosmdrzrie "

    const/4 v2, 0x6

    const-string v0, "eadmliseFrire UmzS"

    const-string v0, "Use SerializedForm"

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    throw p1
.end method

.method private static synthetic u(Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p0, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p0
.end method

.method public static w()Lcom/google/common/collect/la;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/common/collect/cf;->k:Lcom/google/common/collect/la;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static x(Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    aput-object p0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method public static y(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "e1",
            "e2"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    aput-object p0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    aput-object p1, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0
.end method

.method public static z(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/la;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "e1",
            "e2",
            "e3"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(TE;TE;TE;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    aput-object p0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    aput-object p1, v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object p2, v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/common/collect/la;->k([Ljava/lang/Object;)Lcom/google/common/collect/la;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0
.end method


# virtual methods
.method public final H(Ljava/lang/Object;I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "count"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;I)I"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x7

    throw p1
.end method

.method public final S0(Ljava/lang/Object;I)I
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    throw p1
.end method

.method public a()Lcom/google/common/collect/t9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/t9<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/la;->c:Lcom/google/common/collect/t9;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/collect/n9;->a()Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/common/collect/la;->c:Lcom/google/common/collect/t9;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public final a1(Ljava/lang/Object;I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;I)I"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x2

    throw p1
.end method

.method b([Ljava/lang/Object;I)I
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "dst",
            "offset"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/la;->s()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/common/collect/qa;->h()Lcom/google/common/collect/am;

    move-result-object v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v1, Lcom/google/common/collect/ae$a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-int/2addr v2, p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v1}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p1, p2, v2, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v1}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/2addr p2, v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return p2
.end method

.method public bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/la;->q()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-interface {p0, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-lez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method public synthetic d0(Ljava/util/function/ObjIntConsumer;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/common/collect/zd;->b(Lcom/google/common/collect/ae;Ljava/util/function/ObjIntConsumer;)V

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public bridge synthetic entrySet()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/la;->s()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/google/common/collect/de;->i(Lcom/google/common/collect/ae;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p1
.end method

.method public synthetic forEach(Ljava/util/function/Consumer;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/common/collect/zd;->a(Lcom/google/common/collect/ae;Ljava/util/function/Consumer;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public h()Lcom/google/common/collect/am;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/la;->s()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/qa;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lcom/google/common/collect/la$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v1, p0, v0}, Lcom/google/common/collect/la$a;-><init>(Lcom/google/common/collect/la;Ljava/util/Iterator;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/la;->s()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/common/collect/uf;->k(Ljava/util/Set;)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    return v0
.end method

.method public bridge synthetic iterator()Ljava/util/Iterator;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/la;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public abstract q()Lcom/google/common/collect/qa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TE;>;"
        }
    .end annotation
.end method

.method public final q1(Ljava/lang/Object;II)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "element",
            "oldCount",
            "newCount"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;II)Z"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    throw p1
.end method

.method public s()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/la;->d:Lcom/google/common/collect/qa;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/la;->p()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/common/collect/la;->d:Lcom/google/common/collect/qa;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method abstract t(I)Lcom/google/common/collect/ae$a;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/la;->s()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method writeReplace()Ljava/lang/Object;
    .locals 3
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/collect/la$f;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/collect/la$f;-><init>(Lcom/google/common/collect/ae;)V

    const/4 v1, 0x1

    or-int/2addr v2, v1

    return-object v0
.end method
