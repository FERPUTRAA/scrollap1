.class public abstract Lcom/google/common/collect/hb;
.super Lcom/google/common/collect/h0;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/hb$b;,
        Lcom/google/common/collect/hb$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/h0<",
        "TR;TC;TV;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/h0;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static H(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/stream/Collector;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowFunction",
            "columnFunction",
            "valueFunction"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/function/Function<",
            "-TT;+TR;>;",
            "Ljava/util/function/Function<",
            "-TT;+TC;>;",
            "Ljava/util/function/Function<",
            "-TT;+TV;>;)",
            "Ljava/util/stream/Collector<",
            "TT;*",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lcom/google/common/collect/ol;->r(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/stream/Collector;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public static I(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/BinaryOperator;)Ljava/util/stream/Collector;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowFunction",
            "columnFunction",
            "valueFunction",
            "mergeFunction"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/function/Function<",
            "-TT;+TR;>;",
            "Ljava/util/function/Function<",
            "-TT;+TC;>;",
            "Ljava/util/function/Function<",
            "-TT;+TV;>;",
            "Ljava/util/function/BinaryOperator<",
            "TV;>;)",
            "Ljava/util/stream/Collector<",
            "TT;*",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/google/common/collect/ol;->s(Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/BinaryOperator;)Ljava/util/stream/Collector;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method

.method public static i()Lcom/google/common/collect/hb$a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/hb$a<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/hb$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {v0}, Lcom/google/common/collect/hb$a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method static k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/bl$a;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(TR;TC;TV;)",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "Kessrw"

    const-string v0, "ersyKw"

    const/4 v2, 0x3

    const-string/jumbo v0, "reomKy"

    const-string/jumbo v0, "rowKey"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "nmmyoeocu"

    const-string/jumbo v0, "yuemmcnlo"

    const/4 v2, 0x4

    const-string/jumbo v0, "moylubKec"

    const-string v0, "columnKey"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "oueul"

    const-string/jumbo v0, "ulveo"

    const/4 v2, 0x3

    const-string/jumbo v0, "value"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p2, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, p1, p2}, Lcom/google/common/collect/pl;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/bl$a;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/InvalidObjectException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo v0, "s FzeirpeadelbUSmr"

    const-string/jumbo v0, "s zeaboeFmidrUerlS"

    const/4 v2, 0x2

    const-string v0, "eoUsiSaeqzmrrd lFi"

    const-string v0, "Use SerializedForm"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    throw p1
.end method

.method public static s(Lcom/google/common/collect/bl;)Lcom/google/common/collect/hb;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/collect/bl<",
            "+TR;+TC;+TV;>;)",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    instance-of v0, p0, Lcom/google/common/collect/hb;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Lcom/google/common/collect/hb;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {p0}, Lcom/google/common/collect/bl;->G()Ljava/util/Set;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/google/common/collect/hb;->t(Ljava/lang/Iterable;)Lcom/google/common/collect/hb;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method static t(Ljava/lang/Iterable;)Lcom/google/common/collect/hb;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "cells"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "+",
            "Lcom/google/common/collect/bl$a<",
            "+TR;+TC;+TV;>;>;)",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/common/collect/hb;->i()Lcom/google/common/collect/hb$a;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v1, Lcom/google/common/collect/bl$a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Lcom/google/common/collect/hb$a;->f(Lcom/google/common/collect/bl$a;)Lcom/google/common/collect/hb$a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/hb$a;->a()Lcom/google/common/collect/hb;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0
.end method

.method public static x()Lcom/google/common/collect/hb;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/common/collect/rg;->c:Lcom/google/common/collect/hb;

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object v0
.end method

.method public static y(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/hb;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(TR;TC;TV;)",
            "Lcom/google/common/collect/hb<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/eg;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1, p2}, Lcom/google/common/collect/eg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public final A(Lcom/google/common/collect/bl;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/bl<",
            "+TR;+TC;+TV;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    throw p1
.end method

.method public bridge synthetic B()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->p()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public C()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->E()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/common/collect/w9;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public abstract E()Lcom/google/common/collect/w9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/w9<",
            "TR;",
            "Ljava/util/Map<",
            "TC;TV;>;>;"
        }
    .end annotation
.end method

.method public bridge synthetic F(Ljava/lang/Object;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "columnKey"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/hb;->m(Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic G()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->l()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public K()Lcom/google/common/collect/n9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/common/collect/h0;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast v0, Lcom/google/common/collect/n9;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final L(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;TC;TV;)TV;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    throw p1
.end method

.method public bridge synthetic T()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->n()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic U(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "rowKey"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/common/collect/h0;->U(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method public Y(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/hb;->o(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method bridge synthetic a()Ljava/util/Iterator;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->j()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic a0(Ljava/lang/Object;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "rowKey"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/hb;->z(Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method final b()Ljava/util/Spliterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v1, "euso neeabrucl eldvs d"

    const-string v1, " edur ua nveldsleebcol"

    const/4 v3, 0x3

    const-string v1, "e emeellrldnabuvh oscd"

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    throw v0
.end method

.method bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public final clear()V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw v0
.end method

.method public containsValue(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->K()Lcom/google/common/collect/n9;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/collect/n9;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return p1
.end method

.method bridge synthetic d()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->w()Lcom/google/common/collect/n9;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method final e()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "rlocodaelveuhbsp n e e"

    const-string v1, "cedbo spa r vnuleleedh"

    const/4 v3, 0x0

    const-string v1, "hen lbbrecsddalel evo "

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw v0
.end method

.method public bridge synthetic equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-super {p0, p1}, Lcom/google/common/collect/h0;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method public bridge synthetic f()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->C()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic h()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->E()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method public bridge synthetic hashCode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/common/collect/h0;->hashCode()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic isEmpty()Z
    .locals 3

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/common/collect/h0;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method final j()Lcom/google/common/collect/am;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, " lerbeuoundlhde  aqvel"

    const-string v1, "brovh deq lenleceu lad"

    const/4 v3, 0x0

    const-string v1, "dolsevhpl a bednur eec"

    const-string/jumbo v1, "should never be called"

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    throw v0
.end method

.method public l()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/common/collect/h0;->G()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast v0, Lcom/google/common/collect/qa;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public m(Ljava/lang/Object;)Lcom/google/common/collect/w9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "columnKey"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)",
            "Lcom/google/common/collect/w9<",
            "TR;TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "ousclynKq"

    const-string/jumbo v0, "nosKlcyue"

    const/4 v2, 0x4

    const-string/jumbo v0, "ycsuKlenm"

    const-string v0, "columnKey"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->p()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/collect/w9;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p1, Lcom/google/common/collect/w9;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/collect/w9;->w()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    check-cast p1, Lcom/google/common/collect/w9;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1
.end method

.method public n()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->p()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/common/collect/w9;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic o(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "rowKey",
            "columnKey"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/h0;->o(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public abstract p()Lcom/google/common/collect/w9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/w9<",
            "TC;",
            "Ljava/util/Map<",
            "TR;TV;>;>;"
        }
    .end annotation
.end method

.method public bridge synthetic q(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "columnKey"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/common/collect/h0;->q(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method public final remove(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    throw p1
.end method

.method public bridge synthetic toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/collect/h0;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method abstract u()Lcom/google/common/collect/qa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation
.end method

.method abstract v()Lcom/google/common/collect/hb$b;
.end method

.method public bridge synthetic values()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->K()Lcom/google/common/collect/n9;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method abstract w()Lcom/google/common/collect/n9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TV;>;"
        }
    .end annotation
.end method

.method final writeReplace()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->v()Lcom/google/common/collect/hb$b;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public z(Ljava/lang/Object;)Lcom/google/common/collect/w9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "rowKey"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;)",
            "Lcom/google/common/collect/w9<",
            "TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "meymKr"

    const-string v0, "Kremoy"

    const/4 v2, 0x6

    const-string v0, "eoKyow"

    const-string/jumbo v0, "rowKey"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->F(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->E()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/common/collect/w9;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    check-cast p1, Lcom/google/common/collect/w9;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/common/collect/w9;->w()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p1, Lcom/google/common/collect/w9;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method
