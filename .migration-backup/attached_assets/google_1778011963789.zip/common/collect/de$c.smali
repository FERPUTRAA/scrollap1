.class Lcom/google/common/collect/de$c;
.super Lcom/google/common/collect/de$n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/de;->z(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)Lcom/google/common/collect/ae;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/de$n<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic c:Lcom/google/common/collect/ae;

.field final synthetic d:Lcom/google/common/collect/ae;


# direct methods
.method constructor <init>(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$multiset1",
            "val$multiset2"
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    iput-object p2, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/de$n;-><init>(Lcom/google/common/collect/de$a;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public I1(Ljava/lang/Object;)I
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ons@~@/@ii@ oo~@u~   ~i~@a~~@~@ -v@b .t @@tMf~b@@~ @~@l~bS  ~~ l1~m@~ o@ /o~@~ ~d~f~~y@s@cro 4  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v1, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/2addr v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method a()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae;->c()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v1}, Lcom/google/common/collect/ae;->c()Ljava/util/Set;

    move-result-object v1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/google/common/collect/uf;->O(Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/uf$m;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p1
.end method

.method e()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x6

    const-string/jumbo v1, "rnbmedlcoeluses  lheda"

    const-string v1, "d sec e dllaroheselnbu"

    const/4 v3, 0x1

    const-string v1, "h ldolneaeeuc r ldeosb"

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    throw v0
.end method

.method f()Ljava/util/Iterator;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-interface {v1}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v2, Lcom/google/common/collect/de$c$a;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v2, p0, v0, v1}, Lcom/google/common/collect/de$c$a;-><init>(Lcom/google/common/collect/de$c;Ljava/util/Iterator;Ljava/util/Iterator;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v2
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v1, 0x1

    move v2, v1

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    return v0
.end method

.method public size()I
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$c;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/collect/de$c;->d:Lcom/google/common/collect/ae;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v1}, Lcom/google/common/collect/ae;->size()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/common/math/f;->t(II)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method
