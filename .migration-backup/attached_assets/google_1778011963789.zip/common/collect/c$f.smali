.class Lcom/google/common/collect/c$f;
.super Lcom/google/common/collect/t8;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t8<",
        "TV;>;"
    }
.end annotation


# instance fields
.field final a:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "TV;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lcom/google/common/collect/c;


# direct methods
.method private constructor <init>(Lcom/google/common/collect/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/collect/c$f;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/t8;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p1, p1, Lcom/google/common/collect/c;->b:Lcom/google/common/collect/c;

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-virtual {p1}, Lcom/google/common/collect/c;->keySet()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/collect/c$f;->a:Ljava/util/Set;

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/c;Lcom/google/common/collect/c$a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/c$f;-><init>(Lcom/google/common/collect/c;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ sb~~yb ~@ot~~ o@cv@i@~d@ -m    ~obo~~S  t ./1@fs@@f@o/@~~ ~~ @i@K~~   ~@~~@M~~@@ 4@u~~@alrilno"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/c$f;->z0()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method protected bridge synthetic i0()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/c$f;->z0()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/c$f;->b:Lcom/google/common/collect/c;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {v0}, Lcom/google/common/collect/c;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/common/collect/uc;->R0(Ljava/util/Iterator;)Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/z7;->w0()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "array"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/collect/z7;->x0([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/z7;->y0()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method protected z0()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/c$f;->a:Ljava/util/Set;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method
