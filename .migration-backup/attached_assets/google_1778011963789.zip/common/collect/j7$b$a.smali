.class Lcom/google/common/collect/j7$b$a;
.super Lcom/google/common/collect/de$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/j7$b;->b(I)Lcom/google/common/collect/ae$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/de$f<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/google/common/collect/j7$b;


# direct methods
.method constructor <init>(Lcom/google/common/collect/j7$b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$1",
            "val$index"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/j7$b$a;->b:Lcom/google/common/collect/j7$b;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p2, p0, Lcom/google/common/collect/j7$b$a;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/de$f;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic a()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~s.@1~MK ib@/@o s@~~ bi u@~@@~ ~y t@tl~c~i~d@@r~~@~ @~ ba@on v@S@-o4 f@@~~~o@@ /o f~@ ~~~   m~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/j7$b$a;->b()Ljava/lang/Enum;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public b()Ljava/lang/Enum;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/j7$b$a;->b:Lcom/google/common/collect/j7$b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, v0, Lcom/google/common/collect/j7$b;->d:Lcom/google/common/collect/j7;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/common/collect/j7;->g(Lcom/google/common/collect/j7;)[Ljava/lang/Enum;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/common/collect/j7$b$a;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    aget-object v0, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getCount()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/j7$b$a;->b:Lcom/google/common/collect/j7$b;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/google/common/collect/j7$b;->d:Lcom/google/common/collect/j7;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/common/collect/j7;->h(Lcom/google/common/collect/j7;)[I

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/common/collect/j7$b$a;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    aget v0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method
