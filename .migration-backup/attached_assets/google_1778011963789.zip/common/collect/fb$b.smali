.class public final Lcom/google/common/collect/fb$b;
.super Lcom/google/common/collect/qa$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/fb;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/qa$a<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private final d:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "-TE;>;"
        }
    .end annotation
.end field

.field private e:[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TE;"
        }
    .end annotation
.end field

.field private f:I


# direct methods
.method public constructor <init>(Ljava/util/Comparator;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "comparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Comparator<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/common/collect/qa$a;-><init>(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast p1, Ljava/util/Comparator;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v1, 0x2

    move v2, v1

    const/4 p1, 0x4

    shl-int/2addr v2, p1

    const/4 v1, 0x6

    move v2, v1

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x0

    shr-int/2addr v2, p1

    const/4 v1, 0x4

    and-int/2addr v2, v1

    iput p1, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private v()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "its~ o@o~@~~ ~vb~i@~ -~o@/s~Mt@m@d~@S~@i1r~f ~o~~l  @@/ .~ y~ @K@@ o@4@ n b@ ~@@a~lu @~foc ~b~ @"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget v0, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-static {v1, v2, v0, v3}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    move v1, v0

    move v1, v0

    const/4 v6, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v5, 0x5

    and-int/2addr v6, v5

    if-ge v0, v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v4, v1, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    aget-object v4, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    aget-object v3, v3, v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v2, v4, v3}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-gez v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    aget-object v4, v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    aput-object v4, v2, v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x2

    move v1, v3

    move v1, v3

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-gtz v2, :cond_2

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v5, 0x6

    move v6, v5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    and-int/2addr v6, v5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v2, "C omsapromr"

    const-string/jumbo v2, "rasrpomo Ct"

    const/4 v6, 0x6

    const-string/jumbo v2, "orrmoaopatC"

    const-string v2, "Comparator "

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v2, "eolc bi  ects isvnetao totmhprtaomrda"

    const-string v2, "cesmaotoeist m ancr  choe aotttidrlpv"

    const/4 v6, 0x5

    const-string v2, "evo a uhrctt ot crielmtondaeas psicmo"

    const-string v2, " compare method violates its contract"

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    throw v0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v1, v2, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput v1, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)Lcom/google/common/collect/n9$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "element"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->p(Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic b([Ljava/lang/Object;)Lcom/google/common/collect/n9$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->q([Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic c(Ljava/lang/Iterable;)Lcom/google/common/collect/n9$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->r(Ljava/lang/Iterable;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic d(Ljava/util/Iterator;)Lcom/google/common/collect/n9$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->s(Ljava/util/Iterator;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic e()Lcom/google/common/collect/n9;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/fb$b;->t()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic g(Ljava/lang/Object;)Lcom/google/common/collect/qa$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "element"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->p(Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic h([Ljava/lang/Object;)Lcom/google/common/collect/qa$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->q([Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic i(Ljava/lang/Iterable;)Lcom/google/common/collect/qa$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->r(Ljava/lang/Iterable;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic j(Ljava/util/Iterator;)Lcom/google/common/collect/qa$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->s(Ljava/util/Iterator;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic k()Lcom/google/common/collect/qa;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p0}, Lcom/google/common/collect/fb$b;->t()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method bridge synthetic l(Lcom/google/common/collect/qa$a;)Lcom/google/common/collect/qa$a;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/fb$b;->u(Lcom/google/common/collect/qa$a;)Lcom/google/common/collect/fb$b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method m()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v3, 0x0

    array-length v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public p(Ljava/lang/Object;)Lcom/google/common/collect/fb$b;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Lcom/google/common/collect/fb$b<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/qa$a;->n()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    array-length v1, v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ne v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/fb$b;->v()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/lit8 v1, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/google/common/collect/n9$a;->f(II)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length v2, v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-le v0, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x5

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput v2, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    aput-object p1, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0
.end method

.method public varargs q([Ljava/lang/Object;)Lcom/google/common/collect/fb$b;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([TE;)",
            "Lcom/google/common/collect/fb$b<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/common/collect/ke;->b([Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    array-length v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ge v1, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    aget-object v2, p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Lcom/google/common/collect/fb$b;->p(Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object p0
.end method

.method public r(Ljava/lang/Iterable;)Lcom/google/common/collect/fb$b;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+TE;>;)",
            "Lcom/google/common/collect/fb$b<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/common/collect/qa$a;->i(Ljava/lang/Iterable;)Lcom/google/common/collect/qa$a;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public s(Ljava/util/Iterator;)Lcom/google/common/collect/fb$b;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Iterator<",
            "+TE;>;)",
            "Lcom/google/common/collect/fb$b<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/common/collect/qa$a;->j(Ljava/util/Iterator;)Lcom/google/common/collect/qa$a;

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-object p0
.end method

.method public t()Lcom/google/common/collect/fb;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/fb<",
            "TE;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/fb$b;->v()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/common/collect/fb;->e0(Ljava/util/Comparator;)Lcom/google/common/collect/ff;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/google/common/collect/qa$a;->c:Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Lcom/google/common/collect/ff;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/common/collect/fb$b;->f:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lcom/google/common/collect/t9;->j([Ljava/lang/Object;I)Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/collect/fb$b;->d:Ljava/util/Comparator;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/common/collect/ff;-><init>(Lcom/google/common/collect/t9;Ljava/util/Comparator;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v0
.end method

.method u(Lcom/google/common/collect/qa$a;)Lcom/google/common/collect/fb$b;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/qa$a<",
            "TE;>;)",
            "Lcom/google/common/collect/fb$b<",
            "TE;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/qa$a;->n()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p1, Lcom/google/common/collect/fb$b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v1, p1, Lcom/google/common/collect/fb$b;->f:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ge v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p1, Lcom/google/common/collect/fb$b;->e:[Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    aget-object v1, v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v1}, Lcom/google/common/collect/fb$b;->p(Ljava/lang/Object;)Lcom/google/common/collect/fb$b;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method
