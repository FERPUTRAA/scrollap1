.class Lcom/google/common/collect/jb$a;
.super Lcom/google/common/collect/j9;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/jb;->E()Lcom/google/common/collect/t9;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/j9<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/google/common/collect/jb;


# direct methods
.method constructor <init>(Lcom/google/common/collect/jb;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/collect/jb$a;->this$0:Lcom/google/common/collect/jb;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/j9;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method S()Lcom/google/common/collect/n9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TE;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ sc~ uio.@o~@ @4 ~i/y ~ l@~b M f ~d@ l o1oo ~f@@@ ~-~@m@o t@~~@~i~S ~~ @s@bn~~@v@~~ K@@rb/t@~a@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/jb$a;->this$0:Lcom/google/common/collect/jb;

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/jb$a;->this$0:Lcom/google/common/collect/jb;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/common/collect/n9;->g()Z

    move-result v0

    const/4 v2, 0x6

    return v0
.end method

.method public get(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TE;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/common/collect/jb$a;->this$0:Lcom/google/common/collect/jb;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/common/collect/jb;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/jb$a;->this$0:Lcom/google/common/collect/jb;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method
