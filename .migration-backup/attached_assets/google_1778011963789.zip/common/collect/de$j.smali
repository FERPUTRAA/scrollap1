.class final Lcom/google/common/collect/de$j;
.super Lcom/google/common/collect/de$n;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/de;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "j"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/de$n<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final c:Lcom/google/common/collect/ae;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ae<",
            "TE;>;"
        }
    .end annotation
.end field

.field final d:Lcom/google/common/base/w0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/base/w0<",
            "-TE;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/collect/ae;Lcom/google/common/base/w0;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "unfiltered",
            "predicate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ae<",
            "TE;>;",
            "Lcom/google/common/base/w0<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/common/collect/de$n;-><init>(Lcom/google/common/collect/de$a;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast p1, Lcom/google/common/collect/ae;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p1, Lcom/google/common/base/w0;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public I1(Ljava/lang/Object;)I
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s~fy-s4o~~Miod@r~@f/~@b~@~    @~@/i m@~ oS @ .~~@  ~@~~~@tb~bul@ Ki n~@  oo@~@l t@~ @@~1~cv~@o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-lez v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v2, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    move v0, v1

    move v0, v1

    const/4 v4, 0x2

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1
.end method

.method public S0(Ljava/lang/Object;I)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "uermocsrecc"

    const-string/jumbo v0, "ocsescurerc"

    const/4 v2, 0x5

    const-string v0, "ecruosnorcc"

    const-string/jumbo v0, "occurrences"

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {p2, v0}, Lcom/google/common/collect/e4;->b(ILjava/lang/String;)I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/de$j;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/y;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1, p2}, Lcom/google/common/collect/ae;->S0(Ljava/lang/Object;I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method a()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/google/common/collect/ae;->c()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/common/collect/uf;->i(Ljava/util/Set;Lcom/google/common/base/w0;)Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method public a1(Ljava/lang/Object;I)I
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;I)I"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/google/common/base/w0;->apply(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const-string v1, "etarmbd itet scdl m%eoss%h nceat  omnp"

    const-string v1, "entmtas cnptec d%thmaesls rod o e%i em"

    const/4 v4, 0x3

    const-string/jumbo v1, "n %esrul ttaieecst  ad  oo%mmEhneecdps"

    const-string v1, "Element %s does not match predicate %s"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1, p1, v2}, Lcom/google/common/base/u0;->y(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v4, 0x5

    invoke-interface {v0, p1, p2}, Lcom/google/common/collect/ae;->a1(Ljava/lang/Object;I)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p1
.end method

.method b()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v1, Lcom/google/common/collect/de$j$a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/google/common/collect/de$j$a;-><init>(Lcom/google/common/collect/de$j;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/common/collect/uf;->i(Ljava/util/Set;Lcom/google/common/base/w0;)Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method e()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "dvoraubplolece  ldes h"

    const-string v1, "cr  onds eldvblluaeeho"

    const/4 v3, 0x2

    const-string/jumbo v1, "ulevrac qol  dedbeehls"

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw v0
.end method

.method f()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "rlsce dbve uahlso blnd"

    const-string/jumbo v1, "oeau bvbll hldcesrend "

    const/4 v3, 0x5

    const-string/jumbo v1, "udamsrblev nohd lelce "

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw v0
.end method

.method public g()Lcom/google/common/collect/am;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/de$j;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/google/common/collect/ae;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v1, p0, Lcom/google/common/collect/de$j;->d:Lcom/google/common/base/w0;

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/common/collect/yb;->x(Ljava/util/Iterator;Lcom/google/common/base/w0;)Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic iterator()Ljava/util/Iterator;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/de$j;->g()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method
