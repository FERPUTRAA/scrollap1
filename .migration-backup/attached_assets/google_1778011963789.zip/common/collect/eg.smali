.class Lcom/google/common/collect/eg;
.super Lcom/google/common/collect/hb;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/hb<",
        "TR;TC;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# instance fields
.field final singleColumnKey:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TC;"
        }
    .end annotation
.end field

.field final singleRowKey:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TR;"
        }
    .end annotation
.end field

.field final singleValue:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/common/collect/bl$a;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "cell"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p1}, Lcom/google/common/collect/bl$a;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/bl$a;->b()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/bl$a;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, v0, v1, p1}, Lcom/google/common/collect/eg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x4

    return-void
.end method

.method constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;TC;TV;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/hb;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/eg;->singleRowKey:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/common/collect/eg;->singleColumnKey:Ljava/lang/Object;

    const/4 v1, 0x6

    invoke-static {p3}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic B()Ljava/util/Map;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "K@s  d@~~~ ~~S@ ~.fy i~   vbc@@~@ b  @  ~~f~t~t@@o@ @o4 -~/b~l@ @o~m ~~1@o~@@@alM@sno@@uo~i~i~r/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/eg;->p()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public E()Lcom/google/common/collect/w9;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/w9<",
            "TR;",
            "Ljava/util/Map<",
            "TC;TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/eg;->singleRowKey:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/eg;->singleColumnKey:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lcom/google/common/collect/w9;->x(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/google/common/collect/w9;->x(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0
.end method

.method public bridge synthetic F(Ljava/lang/Object;)Ljava/util/Map;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "columnKey"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/eg;->m(Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/eg;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method bridge synthetic d()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/eg;->w()Lcom/google/common/collect/n9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic h()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/eg;->E()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-object v0
.end method

.method public m(Ljava/lang/Object;)Lcom/google/common/collect/w9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "columnKey"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)",
            "Lcom/google/common/collect/w9<",
            "TR;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/hb;->q(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/common/collect/eg;->singleRowKey:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/common/collect/w9;->x(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/common/collect/w9;->w()Lcom/google/common/collect/w9;

    move-result-object p1

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method public p()Lcom/google/common/collect/w9;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/w9<",
            "TC;",
            "Ljava/util/Map<",
            "TR;TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/collect/eg;->singleColumnKey:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/eg;->singleRowKey:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget-object v2, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/google/common/collect/w9;->x(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/google/common/collect/w9;->x(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method u()Lcom/google/common/collect/qa;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/collect/eg;->singleRowKey:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/eg;->singleColumnKey:Ljava/lang/Object;

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Lcom/google/common/collect/hb;->k(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/bl$a;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/common/collect/qa;->w(Ljava/lang/Object;)Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method

.method v()Lcom/google/common/collect/hb$b;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    filled-new-array {v0}, [I

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, v1, v0}, Lcom/google/common/collect/hb$b;->a(Lcom/google/common/collect/hb;[I[I)Lcom/google/common/collect/hb$b;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method w()Lcom/google/common/collect/n9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/eg;->singleValue:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/common/collect/qa;->w(Ljava/lang/Object;)Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method
