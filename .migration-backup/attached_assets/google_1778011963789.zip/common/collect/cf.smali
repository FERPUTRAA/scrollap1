.class Lcom/google/common/collect/cf;
.super Lcom/google/common/collect/la;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/cf$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/la<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
    serializable = true
.end annotation


# static fields
.field private static final j:[Lcom/google/common/collect/de$k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lcom/google/common/collect/de$k<",
            "*>;"
        }
    .end annotation
.end field

.field static final k:Lcom/google/common/collect/la;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/la<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field static final l:D = 1.0
    .annotation build Lx4/e;
    .end annotation
.end field

.field static final m:D = 0.001
    .annotation build Lx4/e;
    .end annotation
.end field

.field static final n:I = 0x9
    .annotation build Lx4/e;
    .end annotation
.end field


# instance fields
.field private final transient e:[Lcom/google/common/collect/de$k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lcom/google/common/collect/de$k<",
            "TE;>;"
        }
    .end annotation
.end field

.field private final transient f:[Lcom/google/common/collect/de$k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lcom/google/common/collect/de$k<",
            "*>;"
        }
    .end annotation
.end field

.field private final transient g:I

.field private final transient h:I

.field private transient i:Lcom/google/common/collect/qa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/qa<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation runtime Lz4/b;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    new-array v0, v0, [Lcom/google/common/collect/de$k;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object v0, Lcom/google/common/collect/cf;->j:[Lcom/google/common/collect/de$k;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/common/collect/cf;->G(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/google/common/collect/cf;->k:Lcom/google/common/collect/la;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>([Lcom/google/common/collect/de$k;[Lcom/google/common/collect/de$k;IILcom/google/common/collect/qa;)V
    .locals 2
    .param p5    # Lcom/google/common/collect/qa;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "entries",
            "hashTable",
            "size",
            "hashCode",
            "elementSet"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/common/collect/de$k<",
            "TE;>;[",
            "Lcom/google/common/collect/de$k<",
            "*>;II",
            "Lcom/google/common/collect/qa<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/la;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/collect/cf;->e:[Lcom/google/common/collect/de$k;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/common/collect/cf;->f:[Lcom/google/common/collect/de$k;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p3, p0, Lcom/google/common/collect/cf;->g:I

    const/4 v1, 0x2

    iput p4, p0, Lcom/google/common/collect/cf;->h:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p5, p0, Lcom/google/common/collect/cf;->i:Lcom/google/common/collect/qa;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static G(Ljava/util/Collection;)Lcom/google/common/collect/la;
    .locals 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "entries"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "+",
            "Lcom/google/common/collect/ae$a<",
            "+TE;>;>;)",
            "Lcom/google/common/collect/la<",
            "TE;>;"
        }
    .end annotation

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    new-array v2, v0, [Lcom/google/common/collect/de$k;

    if-nez v0, :cond_0

    new-instance p0, Lcom/google/common/collect/cf;

    sget-object v3, Lcom/google/common/collect/cf;->j:[Lcom/google/common/collect/de$k;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    invoke-direct/range {v1 .. v6}, Lcom/google/common/collect/cf;-><init>([Lcom/google/common/collect/de$k;[Lcom/google/common/collect/de$k;IILcom/google/common/collect/qa;)V

    return-object p0

    :cond_0
    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    invoke-static {v0, v3, v4}, Lcom/google/common/collect/i9;->a(ID)I

    move-result v0

    add-int/lit8 v1, v0, -0x1

    new-array v3, v0, [Lcom/google/common/collect/de$k;

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/google/common/collect/ae$a;

    invoke-interface {v8}, Lcom/google/common/collect/ae$a;->a()Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    invoke-interface {v8}, Lcom/google/common/collect/ae$a;->getCount()I

    move-result v10

    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    move-result v11

    invoke-static {v11}, Lcom/google/common/collect/i9;->c(I)I

    move-result v12

    and-int/2addr v12, v1

    aget-object v13, v3, v12

    if-nez v13, :cond_3

    instance-of v13, v8, Lcom/google/common/collect/de$k;

    if-eqz v13, :cond_1

    instance-of v13, v8, Lcom/google/common/collect/cf$a;

    if-nez v13, :cond_1

    const/4 v13, 0x1

    goto :goto_1

    :cond_1
    move v13, v0

    move v13, v0

    :goto_1
    if-eqz v13, :cond_2

    check-cast v8, Lcom/google/common/collect/de$k;

    goto :goto_2

    :cond_2
    new-instance v8, Lcom/google/common/collect/de$k;

    invoke-direct {v8, v9, v10}, Lcom/google/common/collect/de$k;-><init>(Ljava/lang/Object;I)V

    goto :goto_2

    :cond_3
    new-instance v8, Lcom/google/common/collect/cf$a;

    invoke-direct {v8, v9, v10, v13}, Lcom/google/common/collect/cf$a;-><init>(Ljava/lang/Object;ILcom/google/common/collect/de$k;)V

    :goto_2
    xor-int v9, v11, v10

    add-int/2addr v6, v9

    add-int/lit8 v9, v7, 0x1

    aput-object v8, v2, v7

    aput-object v8, v3, v12

    int-to-long v7, v10

    add-long/2addr v4, v7

    move v7, v9

    move v7, v9

    move v7, v9

    goto :goto_0

    :cond_4
    invoke-static {v3}, Lcom/google/common/collect/cf;->I([Lcom/google/common/collect/de$k;)Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {v2}, Lcom/google/common/collect/t9;->i([Ljava/lang/Object;)Lcom/google/common/collect/t9;

    move-result-object p0

    invoke-static {p0}, Lcom/google/common/collect/ec;->G(Ljava/util/Collection;)Lcom/google/common/collect/la;

    move-result-object p0

    goto :goto_3

    :cond_5
    new-instance p0, Lcom/google/common/collect/cf;

    invoke-static {v4, v5}, Lcom/google/common/primitives/f0;->z(J)I

    move-result v4

    const/4 v0, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move v5, v6

    move v5, v6

    move v5, v6

    move v5, v6

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    invoke-direct/range {v1 .. v6}, Lcom/google/common/collect/cf;-><init>([Lcom/google/common/collect/de$k;[Lcom/google/common/collect/de$k;IILcom/google/common/collect/qa;)V

    :goto_3
    return-object p0
.end method

.method private static I([Lcom/google/common/collect/de$k;)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "hashTable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/common/collect/de$k<",
            "*>;)Z"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    array-length v2, p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ge v1, v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    aget-object v2, p0, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    move v3, v0

    const/4 v7, 0x3

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v7, 0x5

    if-eqz v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    add-int/2addr v3, v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/16 v5, 0x9

    const/4 v7, 0x5

    if-le v3, v5, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    return v4

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2}, Lcom/google/common/collect/de$k;->b()Lcom/google/common/collect/de$k;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    return v0
.end method


# virtual methods
.method public I1(Ljava/lang/Object;)I
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/common/collect/cf;->f:[Lcom/google/common/collect/de$k;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    array-length v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    array-length v3, v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/lit8 v3, v3, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    and-int/2addr v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    aget-object v0, v0, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/google/common/collect/de$k;->a()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1, v2}, Lcom/google/common/base/m0;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {v0}, Lcom/google/common/collect/de$k;->getCount()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    return p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/common/collect/de$k;->b()Lcom/google/common/collect/de$k;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    return v1
.end method

.method public bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/cf;->q()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/common/collect/cf;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public q()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/google/common/collect/cf;->i:Lcom/google/common/collect/qa;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/common/collect/la$c;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/common/collect/cf;->e:[Lcom/google/common/collect/de$k;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, v1, p0}, Lcom/google/common/collect/la$c;-><init>(Ljava/util/List;Lcom/google/common/collect/ae;)V

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/cf;->i:Lcom/google/common/collect/qa;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/common/collect/cf;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method t(I)Lcom/google/common/collect/ae$a;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/common/collect/cf;->e:[Lcom/google/common/collect/de$k;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    aget-object p1, v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method
