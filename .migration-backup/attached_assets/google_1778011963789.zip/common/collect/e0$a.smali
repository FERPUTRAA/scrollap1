.class Lcom/google/common/collect/e0$a;
.super Lcom/google/common/collect/b7;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/e0;->g()Lcom/google/common/collect/lg;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/b7<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic d:Lcom/google/common/collect/e0;


# direct methods
.method constructor <init>(Lcom/google/common/collect/e0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/common/collect/e0$a;->d:Lcom/google/common/collect/e0;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/b7;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method J0()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~-s~   @ o ~   f@b@ @Ko~@~motl@  @~@i@o srv~~@l.~~/b@~1by~~fa@@@~~t~n~c@@i~Moui@@~@~ 4S o@d /~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/e0$a;->d:Lcom/google/common/collect/e0;

    invoke-virtual {v0}, Lcom/google/common/collect/e0;->i()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method K0()Lcom/google/common/collect/lg;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/lg<",
            "TE;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/e0$a;->d:Lcom/google/common/collect/e0;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/common/collect/e0$a;->d:Lcom/google/common/collect/e0;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/e0;->descendingIterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method
