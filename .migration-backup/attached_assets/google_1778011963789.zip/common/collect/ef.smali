.class final Lcom/google/common/collect/ef;
.super Lcom/google/common/collect/db;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/db<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field private static final j:[J

.field static final k:Lcom/google/common/collect/db;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/db<",
            "Ljava/lang/Comparable;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final transient f:Lcom/google/common/collect/ff;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ff<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation
.end field

.field private final transient g:[J

.field private final transient h:I

.field private final transient i:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v0, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-array v0, v0, [J

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x7

    move v5, v4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput-wide v2, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    sput-object v0, Lcom/google/common/collect/ef;->j:[J

    const/4 v5, 0x3

    const/4 v4, 0x2

    new-instance v0, Lcom/google/common/collect/ef;

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0, v1}, Lcom/google/common/collect/ef;-><init>(Ljava/util/Comparator;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    sput-object v0, Lcom/google/common/collect/ef;->k:Lcom/google/common/collect/db;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method constructor <init>(Lcom/google/common/collect/ff;[JII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "elementSet",
            "cumulativeCounts",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ff<",
            "TE;>;[JII)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/db;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p3, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p4, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method constructor <init>(Ljava/util/Comparator;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "comparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Comparator<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/common/collect/db;-><init>()V

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/common/collect/fb;->e0(Ljava/util/Comparator;)Lcom/google/common/collect/ff;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v1, 0x0

    const/4 v0, 0x4

    sget-object p1, Lcom/google/common/collect/ef;->j:[J

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v0, 0x6

    move v1, v0

    iput p1, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private B0(I)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~~si~@@l~~@y  dv  @  u o@@~@b  b @~@-@aK~@m~oM~4~i~f/ @ @~~ ~ f~@@@~ooc @~ oi~~@brl.1@t tSs@no/~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget v1, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v7, 0x2

    add-int v2, v1, p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    aget-wide v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    add-int/2addr v1, p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    aget-wide v4, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    sub-long/2addr v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    long-to-int p1, v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    return p1
.end method


# virtual methods
.method C0(II)Lcom/google/common/collect/db;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "from",
            "to"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Lcom/google/common/collect/db<",
            "TE;>;"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p1, p2, v0}, Lcom/google/common/base/u0;->f0(III)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-ne p1, p2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/db;->comparator()Ljava/util/Comparator;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/common/collect/db;->g0(Ljava/util/Comparator;)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-object p1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ne p2, v0, :cond_1

    const/4 v5, 0x2

    return-object p0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v5, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/google/common/collect/ff;->B0(II)Lcom/google/common/collect/ff;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Lcom/google/common/collect/ef;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v5, 0x7

    add-int/2addr v3, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    sub-int/2addr p2, p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v1, v0, v2, v3, p2}, Lcom/google/common/collect/ef;-><init>(Lcom/google/common/collect/ff;[JII)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object v1
.end method

.method public bridge synthetic D1(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/lg;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "upperBound",
            "boundType"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ef;->h0(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public I1(Ljava/lang/Object;)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/common/collect/ff;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-ltz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/common/collect/ef;->B0(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p1
.end method

.method public bridge synthetic T1(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/lg;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "lowerBound",
            "boundType"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ef;->y0(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic c()Ljava/util/NavigableSet;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/ef;->f0()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/ef;->f0()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic c()Ljava/util/SortedSet;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/ef;->f0()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public d0(Ljava/util/function/ObjIntConsumer;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "action"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/ObjIntConsumer<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x1

    iget v1, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/google/common/collect/fb;->a()Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/google/common/collect/ef;->B0(I)I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v1, v2}, Lcom/google/common/collect/s;->a(Ljava/util/function/ObjIntConsumer;Ljava/lang/Object;I)V

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public f0()Lcom/google/common/collect/fb;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/fb<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public firstEntry()Lcom/google/common/collect/ae$a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/common/collect/ef;->t(I)Lcom/google/common/collect/ae$a;

    move-result-object v0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method g()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-gtz v0, :cond_1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    iget-object v2, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v4, 0x3

    const/4 v3, 0x5

    array-length v2, v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    sub-int/2addr v2, v1

    const/4 v3, 0x7

    and-int/2addr v4, v3

    if-ge v0, v2, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    move v4, v1

    :cond_1
    :goto_0
    const/4 v3, 0x5

    move v4, v3

    return v1
.end method

.method public h0(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/db;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "upperBound",
            "boundType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lcom/google/common/collect/s0;",
            ")",
            "Lcom/google/common/collect/db<",
            "TE;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v1, Lcom/google/common/collect/s0;->b:Lcom/google/common/collect/s0;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ne p2, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x6

    move v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    move p2, v2

    move p2, v2

    const/4 v4, 0x0

    move p2, v2

    move p2, v2

    :goto_0
    const/4 v4, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/google/common/collect/ff;->C0(Ljava/lang/Object;Z)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, v2, p1}, Lcom/google/common/collect/ef;->C0(II)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p1
.end method

.method public lastEntry()Lcom/google/common/collect/ae$a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/common/collect/ef;->t(I)Lcom/google/common/collect/ae$a;

    move-result-object v0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    return-object v0
.end method

.method public bridge synthetic q()Lcom/google/common/collect/qa;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/ef;->f0()Lcom/google/common/collect/fb;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public size()I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/common/collect/ef;->g:[J

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/common/collect/ef;->h:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v2, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    add-int/2addr v2, v1

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    aget-wide v2, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    aget-wide v4, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    sub-long/2addr v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v2, v3}, Lcom/google/common/primitives/f0;->z(J)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    return v0
.end method

.method t(I)Lcom/google/common/collect/ae$a;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/common/collect/fb;->a()Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/ef;->B0(I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/google/common/collect/de;->k(Ljava/lang/Object;I)Lcom/google/common/collect/ae$a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method

.method public y0(Ljava/lang/Object;Lcom/google/common/collect/s0;)Lcom/google/common/collect/db;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "lowerBound",
            "boundType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lcom/google/common/collect/s0;",
            ")",
            "Lcom/google/common/collect/db<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/ef;->f:Lcom/google/common/collect/ff;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v1, Lcom/google/common/collect/s0;->b:Lcom/google/common/collect/s0;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne p2, v1, :cond_0

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x2

    move v2, p2

    move v2, p2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p2, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/google/common/collect/ff;->D0(Ljava/lang/Object;Z)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget p2, p0, Lcom/google/common/collect/ef;->i:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/ef;->C0(II)Lcom/google/common/collect/db;

    move-result-object p1

    const/4 v2, 0x2

    move v3, v2

    return-object p1
.end method
