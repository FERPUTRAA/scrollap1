.class final Lcom/google/common/collect/ac;
.super Lcom/google/common/collect/k9;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/ac$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/k9<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation


# instance fields
.field private final backwardDelegate:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TV;TK;>;"
        }
    .end annotation
.end field

.field private final transient f:Lcom/google/common/collect/t9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/t9<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field private final forwardDelegate:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private transient g:Lcom/google/common/collect/ac;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ac<",
            "TV;TK;>;"
        }
    .end annotation

    .annotation build Lf6/i;
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation runtime Lz4/b;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lcom/google/common/collect/t9;Ljava/util/Map;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "entries",
            "forwardDelegate",
            "backwardDelegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/t9<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Ljava/util/Map<",
            "TV;TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/k9;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/collect/ac;->f:Lcom/google/common/collect/t9;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/common/collect/ac;->forwardDelegate:Ljava/util/Map;

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/common/collect/ac;->backwardDelegate:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic k0(Lcom/google/common/collect/ac;)Lcom/google/common/collect/t9;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v s f@/1s~i~@y@~@@@ @  ~@t@ /om ~~~b~~ @K~~~   @~S r afilb@n@ @ @oi@oo~~~c~d @@~~@u l-4Mot~bo.@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/common/collect/ac;->f:Lcom/google/common/collect/t9;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method static l0(I[Ljava/util/Map$Entry;)Lcom/google/common/collect/k9;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "n",
            "entryArray"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(I[",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;)",
            "Lcom/google/common/collect/k9<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/google/common/collect/uc;->a0(I)Ljava/util/HashMap;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/google/common/collect/uc;->a0(I)Ljava/util/HashMap;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x0

    if-ge v2, p0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    aget-object v3, p1, v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast v3, Ljava/util/Map$Entry;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v3}, Lcom/google/common/collect/bf;->T(Ljava/util/Map$Entry;)Lcom/google/common/collect/x9;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object v3, p1, v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v0, v4, v5}, Lcom/google/common/collect/b;->a(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x4

    const-string v5, "="

    const-string v5, "="

    const/4 v8, 0x2

    if-nez v4, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1, v4, v6}, Lcom/google/common/collect/b;->a(Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-nez v4, :cond_0

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move v8, v7

    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    aget-object p1, p1, v2

    const/4 v8, 0x5

    const-string/jumbo v0, "sevml"

    const-string v0, "elsuv"

    const/4 v8, 0x5

    const-string v0, "avueo"

    const-string/jumbo v0, "value"

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/common/collect/w9;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    throw p0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    aget-object p1, p1, v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v0, "kye"

    const-string/jumbo v0, "yek"

    const/4 v8, 0x1

    const-string/jumbo v0, "key"

    const-string/jumbo v0, "key"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/common/collect/w9;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    throw p0

    :cond_2
    const/4 v8, 0x1

    invoke-static {p1, p0}, Lcom/google/common/collect/t9;->j([Ljava/lang/Object;I)Lcom/google/common/collect/t9;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance p1, Lcom/google/common/collect/ac;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p1, p0, v0, v1}, Lcom/google/common/collect/ac;-><init>(Lcom/google/common/collect/t9;Ljava/util/Map;Ljava/util/Map;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-object p1
.end method


# virtual methods
.method public T()Lcom/google/common/collect/k9;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/k9<",
            "TV;TK;>;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/common/collect/ac;->g:Lcom/google/common/collect/ac;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v0, Lcom/google/common/collect/ac;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v1, Lcom/google/common/collect/ac$b;

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1, p0, v2}, Lcom/google/common/collect/ac$b;-><init>(Lcom/google/common/collect/ac;Lcom/google/common/collect/ac$a;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/common/collect/ac;->backwardDelegate:Ljava/util/Map;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/common/collect/ac;->forwardDelegate:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0, v1, v2, v3}, Lcom/google/common/collect/ac;-><init>(Lcom/google/common/collect/t9;Ljava/util/Map;Ljava/util/Map;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/common/collect/ac;->g:Lcom/google/common/collect/ac;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-object p0, v0, Lcom/google/common/collect/ac;->g:Lcom/google/common/collect/ac;

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object v0
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/ac;->forwardDelegate:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1
.end method

.method i()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/collect/y9$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/collect/ac;->f:Lcom/google/common/collect/t9;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/y9$b;-><init>(Lcom/google/common/collect/w9;Lcom/google/common/collect/t9;)V

    const/4 v3, 0x4

    return-object v0
.end method

.method k()Lcom/google/common/collect/qa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/aa;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/aa;-><init>(Lcom/google/common/collect/w9;)V

    const/4 v2, 0x7

    return-object v0
.end method

.method s()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/ac;->f:Lcom/google/common/collect/t9;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic u0()Lcom/google/common/collect/r0;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/ac;->T()Lcom/google/common/collect/k9;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method
