.class final Lcom/google/common/collect/pa$b;
.super Lcom/google/common/collect/fb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/pa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/fb<",
        "TC;>;"
    }
.end annotation


# instance fields
.field private final domain:Lcom/google/common/collect/c7;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/c7<",
            "TC;>;"
        }
    .end annotation
.end field

.field private transient k:Ljava/lang/Integer;
    .annotation runtime Lv7/a;
    .end annotation
.end field

.field final synthetic this$0:Lcom/google/common/collect/pa;


# direct methods
.method constructor <init>(Lcom/google/common/collect/pa;Lcom/google/common/collect/c7;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            "this$0",
            "domain"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/c7<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/common/collect/fb;-><init>(Ljava/util/Comparator;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic B0(Lcom/google/common/collect/pa$b;)Lcom/google/common/collect/c7;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "mfs u /~bKf@~@o~ M/~~@~~b@~@ @lbo~-o @ l~i@s~ @d@@v. @@r@y~ n@o~ 4@@t1~@~~~@ao  oc~    ~@S ti~~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v1, 0x6

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/InvalidObjectException;
        }
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, " szmrFeUalosereSmi"

    const-string v0, "ersr iamlsioeUzFSe"

    const-string v0, "iaosomledrzSie eFr"

    const-string v0, "Use SerializedForm"

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw p1
.end method


# virtual methods
.method C0(Ljava/lang/Comparable;Z)Lcom/google/common/collect/fb;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "toElement",
            "inclusive"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;Z)",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/google/common/collect/s0;->b(Z)Lcom/google/common/collect/s0;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lcom/google/common/collect/re;->I(Ljava/lang/Comparable;Lcom/google/common/collect/s0;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa$b;->D0(Lcom/google/common/collect/re;)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method D0(Lcom/google/common/collect/re;)Lcom/google/common/collect/fb;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/common/collect/pa;->I(Lcom/google/common/collect/re;)Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/common/collect/pa;->w(Lcom/google/common/collect/c7;)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1
.end method

.method E0(Ljava/lang/Comparable;ZLjava/lang/Comparable;Z)Lcom/google/common/collect/fb;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "fromElement",
            "fromInclusive",
            "toElement",
            "toInclusive"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;ZTC;Z)",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez p4, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1, p3}, Lcom/google/common/collect/re;->h(Ljava/lang/Comparable;Ljava/lang/Comparable;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/collect/fb;->j0()Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2}, Lcom/google/common/collect/s0;->b(Z)Lcom/google/common/collect/s0;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p4}, Lcom/google/common/collect/s0;->b(Z)Lcom/google/common/collect/s0;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, p2, p3, p4}, Lcom/google/common/collect/re;->C(Ljava/lang/Comparable;Lcom/google/common/collect/s0;Ljava/lang/Comparable;Lcom/google/common/collect/s0;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa$b;->D0(Lcom/google/common/collect/re;)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method F0(Ljava/lang/Comparable;Z)Lcom/google/common/collect/fb;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fromElement",
            "inclusive"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;Z)",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/google/common/collect/s0;->b(Z)Lcom/google/common/collect/s0;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/common/collect/re;->l(Ljava/lang/Comparable;Lcom/google/common/collect/s0;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa$b;->D0(Lcom/google/common/collect/re;)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method a0()Lcom/google/common/collect/fb;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/a7;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/common/collect/a7;-><init>(Lcom/google/common/collect/fb;)V

    const/4 v2, 0x3

    return-object v0
.end method

.method public b0()Lcom/google/common/collect/am;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "TC;>;"
        }
    .end annotation

    .annotation build Lx4/c;
        value = "NavigableSet"
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/pa$b$b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/common/collect/pa$b$b;-><init>(Lcom/google/common/collect/pa$b;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v0

    :cond_0
    :try_start_0
    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Comparable;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Lcom/google/common/collect/pa;->a(Ljava/lang/Comparable;)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p1

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v0
.end method

.method public bridge synthetic descendingIterator()Ljava/util/Iterator;
    .locals 3
    .annotation build Lx4/c;
        value = "NavigableSet"
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/pa$b;->b0()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/n9;->g()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public h()Lcom/google/common/collect/am;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/pa$b$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/collect/pa$b$a;-><init>(Lcom/google/common/collect/pa$b;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method bridge synthetic h0(Ljava/lang/Object;Z)Lcom/google/common/collect/fb;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "toElement",
            "inclusive"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Comparable;

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/pa$b;->C0(Ljava/lang/Comparable;Z)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method indexOf(Ljava/lang/Object;)I
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa$b;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast p1, Ljava/lang/Comparable;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/google/common/collect/t9;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x4

    const-wide/16 v1, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    check-cast v3, Lcom/google/common/collect/re;

    const/4 v6, 0x7

    invoke-virtual {v3, p1}, Lcom/google/common/collect/re;->i(Ljava/lang/Comparable;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v4, :cond_0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v3, v0}, Lcom/google/common/collect/v6;->F0(Lcom/google/common/collect/re;Lcom/google/common/collect/c7;)Lcom/google/common/collect/v6;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Lcom/google/common/collect/fb;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    int-to-long v3, p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-long/2addr v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lcom/google/common/primitives/f0;->z(J)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    return p1

    :cond_0
    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lcom/google/common/collect/v6;->F0(Lcom/google/common/collect/re;Lcom/google/common/collect/c7;)Lcom/google/common/collect/v6;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    int-to-long v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-long/2addr v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/AssertionError;

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v0, "isbmibmple"

    const-string/jumbo v0, "mpimsesilb"

    const/4 v6, 0x1

    const-string/jumbo v0, "mpbsliueoi"

    const-string/jumbo v0, "impossible"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {p1, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    throw p1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 p1, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    return p1
.end method

.method public bridge synthetic iterator()Ljava/util/Iterator;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/pa$b;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public size()I
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->k:Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/t9;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v3, Lcom/google/common/collect/re;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lcom/google/common/collect/v6;->F0(Lcom/google/common/collect/re;Lcom/google/common/collect/c7;)Lcom/google/common/collect/v6;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/util/AbstractCollection;->size()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    int-to-long v3, v3

    const/4 v6, 0x6

    add-long/2addr v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-wide/32 v3, 0x7fffffff

    const-wide/32 v3, 0x7fffffff

    const/4 v6, 0x3

    const-wide/32 v3, 0x7fffffff

    const-wide/32 v3, 0x7fffffff

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    cmp-long v3, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ltz v3, :cond_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v1, v2}, Lcom/google/common/primitives/f0;->z(J)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/google/common/collect/pa$b;->k:Ljava/lang/Integer;

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method bridge synthetic u0(Ljava/lang/Object;ZLjava/lang/Object;Z)Lcom/google/common/collect/fb;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "fromElement",
            "fromInclusive",
            "toElement",
            "toInclusive"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/Comparable;

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p3, Ljava/lang/Comparable;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/common/collect/pa$b;->E0(Ljava/lang/Comparable;ZLjava/lang/Comparable;Z)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method writeReplace()Ljava/lang/Object;
    .locals 5
    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Lcom/google/common/collect/pa$c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/common/collect/pa$b;->domain:Lcom/google/common/collect/c7;

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/common/collect/pa$c;-><init>(Lcom/google/common/collect/t9;Lcom/google/common/collect/c7;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method bridge synthetic x0(Ljava/lang/Object;Z)Lcom/google/common/collect/fb;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "fromElement",
            "inclusive"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Comparable;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/pa$b;->F0(Ljava/lang/Comparable;Z)Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method
