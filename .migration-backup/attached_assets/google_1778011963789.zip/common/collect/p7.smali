.class final Lcom/google/common/collect/p7;
.super Lcom/google/common/collect/q7;

# interfaces
.implements Lcom/google/common/collect/mc;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/q7<",
        "TK;TV;>;",
        "Lcom/google/common/collect/mc<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method constructor <init>(Lcom/google/common/collect/mc;Lcom/google/common/base/w0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "unfiltered",
            "keyPredicate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/mc<",
            "TK;TV;>;",
            "Lcom/google/common/base/w0<",
            "-TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/q7;-><init>(Lcom/google/common/collect/pd;Lcom/google/common/base/w0;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s  /~@vo ~~ i ~~t~s~b~S@r @bf~@/@ c@~ @@~-~n @ o~~d@~KaMof ~4@~o.@@u~ioy@  b tl ~~~l@oi@@ 1@ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Lcom/google/common/collect/p7;->a(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public a(Ljava/lang/Object;)Ljava/util/List;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/common/collect/q7;->a(Ljava/lang/Object;)Ljava/util/Collection;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p1, Ljava/util/List;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/p7;->b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/List;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Ljava/lang/Iterable<",
            "+TV;>;)",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/Collection;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p1, Ljava/util/List;

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic g()Lcom/google/common/collect/pd;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/p7;->p()Lcom/google/common/collect/mc;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/collect/p7;->get(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public get(Ljava/lang/Object;)Ljava/util/List;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-super {p0, p1}, Lcom/google/common/collect/q7;->get(Ljava/lang/Object;)Ljava/util/Collection;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    check-cast p1, Ljava/util/List;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public p()Lcom/google/common/collect/mc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/mc<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-super {p0}, Lcom/google/common/collect/q7;->g()Lcom/google/common/collect/pd;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/common/collect/mc;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
