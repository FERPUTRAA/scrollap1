.class Lcom/google/common/collect/q$c$a;
.super Lcom/google/common/collect/uc$s;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/q$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/uc$s<",
        "TK;",
        "Ljava/util/Collection<",
        "TV;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/collect/q$c;


# direct methods
.method constructor <init>(Lcom/google/common/collect/q$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$1"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/uc$s;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~@b rf ~i.o~y@mK~~b-i  ~~@~@@@u~M~@t @f  btos  @@@av  c~@@~l4o~1~~~ o@/~@ ~nSlo@ ~@ @@@i  do/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, v0, Lcom/google/common/collect/q$c;->d:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lcom/google/common/collect/s5;->i(Ljava/util/Collection;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p1
.end method

.method f()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/collect/q$c$b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lcom/google/common/collect/q$c$b;-><init>(Lcom/google/common/collect/q$c;)V

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/q$c$a;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p1, Ljava/util/Map$Entry;

    iget-object v0, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, v0, Lcom/google/common/collect/q$c;->e:Lcom/google/common/collect/q;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/google/common/collect/q;->B(Lcom/google/common/collect/q;Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p1
.end method

.method public spliterator()Ljava/util/Spliterator;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "Ljava/util/Map$Entry<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, v0, Lcom/google/common/collect/q$c;->d:Ljava/util/Map;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/common/collect/j;->a(Ljava/util/Set;)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/q$c$a;->a:Lcom/google/common/collect/q$c;

    const/4 v4, 0x5

    new-instance v2, Lcom/google/common/collect/r;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v2, v1}, Lcom/google/common/collect/r;-><init>(Lcom/google/common/collect/q$c;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v2}, Lcom/google/common/collect/p4;->h(Ljava/util/Spliterator;Ljava/util/function/Function;)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v0
.end method
