.class final Lcom/google/common/collect/df;
.super Lcom/google/common/collect/qa$b;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/qa$b<",
        "TE;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
    serializable = true
.end annotation


# static fields
.field private static final l:[Ljava/lang/Object;

.field static final m:Lcom/google/common/collect/df;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/df<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final transient h:[Ljava/lang/Object;

.field private final transient i:I

.field final transient j:[Ljava/lang/Object;
    .annotation build Lx4/e;
    .end annotation
.end field

.field private final transient k:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    sput-object v1, Lcom/google/common/collect/df;->l:[Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    new-instance v2, Lcom/google/common/collect/df;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v2, v1, v0, v1, v0}, Lcom/google/common/collect/df;-><init>([Ljava/lang/Object;I[Ljava/lang/Object;I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    sput-object v2, Lcom/google/common/collect/df;->m:Lcom/google/common/collect/df;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method constructor <init>([Ljava/lang/Object;I[Ljava/lang/Object;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "elements",
            "hashCode",
            "table",
            "mask"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/qa$b;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/common/collect/df;->i:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/google/common/collect/df;->j:[Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p4, p0, Lcom/google/common/collect/df;->k:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method E()Lcom/google/common/collect/t9;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/t9<",
            "TE;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "Sos@@@l@@ .@~bfd t-@t~c ~~@ @ K~f@o~o~ @ by~b@v i~@i o /~@~@~u l4s~@ ~@~@~ o r ~n~oaMi@~ ~/@~m 1"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/df;->j:[Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    array-length v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Lcom/google/common/collect/xe;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/xe;-><init>(Lcom/google/common/collect/n9;[Ljava/lang/Object;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method b([Ljava/lang/Object;I)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "dst",
            "offset"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    array-length v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1, p1, p2, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    array-length p1, p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    add-int/2addr p2, p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return p2
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/common/collect/df;->j:[Ljava/lang/Object;

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    const/4 v1, 0x0

    shl-int/2addr v5, v1

    const/4 v4, 0x5

    move v5, v4

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    move v5, v4

    array-length v2, v0

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v2, :cond_0

    const/4 v5, 0x7

    goto :goto_1

    :cond_0
    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/common/collect/i9;->d(Ljava/lang/Object;)I

    move-result v2

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v3, p0, Lcom/google/common/collect/df;->k:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    and-int/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    aget-object v3, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v3, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v3, :cond_2

    const/4 v5, 0x1

    const/4 p1, 0x3

    const/4 v5, 0x0

    const/4 p1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    return p1

    :cond_2
    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v1
.end method

.method d()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method

.method e()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    array-length v0, v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method f()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return v0
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public h()Lcom/google/common/collect/am;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/am<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/common/collect/yb;->B([Ljava/lang/Object;)Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/common/collect/df;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic iterator()Ljava/util/Iterator;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/df;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    array-length v0, v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public spliterator()Ljava/util/Spliterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/df;->h:[Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v1, 0x511

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/google/common/collect/y5;->a([Ljava/lang/Object;I)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method

.method t()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    return v0
.end method
