.class abstract Lcom/google/common/collect/hf;
.super Lcom/google/common/collect/hb;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/hf$c;,
        Lcom/google/common/collect/hf$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/hb<",
        "TR;TC;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/hb;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method

.method public static synthetic M(Ljava/util/Comparator;Ljava/util/Comparator;Lcom/google/common/collect/bl$a;Lcom/google/common/collect/bl$a;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f@s~ ~ @ ~~.r~   @da@@@~c@~@@ ob/ -~@ @ fin~@ ito~/@l~ @ ~4@~1~ @ymv~o@t@o~K~ Mb~uo@~~ lobi@~~S "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-static {p0, p1, p2, p3}, Lcom/google/common/collect/hf;->W(Ljava/util/Comparator;Ljava/util/Comparator;Lcom/google/common/collect/bl$a;Lcom/google/common/collect/bl$a;)I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method static O(Ljava/lang/Iterable;)Lcom/google/common/collect/hf;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "cells"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;)",
            "Lcom/google/common/collect/hf<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0, v0, v0}, Lcom/google/common/collect/hf;->Q(Ljava/lang/Iterable;Ljava/util/Comparator;Ljava/util/Comparator;)Lcom/google/common/collect/hf;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method static P(Ljava/util/List;Ljava/util/Comparator;Ljava/util/Comparator;)Lcom/google/common/collect/hf;
    .locals 3
    .param p1    # Ljava/util/Comparator;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/util/Comparator;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "cells",
            "rowComparator",
            "columnComparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;",
            "Ljava/util/Comparator<",
            "-TR;>;",
            "Ljava/util/Comparator<",
            "-TC;>;)",
            "Lcom/google/common/collect/hf<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    move v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz p2, :cond_1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/gf;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p1, p2}, Lcom/google/common/collect/gf;-><init>(Ljava/util/Comparator;Ljava/util/Comparator;)V

    invoke-static {p0, v0}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lcom/google/common/collect/hf;->Q(Ljava/lang/Iterable;Ljava/util/Comparator;Ljava/util/Comparator;)Lcom/google/common/collect/hf;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method private static Q(Ljava/lang/Iterable;Ljava/util/Comparator;Ljava/util/Comparator;)Lcom/google/common/collect/hf;
    .locals 7
    .param p1    # Ljava/util/Comparator;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/util/Comparator;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "cells",
            "rowComparator",
            "columnComparator"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;",
            "Ljava/util/Comparator<",
            "-TR;>;",
            "Ljava/util/Comparator<",
            "-TC;>;)",
            "Lcom/google/common/collect/hf<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v6, 0x6

    new-instance v1, Ljava/util/LinkedHashSet;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/google/common/collect/t9;->n(Ljava/lang/Iterable;)Lcom/google/common/collect/t9;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v3, Lcom/google/common/collect/bl$a;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v3}, Lcom/google/common/collect/bl$a;->a()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v0, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-interface {v3}, Lcom/google/common/collect/bl$a;->b()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez p1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/common/collect/qa;->o(Ljava/util/Collection;)Lcom/google/common/collect/qa;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1, v0}, Lcom/google/common/collect/t9;->O(Ljava/util/Comparator;Ljava/lang/Iterable;)Lcom/google/common/collect/t9;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/google/common/collect/qa;->o(Ljava/util/Collection;)Lcom/google/common/collect/qa;

    move-result-object p0

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    if-nez p2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/google/common/collect/qa;->o(Ljava/util/Collection;)Lcom/google/common/collect/qa;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_2

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p2, v1}, Lcom/google/common/collect/t9;->O(Ljava/util/Comparator;Ljava/lang/Iterable;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/common/collect/qa;->o(Ljava/util/Collection;)Lcom/google/common/collect/qa;

    move-result-object p1

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v2, p0, p1}, Lcom/google/common/collect/hf;->R(Lcom/google/common/collect/t9;Lcom/google/common/collect/qa;Lcom/google/common/collect/qa;)Lcom/google/common/collect/hf;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p0
.end method

.method static R(Lcom/google/common/collect/t9;Lcom/google/common/collect/qa;Lcom/google/common/collect/qa;)Lcom/google/common/collect/hf;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "cellList",
            "rowSpace",
            "columnSpace"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            "C:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/collect/t9<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;",
            "Lcom/google/common/collect/qa<",
            "TR;>;",
            "Lcom/google/common/collect/qa<",
            "TC;>;)",
            "Lcom/google/common/collect/hf<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    int-to-long v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/util/AbstractCollection;->size()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    int-to-long v4, v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    mul-long/2addr v2, v4

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-wide/16 v4, 0x2

    const-wide/16 v4, 0x2

    const/4 v7, 0x7

    const-wide/16 v4, 0x2

    const-wide/16 v4, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x6

    div-long/2addr v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    cmp-long v0, v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    if-lez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v0, Lcom/google/common/collect/y6;

    const/4 v7, 0x5

    invoke-direct {v0, p0, p1, p2}, Lcom/google/common/collect/y6;-><init>(Lcom/google/common/collect/t9;Lcom/google/common/collect/qa;Lcom/google/common/collect/qa;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v0, Lcom/google/common/collect/rg;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {v0, p0, p1, p2}, Lcom/google/common/collect/rg;-><init>(Lcom/google/common/collect/t9;Lcom/google/common/collect/qa;Lcom/google/common/collect/qa;)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-object v0
.end method

.method private static synthetic W(Ljava/util/Comparator;Ljava/util/Comparator;Lcom/google/common/collect/bl$a;Lcom/google/common/collect/bl$a;)I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    move p0, v0

    move p0, v0

    const/4 v4, 0x7

    move p0, v0

    move p0, v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p2}, Lcom/google/common/collect/bl$a;->a()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-interface {p3}, Lcom/google/common/collect/bl$a;->a()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p0, v1, v2}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v4, 0x5

    return p0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p2}, Lcom/google/common/collect/bl$a;->b()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p3}, Lcom/google/common/collect/bl$a;->b()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p1, p0, p2}, Ljava/util/Comparator;->compare(Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v0

    :goto_1
    const/4 v3, 0x0

    move v4, v3

    return v0
.end method


# virtual methods
.method final N(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 9
    .param p3    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rowKey",
            "columnKey",
            "existingValue",
            "newValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;TC;TV;TV;)V"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x2

    if-nez p3, :cond_0

    const/4 v7, 0x5

    move v8, v7

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string v2, "%lmmc ,, e[= si,slk%(eotslwsy] ev p% Du=ruuca:ans):o."

    const-string v2, " ,su%py sno==r%li aa[s,),vko  t(cuDee:we]l css.l:um%s"

    const/4 v8, 0x0

    const-string v2, " w%,opaekueme:)%s  s=a D%.t:l]lusy,ocr %s v(n=o[ci,lu"

    const-string v2, "Duplicate key: (row=%s, column=%s), values: [%s, %s]."

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static/range {v1 .. v6}, Lcom/google/common/base/u0;->A(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void
.end method

.method abstract S(I)Lcom/google/common/collect/bl$a;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "iterationIndex"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;"
        }
    .end annotation
.end method

.method abstract V(I)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "iterationIndex"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TV;"
        }
    .end annotation
.end method

.method bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/hf;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method bridge synthetic d()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/hf;->w()Lcom/google/common/collect/n9;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method final u()Lcom/google/common/collect/qa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/bl$a<",
            "TR;TC;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->isEmpty()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Lcom/google/common/collect/hf$b;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x0

    xor-int/2addr v3, v1

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/hf$b;-><init>(Lcom/google/common/collect/hf;Lcom/google/common/collect/hf$a;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method final w()Lcom/google/common/collect/n9;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/n9<",
            "TV;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/hb;->isEmpty()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/hf$c;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/hf$c;-><init>(Lcom/google/common/collect/hf;Lcom/google/common/collect/hf$a;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method
