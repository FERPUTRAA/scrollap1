.class public final Lcom/google/common/collect/j7;
.super Lcom/google/common/collect/y;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/j7$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Enum<",
        "TE;>;>",
        "Lcom/google/common/collect/y<",
        "TE;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field private static final serialVersionUID:J
    .annotation build Lx4/c;
    .end annotation
.end field


# instance fields
.field private transient c:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "TE;>;"
        }
    .end annotation
.end field

.field private transient d:[Ljava/lang/Enum;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TE;"
        }
    .end annotation
.end field

.field private transient e:[I

.field private transient f:I

.field private transient g:J


# direct methods
.method private constructor <init>(Ljava/lang/Class;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/common/collect/y;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/common/collect/j7;->c:Ljava/lang/Class;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->isEnum()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p1, [Ljava/lang/Enum;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/common/collect/j7;->d:[Ljava/lang/Enum;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    array-length p1, p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-array p1, p1, [I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic g(Lcom/google/common/collect/j7;)[Ljava/lang/Enum;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s i@~@~n@@d~s~br~l Mt @@ @ f@~4@ub@aScio~@~ ~@~~@- ~y1m~@f.o@~v~@~i o ~b  @/~ @o @~ @ /t o l~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/common/collect/j7;->d:[Ljava/lang/Enum;

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic h(Lcom/google/common/collect/j7;)[I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    iget-object p0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic i(Lcom/google/common/collect/j7;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    add-int/lit8 v1, v0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0
.end method

.method static synthetic j(Lcom/google/common/collect/j7;J)J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sub-long/2addr v0, p1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-wide v0
.end method

.method private l(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/j7;->p(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/ClassCastException;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v2, "saemE exdtcp"

    const-string v2, "e sexdct paE"

    const/4 v4, 0x7

    const-string v2, "E naoc etpex"

    const-string v2, "Expected an "

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/common/collect/j7;->c:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v2, "gout btbm"

    const-string v2, "b  mttguo"

    const/4 v4, 0x3

    const-string/jumbo v2, "o g utu b"

    const-string v2, " but got "

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, p1}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    throw v0
.end method

.method public static m(Ljava/lang/Class;)Lcom/google/common/collect/j7;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Enum<",
            "TE;>;>(",
            "Ljava/lang/Class<",
            "TE;>;)",
            "Lcom/google/common/collect/j7<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/j7;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/collect/j7;-><init>(Ljava/lang/Class;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public static n(Ljava/lang/Iterable;)Lcom/google/common/collect/j7;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "elements"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Enum<",
            "TE;>;>(",
            "Ljava/lang/Iterable<",
            "TE;>;)",
            "Lcom/google/common/collect/j7<",
            "TE;>;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, " itemcupsot EpnorytmtltsoMuartps eudbe erInasl"

    const-string v2, "eureotl bpsnpeodamusunetsrmalcMrcs tE t toItyi"

    const/4 v4, 0x5

    const-string v2, "Mtbcyrr qli uecEmItnatu tdrosnausmtoeeeltsps e"

    const-string v2, "EnumMultiset constructor passed empty Iterable"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/google/common/base/u0;->e(ZLjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v1, Lcom/google/common/collect/j7;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v0, Ljava/lang/Enum;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Enum;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v1, v0}, Lcom/google/common/collect/j7;-><init>(Ljava/lang/Class;)V

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, p0}, Lcom/google/common/collect/rb;->a(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v1
.end method

.method public static o(Ljava/lang/Iterable;Ljava/lang/Class;)Lcom/google/common/collect/j7;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "elements",
            "type"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Enum<",
            "TE;>;>(",
            "Ljava/lang/Iterable<",
            "TE;>;",
            "Ljava/lang/Class<",
            "TE;>;)",
            "Lcom/google/common/collect/j7<",
            "TE;>;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/common/collect/j7;->m(Ljava/lang/Class;)Lcom/google/common/collect/j7;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1, p0}, Lcom/google/common/collect/rb;->a(Ljava/util/Collection;Ljava/lang/Iterable;)Z

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-object p1
.end method

.method private p(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    instance-of v0, p1, Ljava/lang/Enum;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast p1, Ljava/lang/Enum;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/common/collect/j7;->d:[Ljava/lang/Enum;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    array-length v3, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ge v0, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    aget-object v0, v2, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ne v0, p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v1, 0x1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    return v1
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/Class;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/common/collect/j7;->c:Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, [Ljava/lang/Enum;

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/collect/j7;->d:[Ljava/lang/Enum;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    array-length v0, v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-array v0, v0, [I

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lcom/google/common/collect/mf;->f(Lcom/google/common/collect/ae;Ljava/io/ObjectInputStream;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/collect/j7;->c:Ljava/lang/Class;

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/common/collect/mf;->k(Lcom/google/common/collect/ae;Ljava/io/ObjectOutputStream;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic H(Ljava/lang/Object;I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "element",
            "count"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Enum;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/j7;->q(Ljava/lang/Enum;I)I

    move-result p1

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p1
.end method

.method public I1(Ljava/lang/Object;)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/j7;->p(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/Enum;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v1, 0x0

    or-int/2addr v2, v1

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    aget p1, v0, p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method public S0(Ljava/lang/Object;I)I
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/common/collect/j7;->p(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto/16 :goto_1

    :cond_0
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast v1, Ljava/lang/Enum;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v2, "cosrnuccber"

    const-string/jumbo v2, "onrecbucsrc"

    const/4 v4, 0x4

    const-string v2, "ercmnucoscr"

    const-string/jumbo v2, "occurrences"

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p2, v2}, Lcom/google/common/collect/e4;->b(ILjava/lang/String;)I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Lcom/google/common/collect/j7;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return p1

    :cond_1
    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    aget v2, v1, p1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-gt v2, p2, :cond_3

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    aput v0, v1, p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v3, 0x0

    move v4, v3

    iget-wide p1, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    int-to-long v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    sub-long/2addr p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-wide p1, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    sub-int v0, v2, p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    aput v0, v1, p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-wide v0, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    int-to-long p1, p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    sub-long/2addr v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/google/common/collect/j7;->g:J

    :goto_0
    const/4 v3, 0x7

    move v4, v3

    return v2

    :cond_4
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return v0
.end method

.method public bridge synthetic a1(Ljava/lang/Object;I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    check-cast p1, Ljava/lang/Enum;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/j7;->k(Ljava/lang/Enum;I)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p1
.end method

.method public bridge synthetic c()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-super {p0}, Lcom/google/common/collect/y;->c()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public clear()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-wide v2, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void
.end method

.method public bridge synthetic contains(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/common/collect/y;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1
.end method

.method d()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public d0(Ljava/util/function/ObjIntConsumer;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "action"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/function/ObjIntConsumer<",
            "-TE;>;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/common/collect/j7;->d:[Ljava/lang/Enum;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    array-length v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ge v0, v2, :cond_1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    aget v2, v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-lez v2, :cond_0

    const/4 v3, 0x3

    move v4, v3

    aget-object v1, v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1, v1, v2}, Lcom/google/common/collect/s;->a(Ljava/util/function/ObjIntConsumer;Ljava/lang/Object;I)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method e()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/collect/j7$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/j7$a;-><init>(Lcom/google/common/collect/j7;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic entrySet()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/collect/y;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method f()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/j7$b;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/common/collect/j7$b;-><init>(Lcom/google/common/collect/j7;)V

    const/4 v1, 0x1

    or-int/2addr v2, v1

    return-object v0
.end method

.method public bridge synthetic isEmpty()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/common/collect/y;->isEmpty()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    return v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/google/common/collect/de;->n(Lcom/google/common/collect/ae;)Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public k(Ljava/lang/Enum;I)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "occurrences"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;I)I"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/j7;->l(Ljava/lang/Object;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v0, "ceueosrccnr"

    const-string/jumbo v0, "urseccurcen"

    const/4 v8, 0x1

    const-string/jumbo v0, "succobnrecr"

    const-string/jumbo v0, "occurrences"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p2, v0}, Lcom/google/common/collect/e4;->b(ILjava/lang/String;)I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-nez p2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/j7;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    return p1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    aget v0, v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    int-to-long v1, v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    int-to-long v3, p2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-long/2addr v1, v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-wide/32 v5, 0x7fffffff

    const-wide/32 v5, 0x7fffffff

    const/4 v8, 0x3

    const-wide/32 v5, 0x7fffffff

    const-wide/32 v5, 0x7fffffff

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    cmp-long p2, v1, v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v5, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-gtz p2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    move p2, v5

    move p2, v5

    const/4 v8, 0x6

    move p2, v5

    move p2, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 p2, 0x0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v6, "eyos tun rsmuon%ar:ecc o"

    const-string/jumbo v6, "too many occurrences: %s"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p2, v6, v1, v2}, Lcom/google/common/base/u0;->p(ZLjava/lang/String;J)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object p2, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    long-to-int v1, v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    aput v1, p2, p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-nez v0, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    add-int/2addr p1, v5

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput p1, p0, Lcom/google/common/collect/j7;->f:I

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-wide p1, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-long/2addr p1, v3

    const/4 v8, 0x0

    const/4 v7, 0x7

    iput-wide p1, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v7, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    return v0
.end method

.method public q(Ljava/lang/Enum;I)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "element",
            "count"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;I)I"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/collect/j7;->l(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v0, "ocptu"

    const-string/jumbo v0, "ouptc"

    const/4 v7, 0x1

    const-string/jumbo v0, "nouqt"

    const-string v0, "count"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p2, v0}, Lcom/google/common/collect/e4;->b(ILjava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/common/collect/j7;->e:[I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    aget v1, v0, p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    aput p2, v0, p1

    iget-wide v2, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    sub-int p1, p2, v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    int-to-long v4, p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-long/2addr v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-wide v2, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-lez p2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    iget p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v7, 0x1

    iput p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-lez v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez p2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget p1, p0, Lcom/google/common/collect/j7;->f:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput p1, p0, Lcom/google/common/collect/j7;->f:I

    :cond_1
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    return v1
.end method

.method public bridge synthetic q1(Ljava/lang/Object;II)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x1000
        }
        names = {
            "element",
            "oldCount",
            "newCount"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3}, Lcom/google/common/collect/y;->q1(Ljava/lang/Object;II)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    return p1
.end method

.method public size()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/common/collect/j7;->g:J

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/common/primitives/f0;->z(J)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v0
.end method
