.class public Lcom/google/common/collect/p8$b;
.super Lcom/google/common/collect/uc$e0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/p8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/uc$e0<",
        "TK;TV;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lcom/google/common/collect/p8;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/uc$e0;-><init>(Ljava/util/NavigableMap;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method
