.class public abstract Lcom/google/common/collect/k8$a;
.super Lcom/google/common/collect/uc$s;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/k8;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x404
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/uc$s<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/collect/k8;


# direct methods
.method protected constructor <init>(Lcom/google/common/collect/k8;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/k8$a;->a:Lcom/google/common/collect/k8;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/uc$s;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method f()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~is~~~l~@/b~~~of~K~~o@~@~  ~@ @ ~dSa4~o ~@bu@@@vfl~ @iyn@-@~o~i@ @@c r  M@  m@o t1 ~@@/ o@~s  t."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/k8$a;->a:Lcom/google/common/collect/k8;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method
