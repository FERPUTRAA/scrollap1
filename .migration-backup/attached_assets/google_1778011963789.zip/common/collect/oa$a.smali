.class Lcom/google/common/collect/oa$a;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/oa;->t(Lcom/google/common/collect/re;)Lcom/google/common/collect/oa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t9<",
        "Lcom/google/common/collect/re<",
        "TK;>;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/google/common/collect/oa;

.field final synthetic val$len:I

.field final synthetic val$off:I

.field final synthetic val$range:Lcom/google/common/collect/re;


# direct methods
.method constructor <init>(Lcom/google/common/collect/oa;IILcom/google/common/collect/re;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "this$0",
            "val$len",
            "val$off",
            "val$range"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/common/collect/oa$a;->this$0:Lcom/google/common/collect/oa;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/common/collect/oa$a;->val$len:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p3, p0, Lcom/google/common/collect/oa$a;->val$off:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    iput-object p4, p0, Lcom/google/common/collect/oa$a;->val$range:Lcom/google/common/collect/re;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public S(I)Lcom/google/common/collect/re;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/re<",
            "TK;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/common/collect/oa$a;->val$len:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->C(II)I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/common/collect/oa$a;->val$len:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/common/collect/oa$a;->this$0:Lcom/google/common/collect/oa;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/common/collect/oa;->a(Lcom/google/common/collect/oa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/common/collect/oa$a;->val$off:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-int/2addr p1, v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p1, Lcom/google/common/collect/re;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/oa$a;->this$0:Lcom/google/common/collect/oa;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/common/collect/oa;->a(Lcom/google/common/collect/oa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    iget v1, p0, Lcom/google/common/collect/oa$a;->val$off:I

    add-int/2addr p1, v1

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast p1, Lcom/google/common/collect/re;

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/google/common/collect/oa$a;->val$range:Lcom/google/common/collect/re;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/common/collect/re;->t(Lcom/google/common/collect/re;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/collect/oa$a;->S(I)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/common/collect/oa$a;->val$len:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method
