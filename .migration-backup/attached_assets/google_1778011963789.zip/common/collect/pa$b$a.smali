.class Lcom/google/common/collect/pa$b$a;
.super Lcom/google/common/collect/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/pa$b;->h()Lcom/google/common/collect/am;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/e<",
        "TC;>;"
    }
.end annotation


# instance fields
.field final c:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;"
        }
    .end annotation
.end field

.field d:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "TC;>;"
        }
    .end annotation
.end field

.field final synthetic e:Lcom/google/common/collect/pa$b;


# direct methods
.method constructor <init>(Lcom/google/common/collect/pa$b;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$1"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/collect/pa$b$a;->e:Lcom/google/common/collect/pa$b;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/e;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p1, p1, Lcom/google/common/collect/pa$b;->this$0:Lcom/google/common/collect/pa;

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/common/collect/t9;->h()Lcom/google/common/collect/am;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/pa$b$a;->c:Ljava/util/Iterator;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/common/collect/yb;->u()Lcom/google/common/collect/am;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/pa$b$a;->d:Ljava/util/Iterator;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected bridge synthetic a()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@m   @-o@o ~~dt b yi @uto 4@~o@/MfSllK~. @@~~~@~o@ ~~f@n/~~~b ~ @~1@v@o~rbs~@ ci a@i@~@@ ~~~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/pa$b$a;->d()Ljava/lang/Comparable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method protected d()Ljava/lang/Comparable;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TC;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/pa$b$a;->d:Ljava/util/Iterator;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/common/collect/pa$b$a;->c:Ljava/util/Iterator;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/pa$b$a;->c:Ljava/util/Iterator;

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa$b$a;->e:Lcom/google/common/collect/pa$b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/google/common/collect/pa$b;->B0(Lcom/google/common/collect/pa$b;)Lcom/google/common/collect/c7;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/common/collect/v6;->F0(Lcom/google/common/collect/re;Lcom/google/common/collect/c7;)Lcom/google/common/collect/v6;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/common/collect/fb;->h()Lcom/google/common/collect/am;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/common/collect/pa$b$a;->d:Ljava/util/Iterator;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/e;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/Comparable;

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/pa$b$a;->d:Ljava/util/Iterator;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/Comparable;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method
