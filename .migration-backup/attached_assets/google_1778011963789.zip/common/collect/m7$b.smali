.class Lcom/google/common/collect/m7$b;
.super Lcom/google/common/collect/sd$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/m7;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/sd$g<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field final synthetic d:Lcom/google/common/collect/m7;


# direct methods
.method constructor <init>(Lcom/google/common/collect/m7;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/collect/m7$b;->d:Lcom/google/common/collect/m7;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/sd$g;-><init>(Lcom/google/common/collect/pd;)V

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public S0(Ljava/lang/Object;I)I
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "occurrences"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@us~~~~~c o~  ~bti i@~ t@~i~@y~~ @ lro~@@o~m Ksa-@ ~~~n  /b@f@.o~@ l1 SM~bv@   @4@~oo@@@df/~@~ @"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    const-string v0, "ceemcnsoruc"

    const-string/jumbo v0, "occurrences"

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-static {p2, v0}, Lcom/google/common/collect/e4;->b(ILjava/lang/String;)I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez p2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/google/common/collect/sd$g;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    return p1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/common/collect/m7$b;->d:Lcom/google/common/collect/m7;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, v0, Lcom/google/common/collect/m7;->f:Lcom/google/common/collect/pd;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/pd;->d()Ljava/util/Map;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast v0, Ljava/util/Collection;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    iget-object v3, p0, Lcom/google/common/collect/m7$b;->d:Lcom/google/common/collect/m7;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v3, p1, v2}, Lcom/google/common/collect/m7;->o(Lcom/google/common/collect/m7;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-gt v1, p2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v1
.end method

.method public entrySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Lcom/google/common/collect/ae$a<",
            "TK;>;>;"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/m7$b$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/m7$b$a;-><init>(Lcom/google/common/collect/m7$b;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method
