.class final Lcom/google/common/collect/nc$k;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/nc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t9<",
        "Ljava/lang/Character;",
        ">;"
    }
.end annotation


# instance fields
.field private final string:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "string"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public P(II)Lcom/google/common/collect/t9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fromIndex",
            "toIndex"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Lcom/google/common/collect/t9<",
            "Ljava/lang/Character;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/common/collect/nc$k;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1, p2, v0}, Lcom/google/common/base/u0;->f0(III)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/common/collect/nc;->g(Ljava/lang/String;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1
.end method

.method public S(I)Ljava/lang/Character;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/nc$k;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->C(II)I

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/nc$k;->S(I)Ljava/lang/Character;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public indexOf(Ljava/lang/Object;)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    instance-of v0, p1, Ljava/lang/Character;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p1, Ljava/lang/Character;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/String;->indexOf(I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method public lastIndexOf(Ljava/lang/Object;)I
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    instance-of v0, p1, Ljava/lang/Character;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v2, 0x6

    check-cast p1, Ljava/lang/Character;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/nc$k;->string:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic subList(II)Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "fromIndex",
            "toIndex"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/nc$k;->P(II)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method
