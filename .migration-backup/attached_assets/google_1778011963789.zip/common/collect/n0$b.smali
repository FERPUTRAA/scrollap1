.class Lcom/google/common/collect/n0$b;
.super Lcom/google/common/collect/pl$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/n0;->C(I)Lcom/google/common/collect/bl$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/pl$b<",
        "TR;TC;TV;>;"
    }
.end annotation


# instance fields
.field final a:I

.field final b:I

.field final synthetic c:I

.field final synthetic d:Lcom/google/common/collect/n0;


# direct methods
.method constructor <init>(Lcom/google/common/collect/n0;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$index"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/common/collect/n0$b;->d:Lcom/google/common/collect/n0;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p2, p0, Lcom/google/common/collect/n0$b;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/common/collect/pl$b;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/common/collect/n0;->l(Lcom/google/common/collect/n0;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    div-int v0, p2, v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/common/collect/n0$b;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/common/collect/n0;->l(Lcom/google/common/collect/n0;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    rem-int/2addr p2, p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p2, p0, Lcom/google/common/collect/n0$b;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TR;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s@/@c~io -bfi  ~o ~@~@bo@~ @ 1y@~S~r~@K @u sb~@@ ~~ i. ~@@~ ~o ~@am~lof~@@~d @n o~t/@~t@ M 4l~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/n0$b;->d:Lcom/google/common/collect/n0;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/common/collect/n0;->m(Lcom/google/common/collect/n0;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/common/collect/n0$b;->a:I

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method public b()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TC;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/n0$b;->d:Lcom/google/common/collect/n0;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/common/collect/n0;->l(Lcom/google/common/collect/n0;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/common/collect/n0$b;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method public getValue()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/collect/n0$b;->d:Lcom/google/common/collect/n0;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/common/collect/n0$b;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/common/collect/n0$b;->b:I

    invoke-virtual {v0, v1, v2}, Lcom/google/common/collect/n0;->t(II)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0
.end method
