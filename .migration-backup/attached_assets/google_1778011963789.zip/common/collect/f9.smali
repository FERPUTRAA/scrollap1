.class public final Lcom/google/common/collect/f9;
.super Lcom/google/common/collect/g9;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/g9<",
        "TK;TV;>;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
    serializable = true
.end annotation


# static fields
.field private static final i:I = 0x2

.field private static final serialVersionUID:J
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field


# instance fields
.field transient h:I
    .annotation build Lx4/e;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v0, 0xc

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, v0, v1}, Lcom/google/common/collect/f9;-><init>(II)V

    const/4 v3, 0x7

    return-void
.end method

.method private constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "expectedKeys",
            "expectedValuesPerKey"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/common/collect/pe;->f(I)Ljava/util/Map;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/g9;-><init>(Ljava/util/Map;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/common/collect/f9;->h:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-ltz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 p1, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p2, p0, Lcom/google/common/collect/f9;->h:I

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>(Lcom/google/common/collect/pd;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/pd<",
            "+TK;+TV;>;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/pd;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/common/collect/pe;->f(I)Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, v0}, Lcom/google/common/collect/g9;-><init>(Ljava/util/Map;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/common/collect/f9;->h:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/common/collect/f9;->x(Lcom/google/common/collect/pd;)Z

    const/4 v2, 0x4

    return-void
.end method

.method public static a0()Lcom/google/common/collect/f9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/f9<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o sr@i~4~ybS  tn- @fo i  @@~ f~1~/v@/ @@@~~  ~@o@ilm~~~tMl~~~@u@~~  @.~~~o@s@b  b~c ~ @oKa~@@o@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/f9;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/collect/f9;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public static b0(II)Lcom/google/common/collect/f9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "expectedKeys",
            "expectedValuesPerKey"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(II)",
            "Lcom/google/common/collect/f9<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/f9;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/f9;-><init>(II)V

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public static c0(Lcom/google/common/collect/pd;)Lcom/google/common/collect/f9;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/collect/pd<",
            "+TK;+TV;>;)",
            "Lcom/google/common/collect/f9<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/collect/f9;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/collect/f9;-><init>(Lcom/google/common/collect/pd;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/common/collect/f9;->h:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/common/collect/mf;->h(Ljava/io/ObjectInputStream;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0xc

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/common/collect/pe;->f(I)Ljava/util/Map;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/google/common/collect/q;->T(Ljava/util/Map;)V

    const/4 v3, 0x6

    invoke-static {p0, p1, v0}, Lcom/google/common/collect/mf;->e(Lcom/google/common/collect/pd;Ljava/io/ObjectInputStream;I)V

    const/4 v3, 0x3

    return-void
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/common/collect/mf;->j(Lcom/google/common/collect/pd;Ljava/io/ObjectOutputStream;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic C(Ljava/lang/Object;Ljava/lang/Iterable;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->C(Ljava/lang/Object;Ljava/lang/Iterable;)Z

    move-result p1

    const/4 v1, 0x7

    return p1
.end method

.method bridge synthetic F()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/f9;->X()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method X()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/common/collect/f9;->h:I

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/common/collect/pe;->g(I)Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic Z(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->Z(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic a(Ljava/lang/Object;)Ljava/util/Set;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/common/collect/c0;->a(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/Set;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/c0;->b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic clear()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0}, Lcom/google/common/collect/q;->clear()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic containsKey(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/common/collect/q;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p1
.end method

.method public bridge synthetic containsValue(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/google/common/collect/x;->containsValue(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public bridge synthetic d()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/common/collect/c0;->d()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic e()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/common/collect/c0;->e()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/common/collect/c0;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    return p1
.end method

.method public bridge synthetic forEach(Ljava/util/function/BiConsumer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "action"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/collect/q;->forEach(Ljava/util/function/BiConsumer;)V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/util/Set;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/collect/c0;->get(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/common/collect/x;->hashCode()I

    move-result v0

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic isEmpty()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/collect/x;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic keySet()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/common/collect/x;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic keys()Lcom/google/common/collect/ae;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-super {p0}, Lcom/google/common/collect/x;->keys()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic put(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/c0;->put(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method public bridge synthetic size()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/common/collect/q;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/common/collect/x;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic values()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/google/common/collect/q;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic x(Lcom/google/common/collect/pd;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/common/collect/x;->x(Lcom/google/common/collect/pd;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method
