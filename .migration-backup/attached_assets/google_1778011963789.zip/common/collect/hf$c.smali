.class final Lcom/google/common/collect/hf$c;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/hf;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t9<",
        "TV;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/google/common/collect/hf;


# direct methods
.method private constructor <init>(Lcom/google/common/collect/hf;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/common/collect/hf$c;->this$0:Lcom/google/common/collect/hf;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/common/collect/hf;Lcom/google/common/collect/hf$a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/common/collect/hf$c;-><init>(Lcom/google/common/collect/hf;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method g()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~st~oo@/f~@@@~~1K@/@l i~@b@  l@s@~~~  @i4 ar~m o @btc@@id o~~  @@~ ~ o@~~o~~~yu@ @~f .-~bn@Mv~S"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public get(I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TV;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/hf$c;->this$0:Lcom/google/common/collect/hf;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/common/collect/hf;->V(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/collect/hf$c;->this$0:Lcom/google/common/collect/hf;

    invoke-interface {v0}, Lcom/google/common/collect/bl;->size()I

    move-result v0

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method
