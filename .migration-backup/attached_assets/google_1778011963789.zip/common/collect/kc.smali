.class public Lcom/google/common/collect/kc;
.super Lcom/google/common/collect/x;

# interfaces
.implements Lcom/google/common/collect/mc;
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/kc$i;,
        Lcom/google/common/collect/kc$e;,
        Lcom/google/common/collect/kc$h;,
        Lcom/google/common/collect/kc$f;,
        Lcom/google/common/collect/kc$g;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/x<",
        "TK;TV;>;",
        "Lcom/google/common/collect/mc<",
        "TK;TV;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/b;
    emulated = true
    serializable = true
.end annotation


# static fields
.field private static final serialVersionUID:J
    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation
.end field


# instance fields
.field private transient f:Lcom/google/common/collect/kc$g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/kc$g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient g:Lcom/google/common/collect/kc$g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/kc$g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation
.end field

.field private transient h:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TK;",
            "Lcom/google/common/collect/kc$f<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field private transient i:I

.field private transient j:I


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0xc

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/common/collect/kc;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedKeys"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/collect/x;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/common/collect/pe;->f(I)Ljava/util/Map;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method private constructor <init>(Lcom/google/common/collect/pd;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/pd<",
            "+TK;+TV;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/google/common/collect/pd;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/common/collect/kc;-><init>(I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/kc;->x(Lcom/google/common/collect/pd;)Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static A()Lcom/google/common/collect/kc;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/kc<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ".@s ~m@~~@of ~y@~ @@~ tbbi nor1a @ii   So ~@fl @~~~d~ ~M@~~b@~K @~-~tv/ o@ ol@@c~o4 u@@@~~@~~ @s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/kc;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/common/collect/kc;-><init>()V

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static B(I)Lcom/google/common/collect/kc;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedKeys"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(I)",
            "Lcom/google/common/collect/kc<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/kc;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/kc;-><init>(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public static E(Lcom/google/common/collect/pd;)Lcom/google/common/collect/kc;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/common/collect/pd<",
            "+TK;+TV;>;)",
            "Lcom/google/common/collect/kc<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/kc;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/common/collect/kc;-><init>(Lcom/google/common/collect/pd;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method private I(Ljava/lang/Object;)Ljava/util/List;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/kc$i;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/kc$i;-><init>(Lcom/google/common/collect/kc;Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/common/collect/nc;->s(Ljava/util/Iterator;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method

.method private K(Ljava/lang/Object;)V
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/kc$i;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/kc$i;-><init>(Lcom/google/common/collect/kc;Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/common/collect/yb;->h(Ljava/util/Iterator;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method private L(Lcom/google/common/collect/kc$g;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "node"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/kc$g<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p1, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object v1, v0, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v3, 0x3

    move v4, v3

    iput-object v1, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    :goto_0
    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v0, v1, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    :goto_1
    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p1, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    iget-object v0, p1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    if-nez v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p1, Lcom/google/common/collect/kc$g;->a:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast p1, Lcom/google/common/collect/kc$f;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    shl-int/2addr v4, v0

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput v0, p1, Lcom/google/common/collect/kc$f;->c:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_3

    :cond_2
    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->a:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast v0, Lcom/google/common/collect/kc$f;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v1, v0, Lcom/google/common/collect/kc$f;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput v1, v0, Lcom/google/common/collect/kc$f;->c:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v1, :cond_3

    const/4 v4, 0x5

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v1, v0, Lcom/google/common/collect/kc$f;->a:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_2

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v2, p1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v2, v1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v1, :cond_4

    const/4 v3, 0x4

    move v4, v3

    iget-object p1, p1, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p1, v0, Lcom/google/common/collect/kc$f;->b:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_3

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p1, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object p1, v1, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    :goto_3
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget p1, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method

.method static synthetic o(Lcom/google/common/collect/kc;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p0, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic p(Lcom/google/common/collect/kc;)Lcom/google/common/collect/kc$g;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-object p0
.end method

.method static synthetic q(Lcom/google/common/collect/kc;)Lcom/google/common/collect/kc$g;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->defaultReadObject()V

    const/4 v4, 0x0

    or-int/2addr v5, v4

    invoke-static {}, Lcom/google/common/collect/uc;->c0()Ljava/util/LinkedHashMap;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readInt()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ge v1, v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v2, v3}, Lcom/google/common/collect/kc;->put(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method static synthetic s(Lcom/google/common/collect/kc;Lcom/google/common/collect/kc$g;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/kc;->L(Lcom/google/common/collect/kc$g;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic t(Lcom/google/common/collect/kc;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/kc;->K(Ljava/lang/Object;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method static synthetic u(Lcom/google/common/collect/kc;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic v(Lcom/google/common/collect/kc;Ljava/lang/Object;Ljava/lang/Object;Lcom/google/common/collect/kc$g;)Lcom/google/common/collect/kc$g;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/common/collect/kc;->y(Ljava/lang/Object;Ljava/lang/Object;Lcom/google/common/collect/kc$g;)Lcom/google/common/collect/kc$g;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic w(Lcom/google/common/collect/kc;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p0, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method

.method private writeObject(Ljava/io/ObjectOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/io/ObjectOutputStream;->defaultWriteObject()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Ljava/io/ObjectOutputStream;->writeInt(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->H()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v2}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, v1}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method private y(Ljava/lang/Object;Ljava/lang/Object;Lcom/google/common/collect/kc$g;)Lcom/google/common/collect/kc$g;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p3    # Lcom/google/common/collect/kc$g;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "value",
            "nextSibling"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;",
            "Lcom/google/common/collect/kc$g<",
            "TK;TV;>;)",
            "Lcom/google/common/collect/kc$g<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/kc$g;

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2}, Lcom/google/common/collect/kc$g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p3, Lcom/google/common/collect/kc$f;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p3, v0}, Lcom/google/common/collect/kc$f;-><init>(Lcom/google/common/collect/kc$g;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto/16 :goto_2

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p3, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v0, p2, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p2, v0, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p2, Lcom/google/common/collect/kc$f;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p3, Lcom/google/common/collect/kc$f;

    const/4 v2, 0x1

    invoke-direct {p3, v0}, Lcom/google/common/collect/kc$f;-><init>(Lcom/google/common/collect/kc$g;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget p1, p2, Lcom/google/common/collect/kc$f;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput p1, p2, Lcom/google/common/collect/kc$f;->c:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p2, Lcom/google/common/collect/kc$f;->b:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p1, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, v0, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p2, Lcom/google/common/collect/kc$f;->b:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_2

    :cond_2
    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p1, Lcom/google/common/collect/kc$f;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    move v2, v1

    iget p2, p1, Lcom/google/common/collect/kc$f;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    add-int/lit8 p2, p2, 0x1

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    iput p2, p1, Lcom/google/common/collect/kc$f;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object p2, p3, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p2, v0, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p2, p3, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p2, v0, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x3

    const/4 v1, 0x5

    iput-object p3, v0, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p3, v0, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p2, p3, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez p2, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p1, Lcom/google/common/collect/kc$f;->a:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p2, Lcom/google/common/collect/kc$g;->e:Lcom/google/common/collect/kc$g;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p3, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_1

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p1, Lcom/google/common/collect/kc$g;->c:Lcom/google/common/collect/kc$g;

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p3, Lcom/google/common/collect/kc$g;->d:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p3, Lcom/google/common/collect/kc$g;->f:Lcom/google/common/collect/kc$g;

    :goto_2
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget p1, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public bridge synthetic C(Ljava/lang/Object;Ljava/lang/Iterable;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->C(Ljava/lang/Object;Ljava/lang/Iterable;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method

.method F()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/collect/kc$b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/kc$b;-><init>(Lcom/google/common/collect/kc;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method G()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/collect/kc$d;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/collect/kc$d;-><init>(Lcom/google/common/collect/kc;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public H()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/common/collect/x;->e()Ljava/util/Collection;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast v0, Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public M()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/common/collect/x;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast v0, Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic Z(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->Z(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic a(Ljava/lang/Object;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "key"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/collect/kc;->a(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p1
.end method

.method public a(Ljava/lang/Object;)Ljava/util/List;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/common/collect/kc;->I(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/collect/kc;->K(Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/common/collect/kc;->b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p1
.end method

.method public b(Ljava/lang/Object;Ljava/lang/Iterable;)Ljava/util/List;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "values"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Ljava/lang/Iterable<",
            "+TV;>;)",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lcom/google/common/collect/kc;->I(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v1, Lcom/google/common/collect/kc$i;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1}, Lcom/google/common/collect/kc$i;-><init>(Lcom/google/common/collect/kc;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v1}, Ljava/util/ListIterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v1}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v1, p2}, Ljava/util/ListIterator;->set(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-interface {v1}, Ljava/util/ListIterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v1}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v1}, Ljava/util/ListIterator;->remove()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    :goto_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v1, p2}, Ljava/util/ListIterator;->add(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_2

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method c()Ljava/util/Map;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/sd$a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/common/collect/sd$a;-><init>(Lcom/google/common/collect/pd;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/common/collect/kc;->g:Lcom/google/common/collect/kc$g;

    const/4 v2, 0x6

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/common/collect/kc;->j:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public containsKey(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/common/collect/kc;->h:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p1
.end method

.method public containsValue(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->M()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic d()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/common/collect/x;->d()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic e()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->H()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/common/collect/x;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method bridge synthetic f()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->F()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/util/Collection;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/common/collect/kc;->get(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public get(Ljava/lang/Object;)Ljava/util/List;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "key"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)",
            "Ljava/util/List<",
            "TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/collect/kc$a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/kc$a;-><init>(Lcom/google/common/collect/kc;Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method h()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Lcom/google/common/collect/kc$c;

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/google/common/collect/kc$c;-><init>(Lcom/google/common/collect/kc;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic hashCode()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/google/common/collect/x;->hashCode()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method i()Lcom/google/common/collect/ae;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/ae<",
            "TK;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Lcom/google/common/collect/sd$g;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/collect/sd$g;-><init>(Lcom/google/common/collect/pd;)V

    const/4 v1, 0x3

    const/4 v1, 0x7

    return-object v0
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/kc;->f:Lcom/google/common/collect/kc$g;

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method bridge synthetic j()Ljava/util/Collection;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->G()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method k()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x7

    const-string v1, "bvdmeloern csl sue eld"

    const-string v1, "d sbsrl vaclldeeuo ene"

    const/4 v3, 0x3

    const-string/jumbo v1, "nuesovar ellcd deebo h"

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw v0
.end method

.method public bridge synthetic keySet()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/common/collect/x;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic keys()Lcom/google/common/collect/ae;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/common/collect/x;->keys()Lcom/google/common/collect/ae;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public put(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lcom/google/common/collect/me;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)Z"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, v0}, Lcom/google/common/collect/kc;->y(Ljava/lang/Object;Ljava/lang/Object;Lcom/google/common/collect/kc$g;)Lcom/google/common/collect/kc$g;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x6

    move v2, v1

    return p1
.end method

.method public bridge synthetic remove(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "key",
            "value"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-super {p0, p1, p2}, Lcom/google/common/collect/x;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/common/collect/kc;->i:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public bridge synthetic toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/common/collect/x;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic values()Ljava/util/Collection;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0}, Lcom/google/common/collect/kc;->M()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic x(Lcom/google/common/collect/pd;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "multimap"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/common/collect/x;->x(Lcom/google/common/collect/pd;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p1
.end method
