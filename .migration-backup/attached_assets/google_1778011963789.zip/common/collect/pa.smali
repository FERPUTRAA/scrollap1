.class public final Lcom/google/common/collect/pa;
.super Lcom/google/common/collect/a0;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/common/collect/pa$f;,
        Lcom/google/common/collect/pa$d;,
        Lcom/google/common/collect/pa$c;,
        Lcom/google/common/collect/pa$b;,
        Lcom/google/common/collect/pa$e;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<C::",
        "Ljava/lang/Comparable;",
        ">",
        "Lcom/google/common/collect/a0<",
        "TC;>;",
        "Ljava/io/Serializable;"
    }
.end annotation

.annotation build Lx4/c;
.end annotation


# static fields
.field private static final c:Lcom/google/common/collect/pa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/pa<",
            "Ljava/lang/Comparable<",
            "*>;>;"
        }
    .end annotation
.end field

.field private static final d:Lcom/google/common/collect/pa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/pa<",
            "Ljava/lang/Comparable<",
            "*>;>;"
        }
    .end annotation
.end field


# instance fields
.field private final transient a:Lcom/google/common/collect/t9;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/t9<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;"
        }
    .end annotation
.end field

.field private transient b:Lcom/google/common/collect/pa;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    .annotation runtime Lz4/b;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/pa;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    sput-object v0, Lcom/google/common/collect/pa;->c:Lcom/google/common/collect/pa;

    const/4 v3, 0x1

    new-instance v0, Lcom/google/common/collect/pa;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/collect/re;->a()Lcom/google/common/collect/re;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/google/common/collect/t9;->w(Ljava/lang/Object;)Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v0, Lcom/google/common/collect/pa;->d:Lcom/google/common/collect/pa;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method constructor <init>(Lcom/google/common/collect/t9;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ranges"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/t9<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/a0;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>(Lcom/google/common/collect/t9;Lcom/google/common/collect/pa;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "ranges",
            "complement"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/t9<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;",
            "Lcom/google/common/collect/pa<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/common/collect/a0;-><init>()V

    const/4 v0, 0x2

    xor-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/common/collect/pa;->b:Lcom/google/common/collect/pa;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static A(Ljava/lang/Iterable;)Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ranges"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable<",
            "*>;>(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/pa$d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/collect/pa$d;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lcom/google/common/collect/pa$d;->c(Ljava/lang/Iterable;)Lcom/google/common/collect/pa$d;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/pa$d;->d()Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method private C(Lcom/google/common/collect/re;)Lcom/google/common/collect/t9;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)",
            "Lcom/google/common/collect/t9<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    if-nez v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p1}, Lcom/google/common/collect/re;->v()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto/16 :goto_2

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->c()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Lcom/google/common/collect/re;->n(Lcom/google/common/collect/re;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-object p1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p1}, Lcom/google/common/collect/re;->q()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {}, Lcom/google/common/collect/re;->K()Lcom/google/common/base/s;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, p1, Lcom/google/common/collect/re;->lowerBound:Lcom/google/common/collect/x6;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v3, Lcom/google/common/collect/hg$c;->d:Lcom/google/common/collect/hg$c;

    const/4 v7, 0x1

    sget-object v4, Lcom/google/common/collect/hg$b;->b:Lcom/google/common/collect/hg$b;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0, v1, v2, v3, v4}, Lcom/google/common/collect/hg;->a(Ljava/util/List;Lcom/google/common/base/s;Ljava/lang/Comparable;Lcom/google/common/collect/hg$c;Lcom/google/common/collect/hg$b;)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/common/collect/re;->s()Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {}, Lcom/google/common/collect/re;->x()Lcom/google/common/base/s;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v3, p1, Lcom/google/common/collect/re;->upperBound:Lcom/google/common/collect/x6;

    const/4 v7, 0x1

    const/4 v6, 0x0

    sget-object v4, Lcom/google/common/collect/hg$c;->c:Lcom/google/common/collect/hg$c;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v5, Lcom/google/common/collect/hg$b;->b:Lcom/google/common/collect/hg$b;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v2, v3, v4, v5}, Lcom/google/common/collect/hg;->a(Ljava/util/List;Lcom/google/common/base/s;Ljava/lang/Comparable;Lcom/google/common/collect/hg$c;Lcom/google/common/collect/hg$b;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :cond_3
    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    sub-int/2addr v1, v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-nez v1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-object p1

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v2, Lcom/google/common/collect/pa$a;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v2, p0, v1, v0, p1}, Lcom/google/common/collect/pa$a;-><init>(Lcom/google/common/collect/pa;IILcom/google/common/collect/re;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-object v2

    :cond_5
    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/common/collect/t9;->u()Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-object p1
.end method

.method public static G()Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable;",
            ">()",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/common/collect/pa;->c:Lcom/google/common/collect/pa;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static H(Lcom/google/common/collect/re;)Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable;",
            ">(",
            "Lcom/google/common/collect/re<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/google/common/collect/re;->v()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/collect/pa;->G()Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/common/collect/re;->a()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/common/collect/re;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/collect/pa;->t()Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    new-instance v0, Lcom/google/common/collect/pa;

    const/4 v1, 0x1

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/common/collect/t9;->w(Ljava/lang/Object;)Lcom/google/common/collect/t9;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public static K()Ljava/util/stream/Collector;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "Ljava/lang/Comparable<",
            "-TE;>;>()",
            "Ljava/util/stream/Collector<",
            "Lcom/google/common/collect/re<",
            "TE;>;*",
            "Lcom/google/common/collect/pa<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/collect/c4;->t0()Ljava/util/stream/Collector;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static M(Ljava/lang/Iterable;)Lcom/google/common/collect/pa;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ranges"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable<",
            "*>;>(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/common/collect/yl;->v(Ljava/lang/Iterable;)Lcom/google/common/collect/yl;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/common/collect/pa;->z(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "stream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/InvalidObjectException;
        }
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "rdsleUseersa ioFzS"

    const-string v0, "ees laoUrSzsrmdeiF"

    const/4 v2, 0x5

    const-string/jumbo v0, "lrzmUFeeaeoS msidi"

    const-string v0, "Use SerializedForm"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    throw p1
.end method

.method static synthetic s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-object p0
.end method

.method static t()Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable;",
            ">()",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    sget-object v0, Lcom/google/common/collect/pa;->d:Lcom/google/common/collect/pa;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public static x()Lcom/google/common/collect/pa$d;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable<",
            "*>;>()",
            "Lcom/google/common/collect/pa$d<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lcom/google/common/collect/pa$d;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/common/collect/pa$d;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public static z(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "rangeSet"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Ljava/lang/Comparable;",
            ">(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    invoke-interface {p0}, Lcom/google/common/collect/ve;->isEmpty()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/common/collect/pa;->G()Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/common/collect/re;->a()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p0, v0}, Lcom/google/common/collect/ve;->l(Lcom/google/common/collect/re;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/pa;->t()Lcom/google/common/collect/pa;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    instance-of v0, p0, Lcom/google/common/collect/pa;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Lcom/google/common/collect/pa;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/pa;->F()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/collect/pa;

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-interface {p0}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/collect/t9;->o(Ljava/util/Collection;)Lcom/google/common/collect/t9;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method


# virtual methods
.method public B(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/common/collect/yl;->u(Lcom/google/common/collect/ve;)Lcom/google/common/collect/yl;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/google/common/collect/ve;->q(Lcom/google/common/collect/ve;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-static {v0}, Lcom/google/common/collect/pa;->z(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p1
.end method

.method public E(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/common/collect/yl;->u(Lcom/google/common/collect/ve;)Lcom/google/common/collect/yl;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/ve;->e()Lcom/google/common/collect/ve;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/google/common/collect/ve;->q(Lcom/google/common/collect/ve;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/common/collect/pa;->z(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method F()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/common/collect/n9;->g()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    return v0
.end method

.method public I(Lcom/google/common/collect/re;)Lcom/google/common/collect/pa;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->isEmpty()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->c()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/common/collect/re;->n(Lcom/google/common/collect/re;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Lcom/google/common/collect/re;->u(Lcom/google/common/collect/re;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lcom/google/common/collect/pa;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/google/common/collect/pa;->C(Lcom/google/common/collect/re;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, p1}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/common/collect/pa;->G()Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p1
.end method

.method public L(Lcom/google/common/collect/ve;)Lcom/google/common/collect/pa;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->v()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p1}, Lcom/google/common/collect/ve;->p()Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/google/common/collect/rb;->f(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/lang/Iterable;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/common/collect/pa;->M(Ljava/lang/Iterable;)Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1
.end method

.method public bridge synthetic a(Ljava/lang/Comparable;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/collect/a0;->a(Ljava/lang/Comparable;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p1
.end method

.method public b(Lcom/google/common/collect/re;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    throw p1
.end method

.method public c()Lcom/google/common/collect/re;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/re<",
            "TC;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, v0, Lcom/google/common/collect/re;->lowerBound:Lcom/google/common/collect/x6;

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int/lit8 v2, v2, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast v1, Lcom/google/common/collect/re;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, v1, Lcom/google/common/collect/re;->upperBound:Lcom/google/common/collect/x6;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/common/collect/re;->k(Lcom/google/common/collect/x6;Lcom/google/common/collect/x6;)Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v4, 0x1

    throw v0
.end method

.method public bridge synthetic clear()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-super {p0}, Lcom/google/common/collect/a0;->clear()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public d(Lcom/google/common/collect/re;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "range"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v0, 0x7

    move v1, v0

    throw p1
.end method

.method public bridge synthetic e()Lcom/google/common/collect/ve;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->y()Lcom/google/common/collect/pa;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/common/collect/a0;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method public f(Lcom/google/common/collect/re;)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "otherRange"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)Z"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Lcom/google/common/collect/re;->x()Lcom/google/common/base/s;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p1, Lcom/google/common/collect/re;->lowerBound:Lcom/google/common/collect/x6;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v4, Lcom/google/common/collect/hg$c;->a:Lcom/google/common/collect/hg$c;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    sget-object v5, Lcom/google/common/collect/hg$b;->b:Lcom/google/common/collect/hg$b;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/google/common/collect/hg;->b(Ljava/util/List;Lcom/google/common/base/s;Ljava/lang/Object;Ljava/util/Comparator;Lcom/google/common/collect/hg$c;Lcom/google/common/collect/hg$b;)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-ge v0, v1, :cond_0

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    check-cast v1, Lcom/google/common/collect/re;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1, p1}, Lcom/google/common/collect/re;->u(Lcom/google/common/collect/re;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v1, :cond_0

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    check-cast v1, Lcom/google/common/collect/re;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v1, p1}, Lcom/google/common/collect/re;->t(Lcom/google/common/collect/re;)Lcom/google/common/collect/re;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1}, Lcom/google/common/collect/re;->v()Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-nez v1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    return v2

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    if-lez v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    sub-int/2addr v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v1, Lcom/google/common/collect/re;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, p1}, Lcom/google/common/collect/re;->u(Lcom/google/common/collect/re;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/collect/re;->t(Lcom/google/common/collect/re;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/google/common/collect/re;->v()Z

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-nez p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    return v2
.end method

.method public g(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    throw p1
.end method

.method public h(Lcom/google/common/collect/ve;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    throw p1
.end method

.method public i(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public bridge synthetic j(Lcom/google/common/collect/ve;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/common/collect/a0;->j(Lcom/google/common/collect/ve;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method

.method public k(Ljava/lang/Comparable;)Lcom/google/common/collect/re;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TC;)",
            "Lcom/google/common/collect/re<",
            "TC;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {}, Lcom/google/common/collect/re;->x()Lcom/google/common/base/s;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p1}, Lcom/google/common/collect/x6;->d(Ljava/lang/Comparable;)Lcom/google/common/collect/x6;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget-object v4, Lcom/google/common/collect/hg$c;->a:Lcom/google/common/collect/hg$c;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v5, Lcom/google/common/collect/hg$b;->a:Lcom/google/common/collect/hg$b;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lcom/google/common/collect/hg;->b(Ljava/util/List;Lcom/google/common/base/s;Ljava/lang/Object;Ljava/util/Comparator;Lcom/google/common/collect/hg$c;Lcom/google/common/collect/hg$b;)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v1, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq v0, v1, :cond_0

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/collect/re;->i(Ljava/lang/Comparable;)Z

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz p1, :cond_0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v2
.end method

.method public l(Lcom/google/common/collect/re;)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "otherRange"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/re<",
            "TC;>;)Z"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Lcom/google/common/collect/re;->x()Lcom/google/common/base/s;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v2, p1, Lcom/google/common/collect/re;->lowerBound:Lcom/google/common/collect/x6;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Lcom/google/common/collect/le;->A()Lcom/google/common/collect/le;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-object v4, Lcom/google/common/collect/hg$c;->a:Lcom/google/common/collect/hg$c;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget-object v5, Lcom/google/common/collect/hg$b;->a:Lcom/google/common/collect/hg$b;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/common/collect/hg;->b(Ljava/util/List;Lcom/google/common/base/s;Ljava/lang/Object;Ljava/util/Comparator;Lcom/google/common/collect/hg$c;Lcom/google/common/collect/hg$b;)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v1, -0x1

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eq v0, v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Lcom/google/common/collect/re;->n(Lcom/google/common/collect/re;)Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 p1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    return p1
.end method

.method public bridge synthetic n(Lcom/google/common/collect/re;)Lcom/google/common/collect/ve;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "range"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa;->I(Lcom/google/common/collect/re;)Lcom/google/common/collect/pa;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p1
.end method

.method public bridge synthetic o()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic p()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->v()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public q(Lcom/google/common/collect/ve;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/ve<",
            "TC;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/e;
        value = "Always throws UnsupportedOperationException"
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    throw p1
.end method

.method public u()Lcom/google/common/collect/qa;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/google/common/collect/ff;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1}, Lcom/google/common/collect/t9;->L()Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/collect/re;->E()Lcom/google/common/collect/le;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Lcom/google/common/collect/le;->G()Lcom/google/common/collect/le;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/google/common/collect/ff;-><init>(Lcom/google/common/collect/t9;Ljava/util/Comparator;)V

    const/4 v3, 0x5

    move v4, v3

    return-object v0
.end method

.method public v()Lcom/google/common/collect/qa;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/qa<",
            "Lcom/google/common/collect/re<",
            "TC;>;>;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/common/collect/qa;->u()Lcom/google/common/collect/qa;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lcom/google/common/collect/ff;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/common/collect/re;->E()Lcom/google/common/collect/le;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Lcom/google/common/collect/ff;-><init>(Lcom/google/common/collect/t9;Ljava/util/Comparator;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public w(Lcom/google/common/collect/c7;)Lcom/google/common/collect/fb;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "domain"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/c7<",
            "TC;>;)",
            "Lcom/google/common/collect/fb<",
            "TC;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/common/base/u0;->E(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->isEmpty()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/common/collect/fb;->j0()Lcom/google/common/collect/fb;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pa;->c()Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/google/common/collect/re;->e(Lcom/google/common/collect/c7;)Lcom/google/common/collect/re;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/re;->q()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/common/collect/re;->s()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_1

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/common/collect/c7;->e()Ljava/lang/Comparable;
    :try_end_0
    .catch Ljava/util/NoSuchElementException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, " nreoea eisobebhiroonihdNisanmd rust Dathtem   eoacreg  rettevn"

    const-string/jumbo v0, "oirms o rrecuN evntee dara Dehoe enrnhab ttii hsisedgntbm aoeet"

    const/4 v3, 0x4

    const-string/jumbo v0, "sveegbt hsa nnabnta  tiN eedr hreoeDdDor beitoerrioc eietusahmn"

    const-string v0, "Neither the DiscreteDomain nor this range set are bounded above"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    move v3, v2

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Lcom/google/common/collect/pa$b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/pa$b;-><init>(Lcom/google/common/collect/pa;Lcom/google/common/collect/c7;)V

    const/4 v2, 0x1

    move v3, v2

    return-object v0

    :cond_2
    const/4 v3, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "tbnoa usD ogbtou wmhnteear t o eseeesDhie dNr i hnctrieerdaonie"

    const-string/jumbo v0, "it aoe enes thDNnhodie h enoe bn ieriet ttbrDrrssdeaocr muewgoa"

    const/4 v3, 0x4

    const-string v0, " ett depNao hen g odounin horne rertmebearelbate ssDiitiDeh rcs"

    const-string v0, "Neither the DiscreteDomain nor this range set are bounded below"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    throw p1
.end method

.method writeReplace()Ljava/lang/Object;
    .locals 4
    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Lcom/google/common/collect/pa$f;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/common/collect/pa$f;-><init>(Lcom/google/common/collect/t9;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public y()Lcom/google/common/collect/pa;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/pa<",
            "TC;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/pa;->b:Lcom/google/common/collect/pa;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/common/collect/pa;->t()Lcom/google/common/collect/pa;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/common/collect/pa;->b:Lcom/google/common/collect/pa;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v0, v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/common/collect/pa;->a:Lcom/google/common/collect/t9;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/common/collect/re;->a()Lcom/google/common/collect/re;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/common/collect/re;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/common/collect/pa;->G()Lcom/google/common/collect/pa;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/common/collect/pa;->b:Lcom/google/common/collect/pa;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/pa$e;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/google/common/collect/pa$e;-><init>(Lcom/google/common/collect/pa;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    new-instance v1, Lcom/google/common/collect/pa;

    const/4 v2, 0x5

    or-int/2addr v3, v2

    invoke-direct {v1, v0, p0}, Lcom/google/common/collect/pa;-><init>(Lcom/google/common/collect/t9;Lcom/google/common/collect/pa;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/google/common/collect/pa;->b:Lcom/google/common/collect/pa;

    const/4 v2, 0x1

    and-int/2addr v3, v2

    return-object v1
.end method
