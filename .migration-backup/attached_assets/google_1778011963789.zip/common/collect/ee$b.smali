.class Lcom/google/common/collect/ee$b;
.super Lcom/google/common/collect/t8;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/ee;->entrySet()Ljava/util/Set;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t8<",
        "Ljava/util/Map$Entry<",
        "Ljava/lang/Class<",
        "+TB;>;TB;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/collect/ee;


# direct methods
.method constructor <init>(Lcom/google/common/collect/ee;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/common/collect/ee$b;->a:Lcom/google/common/collect/ee;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/t8;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic C0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "d s~@ol/ @ct ~on~4@ytm   @ /~@-@obo~@~~~i@~~frl1@ @~fi@@~~ v . @~@@~ o@ ~@ ~b~oS~K biM~@@@~ua s~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/common/collect/ee$b;->D0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method private static synthetic D0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/common/collect/ee;->y0(Ljava/util/Map$Entry;)Ljava/util/Map$Entry;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method


# virtual methods
.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/ee$b;->z0()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic i0()Ljava/util/Collection;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/ee$b;->z0()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;>;"
        }
    .end annotation

    const/4 v3, 0x2

    new-instance v0, Lcom/google/common/collect/ee$b$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/ee$b;->z0()Ljava/util/Set;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/ee$b$a;-><init>(Lcom/google/common/collect/ee$b;Ljava/util/Iterator;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public spliterator()Ljava/util/Spliterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Spliterator<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/ee$b;->z0()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/common/collect/j;->a(Ljava/util/Set;)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v1, Lcom/google/common/collect/fe;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/google/common/collect/fe;-><init>()V

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/google/common/collect/p4;->h(Ljava/util/Spliterator;Ljava/util/function/Function;)Ljava/util/Spliterator;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public toArray()[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/common/collect/z7;->w0()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-object v0
.end method

.method public toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "array"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/common/collect/z7;->x0([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method protected z0()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "Ljava/lang/Class<",
            "+TB;>;TB;>;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/common/collect/ee$b;->a:Lcom/google/common/collect/ee;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/common/collect/ee;->i0()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method
