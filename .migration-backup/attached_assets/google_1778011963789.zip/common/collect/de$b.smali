.class Lcom/google/common/collect/de$b;
.super Lcom/google/common/collect/de$n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/de;->m(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)Lcom/google/common/collect/ae;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/de$n<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic c:Lcom/google/common/collect/ae;

.field final synthetic d:Lcom/google/common/collect/ae;


# direct methods
.method constructor <init>(Lcom/google/common/collect/ae;Lcom/google/common/collect/ae;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$multiset1",
            "val$multiset2"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/common/collect/de$b;->c:Lcom/google/common/collect/ae;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/common/collect/de$b;->d:Lcom/google/common/collect/ae;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0, p1}, Lcom/google/common/collect/de$n;-><init>(Lcom/google/common/collect/de$a;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public I1(Ljava/lang/Object;)I
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~1s~@o@@ov@~@@u~ b~ @K@ f@-~~~ns~cy~/~.  @M 4 ra@@~l  ~bfo~@/@li@ t d~ooiS@~@o~ @mt~~i @@~  ~b ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/common/collect/de$b;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/common/collect/de$b;->d:Lcom/google/common/collect/ae;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v1, p1}, Lcom/google/common/collect/ae;->I1(Ljava/lang/Object;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1
.end method

.method a()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/common/collect/de$b;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/google/common/collect/ae;->c()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/common/collect/de$b;->d:Lcom/google/common/collect/ae;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v1}, Lcom/google/common/collect/ae;->c()Ljava/util/Set;

    move-result-object v1

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    invoke-static {v0, v1}, Lcom/google/common/collect/uf;->n(Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/uf$m;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method e()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "hdem a ndvlcbs reuslel"

    const-string v1, "ensder ubllsolvdhc a e"

    const/4 v3, 0x5

    const-string/jumbo v1, "nceeordul ed hesoa vlb"

    const-string/jumbo v1, "should never be called"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw v0
.end method

.method f()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Lcom/google/common/collect/ae$a<",
            "TE;>;>;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/de$b;->c:Lcom/google/common/collect/ae;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/google/common/collect/ae;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    new-instance v1, Lcom/google/common/collect/de$b$a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, p0, v0}, Lcom/google/common/collect/de$b$a;-><init>(Lcom/google/common/collect/de$b;Ljava/util/Iterator;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v1
.end method
