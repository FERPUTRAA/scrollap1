.class Lcom/google/common/collect/f7;
.super Lcom/google/common/collect/u9;


# annotations
.annotation runtime Lcom/google/common/collect/d7;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/u9<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation build Lx4/b;
    serializable = true
.end annotation


# static fields
.field static final g:Lcom/google/common/collect/f7;

.field private static final serialVersionUID:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/common/collect/f7;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/collect/f7;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lcom/google/common/collect/f7;->g:Lcom/google/common/collect/f7;

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/w9;->w()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lcom/google/common/collect/u9;-><init>(Lcom/google/common/collect/w9;I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private readResolve()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ss- ~/ @tbso/o4tb @iolu ~@rm ~1~~@~ @~  @@ofM @@~  ~o@yi@@K@v@@b~ ~@c ~ @n~@  @~~~f.~~il@~~o da"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/google/common/collect/f7;->g:Lcom/google/common/collect/f7;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public bridge synthetic d()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/f7;->t()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public t()Lcom/google/common/collect/w9;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/w9<",
            "Ljava/lang/Object;",
            "Ljava/util/Collection<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/common/collect/ia;->t()Lcom/google/common/collect/w9;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
