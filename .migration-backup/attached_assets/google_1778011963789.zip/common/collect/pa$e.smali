.class final Lcom/google/common/collect/pa$e;
.super Lcom/google/common/collect/t9;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/pa;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/t9<",
        "Lcom/google/common/collect/re<",
        "TC;>;>;"
    }
.end annotation


# instance fields
.field private final positiveBoundedAbove:Z

.field private final positiveBoundedBelow:Z

.field private final size:I

.field final synthetic this$0:Lcom/google/common/collect/pa;


# direct methods
.method constructor <init>(Lcom/google/common/collect/pa;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/common/collect/pa$e;->this$0:Lcom/google/common/collect/pa;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/common/collect/t9;-><init>()V

    const/4 v2, 0x6

    move v3, v2

    invoke-static {p1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/common/collect/re;->q()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/google/common/collect/pa$e;->positiveBoundedBelow:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/google/common/collect/rb;->w(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    check-cast v1, Lcom/google/common/collect/re;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/common/collect/re;->s()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-boolean v1, p0, Lcom/google/common/collect/pa$e;->positiveBoundedAbove:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    add-int/lit8 p1, p1, 0x1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v2, 0x4

    move v3, v2

    add-int/lit8 p1, p1, 0x1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p1, p0, Lcom/google/common/collect/pa$e;->size:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public S(I)Lcom/google/common/collect/re;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/common/collect/re<",
            "TC;>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/common/collect/pa$e;->size:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lcom/google/common/base/u0;->C(II)I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/google/common/collect/pa$e;->positiveBoundedBelow:Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez p1, :cond_0

    invoke-static {}, Lcom/google/common/collect/x6;->c()Lcom/google/common/collect/x6;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/common/collect/pa$e;->this$0:Lcom/google/common/collect/pa;

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v1, p1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/google/common/collect/re;->upperBound:Lcom/google/common/collect/x6;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/common/collect/pa$e;->this$0:Lcom/google/common/collect/pa;

    const/4 v3, 0x0

    move v4, v3

    invoke-static {v0}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast v0, Lcom/google/common/collect/re;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/google/common/collect/re;->upperBound:Lcom/google/common/collect/x6;

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/google/common/collect/pa$e;->positiveBoundedAbove:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/common/collect/pa$e;->size:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ne p1, v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/common/collect/x6;->a()Lcom/google/common/collect/x6;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    goto :goto_1

    :cond_2
    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/common/collect/pa$e;->this$0:Lcom/google/common/collect/pa;

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/google/common/collect/pa;->s(Lcom/google/common/collect/pa;)Lcom/google/common/collect/t9;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean v2, p0, Lcom/google/common/collect/pa$e;->positiveBoundedBelow:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    xor-int/lit8 v2, v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    add-int/2addr p1, v2

    const/4 v4, 0x5

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    check-cast p1, Lcom/google/common/collect/re;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p1, Lcom/google/common/collect/re;->lowerBound:Lcom/google/common/collect/x6;

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, p1}, Lcom/google/common/collect/re;->k(Lcom/google/common/collect/x6;Lcom/google/common/collect/x6;)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p1
.end method

.method g()Z
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/common/collect/pa$e;->S(I)Lcom/google/common/collect/re;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/common/collect/pa$e;->size:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method
