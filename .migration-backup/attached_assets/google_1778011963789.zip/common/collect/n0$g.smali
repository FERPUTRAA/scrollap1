.class Lcom/google/common/collect/n0$g;
.super Lcom/google/common/collect/n0$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/n0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/n0$d<",
        "TC;TV;>;"
    }
.end annotation


# instance fields
.field final b:I

.field final synthetic c:Lcom/google/common/collect/n0;


# direct methods
.method constructor <init>(Lcom/google/common/collect/n0;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            "this$0",
            "rowIndex"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/common/collect/n0$g;->c:Lcom/google/common/collect/n0;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/common/collect/n0;->p(Lcom/google/common/collect/n0;)Lcom/google/common/collect/w9;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/common/collect/n0$d;-><init>(Lcom/google/common/collect/w9;Lcom/google/common/collect/n0$a;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput p2, p0, Lcom/google/common/collect/n0$g;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method f()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s@S bo o~i@~l@@fi@1 ~@s~~ ia@@bufMr  ~c.l@@t~b@~@-~ @v/oo~~~~@ @ ~ ~m@ 4t ~~K@n d~/~ ~~oo@@y~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-string/jumbo v0, "luomCs"

    const-string/jumbo v0, "losCum"

    const/4 v2, 0x2

    const-string v0, "Column"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method g(I)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/common/collect/n0$g;->c:Lcom/google/common/collect/n0;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/common/collect/n0$g;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Lcom/google/common/collect/n0;->t(II)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p1
.end method

.method h(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "newValue"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITV;)TV;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/common/collect/n0$g;->c:Lcom/google/common/collect/n0;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/common/collect/n0$g;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1, p1, p2}, Lcom/google/common/collect/n0;->K(IILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1
.end method
