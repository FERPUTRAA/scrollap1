.class final Lcom/google/common/collect/pl$f;
.super Lcom/google/common/collect/pl$g;

# interfaces
.implements Lcom/google/common/collect/lf;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/pl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        "C:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/collect/pl$g<",
        "TR;TC;TV;>;",
        "Lcom/google/common/collect/lf<",
        "TR;TC;TV;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J


# direct methods
.method public constructor <init>(Lcom/google/common/collect/lf;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "delegate"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/lf<",
            "TR;+TC;+TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/common/collect/pl$g;-><init>(Lcom/google/common/collect/bl;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic f()Ljava/util/Set;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~~ @~@f@l~ @o~uSa@ooltf@@~icm~~~on~~t@o-  ~i@ /v~K@ y ~ M@ @@rdi@~. ~b ~@@4  s ~b~@~/ 1o  b@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->f()Ljava/util/SortedSet;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public f()Ljava/util/SortedSet;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/SortedSet<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->j0()Lcom/google/common/collect/lf;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/google/common/collect/lf;->f()Ljava/util/SortedSet;

    move-result-object v0

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSortedSet(Ljava/util/SortedSet;)Ljava/util/SortedSet;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method protected bridge synthetic g0()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->j0()Lcom/google/common/collect/lf;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic h()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->h()Ljava/util/SortedMap;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-object v0
.end method

.method public h()Ljava/util/SortedMap;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/SortedMap<",
            "TR;",
            "Ljava/util/Map<",
            "TC;TV;>;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/common/collect/pl;->a()Lcom/google/common/base/s;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->j0()Lcom/google/common/collect/lf;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v1}, Lcom/google/common/collect/lf;->h()Ljava/util/SortedMap;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/google/common/collect/uc;->F0(Ljava/util/SortedMap;Lcom/google/common/base/s;)Ljava/util/SortedMap;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSortedMap(Ljava/util/SortedMap;)Ljava/util/SortedMap;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method protected bridge synthetic i0()Lcom/google/common/collect/bl;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/collect/pl$f;->j0()Lcom/google/common/collect/lf;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method protected j0()Lcom/google/common/collect/lf;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/lf<",
            "TR;TC;TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/common/collect/pl$g;->i0()Lcom/google/common/collect/bl;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Lcom/google/common/collect/lf;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method
