.class Lcom/google/common/collect/m7$a$a$a;
.super Lcom/google/common/collect/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/m7$a$a;->iterator()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/e<",
        "Ljava/util/Map$Entry<",
        "TK;",
        "Ljava/util/Collection<",
        "TV;>;>;>;"
    }
.end annotation


# instance fields
.field final c:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;>;"
        }
    .end annotation
.end field

.field final synthetic d:Lcom/google/common/collect/m7$a$a;


# direct methods
.method constructor <init>(Lcom/google/common/collect/m7$a$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$2"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/collect/m7$a$a$a;->d:Lcom/google/common/collect/m7$a$a;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/common/collect/e;-><init>()V

    const/4 v1, 0x5

    iget-object p1, p1, Lcom/google/common/collect/m7$a$a;->a:Lcom/google/common/collect/m7$a;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p1, p1, Lcom/google/common/collect/m7$a;->d:Lcom/google/common/collect/m7;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p1, p1, Lcom/google/common/collect/m7;->f:Lcom/google/common/collect/pd;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-interface {p1}, Lcom/google/common/collect/pd;->d()Ljava/util/Map;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/collect/m7$a$a$a;->c:Ljava/util/Iterator;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected bridge synthetic a()Ljava/lang/Object;
    .locals 3
    .annotation runtime Lv7/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~su ~i~bo  @@r@f~@ @y@ni@t~~o   o~~1@@@o ./vmliM ~l~ ~s ~d~/@@@~ob@@~@@~ @4 @f~~- ~bt oa  ~~S~c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/common/collect/m7$a$a$a;->d()Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method protected d()Ljava/util/Map$Entry;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;",
            "Ljava/util/Collection<",
            "TV;>;>;"
        }
    .end annotation

    .annotation runtime Lv7/a;
    .end annotation

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/common/collect/m7$a$a$a;->c:Ljava/util/Iterator;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/common/collect/m7$a$a$a;->c:Ljava/util/Iterator;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v0, Ljava/util/Collection;

    const/4 v5, 0x7

    new-instance v2, Lcom/google/common/collect/m7$c;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/common/collect/m7$a$a$a;->d:Lcom/google/common/collect/m7$a$a;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, v3, Lcom/google/common/collect/m7$a$a;->a:Lcom/google/common/collect/m7$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, v3, Lcom/google/common/collect/m7$a;->d:Lcom/google/common/collect/m7;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v2, v3, v1}, Lcom/google/common/collect/m7$c;-><init>(Lcom/google/common/collect/m7;Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v2}, Lcom/google/common/collect/m7;->p(Ljava/util/Collection;Lcom/google/common/base/w0;)Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1, v0}, Lcom/google/common/collect/uc;->O(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object v0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/common/collect/e;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v0
.end method
