.class final Lcom/google/common/base/e$l;
.super Lcom/google/common/base/e$a0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "l"
.end annotation


# static fields
.field private static final e:Ljava/lang/String; = "\u0000\u007f\u00ad\u0600\u061c\u06dd\u070f\u0890\u08e2\u1680\u180e\u2000\u2028\u205f\u2066\u3000\ud800\ufeff\ufff9"

.field private static final f:Ljava/lang/String; = " \u00a0\u00ad\u0605\u061c\u06dd\u070f\u0891\u08e2\u1680\u180e\u200f\u202f\u2064\u206f\u3000\uf8ff\ufeff\ufffb"

.field static final g:Lcom/google/common/base/e$l;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lcom/google/common/base/e$l;

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/common/base/e$l;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/google/common/base/e$l;->g:Lcom/google/common/base/e$l;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v0, "00s22002fs1d68fu/f0eu390uf0//u/u//87/f015290u/d0/f8d60ua00u8u0000660e0f20uu/00080/u07uu002du/f/00u/uu6fe0/16/0c///"

    const-string/jumbo v0, "u0s9c80000500/0/068/f7/d08/670/3a9u/2000/d/20e/u/0f000uf160//u/00u0e20u0/60d/du026ffuf0/1ffu062uf1uuu/200uu8u8e/uu"

    const/4 v4, 0x4

    const-string v0, "/5/m82/00u683ufcu8/0d/0f20/0u0ef0e2//u0ud/0u786ueu90d00f000u060/68u020006uff6270f1/uu/0u2df/u0/u/8f/10//19000u0a/0"

    const-string v0, "\u0000\u007f\u00ad\u0600\u061c\u06dd\u070f\u0890\u08e2\u1680\u180e\u2000\u2028\u205f\u2066\u3000\ud800\ufeff\ufff9"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "/fu/o//uf/ue/u/u020uu16/8uf0u00f2u48f0/fu11f/a9f06b6f/0080u00008800 0a03/df0u/0/26ud/feucuf52mdu620270fu//16/"

    const-string v1, "1f/mufu2/uu0/f5c6d /08u/160u0a0/ffd0u60e/00/2fe/u/u0fa10/6f0///069fuu87/e2uf48001/0ud00f00u/u/uf0f8262b3u20u8"

    const/4 v4, 0x1

    const-string v1, "/8u/eb2/u4006u/0/006/fu03f0 fu60u1/0u6dufu/b/f/u2ue200udud/7/f2/f0f0//02u0650u0/88a0f//f0e0c2160a9808u0ufu1ff"

    const-string v1, " \u00a0\u00ad\u0605\u061c\u06dd\u070f\u0891\u08e2\u1680\u180e\u200f\u202f\u2064\u206f\u3000\uf8ff\ufeff\ufffb"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "rMh(ahusavionie)t.lrCce"

    const-string v2, "htrioic.Canl)hes(vraMei"

    const/4 v4, 0x6

    const-string v2, "ctrrhn.pl(ibaheeMaC)iiv"

    const-string v2, "CharMatcher.invisible()"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p0, v2, v0, v1}, Lcom/google/common/base/e$a0;-><init>(Ljava/lang/String;[C[C)V

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    return-void
.end method
