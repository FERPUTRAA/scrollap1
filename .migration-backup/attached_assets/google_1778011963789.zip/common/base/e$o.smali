.class final Lcom/google/common/base/e$o;
.super Lcom/google/common/base/e$i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "o"
.end annotation


# instance fields
.field private final b:C


# direct methods
.method constructor <init>(C)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "match"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/base/e$i;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-char p1, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~@rS~4@@~ ~ @~movf@ @i/lb o c t/.o@~~b  ~ ~od~@ K@o~ oM@~ ~~~@~  ~~@@@@@s~ ~@~1aun@l~i- fbi@y"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-char v0, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    return p1
.end method

.method public F()Lcom/google/common/base/e;
    .locals 3

    const/4 v2, 0x2

    iget-char v0, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {v0}, Lcom/google/common/base/e;->q(C)Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public I(Lcom/google/common/base/e;)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-char v0, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Lcom/google/common/base/e;->B(C)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/common/base/e;->c()Lcom/google/common/base/e;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-char v1, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Ljava/util/BitSet;->set(II)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-char v0, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/high16 v1, 0x10000

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Ljava/util/BitSet;->set(II)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public b(Lcom/google/common/base/e;)Lcom/google/common/base/e;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-char v0, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Lcom/google/common/base/e;->B(C)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-super {p0, p1}, Lcom/google/common/base/e;->b(Lcom/google/common/base/e;)Lcom/google/common/base/e;

    move-result-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p1
.end method

.method public bridge synthetic negate()Ljava/util/function/Predicate;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/common/base/e$o;->F()Lcom/google/common/base/e;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "siomatea.hcrNrCh(//M"

    const-string v1, "hos(C//NracehriMt.ta"

    const-string/jumbo v1, "tehCohc/rst(M.arNoa/"

    const-string v1, "CharMatcher.isNot(\'"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    iget-char v1, p0, Lcom/google/common/base/e$o;->b:C

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/common/base/e;->a(C)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const-string v1, ")//"

    const-string v1, "/)/"

    const/4 v3, 0x3

    const-string v1, "//)"

    const-string v1, "\')"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method
