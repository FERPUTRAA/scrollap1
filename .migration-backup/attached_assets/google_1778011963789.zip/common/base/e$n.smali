.class final Lcom/google/common/base/e$n;
.super Lcom/google/common/base/e$i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "n"
.end annotation


# instance fields
.field private final b:C

.field private final c:C


# direct methods
.method constructor <init>(CC)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "match1",
            "match2"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/common/base/e$i;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-char p1, p0, Lcom/google/common/base/e$n;->b:C

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-char p2, p0, Lcom/google/common/base/e$n;->c:C

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sli@.~r~lf@ ~ @~~oS4  @ d~ m~v ~ @~/i~o~y   ~@~1@oi~@t@@u/ ~@@ @ ~b~o~tbs@~  MnK@@@ac@~bof -@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-char v0, p0, Lcom/google/common/base/e$n;->b:C

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eq p1, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-char v0, p0, Lcom/google/common/base/e$n;->c:C

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    return p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-char v0, p0, Lcom/google/common/base/e$n;->b:C

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->set(I)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-char v0, p0, Lcom/google/common/base/e$n;->c:C

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1, v0}, Ljava/util/BitSet;->set(I)V

    const/4 v2, 0x1

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "srym/Oheact(farMna/h"

    const-string/jumbo v1, "tnsOCfe/aayrrcah/(hM"

    const-string v1, "(h/eorChafM.rat/caOy"

    const-string v1, "CharMatcher.anyOf(\""

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-char v1, p0, Lcom/google/common/base/e$n;->b:C

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/common/base/e;->a(C)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-char v1, p0, Lcom/google/common/base/e$n;->c:C

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/common/base/e;->a(C)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const-string v1, "//)"

    const/4 v3, 0x7

    const-string v1, "/)/"

    const-string v1, "\")"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method
