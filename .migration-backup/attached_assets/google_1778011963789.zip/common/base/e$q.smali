.class final Lcom/google/common/base/e$q;
.super Lcom/google/common/base/e$v;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "q"
.end annotation


# static fields
.field static final c:Lcom/google/common/base/e$q;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/common/base/e$q;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/common/base/e$q;-><init>()V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    sput-object v0, Lcom/google/common/base/e$q;->c:Lcom/google/common/base/e$q;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "ohsCehojrI.satCr(toacvrsM)an"

    const-string/jumbo v0, "tcs(rChaaC)ovoat.jhoMsnrlIer"

    const/4 v2, 0x2

    const-string v0, ").tmlr(saaIorceoCtohjrhCaavM"

    const-string v0, "CharMatcher.javaIsoControl()"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/common/base/e$v;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4 obo @oco @~~ yr fs@@// @o~@b@@on ai~@@ ~-i l@ut~ @1 S ~ ~l~t~ ~K  ~d~~f~@~~@@@~b~@@~ @~oMv.~m@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/16 v0, 0x1f

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-le p1, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/16 v0, 0x7f

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-lt p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v0, 0x9f

    const/4 v2, 0x6

    if-gt p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x1

    :goto_1
    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1
.end method
