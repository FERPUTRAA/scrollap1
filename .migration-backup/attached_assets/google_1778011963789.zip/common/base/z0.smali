.class final Lcom/google/common/base/z0;
.super Lcom/google/common/base/e$v;


# annotations
.annotation runtime Lcom/google/common/base/k;
.end annotation

.annotation build Lx4/c;
.end annotation

.annotation build Lx4/d;
.end annotation


# static fields
.field static final f:I = 0x3ff

.field private static final g:I = -0x3361d2af

.field private static final h:I = 0x1b873593

.field private static final i:D = 0.5


# instance fields
.field private final c:[C

.field private final d:Z

.field private final e:J


# direct methods
.method private constructor <init>([CJZLjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "table",
            "filter",
            "containsZero",
            "description"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p5}, Lcom/google/common/base/e$v;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/base/z0;->c:[C

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-wide p2, p0, Lcom/google/common/base/z0;->e:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-boolean p4, p0, Lcom/google/common/base/z0;->d:Z

    const/4 v1, 0x2

    return-void
.end method

.method private Y(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "c s@tf@ ~@/~r~oob@u~ @S~-ni~b.~ @4~l ~y~@@~~f~o  M@@ m1l@ s @~~o~~~@~@a@ d@v@ob@ io~@~/t   @i  K"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/google/common/base/z0;->e:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    shr-long/2addr v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x7

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    and-long/2addr v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    cmp-long p1, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    move v5, v4

    const/4 p1, 0x0

    xor-int/2addr v5, p1

    :goto_0
    const/4 v4, 0x5

    move v5, v4

    return p1
.end method

.method static Z(I)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "setSize"
        }
    .end annotation

    .annotation build Lx4/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ne p0, v0, :cond_0

    const/4 v6, 0x5

    const/4 p0, 0x1

    const/4 v6, 0x1

    const/4 p0, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    return p0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v1, p0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    shl-int/lit8 v0, v1, 0x1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    int-to-double v1, v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    const/4 v6, 0x3

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    mul-double/2addr v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    int-to-double v3, p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    cmpg-double v1, v1, v3

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-gez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    shl-int/lit8 v0, v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    return v0
.end method

.method static a0(Ljava/util/BitSet;Ljava/lang/String;)Lcom/google/common/base/e;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "chars",
            "description"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p0}, Ljava/util/BitSet;->cardinality()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/4 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0, v1}, Ljava/util/BitSet;->get(I)Z

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/google/common/base/z0;->Z(I)I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-array v3, v0, [C

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v10, 0x0

    invoke-virtual {p0, v1}, Ljava/util/BitSet;->nextSetBit(I)I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eq v1, v2, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v10, 0x2

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v9, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    shl-long/2addr v7, v1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    or-long/2addr v7, v4

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/google/common/base/z0;->b0(I)I

    move-result v2

    :goto_1
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    and-int/2addr v2, v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    aget-char v4, v3, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-nez v4, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    int-to-char v4, v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    aput-char v4, v3, v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p0, v1}, Ljava/util/BitSet;->nextSetBit(I)I

    move-result v1

    move-wide v4, v7

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    goto :goto_1

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    new-instance p0, Lcom/google/common/base/z0;

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct/range {v2 .. v7}, Lcom/google/common/base/z0;-><init>([CJZLjava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-object p0
.end method

.method static b0(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "hashCode"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const v0, -0x3361d2af    # -8.2930312E7f

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    mul-int/2addr p0, v0

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 v0, 0xf

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const v0, 0x1b873593

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    mul-int/2addr p0, v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p0
.end method


# virtual methods
.method public B(C)Z
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez p1, :cond_0

    const/4 v6, 0x6

    move v7, v6

    iget-boolean p1, p0, Lcom/google/common/base/z0;->d:Z

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    return p1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, p1}, Lcom/google/common/base/z0;->Y(I)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x4

    if-nez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    return v1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/common/base/z0;->c:[C

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    array-length v0, v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    sub-int/2addr v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/google/common/base/z0;->b0(I)I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    and-int/2addr v3, v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v4, v3

    move v4, v3

    const/4 v7, 0x7

    move v4, v3

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    iget-object v5, p0, Lcom/google/common/base/z0;->c:[C

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    aget-char v5, v5, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-nez v5, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    return v1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ne v5, p1, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    return v2

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    and-int/2addr v4, v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-ne v4, v3, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    return v1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-boolean v0, p0, Lcom/google/common/base/z0;->d:Z

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {p1, v1}, Ljava/util/BitSet;->set(I)V

    :cond_0
    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/common/base/z0;->c:[C

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    array-length v2, v0

    :goto_0
    const/4 v5, 0x3

    if-ge v1, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-char v3, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1, v3}, Ljava/util/BitSet;->set(I)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method
