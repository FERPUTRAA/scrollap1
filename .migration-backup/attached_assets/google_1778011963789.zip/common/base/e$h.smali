.class final Lcom/google/common/base/e$h;
.super Lcom/google/common/base/e$a0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "h"
.end annotation


# static fields
.field private static final e:Ljava/lang/String; = "0\u0660\u06f0\u07c0\u0966\u09e6\u0a66\u0ae6\u0b66\u0be6\u0c66\u0ce6\u0d66\u0de6\u0e50\u0ed0\u0f20\u1040\u1090\u17e0\u1810\u1946\u19d0\u1a80\u1a90\u1b50\u1bb0\u1c40\u1c50\ua620\ua8d0\ua900\ua9d0\ua9f0\uaa50\uabf0\uff10"

.field static final f:Lcom/google/common/base/e$h;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/google/common/base/e$h;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/google/common/base/e$h;-><init>()V

    const/4 v1, 0x5

    move v2, v1

    sput-object v0, Lcom/google/common/base/e$h;->f:Lcom/google/common/base/e$h;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/common/base/e$h;->Z()[C

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/common/base/e$h;->Y()[C

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "tMstarC.hce)higsard"

    const-string v2, ".Cs)rhctghMdaaterii"

    const-string v2, "hr(meg.aMit)dtcahCi"

    const-string v2, "CharMatcher.digit()"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, v2, v0, v1}, Lcom/google/common/base/e$a0;-><init>(Ljava/lang/String;[C[C)V

    const/4 v4, 0x2

    return-void
.end method

.method private static Y()[C
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~-io @tK@ ~~b~~ b @o/@o v~b~ ~~4@@~~M@/du~  t@c~ ~.~@of o@@ i @n@~f@l ~~y1~ @~Sal iorms@@~~ o @"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const/16 v0, 0x25

    const/4 v5, 0x1

    new-array v1, v0, [C

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ge v2, v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v3, "01uueb16669/u0u///0a6u560f691/0u/9d/0/f/6558c4ed0a0a19u0cu/0d/0u69/u0b040u//106f7e6/ea1100d061u//00u01/uu00669uu/00d/0u0uuuc6cau4e0/0uba6/001601000/6///002e61/ub/1cu9u/a0u/601/09//0fb0u/uea80a/uueuu6f5972aa0bdu/8ufbau"

    const-string v3, "0\u0660\u06f0\u07c0\u0966\u09e6\u0a66\u0ae6\u0b66\u0be6\u0c66\u0ce6\u0d66\u0de6\u0e50\u0ed0\u0f20\u1040\u1090\u17e0\u1810\u1946\u19d0\u1a80\u1a90\u1b50\u1bb0\u1c40\u1c50\ua620\ua8d0\ua900\ua9d0\ua9f0\uaa50\uabf0\uff10"

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v3, v3, 0x9

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    int-to-char v3, v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    aput-char v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    return-object v1
.end method

.method private static Z()[C
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "0/b9f0u/60/60u/00/d180uu/auu0ad/6/u1/60///fu1ef0b/00a6f1a2aa/u10ebuea066u/5b064/65c79a1/019a0u/0/0919/6/0f0u00uu00/0u5uu16du08b/0000u1//0a6a9u2/u/u4a171/u//d01c/duc40u6e/668ue5uue0b00uu69f6/00uu0e0c01c/u6//u69m0eu9ud0"

    const-string v0, "0e2m/ce19/u7d//a/d/u0/1/0cb0au2080e616/06ecaua6906u90ufuae/0u06/b1/b6u1/5/61a697uf///f/0d4u0/00010u10uu6eu16116uu/9e686u6u6/0a000cu0e960//a0d5900a/0ufab0u860/ua469fb50b/60ufuu10/10/0/ud00cu/00/uuuda0u//u004/1u0//05u9u"

    const/4 v2, 0x5

    const-string v0, "e/u0200pcb/9aeu0u600u091c/6440a16cbua/u/0uf696//u/u/uud660d0//5u0e60aua0u6fe70uu/00000//9/0bbu6d00f09500au0b0/960a/u1/u//6/1uu1a100u5/0169/0100/uf0e64fuu/e8ufu6u1d//u1u006ea/u66/1b/1/190907aa0d/du/5/c6/1u0c0/6e08au082"

    const-string v0, "0\u0660\u06f0\u07c0\u0966\u09e6\u0a66\u0ae6\u0b66\u0be6\u0c66\u0ce6\u0d66\u0de6\u0e50\u0ed0\u0f20\u1040\u1090\u17e0\u1810\u1946\u19d0\u1a80\u1a90\u1b50\u1bb0\u1c40\u1c50\ua620\ua8d0\ua900\ua9d0\ua9f0\uaa50\uabf0\uff10"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method
