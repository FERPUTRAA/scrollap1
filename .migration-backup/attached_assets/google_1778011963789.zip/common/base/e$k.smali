.class final Lcom/google/common/base/e$k;
.super Lcom/google/common/base/e$i;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "k"
.end annotation


# instance fields
.field private final b:C

.field private final c:C


# direct methods
.method constructor <init>(CC)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "startInclusive",
            "endInclusive"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/common/base/e$i;-><init>()V

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    if-lt p2, p1, :cond_0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/common/base/u0;->d(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-char p1, p0, Lcom/google/common/base/e$k;->b:C

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-char p2, p0, Lcom/google/common/base/e$k;->c:C

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@st@/uKo~~f4m-ob  ol  ro~ ~~@Si@@f~ls @~ @ai @@@dco@ ~~@~/i~@~b@@@@~v. t n ~ by@1M~  ~~~~o~@ ~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-char v0, p0, Lcom/google/common/base/e$k;->b:C

    const/4 v2, 0x3

    const/4 v1, 0x7

    if-gt v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-char v0, p0, Lcom/google/common/base/e$k;->c:C

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-gt p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    return p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v2, 0x5

    move v3, v2

    iget-char v0, p0, Lcom/google/common/base/e$k;->b:C

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-char v1, p0, Lcom/google/common/base/e$k;->c:C

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Ljava/util/BitSet;->set(II)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const-string v1, "e(gma/rhaeMCsc/iRnah.t"

    const-string v1, "Mhs(echgiatRCea.nanr//"

    const/4 v3, 0x0

    const-string v1, "gah/oenc/(.etnraiaCRhr"

    const-string v1, "CharMatcher.inRange(\'"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-char v1, p0, Lcom/google/common/base/e$k;->b:C

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/google/common/base/e;->a(C)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    or-int/2addr v3, v2

    const-string v1, "//m/,b"

    const-string v1, "//,m /"

    const/4 v3, 0x5

    const-string/jumbo v1, "u/,/ /"

    const-string v1, "\', \'"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-char v1, p0, Lcom/google/common/base/e$k;->c:C

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/common/base/e;->a(C)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "//)"

    const-string v1, ")//"

    const/4 v3, 0x6

    const-string v1, ")//"

    const-string v1, "\')"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method
