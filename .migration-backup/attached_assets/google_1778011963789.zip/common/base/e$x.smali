.class Lcom/google/common/base/e$x;
.super Lcom/google/common/base/e$w;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "x"
.end annotation


# direct methods
.method constructor <init>(Lcom/google/common/base/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "original"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/common/base/e$w;-><init>(Lcom/google/common/base/e;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final J()Lcom/google/common/base/e;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s ~ ~oob~@a~~~f/  @~@@@cd t  ~~i~@v~~y~ @  i~o@@M  @/r @o  ~Kl@@-~f~s@Smo~b@4 u. lb@1~@tni@@o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    return-object p0
.end method
