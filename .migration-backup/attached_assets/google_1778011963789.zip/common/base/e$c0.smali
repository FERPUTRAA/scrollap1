.class final Lcom/google/common/base/e$c0;
.super Lcom/google/common/base/e$v;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/base/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c0"
.end annotation

.annotation build Lx4/e;
.end annotation


# static fields
.field static final c:Ljava/lang/String; = "\u2002\u3000\r\u0085\u200a\u2005\u2000\u3000\u2029\u000b\u3000\u2008\u2003\u205f\u3000\u1680\t \u2006\u2001\u202f\u00a0\u000c\u2009\u3000\u2004\u3000\u3000\u2028\n\u2007\u3000"

.field static final d:I = 0x6449bf0a

.field static final e:I

.field static final f:Lcom/google/common/base/e$c0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/16 v0, 0x1f

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput v0, Lcom/google/common/base/e$c0;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/common/base/e$c0;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/common/base/e$c0;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/google/common/base/e$c0;->f:Lcom/google/common/base/e$c0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "(ssae.paahct)tehhMeCicsr"

    const-string v0, "cesaewCpha.hiMt)ea(hcsrt"

    const/4 v2, 0x5

    const-string/jumbo v0, "schmiMapt.eareaec(hCw)tr"

    const-string v0, "CharMatcher.whitespace()"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/common/base/e$v;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public B(C)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "c"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~M1~o~tso@ @v.m~@~di~@oSr~@~ ~b@~~ ~@Koo- b~~yl@ 4  @@ @n o@f@~~u~oa~ f c@ @ @ @i@ ~//~l ~@tbi~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const v0, 0x6449bf0a

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/2addr v0, p1

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget v1, Lcom/google/common/base/e$c0;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    ushr-int/2addr v0, v1

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "30230b002/2/u20/0050//3m3u28/00u//20au002000 /8t/2/23/00un0u/0uuuu022000u9000/02buuur3/0u0/068uu//u0/u00000//033//2f20000u28u5c/00000//0002/70/uu22319au004/01u/u000000u5000u6/"

    const-string v1, "020m02a005u0//2/20/uuu/u0t/8080/2/u00u8010u010000/20036n2/62//0//2392b00u0/003u9520000 0/u70f/8/c2/02220uu0uu/u0230u0u030030u0u00u50/200000432fu00//uu/r00////00000/0/u03u3/auu"

    const/4 v3, 0x5

    const-string v1, "202u2uu/352/0//0u60u70a0f0/10c0t000/00/uu/u00580/090uu0u040/020002u200032u0//63/u0018//u0u090020382033uu022003u00/02/00/00f/3/00/0u380u0 u02uu/2r/u0n0/0b025a/02/2u00uu/020///u"

    const-string/jumbo v1, "\u2002\u3000\r\u0085\u200a\u2005\u2000\u3000\u2029\u000b\u3000\u2008\u2003\u205f\u3000\u1680\t \u2006\u2001\u202f\u00a0\u000c\u2009\u3000\u2004\u3000\u3000\u2028\n\u2007\u3000"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne v0, p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p1
.end method

.method Q(Ljava/util/BitSet;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "table"
        }
    .end annotation

    .annotation build Lx4/c;
    .end annotation

    .annotation build Lx4/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v1, 0x20

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ge v0, v1, :cond_0

    const/4 v2, 0x6

    move v3, v2

    const-string v1, "/u00o00uu00fr0///96uuu3000005u22a22//0u203u03/42u/820/uuf0/65/23u/0020u020/000001/700/2/3/u02/3102u/00/0/0u22tn00buu0290u200u3c0//2000// /0u/300u0808u3u/0/00/0000u08/0000uua52"

    const/4 v3, 0x2

    const-string v1, "0200002p2/u0/00130u0000/0u0/00n22uf00/a226/uu0080685u22u/0tu022u/02/0uu/0c/u001/000203/000090009//uu2f/u00u0u//0u402/503203uuruu0u0ab000/3/0u/20u// 3/003//302u/0u858/0/0/00273"

    const-string/jumbo v1, "\u2002\u3000\r\u0085\u200a\u2005\u2000\u3000\u2029\u000b\u3000\u2008\u2003\u205f\u3000\u1680\t \u2006\u2001\u202f\u00a0\u000c\u2009\u3000\u2004\u3000\u3000\u2028\n\u2007\u3000"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v1}, Ljava/util/BitSet;->set(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method
