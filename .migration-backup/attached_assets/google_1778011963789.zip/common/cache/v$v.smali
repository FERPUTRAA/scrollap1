.class final Lcom/google/common/cache/v$v;
.super Lcom/google/common/cache/v$x;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "v"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/cache/v$x<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field volatile e:J

.field f:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field g:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;ILcom/google/common/cache/f0;)V
    .locals 2
    .param p3    # Lcom/google/common/cache/f0;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "hash",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;I",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/google/common/cache/v$x;-><init>(Ljava/lang/Object;ILcom/google/common/cache/f0;)V

    const/4 v0, 0x1

    shr-int/2addr v1, v0

    const-wide p1, 0x7fffffffffffffffL

    const-wide p1, 0x7fffffffffffffffL

    const/4 v1, 0x6

    const-wide p1, 0x7fffffffffffffffL

    const-wide p1, 0x7fffffffffffffffL

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/google/common/cache/v$v;->e:J

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$v;->f:Lcom/google/common/cache/f0;

    const/4 v0, 0x4

    const/4 v0, 0x6

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/google/common/cache/v$v;->g:Lcom/google/common/cache/f0;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public d()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@sf@~o@~~/u@i @@b~~ y~~~~ ~@Ko~~@o~ ~~o@c @@ o @~r@~i @~ t.a omi-~bstM f@n/~  b @@~1Sl v4 ~@@ld"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v$v;->g:Lcom/google/common/cache/f0;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public f()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$v;->f:Lcom/google/common/cache/f0;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public g(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "previous"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$v;->g:Lcom/google/common/cache/f0;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public l(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "time"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/google/common/cache/v$v;->e:J

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public m()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/google/common/cache/v$v;->e:J

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-wide v0
.end method

.method public p(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/common/cache/v$v;->f:Lcom/google/common/cache/f0;

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method
