.class final Lcom/google/common/cache/v$w;
.super Lcom/google/common/cache/v$x;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/cache/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "w"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/common/cache/v$x<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field volatile e:J

.field f:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field g:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field volatile h:J

.field i:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field

.field j:Lcom/google/common/cache/f0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf6/j;
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;ILcom/google/common/cache/f0;)V
    .locals 2
    .param p3    # Lcom/google/common/cache/f0;
        .annotation runtime Lv7/a;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "key",
            "hash",
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;I",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/google/common/cache/v$x;-><init>(Ljava/lang/Object;ILcom/google/common/cache/f0;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    const-wide p1, 0x7fffffffffffffffL

    const-wide p1, 0x7fffffffffffffffL

    const/4 v1, 0x7

    const-wide p1, 0x7fffffffffffffffL

    const-wide p1, 0x7fffffffffffffffL

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/google/common/cache/v$w;->e:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p3

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/common/cache/v$w;->f:Lcom/google/common/cache/f0;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p3

    const/4 v1, 0x0

    const/4 v0, 0x5

    iput-object p3, p0, Lcom/google/common/cache/v$w;->g:Lcom/google/common/cache/f0;

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/google/common/cache/v$w;->h:J

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$w;->i:Lcom/google/common/cache/f0;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {}, Lcom/google/common/cache/v;->L()Lcom/google/common/cache/f0;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$w;->j:Lcom/google/common/cache/f0;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public d()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S s@~@1~i@~i~n/@@@~@ u/@~@ @d~f~ @~im  ol ~~ @o~a~yo~~@.tv@ ~@ K oMo@o~b b~~@- c@  lt@ ~r~b~f @s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/common/cache/v$w;->g:Lcom/google/common/cache/f0;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public e()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/common/cache/v$w;->i:Lcom/google/common/cache/f0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public f()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/common/cache/v$w;->f:Lcom/google/common/cache/f0;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public g(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "previous"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/common/cache/v$w;->g:Lcom/google/common/cache/f0;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public h()Lcom/google/common/cache/f0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/common/cache/v$w;->j:Lcom/google/common/cache/f0;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public j()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/google/common/cache/v$w;->h:J

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide v0
.end method

.method public l(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "time"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/google/common/cache/v$w;->e:J

    const/4 v1, 0x5

    return-void
.end method

.method public m()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/google/common/cache/v$w;->e:J

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-wide v0
.end method

.method public o(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "time"
        }
    .end annotation

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/google/common/cache/v$w;->h:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public p(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/google/common/cache/v$w;->f:Lcom/google/common/cache/f0;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public q(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "next"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/common/cache/v$w;->i:Lcom/google/common/cache/f0;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public s(Lcom/google/common/cache/f0;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "previous"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/cache/f0<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/common/cache/v$w;->j:Lcom/google/common/cache/f0;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
