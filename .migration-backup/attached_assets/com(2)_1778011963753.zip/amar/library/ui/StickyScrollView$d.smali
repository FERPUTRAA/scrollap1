.class public final Lcom/amar/library/ui/StickyScrollView$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/amar/library/ui/StickyScrollView;->L(Landroid/view/View;Li8/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic a:Li8/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/a<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Landroid/view/View;


# direct methods
.method constructor <init>(Li8/a;Landroid/view/View;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/a<",
            "Lkotlin/s2;",
            ">;",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/amar/library/ui/StickyScrollView$d;->a:Li8/a;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/amar/library/ui/StickyScrollView$d;->b:Landroid/view/View;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "-@s ~@@~b@K@@~b4/oo~@@a~~~ stM  @brvn~ i1~oS@i@ ~~~  @ f ~@l   @@~~~~y./ ~@dtfi @ ~c~~@omlo~ o@u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$d;->a:Li8/a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Li8/a;->invoke()Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$d;->b:Landroid/view/View;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
