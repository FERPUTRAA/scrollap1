.class final Lcom/amar/library/ui/StickyScrollView$c;
.super Ljava/lang/Object;

# interfaces
.implements Lj1/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/amar/library/ui/StickyScrollView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Lcom/amar/library/ui/StickyScrollView;


# direct methods
.method public constructor <init>(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const-string v0, "$ss0hi"

    const-string v0, "i$s0sh"

    const/4 v2, 0x3

    const-string v0, "$0hmst"

    const-string/jumbo v0, "this$0"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public static synthetic h(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @f~o~ms@~@S ~~@~b-oK~~~~roio 4@.  ~ @@o~@  i cMu@y @ 1@~d~~ o~@@f@@/ t@~/ a ~o~~b nl~b@@@l i@~v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/amar/library/ui/StickyScrollView$c;->j(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static synthetic i(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/amar/library/ui/StickyScrollView$c;->k(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method private static final j(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string v0, "i0mstb"

    const-string/jumbo v0, "s$tm0i"

    const/4 v2, 0x4

    const-string/jumbo v0, "usith$"

    const-string/jumbo v0, "this$0"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/amar/library/ui/StickyScrollView;->C(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method private static final k(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "tphi$0"

    const-string/jumbo v0, "it0$oh"

    const/4 v2, 0x0

    const-string v0, "0$qits"

    const-string/jumbo v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/amar/library/ui/StickyScrollView;->D(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView;->B(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    int-to-float p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/view/View;->setTranslationY(F)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object p1, Lcom/amar/library/ui/a;->a:Lcom/amar/library/ui/a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Lcom/amar/library/ui/a;->a(Landroid/view/View;F)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public b(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, p1}, Lcom/amar/library/ui/StickyScrollView;->F(Lcom/amar/library/ui/StickyScrollView;Landroid/view/View;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/amar/library/ui/StickyScrollView;->B(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v1, Lcom/amar/library/ui/c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1, v0}, Lcom/amar/library/ui/c;-><init>(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public d()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v2, 0x5

    move v3, v2

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView;->A(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    :goto_0
    const/4 v3, 0x4

    return-void
.end method

.method public e(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView;->A(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    int-to-float p1, p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/view/View;->setTranslationY(F)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public f(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lcom/amar/library/ui/StickyScrollView;->E(Lcom/amar/library/ui/StickyScrollView;Landroid/view/View;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/amar/library/ui/StickyScrollView;->A(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Lcom/amar/library/ui/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v1, v0}, Lcom/amar/library/ui/d;-><init>(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public g()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/amar/library/ui/StickyScrollView$c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView;->B(Lcom/amar/library/ui/StickyScrollView;)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x7

    move v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Lcom/amar/library/ui/a;->a:Lcom/amar/library/ui/a;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    invoke-virtual {v2, v0, v1}, Lcom/amar/library/ui/a;->a(Landroid/view/View;F)V

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method
