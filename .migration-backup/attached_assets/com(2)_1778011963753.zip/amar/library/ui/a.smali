.class public final Lcom/amar/library/ui/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lcom/amar/library/ui/a;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    new-instance v0, Lcom/amar/library/ui/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/amar/library/ui/a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    sput-object v0, Lcom/amar/library/ui/a;->a:Lcom/amar/library/ui/a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;F)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "-@so~~ M~@oft/o@~m@ ~ ~ ~ ~@~@ ~@@~@  4@~l  n/ i~l@ @@~~@d@v @cu~si~ ~~o@o r@K~abfb@.t1@o biS y~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1, p2}, Landroidx/core/view/k1;->w2(Landroid/view/View;F)V

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method
