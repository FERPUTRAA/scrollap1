.class public final synthetic Lcom/amar/library/ui/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/amar/library/ui/StickyScrollView;


# direct methods
.method public synthetic constructor <init>(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/amar/library/ui/c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osno@u  1 .~ @m@@-   @@l @oy~@~i~ 4@@btt@ sb~ @o@/o~@o~ ri@ ~c@@lS~@d~~MfKi~@~~b ~ ~af~~@/~  v~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/amar/library/ui/c;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView$c;->i(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
