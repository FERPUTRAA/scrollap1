.class public final synthetic Lcom/amar/library/ui/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/amar/library/ui/StickyScrollView;


# direct methods
.method public synthetic constructor <init>(Lcom/amar/library/ui/StickyScrollView;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/amar/library/ui/d;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s4~@a@~ ~ @o~@t@od@u~yo~rsS l-@v~f@ i@~i @n /b1@ ~~ K~~ to.o@bi~~~@@/~  c@l   o@~ ~@~mb~M  @f@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/amar/library/ui/d;->a:Lcom/amar/library/ui/StickyScrollView;

    const/4 v1, 0x7

    move v2, v1

    invoke-static {v0}, Lcom/amar/library/ui/StickyScrollView$c;->h(Lcom/amar/library/ui/StickyScrollView;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
