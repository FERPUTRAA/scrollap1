.class public final synthetic Lcom/amar/library/ui/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/DisplayCutout;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/view/DisplayCutout;->getSafeInsetTop()I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    return p0
.end method
