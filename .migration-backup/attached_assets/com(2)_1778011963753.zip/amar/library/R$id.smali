.class public final Lcom/amar/library/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/amar/library/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final accessibility_action_clickable_span:I = 0x7f090020

.field public static final accessibility_custom_action_0:I = 0x7f090021

.field public static final accessibility_custom_action_1:I = 0x7f090022

.field public static final accessibility_custom_action_10:I = 0x7f090023

.field public static final accessibility_custom_action_11:I = 0x7f090024

.field public static final accessibility_custom_action_12:I = 0x7f090025

.field public static final accessibility_custom_action_13:I = 0x7f090026

.field public static final accessibility_custom_action_14:I = 0x7f090027

.field public static final accessibility_custom_action_15:I = 0x7f090028

.field public static final accessibility_custom_action_16:I = 0x7f090029

.field public static final accessibility_custom_action_17:I = 0x7f09002a

.field public static final accessibility_custom_action_18:I = 0x7f09002b

.field public static final accessibility_custom_action_19:I = 0x7f09002c

.field public static final accessibility_custom_action_2:I = 0x7f09002d

.field public static final accessibility_custom_action_20:I = 0x7f09002e

.field public static final accessibility_custom_action_21:I = 0x7f09002f

.field public static final accessibility_custom_action_22:I = 0x7f090030

.field public static final accessibility_custom_action_23:I = 0x7f090031

.field public static final accessibility_custom_action_24:I = 0x7f090032

.field public static final accessibility_custom_action_25:I = 0x7f090033

.field public static final accessibility_custom_action_26:I = 0x7f090034

.field public static final accessibility_custom_action_27:I = 0x7f090035

.field public static final accessibility_custom_action_28:I = 0x7f090036

.field public static final accessibility_custom_action_29:I = 0x7f090037

.field public static final accessibility_custom_action_3:I = 0x7f090038

.field public static final accessibility_custom_action_30:I = 0x7f090039

.field public static final accessibility_custom_action_31:I = 0x7f09003a

.field public static final accessibility_custom_action_4:I = 0x7f09003b

.field public static final accessibility_custom_action_5:I = 0x7f09003c

.field public static final accessibility_custom_action_6:I = 0x7f09003d

.field public static final accessibility_custom_action_7:I = 0x7f09003e

.field public static final accessibility_custom_action_8:I = 0x7f09003f

.field public static final accessibility_custom_action_9:I = 0x7f090040

.field public static final action_bar:I = 0x7f09004b

.field public static final action_bar_activity_content:I = 0x7f09004c

.field public static final action_bar_container:I = 0x7f09004d

.field public static final action_bar_root:I = 0x7f09004e

.field public static final action_bar_spinner:I = 0x7f09004f

.field public static final action_bar_subtitle:I = 0x7f090050

.field public static final action_bar_title:I = 0x7f090051

.field public static final action_container:I = 0x7f090052

.field public static final action_context_bar:I = 0x7f090053

.field public static final action_divider:I = 0x7f090054

.field public static final action_image:I = 0x7f090055

.field public static final action_menu_divider:I = 0x7f090056

.field public static final action_menu_presenter:I = 0x7f090057

.field public static final action_mode_bar:I = 0x7f090058

.field public static final action_mode_bar_stub:I = 0x7f090059

.field public static final action_mode_close_button:I = 0x7f09005a

.field public static final action_text:I = 0x7f09005b

.field public static final actions:I = 0x7f09005d

.field public static final activity_chooser_view_content:I = 0x7f09005f

.field public static final add:I = 0x7f090061

.field public static final alertTitle:I = 0x7f090071

.field public static final async:I = 0x7f090082

.field public static final blocking:I = 0x7f0900b8

.field public static final buttonPanel:I = 0x7f090133

.field public static final checkbox:I = 0x7f090155

.field public static final checked:I = 0x7f090156

.field public static final chronometer:I = 0x7f090161

.field public static final content:I = 0x7f0901b5

.field public static final contentPanel:I = 0x7f0901b7

.field public static final custom:I = 0x7f0901de

.field public static final customPanel:I = 0x7f0901df

.field public static final decor_content_parent:I = 0x7f0901f9

.field public static final default_activity_button:I = 0x7f0901fb

.field public static final dialog_button:I = 0x7f09020c

.field public static final edit_query:I = 0x7f090247

.field public static final expand_activities_button:I = 0x7f090280

.field public static final expanded_menu:I = 0x7f090281

.field public static final forever:I = 0x7f0902a7

.field public static final group_divider:I = 0x7f0902eb

.field public static final home:I = 0x7f090307

.field public static final icon:I = 0x7f090318

.field public static final icon_group:I = 0x7f09031a

.field public static final image:I = 0x7f09031f

.field public static final info:I = 0x7f090385

.field public static final italic:I = 0x7f090391

.field public static final line1:I = 0x7f0904ef

.field public static final line3:I = 0x7f0904f1

.field public static final listMode:I = 0x7f0904fb

.field public static final list_item:I = 0x7f0904fd

.field public static final message:I = 0x7f0905b3

.field public static final multiply:I = 0x7f0905e3

.field public static final none:I = 0x7f0905fe

.field public static final normal:I = 0x7f0905ff

.field public static final notification_background:I = 0x7f090602

.field public static final notification_main_column:I = 0x7f090603

.field public static final notification_main_column_container:I = 0x7f090604

.field public static final off:I = 0x7f090626

.field public static final on:I = 0x7f09062a

.field public static final parentPanel:I = 0x7f090646

.field public static final progress_circular:I = 0x7f090687

.field public static final progress_horizontal:I = 0x7f090688

.field public static final radio:I = 0x7f0906aa

.field public static final right_icon:I = 0x7f0906ca

.field public static final right_side:I = 0x7f0906cb

.field public static final screen:I = 0x7f090709

.field public static final scrollIndicatorDown:I = 0x7f09070b

.field public static final scrollIndicatorUp:I = 0x7f09070c

.field public static final scrollView:I = 0x7f09070d

.field public static final search_badge:I = 0x7f090713

.field public static final search_bar:I = 0x7f090714

.field public static final search_button:I = 0x7f090715

.field public static final search_close_btn:I = 0x7f090716

.field public static final search_edit_frame:I = 0x7f090718

.field public static final search_go_btn:I = 0x7f090719

.field public static final search_mag_icon:I = 0x7f09071a

.field public static final search_plate:I = 0x7f09071b

.field public static final search_src_text:I = 0x7f09071c

.field public static final search_voice_btn:I = 0x7f09071d

.field public static final select_dialog_listview:I = 0x7f090727

.field public static final shortcut:I = 0x7f090737

.field public static final spacer:I = 0x7f090752

.field public static final split_action_bar:I = 0x7f090756

.field public static final src_atop:I = 0x7f09075b

.field public static final src_in:I = 0x7f09075c

.field public static final src_over:I = 0x7f09075d

.field public static final submenuarrow:I = 0x7f090778

.field public static final submit_area:I = 0x7f09077b

.field public static final tabMode:I = 0x7f09079c

.field public static final tag_accessibility_actions:I = 0x7f0907a1

.field public static final tag_accessibility_clickable_spans:I = 0x7f0907a2

.field public static final tag_accessibility_heading:I = 0x7f0907a3

.field public static final tag_accessibility_pane_title:I = 0x7f0907a4

.field public static final tag_screen_reader_focusable:I = 0x7f0907aa

.field public static final tag_transition_group:I = 0x7f0907ad

.field public static final tag_unhandled_key_event_manager:I = 0x7f0907af

.field public static final tag_unhandled_key_listeners:I = 0x7f0907b0

.field public static final text:I = 0x7f0907b7

.field public static final text2:I = 0x7f0907ba

.field public static final textSpacerNoButtons:I = 0x7f0907c0

.field public static final textSpacerNoTitle:I = 0x7f0907c1

.field public static final time:I = 0x7f09082f

.field public static final title:I = 0x7f090834

.field public static final titleDividerNoCustom:I = 0x7f090836

.field public static final title_template:I = 0x7f09083d

.field public static final topPanel:I = 0x7f090846

.field public static final unchecked:I = 0x7f090a88

.field public static final uniform:I = 0x7f090a89

.field public static final up:I = 0x7f090a8c

.field public static final wrap_content:I = 0x7f090aed


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
