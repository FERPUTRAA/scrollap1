.class public Lcom/alibaba/fastjson/serializer/g;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/g;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/alibaba/fastjson/serializer/g;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/g;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object v0, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@/s~@@@ c ~@@mll an@~@~ir   ~b@oo~@4~@~ b/1K~ o@@i~~ t~S~@b@-~ @~ t  id~f .s~@My~@  ~f~ oo~u~ov@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/16 v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 p2, 0x10

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-class v0, Lcom/alibaba/fastjson/b;

    const-class v0, Lcom/alibaba/fastjson/b;

    const/4 v3, 0x4

    const-class v0, Lcom/alibaba/fastjson/b;

    const-class v0, Lcom/alibaba/fastjson/b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne p2, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p2, Lcom/alibaba/fastjson/b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p2}, Lcom/alibaba/fastjson/b;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/parser/b;->K(Ljava/util/Collection;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p2

    :cond_1
    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_a

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/Class;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-class v1, Ljava/util/AbstractCollection;

    const-class v1, Ljava/util/AbstractCollection;

    const/4 v3, 0x0

    const-class v1, Ljava/util/AbstractCollection;

    const-class v1, Ljava/util/AbstractCollection;

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq v0, v1, :cond_9

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-class v1, Ljava/util/Collection;

    const-class v1, Ljava/util/Collection;

    const-class v1, Ljava/util/Collection;

    const-class v1, Ljava/util/Collection;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v0, v1, :cond_2

    const/4 v3, 0x4

    goto/16 :goto_2

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v1, Ljava/util/HashSet;

    const/4 v3, 0x7

    const-class v1, Ljava/util/HashSet;

    const-class v1, Ljava/util/HashSet;

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto/16 :goto_3

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-class v1, Ljava/util/LinkedHashSet;

    const-class v1, Ljava/util/LinkedHashSet;

    const-class v1, Ljava/util/LinkedHashSet;

    const-class v1, Ljava/util/LinkedHashSet;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/util/LinkedHashSet;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto/16 :goto_3

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-class v1, Ljava/util/TreeSet;

    const-class v1, Ljava/util/TreeSet;

    const/4 v3, 0x0

    const-class v1, Ljava/util/TreeSet;

    const-class v1, Ljava/util/TreeSet;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/util/TreeSet;

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto/16 :goto_3

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-class v1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const-class v1, Ljava/util/ArrayList;

    const-class v1, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto/16 :goto_3

    :cond_6
    const/4 v3, 0x7

    const-class v1, Ljava/util/EnumSet;

    const-class v1, Ljava/util/EnumSet;

    const/4 v3, 0x2

    const-class v1, Ljava/util/EnumSet;

    const-class v1, Ljava/util/EnumSet;

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_8

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    instance-of v0, p2, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_7

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    move v3, v2

    aget-object v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_1

    :cond_7
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v3, 0x5

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/Class;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_3

    :cond_8
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v1, Ljava/util/Collection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_3

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p3, "ar,m rnssoeer cctrnitasesle "

    const-string/jumbo p3, "tns e,corrreiraensce a stls "

    const/4 v3, 0x5

    const-string/jumbo p3, "norao,eealsrers t airsct nce"

    const-string p3, "create instane error, class "

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    throw p1

    :cond_9
    :goto_2
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_3
    const/4 v3, 0x0

    invoke-static {p2}, Lq0/d;->E(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2, v0, p3}, Lcom/alibaba/fastjson/parser/b;->J(Ljava/lang/reflect/Type;Ljava/util/Collection;Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_a
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    if-eqz v1, :cond_b

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto/16 :goto_0

    :cond_b
    const/4 v3, 0x3

    const/4 v2, 0x4

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p2, "ODOT"

    const-string p2, "ODTO"

    const/4 v3, 0x5

    const-string p2, "DTOO"

    const-string p2, "TODO"

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    throw p1
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v7, 0x5

    const/4 v6, 0x3

    if-nez p2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget p1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget-object p2, Lcom/alibaba/fastjson/serializer/a0;->f:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget p2, p2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr p1, p2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string p1, "[]"

    const-string p1, "[]"

    const/4 v7, 0x5

    const-string p1, "]["

    const-string p1, "[]"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget v1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget v3, v2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    and-int/2addr v1, v3

    const/4 v7, 0x0

    if-eqz v1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p4}, Lq0/d;->E(Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object p4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 p4, 0x0

    :goto_1
    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v1, Ljava/util/Collection;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v3, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, v3, p2, p3, v4}, Lcom/alibaba/fastjson/serializer/m;->t(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget p2, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget p3, v2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    and-int/2addr p2, p3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p2, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-class p3, Ljava/util/HashSet;

    const-class p3, Ljava/util/HashSet;

    const/4 v7, 0x7

    const-class p3, Ljava/util/HashSet;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ne p3, p2, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string p2, "etS"

    const-string/jumbo p2, "tSe"

    const/4 v7, 0x7

    const-string p2, "eSt"

    const-string p2, "Set"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v6, 0x5

    and-int/2addr v7, v6

    goto :goto_2

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-class p3, Ljava/util/TreeSet;

    const-class p3, Ljava/util/TreeSet;

    const/4 v7, 0x5

    const-class p3, Ljava/util/TreeSet;

    const-class p3, Ljava/util/TreeSet;

    const/4 v7, 0x2

    const/4 v6, 0x4

    if-ne p3, p2, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string p2, "eSTeebr"

    const-string p2, "TeemrSe"

    const/4 v7, 0x3

    const-string/jumbo p2, "rSeeteu"

    const-string p2, "TreeSet"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    :cond_4
    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/16 p2, 0x5b

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_3
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz p3, :cond_a

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v1, v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v4, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/16 v2, 0x2c

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x6

    if-nez p3, :cond_6

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto/16 :goto_4

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-class v4, Ljava/lang/Integer;

    const-class v4, Ljava/lang/Integer;

    const/4 v7, 0x5

    const-class v4, Ljava/lang/Integer;

    const-class v4, Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ne v2, v4, :cond_7

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    check-cast p3, Ljava/lang/Integer;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, p3}, Lcom/alibaba/fastjson/serializer/z;->t(I)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_4

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-class v4, Ljava/lang/Long;

    const-class v4, Ljava/lang/Long;

    const-class v4, Ljava/lang/Long;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-ne v2, v4, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast p3, Ljava/lang/Long;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0, v4, v5}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget p3, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x0

    iget v2, v2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x6

    and-int/2addr p3, v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz p3, :cond_9

    const/4 v7, 0x6

    const/16 p3, 0x4c

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, p3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_4

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v4, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v4, v2}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    add-int/lit8 v4, v1, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v2, p1, p3, v4, p4}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    :cond_9
    :goto_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    move v4, v1

    move v4, v1

    const/4 v7, 0x4

    move v4, v1

    move v4, v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto/16 :goto_3

    :cond_a
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/16 p2, 0x5d

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v3, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :catchall_0
    move-exception p2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    iput-object v3, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw p2
.end method
