.class Lcom/alibaba/fastjson/serializer/i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~ifo~1~@t @o~ o~~b~/ @ ~~ufcs@o@ ~4l SM.d@b@~ ~ an@ @i~r~~v@t K  -@~@b @@~/@l~o~ @ @i~ ~@y m~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget p3, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    sget-object p4, Lcom/alibaba/fastjson/serializer/a0;->d:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget p4, p4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    and-int/2addr p3, p4

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p3, :cond_2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p2, Ljava/lang/Enum;

    const/4 v1, 0x2

    invoke-virtual {p2}, Ljava/lang/Enum;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p3, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v0, 0x1

    const/4 v0, 0x2

    sget-object p4, Lcom/alibaba/fastjson/serializer/a0;->b:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p4, p4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    and-int/2addr p3, p4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 p4, 0x2

    const/4 p4, 0x0

    const/4 v0, 0x1

    shr-int/2addr v1, v0

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 p3, 0x1

    shl-int/2addr v1, p3

    const/4 v0, 0x3

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    move p3, p4

    move p3, p4

    :goto_0
    const/4 v1, 0x4

    if-eqz p3, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->N(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, p2, p4, p4}, Lcom/alibaba/fastjson/serializer/z;->K(Ljava/lang/String;CZ)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    goto :goto_1

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/Enum;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->t(I)V

    :goto_1
    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
