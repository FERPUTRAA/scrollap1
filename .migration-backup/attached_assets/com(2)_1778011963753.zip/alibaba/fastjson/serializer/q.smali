.class public final Lcom/alibaba/fastjson/serializer/q;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/q;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lcom/alibaba/fastjson/serializer/q;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/q;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object v0, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "-~s@~ntouo~~@d~@ bb~@a o@i@@1.@~~~f t rl @ @@ ~oo@M ~f ~~@~@  ~ @ ~yo/bi@4~@@K mc @s ~l~ /~@v~i~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    const-class p3, Ljava/lang/StackTraceElement;

    const-class p3, Ljava/lang/StackTraceElement;

    const/4 v7, 0x6

    const-class p3, Ljava/lang/StackTraceElement;

    const-class p3, Ljava/lang/StackTraceElement;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-ne p2, p3, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/serializer/q;->c(Lcom/alibaba/fastjson/parser/b;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-object p1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object p3, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v0, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v1, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ne v0, v1, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput v2, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/16 v0, 0x10

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v3, 0x4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v4, "ryxmarstrn s"

    const-string/jumbo v4, "yssrnre atrx"

    const/4 v7, 0x7

    const-string/jumbo v4, "xsroot arren"

    const-string/jumbo v4, "syntax error"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ne v0, v3, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v0, "avl"

    const-string/jumbo v0, "lva"

    const/4 v7, 0x0

    const-string/jumbo v0, "val"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->t()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/16 p3, 0x11

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, p3}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v0, 0xd

    const/4 v7, 0x4

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p1, v4}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    throw p1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {p1, v4}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    throw p1

    :cond_3
    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-nez p3, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v0

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    instance-of v3, p3, Ljava/lang/String;

    const/4 v7, 0x7

    const-class v4, Ljava/util/Currency;

    const-class v4, Ljava/util/Currency;

    const/4 v7, 0x2

    const-class v4, Ljava/util/Currency;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v3, :cond_14

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast p3, Ljava/lang/String;

    const/4 v7, 0x7

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    if-nez v3, :cond_5

    const/4 v7, 0x0

    return-object v0

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-class v3, Ljava/util/UUID;

    const-class v3, Ljava/util/UUID;

    const/4 v7, 0x4

    const-class v3, Ljava/util/UUID;

    const-class v3, Ljava/util/UUID;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-ne p2, v3, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p3}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-object p1

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-class v3, Ljava/lang/Class;

    const-class v3, Ljava/lang/Class;

    const/4 v7, 0x6

    const-class v3, Ljava/lang/Class;

    const-class v3, Ljava/lang/Class;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ne p2, v3, :cond_7

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object p1, p1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object p1, p1, Lcom/alibaba/fastjson/parser/m;->c:Ljava/lang/ClassLoader;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {p3, p1, v2}, Lq0/d;->Q(Ljava/lang/String;Ljava/lang/ClassLoader;Z)Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-object p1

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-class v3, Ljava/util/Locale;

    const-class v3, Ljava/util/Locale;

    const-class v3, Ljava/util/Locale;

    const-class v3, Ljava/util/Locale;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    if-ne p2, v3, :cond_a

    const/4 v7, 0x2

    const-string p1, "_"

    const-string p1, "_"

    const/4 v7, 0x0

    const-string p1, "_"

    const-string p1, "_"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    array-length p2, p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    if-ne p2, v5, :cond_8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p2, Ljava/util/Locale;

    const/4 v7, 0x7

    aget-object p1, p1, v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {p2, p1}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    return-object p2

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    array-length p2, p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-ne p2, v1, :cond_9

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance p2, Ljava/util/Locale;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget-object p3, p1, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    aget-object p1, p1, v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {p2, p3, p1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object p2

    :cond_9
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p2, Ljava/util/Locale;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    aget-object p3, p1, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    aget-object v0, p1, v5

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    aget-object p1, p1, v1

    const/4 v7, 0x5

    invoke-direct {p2, p3, v0, p1}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-object p2

    :cond_a
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-class v1, Ljava/net/URI;

    const-class v1, Ljava/net/URI;

    const/4 v7, 0x1

    const-class v1, Ljava/net/URI;

    const-class v1, Ljava/net/URI;

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    if-ne p2, v1, :cond_b

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p3}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object p1

    :cond_b
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-class v1, Ljava/net/URL;

    const-class v1, Ljava/net/URL;

    const/4 v7, 0x5

    const-class v1, Ljava/net/URL;

    const-class v1, Ljava/net/URL;

    const/4 v6, 0x5

    move v7, v6

    if-ne p2, v1, :cond_c

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance p1, Ljava/net/URL;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p1, p3}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object p1

    :catch_0
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo p3, "rr elbeectra rrm"

    const-string/jumbo p3, "lrrmcetae  rreur"

    const/4 v7, 0x3

    const-string/jumbo p3, "ra c ouleurererr"

    const-string p3, "create url error"

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-direct {p2, p3, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    throw p2

    :cond_c
    const/4 v7, 0x7

    const-class v1, Ljava/util/regex/Pattern;

    const-class v1, Ljava/util/regex/Pattern;

    const/4 v7, 0x2

    const-class v1, Ljava/util/regex/Pattern;

    const-class v1, Ljava/util/regex/Pattern;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ne p2, v1, :cond_d

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {p3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object p1

    :cond_d
    const/4 v7, 0x2

    const-class v1, Ljava/nio/charset/Charset;

    const-class v1, Ljava/nio/charset/Charset;

    const/4 v7, 0x0

    const-class v1, Ljava/nio/charset/Charset;

    const-class v1, Ljava/nio/charset/Charset;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ne p2, v1, :cond_e

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p3}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-object p1

    :cond_e
    const/4 v7, 0x5

    const/4 v6, 0x5

    if-ne p2, v4, :cond_f

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p3}, Ljava/util/Currency;->getInstance(Ljava/lang/String;)Ljava/util/Currency;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-object p1

    :cond_f
    const/4 v6, 0x5

    const/4 v7, 0x3

    const-class v1, Ljava/text/SimpleDateFormat;

    const-class v1, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x0

    const-class v1, Ljava/text/SimpleDateFormat;

    const-class v1, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-ne p2, v1, :cond_10

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance p2, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v0, v0, Lcom/alibaba/fastjson/parser/e;->n:Ljava/util/Locale;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-direct {p2, p3, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v6, 0x1

    move v7, v6

    iget-object p1, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object p1, p1, Lcom/alibaba/fastjson/parser/e;->m:Ljava/util/TimeZone;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-object p2

    :cond_10
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object p1, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eq p2, p1, :cond_13

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-class p1, Ljava/lang/Character;

    const-class p1, Ljava/lang/Character;

    const/4 v7, 0x2

    const-class p1, Ljava/lang/Character;

    const-class p1, Ljava/lang/Character;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne p2, p1, :cond_11

    const/4 v7, 0x6

    goto/16 :goto_1

    :cond_11
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    instance-of p1, p2, Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p1, :cond_12

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    check-cast p2, Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string p2, "Utirore..dnoida"

    const/4 v7, 0x7

    const-string p2, "arnd.reptionUi."

    const-string p2, "android.net.Uri"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz p1, :cond_12

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo p2, "pebqr"

    const-string p2, "bprae"

    const/4 v7, 0x5

    const-string p2, "assep"

    const-string/jumbo p2, "parse"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-array v1, v5, [Ljava/lang/Class;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const-class v3, Ljava/lang/String;

    const-class v3, Ljava/lang/String;

    const/4 v7, 0x6

    const-class v3, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    aput-object v3, v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p1, p2, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-array p2, v5, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    aput-object p3, p2, v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, v0, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object p1

    :catch_1
    move-exception p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo p3, "rnome n.drrrrrUt asdi.peioe."

    const-string/jumbo p3, "parse android.net.Uri error."

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {p2, p3, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    throw p2

    :cond_12
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p3}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-object p1

    :cond_13
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p3}, Lq0/d;->k(Ljava/lang/Object;)Ljava/lang/Character;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object p1

    :cond_14
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    instance-of p1, p3, Lcom/alibaba/fastjson/e;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz p1, :cond_17

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    check-cast p3, Lcom/alibaba/fastjson/e;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ne p2, v4, :cond_16

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo p1, "rrnyoeuu"

    const-string p1, "cryureun"

    const/4 v7, 0x3

    const-string/jumbo p1, "rcncebyr"

    const-string p1, "currency"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p3, p1}, Lcom/alibaba/fastjson/e;->O0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p1, :cond_15

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p1}, Ljava/util/Currency;->getInstance(Ljava/lang/String;)Ljava/util/Currency;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object p1

    :cond_15
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string/jumbo p1, "occreeunpCdu"

    const-string/jumbo p1, "yrcocCepndue"

    const/4 v7, 0x6

    const-string p1, "crnreyepoCcd"

    const-string p1, "currencyCode"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p3, p1}, Lcom/alibaba/fastjson/e;->O0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz p1, :cond_16

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p1}, Ljava/util/Currency;->getInstance(Ljava/lang/String;)Ljava/util/Currency;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    return-object p1

    :cond_16
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-class p1, Ljava/util/Map$Entry;

    const-class p1, Ljava/util/Map$Entry;

    const/4 v7, 0x6

    const-class p1, Ljava/util/Map$Entry;

    const-class p1, Ljava/util/Map$Entry;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-ne p2, p1, :cond_17

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p3}, Lcom/alibaba/fastjson/e;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-object p1

    :cond_17
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo p2, "snerpeu qgv itxqeal"

    const-string p2, "ereilt  qunexcapvgs"

    const/4 v7, 0x4

    const-string p2, "ees  gxaunlvietstrc"

    const-string p2, "except string value"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    throw p1
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v0, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez p2, :cond_3

    const/4 v7, 0x1

    sget-object p2, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eq p4, p2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-class p2, Ljava/lang/Character;

    const-class p2, Ljava/lang/Character;

    const/4 v7, 0x2

    const-class p2, Ljava/lang/Character;

    const-class p2, Ljava/lang/Character;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne p4, p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget p1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x6

    sget-object p2, Lcom/alibaba/fastjson/serializer/a0;->f:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget p2, p2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    and-int/2addr p1, p2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz p1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p4}, Lq0/d;->C(Ljava/lang/reflect/Type;)Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-class p2, Ljava/util/Enumeration;

    const-class p2, Ljava/util/Enumeration;

    const/4 v7, 0x7

    const-class p2, Ljava/util/Enumeration;

    const-class p2, Ljava/util/Enumeration;

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string p1, "[]"

    const-string p1, "]["

    const/4 v7, 0x2

    const-string p1, "[]"

    const-string p1, "[]"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-void

    :cond_3
    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    instance-of v1, p2, Ljava/util/regex/Pattern;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    check-cast p2, Ljava/util/regex/Pattern;

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/util/regex/Pattern;->pattern()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto/16 :goto_5

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    instance-of v1, p2, Ljava/util/TimeZone;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v1, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast p2, Ljava/util/TimeZone;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto/16 :goto_5

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    instance-of v1, p2, Ljava/util/Currency;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz v1, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x4

    check-cast p2, Ljava/util/Currency;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/util/Currency;->getCurrencyCode()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto/16 :goto_5

    :cond_6
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    instance-of v1, p2, Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v1, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    check-cast p2, Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x2

    goto/16 :goto_5

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    instance-of v1, p2, Ljava/lang/Character;

    const/4 v6, 0x5

    and-int/2addr v7, v6

    if-eqz v1, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast p2, Ljava/lang/Character;

    const/4 v6, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p2}, Ljava/lang/Character;->charValue()C

    move-result p3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-nez p3, :cond_8

    const/4 v7, 0x4

    const-string p2, "000m/s"

    const-string p2, "00s00/"

    const/4 v7, 0x7

    const-string p2, "00/0ou"

    const-string p2, "\u0000"

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto/16 :goto_5

    :cond_8
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/lang/Character;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto/16 :goto_5

    :cond_9
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    instance-of v1, p2, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 v2, 0x2c

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v1, :cond_b

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    const/4 v7, 0x7

    const/4 v6, 0x2

    check-cast p3, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p3}, Ljava/text/SimpleDateFormat;->toPattern()Ljava/lang/String;

    move-result-object p3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget-object v4, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget v4, v4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    and-int/2addr v1, v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v1, :cond_a

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v1, p4, :cond_a

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/16 p4, 0x7b

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, p4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string p4, "by@em"

    const-string/jumbo p4, "yepm@"

    const/4 v7, 0x6

    const-string/jumbo p4, "tup@e"

    const-string p4, "@type"

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, p4, v3}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string p1, "avl"

    const-string/jumbo p1, "vla"

    const/4 v7, 0x6

    const-string/jumbo p1, "lav"

    const-string/jumbo p1, "val"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, p1, v3}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, p3}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 p1, 0x7d

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void

    :cond_a
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, p3}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto/16 :goto_5

    :cond_b
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    instance-of v1, p2, Lcom/alibaba/fastjson/g;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v1, :cond_c

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    check-cast p2, Lcom/alibaba/fastjson/g;

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-interface {p2, v0}, Lcom/alibaba/fastjson/g;->a(Ljava/lang/Appendable;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto/16 :goto_5

    :cond_c
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    instance-of v1, p2, Lcom/alibaba/fastjson/c;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v1, :cond_d

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    check-cast p2, Lcom/alibaba/fastjson/c;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {p2}, Lcom/alibaba/fastjson/c;->b()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto/16 :goto_5

    :cond_d
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    instance-of v1, p2, Lcom/alibaba/fastjson/serializer/l;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v1, :cond_e

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast p2, Lcom/alibaba/fastjson/serializer/l;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-interface {p2, p1, p3, p4}, Lcom/alibaba/fastjson/serializer/l;->a(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto/16 :goto_5

    :cond_e
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    instance-of v1, p2, Ljava/util/Enumeration;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v1, :cond_13

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget v1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v4, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget v4, v4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    and-int/2addr v1, v4

    const/4 v7, 0x2

    if-eqz v1, :cond_f

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    instance-of v1, p4, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x3

    if-eqz v1, :cond_f

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    check-cast p4, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {p4}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-object p4, p4, v3

    const/4 v7, 0x6

    goto :goto_2

    :cond_f
    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 p4, 0x0

    :goto_2
    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x0

    const/4 v6, 0x5

    check-cast v1, Ljava/util/Enumeration;

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget-object v4, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x5

    invoke-virtual {p1, v4, p2, p3, v3}, Lcom/alibaba/fastjson/serializer/m;->t(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/16 p2, 0x5b

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_3
    const/4 v7, 0x6

    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result p2

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-eqz p2, :cond_12

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-int/lit8 p3, v3, 0x1

    const/4 v7, 0x3

    if-eqz v3, :cond_10

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_10
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez p2, :cond_11

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_4

    :cond_11
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v5, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v5, v3}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    add-int/lit8 v5, p3, -0x1

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v3, p1, p2, v5, p4}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    :goto_4
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    move v3, p3

    move v3, p3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_3

    :cond_12
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/16 p2, 0x5d

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    iput-object v4, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_5

    :catchall_0
    move-exception p2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput-object v4, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    throw p2

    :cond_13
    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    :goto_5
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-void
.end method

.method protected c(Lcom/alibaba/fastjson/parser/b;)Ljava/lang/Object;
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            ")TT;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    iget-object v1, v0, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v2

    const/4 v3, 0x0

    const/16 v4, 0x8

    if-ne v2, v4, :cond_0

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->t()V

    return-object v3

    :cond_0
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v2

    const/16 v5, 0xc

    const/16 v6, 0x10

    if-eq v2, v5, :cond_2

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v2

    if-ne v2, v6, :cond_1

    goto :goto_0

    :cond_1
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " ar renpr:oxsy"

    const-string v3, " xrso:neoarry "

    const-string/jumbo v3, "noarerxrqs t: "

    const-string/jumbo v3, "syntax error: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    invoke-static {v1}, Lcom/alibaba/fastjson/parser/f;->a(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    :goto_0
    const/4 v2, 0x0

    move v9, v2

    move v9, v2

    move v9, v2

    move v9, v2

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    move-object v8, v7

    move-object v8, v7

    :cond_3
    :goto_1
    iget-object v10, v0, Lcom/alibaba/fastjson/parser/b;->a:Lcom/alibaba/fastjson/parser/o;

    invoke-virtual {v1, v10}, Lcom/alibaba/fastjson/parser/e;->U(Lcom/alibaba/fastjson/parser/o;)Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0xd

    if-nez v10, :cond_5

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v12

    if-ne v12, v11, :cond_4

    invoke-virtual {v1, v6}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    goto/16 :goto_3

    :cond_4
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v12

    if-ne v12, v6, :cond_5

    goto :goto_1

    :cond_5
    const/16 v12, 0x3a

    invoke-virtual {v1, v12}, Lcom/alibaba/fastjson/parser/e;->v(C)V

    const-string v12, "abseacNml"

    const-string v12, "aasemblNc"

    const-string v12, "className"

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v13, 0x4

    const-string/jumbo v14, "rrrmouxt say"

    const-string v14, "ar srxutroye"

    const-string/jumbo v14, "rrtyosrea xo"

    const-string/jumbo v14, "syntax error"

    if-eqz v12, :cond_8

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v5

    if-ne v5, v4, :cond_6

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    goto/16 :goto_2

    :cond_6
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v5

    if-ne v5, v13, :cond_7

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_2

    :cond_7
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    const-string/jumbo v12, "mpoNtbedma"

    const-string/jumbo v12, "mhNoatepdm"

    const-string v12, "Neamoeudmh"

    const-string/jumbo v12, "methodName"

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_b

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v7

    if-ne v7, v4, :cond_9

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    goto/16 :goto_2

    :cond_9
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v7

    if-ne v7, v13, :cond_a

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v7

    goto/16 :goto_2

    :cond_a
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b
    const-string/jumbo v12, "mieNqlep"

    const-string/jumbo v12, "qNlamiee"

    const-string/jumbo v12, "qfmaeiNl"

    const-string v12, "fileName"

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_e

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v8

    if-ne v8, v4, :cond_c

    move-object v8, v3

    move-object v8, v3

    move-object v8, v3

    goto/16 :goto_2

    :cond_c
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v8

    if-ne v8, v13, :cond_d

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v8

    goto/16 :goto_2

    :cond_d
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    const-string/jumbo v12, "misenlbNur"

    const-string/jumbo v12, "lineNumber"

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_11

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v9

    if-ne v9, v4, :cond_f

    move v9, v2

    move v9, v2

    move v9, v2

    move v9, v2

    goto/16 :goto_2

    :cond_f
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v9

    const/4 v10, 0x2

    if-ne v9, v10, :cond_10

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->k()I

    move-result v9

    goto/16 :goto_2

    :cond_10
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_11
    const-string v12, "eetmtviaohns"

    const-string/jumbo v12, "neseavotMhti"

    const-string/jumbo v12, "tneiohdMatvo"

    const-string/jumbo v12, "nativeMethod"

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_15

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    if-ne v10, v4, :cond_12

    invoke-virtual {v1, v6}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    goto :goto_2

    :cond_12
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    const/4 v12, 0x6

    if-ne v10, v12, :cond_13

    invoke-virtual {v1, v6}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    goto :goto_2

    :cond_13
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    const/4 v12, 0x7

    if-ne v10, v12, :cond_14

    invoke-virtual {v1, v6}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    goto :goto_2

    :cond_14
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_15
    const-string v12, "bempt"

    const-string v12, "@epmt"

    const-string/jumbo v12, "put@y"

    const-string v12, "@type"

    const-string/jumbo v15, "xs rtn:p oar or"

    const-string/jumbo v15, "o etor rxn:as r"

    const-string v15, " ne  xsrqot:rar"

    const-string/jumbo v15, "syntax error : "

    if-ne v10, v12, :cond_19

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    if-ne v10, v13, :cond_17

    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v10

    const-string v12, "ejscvaeTe.n.bgaSncrlltmaaat"

    const-string/jumbo v12, "vaaenbe.kalernagTatcc.Stmjl"

    const-string/jumbo v12, "rammk.jSavEeeaalacn.ltTgnte"

    const-string/jumbo v12, "java.lang.StackTraceElement"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_16

    goto :goto_2

    :cond_16
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_17
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    if-ne v10, v4, :cond_18

    :goto_2
    invoke-virtual {v1}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v10

    if-ne v10, v11, :cond_3

    invoke-virtual {v1, v6}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    :goto_3
    new-instance v0, Ljava/lang/StackTraceElement;

    invoke-direct {v0, v5, v7, v8, v9}, Ljava/lang/StackTraceElement;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    return-object v0

    :cond_18
    new-instance v0, Lcom/alibaba/fastjson/d;

    invoke-direct {v0, v14}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_19
    new-instance v0, Lcom/alibaba/fastjson/d;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw v0
.end method
