.class public final Lcom/alibaba/fastjson/serializer/f;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/f;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/alibaba/fastjson/serializer/f;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/f;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    sput-object v0, Lcom/alibaba/fastjson/serializer/f;->a:Lcom/alibaba/fastjson/serializer/f;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~~ovtc@.K-~~@  @ @1 @@ ~~@@  ~~o~@   ~@/b~~i~ ~ So~da@ ~y/@oofo4bl@r@~@~@@isn i@~~m  b~fuM @l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object p2, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v1, 0x10

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne p3, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2, v1}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v0, 0x7

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    if-ne p3, v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne p3, v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/alibaba/fastjson/parser/e;->k()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, v1}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p2, 0x1

    if-ne p1, p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x0

    goto :goto_0

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez p1, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Lq0/d;->h(Ljava/lang/Object;)Ljava/lang/Boolean;

    move-result-object p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    check-cast p2, Ljava/lang/Boolean;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    const-string p3, "alsme"

    const-string p3, "aessl"

    const/4 v1, 0x5

    const-string p3, "aselo"

    const-string p3, "false"

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p2, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    sget-object p4, Lcom/alibaba/fastjson/serializer/a0;->i:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget p4, p4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    and-int/2addr p2, p4

    const/4 v0, 0x1

    move v1, v0

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p3}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p2, :cond_2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    const-string p2, "ertu"

    const-string/jumbo p2, "rtue"

    const/4 v1, 0x1

    const-string/jumbo p2, "teru"

    const-string/jumbo p2, "true"

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    goto :goto_1

    :cond_2
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1, p3}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    :goto_1
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
