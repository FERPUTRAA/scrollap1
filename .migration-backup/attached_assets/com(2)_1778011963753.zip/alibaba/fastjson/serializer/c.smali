.class final Lcom/alibaba/fastjson/serializer/c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;


# instance fields
.field private final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private final b:Lcom/alibaba/fastjson/serializer/t;


# direct methods
.method constructor <init>(Ljava/lang/Class;Lcom/alibaba/fastjson/serializer/t;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Lcom/alibaba/fastjson/serializer/t;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/c;->a:Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/alibaba/fastjson/serializer/c;->b:Lcom/alibaba/fastjson/serializer/t;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "i~s~y~bt-i@@ ~1 ou@cs@~m@@~b/~~@~~@K4M~oo / o~@.~~fSd a@ @l@~@~n t  v ~r~  @~ @@l@~  ~bf @o@@i~o"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    iget-object p4, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string v0, "]["

    const-string v0, "[]"

    const/4 v10, 0x2

    const-string v0, "[]"

    const-string v0, "[]"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-nez p2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x6

    iget p1, p4, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object p2, Lcom/alibaba/fastjson/serializer/a0;->f:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget p2, p2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    and-int/2addr p1, p2

    const/4 v10, 0x5

    const/4 v9, 0x2

    if-eqz p1, :cond_0

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {p4, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    return-void

    :cond_1
    const/4 v9, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    instance-of v1, p2, [Z

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/16 v2, 0x2c

    const/4 v10, 0x6

    const/16 v3, 0x5d

    const/4 v9, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/16 v4, 0x5b

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz v1, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    check-cast p2, [Z

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_1
    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    array-length p1, p2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-ge v5, p1, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eqz v5, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_2
    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    aget-boolean p1, p2, v5

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->m(Z)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    goto :goto_1

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v9, 0x5

    move v10, v9

    return-void

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    instance-of v1, p2, [B

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz v1, :cond_5

    const/4 v9, 0x2

    and-int/2addr v10, v9

    check-cast p2, [B

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p4, p2}, Lcom/alibaba/fastjson/serializer/z;->p([B)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-void

    :cond_5
    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    instance-of v1, p2, [C

    const/4 v10, 0x7

    const/4 v9, 0x1

    if-eqz v1, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    check-cast p2, [C

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-instance p1, Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {p1, p2}, Ljava/lang/String;-><init>([C)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    return-void

    :cond_6
    const/4 v10, 0x0

    const/4 v9, 0x7

    instance-of v1, p2, [D

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v6, -0x1

    const/4 v10, 0x0

    if-eqz v1, :cond_b

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    check-cast p2, [D

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    array-length p1, p2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    add-int/lit8 p1, p1, -0x1

    if-ne p1, v6, :cond_7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p4, v0}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    return-void

    :cond_7
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ge v5, p1, :cond_9

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    aget-wide v0, p2, v5

    const/4 v9, 0x0

    shl-int/2addr v10, v9

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result p3

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-eqz p3, :cond_8

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_3

    :cond_8
    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    :goto_3
    const/4 v9, 0x2

    move v10, v9

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    goto :goto_2

    :cond_9
    const/4 v9, 0x2

    const/4 v10, 0x1

    aget-wide p1, p2, p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-static {p1, p2}, Ljava/lang/Double;->isNaN(D)Z

    move-result p3

    const/4 v10, 0x2

    const/4 v9, 0x1

    if-eqz p3, :cond_a

    const/4 v9, 0x3

    const/4 v9, 0x5

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_4

    :cond_a
    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-static {p1, p2}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    :goto_4
    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    return-void

    :cond_b
    const/4 v10, 0x5

    const/4 v9, 0x6

    instance-of v1, p2, [F

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eqz v1, :cond_10

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    check-cast p2, [F

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    array-length p1, p2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ne p1, v6, :cond_c

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p4, v0}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    return-void

    :cond_c
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_5
    const/4 v9, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-ge v5, p1, :cond_e

    const/4 v9, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    aget p3, p2, v5

    const/4 v10, 0x5

    invoke-static {p3}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-eqz v0, :cond_d

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_6

    :cond_d
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {p3}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object p3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    :goto_6
    const/4 v10, 0x6

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    goto :goto_5

    :cond_e
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    aget p1, p2, p1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    move-result p2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz p2, :cond_f

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    goto :goto_7

    :cond_f
    const/4 v10, 0x4

    invoke-static {p1}, Ljava/lang/Float;->toString(F)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    :goto_7
    const/4 v10, 0x0

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    return-void

    :cond_10
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    instance-of v0, p2, [I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v0, :cond_13

    const/4 v10, 0x6

    check-cast p2, [I

    const/4 v9, 0x0

    xor-int/2addr v10, v9

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_8
    const/4 v9, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    array-length p1, p2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-ge v5, p1, :cond_12

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v5, :cond_11

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_11
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    aget p1, p2, v5

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->t(I)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_8

    :cond_12
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void

    :cond_13
    const/4 v10, 0x3

    const/4 v9, 0x7

    instance-of v0, p2, [J

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v0, :cond_16

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    check-cast p2, [J

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_9
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    array-length p1, p2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-ge v5, p1, :cond_15

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v5, :cond_14

    const/4 v10, 0x4

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_14
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    aget-wide v0, p2, v5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p4, v0, v1}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto :goto_9

    :cond_15
    const/4 v10, 0x2

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v9, 0x6

    move v10, v9

    return-void

    :cond_16
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    instance-of v0, p2, [S

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz v0, :cond_19

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    check-cast p2, [S

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_a
    const/4 v10, 0x6

    const/4 v9, 0x7

    array-length p1, p2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-ge v5, p1, :cond_18

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-eqz v5, :cond_17

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_17
    const/4 v10, 0x3

    const/4 v9, 0x4

    aget-short p1, p2, v5

    const/4 v9, 0x0

    move v10, v9

    invoke-virtual {p4, p1}, Lcom/alibaba/fastjson/serializer/z;->t(I)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto :goto_a

    :cond_18
    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    return-void

    :cond_19
    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    check-cast v0, [Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    array-length v1, v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v6, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v9, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1, v6, p2, p3, v5}, Lcom/alibaba/fastjson/serializer/m;->t(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V

    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p4, v4}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_b
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ge v5, v1, :cond_1e

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v5, :cond_1a

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p4, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_1a
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    aget-object p3, v0, v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-nez p3, :cond_1c

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    sget-object p3, Lcom/alibaba/fastjson/serializer/a0;->g:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v10, 0x1

    const/4 v9, 0x3

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->j(Lcom/alibaba/fastjson/serializer/a0;)Z

    move-result p3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eqz p3, :cond_1b

    const/4 v9, 0x7

    const/4 v10, 0x1

    instance-of p3, p2, [Ljava/lang/String;

    const/4 v10, 0x0

    if-eqz p3, :cond_1b

    const/4 v9, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string p3, ""

    const-string p3, ""

    const/4 v10, 0x0

    const-string p3, ""

    const-string p3, ""

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_c

    :cond_1b
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string/jumbo p3, "null"

    const-string/jumbo p3, "llun"

    const-string/jumbo p3, "luln"

    const-string/jumbo p3, "null"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_c

    :cond_1c
    const/4 v9, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v7, p0, Lcom/alibaba/fastjson/serializer/c;->a:Ljava/lang/Class;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-ne v4, v7, :cond_1d

    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v4, p0, Lcom/alibaba/fastjson/serializer/c;->b:Lcom/alibaba/fastjson/serializer/t;

    const/4 v10, 0x7

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-interface {v4, p1, p3, v7, v8}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_c

    :cond_1d
    const/4 v9, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v4, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v10, 0x2

    const/4 v9, 0x4

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v4, v7}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-interface {v4, p1, p3, v7, v8}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    :goto_c
    const/4 v10, 0x7

    const/4 v9, 0x3

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto/16 :goto_b

    :cond_1e
    const/4 v9, 0x6

    invoke-virtual {p4, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    iput-object v6, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-void

    :catchall_0
    move-exception p2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-object v6, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    throw p2
.end method
