.class Lcom/alibaba/fastjson/serializer/j$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alibaba/fastjson/serializer/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field a:Lcom/alibaba/fastjson/serializer/t;

.field b:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/serializer/t;Ljava/lang/Class;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/serializer/t;",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/j$a;->a:Lcom/alibaba/fastjson/serializer/t;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method
