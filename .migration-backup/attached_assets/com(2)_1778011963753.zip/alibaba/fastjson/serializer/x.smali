.class public Lcom/alibaba/fastjson/serializer/x;
.super Ljava/lang/Object;


# static fields
.field public static final d:Lcom/alibaba/fastjson/serializer/x;


# instance fields
.field private final a:Lq0/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lq0/b<",
            "Lcom/alibaba/fastjson/serializer/t;",
            ">;"
        }
    .end annotation
.end field

.field protected b:Ljava/lang/String;

.field public c:Lcom/alibaba/fastjson/j;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/alibaba/fastjson/serializer/x;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/x;-><init>()V

    const/4 v1, 0x5

    and-int/2addr v2, v1

    sput-object v0, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v0, "sestp"

    const-string/jumbo v0, "tyspe"

    const/4 v5, 0x6

    const-string/jumbo v0, "y@pme"

    const-string v0, "@type"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Lq0/b;

    const/4 v5, 0x2

    const/16 v1, 0x400

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Lq0/b;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v5, 0x7

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object v2, Lcom/alibaba/fastjson/serializer/f;->a:Lcom/alibaba/fastjson/serializer/f;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-class v2, Ljava/lang/Character;

    const-class v2, Ljava/lang/Character;

    const-class v2, Ljava/lang/Character;

    const-class v2, Ljava/lang/Character;

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-class v2, Ljava/lang/Byte;

    const-class v2, Ljava/lang/Byte;

    const/4 v5, 0x7

    const-class v2, Ljava/lang/Byte;

    const-class v2, Ljava/lang/Byte;

    const/4 v5, 0x3

    const/4 v4, 0x6

    sget-object v3, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-class v2, Ljava/lang/Short;

    const-class v2, Ljava/lang/Short;

    const/4 v5, 0x2

    const-class v2, Ljava/lang/Short;

    const-class v2, Ljava/lang/Short;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v3, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const-class v2, Ljava/lang/Integer;

    const-class v2, Ljava/lang/Integer;

    const/4 v5, 0x3

    const-class v2, Ljava/lang/Integer;

    const-class v2, Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v3, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-class v2, Ljava/lang/Long;

    const-class v2, Ljava/lang/Long;

    const/4 v5, 0x5

    const-class v2, Ljava/lang/Long;

    const-class v2, Ljava/lang/Long;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v3, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object v2, Lcom/alibaba/fastjson/serializer/s;->b:Lcom/alibaba/fastjson/serializer/s;

    const/4 v5, 0x6

    const-class v3, Ljava/lang/Float;

    const-class v3, Ljava/lang/Float;

    const/4 v5, 0x2

    const-class v3, Ljava/lang/Float;

    const-class v3, Ljava/lang/Float;

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-class v3, Ljava/lang/Double;

    const-class v3, Ljava/lang/Double;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-class v3, Ljava/lang/Number;

    const-class v3, Ljava/lang/Number;

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v2, Lcom/alibaba/fastjson/serializer/e;->a:Lcom/alibaba/fastjson/serializer/e;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-class v3, Ljava/math/BigDecimal;

    const-class v3, Ljava/math/BigDecimal;

    const-class v3, Ljava/math/BigDecimal;

    const-class v3, Ljava/math/BigDecimal;

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-class v3, Ljava/math/BigInteger;

    const-class v3, Ljava/math/BigInteger;

    const/4 v5, 0x2

    const-class v3, Ljava/math/BigInteger;

    const-class v3, Ljava/math/BigInteger;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v3, v2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x0

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v3, Lcom/alibaba/fastjson/serializer/c0;->a:Lcom/alibaba/fastjson/serializer/c0;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-class v2, [Ljava/lang/Object;

    const-class v2, [Ljava/lang/Object;

    const-class v2, [Ljava/lang/Object;

    const-class v2, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v3, Lcom/alibaba/fastjson/serializer/b;->a:Lcom/alibaba/fastjson/serializer/b;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-class v2, Ljava/lang/Class;

    const-class v2, Ljava/lang/Class;

    const/4 v5, 0x7

    const-class v2, Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v5, 0x0

    const-class v2, Ljava/text/SimpleDateFormat;

    const-class v2, Ljava/text/SimpleDateFormat;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-class v2, Ljava/util/Locale;

    const-class v2, Ljava/util/Locale;

    const/4 v5, 0x4

    const-class v2, Ljava/util/Locale;

    const-class v2, Ljava/util/Locale;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-class v2, Ljava/util/Currency;

    const-class v2, Ljava/util/Currency;

    const/4 v5, 0x7

    const-class v2, Ljava/util/Currency;

    const-class v2, Ljava/util/Currency;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-class v2, Ljava/util/TimeZone;

    const-class v2, Ljava/util/TimeZone;

    const-class v2, Ljava/util/TimeZone;

    const-class v2, Ljava/util/TimeZone;

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-class v2, Ljava/util/UUID;

    const-class v2, Ljava/util/UUID;

    const/4 v5, 0x0

    const-class v2, Ljava/util/UUID;

    const-class v2, Ljava/util/UUID;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const-class v2, Ljava/net/URI;

    const-class v2, Ljava/net/URI;

    const/4 v5, 0x6

    const-class v2, Ljava/net/URI;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-class v2, Ljava/net/URL;

    const-class v2, Ljava/net/URL;

    const/4 v5, 0x5

    const-class v2, Ljava/net/URL;

    const-class v2, Ljava/net/URL;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-class v2, Ljava/util/regex/Pattern;

    const-class v2, Ljava/util/regex/Pattern;

    const/4 v5, 0x3

    const-class v2, Ljava/util/regex/Pattern;

    const-class v2, Ljava/util/regex/Pattern;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-class v2, Ljava/nio/charset/Charset;

    const-class v2, Ljava/nio/charset/Charset;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v5, 0x5

    return-void
.end method

.method public static final b()Lcom/alibaba/fastjson/serializer/x;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ov~ao@ ~4  @o ~md~ ~~tM~ @nSf@@l@o~~oK@@~s~ @~@ -/ @ @it~~i bb u@/@~yo 1~~f.~@~c@~ @@ o @@ ~~lbi"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/alibaba/fastjson/serializer/t;"
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    check-cast v0, Lcom/alibaba/fastjson/serializer/t;

    const/4 v10, 0x2

    const/4 v9, 0x5

    if-nez v0, :cond_17

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v10, 0x2

    const-class v0, Ljava/util/Map;

    const-class v0, Ljava/util/Map;

    const/4 v10, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v0, :cond_0

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x1

    const/4 v9, 0x6

    new-instance v1, Lcom/alibaba/fastjson/serializer/p;

    const/4 v10, 0x6

    const/4 v9, 0x4

    invoke-direct {v1}, Lcom/alibaba/fastjson/serializer/p;-><init>()V

    const/4 v9, 0x6

    and-int/2addr v10, v9

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    :goto_0
    move-object v0, v1

    move-object v0, v1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto/16 :goto_7

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-class v0, Ljava/util/AbstractSequentialList;

    const-class v0, Ljava/util/AbstractSequentialList;

    const/4 v10, 0x4

    const-class v0, Ljava/util/AbstractSequentialList;

    const-class v0, Ljava/util/AbstractSequentialList;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz v0, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    sget-object v1, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    goto :goto_0

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-class v0, Ljava/util/List;

    const-class v0, Ljava/util/List;

    const/4 v10, 0x0

    const-class v0, Ljava/util/List;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v0, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    new-instance v1, Lcom/alibaba/fastjson/serializer/o;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-direct {v1}, Lcom/alibaba/fastjson/serializer/o;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_0

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const/4 v10, 0x4

    const-class v0, Ljava/util/Collection;

    const-class v0, Ljava/util/Collection;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    sget-object v1, Lcom/alibaba/fastjson/serializer/g;->a:Lcom/alibaba/fastjson/serializer/g;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-class v0, Ljava/util/Date;

    const-class v0, Ljava/util/Date;

    const/4 v10, 0x5

    const-class v0, Ljava/util/Date;

    const-class v0, Ljava/util/Date;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v0, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    sget-object v1, Lcom/alibaba/fastjson/serializer/h;->a:Lcom/alibaba/fastjson/serializer/h;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-class v0, Lcom/alibaba/fastjson/c;

    const-class v0, Lcom/alibaba/fastjson/c;

    const/4 v10, 0x6

    const-class v0, Lcom/alibaba/fastjson/c;

    const-class v0, Lcom/alibaba/fastjson/c;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-eqz v0, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v9, 0x7

    shr-int/2addr v10, v9

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-class v0, Lcom/alibaba/fastjson/serializer/l;

    const-class v0, Lcom/alibaba/fastjson/serializer/l;

    const/4 v10, 0x5

    const-class v0, Lcom/alibaba/fastjson/serializer/l;

    const-class v0, Lcom/alibaba/fastjson/serializer/l;

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v0, :cond_6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_6
    const/4 v10, 0x6

    const-class v0, Lcom/alibaba/fastjson/g;

    const-class v0, Lcom/alibaba/fastjson/g;

    const/4 v10, 0x6

    const-class v0, Lcom/alibaba/fastjson/g;

    const-class v0, Lcom/alibaba/fastjson/g;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-eqz v0, :cond_7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_7
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->isEnum()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    if-nez v0, :cond_16

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v0, :cond_8

    const/4 v10, 0x7

    const/4 v9, 0x3

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v10, 0x2

    const-class v1, Ljava/lang/Object;

    const-class v1, Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eq v0, v1, :cond_8

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->isEnum()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-eqz v0, :cond_8

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto/16 :goto_6

    :cond_8
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->isArray()Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v0, :cond_9

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x7

    const/4 v9, 0x1

    new-instance v3, Lcom/alibaba/fastjson/serializer/c;

    const/4 v10, 0x7

    const/4 v9, 0x4

    invoke-direct {v3, v0, v1}, Lcom/alibaba/fastjson/serializer/c;-><init>(Ljava/lang/Class;Lcom/alibaba/fastjson/serializer/t;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v2, p1, v3}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto/16 :goto_7

    :cond_9
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-class v0, Ljava/lang/Throwable;

    const-class v0, Ljava/lang/Throwable;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v0, :cond_a

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    new-instance v0, Lcom/alibaba/fastjson/serializer/n;

    const/4 v10, 0x7

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/x;->c:Lcom/alibaba/fastjson/j;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {v0, p1, v1}, Lcom/alibaba/fastjson/serializer/n;-><init>(Ljava/lang/Class;Lcom/alibaba/fastjson/j;)V

    const/4 v9, 0x3

    move v10, v9

    iget v1, v0, Lcom/alibaba/fastjson/serializer/n;->c:I

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v9, 0x4

    and-int/2addr v10, v9

    iget v2, v2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    or-int/2addr v1, v2

    const/4 v10, 0x6

    iput v1, v0, Lcom/alibaba/fastjson/serializer/n;->c:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v1, p1, v0}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto/16 :goto_7

    :cond_a
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-class v0, Ljava/util/TimeZone;

    const-class v0, Ljava/util/TimeZone;

    const/4 v10, 0x0

    const-class v0, Ljava/util/TimeZone;

    const-class v0, Ljava/util/TimeZone;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v0, :cond_b

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_b
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-class v0, Ljava/nio/charset/Charset;

    const-class v0, Ljava/nio/charset/Charset;

    const/4 v10, 0x7

    const-class v0, Ljava/nio/charset/Charset;

    const-class v0, Ljava/nio/charset/Charset;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz v0, :cond_c

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto/16 :goto_0

    :cond_c
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-class v0, Ljava/util/Enumeration;

    const-class v0, Ljava/util/Enumeration;

    const/4 v10, 0x0

    const-class v0, Ljava/util/Enumeration;

    const-class v0, Ljava/util/Enumeration;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz v0, :cond_d

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x1

    sget-object v1, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_d
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-class v0, Ljava/util/Calendar;

    const-class v0, Ljava/util/Calendar;

    const/4 v10, 0x2

    const-class v0, Ljava/util/Calendar;

    const-class v0, Ljava/util/Calendar;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz v0, :cond_e

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/h;->a:Lcom/alibaba/fastjson/serializer/h;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_e
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    array-length v1, v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    move v3, v2

    move v3, v2

    const/4 v10, 0x4

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-ge v3, v1, :cond_12

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    aget-object v4, v0, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string v6, ".cmltbobs.pgrxtnfFy.yorec."

    const-string/jumbo v6, "ptfmaFo.cg.l.ycnrbex.tsory"

    const/4 v10, 0x3

    const-string v6, ".cFcsouabryt.itp.nxy.glfro"

    const-string/jumbo v6, "net.sf.cglib.proxy.Factory"

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v6, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-nez v5, :cond_11

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string/jumbo v7, "osramgoppgc.xk.plowgrcbryireF.nrfa.oyir"

    const-string/jumbo v7, "lsrcoFrprapforcwrgmgnrxi.ogoyy.abie.k.o"

    const/4 v10, 0x7

    const-string/jumbo v7, "oywc..rcq.Fgosbxg.rypiaoiogntlfaprmkrer"

    const-string/jumbo v7, "org.springframework.cglib.proxy.Factory"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v5, :cond_f

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    goto :goto_2

    :cond_f
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string v5, "btsyvssoyurOp.iPj.oiaextcrta.xls"

    const-string/jumbo v5, "javassist.util.proxy.ProxyObject"

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x6

    if-eqz v4, :cond_10

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto :goto_3

    :cond_10
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_1

    :cond_11
    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v8, v6

    move v8, v6

    const/4 v10, 0x4

    move v8, v6

    move v8, v6

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    move v6, v2

    move v6, v2

    move v6, v2

    move v6, v2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    move v2, v8

    move v2, v8

    const/4 v10, 0x4

    move v2, v8

    move v2, v8

    const/4 v10, 0x2

    const/4 v9, 0x0

    goto :goto_3

    :cond_12
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    move v6, v2

    move v6, v2

    const/4 v10, 0x6

    move v6, v2

    move v6, v2

    :goto_3
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-nez v2, :cond_15

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v6, :cond_13

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    goto :goto_5

    :cond_13
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string/jumbo v1, "rnrmdidnot.baUei"

    const-string/jumbo v1, "ndioUbdaetrri.n."

    const/4 v10, 0x4

    const-string/jumbo v1, "rd$noite.idra.nU"

    const-string v1, "android.net.Uri$"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v0, :cond_14

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    sget-object v0, Lcom/alibaba/fastjson/serializer/q;->a:Lcom/alibaba/fastjson/serializer/q;

    const/4 v10, 0x2

    goto :goto_4

    :cond_14
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    new-instance v0, Lcom/alibaba/fastjson/serializer/n;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/x;->c:Lcom/alibaba/fastjson/j;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-direct {v0, p1, v1}, Lcom/alibaba/fastjson/serializer/n;-><init>(Ljava/lang/Class;Lcom/alibaba/fastjson/j;)V

    :goto_4
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v1, p1, v0}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto :goto_7

    :cond_15
    :goto_5
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0, v0}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v1, p1, v0}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    return-object v0

    :cond_16
    :goto_6
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance v1, Lcom/alibaba/fastjson/serializer/i;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-direct {v1}, Lcom/alibaba/fastjson/serializer/i;-><init>()V

    const/4 v10, 0x5

    invoke-virtual {v0, p1, v1}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto/16 :goto_0

    :goto_7
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-nez v0, :cond_17

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    check-cast v0, Lcom/alibaba/fastjson/serializer/t;

    :cond_17
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->b:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object v0
.end method

.method public d(Ljava/lang/reflect/Type;Lcom/alibaba/fastjson/serializer/t;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {v0, p1, p2}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method public e(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/alibaba/fastjson/serializer/t;"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getModifiers()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v5, 0x1

    move v8, v5

    const/4 v7, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v6, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual/range {v0 .. v6}, Lcom/alibaba/fastjson/serializer/x;->f(Ljava/lang/Class;IZZZZ)Lcom/alibaba/fastjson/serializer/t;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    return-object p1
.end method

.method public f(Ljava/lang/Class;IZZZZ)Lcom/alibaba/fastjson/serializer/t;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;IZZZZ)",
            "Lcom/alibaba/fastjson/serializer/t;"
        }
    .end annotation

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v10, p1

    move-object v10, p1

    move-object v10, p1

    move-object v10, p1

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    invoke-virtual {v1, p1}, Lq0/b;->b(Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/alibaba/fastjson/serializer/t;

    if-nez v1, :cond_0

    new-instance v11, Lcom/alibaba/fastjson/serializer/n;

    const/4 v4, 0x0

    iget-object v9, v0, Lcom/alibaba/fastjson/serializer/x;->c:Lcom/alibaba/fastjson/j;

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move v5, p3

    move v5, p3

    move v5, p3

    move/from16 v6, p4

    move/from16 v6, p4

    move/from16 v6, p4

    move/from16 v7, p5

    move/from16 v7, p5

    move/from16 v8, p6

    move/from16 v8, p6

    invoke-direct/range {v1 .. v9}, Lcom/alibaba/fastjson/serializer/n;-><init>(Ljava/lang/Class;ILjava/util/Map;ZZZZLcom/alibaba/fastjson/j;)V

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/x;->a:Lq0/b;

    invoke-virtual {v1, p1, v11}, Lq0/b;->c(Ljava/lang/reflect/Type;Ljava/lang/Object;)Z

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    :cond_0
    return-object v1
.end method

.method public g(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/x;->b:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method
