.class public Lcom/alibaba/fastjson/serializer/m;
.super Ljava/lang/Object;


# instance fields
.field public final a:Lcom/alibaba/fastjson/serializer/x;

.field public final b:Lcom/alibaba/fastjson/serializer/z;

.field protected c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/d;",
            ">;"
        }
    .end annotation
.end field

.field protected d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/a;",
            ">;"
        }
    .end annotation
.end field

.field protected e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/u;",
            ">;"
        }
    .end annotation
.end field

.field protected f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/d0;",
            ">;"
        }
    .end annotation
.end field

.field protected g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/r;",
            ">;"
        }
    .end annotation
.end field

.field protected h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/v;",
            ">;"
        }
    .end annotation
.end field

.field private i:I

.field private j:Ljava/lang/String;

.field private k:Ljava/text/DateFormat;

.field protected l:Ljava/util/IdentityHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/IdentityHashMap<",
            "Ljava/lang/Object;",
            "Lcom/alibaba/fastjson/serializer/w;",
            ">;"
        }
    .end annotation
.end field

.field protected m:Lcom/alibaba/fastjson/serializer/w;

.field public n:Ljava/util/TimeZone;

.field public o:Ljava/util/Locale;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->w:[Lcom/alibaba/fastjson/serializer/a0;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, v3, v1, v2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0, v0, v1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method public constructor <init>(Lcom/alibaba/fastjson/serializer/x;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->w:[Lcom/alibaba/fastjson/serializer/a0;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v0, v3, v1, v2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {p0, v0, p1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/alibaba/fastjson/serializer/z;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->c:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->d:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->e:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->f:Ljava/util/List;

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->g:Ljava/util/List;

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->h:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput v1, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lcom/alibaba/fastjson/a;->a:Ljava/util/TimeZone;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Lcom/alibaba/fastjson/a;->b:Ljava/util/Locale;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->o:Ljava/util/Locale;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object p2, p0, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x6

    const/4 v2, 0x2

    sget-object p1, Lcom/alibaba/fastjson/a;->a:Ljava/util/TimeZone;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static s(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/bs al@  ~~ l~@t~K@v~m t~/ oSo~~c@@yb~ ~ @sbof@@ 4@~@~~ -. ~i  @~  @1@@o~~n@@~@o r~~@~du@M@i~f o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object p0, p0, Lcom/alibaba/fastjson/serializer/m;->f:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    instance-of v0, p2, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    check-cast v0, Lcom/alibaba/fastjson/serializer/d0;

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0, p1, v1, p3}, Lcom/alibaba/fastjson/serializer/d0;->a(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    return-object p3
.end method

.method public static final w(Lcom/alibaba/fastjson/serializer/z;Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/alibaba/fastjson/serializer/m;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v1, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public static final x(Ljava/io/Writer;Ljava/lang/Object;)V
    .locals 6

    new-instance v0, Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x2

    move v5, v4

    sget v1, Lcom/alibaba/fastjson/a;->f:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->w:[Lcom/alibaba/fastjson/serializer/a0;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v0, v3, v1, v2}, Lcom/alibaba/fastjson/serializer/z;-><init>(Ljava/io/Writer;I[Lcom/alibaba/fastjson/serializer/a0;)V

    :try_start_0
    const/4 v5, 0x7

    new-instance v1, Lcom/alibaba/fastjson/serializer/m;

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget-object v2, Lcom/alibaba/fastjson/serializer/x;->d:Lcom/alibaba/fastjson/serializer/x;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, v0, v2}, Lcom/alibaba/fastjson/serializer/m;-><init>(Lcom/alibaba/fastjson/serializer/z;Lcom/alibaba/fastjson/serializer/x;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Lcom/alibaba/fastjson/serializer/z;->d0(Ljava/io/Writer;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p1, v1, p0}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw p0
.end method


# virtual methods
.method protected final A(CLjava/lang/String;Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, p2, v0}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p3}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public B(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v2, 0x0

    move v3, v2

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/w;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne p1, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "{\"$ref\":\"@\"}"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/w;->a:Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, v1, Lcom/alibaba/fastjson/serializer/w;->b:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne p1, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "$.s/re{///:////.}"

    const/4 v3, 0x6

    const-string v0, "/$/m//e{:}/.fr.//"

    const-string/jumbo v0, "{\"$ref\":\"..\"}"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x0

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/w;->a:Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, v0, Lcom/alibaba/fastjson/serializer/w;->b:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne p1, v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "//}$ofm//r://$//"

    const-string/jumbo v0, "{/:m/$}//$rf////"

    const/4 v3, 0x2

    const-string v0, "/:fe$b{///r////$"

    const-string/jumbo v0, "{\"$ref\":\"$\"}"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/util/IdentityHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast p1, Lcom/alibaba/fastjson/serializer/w;

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/w;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    const-string/jumbo v1, "{://r/ueof//"

    const-string v1, "/{reo//://f/"

    const/4 v3, 0x2

    const-string/jumbo v1, "{\"$ref\":\""

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "}//"

    const-string v0, "\"}"

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_3
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto/16 :goto_0
.end method

.method public final C(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/alibaba/fastjson/serializer/m;->D(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public final D(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p1, :cond_0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p4}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object p4

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p4, p0, p1, p2, p3}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    new-instance p2, Lcom/alibaba/fastjson/d;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p2, p3, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    throw p2
.end method

.method public final E(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v0, p1, Ljava/util/Date;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/alibaba/fastjson/serializer/m;->i()Ljava/text/DateFormat;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_0

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/m;->o:Ljava/util/Locale;

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast p1, Ljava/util/Date;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2, p1}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public a(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->e:Ljava/util/List;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    instance-of v2, p2, Ljava/lang/String;

    const/4 v4, 0x1

    move v5, v4

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p2}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    check-cast v2, Lcom/alibaba/fastjson/serializer/u;

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x3

    invoke-interface {v2, p1, v3, p3}, Lcom/alibaba/fastjson/serializer/u;->b(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 p1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    return p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x2

    return v1
.end method

.method public b(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->h:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    return v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    check-cast v2, Lcom/alibaba/fastjson/serializer/v;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    instance-of v3, p2, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v3, :cond_2

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p2}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    :cond_2
    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x6

    invoke-interface {v2, p0, p1, v3}, Lcom/alibaba/fastjson/serializer/v;->c(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    return p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v1
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->close()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public d(Lcom/alibaba/fastjson/serializer/a0;Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/alibaba/fastjson/serializer/z;->d(Lcom/alibaba/fastjson/serializer/a0;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public e()V
    .locals 3

    iget v0, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public f()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/a;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->d:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->d:Ljava/util/List;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->d:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public g()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/d;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->c:Ljava/util/List;

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->c:Ljava/util/List;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->c:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public h()Lcom/alibaba/fastjson/serializer/w;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v1, 0x4

    move v2, v1

    return-object v0
.end method

.method public i()Ljava/text/DateFormat;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/alibaba/fastjson/serializer/m;->o:Ljava/util/Locale;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    return-object v0
.end method

.method public j()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x4

    const/4 v2, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/text/SimpleDateFormat;->toPattern()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    const/4 v2, 0x2

    move v3, v2

    return-object v0
.end method

.method public k()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/r;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->g:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->g:Ljava/util/List;

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->g:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public l()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/u;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->e:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->e:Ljava/util/List;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->e:Ljava/util/List;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public m()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/v;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->h:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->h:Ljava/util/List;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->h:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public n()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/alibaba/fastjson/serializer/d0;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->f:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->f:Ljava/util/List;

    :cond_0
    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->f:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public o()Lcom/alibaba/fastjson/serializer/z;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public p()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public q()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 v1, 0xa

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    iget v1, p0, Lcom/alibaba/fastjson/serializer/m;->i:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-ge v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x4

    const/16 v2, 0x9

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public r(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->g:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, p2, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v1, Lcom/alibaba/fastjson/serializer/r;

    const/4 v3, 0x5

    const/4 v2, 0x5

    check-cast p2, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v1, p1, p2, p3}, Lcom/alibaba/fastjson/serializer/r;->a(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p2
.end method

.method public t(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    iget v0, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->o:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p1, p2, p3, p4}, Lcom/alibaba/fastjson/serializer/w;-><init>(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance p1, Ljava/util/IdentityHashMap;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/util/IdentityHashMap;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p3, p0, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, p2, p3}, Ljava/util/IdentityHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v2, 0x7

    move v3, v2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/serializer/z;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public u(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public v(Ljava/text/DateFormat;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->k:Ljava/text/DateFormat;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->j:Ljava/lang/String;

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public final y(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0, p0, p1, v1, v1}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw v0
.end method

.method public final z(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v0, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->g:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    and-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v1, v0, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v2, Lcom/alibaba/fastjson/serializer/a0;->b:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v2, v2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Lcom/alibaba/fastjson/serializer/z;->N(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x1

    xor-int/2addr v4, v2

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {v0, p1, v1, v2}, Lcom/alibaba/fastjson/serializer/z;->K(Ljava/lang/String;CZ)V

    :goto_1
    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method
