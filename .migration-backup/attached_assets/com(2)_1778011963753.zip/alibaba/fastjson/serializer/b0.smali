.class public Lcom/alibaba/fastjson/serializer/b0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/v;


# instance fields
.field private final a:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private d:I


# direct methods
.method public varargs constructor <init>(Ljava/lang/Class;[Ljava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;[",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Ljava/util/HashSet;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/b0;->b:Ljava/util/Set;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/alibaba/fastjson/serializer/b0;->c:Ljava/util/Set;

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/alibaba/fastjson/serializer/b0;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/b0;->a:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length p1, p2

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ge v0, p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    aget-object v1, p2, v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/alibaba/fastjson/serializer/b0;->b:Ljava/util/Set;

    const/4 v4, 0x3

    invoke-interface {v2, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method public varargs constructor <init>([Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Lcom/alibaba/fastjson/serializer/b0;-><init>(Ljava/lang/Class;[Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public c(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/String;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/b0;->a:Ljava/lang/Class;

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    return v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/alibaba/fastjson/serializer/b0;->c:Ljava/util/Set;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {p2, p3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    if-eqz p2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v1

    :cond_2
    const/4 v4, 0x2

    iget p2, p0, Lcom/alibaba/fastjson/serializer/b0;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-lez p2, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    move p2, v1

    move p2, v1

    const/4 v4, 0x3

    move p2, v1

    move p2, v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    move v4, v3

    add-int/2addr p2, v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v2, p0, Lcom/alibaba/fastjson/serializer/b0;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-le p2, v2, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x3

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/w;->a:Lcom/alibaba/fastjson/serializer/w;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_4
    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/b0;->b:Ljava/util/Set;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p1, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/b0;->b:Ljava/util/Set;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p1, p3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_5

    const/4 v4, 0x0

    goto :goto_1

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1

    :cond_6
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v0
.end method

.method public d()Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/b0;->a:Ljava/lang/Class;

    const/4 v2, 0x3

    return-object v0
.end method

.method public e()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/b0;->c:Ljava/util/Set;

    const/4 v2, 0x0

    return-object v0
.end method

.method public f()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/b0;->b:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/alibaba/fastjson/serializer/b0;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public h(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Lcom/alibaba/fastjson/serializer/b0;->d:I

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
