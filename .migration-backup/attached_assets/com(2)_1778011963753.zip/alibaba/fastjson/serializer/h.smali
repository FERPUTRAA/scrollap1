.class public final Lcom/alibaba/fastjson/serializer/h;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/h;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    new-instance v0, Lcom/alibaba/fastjson/serializer/h;

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/h;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object v0, Lcom/alibaba/fastjson/serializer/h;->a:Lcom/alibaba/fastjson/serializer/h;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~sv~ @~@t~o@  o ~ @Mf~@  o~ui f@r  S@@-~~Ko @i@~/i~~ @@y~~ d4@1~@~b@/  ~am ~ b@~so~@lbo~c@@t.n@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/alibaba/fastjson/serializer/h;->d(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 17
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    iget-object v2, v0, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    if-nez v1, :cond_0

    invoke-virtual {v2}, Lcom/alibaba/fastjson/serializer/z;->I()V

    return-void

    :cond_0
    iget v3, v2, Lcom/alibaba/fastjson/serializer/z;->c:I

    sget-object v4, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    iget v4, v4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr v3, v4

    if-eqz v3, :cond_2

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    if-eq v3, v4, :cond_2

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const-class v4, Ljava/util/Date;

    const-class v4, Ljava/util/Date;

    const-class v4, Ljava/util/Date;

    const-class v4, Ljava/util/Date;

    if-ne v3, v4, :cond_1

    const-string v0, " asnteD(w"

    const-string v0, "ew mntaD("

    const-string/jumbo v0, "new Date("

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    check-cast v0, Ljava/util/Date;

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    invoke-virtual {v2, v0, v1}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    const/16 v0, 0x29

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    goto :goto_0

    :cond_1
    const/16 v3, 0x7b

    invoke-virtual {v2, v3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const-string/jumbo v3, "yt@po"

    const-string v3, "@type"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/serializer/m;->z(Ljava/lang/String;)V

    const/16 v0, 0x2c

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const-string v0, "avl"

    const-string/jumbo v0, "lav"

    const-string v0, "alv"

    const-string/jumbo v0, "val"

    invoke-virtual {v2, v0, v4}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    check-cast v0, Ljava/util/Date;

    invoke-virtual {v0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    invoke-virtual {v2, v0, v1}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    const/16 v0, 0x7d

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_0
    return-void

    :cond_2
    instance-of v3, v1, Ljava/util/Calendar;

    if-eqz v3, :cond_3

    check-cast v1, Ljava/util/Calendar;

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    goto :goto_1

    :cond_3
    check-cast v1, Ljava/util/Date;

    :goto_1
    iget v3, v2, Lcom/alibaba/fastjson/serializer/z;->c:I

    sget-object v4, Lcom/alibaba/fastjson/serializer/a0;->q:Lcom/alibaba/fastjson/serializer/a0;

    iget v4, v4, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr v3, v4

    if-eqz v3, :cond_5

    invoke-virtual/range {p1 .. p1}, Lcom/alibaba/fastjson/serializer/m;->i()Ljava/text/DateFormat;

    move-result-object v3

    if-nez v3, :cond_4

    new-instance v3, Ljava/text/SimpleDateFormat;

    sget-object v4, Lcom/alibaba/fastjson/a;->e:Ljava/lang/String;

    iget-object v5, v0, Lcom/alibaba/fastjson/serializer/m;->o:Ljava/util/Locale;

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iget-object v0, v0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    invoke-virtual {v3, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    :cond_4
    invoke-virtual {v3, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->J(Ljava/lang/String;)V

    return-void

    :cond_5
    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    move-result-wide v3

    iget v1, v2, Lcom/alibaba/fastjson/serializer/z;->c:I

    sget-object v5, Lcom/alibaba/fastjson/serializer/a0;->e:Lcom/alibaba/fastjson/serializer/a0;

    iget v5, v5, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr v5, v1

    if-eqz v5, :cond_a

    sget-object v5, Lcom/alibaba/fastjson/serializer/a0;->b:Lcom/alibaba/fastjson/serializer/a0;

    iget v6, v5, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr v1, v6

    const/16 v6, 0x27

    const/16 v7, 0x22

    if-eqz v1, :cond_6

    invoke-virtual {v2, v6}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    goto :goto_2

    :cond_6
    invoke-virtual {v2, v7}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_2
    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/m;->n:Ljava/util/TimeZone;

    iget-object v0, v0, Lcom/alibaba/fastjson/serializer/m;->o:Ljava/util/Locale;

    invoke-static {v1, v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;Ljava/util/Locale;)Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0, v3, v4}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v3

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v4

    add-int/2addr v4, v1

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/16 v8, 0xb

    invoke-virtual {v0, v8}, Ljava/util/Calendar;->get(I)I

    move-result v8

    const/16 v9, 0xc

    invoke-virtual {v0, v9}, Ljava/util/Calendar;->get(I)I

    move-result v9

    const/16 v10, 0xd

    invoke-virtual {v0, v10}, Ljava/util/Calendar;->get(I)I

    move-result v11

    const/16 v12, 0xe

    invoke-virtual {v0, v12}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/16 v12, 0x10

    const/16 v13, 0x13

    const/16 v7, 0xa

    if-eqz v0, :cond_7

    const-string v16, "T-0m000:-0.000:00000000"

    const-string v16, "00000b0:0-000.0-T00:000"

    const-string v16, "0000-00-00T00:00:00.000"

    invoke-virtual/range {v16 .. v16}, Ljava/lang/String;->toCharArray()[C

    move-result-object v6

    int-to-long v14, v0

    const/16 v0, 0x17

    invoke-static {v14, v15, v0, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v14, v11

    invoke-static {v14, v15, v13, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v13, v9

    invoke-static {v13, v14, v12, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v8, v8

    invoke-static {v8, v9, v10, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v1

    invoke-static {v0, v1, v7, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v4

    const/4 v4, 0x7

    invoke-static {v0, v1, v4, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v3

    const/4 v3, 0x4

    invoke-static {v0, v1, v3, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    goto :goto_3

    :cond_7
    if-nez v11, :cond_8

    if-nez v9, :cond_8

    if-nez v8, :cond_8

    const-string v0, "0000o000--"

    const-string v0, "0-000-u000"

    const-string v0, "0000-00-00"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v6

    int-to-long v0, v1

    invoke-static {v0, v1, v7, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v4

    const/4 v4, 0x7

    invoke-static {v0, v1, v4, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v3

    const/4 v3, 0x4

    invoke-static {v0, v1, v3, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    goto :goto_3

    :cond_8
    const-string v0, "-0000b::00T-0000000"

    const-string v0, "0000-00-00T00:00:00"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v6

    int-to-long v14, v11

    invoke-static {v14, v15, v13, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v13, v9

    invoke-static {v13, v14, v12, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v8, v8

    invoke-static {v8, v9, v10, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v1

    invoke-static {v0, v1, v7, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v4

    const/4 v4, 0x7

    invoke-static {v0, v1, v4, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    int-to-long v0, v3

    const/4 v3, 0x4

    invoke-static {v0, v1, v3, v6}, Lcom/alibaba/fastjson/serializer/z;->f(JI[C)V

    :goto_3
    invoke-virtual {v2, v6}, Ljava/io/Writer;->write([C)V

    iget v0, v2, Lcom/alibaba/fastjson/serializer/z;->c:I

    iget v1, v5, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_9

    const/16 v0, 0x27

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    goto :goto_4

    :cond_9
    const/16 v0, 0x22

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    goto :goto_4

    :cond_a
    invoke-virtual {v2, v3, v4}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    :goto_4
    return-void
.end method

.method protected c(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p3, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p4, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p3

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    instance-of v0, p4, Ljava/util/Date;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    return-object p4

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    instance-of v0, p4, Ljava/math/BigDecimal;

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p1, Ljava/util/Date;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast p4, Ljava/math/BigDecimal;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p4}, Ljava/math/BigDecimal;->longValueExact()J

    move-result-wide p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1, p2, p3}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x4

    return-object p1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v0, p4, Ljava/lang/Number;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Ljava/util/Date;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast p4, Ljava/lang/Number;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-virtual {p4}, Ljava/lang/Number;->longValue()J

    move-result-wide p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p1, p2, p3}, Ljava/util/Date;-><init>(J)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of v0, p4, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_a

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast p4, Ljava/lang/String;

    const/4 v3, 0x5

    invoke-virtual {p4}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object p3

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/alibaba/fastjson/parser/e;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, p4}, Lcom/alibaba/fastjson/parser/e;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/e;->M(Z)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_6

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, v0, Lcom/alibaba/fastjson/parser/e;->o:Ljava/util/Calendar;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-class p3, Ljava/util/Calendar;

    const-class p3, Ljava/util/Calendar;

    const/4 v3, 0x0

    const-class p3, Ljava/util/Calendar;

    const-class p3, Ljava/util/Calendar;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne p2, p3, :cond_5

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p1

    :cond_5
    :try_start_1
    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1

    :cond_6
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p2, "0-000u0p0-"

    const-string p2, "00-0-0u000"

    const/4 v3, 0x1

    const-string p2, "00-00000q-"

    const-string p2, "0000-00-00"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p2, p4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-nez p2, :cond_9

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p2, "00s000Tp::00-00000-"

    const-string p2, "-00000:p-000T:00000"

    const/4 v3, 0x7

    const-string p2, "000m000000:-0:-0T00"

    const-string p2, "0000-00-00T00:00:00"

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p2, p4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez p2, :cond_9

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p2, "000To000011:-:000q0:8-100"

    const-string p2, "00010:00q0-:-000:000118T0"

    const/4 v3, 0x3

    const-string p2, "800T0b0:0001001-1-0:+0000"

    const-string p2, "0001-01-01T00:00:00+08:00"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, p4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p2, :cond_7

    const/4 v3, 0x7

    goto :goto_1

    :cond_7
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p5, :cond_8

    const/4 v3, 0x0

    const/4 v2, 0x3

    new-instance p1, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {p1, p5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_8
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->j()Ljava/text/DateFormat;

    move-result-object p1

    :goto_0
    :try_start_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p4}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1
    :try_end_2
    .catch Ljava/text/ParseException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object p1

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p3, Ljava/util/Date;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-direct {p3, p1, p2}, Ljava/util/Date;-><init>(J)V

    :cond_9
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p3

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->e()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p1

    :cond_a
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance p1, Lcom/alibaba/fastjson/d;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string p2, " sraepuosre"

    const-string/jumbo p2, "rasese oprr"

    const/4 v3, 0x6

    const-string/jumbo p2, "prresorpa e"

    const-string/jumbo p2, "parse error"

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p1
.end method

.method public d(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    const-class v2, Ljava/util/Calendar;

    const-class v2, Ljava/util/Calendar;

    const-class v2, Ljava/util/Calendar;

    const-class v2, Ljava/util/Calendar;

    const/4 v3, 0x0

    const/16 v4, 0x10

    const/4 v5, 0x2

    if-ne v1, v5, :cond_1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->o()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v0, v4}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    :cond_0
    :goto_0
    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    goto/16 :goto_1

    :cond_1
    const/4 v6, 0x4

    if-ne v1, v6, :cond_4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v4}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    iget v4, v0, Lcom/alibaba/fastjson/parser/e;->c:I

    sget-object v5, Lcom/alibaba/fastjson/parser/d;->f:Lcom/alibaba/fastjson/parser/d;

    iget v5, v5, Lcom/alibaba/fastjson/parser/d;->mask:I

    and-int/2addr v4, v5

    if-eqz v4, :cond_0

    new-instance v4, Lcom/alibaba/fastjson/parser/e;

    invoke-direct {v4, v1}, Lcom/alibaba/fastjson/parser/e;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Lcom/alibaba/fastjson/parser/e;->M(Z)Z

    move-result v5

    if-eqz v5, :cond_3

    iget-object v1, v4, Lcom/alibaba/fastjson/parser/e;->o:Ljava/util/Calendar;

    if-ne p2, v2, :cond_2

    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->e()V

    return-object v1

    :cond_2
    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v1

    :cond_3
    invoke-virtual {v4}, Lcom/alibaba/fastjson/parser/e;->e()V

    goto :goto_0

    :cond_4
    const/16 v7, 0x8

    if-ne v1, v7, :cond_5

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    move-object v8, v3

    move-object v8, v3

    move-object v8, v3

    goto/16 :goto_1

    :cond_5
    const/16 v7, 0xc

    const/16 v8, 0xd

    const/16 v9, 0x11

    const-string/jumbo v10, "ortsr mnqxye"

    const-string/jumbo v10, "yermoxnsrt a"

    const-string v10, "assx nyerrrt"

    const-string/jumbo v10, "syntax error"

    if-ne v1, v7, :cond_a

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    if-ne v1, v6, :cond_9

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v1

    const-string/jumbo v7, "tepmo"

    const-string/jumbo v7, "tpe@o"

    const-string v7, "@type"

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    invoke-virtual {p1, v9}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v1

    iget-object v7, p1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    iget v9, v0, Lcom/alibaba/fastjson/parser/e;->c:I

    invoke-virtual {v7, v1, v3, v9}, Lcom/alibaba/fastjson/parser/m;->a(Ljava/lang/String;Ljava/lang/Class;I)Ljava/lang/Class;

    move-result-object v1

    if-eqz v1, :cond_6

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :cond_6
    invoke-virtual {p1, v6}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    invoke-virtual {p1, v4}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    :cond_7
    const/16 v1, 0x3a

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/parser/e;->v(C)V

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    if-ne v1, v5, :cond_8

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->o()J

    move-result-wide v4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {p1, v8}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    goto/16 :goto_0

    :cond_8
    new-instance p1, Lcom/alibaba/fastjson/d;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo p3, "te:yorbox  r ns"

    const-string/jumbo p3, "r syebt: or xrn"

    const-string/jumbo p3, "r:n eboyar sx r"

    const-string/jumbo p3, "syntax error : "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1}, Lcom/alibaba/fastjson/parser/f;->a(I)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_9
    new-instance p1, Lcom/alibaba/fastjson/d;

    invoke-direct {p1, v10}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_a
    iget v1, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    if-ne v1, v5, :cond_d

    const/4 v1, 0x0

    iput v1, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    invoke-virtual {p1, v4}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    if-ne v1, v6, :cond_c

    const-string/jumbo v1, "val"

    const-string/jumbo v1, "lva"

    const-string/jumbo v1, "lav"

    const-string/jumbo v1, "val"

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->t()V

    invoke-virtual {p1, v9}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1, v8}, Lcom/alibaba/fastjson/parser/b;->a(I)V

    goto/16 :goto_0

    :cond_b
    new-instance p1, Lcom/alibaba/fastjson/d;

    invoke-direct {p1, v10}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_c
    new-instance p1, Lcom/alibaba/fastjson/d;

    invoke-direct {p1, v10}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_d
    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object v1

    goto/16 :goto_0

    :goto_1
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v7, p3

    move-object v7, p3

    move-object v9, p4

    invoke-virtual/range {v4 .. v9}, Lcom/alibaba/fastjson/serializer/h;->c(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    if-ne p2, v2, :cond_10

    instance-of p2, p1, Ljava/util/Calendar;

    if-eqz p2, :cond_e

    return-object p1

    :cond_e
    check-cast p1, Ljava/util/Date;

    if-nez p1, :cond_f

    return-object v3

    :cond_f
    iget-object p2, v0, Lcom/alibaba/fastjson/parser/e;->m:Ljava/util/TimeZone;

    iget-object p3, v0, Lcom/alibaba/fastjson/parser/e;->n:Ljava/util/Locale;

    invoke-static {p2, p3}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;Ljava/util/Locale;)Ljava/util/Calendar;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    return-object p2

    :cond_10
    return-object p1
.end method
