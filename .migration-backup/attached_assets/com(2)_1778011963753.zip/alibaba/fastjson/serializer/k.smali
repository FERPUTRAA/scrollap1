.class public final Lcom/alibaba/fastjson/serializer/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static a:Lcom/alibaba/fastjson/serializer/k;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/alibaba/fastjson/serializer/k;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/k;-><init>()V

    const/4 v1, 0x1

    and-int/2addr v2, v1

    sput-object v0, Lcom/alibaba/fastjson/serializer/k;->a:Lcom/alibaba/fastjson/serializer/k;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @st @/~t~~ @ @imiy~b@~~@o~~  b@sb ucoKa@o~iS 1oo.~@ 4~@ @@~@-f Ml d@~~ ~f~~~v~@/@ @ @n@ ro~l ~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v2, 0x8

    const/4 v6, 0x5

    const/16 v3, 0x10

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ne v1, v2, :cond_0

    const/4 v6, 0x0

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object p1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-class v4, Ljava/lang/Long;

    const-class v4, Ljava/lang/Long;

    const/4 v6, 0x2

    const-class v4, Ljava/lang/Long;

    const-class v4, Ljava/lang/Long;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-ne v1, v2, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object p1, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x4

    if-eq p2, p1, :cond_2

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    if-ne p2, v4, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->k()I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v1, " iemfallid serunt:ow vfeol v"

    const-string v1, "ftsv eoerll i : iolufane dvw"

    const/4 v6, 0x5

    const-string/jumbo v1, "vivnoai  f,ldtee wool  el:fu"

    const-string/jumbo v1, "int value overflow, field : "

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p2, p3, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    throw p2

    :cond_2
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->o()J

    move-result-wide p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_4

    :cond_3
    const/4 v6, 0x5

    const/4 v2, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-ne v1, v2, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->h()Ljava/math/BigDecimal;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    sget-object p3, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eq p2, p3, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-ne p2, v4, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_2

    :cond_4
    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p1}, Ljava/math/BigDecimal;->intValueExact()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_4

    :cond_5
    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/math/BigDecimal;->longValueExact()J

    move-result-wide p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_4

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p1

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object v0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eq p2, v0, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-ne p2, v4, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_3

    :cond_7
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Lq0/d;->p(Ljava/lang/Object;)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_4

    :cond_8
    :goto_3
    const/4 v5, 0x1

    invoke-static {p1}, Lq0/d;->t(Ljava/lang/Object;)Ljava/lang/Long;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :goto_4
    const/4 v6, 0x7

    const/4 v5, 0x4

    return-object p1

    :catch_1
    move-exception p2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v0, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v2, ":rit brsra  ,clof me"

    const-string/jumbo v2, "rrcm aste  ,fel ori:"

    const/4 v6, 0x5

    const-string/jumbo v2, "t:eareu,cr li sof  d"

    const-string v2, "cast error, field : "

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo p3, "ue l ovp"

    const-string/jumbo p3, "v  loue,"

    const-string/jumbo p3, "q euvla,"

    const-string p3, ", value "

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    invoke-direct {v0, p1, p2}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    throw v0
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    check-cast p3, Ljava/lang/Number;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    iget p2, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object p3, Lcom/alibaba/fastjson/serializer/a0;->h:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget p3, p3, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    and-int/2addr p2, p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/16 p2, 0x30

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    instance-of p2, p2, Ljava/lang/Long;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p3}, Ljava/lang/Number;->longValue()J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lcom/alibaba/fastjson/serializer/z;->H(J)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_1

    :cond_2
    const/4 v4, 0x6

    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->t(I)V

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget p2, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v0, v0, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    and-int/2addr p2, v0

    const/4 v4, 0x2

    if-eqz p2, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne p2, v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 p2, 0x42

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x4

    goto :goto_2

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-class v0, Ljava/lang/Short;

    const-class v0, Ljava/lang/Short;

    const/4 v4, 0x5

    const-class v0, Ljava/lang/Short;

    const-class v0, Ljava/lang/Short;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ne p2, v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/16 p2, 0x53

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_2

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x3

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ne p2, v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p3}, Ljava/lang/Number;->longValue()J

    move-result-wide p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-wide/32 v1, 0x7fffffff

    const-wide/32 v1, 0x7fffffff

    const/4 v4, 0x2

    const-wide/32 v1, 0x7fffffff

    const-wide/32 v1, 0x7fffffff

    cmp-long v1, p2, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-gtz v1, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-wide/32 v1, -0x80000000

    const-wide/32 v1, -0x80000000

    const/4 v4, 0x2

    const-wide/32 v1, -0x80000000

    const-wide/32 v1, -0x80000000

    const/4 v4, 0x5

    cmp-long p2, p2, v1

    const/4 v3, 0x7

    move v4, v3

    if-ltz p2, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq p4, v0, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 p2, 0x4c

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_5
    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method
