.class public Lcom/alibaba/fastjson/serializer/e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/alibaba/fastjson/serializer/e;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/e;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    sput-object v0, Lcom/alibaba/fastjson/serializer/e;->a:Lcom/alibaba/fastjson/serializer/e;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "sisrv@f@ ~@@~oc@ o ~@y d@i~ou1M@~~ 4@tb~~.~m~b@~  @o/ i@ ~a/S~  ~~on~t@~ Kf~@~~@~ll  -o@ ~b @ @@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object p3, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v2, 0x10

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-class v3, Ljava/math/BigInteger;

    const-class v3, Ljava/math/BigInteger;

    const/4 v5, 0x0

    const-class v3, Ljava/math/BigInteger;

    const-class v3, Ljava/math/BigInteger;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne v0, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne p2, v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->w()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p3, v2}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance p2, Ljava/math/BigInteger;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/16 p3, 0xa

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {p2, p1, p3}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;I)V

    return-object p2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->h()Ljava/math/BigDecimal;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p3, v2}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ne v0, v1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p3}, Lcom/alibaba/fastjson/parser/e;->h()Ljava/math/BigDecimal;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p3, v2}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne p2, v3, :cond_3

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/math/BigDecimal;->scale()I

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 p3, -0x64

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    if-lt p2, p3, :cond_2

    const/4 v4, 0x7

    move v5, v4

    const/16 p3, 0x64

    const/4 v5, 0x3

    if-gt p2, p3, :cond_2

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p1}, Ljava/math/BigDecimal;->toBigInteger()Ljava/math/BigInteger;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    return-object p1

    :cond_2
    const/4 v4, 0x6

    move v5, v4

    new-instance p1, Ljava/lang/NumberFormatException;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1}, Ljava/lang/NumberFormatException;-><init>()V

    const/4 v5, 0x4

    throw p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-object p1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    if-nez p1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object p1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ne p2, v3, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1}, Lq0/d;->g(Ljava/lang/Object;)Ljava/math/BigInteger;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object p1

    :cond_6
    const/4 v4, 0x3

    move v5, v4

    invoke-static {p1}, Lq0/d;->f(Ljava/lang/Object;)Ljava/math/BigDecimal;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object p1
.end method

.method public b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget p2, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object p3, Lcom/alibaba/fastjson/serializer/a0;->h:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget p3, p3, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    and-int/2addr p2, p3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p2, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/16 p2, 0x30

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    instance-of p3, p2, Ljava/math/BigInteger;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p3, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p2, Ljava/math/BigInteger;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p2}, Ljava/math/BigInteger;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :cond_2
    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p2, Ljava/math/BigDecimal;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/math/BigDecimal;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, p3}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget p3, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/alibaba/fastjson/serializer/a0;->n:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, v0, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    and-int/2addr p3, v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p3, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-class p3, Ljava/math/BigDecimal;

    const-class p3, Ljava/math/BigDecimal;

    const/4 v2, 0x7

    const-class p3, Ljava/math/BigDecimal;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eq p4, p3, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/math/BigDecimal;->scale()I

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez p2, :cond_3

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 p2, 0x2e

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method
