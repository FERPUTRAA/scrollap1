.class public final Lcom/alibaba/fastjson/serializer/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/t;
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/serializer/b;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/alibaba/fastjson/serializer/b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/alibaba/fastjson/serializer/b;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lcom/alibaba/fastjson/serializer/b;->a:Lcom/alibaba/fastjson/serializer/b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private c(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Class;Lcom/alibaba/fastjson/b;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/Class<",
            "*>;",
            "Lcom/alibaba/fastjson/b;",
            ")TT;"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " rs@~@u @@b  t i~o~@@-@K@o~~o4@dM~s~ab@@ ~ @@Si~oi~~~@@1~@~~/o@ c/  n@@  ~ob~~   f~.~~@ytlfvm l "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    if-nez p3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 p1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object p1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p3}, Lcom/alibaba/fastjson/b;->size()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-ge v2, v0, :cond_4

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p3, v2}, Lcom/alibaba/fastjson/b;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ne v3, p3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v1, v2, v1}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_2

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/Class;->isArray()Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast v3, Lcom/alibaba/fastjson/b;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, p1, p2, v3}, Lcom/alibaba/fastjson/serializer/b;->c(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Class;Lcom/alibaba/fastjson/b;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v4, p1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v3, p2, v4}, Lq0/d;->b(Ljava/lang/Object;Ljava/lang/Class;Lcom/alibaba/fastjson/parser/m;)Ljava/lang/Object;

    move-result-object v3

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1, v2, v3}, Ljava/lang/reflect/Array;->set(Ljava/lang/Object;ILjava/lang/Object;)V

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    move v6, v5

    goto :goto_0

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p3, v1}, Lcom/alibaba/fastjson/b;->P0(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p3, p2}, Lcom/alibaba/fastjson/b;->O0(Ljava/lang/reflect/Type;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object v1
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->e:Lcom/alibaba/fastjson/parser/e;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->f0()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/16 v2, 0x8

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/16 v3, 0x10

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-ne v1, v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 p1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object p1

    :cond_0
    const/4 v6, 0x7

    const-class v2, [C

    const-class v2, [C

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ne p2, v2, :cond_3

    const/4 v6, 0x5

    if-ne v1, v4, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->c0()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1

    :cond_1
    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 p2, 0x2

    const/4 v6, 0x3

    if-ne v1, p2, :cond_2

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->l()Ljava/lang/Number;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->t()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/alibaba/fastjson/a;->U(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p1

    :cond_3
    const/4 v5, 0x6

    const/4 v6, 0x0

    if-ne v1, v4, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/alibaba/fastjson/parser/e;->a()[B

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, v3}, Lcom/alibaba/fastjson/parser/e;->u(I)V

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p1

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast p2, Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v0, Lcom/alibaba/fastjson/b;

    const/4 v6, 0x5

    invoke-direct {v0}, Lcom/alibaba/fastjson/b;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1, p2, v0, p3}, Lcom/alibaba/fastjson/parser/b;->J(Ljava/lang/reflect/Type;Ljava/util/Collection;Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {p0, p1, p2, v0}, Lcom/alibaba/fastjson/serializer/b;->c(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Class;Lcom/alibaba/fastjson/b;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object p1
.end method

.method public final b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x7

    iget-object p4, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    check-cast v0, [Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v1, "]["

    const-string v1, "[]"

    const/4 v10, 0x7

    const-string v1, "[]"

    const-string v1, "[]"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-nez p2, :cond_1

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget p1, p4, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    sget-object p2, Lcom/alibaba/fastjson/serializer/a0;->f:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v10, 0x0

    const/4 v9, 0x6

    iget p2, p2, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    and-int/2addr p1, p2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eqz p1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p4, v1}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    const/4 v10, 0x3

    invoke-virtual {p4}, Lcom/alibaba/fastjson/serializer/z;->I()V

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    return-void

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    array-length v2, v0

    const/4 v9, 0x0

    move v10, v9

    add-int/lit8 v3, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v4, -0x1

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-ne v3, v4, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p4, v1}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v9, 0x2

    and-int/2addr v10, v9

    return-void

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v1, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p1, v1, p2, p3, v4}, Lcom/alibaba/fastjson/serializer/m;->t(Lcom/alibaba/fastjson/serializer/w;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    const/16 p2, 0x5b

    :try_start_0
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p4, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget p2, p4, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v10, 0x3

    sget-object p3, Lcom/alibaba/fastjson/serializer/a0;->m:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v9, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget p3, p3, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    and-int/2addr p2, p3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/16 p3, 0x5d

    const/4 v10, 0x4

    const/16 v5, 0x2c

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p2, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/m;->p()V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/m;->q()V

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-ge v4, v2, :cond_4

    const/4 v10, 0x1

    if-eqz v4, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p4, v5}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/m;->q()V

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x5

    aget-object p2, v0, v4

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->y(Ljava/lang/Object;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    goto :goto_1

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/m;->e()V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/alibaba/fastjson/serializer/m;->q()V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    iput-object v1, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    return-void

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 p2, 0x0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v6, v2

    move-object v6, v2

    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x6

    if-ge v4, v3, :cond_9

    :try_start_1
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    aget-object v7, v0, v4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-nez v7, :cond_6

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string v7, ",lsmn"

    const-string v7, ",nsll"

    const/4 v10, 0x5

    const-string/jumbo v7, "nl,lo"

    const-string/jumbo v7, "null,"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p4, v7}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_4

    :cond_6
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object v8, p1, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz v8, :cond_7

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v8, v7}, Ljava/util/IdentityHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v8

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eqz v8, :cond_7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {p1, v7}, Lcom/alibaba/fastjson/serializer/m;->B(Ljava/lang/Object;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_3

    :cond_7
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-ne v8, v2, :cond_8

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-interface {v6, p1, v7, p2, p2}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    goto :goto_3

    :cond_8
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v2, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v2, v8}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x5

    invoke-interface {v6, p1, v7, p2, p2}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    move-object v2, v8

    move-object v2, v8

    move-object v2, v8

    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p4, v5}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    :goto_4
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_2

    :cond_9
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    aget-object p2, v0, v3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-nez p2, :cond_a

    const/4 v10, 0x0

    const-string p2, "bn]ll"

    const-string/jumbo p2, "ln]ml"

    const/4 v10, 0x0

    const-string p2, "]ulnu"

    const-string/jumbo p2, "null]"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p4, p2}, Lcom/alibaba/fastjson/serializer/z;->b(Ljava/lang/CharSequence;)Lcom/alibaba/fastjson/serializer/z;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_6

    :cond_a
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v0, p1, Lcom/alibaba/fastjson/serializer/m;->l:Ljava/util/IdentityHashMap;

    const/4 v9, 0x6

    move v10, v9

    if-eqz v0, :cond_b

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v0, p2}, Ljava/util/IdentityHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-eqz v0, :cond_b

    const/4 v9, 0x3

    and-int/2addr v10, v9

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/m;->B(Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    goto :goto_5

    :cond_b
    const/4 v10, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1, p2, v0}, Lcom/alibaba/fastjson/serializer/m;->C(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_5
    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p4, p3}, Lcom/alibaba/fastjson/serializer/z;->write(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_6
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    iput-object v1, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x3

    return-void

    :catchall_0
    move-exception p2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-object v1, p1, Lcom/alibaba/fastjson/serializer/m;->m:Lcom/alibaba/fastjson/serializer/w;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    throw p2
.end method
