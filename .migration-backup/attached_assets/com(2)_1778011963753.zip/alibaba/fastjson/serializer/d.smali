.class public abstract Lcom/alibaba/fastjson/serializer/d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/y;


# static fields
.field private static final a:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lcom/alibaba/fastjson/serializer/m;",
            ">;"
        }
    .end annotation
.end field

.field private static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Ljava/lang/Character;",
            ">;"
        }
    .end annotation
.end field

.field private static final c:Ljava/lang/Character;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/alibaba/fastjson/serializer/d;->a:Ljava/lang/ThreadLocal;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    sput-object v0, Lcom/alibaba/fastjson/serializer/d;->b:Ljava/lang/ThreadLocal;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 v0, 0x2c

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Lcom/alibaba/fastjson/serializer/d;->c:Ljava/lang/Character;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method final d(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;C)C
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ts@~  @~Sv@oob~oc@~~@~~@~Ki of~~~ @@ @My ~4i@ /o  @us~b ~~l ~@~~@  l@@orma1.@n ~if@d~ @t@~/ ~b "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/alibaba/fastjson/serializer/d;->a:Ljava/lang/ThreadLocal;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object p1, Lcom/alibaba/fastjson/serializer/d;->b:Ljava/lang/ThreadLocal;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p3}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Lcom/alibaba/fastjson/serializer/d;->e(Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p1, Ljava/lang/Character;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method

.method public abstract e(Ljava/lang/Object;)V
.end method

.method protected final f(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 5

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v0, Lcom/alibaba/fastjson/serializer/d;->a:Ljava/lang/ThreadLocal;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v0, Lcom/alibaba/fastjson/serializer/m;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/d;->b:Ljava/lang/ThreadLocal;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v2, Ljava/lang/Character;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/Character;->charValue()C

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v2, p1, p2}, Lcom/alibaba/fastjson/serializer/m;->A(CLjava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/16 p1, 0x2c

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eq v2, p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object p1, Lcom/alibaba/fastjson/serializer/d;->c:Ljava/lang/Character;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method
