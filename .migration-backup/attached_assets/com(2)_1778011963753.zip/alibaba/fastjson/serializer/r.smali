.class public interface abstract Lcom/alibaba/fastjson/serializer/r;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/serializer/y;


# virtual methods
.method public abstract a(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
.end method
