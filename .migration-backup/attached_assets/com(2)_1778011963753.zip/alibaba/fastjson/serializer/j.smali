.class public final Lcom/alibaba/fastjson/serializer/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alibaba/fastjson/serializer/j$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lcom/alibaba/fastjson/serializer/j;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Lq0/a;

.field protected final b:Z

.field protected final c:I

.field protected final d:Ljava/lang/String;

.field protected e:[C

.field private f:Lcom/alibaba/fastjson/serializer/j$a;


# direct methods
.method public constructor <init>(Lq0/a;)V
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput-object p1, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v11, 0x0

    invoke-virtual {p1}, Lq0/a;->d()Lp0/b;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v1, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    const/4 v2, 0x0

    const/4 v11, 0x5

    const/4 v3, 0x4

    const/4 v11, 0x1

    const/4 v3, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eqz v0, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-interface {v0}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v4

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    array-length v5, v4

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    move v6, v2

    move v6, v2

    const/4 v11, 0x1

    move v6, v2

    move v6, v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    move v7, v6

    move v7, v6

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-ge v6, v5, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    aget-object v8, v4, v6

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object v9, Lcom/alibaba/fastjson/serializer/a0;->c:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-ne v8, v9, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    move v7, v1

    move v7, v1

    const/4 v11, 0x2

    move v7, v1

    move v7, v1

    :cond_0
    const/4 v11, 0x5

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x5

    goto :goto_0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0}, Lp0/b;->format()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-nez v5, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    goto :goto_1

    :cond_2
    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-interface {v0}, Lp0/b;->serialzeFeatures()[Lcom/alibaba/fastjson/serializer/a0;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v0}, Lcom/alibaba/fastjson/serializer/a0;->a([Lcom/alibaba/fastjson/serializer/a0;)I

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput v0, p0, Lcom/alibaba/fastjson/serializer/j;->c:I

    const/4 v10, 0x6

    move v11, v10

    goto :goto_2

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput v2, p0, Lcom/alibaba/fastjson/serializer/j;->c:I

    const/4 v11, 0x6

    move v7, v2

    move v7, v2

    const/4 v11, 0x3

    move v7, v2

    move v7, v2

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x4

    iput-boolean v7, p0, Lcom/alibaba/fastjson/serializer/j;->b:Z

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    iput-object v3, p0, Lcom/alibaba/fastjson/serializer/j;->d:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object p1, p1, Lq0/a;->a:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    add-int/lit8 v3, v0, 0x3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    new-array v3, v3, [C

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    iput-object v3, p0, Lcom/alibaba/fastjson/serializer/j;->e:[C

    const/4 v11, 0x4

    const/4 v10, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object v4, p0, Lcom/alibaba/fastjson/serializer/j;->e:[C

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p1, v2, v3, v4, v1}, Ljava/lang/String;->getChars(II[CI)V

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/alibaba/fastjson/serializer/j;->e:[C

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/16 v1, 0x22

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    aput-char v1, p1, v2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    add-int/lit8 v2, v0, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    aput-char v1, p1, v2

    const/4 v11, 0x0

    add-int/lit8 v0, v0, 0x2

    const/4 v11, 0x4

    const/16 v1, 0x3a

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    aput-char v1, p1, v0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/serializer/j;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s~@~~ 4vau1@l~@@i.@c~~sf~~@K@ @y@@~~@@ i/ o o~- i@m~@Mf  / @ @n~@t ~ @b~obor S@d~o~~@b ~ l~~t~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lq0/a;->a(Lq0/a;)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method public b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lq0/a;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p1

    :catch_0
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v1, v0, Lq0/a;->b:Ljava/lang/reflect/Method;

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    :goto_0
    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/lang/reflect/Member;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v2, "."

    const-string v2, "."

    const/4 v5, 0x6

    const-string v2, "."

    const-string v2, "."

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/lang/reflect/Member;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v1, Lcom/alibaba/fastjson/d;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v3, "ygemt rrre00ptor eo/ 3u2s"

    const-string/jumbo v3, "t0sp e23 0r gorpyoueterr/"

    const/4 v5, 0x0

    const-string/jumbo v3, "yr03ort ergrpe0oeo u t/2r"

    const-string v3, "get property error\u3002 "

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-direct {v1, v0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw v1
.end method

.method public c(Lcom/alibaba/fastjson/serializer/m;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x4

    iget v0, p1, Lcom/alibaba/fastjson/serializer/z;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->a:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x6

    and-int/2addr v1, v0

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->b:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    and-int/2addr v0, v1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, v0, Lq0/a;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v2}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->e:[C

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    array-length v2, v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Lcom/alibaba/fastjson/serializer/z;->write([CII)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, v0, Lq0/a;->a:Ljava/lang/String;

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v2}, Lcom/alibaba/fastjson/serializer/z;->r(Ljava/lang/String;Z)V

    :goto_0
    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p1, Lcom/alibaba/fastjson/serializer/j;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/alibaba/fastjson/serializer/j;->a(Lcom/alibaba/fastjson/serializer/j;)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method public d(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->d:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    invoke-virtual {p1, p2, v0}, Lcom/alibaba/fastjson/serializer/m;->E(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->f:Lcom/alibaba/fastjson/serializer/j$a;

    const/4 v4, 0x4

    if-nez v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez p2, :cond_1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    iget-object v0, v0, Lq0/a;->g:Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v2, Lcom/alibaba/fastjson/serializer/j$a;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v2, v1, v0}, Lcom/alibaba/fastjson/serializer/j$a;-><init>(Lcom/alibaba/fastjson/serializer/t;Ljava/lang/Class;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/alibaba/fastjson/serializer/j;->f:Lcom/alibaba/fastjson/serializer/j$a;

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/serializer/j;->f:Lcom/alibaba/fastjson/serializer/j$a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez p2, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget p2, p0, Lcom/alibaba/fastjson/serializer/j;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->h:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    and-int/2addr p2, v1

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-class p2, Ljava/lang/Number;

    const/4 v4, 0x1

    const-class p2, Ljava/lang/Number;

    const-class p2, Ljava/lang/Number;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/16 p2, 0x30

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(I)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget p2, p0, Lcom/alibaba/fastjson/serializer/j;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->i:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    and-int/2addr v1, p2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v4, 0x3

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, v0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ne v1, v2, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string p2, "bamsf"

    const-string/jumbo p2, "seamf"

    const/4 v4, 0x5

    const-string p2, "fuals"

    const-string p2, "false"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_4
    const/4 v4, 0x7

    sget-object v1, Lcom/alibaba/fastjson/serializer/a0;->f:Lcom/alibaba/fastjson/serializer/a0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v1, v1, Lcom/alibaba/fastjson/serializer/a0;->mask:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    and-int/2addr p2, v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz p2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-class p2, Ljava/util/Collection;

    const-class p2, Ljava/util/Collection;

    const/4 v4, 0x0

    const-class p2, Ljava/util/Collection;

    const-class p2, Ljava/util/Collection;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, v0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/alibaba/fastjson/serializer/m;->b:Lcom/alibaba/fastjson/serializer/z;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string p2, "[]"

    const-string p2, "]["

    const/4 v4, 0x6

    const-string p2, "]["

    const-string p2, "[]"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lcom/alibaba/fastjson/serializer/z;->write(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p2, v0, Lcom/alibaba/fastjson/serializer/j$a;->a:Lcom/alibaba/fastjson/serializer/t;

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, v1, Lq0/a;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p2, p1, v2, v1, v0}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, v0, Lcom/alibaba/fastjson/serializer/j$a;->b:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne v1, v2, :cond_7

    const/4 v3, 0x4

    move v4, v3

    iget-object v0, v0, Lcom/alibaba/fastjson/serializer/j$a;->a:Lcom/alibaba/fastjson/serializer/t;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v2, v1, Lq0/a;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, v1, Lq0/a;->h:Ljava/lang/reflect/Type;

    const/4 v3, 0x0

    move v4, v3

    invoke-interface {v0, p1, p2, v2, v1}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v3, 0x4

    const/4 v3, 0x4

    return-void

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p1, Lcom/alibaba/fastjson/serializer/m;->a:Lcom/alibaba/fastjson/serializer/x;

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/alibaba/fastjson/serializer/x;->a(Ljava/lang/Class;)Lcom/alibaba/fastjson/serializer/t;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/alibaba/fastjson/serializer/j;->a:Lq0/a;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, v1, Lq0/a;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, v1, Lq0/a;->h:Ljava/lang/reflect/Type;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0, p1, p2, v2, v1}, Lcom/alibaba/fastjson/serializer/t;->b(Lcom/alibaba/fastjson/serializer/m;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/reflect/Type;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method
