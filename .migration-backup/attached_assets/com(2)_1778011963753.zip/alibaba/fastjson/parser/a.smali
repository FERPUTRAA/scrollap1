.class public Lcom/alibaba/fastjson/parser/a;
.super Lcom/alibaba/fastjson/parser/deserializer/d;


# instance fields
.field protected e:Lcom/alibaba/fastjson/parser/deserializer/f;


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/parser/m;Ljava/lang/Class;Lq0/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/m;",
            "Ljava/lang/Class<",
            "*>;",
            "Lq0/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0, p2, p3, p1}, Lcom/alibaba/fastjson/parser/deserializer/d;-><init>(Ljava/lang/Class;Lq0/a;I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public b(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Object;Ljava/lang/reflect/Type;Ljava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/Type;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ls~~~yo /~@i   4 @ ~b   cK~ ~ b-Siv~~@@f~@n~u bt~@@~i/~ ~~@.@o~o~@o~@@~@~@dm@oa@t@l@@ s@ rM f 1"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v6, 0x3

    const/4 v5, 0x2

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v2, v1, Lq0/a;->g:Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, v1, Lq0/a;->h:Ljava/lang/reflect/Type;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, v2, v1}, Lcom/alibaba/fastjson/parser/m;->d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, v0, Lq0/a;->h:Ljava/lang/reflect/Type;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    instance-of v1, p3, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v1, :cond_2

    const/4 v6, 0x0

    iget-object v2, p1, Lcom/alibaba/fastjson/parser/b;->f:Lcom/alibaba/fastjson/parser/l;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput-object p3, v2, Lcom/alibaba/fastjson/parser/l;->d:Ljava/lang/reflect/Type;

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->b:Ljava/lang/Class;

    const/4 v6, 0x6

    invoke-static {v2, p3, v0}, Lq0/a;->e(Ljava/lang/Class;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p1, Lcom/alibaba/fastjson/parser/b;->b:Lcom/alibaba/fastjson/parser/m;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v2, v0}, Lcom/alibaba/fastjson/parser/m;->e(Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    instance-of v2, v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_3

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast v1, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast p3, Ljava/lang/reflect/ParameterizedType;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p3}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    instance-of v4, v3, Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v3, Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {p3}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object p3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v2, v3, p3}, Lq0/d;->B([Ljava/lang/reflect/Type;[Ljava/lang/reflect/TypeVariable;[Ljava/lang/reflect/Type;)Z

    move-result p3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz p3, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v0, Lq0/c;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getOwnerType()Ljava/lang/reflect/Type;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v0, v2, p3, v1}, Lq0/c;-><init>([Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)V

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p3, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p3, Lq0/a;->n:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    instance-of v3, v2, Lcom/alibaba/fastjson/serializer/h;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v2, Lcom/alibaba/fastjson/serializer/h;

    const/4 v6, 0x4

    iget-object p3, p3, Lq0/a;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2, p1, v0, p3, v1}, Lcom/alibaba/fastjson/serializer/h;->d(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p3

    const/4 v6, 0x5

    goto :goto_0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object p3, p3, Lq0/a;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-interface {v1, p1, v0, p3}, Lcom/alibaba/fastjson/parser/deserializer/f;->a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget v0, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne v0, v1, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/alibaba/fastjson/parser/b;->p()Lcom/alibaba/fastjson/parser/b$a;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object p0, p2, Lcom/alibaba/fastjson/parser/b$a;->c:Lcom/alibaba/fastjson/parser/deserializer/d;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object p3, p1, Lcom/alibaba/fastjson/parser/b;->f:Lcom/alibaba/fastjson/parser/l;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object p3, p2, Lcom/alibaba/fastjson/parser/b$a;->d:Lcom/alibaba/fastjson/parser/l;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 p2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    iput p2, p1, Lcom/alibaba/fastjson/parser/b;->j:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez p2, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object p1, p1, Lq0/a;->a:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {p4, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_1

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez p3, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object p1, p1, Lq0/a;->g:Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object p4, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eq p1, p4, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget-object p4, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eq p1, p4, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    sget-object p4, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eq p1, p4, :cond_7

    const/4 v6, 0x3

    sget-object p4, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-ne p1, p4, :cond_8

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-void

    :cond_8
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, p2, p3}, Lcom/alibaba/fastjson/parser/deserializer/d;->g(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void
.end method

.method public h(Lcom/alibaba/fastjson/parser/m;)Lcom/alibaba/fastjson/parser/deserializer/f;
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, v0, Lq0/a;->g:Ljava/lang/Class;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, v0, Lq0/a;->h:Ljava/lang/reflect/Type;

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v1, v0}, Lcom/alibaba/fastjson/parser/m;->d(Ljava/lang/Class;Ljava/lang/reflect/Type;)Lcom/alibaba/fastjson/parser/deserializer/f;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/alibaba/fastjson/parser/a;->e:Lcom/alibaba/fastjson/parser/deserializer/f;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p1
.end method
