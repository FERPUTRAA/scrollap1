.class public Lcom/alibaba/fastjson/parser/o;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/alibaba/fastjson/parser/o$a;
    }
.end annotation


# instance fields
.field private final a:[Lcom/alibaba/fastjson/parser/o$a;

.field private final b:I


# direct methods
.method public constructor <init>(I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    add-int/lit8 v0, p1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput v0, p0, Lcom/alibaba/fastjson/parser/o;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-array p1, p1, [Lcom/alibaba/fastjson/parser/o$a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/o;->a:[Lcom/alibaba/fastjson/parser/o$a;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    const v0, 0x1215ef

    const/4 v3, 0x1

    move v4, v3

    const-string v1, "er$f"

    const-string v1, "efr$"

    const/4 v4, 0x0

    const-string v1, "er$f"

    const-string v1, "$ref"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2, p1, v0}, Lcom/alibaba/fastjson/parser/o;->a(Ljava/lang/String;III)Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 p1, 0x5

    const/4 v3, 0x0

    const/4 v3, 0x4

    const v0, 0x3bc6f7a

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v1, "ytspe"

    const-string/jumbo v1, "tpsey"

    const-string/jumbo v1, "py@me"

    const-string v1, "@type"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, v1, v2, p1, v0}, Lcom/alibaba/fastjson/parser/o;->a(Ljava/lang/String;III)Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method private static c(Ljava/lang/String;II)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "art/o/~oK1~~u@~@~-y ll~~~@bs@~b~ 4@~o@~~o @ @ v@ @~@@~  . ~t  M Sf~@@o ~~ ~ibmd@co ~o@f@i@n @@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-array v0, p2, [C

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/2addr p2, p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2, v0, v1}, Ljava/lang/String;->getChars(II[CI)V

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/String;-><init>([C)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method


# virtual methods
.method public a(Ljava/lang/String;III)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    iget v0, p0, Lcom/alibaba/fastjson/parser/o;->b:I

    const/4 v3, 0x5

    and-int/2addr v0, p4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/o;->a:[Lcom/alibaba/fastjson/parser/o$a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    aget-object v1, v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, v1, Lcom/alibaba/fastjson/parser/o$a;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne p4, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p4, v1, Lcom/alibaba/fastjson/parser/o$a;->b:[C

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    array-length p4, p4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne p3, p4, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p4, v1, Lcom/alibaba/fastjson/parser/o$a;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    invoke-virtual {p1, p2, p4, v0, p3}, Ljava/lang/String;->regionMatches(ILjava/lang/String;II)Z

    move-result p4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p4, :cond_0

    const/4 v3, 0x6

    iget-object p1, v1, Lcom/alibaba/fastjson/parser/o$a;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, p2, p3}, Lcom/alibaba/fastjson/parser/o;->c(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-object p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-ne p3, v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p2, p3}, Lcom/alibaba/fastjson/parser/o;->c(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->intern()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/alibaba/fastjson/parser/o;->a:[Lcom/alibaba/fastjson/parser/o$a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p3, Lcom/alibaba/fastjson/parser/o$a;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p3, p1, p4}, Lcom/alibaba/fastjson/parser/o$a;-><init>(Ljava/lang/String;I)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    aput-object p3, p2, v0

    const/4 v3, 0x1

    return-object p1
.end method

.method public b([CIII)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    iget v0, p0, Lcom/alibaba/fastjson/parser/o;->b:I

    const/4 v5, 0x6

    and-int/2addr v0, p4

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/o;->a:[Lcom/alibaba/fastjson/parser/o$a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-object v1, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v0, v1, Lcom/alibaba/fastjson/parser/o$a;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ne p4, v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object p4, v1, Lcom/alibaba/fastjson/parser/o$a;->b:[C

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    array-length p4, p4

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-ne p3, p4, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    move p4, v2

    move p4, v2

    const/4 v5, 0x2

    move p4, v2

    move p4, v2

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    if-ge p4, p3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    add-int v0, p2, p4

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    aget-char v0, p1, v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    iget-object v3, v1, Lcom/alibaba/fastjson/parser/o$a;->b:[C

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-char v3, v3, p4

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v0, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    add-int/lit8 p4, p4, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 p4, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v2, p4

    const/4 v5, 0x4

    move v2, p4

    move v2, p4

    :cond_2
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p1, v1, Lcom/alibaba/fastjson/parser/o$a;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object p1

    :cond_3
    const/4 v5, 0x3

    new-instance p4, Ljava/lang/String;

    const/4 v5, 0x7

    invoke-direct {p4, p1, p2, p3}, Ljava/lang/String;-><init>([CII)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object p4

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, p1, p2, p3}, Ljava/lang/String;-><init>([CII)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->intern()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance p2, Lcom/alibaba/fastjson/parser/o$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p2, p1, p4}, Lcom/alibaba/fastjson/parser/o$a;-><init>(Ljava/lang/String;I)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p3, p0, Lcom/alibaba/fastjson/parser/o;->a:[Lcom/alibaba/fastjson/parser/o$a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    aput-object p2, p3, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object p1
.end method
