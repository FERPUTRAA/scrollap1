.class Lcom/alibaba/fastjson/parser/i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/parser/deserializer/f;


# static fields
.field public static final a:Lcom/alibaba/fastjson/parser/i;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/alibaba/fastjson/parser/i;

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-direct {v0}, Lcom/alibaba/fastjson/parser/i;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/alibaba/fastjson/parser/i;->a:Lcom/alibaba/fastjson/parser/i;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/alibaba/fastjson/parser/b;Ljava/lang/reflect/Type;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/reflect/Type;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s  @ @.Sft@olm~~f1@~  ~@@/~ bM~~d@~i~oo b~@@~ins@oK@@4~y~ @uo  @oblvi~~@ @ ~t~   ~ @~r@@c~/-a@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    instance-of v0, p2, Ljava/lang/reflect/GenericArrayType;

    const/4 v1, 0x4

    const/4 v1, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p2, Ljava/lang/reflect/GenericArrayType;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p2}, Ljava/lang/reflect/GenericArrayType;->getGenericComponentType()Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    instance-of p3, p2, Ljava/lang/reflect/TypeVariable;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p3, :cond_0

    const/4 v2, 0x6

    check-cast p2, Ljava/lang/reflect/TypeVariable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {p2}, Ljava/lang/reflect/TypeVariable;->getBounds()[Ljava/lang/reflect/Type;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    aget-object p2, p2, p3

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p3, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1, p2, p3}, Lcom/alibaba/fastjson/parser/b;->I(Ljava/lang/reflect/Type;Ljava/util/Collection;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    instance-of p1, p2, Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p2, Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p2, p1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p1, [Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p3, p1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x1

    invoke-interface {p3}, Ljava/util/List;->toArray()[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, p3}, Lcom/alibaba/fastjson/parser/b;->v(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p1
.end method
