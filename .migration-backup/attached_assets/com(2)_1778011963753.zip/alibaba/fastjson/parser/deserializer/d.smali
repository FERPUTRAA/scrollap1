.class public abstract Lcom/alibaba/fastjson/parser/deserializer/d;
.super Ljava/lang/Object;


# instance fields
.field public final a:Lq0/a;

.field public final b:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field protected c:[Ljava/lang/Enum;

.field protected d:[J


# direct methods
.method public constructor <init>(Ljava/lang/Class;Lq0/a;I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;",
            "Lq0/a;",
            "I)V"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->b:Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x6

    iput-object p2, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v9, 0x7

    if-nez p2, :cond_0

    const/4 v9, 0x4

    return-void

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    iget-object p1, p2, Lq0/a;->g:Ljava/lang/Class;

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/Class;->isEnum()Z

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz p2, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getEnumConstants()[Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    check-cast p1, [Ljava/lang/Enum;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    array-length p2, p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-array p3, p2, [J

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    array-length v0, p1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    new-array v0, v0, [J

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    iput-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v0, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    move v1, v0

    move v1, v0

    const/4 v9, 0x2

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    array-length v2, p1

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ge v1, v2, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    aget-object v2, p1, v1

    const/4 v9, 0x5

    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const-wide v3, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v3, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v3, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const-wide v3, -0x340d631b7bdddcdbL    # -7.302176725335867E57

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    move v5, v0

    move v5, v0

    const/4 v9, 0x6

    move v5, v0

    move v5, v0

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-ge v5, v6, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    int-to-long v6, v6

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    xor-long/2addr v3, v6

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-wide v6, 0x100000001b3L

    const-wide v6, 0x100000001b3L

    const-wide v6, 0x100000001b3L

    const-wide v6, 0x100000001b3L

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    mul-long/2addr v3, v6

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto :goto_1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    aput-wide v3, p3, v1

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v9, 0x3

    aput-wide v3, v2, v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v9, 0x0

    invoke-static {v1}, Ljava/util/Arrays;->sort([J)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    array-length v1, p1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    new-array v1, v1, [Ljava/lang/Enum;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput-object v1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->c:[Ljava/lang/Enum;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v1, v0

    move v1, v0

    const/4 v9, 0x2

    move v1, v0

    move v1, v0

    :goto_2
    const/4 v9, 0x4

    iget-object v2, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    array-length v2, v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ge v1, v2, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    move v2, v0

    move v2, v0

    const/4 v9, 0x5

    move v2, v0

    move v2, v0

    :goto_3
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-ge v2, p2, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    aget-wide v4, v3, v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    aget-wide v6, p3, v2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    cmp-long v3, v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez v3, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->c:[Ljava/lang/Enum;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    aget-object v2, p1, v2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    aput-object v2, v3, v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_4

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x7

    goto :goto_3

    :cond_4
    :goto_4
    const/4 v9, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto :goto_2

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void
.end method


# virtual methods
.method public a(J)Ljava/lang/Enum;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~/sbbd@~s oi  .m  @@~~~@~c~~@oun4l~@@~v t~~    Ky@~l@~@~-~~@oa  t@~~/@ M~i1bi @ S@~ @o f~o@@@@rf"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->c:[Ljava/lang/Enum;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    return-object v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->d:[J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0, p1, p2}, Ljava/util/Arrays;->binarySearch([JJ)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-gez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->c:[Ljava/lang/Enum;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    aget-object p1, p2, p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p1
.end method

.method public abstract b(Lcom/alibaba/fastjson/parser/b;Ljava/lang/Object;Ljava/lang/reflect/Type;Ljava/util/Map;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/alibaba/fastjson/parser/b;",
            "Ljava/lang/Object;",
            "Ljava/lang/reflect/Type;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation
.end method

.method public c(Ljava/lang/Object;D)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget-object v0, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2, p3}, Ljava/lang/reflect/Field;->setDouble(Ljava/lang/Object;D)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public d(Ljava/lang/Object;F)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Ljava/lang/reflect/Field;->setFloat(Ljava/lang/Object;F)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public e(Ljava/lang/Object;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v2, 0x0

    iget-object v0, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Ljava/lang/reflect/Field;->setInt(Ljava/lang/Object;I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;J)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v2, 0x2

    iget-object v0, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p1, p2, p3}, Ljava/lang/reflect/Field;->setLong(Ljava/lang/Object;J)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public g(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez p2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, v0, Lq0/a;->g:Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, v0, Lq0/a;->c:Ljava/lang/reflect/Field;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, v0, Lq0/a;->b:Ljava/lang/reflect/Method;

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-boolean v3, v0, Lq0/a;->d:Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-class v4, Ljava/util/Map;

    const-class v4, Ljava/util/Map;

    const/4 v6, 0x6

    const-class v4, Ljava/util/Map;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v3, :cond_3

    :try_start_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-boolean v2, v0, Lq0/a;->j:Z

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    iget-object v0, v0, Lq0/a;->g:Ljava/lang/Class;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v4, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast p1, Ljava/util/Map;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz p1, :cond_6

    const/4 v6, 0x0

    check-cast p2, Ljava/util/Map;

    const/4 v5, 0x2

    move v6, v5

    invoke-interface {p1, p2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast p1, Ljava/util/Collection;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p1, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast p2, Ljava/util/Collection;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {p1, p2}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, p1, p2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-boolean v1, v0, Lq0/a;->j:Z

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x1

    or-int/2addr v6, v5

    if-eqz v1, :cond_5

    iget-object v0, v0, Lq0/a;->g:Ljava/lang/Class;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v4, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v2, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast p1, Ljava/util/Map;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz p1, :cond_6

    const/4 v5, 0x1

    move v6, v5

    check-cast p2, Ljava/util/Map;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p1, p2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v6, 0x1

    goto :goto_0

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x3

    new-array v0, v3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast p1, Ljava/util/Collection;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p1, :cond_6

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    check-cast p2, Ljava/util/Collection;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {p1, p2}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_0

    :cond_5
    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    aput-object p2, v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :cond_6
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance p2, Lcom/alibaba/fastjson/d;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo v1, "set property error, "

    const-string/jumbo v1, "set property error, "

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/alibaba/fastjson/parser/deserializer/d;->a:Lq0/a;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, v1, Lq0/a;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p2, v0, p1}, Lcom/alibaba/fastjson/d;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    throw p2
.end method
