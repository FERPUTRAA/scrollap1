.class public interface abstract Lcom/alibaba/fastjson/parser/deserializer/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ljava/lang/String;Ljava/lang/Object;)V
.end method
