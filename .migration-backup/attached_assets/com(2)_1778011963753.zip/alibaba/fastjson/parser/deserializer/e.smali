.class public interface abstract Lcom/alibaba/fastjson/parser/deserializer/e;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/alibaba/fastjson/parser/deserializer/g;


# virtual methods
.method public abstract c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Type;
.end method
