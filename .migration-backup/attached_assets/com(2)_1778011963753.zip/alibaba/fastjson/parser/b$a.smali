.class public Lcom/alibaba/fastjson/parser/b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/alibaba/fastjson/parser/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Lcom/alibaba/fastjson/parser/l;

.field private final b:Ljava/lang/String;

.field public c:Lcom/alibaba/fastjson/parser/deserializer/d;

.field public d:Lcom/alibaba/fastjson/parser/l;


# direct methods
.method public constructor <init>(Lcom/alibaba/fastjson/parser/l;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/alibaba/fastjson/parser/b$a;->a:Lcom/alibaba/fastjson/parser/l;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/alibaba/fastjson/parser/b$a;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/alibaba/fastjson/parser/b$a;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t~sSnb~~@y ~ ~~/@ 4@@@rff@oto. ~@ @~ i@  @i d~o~@o@@~a1~buo~~ cv@Mo~ @ ~@~K@~@m@s /l ~@~l~i -b~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/alibaba/fastjson/parser/b$a;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic b(Lcom/alibaba/fastjson/parser/b$a;)Lcom/alibaba/fastjson/parser/l;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/alibaba/fastjson/parser/b$a;->a:Lcom/alibaba/fastjson/parser/l;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method
